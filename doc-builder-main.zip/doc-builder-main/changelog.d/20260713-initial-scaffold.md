---
date: 2026-07-13
---

### Added

- **Project scaffolding (Phase 0)** — Initial repository setup with README, GitLab CI (SAST + Secret Detection) (`2f0d280`, `590ddc8`, `1769af3`)
- Build plan document (`157e4de`, `833b8e4`)
- `CLAUDE.md` project instructions (`6bf9e1e`)
- Vite + React + TypeScript + Tailwind scaffold with GitLab Pages deployment CI (`64a1360`)
- **Schema engine (Phase 1)** — Document type schema format (sections → fields with types, AI hints, output templates) (`7d225cf`); schema loader with validation and TypeScript types; NDA as first document type
- **Interview UI (Phase 2)** — Wizard shell with three-panel layout: section outline, field editor, AI panel placeholder (`4a5858f`); field renderer supporting `string`, `number`, `boolean`, `date`, `enum`, and `freetext` types; IndexedDB persistence via Dexie (sessions, answers); interview engine with section completion tracking (○ empty, ◐ in-progress, ✓ complete); Review page showing all answers organized by section
- **Document export (Phase 3)** — Markdown template substitution with `{{section_id.field_id}}` placeholders → HTML preview (`f08c140`); rendered preview page with print-to-PDF support
- Resizable sidebar component (`0314e15`)
- Top menu bar with File/Edit/View dropdowns and confirmation dialogs (`db1c339`)
- App sidebar with session list and schema picker (`7a0632b`)
