---
date: 2026-07-14
---

### Added

- **AI writing assistant (Phase 4b)** — AI chat panel for drafting `freetext` fields via LiteLLM proxy (`1bf9325`)
- OpenAI-compatible chat completions API integration with streaming support
- Chat UI: message list, input bar, collapsible right panel
- System prompt generation with schema/field context for targeted drafting
- Settings dialog for API key configuration (stored in localStorage)
- Separated draft output blocks for easy copy-to-field workflow (`63cfca1`)
- Active field highlighting so AI panel shows which field is being drafted (`bc254e7`)
- Persisted chat history per session in IndexedDB
- **Word document generation** — `.docx` output support using `docx` library alongside existing Markdown/HTML export (`bb7c0e3`); schemas can reference a `docx_template`
- FMS Memo SH Request as first Word-templated document type (`03854fe`)
- AI ingestion design doc (`docs/2026-07-14-ai-ingestion.md`) covering extraction architecture (`60a1255`)
- Expanded build plan with Word doc builder requirements

### Fixed

- Sidebar not updating when switching between sessions (`194e7af`)
