---
date: 2026-07-15
---

### Added

- **Bulk AI extraction (Phase 4)** — Upload a document (Word/PDF) and have AI extract field values across multiple sections at once (`cfcfcfc`)
- File parsing utilities (mammoth for `.docx`, pdf.js for PDF text extraction)
- Multi-step bulk-edit UI: section selector → file/text input → AI extraction → diff preview → apply
- Verbose logging and progress indicators for extraction pipeline
- **LCSP schema** — Life Cycle Sustainment Plan with 586-line field definition and `.docx` template (`93634cf`); includes `tools/prepare-lcsp-template.py` helper

### Changed

- **Navigation refactor** — Extracted session/interview state into a shared `SessionContext` provider, replacing per-page `useInterview` hook (`dfed154`); simplified `AppSidebar`, `AppMenuBar`, and route-level pages to consume context
- Fixed Vite base path and React Router `basename` for GitLab Pages sub-path hosting (`11991e9`)
- Moved static assets from `public/` to `static/` (`a760de6`)
- Fixed internal navigation links across all route-level pages (`d80689f`)
- Updated README with access link and GitLab Pages setup notes (`e38e347`, `6d1d57d`)

### Fixed

- Error handling when no text can be extracted from an uploaded document (`621d7de`)
- File upload parsing bug (`60668f7`)
- Bulk AI editor failing with "not valid JSON" error when a file is uploaded and then the user types a prompt — document text was being dropped when input mode switched
