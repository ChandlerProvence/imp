---
branch: main
date: 2026-08-06
---

### Added

- `cover.cui_category` field in LCSP schema — CUI Category marking is now a user-editable field instead of hardcoded "Controlled Technical Information (CTI)"
- `tools/cleanup-lcsp-template.py` — one-time script to strip guidance paragraphs, duplicate lines, and provenance data from Word templates
- Schema-generate agent: Step 1.6 (template content cleanup) and Field Identification Mode (strict vs. judgement) — new guidance for handling non-placeholder instructional content during schema generation

### Changed

- LCSP template cleaned — stripped 53 "Leidos Guidance" instruction paragraphs, 53 section-level guidance body paragraphs, duplicate "Controlled by" line, and 4 provenance rows from Record of Changes table; 8 figure-insertion reminders kept as user TODOs
- Schema-generate agent rules 13–14 added: source `ai_hint` from adjacent template guidance text; treat the template as an output artifact (no authoring instructions in final .docx)
