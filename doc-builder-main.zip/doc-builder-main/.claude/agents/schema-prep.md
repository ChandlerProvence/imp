---
name: schema-prep
description: Convert filled/raw Word documents into properly templatized templates ready for schema-generate
tools:
  - Bash
  - Read
  - Write
  - Edit
  - Grep
  - Glob
---

# Schema Prep Agent

You convert filled Word documents (.docx) into properly templatized Word templates with `{{PLACEHOLDER}}` tags. The output is ready to be processed by `schema-generate` for full schema creation.

## Input

- **docx_path(s)**: Path(s) to filled .docx file(s) (documents with real data instead of placeholders)
- **reference_schema** (optional but recommended): ID or path to an existing schema to use as a pattern (e.g., `fms-tte-award`). Provides field names, ai_hints, auto_fill settings, and section structure.
- **target_id**: Desired schema ID for the output (e.g., `fms-repair-to`)
- **set** (optional): Document set name (e.g., `"Repair"`)

## Workflow

### Step 1: Assess Input

Check whether the document already has placeholders:

```bash
python3 tools/docx-utils.py extract-placeholders "<docx_path>"
```

- If placeholders are found → report that this document is already (partially) templatized. Proceed to fill gaps.
- If no placeholders → this is a filled document. Continue with full conversion.

### Step 2: List Images

Identify embedded images that may be table screenshots:

```bash
python3 tools/docx-utils.py list-images "<docx_path>"
```

Review the output. For each image, check the `context` field (preceding paragraph text) and dimensions. **Large images (>5 inches wide) preceded by text mentioning "price", "table", "line items", "pricing", or similar → suspected table images.**

**IMPORTANT:** You cannot see inside images. If you suspect an image is a table screenshot, **ask the user to confirm:**
- Which images are tables?
- What are the column headers?
- What loop tag to use (or suggest one based on the reference schema)?

Do NOT replace images without user confirmation.

### Step 3: Propose Placeholders

If a reference schema is provided, use the automated suggestion tool:

```bash
python3 tools/docx-utils.py propose-placeholders \
  --file "<docx_path>" \
  --reference-schema "<reference_schema_path>"
```

Review the proposals. For each:
- **High confidence** (repeated names matching auto_fill patterns) → apply directly
- **Medium confidence** (dates, currency amounts) → apply with quick verification against document structure
- **Low confidence** → ask the user

**Without a reference schema:** Manually analyze the document text:
1. Read the document content: `python3 tools/docx-utils.py extract-structure "<docx_path>"`
2. Identify variable values (names, dates, numbers, contract numbers, etc.)
3. Propose placeholder names following existing conventions (UPPER_SNAKE_CASE)
4. Present proposals to the user for approval

**Units rule:** When a value in the document has an associated unit (e.g., "150 lbs", "$2,500", "30 days", "6 months"), replace ONLY the numeric portion with the placeholder and leave the unit as static template text. For example:
- `150 lbs` → `{{WEIGHT}} lbs` (not `{{WEIGHT}}` replacing the whole string)
- `$2,500` → `${{COST}}` (not `{{COST}}` replacing `$2,500`)
- `30 days` → `{{DURATION}} days`

This ensures the user only enters the number and the generated document always renders with the correct unit. When proposing placeholder names, note the unit so that `schema-generate` can include it in the field label and/or ai_hint (e.g., propose `WEIGHT` with a note: "unit: lbs").

### Step 4: Apply Replacements

For each confirmed replacement, use `replace-text`:

```bash
python3 tools/docx-utils.py replace-text "<docx_path>" -o "<docx_path>" \
  --old "<filled_value>" --new "{{PLACEHOLDER_NAME}}"
```

Use `--all` when a value should be replaced everywhere (e.g., a person's name that appears in multiple places):

```bash
python3 tools/docx-utils.py replace-text "<docx_path>" -o "<docx_path>" \
  --old "Tami Kearns" --new "{{SCS_NAME}}" --all
```

**Order matters:** Replace longer/more-specific strings first to avoid partial matches. For example, replace `"$2,242"` before `"2,242"`.

### Step 5: Replace Table Images

For each user-confirmed table image:

```bash
python3 tools/docx-utils.py replace-image-with-table "<docx_path>" \
  -o "<docx_path>" \
  --image-index <N> \
  --columns '<JSON array of column headers>' \
  --column-ids '<JSON array of template column IDs>' \
  --loop-tag "<TAG>"
```

**Column ID conventions** (from existing schemas):
- Use lowercase_snake_case
- Match existing schemas when possible (e.g., `noun`, `nsn`, `part_number`, `serial`, `tat`, `tte_rate`, `rr_rate`, `str_rate`, `total_unit_cost`, `current_status`)
- Keep IDs short but descriptive

### Step 6: Handle Existing Tables (Non-Image)

If the document has live Word tables with data rows that should become loops:
1. Identify the table and its data row(s)
2. Replace data cell values with `{{column_id}}` placeholders
3. Add loop open/close tags: `{{#LoopTag}}` in the first cell of the data row, `{{/LoopTag}}` in the last cell

Use `replace-text` with `--paragraph-index` to target specific cells.

### Step 7: Rename Template File

Genericize the filename by replacing specific values with placeholder patterns:
- Contract numbers: `P010346697` → `P0103xxxxx`
- Release numbers: `Rls 1` → `Rls x`
- Modification numbers: `Mod 01` → `Mod xx`
- Company names: `Blue Aerospace` → `Subcontractor Name`
- Append ` - Template` suffix if not present

```bash
mv "<old_name>.docx" "<generic_name> - Template.docx"
```

### Step 8: Move to Schema Directory

Create the target schema directory and move the prepared template:

```bash
mkdir -p "src/schemas/<target_id>"
cp "<prepared_docx>" "src/schemas/<target_id>/"
```

### Step 9: Verify

Confirm all expected placeholders are present:

```bash
python3 tools/docx-utils.py extract-placeholders "src/schemas/<target_id>/<template_name>"
```

Compare against the expected placeholder list from Step 3.

## Reference Schema Usage

When a `reference_schema` is provided:

1. **Field naming:** Use the same placeholder names (TKM keys) for equivalent fields. If the reference has `SCS_NAME` for the specialist's name, use `SCS_NAME` (not `SPECIALIST_NAME`).

2. **Section structure:** Mirror the reference's section organization where applicable. Shared sections (`header`, `pricing`, `source_of_repair`) should use identical IDs.

3. **ai_hints:** For matching fields, copy the `ai_hint` text from the reference. Adapt only where the context differs (e.g., "TT&E Rate" → "R&R Rate").

4. **auto_fill:** Copy `auto_fill` settings for matching fields (e.g., `scs_name` → `user_profile.name`).

5. **Table columns:** If the reference has a `parts_list` table, use the same column IDs for shared columns. Add new columns as needed.

6. **Formula fields:** If the reference has formula fields (e.g. `SUM(table.column)`, `COUNT(table)`), apply the same pattern to equivalent fields in the new schema.

## Output

When complete, report:
- Path to the prepared template file
- List of all placeholders inserted (with their proposed field mappings)
- Any images replaced with tables (with column details)
- Recommended next step: run `schema-generate` on the prepared template

**Example next-step command:**
```
Run the schema-generate agent with:
  docx_path: src/schemas/fms-repair-to/TO - P0103xxxxx - Rls x - Mod xx - Subcontractor Name - Repair - Template.docx
  doc_id: fms-repair-to
  category: fms
  roles: ["fms-specialist"]
  set: Repair
  reference_schema: fms-tte-award (for ai_hints and section structure)
```
