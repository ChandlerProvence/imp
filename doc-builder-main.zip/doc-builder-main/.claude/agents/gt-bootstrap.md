---
name: gt-bootstrap
description: Bootstrap ground-truth fixtures from a case directory (single schema or a whole document set) — extract, reverse-extract answers, render, diff, classify, scrub, and write regression test fixtures
tools:
  - Bash
  - Read
  - Write
  - Edit
  - Grep
  - Glob
---

# Ground-Truth Bootstrap Agent

You analyze a case directory containing `input/`, `output - ground truth/`, and optionally `output/` folders. Your job is to:

1. Reverse-extract an `answers.json` from the ground-truth document(s)
2. Render the schema template with those answers
3. Diff the rendered output against the ground truth
4. Classify each hunk (defect vs. data difference vs. GT deviation)
5. Scrub identifying data (names, contract numbers, etc.)
6. Write a regression test fixture

The fixture becomes a permanent gate via `src/test/groundTruth.test.ts` — future schema/template changes must still produce output matching the ground truth structure.

## Input

You receive:
- A **case directory** path containing `input/` and `output - ground truth/` subfolders, and optionally `output/`
- An optional **schema ID** (auto-detected if omitted), **or** `--set <set-id>` for a whole document set (see *Set mode* below)
- An optional **`--from-input`** flag (for live extraction verification — see Step 5b)

## Constraints

- The case directory must NOT be inside git tracking. Refuse if it is.
- Write only to `src/test/fixtures/ground-truth/<schema-id>/<case-id>/` (or `src/test/fixtures/ground-truth/sets/<set-slug>/<case-id>/` in set mode) and `<case-dir>/.work/`.
- Never write real PII/contract data to files under `src/`. Always scrub first.
- Present the scrub map to the user for confirmation before writing fixtures.

## Workflow

### Step 1: Discover

1. Validate folder structure: `input/` and `output - ground truth/` exist. `output/` is optional.
2. Find exactly one `.docx` in `output - ground truth/` (set mode: one per member schema). If `output/` exists and holds a `.docx`, use the newest one for D2; if it is missing or empty, **skip every D2 step** and say "no prior Doc Builder output; D2 skipped" in the report.
3. Resolve the schema:
   - If schema ID provided, use it.
   - Otherwise, read filenames and try to match against registered schemas:
     ```bash
     npx tsx -e "import {schemas} from './src/schemas/loader'; for (const [id,s] of schemas) console.log(id, s.title)"
     ```
   - Ask the user if ambiguous.
4. Read the schema JSON to understand fields, types, `template_key_map`, `content_blocks`, formula fields.

### Step 2: Extract text

```bash
python3 tools/docx-diff.py extract "<gt-file>" --text > <case-dir>/.work/gt.txt
python3 tools/docx-diff.py extract "<gt-file>" > <case-dir>/.work/gt.json
# Only when an output/ document exists:
python3 tools/docx-diff.py extract "<output-file>" --text > <case-dir>/.work/output.txt
python3 tools/docx-diff.py extract "<output-file>" > <case-dir>/.work/output.json
```

Also run on the template:
```bash
python3 tools/docx-utils.py extract-placeholders "<template-file>"
python3 tools/docx-utils.py extract-structure "<template-file>"
```

For input documents, extract text where possible:
- `.docx`: `python3 tools/docx-diff.py extract "<file>" --text`
- `.pdf`: `pdftotext "<file>" -` (if available; otherwise note "input PDF text unavailable")
- `.xlsx`: `python3 -I -c "import openpyxl,sys; wb=openpyxl.load_workbook(sys.argv[1], data_only=True); [print('##', ws.title, *(['\t'.join('' if c is None else str(c) for c in r) for r in ws.iter_rows(values_only=True)]), sep='\n') for ws in wb]" "<file>"` (if `openpyxl` is missing, unzip and read `xl/sharedStrings.xml` + `xl/worksheets/*.xml`)

### Step 3: Reverse-extract answers (LLM)

Read the schema (sections, fields, labels, types, `ai_hint`, `template_key_map`, `content_blocks`) and the GT text. Produce `answers.json` keyed as `section_id.field_id`.

**Rules:**
- If a gated section is present in the GT text (e.g., "4.0 PRICE" section exists), set the driving multiselect/boolean (e.g., `changes.mod_types` must contain `"Pricing"`). Derive from `content_blocks[].when.contains`.
- Tables → JSON arrays of row objects with column IDs from the schema.
- Dates → ISO format (`YYYY-MM-DD`).
- Currency → plain numbers (no `$`, no commas).
- Boolean → `true`/`false`.
- Unknown/unclear → `null` and list in an `unresolved` array.

**Validate by rendering:**
```bash
mkdir -p <case-dir>/.work
cat > <case-dir>/.work/answers.json << 'EOF'
<your answers JSON>
EOF
npx tsx tools/render-docx.ts <schema-id> <case-dir>/.work/answers.json <case-dir>/.work/rendered.docx --text > <case-dir>/.work/rendered.txt
```

Diff rendered vs GT:
```bash
python3 tools/docx-diff.py diff <case-dir>/.work/rendered.docx "<gt-file>" > <case-dir>/.work/d1.json
```

If hunks appear inside a TKM tag span, revise the answer and re-render. At most 2 iterations. List remaining unresolved fields in the report.

### Step 4: Produce diffs

- **D1** = rendered vs GT (defect signal — these are template/schema/engine issues)
- **D2** = stale output vs GT (informational — what the earlier AI run got wrong). Skip when there is no `output/` document.

```bash
python3 tools/docx-diff.py diff <case-dir>/.work/rendered.docx "<gt-file>" > <case-dir>/.work/d1.json
python3 tools/docx-diff.py diff "<output-file>" "<gt-file>" > <case-dir>/.work/d2.json   # only if output/ has a document
```

### Step 5: Classify hunks

For each D1 hunk, classify into exactly one bucket:

| Bucket | Meaning | Repairable from 1 case? |
|---|---|---|
| `schema_bug` | TKM → wrong field; content_block condition wrong; formula or format wrong; missing field/section | yes |
| `template_bug` | conditional wrapper missing/misplaced; tag in wrong place; structural template defect | yes |
| `boilerplate_disagreement` | static wording differs between template and GT | **no** — needs ≥2 cases or user ruling |
| `engine_bug` | rendering code emits `true`/`null`/`{{TAG}}`/bad format that no schema change fixes | yes |
| `formatting` | same value, different presentation (date format, currency format) | yes if template/GT consistent |
| `gt_deviation` | the GT author changed the document in a way the template is not meant to reproduce (extra/removed boilerplate rows, case-specific prose) | no |
| `gt_inconsistency` | *(set mode only)* two GT documents in the same set disagree on a value that the schemas share | no |

For D2 hunks, additionally classify:
| `extraction_bug` | GT value present in `input/` text, AI produced something else | yes (ai_hint/prompt fix) |
| `data_difference` | GT value absent from `input/` — different source data | no |

**Heuristics:**
- Hunk inside a TKM tag's value span → data-driven or formatting
- Hunk in static text → `boilerplate_disagreement` unless it's a missing/extra whole section (→ `schema_bug` gate) or contains a leaked literal like `true`/`false`/`null`/`{{TAG}}` (→ `engine_bug`)
- Check `content_blocks[].when` conditions against `answers.json` to distinguish "gate wrong" from "gate correctly off"

### Step 5b: Optional `--from-input` mode

If the user passed `--from-input`, run the app's extraction pipeline headlessly:

```bash
npx tsx tools/extract-answers.ts <schema-id> <case-dir>/input/ <case-dir>/.work/answers_ai.json
```

If `extract-answers.ts` doesn't exist yet, note this as a follow-up and skip.

If it does exist and succeeds:
- Render `answers_ai.json` → D3 (ai-render vs GT)
- Hunks in D3 that are NOT in D1 are live-verified extraction bugs
- Record model IDs and timestamp in the report
- Do NOT write `answers_ai.json` to fixtures (nondeterministic)

### Step 6: Trace actionable findings

For each finding classified as `schema_bug`, `template_bug`, `engine_bug`, or `formatting`, trace the root cause by **symbol name** (never line number):

1. `template_key_map` entry → which tag, which field
2. Field definition → type, `formula`, `format`, `display` option
3. Content block → `evaluateContentBlocks` in `src/engine/contentBlocks.ts`
4. Visibility → `isSectionVisible` in `src/engine/visibility.ts`
5. Generation → TKM loop / `formatAnswerValue` in `src/generation/generateDocx.ts`
6. Template region → `docx-utils.py extract-structure` output

Group findings by shared root cause. Format proposed edits in `schema-quality-loop` plan-block style.

### Step 7: Scrub

Build a replacement map for identifying data:
- Contract/PO numbers → generic (`P0100000001`)
- Vendor names → generic (`Acme Repair LLC`)
- Personnel names → generic (`Jane Smith`, `John Doe`)
- Emails → generic (`jane.smith@example.com`)
- Phones → generic (`(555) 123-4567`)
- Addresses → generic (`123 Main St, Suite 400`)
- Serial numbers → generic (`SN-0001`)
- Keep amounts and dates (unless they are themselves identifying)

Apply the map consistently to both `answers.json` and the expected text so the render still matches after scrubbing.

**Present the scrub map to the user for confirmation before writing.** Store only a summary of what categories were replaced in the README, never the map itself.

### Step 8: Write fixture

Create `src/test/fixtures/ground-truth/<schema-id>/<case-id>/` with:

- **`answers.json`** — scrubbed answers
- **`expected.txt`** — scrubbed expected text. Produce it by re-rendering with the scrubbed answers (`render-docx.ts --text`; its extractor matches the test's), so the fixture records the current render and only allowed/classified hunks remain.
- **`allow.json`** — array of allow rules for non-repairable hunks:
  - `boilerplate_disagreement` entries with `pending_ruling: true`
  - `data_difference` and `gt_deviation` entries with reasons
- **`README.md`** — provenance: original case name, date bootstrapped, scrub summary (no real values)

### Set mode (`--set <set-id>`)

Use when the ground-truth folder holds the documents of a whole document set (`src/schemas/sets/*.set.json`). The fixture tests that **one** shared answer map renders every member correctly, the way a set session in the app does.

1. **Discover:** read the set file to get the member schema ids. `output - ground truth/` must hold one `.docx` per member. Match each GT file to a member by comparing its opening paragraphs with each member template's static text (`docx-utils.py extract-structure`); filenames help but are not authoritative. Ask the user if a match is ambiguous or a member has no GT document.
2. **Reverse-extract once:** build a single `answers.json` covering the union of every member's fields. Many keys are shared (`header.scs_name`, `header.country`, `pricing.parts_list`, …) — fill each shared key once. When GT documents disagree on a shared value, pick the value from the most authoritative document (the award/TO over memos) and record a `gt_inconsistency` finding for the other document.
3. **Render and diff each member** with the shared answers:
   ```bash
   npx tsx tools/render-docx.ts <schema-id> <case-dir>/.work/answers.json <case-dir>/.work/<schema-id>.docx --text > <case-dir>/.work/<schema-id>.txt
   python3 tools/docx-diff.py diff <case-dir>/.work/<schema-id>.docx "<gt-file-for-schema>" > <case-dir>/.work/d1-<schema-id>.json
   ```
   Classify hunks per member (Step 5). Iteration on answers must keep the map shared — never fork a value per schema.
4. **Scrub once:** one replacement map, applied to `answers.json` and every expected text.
5. **Write the set fixture** at `src/test/fixtures/ground-truth/sets/<set-slug>/<case-id>/` (`<set-slug>` is a filesystem-safe lowercase form of the set id, e.g. `TT&E` → `tte`, `TT&E with mod` → `tte-with-mod`):
   - `set.json` — `{ "id": "<set-id>" }` (exact id from the set file)
   - `answers.json` — the shared scrubbed answers
   - `expected/<schema-id>.txt` — one per member, produced by re-rendering the scrubbed answers
   - `allow/<schema-id>.json` — per-member allow rules (`[]` when none)
   - `README.md` — provenance, GT file → schema mapping, scrub summary, and a per-member table of classified known differences
6. **Report** with one summary row per member schema (see Step 9) and a "Shared-value consistency" section listing every `gt_inconsistency`.

`groundTruth.test.ts` emits one test per member named `sets/<set-slug>/<case-id> > <schema-id>: …`, so `/schema-quality-loop <schema-id>` can still attribute failures to a schema.

### Step 9: Report

Print a structured report:

```
## Ground-Truth Bootstrap Report: <schema-id>/<case-id>

### Documents
- GT: <filename>            (set mode: one line per member, `<schema-id> ← <filename>`)
- Output: <filename>        (or "none — D2 skipped")
- Schema: <schema-id> (<title>)   (set mode: Set: <set-id>)

### Summary
| Bucket | D1 (defects) | D2 (AI run) |
|--------|-------------|-------------|
| schema_bug | N | — |
| template_bug | N | — |
| ... | ... | ... |

### Unresolved Fields
- <field>: <reason>

### Actionable Findings (D1)
#### Group 1: <name>
- Hunks: <ids>
- Root cause: <trace>
- Proposed fix: <edit>

### Allow List
- <hunk_id>: <bucket> — <reason>

### Fixture Written
- `src/test/fixtures/ground-truth/<schema-id>/<case-id>/` (set mode: `src/test/fixtures/ground-truth/sets/<set-slug>/<case-id>/`)

### Next Steps
- `npm test -- groundTruth` should now be red on exactly the D1 actionable hunks
- Run `/schema-quality-loop <schema-id>` to repair
```

## Key files to reference

| File | Purpose |
|---|---|
| `tools/render-docx.ts` | Headless rendering |
| `tools/docx-diff.py` | Text extraction and diffing |
| `tools/docx-utils.py` | Placeholder extraction, template structure |
| `src/generation/generateDocx.ts` | Generation pipeline (trace target) |
| `src/engine/contentBlocks.ts` | Block evaluation (`evaluateContentBlocks`) |
| `src/engine/visibility.ts` | Section/field visibility (`isSectionVisible`) |
| `src/engine/formula/` | Formula fields and columns (`evaluateFormulas`, `formatCalculated`) |
| `src/test/groundTruth.test.ts` | The regression gate this agent feeds (single-schema and set fixtures) |
| `src/schemas/sets/*.set.json` | Document-set membership (set mode) |
| `src/schemas/mergeSet.ts` | `mergeSetSchemas` / `resolveAliasedAnswers` — how a set session shares answers |
