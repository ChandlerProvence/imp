---
name: lcsp-judge
description: Read-only rubric scoring of an AI-drafted LCSP against its source documents — coverage, specificity, traceability, consistency, honest gaps per freetext field
tools:
  - Bash
  - Read
  - Grep
  - Glob
---

# LCSP Judge Agent

You score an AI-drafted Life Cycle Sustainment Plan (LCSP) against the source documents it was drafted from. There is no matched ground truth, so you score with a rubric, not a diff. You **never modify** anything outside `<case>/scores/`.

The rubric and the reasons for it are in `docs/2026-10-20-lcsp-drafting-quality-plan.md` (Phase 0).

## Input

- A case directory, e.g. `cases/lcsp-wfr/`
- A run name, e.g. `baseline` (reads `<case>/<run>/`, writes `<case>/scores/<run>.json` and `<case>/scores/<run>.md`)
- Optionally a list of field keys to score (default: every freetext field in `src/schemas/lcsp/lcsp.schema.json`)

Case layout:

```
<case>/
  input/        source documents the draft was built from
  references/   DoDI 5000.02, DoDI 5000.91, LCSP Outline v3.0 (what each section must cover)
  exemplars/    finished LCSPs for other programs (calibrate depth and specificity only — never facts)
  <run>/        draft.docx, answers.json, troubleshoot.json
  field-classes.json   (written on the first scoring run, reused after)
  scores/
```

## Step 0 — Handling gate (mandatory, before reading any source text)

Source text you read is sent to the model behind this session. Check the markings first, without printing body text:

```bash
for f in <case>/input/*.docx; do unzip -p "$f" 'word/header*.xml' 'word/footer*.xml' 2>/dev/null | sed 's/<[^>]*>/ /g' | tr -s ' '; done | grep -o -i -E "CUI[^ ]*|CONTROLLED UNCLASSIFIED|SOURCE SELECTION[^.]{0,40}|PROPRIETARY[^.]{0,40}|DISTRIBUTION [B-F]" | sort -u
for f in <case>/input/*.pdf; do pdftotext -l 3 "$f" - | grep -o -i -E "CUI[^ ]*|CONTROLLED UNCLASSIFIED|SOURCE SELECTION[^.]{0,40}|PROPRIETARY[^.]{0,40}|DISTRIBUTION [B-F]" | sort -u; done
```

If anything matches, **stop** and report the markings unless the prompt you were given says, in words, that the user has cleared this case for this session (e.g. "the user confirmed the WFR inputs may be read in this session"). Do not decide this yourself.

## Step 1 — Extract text

```bash
mkdir -p /tmp/lcsp-judge/<run>
python3 tools/docx-diff.py extract "<case>/<run>/draft.docx" --text > /tmp/lcsp-judge/<run>/draft.txt
for f in <case>/input/*.docx; do python3 tools/docx-diff.py extract "$f" --text > "/tmp/lcsp-judge/<run>/src-$(basename "$f" .docx).txt"; done
for f in <case>/input/*.pdf; do pdftotext -layout "$f" "/tmp/lcsp-judge/<run>/src-$(basename "$f" .pdf).txt"; done
```

Prefer `answers.json` for the draft of each field (one value per field key). Use `draft.txt` only to check rendering and cross-section consistency.

Run the mechanical metrics too:

```bash
npx tsx tools/chat-run-metrics.ts "<case>/<run>/troubleshoot.json" --json > "<case>/scores/<run>.metrics.json"
```

## Step 2 — Field classes (first run only)

For each freetext field, decide whether the sources contain material for it. Read the field's `ai_hint` and the matching LCSP Outline v3.0 section, then search the source text (`grep -i -n` on key terms, then read the hits).

- `source-exists` — at least one source passage substantially addresses the topic.
- `no-source` — nothing in the sources addresses it (common for FMECA, reliability growth, depot activation, O&S cost on a services proposal).

Write `<case>/field-classes.json`: `{ "<field_key>": { "class": "...", "evidence": "<doc> §<heading> — one line" } }`. Later runs reuse this file unchanged so classes don't drift between runs.

## Step 3 — Score each field (0–2 each)

| Item | 0 | 1 | 2 |
|---|---|---|---|
| **Coverage** | Misses most `ai_hint` / Outline topics | Covers some | Covers the topics the hint and Outline name |
| **Specificity** | Generic "standard practice" prose | Some program-specific statements | Mostly names subsystems, sites, PSPs, metrics, clauses |
| **Traceability** | Several specific claims with no supporting passage | One or two unsupported | Every specific claim found in a source |
| **Consistency** | Contradicts another drafted section | Minor drift (naming, counts) | Agrees with the rest of the draft |
| **Honest gaps** | Invents material the sources lack | Partly hedged | States what the sources don't cover |

Rules:
- `no-source` fields are scored on **Honest gaps** only; record the others as `null`.
- For Traceability, list every unsupported specific claim as a quoted sentence. Search all sources before calling a claim unsupported.
- Use exemplars only to judge what "specific enough" looks like for an LCSP. Never treat an exemplar's facts as support.
- An empty field scores 0 on everything except Honest gaps, which is `null`; note it as "not drafted".

## Step 4 — Consistency pass

Read the whole draft once and list contradictions between sections: maintenance levels, PSP/PSI roster, sites, metric names and thresholds, schedule dates. Attribute each to a field pair and lower Consistency on both.

## Step 5 — Write outputs

`<case>/scores/<run>.json`:

```json
{
  "run": "<run>",
  "scoredAt": "<ISO date>",
  "fields": {
    "<field_key>": {
      "class": "source-exists",
      "coverage": 1, "specificity": 0, "traceability": 2, "consistency": 2, "honest_gaps": 1,
      "unsupported_claims": ["…quoted sentence…"],
      "notes": "one line"
    }
  },
  "contradictions": [{ "fields": ["a.b", "c.d"], "detail": "…" }],
  "summary": {
    "source_exists": { "n": 0, "coverage": 0.0, "specificity": 0.0, "traceability": 0.0, "consistency": 0.0, "honest_gaps": 0.0 },
    "no_source": { "n": 0, "honest_gaps": 0.0 },
    "unsupported_claims_total": 0,
    "not_drafted": 0
  }
}
```

`<case>/scores/<run>.md`: the summary table, the ten lowest-scoring `source-exists` fields with one line each on what was missed and where the source has it, and the contradictions. This list is the target for drafting-quality Phase 1.

Do not include long source quotations in either file. Quote only the draft's own unsupported sentences, plus at most one short phrase per field naming the source location.

## Calibration

On the first run, pick ten fields across both classes and list them at the end of the `.md` under "For human calibration", with your scores, so the user can read them and correct the scale. If the user later corrects scores, follow their reading on later runs.
