---
description: "Generate, validate, or repair document schemas from Word templates (.docx). Handles single templates, batches (document sets), validation, repairs, and converting filled documents into templates."
---

# New Schema

Schema management for doc-builder — generate new schemas, validate existing ones, or repair alignment between schemas and templates.

## Instructions

You are the interactive entry point for schema operations. Detect the user's intent, gather required information, then spawn the appropriate agent.

### Step 1: Detect intent

From the user's message, determine which mode applies:

**Mode A: Generate** — user says "new schema", "create schema", "generate", provides a template path that has no existing schema, or provides unregistered .docx files.

**Mode B: Validate** — user says "check", "validate", "audit", "are schemas aligned", "compare", or asks about schema-to-template alignment status. Does NOT imply fixing anything.

**Mode C: Repair** — user says "repair", "fix", "update schema", "sync template", "add placeholder tags", or provides a template that already has a schema and wants changes.

**Mode D: Health Check** — user says "template health", "deep check", "pre-flight", "generation check", "will this render", "runtime validation", "health check", or asks whether generation will produce correct output. Deeper than validate — checks TKM integrity, loop syntax, naming conventions, schema structure, and runtime viability.

**Mode E: Prep (Filled Doc → Template)** — user provides a filled document (no `{{` tags) that needs to be converted into a template, says "convert to template", "templatize", "prep", "filled document", or provides a `--reference` schema. Also triggered when a `.docx` file is provided that has no existing schema AND running `extract-placeholders` on it returns no tags.

If ambiguous, ask:
> Would you like me to (a) generate a new schema from a templatized .docx, (b) validate existing schemas for issues, (c) repair schema/template alignment, or (d) convert a filled document into a template?

### Step 2: Gather input (mode-specific)

#### Mode A: Generate

Ask for:
1. **Template(s)** — "What's the path to the .docx template file(s)?"
   - If they provide a directory, list the .docx files in it for confirmation.
   - If nothing provided, look for unregistered templates: list `.docx` files in the repo that aren't already in `src/schemas/`.

2. **Single or set?** — if multiple templates: "Should these be grouped as a document set? If so, what's the set name?"

3. **Optional metadata** (offer defaults of "skip"):
   - `category` — check `src/categories.ts` for available categories
   - `roles` — restrict to certain roles

#### Mode B: Validate

Ask for:
1. **Scope** — "Which schemas should I validate? (specific path, set name, or 'all')"
   - Default to "all" if user said something generic like "check schemas" or "health check"

No other inputs needed — validation is read-only.

#### Mode C: Repair

Ask for:
1. **Scope** — "Which schema(s) need repair?" (path, doc-id, set name, or "all")

2. **Template modification** — "Should I also modify the .docx template to add missing placeholder tags, or only fix the schema JSON?"
   - Default: fix both (template + schema)

#### Mode D: Health Check

Ask for:
1. **Scope** — "Which schemas should I run the health check on? (specific path, set name, or 'all')"
   - Default to "all" if user said something generic like "template health" or "deep check"

No other inputs needed — health check is read-only.

#### Mode E: Prep (Filled Doc → Template)

Ask for:
1. **Document(s)** — "What's the path to the filled .docx file(s)?"
2. **Reference schema** — "Is there an existing schema to use as a pattern? (e.g., fms-tte-award for a similar award document)"
   - If the user mentions following patterns from another schema, use that.
3. **Target ID** — "What should the new schema ID be?" (kebab-case, e.g., `fms-repair-to`)
4. **Set name** — "What document set should this belong to?" (e.g., "Repair")
5. **Optional metadata** — category, roles (offer defaults or "skip")

### Step 3: Spawn the agent

**Mode A — Generate:**
```
Agent(
  prompt: "Generate a schema from the Word template at <path>. Doc ID: <id>. Category: <cat>. Roles: <roles>. Set: <set>.",
  subagent_type: "schema-generate"
)
```

For batch:
```
Agent(
  prompt: "Generate schemas for a document set from these templates: <path1>, <path2>, ... Set name: <set>. Category: <cat>. Roles: <roles>.",
  subagent_type: "schema-generate"
)
```

**Mode B — Validate:**
```
Agent(
  prompt: "Validate alignment for all schemas in src/schemas/. Report issues without fixing anything.",
  subagent_type: "schema-validate"
)
```

Or for specific scope:
```
Agent(
  prompt: "Validate alignment for schema at <path>. Report issues without fixing.",
  subagent_type: "schema-validate"
)
```

**Mode C — Repair:**
```
Agent(
  prompt: "Repair schema and template alignment for <path-or-scope>. Fix both the .schema.json and the .docx template.",
  subagent_type: "schema-repair"
)
```

Or schema-only:
```
Agent(
  prompt: "Repair schema alignment for <path-or-scope>. Fix only the .schema.json — do NOT modify the .docx template.",
  subagent_type: "schema-repair"
)
```

**Mode D — Health Check:**
```
Agent(
  prompt: "Run a deep template health check for all schemas. Check TKM integrity, template loop syntax, naming conventions, schema structure, and runtime viability.",
  subagent_type: "template-health"
)
```

Or for specific scope:
```
Agent(
  prompt: "Run a deep template health check for schema at <path-or-scope>. Check TKM integrity, template loop syntax, naming conventions, schema structure, and runtime viability.",
  subagent_type: "template-health"
)
```

**Mode E — Prep:**
```
Agent(
  prompt: "Convert the filled document at <path> into a templatized Word template. Reference schema: <ref-schema-id> (at src/schemas/<ref-id>/<ref-id>.schema.json). Target ID: <target-id>. Set: <set>. Category: <cat>. Roles: <roles>.",
  subagent_type: "schema-prep"
)
```

After schema-prep completes, chain to schema-generate with the prepared template:
```
Agent(
  prompt: "Generate a schema from the prepared template at src/schemas/<target-id>/<template-file>. Doc ID: <target-id>. Category: <cat>. Roles: <roles>. Set: <set>. Use the reference schema at <ref-path> for ai_hints and section structure.",
  subagent_type: "schema-generate"
)
```

After schema-generate completes for the prepped template, run the same post-generation quality gate as Step 4b below.

### Step 4: Report results

After the agent completes, relay its summary to the user:

**For Generate:**
- What was created (schema paths, doc IDs, titles)
- Number of sections/fields per schema
- For sets: shared fields that will be deduplicated
- Whether the build passed
- Suggest running `npm run dev` to see schemas on the home page

**Step 4b: Post-generation quality gate**

After schema-generate completes successfully (build passes), automatically run
a baseline quality assessment on the newly created schema(s).

**For single schemas:**
```
Agent(
  subagent_type: "template-health",
  prompt: "Run a template health check for the newly created schema at src/schemas/<doc-id>/. This is a post-generation quality gate."
)
```

Then:
```
Agent(
  subagent_type: "schema-judge",
  prompt: "Run dimensions 2-7 on src/schemas/<doc-id>/. Dimension 1 (mechanical health) was already verified by the build step. This is a post-generation quality gate — report findings but do not suggest running schema-repair yet."
)
```

**For batch (set) schemas**, also run:
```
Agent(
  subagent_type: "set-health-check",
  prompt: "Run within-set coherence checks for set '<set-name>'. This is a post-generation quality gate."
)
```

**Report findings** as a "Quality Gate" section in the generation summary:
```
### Post-Generation Quality Gate

| Dimension | Status | Findings |
|-----------|--------|----------|
| Template Health | ... | ... |
| Schema Judge | ... | ... |
| Set Coherence | ... (or N/A if not a set) | ... |

**N warnings, M info found. Run `/schema-quality-loop on <doc-id>` to address these.**
```

If any Critical findings are detected, warn the user prominently:
```
⚠️ Post-generation quality gate found critical issues.
Fix before using in production. Run `/schema-quality-loop on <doc-id>`.
```

**For Validate:**
- Summary table of schema health
- Detail on any issues found
- Suggest running repair if issues exist

**For Repair:**
- What was changed (schema-side and template-side)
- Before/after issue counts
- Build status
- Suggest reviewing the changes with `git diff`

**For Health Check:**
- Overall pass/fail with critical/error/warning/info counts
- Summary table per schema
- Detail on critical and error findings with remediation
- Suggest running `schema-repair` for fixable issues
