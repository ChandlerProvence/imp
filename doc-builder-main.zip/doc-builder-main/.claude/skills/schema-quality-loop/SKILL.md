---
description: "Quality improvement loop — runs all assessment agents, synthesizes findings, gets approval, executes repairs, tracks outcomes in the quality ledger, and runs retrospectives."
---

# Schema Quality Loop

Orchestrate a multi-agent quality improvement loop on document schemas. This skill replaces `schema-improve` as the primary quality improvement entry point by coordinating all assessment agents (schema-judge, template-health, set-health-check) and feeding their consolidated findings into schema-repair.

## Instructions

### Step 1: Determine scope

Parse user input for:
- Schema path/ID, set name, or "all"
- Max iterations (default: 3)
- Severity threshold (default: Warning and above)

Resolve scope the same way as the agents:
```bash
# Discover sets
python3 -c "
import json, glob
for f in sorted(glob.glob('src/schemas/sets/*.set.json')):
    s = json.load(open(f))
    print(f\"{s['id']}: {s['schemas']}\")
"

# Discover all schemas
find src/schemas -name "*.schema.json" -o -name "*.variant.json" | sort
```

### Step 2: Load the quality ledger

Read `.claude/quality-ledger.json`. If it does not exist, treat as empty:
```json
{"runs": [], "known_false_positives": [], "schema_baselines": {}}
```

### Step 3: Run assessment agents (Phase 1 — ASSESS)

Spawn three assessment agents in sequence. Ask each to "output structured findings" to get machine-readable JSON.

**3a. Schema Judge (8 dimensions):**
```
Agent(
  subagent_type: "schema-judge",
  prompt: "Run all 8 dimensions on <scope>. Output structured findings. Output the full report."
)
```

**3b. Template Health (6 dimensions):**
```
Agent(
  subagent_type: "template-health",
  prompt: "Run all 6 dimensions on <scope>. Output structured findings. Output the full report."
)
```

**3c. Set Health Check (7 checks) — only if scope includes schemas in sets:**
```
Agent(
  subagent_type: "set-health-check",
  prompt: "Run within-set and cross-set checks for <scope>. Output structured findings. Output the full report."
)
```

**3d. Ground-Truth Test Failures — if `src/test/fixtures/ground-truth/` has fixtures for any schema in scope:**

Run the ground-truth regression test and parse failures into findings:

```bash
npx vitest run src/test/groundTruth.test.ts --reporter=json 2>&1
```

Fixtures come in two layouts: single-schema (`ground-truth/<schema-id>/<case>/`, test name `<schema-id>/<case>: …`) and document-set (`ground-truth/sets/<set-slug>/<case>/`, test name `sets/<set-slug>/<case> > <schema-id>: …`). A set fixture is in scope when any of its member schemas is in scope; attribute each failure to the `<schema-id>` in the test name. Repairs to a set member must keep the other members' set tests green, because they share one `answers.json`.

For each failed test, extract the hunk details from the error message. Each unallowed hunk becomes a finding with:
- Dimension: `ground-truth:<bucket>` (bucket from the hunk's classification, or `unclassified` if the bootstrap report hasn't been run)
- Finding ID: `<schema-id>:ground-truth:<bucket>:<hunk-id>`
- Severity: `warning` (or `critical` if the hunk involves a leaked literal like `true`/`null`/`{{TAG}}`)
- Detail: the hunk's `a` (rendered) vs `b` (expected) text

If no ground-truth fixtures exist for schemas in scope, skip this step silently.

### Step 4: Synthesize findings (Phase 2 — PLAN)

Merge findings from all agents. For each finding:

1. **Assign a unified finding ID:** `<schema-id>:<dimension>:<check-code>:<field-path>`
2. **Deduplicate:** If schema-judge and template-health both flag the same issue (e.g., both detect orphaned fields), keep the more detailed version.
3. **Cross-reference with ledger:**
   - If this finding matches an entry in `known_false_positives`, mark as "suppressed"
   - If this finding appeared in a prior run and was repaired but recurred, escalate severity and note recurrence
   - If this finding is new (not in any prior run), mark as "new"
4. **Group by severity** (Critical > Warning > Info), then by schema.

### Step 5: Present repair plan (Phase 3 — APPROVE)

Present the synthesized plan:

```
## Improvement Plan (Iteration N)

### Scope: <input description>
### Schemas assessed: N
### Assessment agents: schema-judge (8 dims) + template-health (6 dims) + set-health-check (7 checks)
### Findings: X critical, Y warnings, Z info

### Proposed Repairs (Critical + Warning — will be applied if approved):

1. **<schema-id>** `<field>`
   Source: <agent>:<dimension>
   Change: <description>
   ↳ Also affects: <cross-schema effects>

### Suppressed (matched known_false_positives):
- <finding-id>: <reason>

### Recurring (seen in N prior runs):
- <finding-id>: <detail>

### Skipped (Info — reported only):
- <finding-id>: <detail>

Approve these repairs? (yes / edit / skip / mark-false-positive <finding-ids>)
```

**Wait for user approval before proceeding.**

If user marks findings as false positives, update `known_false_positives` in the ledger and remove from the plan.

### Step 6: Execute repairs (Phase 4 — REPAIR)

Spawn schema-repair with the approved plan:
```
Agent(
  subagent_type: "schema-repair",
  prompt: "Apply these specific repairs: <approved-repair-list>. For each: <schema-path>, <change-description>, <source-dimension>. Finding IDs: <id-list>."
)
```

### Step 7: Verify

```bash
npm test
```

- **Tests fail:** Identify which repair caused the failure. Recommend reverting that specific edit. Flag it as "needs manual review".
- **Tests pass:** Re-spawn schema-judge on just the repaired schemas to verify fixes:

```
Agent(
  subagent_type: "schema-judge",
  prompt: "Run all 8 dimensions on <repaired-schema-ids-only>. Output structured findings."
)
```

### Step 8: Update quality ledger

Read `.claude/quality-ledger.json` and append a new run entry:

```json
{
  "run_id": "<ISO-timestamp>",
  "scope": "<scope description>",
  "iteration": 1,
  "findings_count": {"critical": 0, "warning": 0, "info": 0},
  "repairs_attempted": 0,
  "repairs_succeeded": 0,
  "repairs_reverted": 0,
  "new_findings_after_repair": 0,
  "findings": [
    {
      "id": "<finding-id>",
      "schema": "<schema-id>",
      "dimension": "<source-agent>:<dimension-name>",
      "code": "<CHECK_CODE>",
      "field": "<section.field or null>",
      "severity": "warning",
      "status": "fixed|persists|new|suppressed|reverted",
      "detail": "<one-line description>"
    }
  ]
}
```

Update `schema_baselines` with current per-dimension scores. Trim `runs` to the most recent 20 entries.

Write the updated ledger back to `.claude/quality-ledger.json`.

### Step 9: Retrospective

Analyze the ledger across all runs:

1. **Recurring findings:** Findings with the same ID that have `status: "persists"` across 2+ runs. Note these need manual attention or a different repair strategy.

2. **Repair instability:** Findings that were `"fixed"` in run N but reappear in run N+1. Suggest why (e.g., variant inheritance overwrites the fix, set peer has the same issue).

3. **False positive candidates:** Findings that the user has repeatedly skipped (not approved for repair) across 2+ runs. Suggest adding to `known_false_positives`.

4. **Quality trends:** Compare `schema_baselines` across runs. Report which schemas improved, degraded, or plateaued.

5. **Agent improvement suggestions:** If a specific check code produces findings that are always suppressed or skipped, suggest amending the check's threshold in the relevant agent `.md` file. Record the suggestion in `agent_improvement_suggestions` in the ledger for human review.

### Step 10: Converge or loop

- **No new findings above threshold** → print final summary, done.
- **New findings + iteration < max** → go to Step 3 with narrowed scope (only schemas with remaining findings).
- **Iteration = max** → stop, report remaining findings.
- **Finding count did not decrease** → stop (diminishing returns), report what's stuck.

### Final Report

```
## Schema Quality Loop Summary: <scope>

### Iterations: N (converged | hit max | diminishing returns)

### Changes Applied
| Schema | Field/Target | Change | Source |
|--------|-------------|--------|--------|
| ... | ... | ... | schema-judge:type_fitness |

### Cross-Schema Effects
- <variant> inherits <change> from <base>

### Remaining (not auto-repaired)
| Schema | Finding | Severity | Reason |
|--------|---------|----------|--------|
| ... | ... | info | below threshold |

### Quality Trends
| Schema | Prev Warnings | Current Warnings | Δ |
|--------|--------------|------------------|---|
| ... | ... | ... | ... |

### Retrospective Highlights
- N recurring findings need manual attention
- N agent improvement suggestions recorded

### Test Results: ✓ All passing (or list failures)
```
