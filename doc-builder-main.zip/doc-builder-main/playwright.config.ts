import { defineConfig, devices } from '@playwright/test';

// E2E_BASE_URL points the suite at a deployed site (the nightly CI job sets it
// to production); unset, tests run against the local dev or preview server.
const externalBaseURL = process.env.E2E_BASE_URL?.replace(/\/?$/, '/');

export default defineConfig({
  testDir: './e2e/tests',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: process.env.CI ? 'dot' : 'list',
  outputDir: './e2e/test-results',

  use: {
    baseURL: externalBaseURL ?? 'http://localhost:5173/doc-builder/',
    screenshot: 'only-on-failure',
    trace: 'on-first-retry',
    actionTimeout: 10_000,
    navigationTimeout: 15_000,
  },

  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
    {
      // Catches browser differences in native form controls (e.g. how number
      // inputs treat commas) that a Chromium-only run can't see.
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },
  ],

  webServer: process.env.CI || externalBaseURL
    ? undefined
    : {
        command: 'npm run dev',
        port: 5173,
        reuseExistingServer: true,
        timeout: 30_000,
      },
});
