# Doc Builder

A schema-driven, TurboTax-style SPA for building standardized documents with AI-assisted drafting. Runs entirely client-side and deploys as static files to GitLab Pages.

**Live app:** https://ams-oot.pages.lsde.leidos.com/doc-builder

## Quick Start

```bash
npm ci          # install dependencies
npm run dev     # local dev server at http://localhost:5173/doc-builder/
npm run build   # production build → dist/
npm test        # run unit + component tests
```

### Dependencies

`npm ci` downloads only from the npm registry. SheetJS (`xlsx`) is not published there, so its tarball is committed under `vendor/`. See `vendor/README.md` to upgrade it. Runtime dependencies are pinned to exact versions, and `.npmrc` sets `save-exact=true` so `npm install <pkg>` keeps it that way. CI uses one exact Node image tag. `src/test/supplyChain.test.ts` and `src/test/ciImages.test.ts` fail if any of this drifts.

## Running Locally (Standalone)

The primary deployment is [GitLab Pages](https://ams-oot.pages.lsde.leidos.com/doc-builder), but you can also run the app locally as a standalone application. All data stays in your browser's IndexedDB — it persists across restarts and is specific to your browser profile.

**Prerequisites:** Node.js ≥ 22.13, npm

```bash
npm ci                # install dependencies (first time only)
npm run serve:local   # build and serve at http://localhost:4173/
```

This builds the app with base path `/` (instead of `/doc-builder/`) and starts a local preview server. AI features still require a LiteLLM API key — configure it in **Settings** after opening the app.

To build without serving (e.g. to host the files yourself):

```bash
npm run build:local   # production build → dist/ (base path /)
```

The output in `dist/` can be served by any static file server with SPA fallback support.

## Architecture

The app is **schema-driven** — each document type is defined by a JSON schema file. No application code changes are needed to add a new document type.

```
src/schemas/            → Document type definitions + colocated .docx templates
  nda/
    schema.json         → Schema (interview fields, output template)
  sh-request-memo/
    schema.json         → Schema (interview fields, template_key_map)
    Template.docx       → Word template with {{PLACEHOLDER}} tags
  sets/
    tte.set.json        → Authoritative set definitions (which schema IDs belong to each set)
    shipping-hub.set.json
    …
src/engine/             → Interview state machine, session tracking, field destination resolution
src/components/         → Wizard shell, field renderer, chat panel
src/pages/              → Route-level views (home, interview, review, preview)
src/generation/         → Template substitution → HTML preview / .docx download
  generateDocx.ts       → Fills Word templates; generateDocxBlob() returns a Blob
  generateSet.ts        → Generates all documents in a set from shared answers
  downloadAll.ts        → Zips a full document set into a single .zip download
  resolveOutputFilename.ts → Resolves output_filename template against session answers
  markdownToWordXml.ts  → Converts freetext markdown to Word Open XML paragraphs (headings, bold, lists, code); supports headingStyleMap + baseLevel for template-specific styles
  tocUpdate.ts          → updateTableOfContents(): replaces the static TOC section in a rendered document.xml with dynamically generated TOC entries
  docxPreview.ts        → docxToHtmlPreview(): converts a .docx Blob to HTML via mammoth for inline preview
src/engine/
  fieldLookup.ts        → lookupField() / isFieldRequired(): resolve field defs by "section_id.field_id" key
src/extraction/         → File parsing, image vision extraction, LiteLLM API calls
src/utils/
  concurrency.ts        → mapWithLimit(): run async tasks with a concurrency cap
  fileSave.ts           → saveFile(): native File System Access API picker with file-saver fallback
src/ai/                 → Bulk-edit orchestration, embeddings, prompt utilities
  litellm.ts            → Anthropic SDK wrapper: streaming + non-streaming completions, typed error handling, auto-retry
  litellm-legacy.ts     → Previous fetch-based implementation (retained for reference)
  bulkEdit.ts           → Builds all system prompts (document/section/field scope) and parses propose_changes tool calls
  unifiedPrompt.ts      → Scope dispatcher: routes document/section/field scope to buildBulkEditChatSystemPrompt
  promptUtils.ts        → Shared helpers: todayLine(), formatExistingAnswers(), formatColumnDefs()
  cuiDetection.ts       → CUI detection: regexCuiPreScreen() (fast regex), aiCuiClassification() (AI via CUI endpoint), checkForCui() (combined)
src/db/                 → IndexedDB (Dexie) persistence layer
  writeStatus.ts        → trackWrite(): wraps background IndexedDB writes; failures raise SaveErrorBanner
  resetDatabase.ts      → clearDataAndReload(): last-resort recovery (delete DB + localStorage, then reload)
src/errors/             → Modular error-handling framework
  catalog.ts            → All user-facing error wording in one place (title, message, help, support contact)
  types.ts              → AppError type + ErrorKind union
  index.ts              → toAppError(err, { domain }): normalize any thrown value to AppError
  recordError.ts        → recordError() + getRecentErrors(): ring buffer of recent caught errors
  formatDiagnostics.ts  → formatDiagnostics(): builds a JSON diagnostic payload for clipboard export
  classifiers/          → Per-domain error classifiers (ai/, db/, file/, generation/) — classify by HTTP status and message text
tools/
  render-docx.ts        → Headless CLI renderer: `npx tsx tools/render-docx.ts <schema-id> <answers.json> <out.docx> [--text]`; runs the real Docxtemplater pipeline without a browser (used by the gt-bootstrap agent and manual testing)
  import-template-bundle.ts → Promote a user-submitted bundle to a built-in schema: `npx tsx tools/import-template-bundle.ts <bundle.json> [--id <schema-id>] [--force] [--dry-run]`; runs upload validation, writes src/schemas/<id>/, prints loader.ts lines to add
  chat-run-metrics.ts   → Summarizes a chat troubleshoot export: context tokens per call (incl. cached input), cache share, tool calls, zero-hit searches, freetext/table coverage; `npx tsx tools/chat-run-metrics.ts <troubleshoot.json> [--schema <id>] [--json]`
  docx-diff.py          → Deterministic .docx text extraction and section-aligned diffing; `extract` produces structured JSON, `diff` outputs classified hunks with optional `--allow allow.json` whitelist
  docx-utils.py         → Python CLI for .docx template inspection and manipulation
  prepare-lcsp-template.py → One-time script to transform the iLCSP Word doc into a tagged template
  cleanup-lcsp-instructional.py → Strips instructional/meta paragraphs and the "Overview and Expectations" section from iLCSP.docx; supports --dry-run; includes placeholder-safety guard and post-write verification
  insert-update-fields.py → Patches word/settings.xml inside a .docx to set <w:updateFields w:val="true"/>, causing Word to refresh ToC/LoT/LoF fields automatically on first open; usage: python3 tools/insert-update-fields.py <path/to/file.docx>
  requirements.txt      → Python dependencies for the tools scripts (install with pip install -r tools/requirements.txt)
```

---

## Creating a New Document Template

Adding a new document type requires **two files** and one line in the loader — no application code changes.

### What You Need

1. **A Word template** (`.docx`) — a normal Word document with `{{PLACEHOLDER}}` tags where dynamic values should appear. You can optionally add inline hints to guide AI schema generation: `{{FIELD_NAME: describe what this field should contain}}`
2. **A schema file** (`schema.json`) — defines the interview questions and maps placeholders to answers

### Steps

1. Create a new directory under `src/schemas/<doc-id>/`
2. Place your `.docx` template in that directory
3. Create a `schema.json` in the same directory
4. Register the schema in `src/schemas/loader.ts` (one import + one array entry)
5. Done — the app auto-discovers the new document type

### Directory Structure

Each document type is a self-contained folder:

```
src/schemas/my-document/
  schema.json                    ← interview fields + template_key_map
  My_Document_Template.docx      ← Word template with {{TAGS}}
```

The `.docx` file is copied to `dist/templates/` at build time by a Vite plugin, making it fetchable at runtime for generation.

### Generating a Schema

Run `/new-schema` in Claude Code to auto-generate a schema from your Word template. The skill detects your intent and routes to one of four focused agents:

- **`schema-generate`** — creates a new schema from a `.docx` template; handles single templates and batches (document sets).
- **`schema-validate`** — read-only health check that compares template placeholders against the schema's `template_key_map`. Runs the CI integrity tests first (Step 0) and stops on failure so soft checks only run when the schema foundation is sound.
- **`schema-repair`** — fixes mismatches in both the `.schema.json` and the `.docx` template.
- **`schema-prep`** — converts a filled Word document (with real data instead of `{{PLACEHOLDER}}` tags) into a properly templatized `.docx` ready for `schema-generate`. Handles placeholder proposals, image-to-table replacement, multi-value text substitutions, file renaming, and directory staging. Triggered automatically when you say "templatize", "prep", "convert to template", or provide a filled `.docx` that has no existing placeholder tags.
- **`set-health-check`** — read-only coherence check for document sets. Diagnoses soft issues not caught by CI: label drift, `ai_hint` divergence, required-field disagreement, coverage gaps (within-set), and table split divergence, required escalation, and cross-set label conflicts. Invoke with a set name or "all".
- **`schema-judge`** — comprehensive read-only quality assessment across 8 dimensions: mechanical health, template fragility (with `content_blocks` migration readiness), type fitness, label and hint quality, section organization, redundancy detection, template prose quality, and output readability. Accepts a single schema path, a set name, or `"all"`. Reports findings with severity levels (Critical / Warning / Info) and a prioritized action plan. Never modifies files.
- **`schema-improve`** — lightweight single-schema improvement agent. Delegates assessment to `schema-judge`'s 8-dimension framework (no embedded copy), builds a repair plan, waits for approval, executes fixes, and verifies with `npm test`. For comprehensive multi-agent improvement across all assessment dimensions, use `/schema-quality-loop` instead.

Run `/schema-quality-loop` in Claude Code for the full multi-agent quality improvement loop. It spawns `schema-judge` (8 dimensions), `template-health` (6 dimensions), and `set-health-check` (7 checks) — 21 assessment dimensions total — synthesizes and deduplicates findings, presents a prioritized repair plan with user approval, spawns `schema-repair`, tracks outcomes in a persistent quality ledger (`.claude/quality-ledger.json`), and runs a retrospective that identifies recurring findings, repair instability, false-positive candidates, and agent improvement suggestions. Converges in up to 3 iterations.

You can also use `tools/docx-utils.py` directly for lower-level template manipulation.

**Prerequisite:** install the Python dependencies once before running any tool script:

```bash
pip install -r tools/requirements.txt
```

```bash
# Extract all {{PLACEHOLDER}} tags (handles split XML runs)
python3 tools/docx-utils.py extract-placeholders src/schemas/my-doc/My_Template.docx

# Extract placeholders WITH author-provided inline hints
python3 tools/docx-utils.py extract-placeholders --with-hints src/schemas/my-doc/My_Template.docx

# Strip inline hints from template ({{TAG: hint}} → {{TAG}}) before storage
python3 tools/docx-utils.py strip-hints src/schemas/my-doc/My_Template.docx -o src/schemas/my-doc/My_Template.docx

# Map each placeholder to its preceding heading (level, outline number)
python3 tools/docx-utils.py extract-structure src/schemas/my-doc/My_Template.docx

# Validate a template against its schema
python3 tools/docx-utils.py validate src/schemas/my-doc/My_Template.docx src/schemas/my-doc/my-doc.schema.json

# Replace a highlighted region with a placeholder tag
python3 tools/docx-utils.py replace-highlight src/schemas/my-doc/My_Template.docx \
  -o src/schemas/my-doc/My_Template.docx \
  --text "highlighted text" --placeholder FIELD_NAME

# List all embedded images with their index, context, and dimensions (inches + EMU)
python3 tools/docx-utils.py list-images src/schemas/my-doc/My_Template.docx

# Replace a specific image (by index) with a Docxtemplater loop table
python3 tools/docx-utils.py replace-image-with-table src/schemas/my-doc/My_Template.docx \
  -o src/schemas/my-doc/My_Template.docx \
  --image-index 0 \
  --columns '["Noun","NSN","Part Number","Serial #","Total Cost"]' \
  --column-ids '["noun","nsn","part_number","serial","total_unit_cost"]' \
  --loop-tag "PTab"

# Propose placeholder replacements for a filled document using a reference schema
python3 tools/docx-utils.py propose-placeholders \
  --file filled-document.docx \
  --reference-schema src/schemas/fms-tte-award/fms-tte-award.schema.json

# Fix missing xmlns: declarations for mc:Ignorable prefixes (prevents Word "unreadable content" errors)
python3 tools/docx-utils.py fix-namespaces src/schemas/my-doc/My_Template.docx
```

### Inline Hints for Schema Generation

Template authors can annotate placeholders with guidance that the schema generator uses for `ai_hint` values:

```
{{PROJECT_NAME: The official project name as it appears in the contract}}
{{TIMELINE: Describe the project timeline including key milestones and deliverable dates}}
{{COST_ESTIMATE: format is $X,XXX.XX — include labor and materials}}
```

**Rules:**
- Syntax: `{{FIELD_NAME: hint text}}`
- Colons within the hint text are fine: `{{TIME_FORMAT: use HH:MM:SS format}}`
- First occurrence wins if the same placeholder appears multiple times with different hints
- Loop markers (`{{#TABLE}}` / `{{/TABLE}}`) do not support hints
- Hints are stripped from the stored template during schema generation (Docxtemplater only sees clean `{{FIELD}}` tags)

For manual creation, see the schema field reference below and follow the directory structure above.

### Schema Field Reference

| Field Type | Description | Extra Properties |
|-----------|-------------|-----------------|
| `string` | Short text input | `auto_fill?: string` (see below) |
| `number` | Numeric input — renders as a text field; currency values reformat to `"1,234.50"` on blur (consistent across all browsers) | `format?: "currency" \| "integer" \| "number"` (controls formatting in generated documents) |
| `boolean` | Yes/No toggle | — |
| `date` | Date picker | — |
| `enum` | Dropdown select | `options: string[]` required |
| `multiselect` | Checkbox group (multiple values) | `options: string[]` required; value stored as JSON array |
| `freetext` | Multi-paragraph (AI-eligible) | `ai_hint?: string` recommended; `template_heading?`, `outline_number?`, `heading_level?` for heading-aware AI drafting |
| `table` | Editable grid of rows | `columns` array required; `min_rows` optional; `ai_hint` recommended |

`string`, `number`, `boolean`, `freetext`, `date`, and `enum` fields accept an optional `default` value (it must match the field type; an `enum` default must be one of the `options`). It is applied when a new session is created and when a saved session loads without an answer for that field (e.g., sessions saved before the field was added); existing answers, including `false`, are never overridden. Not supported on `table`, `multiselect`, `image`, formula, or `same_as` fields. Developer-only: the template authoring guide tells users to leave it for the developers.

#### Required vs. Optional Fields

The `required` boolean controls how unfilled fields behave throughout the app:

| Scenario | `required: true` | `required: false` |
|----------|-----------------|-------------------|
| Field label | Red asterisk (`*`) shown | No indicator |
| Review page highlight | Red left border | Yellow left border |
| Review page value | "Not filled" (red) | "Optional — not filled" (yellow) |
| Markdown preview | `[Not provided]` placeholder | Blank |
| Word document output | `{{TAG}}` preserved for re-import | Blank paragraph |
| Approve gate | Blocks approval | Does not block |

A required `table` counts as filled only when it is complete: it has at least `min_rows` rows (or every fixed row), and every required non-formula column is filled in every row. The sidebar status, the Review page's unfilled count, and the approve gate all use this rule. An optional table counts as filled once any cell has a value.

#### Freetext Heading Annotations

Three optional properties on `freetext` fields allow schema authors to tell the AI drafting assistant about the heading context in the Word template:

| Property | Type | Description |
|----------|------|-------------|
| `template_heading` | `string` | The exact heading text already present in the `.docx` template above this field's placeholder. The AI will not repeat this heading in its draft. |
| `outline_number` | `string` | The outline number of that heading (e.g., `"3.1"`, `"4.3.1"`). When set, the AI numbers any sub-headings it creates as extensions (e.g., `3.1.1`, `3.1.2`). |
| `heading_level` | `number` | Heading depth (1–6) of the template heading above this field. For unnumbered documents, the AI uses the next level down for sub-headings. |

When a `.docx` freetext field has content, the generation engine converts the stored markdown to Word Open XML (`<w:p>`) elements with proper heading styles (Heading1–Heading6), bold/italic runs, lists, code blocks, and horizontal rules. The template placeholder is automatically switched to Docxtemplater's `rawXml` (`{@TAG}`) syntax at generation time.

To populate these annotations from an existing `.docx` template, use `docx-utils.py extract-structure`:

```bash
python3 tools/docx-utils.py extract-structure src/schemas/my-doc/My_Template.docx
```

This outputs a JSON object with two keys:

- `placeholders` — maps each placeholder to its preceding heading text, level, outline number, and `style_id` (the exact Word paragraph style used in the template).
- `heading_style_map` — a ready-to-paste map from heading level to the style ID actually used in the template (e.g., `{ "2": "Heading2Manual" }`). Copy this object into the schema's top-level `heading_style_map` property when the template uses non-generic heading styles so generated freetext content renders with matching Word formatting.

#### Auto-Fill from User Profile (`auto_fill`)

A field can be pre-populated from the user's cached profile (configured in **Settings → Your Information**) by adding an `auto_fill` key:

```json
{
  "id": "preparer_name",
  "label": "Preparer name",
  "type": "string",
  "required": true,
  "auto_fill": "user_profile.name"
}
```

Valid `auto_fill` values:

| Value | Source |
|-------|--------|
| `user_profile.name` | User's name |
| `user_profile.title` | User's job title |
| `user_profile.phone` | User's phone number |
| `user_profile.email` | User's email address |

When a new session is created, fields with `auto_fill` annotations are pre-populated from the stored profile. Users can still edit the pre-filled values. The profile is stored in localStorage and can be updated at any time via Settings.

The schema loader validates `auto_fill` values at load time and reports an error for any unrecognized key.

#### Linked Fields (`same_as`)

A field can mirror another field's value automatically by setting `same_as` to the source field's `"section_id.field_id"` key:

```json
{
  "id": "contract_date",
  "label": "Contract date",
  "type": "date",
  "required": true,
  "same_as": "header.award_date"
}
```

Rules enforced at schema load:
- The source field must exist in the same schema.
- Source and follower must share the same `type`.
- Cycles are not allowed.
- Linked fields are read-only in the UI — their value is set automatically when the source changes.

If an entire section's fields are all `same_as` links, the section is considered automatically complete and skipped in the section outline.

#### Calculated Values (`formula`)

A `number` field or table column with a `formula` is calculated automatically and read-only in the UI. One expression language serves every position; the engine is `src/engine/formula/` (parser, scope rules, dependency graph, evaluator, validator, and migration of old schemas).

```json
"constants": { "TAX_RATE": 0.06 },
"sections": [{ "id": "pricing", "title": "Pricing", "fields": [
  { "id": "items", "label": "Items", "type": "table", "required": true, "columns": [
    { "id": "qty", "label": "Qty", "type": "number" },
    { "id": "unit_price", "label": "Unit price", "type": "number", "format": "currency" },
    { "id": "line_total", "label": "Line total", "type": "number", "formula": "qty * unit_price", "format": "currency" }
  ]},
  { "id": "price_from", "label": "Previous price", "type": "number", "required": true, "format": "currency" },
  { "id": "total", "label": "Total", "type": "number", "required": true, "formula": "SUM(items.line_total) * (1 + TAX_RATE)", "format": "currency" },
  { "id": "price_delta", "label": "Price change", "type": "number", "required": true, "formula": "total - price_from", "format": "currency", "display": "abs" }
]}]
```

Formulas support `+`, `-`, `*`, `/`, `^` (right-associative), parentheses, numeric literals (no unary minus: write `0 - x`), and these functions:

- **`COALESCE(a, b, …)`** — the first argument that isn't empty. Use it for optional cells that should count as `0` rather than empty the result.
- **`ABS(x)`** — absolute value.
- **`SUM` / `AVG` / `MIN` / `MAX`(`table.column`)** — over a number column's filled cells; empty when the table has no rows or no numbers.
- **`COUNT(table)`** counts rows; **`COUNT(table.column)`** counts rows with that cell filled.

What a name refers to depends on where the formula sits:

| Formula on | Bare `x` | `section.field` | Aggregates |
|---|---|---|---|
| table column | another number column of the same table, then a constant | not allowed | not allowed |
| field | a number field in the same section, then a constant | any number field | `table.column` in the same section, or `section.table.column` |

Every referenced field or column must be a `number` (formula fields are). Schema-level `constants` names must not match any section or field id, and ids used in formulas cannot contain `-`. Formula columns are filled in first, then formula fields in dependency order, so a total can sum a calculated column; a dependency loop is a load error. Empty or non-numeric inputs make a result empty; division by zero is empty.

`format` controls how a number appears in the generated Word document (`$` lives in the template):

| Value | Entered number | Calculated value |
|-------|---------------|------------------|
| `"currency"` | `12,300.00` | `12,300.00`; also rounded to cents before conditions and validation see it, so `0.7 + 0.1 - 0.8` is exactly `0` |
| `"integer"` | `60` | `60` |
| `"number"` / omitted | as entered | `decimals` places, grouped (`1,234.50`) |

`decimals` (0–6, default 2) changes the digits for `currency` and `number`. `"display": "abs"` on a formula field renders the absolute value in the document while the wizard, Review, `content_blocks` conditions, and validation rules still see the sign, so a template can choose "Increase" or "Reduce" wording while printing an unsigned amount.

Schemas written before 2026-10 used `computed`, table `aggregates`, and schema-level `derived_fields`. Built-in schemas were rewritten; custom templates, drafts, uploads, session imports, and backups are migrated on read by `migrateSchemaShape`, and the loader rejects the old keys in a schema file with a message naming the replacement.

#### Field Validation Rules (`validate`)

Any field or table column can declare a `validate` array of rules:

```json
{
  "id": "funded_amount",
  "label": "New funded amount ($)",
  "type": "number",
  "required": true,
  "validate": [
    { "rule": "range", "min": 0 },
    { "rule": "compare", "op": "lte", "other": "header.nte_fp_price",
      "message": "Funded value exceeds the task order price" }
  ]
}
```

Problems are **warnings only** — they never block approval or generation. They appear:

- Inline below the field in the wizard (native `min`/`max` attributes are applied to `date` inputs; `number` inputs use the `range` rule warning instead)
- As a red `!` badge on the section in the sidebar
- On the Review page as a banner, per-section badge, and per-field message, and in the "Approve Anyway" confirmation dialog
- On AI proposals: a proposed value that breaks a rule arrives unaccepted with a warning. The AI prompt also describes each field's constraints.

Rules skip empty values and hidden fields; formula and `same_as` fields are not validated (their sources are).

Every `number` field and column also has an **implicit format validator**: the whole value must be a number — `$` and spaces are ignored, and commas are allowed only as thousands separators (e.g. `"$1,234.50"` is accepted; `"1234,5"`, `"12abc"`, and `"45 days"` are flagged "Must be a number"). This check runs automatically — no schema configuration needed.

**Schema-declared rules** (every rule also accepts `message` to override the default text and `severity`: `"warning"` (default) or `"info"` — info messages are shown but not counted as problems):

| Rule | Params | Applies to |
|------|--------|------------|
| `range` | `min` and/or `max` (inclusive) — numbers for `number`, `"YYYY-MM-DD"` strings for `date` | `number`, `date` |
| `compare` | `op` (`lt` \| `lte` \| `gt` \| `gte` \| `eq` \| `neq`), `other` — a `section.field` key (formula fields allowed) or, on a table column, a sibling column id | `number`, `date` (both sides must be numeric, or both dates) |

`compare` is skipped while `other` is empty or hidden. The loader rejects unknown rules, rules on the wrong field type, bad params, and unresolved `other` references.

**Adding a new rule:**

1. Create `src/engine/validation/rules/<name>.ts` exporting a `ValidationRule` (`id`, `appliesTo`, `checkParams`, `check`, and optional `describe` / `inputAttrs`).
2. Add it to the `RULES` list in `src/engine/validation/registry.ts`.
3. Add `src/engine/validation/rules/<name>.test.ts` (a registry test fails if it's missing).

No loader, wizard, Review, or AI changes are needed.

#### Dynamic Output Filenames

The `output_filename` schema property controls the generated document's filename. It uses the same `{{section_id.field_id}}` placeholder syntax as templates:

```json
"output_filename": "TO - {{header.idiq_number}} - Rls. {{header.to_release_num}} - {{header.subcontractor_name}} - TT&E"
```

If a referenced field is empty or missing, that placeholder resolves to `"DRAFT"`. When `output_filename` is omitted entirely, the schema `title` is used (sanitized for filesystem safety).

### Schema Top-Level Fields

| Field | Required | Description |
|-------|----------|-------------|
| `id` | ✓ | Unique kebab-case identifier |
| `title` | ✓ | Display name |
| `version` | ✓ | Schema version number — increment when fields or template mappings change |
| `sections` | ✓ | Array of section definitions |
| `output_template` | One of these | Markdown template with `{{section_id.field_id}}` placeholders |
| `docx_template` | One of these | Filename of colocated `.docx` template |
| `template_key_map` | With `docx_template` | Maps docx `{{TAG}}` → answer key. |
| `roles` | — | Array of role strings; if omitted the schema is visible to all users |
| `category` | — | Category ID for grouping on the home page (see `src/categories.ts`) |
| `set` | — | Informational set label (legacy). Set membership is now controlled by `src/schemas/sets/*.set.json` definition files — the home page reads set definitions to group schemas and launch set sessions. The inline `set` field on a schema is used as a fallback when no set definition is found. |
| `output_filename` | — | Template for generated filename (without extension). Uses `{{section_id.field_id}}` placeholders; missing values fall back to `"DRAFT"`. Falls back to sanitized `schema.title` when omitted. |
| `reference_docs` | — | Array of reference documents available as AI context during drafting |
| `recommended_uploads` | — | Document slots in the picker: each entry declares a source document the user can attach; slot `ai_hint` is forwarded to the AI as authoritative-source guidance (see below) |
| `template_text_replace` | — | Array of `{ from, to }` pairs applied to all `word/*.xml` parts in the `.docx` ZIP at generation time (before Docxtemplater rendering). Used by variant schemas to reuse a base Word template while substituting prose text (e.g., `"TT&E"` → `"Straight to Repair"`). |
| `content_blocks` | — | `Record<string, string \| boolean \| { when: BlockCondition }>` injected into the Docxtemplater data object at generation time. Boolean values control `{{#TAG}}...{{/TAG}}` conditional sections; string values fill `{{TAG}}` placeholders; `{ when: BlockCondition }` entries are evaluated at runtime against the current answers (see Conditional Visibility below). Shallow-merged during variant resolution. Prefer `content_blocks` over `template_text_replace` paragraph-removal rules — it is more reliable and testable. |
| `heading_style_map` | — | `Record<string, string>` mapping markdown heading depth (as a string key, `"1"`–`"6"`) to the Word paragraph style ID used in this template (e.g., `{ "2": "Heading2Manual" }`). When present, `markdownToWordXml` emits these style names instead of the generic `Heading{N}` defaults, keeping AI-authored freetext headings visually consistent with the template's own headings. Obtain the correct values by running `docx-utils.py extract-structure` and copying the `heading_style_map` from the output. |
| `toc` | — | `TocConfig` object that enables automatic Table of Contents generation. After Docxtemplater renders the template, `updateTableOfContents` scans the resulting `word/document.xml` for heading paragraphs and replaces the static TOC section with dynamically generated `TOC{N}`-styled entries. Properties: `heading_text` (required — exact text of the TOC heading paragraph used as the section boundary sentinel), `max_depth` (default 3 — deepest heading level to include), `exclude_texts` (heading texts to omit, e.g. `["List of Tables", "List of Figures"]`), `toc_style_map` (maps heading depth to a custom TOC paragraph style ID when the template uses non-standard `TOC{N}` styles). |
| `download_hints` | — | `string[]` of informational messages shown to the user on the Preview/download page. Each string is rendered as a separate line in an info banner near the download button. A second dismissible banner appears for 15 seconds after each successful download. Use for post-download instructions that depend on the template — for example, `"Press Ctrl+A → F9 in Word to update the Table of Contents, List of Tables, and List of Figures with page numbers."` |

#### Recommended Uploads / Document Slots (`recommended_uploads`)

An optional array declaring **document slots** that appear in the document picker when the user opens an AI Draft conversation. A document dropped into a slot receives a `role` attribute; the slot's `ai_hint` is forwarded to the AI in a "Source document guidance" block so the model knows what each attached document is authoritative for.

```json
"recommended_uploads": [
  {
    "id": "pws",
    "title": "PWS (Performance Work Statement)",
    "description": "Defines the scope of work referenced in the award document.",
    "priority": "recommended",
    "ai_hint": "Authoritative for scope, parts list, quantities, SOW date, and TAT. Prefer it over the prior task order or any emails for scope details."
  },
  {
    "id": "contact-info",
    "title": "Contact Information",
    "description": "Leidos SCA, TOM, and SOR contact sheet. Loaded automatically.",
    "priority": "recommended",
    "default_reference": "contact-information",
    "ai_hint": "Authoritative for names, titles, phones, emails, and addresses. Prefer it over email signatures."
  }
]
```

| Field | Required | Description |
|-------|----------|-------------|
| `id` | ✓ | Unique string; used to deduplicate across schemas when merging a document set |
| `title` | ✓ | Human-readable name shown in the slot |
| `description` | — | One-sentence explanation of why this document helps |
| `priority` | — | `"recommended"` (default) or `"optional"` |
| `ai_hint` | — | Guidance for the AI: what the document is authoritative for, and what not to take from it |
| `multiple` | — | Allow more than one document in this slot (e.g. several vendor quotes). Default `false` |
| `default_reference` | — | Stable id prefix of a bundled reference doc in `static/reference-docs/<category>/` (same category as the schema; ids are derived from filenames, so `contact-information` matches `Contact-Information-SCA-SOR-TOM-260829.xlsx`, newest file wins) to pre-place in the slot when the picker opens. The user can remove it before clicking Attach; removal is remembered for the session. The newest manifest file matching the prefix wins, so refreshing the dated file needs no schema change. |

When schemas are merged into a document-set session, entries with the same `id` are deduplicated: strongest priority wins; `multiple` is OR-ed; `default_reference` uses the first non-empty value. When two schemas declare different `ai_hint` values for the same slot, each hint is prefixed "For \<schema title\>: …" so the AI knows which target document it applies to.

#### Conditional Field Visibility (`visible_when`)

A section or field can be shown or hidden based on the current answers by adding a `visible_when` property that names a `content_blocks` entry:

```json
{
  "id": "funding_change",
  "title": "Funding Change",
  "visible_when": "FUNDING_CHANGE",
  "fields": [...]
}
```

The named block must be declared in `content_blocks` and evaluate to a boolean. When the block is `false` the section (or field) is:

- Hidden in the interview wizard and section outline
- Excluded from the Review page's unfilled-field count
- Omitted from the generated Word document

**`BlockCondition`** syntax — use a `{ when: ... }` entry in `content_blocks` to express a runtime predicate:

```json
"content_blocks": {
  "FUNDING_CHANGE": {
    "when": {
      "field": "modifications.change_types",
      "contains": "Funding"
    }
  }
}
```

| Operator | Field type | Meaning |
|----------|-----------|---------|
| `contains` | `multiselect` | Array includes this value |
| `equals` | `enum` / `string` | Field value exactly matches |
| `not_equals` | `enum` / `string` | Field value does not match |
| `is_truthy` | `boolean` | Field is non-empty and not `false` |
| `gte` | `number` (entered or formula) | Value ≥ threshold (null → false) |
| `lt` | `number` (entered or formula) | Value < threshold (null → false) |

When the AI bulk-edit assistant is filling a schema that uses visibility gates, the system prompt includes a `## Visibility Gates` section that tells the model which multiselect values unlock which sections, so it fills gate fields and gated fields together.

---

## Saving and Loading Progress

Session progress can be saved to a portable JSON file and loaded back on any browser — useful for backing up work, transferring a session between machines, or sharing a partially-filled document with a colleague.

### Saving

With an active session open, choose **File → Save Progress…** from the menu bar. The app opens a native "Save As" dialog (Chrome/Edge) or triggers a download (Firefox) using the filename `<document-title>-progress-<timestamp>.json`. The file contains all answers, field metadata, conversation history, and a schema fingerprint for compatibility checking.

### Loading

From the menu bar choose **File → Load Progress…**, or use the **Load Progress…** button on the home page (visible when no session is active). Select the `.json` file. The app validates the file and, if the schema has changed since the file was saved, shows a warning describing which answers are affected before proceeding.

**Compatibility warnings** are shown (but do not block import) when:
- Fields that had saved answers no longer exist in the current schema version.
- Field types have changed for fields that had saved answers.

If you see compatibility warnings, you can attach the progress file in the AI Draft chat panel and ask the model to help resolve any mapping issues.

**Hard errors** (import blocked) occur when:
- The file is not a valid Doc Builder progress file.
- The required schema is not installed in this copy of the app.
- The file format version is newer than what this version of the app supports.

### Progress protection on navigation

When you have unsaved answers and attempt to start a new document, switch document types, or clear your session, a confirmation dialog appears. It offers three choices: cancel, discard and proceed, or **Save Progress** — which opens the file-save dialog and proceeds automatically after a successful save. Dismissing the file dialog cancels the entire action.

### Multi-tab safety

Only one browser tab may edit a session at a time. If you open the same session in a second tab, that tab displays a yellow banner ("This session is open for editing in another tab. Changes here are disabled to prevent conflicts.") and becomes read-only. The lock is released automatically when the editing tab closes.

### Schema Variants

When two document types share the same structure and template but differ only in a few labels or prose strings, you can create a **variant** instead of duplicating the entire schema.

A variant is a small `.variant.json` file placed in its own schema directory:

```json
{
  "$variant": 1,
  "extends": "fms-tte-award",
  "id": "fms-str-award",
  "string_replace": [{ "from": "TT&E", "to": "Straight to Repair" }],
  "overrides": {
    "title": "FMS Straight to Repair – Task Order Award",
    "set": "Straight to Repair",
    "output_filename": "TO - {{header.idiq_number}} - Rls. {{header.to_release_num}} - {{source_of_repair.sor_name}} - STR",
    "template_text_replace": [{ "from": "TT&E", "to": "Straight to Repair" }]
  }
}
```

The `TO Modification` set provides the general-purpose task order modification document that works across TT&E, Straight to Repair, and other repair workflows:

```json
{
  "id": "TO Modification",
  "schemas": ["fms-to-mod"]
}
```

The loader resolves variants at startup into complete `DocumentSchema` objects. All downstream code — the interview wizard, AI extraction, and generation pipeline — sees a normal schema.

**`string_replace`** applies find/replace to every human-visible string in the base schema: the schema title, section titles, field labels, `ai_hint`, `template_heading`, column/row labels, and `recommended_uploads`/`reference_docs` titles. Structural identifiers are never modified: field IDs, section IDs, `template_key_map` keys and values, formula expressions, `constants`, `same_as` references, and `auto_fill` paths.

**`overrides`** sets top-level schema properties after string replacement. Any property that can appear on a `DocumentSchema` object may be overridden here except `id` (set at the top level), `version` (inherited from the base), and `sections` (use `string_replace` for field-level text changes).

**`template_text_replace`** (an override property) applies find/replace to the raw XML inside `word/*.xml` parts of the inherited `.docx` template at generation time, before Docxtemplater renders placeholders. This allows the template file itself to be shared while the generated Word document contains the variant's prose.

**`content_blocks`** is the preferred alternative to paragraph-removal `template_text_replace` rules. Add `{{#TAG}}...{{/TAG}}` markers around the relevant paragraph(s) in the base `.docx` template, set `"content_blocks": { "TAG": true }` on the base schema, then override with `"content_blocks": { "TAG": false }` in the variant. During variant resolution `content_blocks` is shallow-merged, so overriding a single key leaves all other blocks from the base intact. The `schema-judge` agent can identify fragile removal rules and propose block names; `schema-repair` has step-by-step migration instructions.

To register a new variant, add one import line and one array entry in `src/schemas/loader.ts` under the `RAW_VARIANTS` block — the same pattern as base schemas.

---

## Backing Up All Data

**File → Save Progress…** saves a single session. To protect everything — all sessions, AI chats, uploaded documents, custom templates, and settings — use the whole-database backup.

### Back up

1. Choose **File → Back Up or Restore All Data…** (or **Edit → Settings…** → **Your data**).
2. Click **Back up all data…**. Doc Builder shows what will be included and warns if any uploaded document is marked or flagged as CUI.
3. Click **Save backup** and choose a location. The file is named `doc-builder-backup-<timestamp>.json`.

API keys are never included in backups. Search indexes for large uploaded documents are excluded (they are rebuilt automatically the next time you attach the document).

Settings → **Your data** shows **Last backup: …**, in red when there has never been a backup or the last one is more than 14 days old.

### Restore

1. Choose **File → Back Up or Restore All Data…**.
2. Click **Restore from backup…** and select a backup file.
3. Review the backup's date and contents, then click **Replace all data**.

Restoring replaces everything in this browser with the backup contents. **Back up current data first** is ticked by default, so the existing data is saved before it is replaced. API keys are kept. The page reloads when the restore finishes.

If a custom template in the backup fails re-validation it is skipped, and a warning is shown before you confirm.

---

## Document Set Sessions

Document sets are defined in `src/schemas/sets/*.set.json` files. Each file lists the ordered schema IDs that belong to the set:

```json
{
  "id": "TT&E",
  "schemas": ["fms-tte-no-sow-memo", "fms-tte-proposal", "fms-tte-price-reasonableness", "fms-tte-award"]
}
```

The `TT&E with mod` set includes the general-purpose task order modification document alongside the base TT&E documents:

```json
{
  "id": "TT&E with mod",
  "schemas": ["fms-tte-no-sow-memo", "fms-tte-price-reasonableness", "fms-tte-proposal", "fms-to-mod"]
}
```

**Source document consistency review:** The `fms-source-review` schema ("FMS – Source Document Consistency Review") is a standalone FMS document that is not a member of any set; run it on the source documents before starting a procurement set. It is a Markdown-only document type (no Word template) whose field hints instruct the AI to compare every shared fact across the uploaded source documents — NSNs, quantities, prices, dates, contract and case numbers, parties, contacts, and scope wording. Discrepancies are recorded row by row in a `findings` table that the SCA can disposition as Open, Dismissed, Sent for correction, or Corrected. The `summary` field instructs the AI not to certify correctness. The `reviewer_notes` field is reserved for the SCA; the AI is told never to propose a value for it.

The home page reads these definitions (via `setDefs` from `src/schemas/sets/index.ts`) to group schemas and display **"Generate full set"** buttons. A schema can belong to multiple sets. To add a schema to an existing set or create a new one, edit or add a `.set.json` file — no application code changes required.

When a user clicks **"Generate full set"**, a **set session** starts that:

1. Merges all schemas in the set into a single virtual interview form, de-duplicating shared fields.
2. Runs the normal interview wizard against the merged form — users fill data once.
3. On the Preview page, shows each document in a collapsible accordion row with inline Word / Copy MD / Print buttons. Expanding a row lazy-loads an inline HTML preview rendered from the generated `.docx` (for Word-template schemas) or Markdown (for other schemas).
4. Provides a **"Download All (.zip)"** button (top of page and footer) that packages every document in the set into a single archive.

For this to work correctly, all schemas in a set should use **consistent `section_id.field_id` paths** for shared fields (e.g., the preparer's name should map to `header.preparer_name` in every schema that uses it). Use the `/new-schema` skill with the batch mode to generate consistent cross-schema field mappings automatically.

---

## Custom Templates

Users can upload their own document types without a developer or a code deploy. Custom templates are stored only in the uploading browser's IndexedDB — they are not shared automatically.

### Installing a custom template

1. Open **File › Manage Custom Templates** (route `/templates`).
2. Click **Add template** and add the `.docx` and `.schema.json` in their own upload areas (or a `.template-bundle.json` in the bundle area). Each area shows a checkmark once its file is added, and the dialog says which file is still missing if only one of the pair is there. Files are sorted by type, so dropping both files on either area also works.
3. The app runs the same integrity checks used in CI. Any issues appear as a validation report with stable error codes and a **Copy for your AI assistant** button so the authoring chatbot can fix them.
4. On success the template is installed immediately and appears in the document list on the home page.

Have only a tagged `.docx` and no schema? Add just the Word file and choose **Build the schema from the tags**. The app creates a starter schema from the `{{TAGS}}` and headings and opens it in the schema editor to review before installing.

### Editing in the app

The in-app schema editor (route `/templates/edit/:id`) lets you change a template without touching JSON. Open it with **Edit** on an installed template, **Edit in app** on an official template (which edits a custom copy), or after building a schema from tags.

- Edit sections, fields, field types, hints, and order. Advanced features (conditions, calculations, validation rules, and similar) are locked; a tooltip explains each lock. Use the AI-assistant download flow for those.
- **Check** validates the template and schema with the same checks as upload; **Save** installs it.
- The preview renders the Word template with bracketed placeholder answers such as `[Party name]`. The **Tags** tab lists every tag; clicking a field finds it in the preview.
- Unsaved work is kept as a draft. The **Drafts** section on `/templates` offers **Continue editing** and **Discard**.

See `docs/help/template-editor.md` for the full walkthrough.

### Starting point downloads

On the Manage Custom Templates page you can also:

- **Modify an official template** — pick a built-in and download a `.zip` of editable files: its `.schema.json` (under a new `<id>-custom` id, with `based_on` pointing at the original), its `.docx` (variant text replacements baked in), `AI-EDITING-GUIDE.md`, and a README with a starter prompt.
- **Download for editing** — the same `.zip` for one of your own templates, under its existing id, so uploading the edited files replaces it and saved documents stay linked.
- **Create a new template with an AI assistant** — download the guide alone and copy a starter prompt for a Word file you've tagged with `{{TAGS}}` or for a finished document.

Give the files to an AI chatbot with a description of the change. The guide (`docs/help/template-authoring-guide.md`, also on the Documentation page) tells it how the schema and template connect, which features to leave alone, and what to return. If the upload reports problems, **Copy for your AI assistant** copies each error with its fix for pasting back into the chat. When the schema format or upload validation changes, update the guide; `templateAuthoringGuide.test.ts` checks it covers every field type and condition operator and that its worked example validates.

### Submitting for team use

Click **Submit for team use** on any installed template to download a self-contained bundle and open a pre-filled email to the team contact address. Without a working email app, choose **Save bundle & copy message** instead: the message (To, Subject, body) is copied to the clipboard, and the dialog lists the steps to paste it into any email, attach the saved `<id>.template-bundle.json`, and send. The message is also shown in a selectable box with a **Copy message** button, in case the browser blocks copying. A developer then runs:

```bash
npx tsx tools/import-template-bundle.ts <bundle.json> [--id <schema-id>] [--force] [--dry-run]
```

This validates the bundle with the same checks as the upload dialog, writes the schema and `.docx` into `src/schemas/<id>/`, and prints the `loader.ts` lines to add. After importing, run the `template-health` agent and decide on set membership.

### Session portability

Progress files saved with **File → Save Progress…** embed any custom template used by the session. When the file is loaded on a browser that doesn't have the template, the embedded copy is re-validated and installed once the user confirms the import. If a local version already exists but differs, the local version is kept and a compatibility warning is shown.

### Promoted templates

When a custom template has been promoted to a built-in (the developer imported the submission and deployed), the Manage Custom Templates page detects the overlap (matching id, or a `based_on` that names the built-in) and offers to switch saved documents to the official version and archive the local copy.

Custom template ids are stored as `custom-<id>`; built-in ids may not start with `custom-`, so the two can never collide.

---

## Bulk Edit Chat

The AI bulk-edit panel lets users fill or refine document fields conversationally. When the model has values to propose it calls the `propose_changes` tool with all changes in a single structured batch. The UI validates each value against the field's type/options, presents the changes as an accept/reject list, and applies accepted values to the session.

When the model proposes values that cannot be applied (field not in scope, unrecognized field key, value that cannot be coerced to the target type), the tool result includes a `skipped_entries` array so the model understands why those entries were not applied and can try alternative approaches. Expected no-ops — values that are identical to the current answer, and fields that are auto-filled via `same_as` links — are silently excluded from the skip report to avoid noise.

**Freetext drafting behavior:** For `freetext` fields the model is expected to draft complete narrative prose from uploaded source documents, template context, field guidance, and standard practice. Grounding rules apply to specific facts (names, dates, amounts, identifiers, commitments) — not to the prose itself — so the model does not stall when no source document directly covers a section. Drafts that rely mainly on standard practice are emitted with confidence < 0.6 and any unconfirmed facts are noted in the assistant's reply rather than written as document placeholders. Non-freetext fields and the AI review prompt retain the original strict grounding rules.

**Drafting style:** For schemas with freetext fields, the **Prep → Drafting style** page holds a per-session style note that is added to every drafting and review prompt. It governs form, not facts. Attach a document the customer wrote under the **Style reference** upload slot, and one analysis call derives the note from it. That document is kept out of prompt documents, source guidance, and RAG. You can also start from the **Narrative**, **Bulleted**, or **Mixed** preset, or write the note yourself. Once you edit the note, a new style reference or **Re-analyze** asks before replacing it. The note travels with session export.

**Truncation handling:** When a response is cut off at the model's `max_tokens` limit, the final (partially-parsed, potentially corrupt) field value is automatically dropped from the `propose_changes` call, `truncated: true` is sent back to the model, and the model is asked to re-propose that field in a smaller batch. This prevents a silently wrong value from being applied.

Each response in the activity log shows a compact context-size badge (e.g., `· 85k ctx`) reflecting the prompt token count for that turn.

Three additional tools are available to the AI in both bulk-edit and review conversations:

- **`get_field_info`** — look up field definitions, `ai_hint` values, current answers, and document structure for specific sections on demand. Allows the review system prompt to stay lean (~3 k tokens) by omitting field data that is only needed when a specific section is examined.
- **`get_template_context`** — view the surrounding prose in the unfilled document template (`.docx` or markdown) where a field's output will appear. Queries by field key, line range, or keyword search. Returns numbered lines with a document outline annotated with nearby `{{TAG}}` placeholders. Useful when drafting freetext fields to match tone and avoid duplicating headings already present in the template.
- **`ask_user`** — pause and ask the user one or more multiple-choice questions when their preference or decision would meaningfully shape the response and can't be reasonably inferred (see "Asking the User" below).

After applying accepted changes, the drawer closes and the interview page opens so users can review the filled fields before continuing. Conversations are persisted to IndexedDB and can be resumed after a page reload. The **Chat Sessions** dropdown in the panel header lists them; hovering a row reveals a trash icon that deletes that conversation (messages and metadata), and deleting the active one starts a fresh chat. Old conversations that were started before the tool-call migration (those containing `<proposed-changes>` XML blocks in assistant messages) are still rendered correctly via a backward-compatibility fallback.

### Asking the User

The AI can call `ask_user` at any point in a conversation to ask up to 4 multiple-choice questions in a single batch — for example, to confirm a tone, pick between equally valid phrasings, or get a decision before drafting. This is a general-purpose mechanism: the model decides if and when to ask, and it is not tied to any particular kind of decision (it is separate from, and unrelated to, the conflict-detection mechanism described below).

Questions render inline in the chat as a card:

- Each question can be single-select (radio) or multi-select (checkboxes), with up to 6 labeled options. An option can carry a short description and a "★ Recommended" badge.
- A built-in **Other** field lets the user type a free-text answer instead of (or alongside) the listed options; a **Skip** link is always available.
- When a card has more than one question, they appear as tabs/chips you can switch between; number keys select an option and Enter advances to the next question or submits.

Submitting (or skipping) delivers the answers back to the model as the deferred result of the `ask_user` call, and the conversation resumes immediately — no extra round trip is needed. Typing a reply directly into the chat input while a question is pending answers the first question with that text and marks any remaining questions in the batch as skipped. The AI panel always switches to the Chat tab when a question is pending so it's never missed behind another tab, and an unanswered question is restored correctly if you reload the page mid-question. Answered questions leave a compact summary of the chosen options under the assistant's message.

### Effort Tier Selector

A **Fast / Balanced / Thorough** dropdown in the chat toolbar controls the AI effort level for the current conversation:

| Tier | Label | Model | Behaviour |
|------|-------|-------|-----------|
| `low` | Fast | Standard | Low effort — quickest responses |
| `medium` | Balanced | Standard | Medium effort — default |
| `high` | Thorough | Advanced | Extended thinking enabled (10 k token budget); inter-chunk stream timeout 90 s (initial 180 s) |

The selector is disabled while a response is streaming. Extraction requests always use the Fast tier regardless of the selector value. The active model name appears in the selector's tooltip.

### AI Observations and Conflict Detection

When two or more documents are attached, the AI can detect contradictions, gaps, and assumptions across them and report those findings as structured observations. Observations appear in a dedicated **Conflicts** tab in the AI panel, each showing:

- **Severity** — color-coded indicator (e.g., warning, error)
- **Type** — the category of issue (contradiction, gap, assumption)
- **Source details** — which documents are involved
- **Recommendation** — suggested action to resolve the conflict

**Automatic detection:** The model is instructed to call `report_observations` proactively during extraction and normal chat turns when it notices discrepancies. The `fms-source-review` schema takes this further: its field hints direct the AI to systematically compare every shared fact across attached source documents and record each disagreement in a structured findings table as a standalone pre-drafting step. Observations accumulate across turns and are restored when a conversation is resumed after a page reload.

When a document attached to a picker slot clearly does not match the slot's expected content (e.g. a vendor quote placed in the PWS slot), the AI calls `report_observations` with type "conflict" to flag the mismatch and uses the document only as general reference material, not as authoritative for that slot's fields.

**Cross-tab navigation:** Field change proposals in the Proposed Changes tab that relate to a flagged observation display a conflict badge. Clicking the badge jumps directly to the corresponding card in the Conflicts tab.

### AI Document Review

The Preview page includes a **"Review with AI"** button that sends the generated document(s) to the AI assistant for a final quality check before export. The AI analyzes the full rendered output and flags cross-cutting issues:

- **Inconsistencies** — related field values that contradict each other
- **Placeholders** — unfilled template artifacts (`{{...}}`, `[Not provided]`)
- **Coherence** — logical problems in narrative sections
- **Calculations** — amounts or totals that don't add up
- **Quality** — incomplete sentences, unprofessional tone, missing context

Issues are reported via the `report_observations` tool and appear in the **Conflicts** tab. The review is fully conversational — users can ask follow-up questions about any flagged issue.

**How the review works** — clicking "Review with AI":

1. Registers the generated document(s) as virtual entries in the document manager (small documents are included inline in the prompt; large documents are chunked and embedded for `search_references` retrieval).
2. Opens the AI panel with a lean, review-specific system prompt (~3 k tokens) in place of the bulk-edit prompt — field-editing guidance and `propose_changes` are omitted; the reviewer uses `report_observations`, `get_field_info`, and `get_template_context` instead.
3. Pre-fills the chat input with a review request so the user can send immediately or customize the prompt first.

The generated document source badge (`📝`) appears in the document picker, so users can see what the AI is reviewing and deselect documents as needed.

For document sets, each document in the accordion has its own **Review** button that scopes the review to that document's schema and content. The top-level "Review with AI" button attaches all documents and instructs the AI to check for cross-document inconsistencies (e.g., party names or amounts that differ between documents).

### Adding Documents Mid-Conversation

Documents can be added to an active conversation at any time by opening the document picker. When the picker closes, the chat automatically receives a notification containing the new document's content — inline text for small documents, or a search notice for large documents that have been indexed into embeddings. The model immediately responds with additional `propose_changes` proposals based on the new material, with no manual follow-up required.

If a newly added document is still being embedded when the picker closes, the notification is deferred and fires automatically once embedding finishes.

The Send button is disabled while any attached document is still being fetched, parsed, or embedded. Each attached document chip shows a spinner during processing, and a status banner appears in the chat panel until all documents are ready. If content is unavailable at send time (e.g. an embedding failure), the chat panel shows an explicit error rather than silently omitting the document from the prompt.

The document picker accepts `.pdf`, `.docx`, `.xlsx`, `.xls`, `.csv`, `.txt`, `.md`, and `.json` files. JSON files are read as plain text, which is useful for attaching structured data exports (e.g., a saved progress file) as AI context. The maximum upload size is 50 MB per file. Scanned PDFs with no selectable text layer are rejected with a message pointing users to OCR tools; legacy `.doc` (binary Word 97) and password-protected files are rejected with a clear explanation.

### Error Reports and Diagnostics

Every error box in the app — inline file errors, AI errors, settings errors, and the save-error banner — has a **Copy Error Report** button. Clicking it copies a JSON payload containing the error summary, the active endpoint configuration, feature flags, and the most recent caught errors from the in-memory ring buffer. The report is safe to share — it contains no field values or document content.

When the app hits an unrecoverable error (root error boundary) or IndexedDB fails to open at startup (storage-unavailable page), a **Copy diagnostics** button also appears directly on the crash page with the same JSON content.

Diagnostics can also be copied without an error: use **View → Copy Diagnostics** or the **Copy diagnostics** button in the Settings footer. Reports include the build SHA (also shown in the Settings footer as "Build <sha> · <date>"; `dev` for local builds) and the resolved models.

The storage-unavailable page additionally offers an **Export progress** button (saves in-memory answers before storage fails) and a **Clear data and reload** last-resort action that deletes the IndexedDB database and localStorage then reloads the app.

To report an error, use the "Copy Error Report" button and send the result to Winston T. Chu (winston.chu@leidos.com).

### General Chat (No Document Open)

When no document is open (Home, Manage Templates, Documentation), the AI Assistant panel works as a general-purpose chat. The empty chat explains that the assistant can be used as a general chatbot (including for questions about CUI material) whenever no drafting session is active, and invites the user to ask a question or attach documents; the input shows "Ask anything…". It uses the same pipeline as document chats (streaming, effort tiers, `ask_user`, document attachments with CUI scanning, embedding and `search_references` for large documents, IndexedDB persistence, conversation dropdown), but the drafting tools (`propose_changes`, `report_observations`, `get_field_info`, `get_template_context`) are not offered, and the Changes/Observations tabs and the troubleshoot export menu are hidden.

Uploads in general mode are saved under the `general` category, so they do not appear in document sessions' pickers and vice versa. Conversations are stored under the pseudo session id `__general__`, survive reloads, and can be deleted one at a time from the Chat Sessions dropdown (or all at once with **Clear all data**). The panel starts a new conversation whenever the chat session changes after page load (a document or set is started, opened, or closed); a reload restores the most recent one. The feature code is in `src/ai/generalChat.ts` behind the `GENERAL_CHAT_ENABLED` constant (no Settings toggle).

### Exporting a Chat for Troubleshooting

A kebab menu (three vertical dots) in the AI panel header provides chat-level utilities. Currently it has one action: **Export Chat for Troubleshooting**.

Clicking it downloads a JSON file named `<document-title>-chat-troubleshoot-<timestamp>.json` that contains:

- All messages in the conversation (including hidden tool-role messages), with tool call details and response timings (including per-call token usage, with cached input shown separately).
- The active endpoint configuration (ID, label, base URL, and model names) at the time of export.
- Session context: document type, schema title, and the set of answered field keys — actual field values are **not** included, only which keys have a non-empty value.
- Browser environment metadata (user agent, current URL, timestamp).

The file is intended for sharing with an administrator or developer to diagnose unexpected AI behaviour. Because field values are omitted, it is safe to share without concerns about sensitive content.

### Adding Reference Documents

Pre-loaded reference documents can be made available to all users by placing files in `static/reference-docs/<category>/`. The `referenceDocsManifest` Vite plugin inventories all supported files at build time and writes a `manifest.json` that the app fetches at runtime.

Supported formats (same as the user upload dialog): `.pdf`, `.docx`, `.xlsx`, `.xls`, `.csv`, `.txt`, `.md`, `.json`, and common image types (`.png`, `.jpg`, `.jpeg`, `.gif`, `.webp`, `.tiff`).

When a user selects a reference doc, the app fetches the raw file and processes it through the same upload and parsing pipeline as a user-uploaded document — no special handling required. To add a new reference document, drop the file into the appropriate category folder; no code changes are needed.

---

## Git LFS (Required for Templates)

Word templates (`.docx`) are tracked via [Git LFS](https://git-lfs.com/) to keep the repository fast with ~50+ binary files. **One-time setup per machine:**

```bash
# Install git-lfs (if not already installed)
sudo apt-get install git-lfs   # Ubuntu/Debian
# or: brew install git-lfs     # macOS

# Initialize LFS for your user (once per machine)
git lfs install

# Clone normally — LFS files download automatically
git clone <repo-url>
```

The `.gitattributes` file tracks `*.docx`, `*.doc`, `*.xlsx`, `*.pptx`, and `*.pdf` via LFS. No additional configuration needed after the one-time `git lfs install`.

> **Note for CI:** The GitLab CI pipeline installs `git-lfs` and runs `git lfs pull` automatically in the `pages` job. If you use a custom runner, ensure `git-lfs` is available and `GIT_LFS_SKIP_SMUDGE: "0"` is set.

---

## Testing

The project has two test layers: Vitest for unit and component tests, and Playwright for end-to-end tests.

### Unit and Component Tests (Vitest)

```bash
npm test              # single run (CI-friendly)
npm run test:watch    # interactive watch mode
npm run test:coverage # with V8 coverage report
```

Tests are colocated next to source files (`Component.tsx` → `Component.test.tsx`). Test infrastructure lives in `src/test/`:

- **`setup.ts`** — global setup (jest-dom matchers, fake-indexeddb, localStorage/jsdom stubs)
- **`mocks.ts`** — factory functions for context values, schemas, and sessions
- **`renderWithProviders.tsx`** — custom `render()` wrapper with MemoryRouter + mocked context providers
- **`docx-test-utils.ts`** — template loading from disk, text extraction from .docx blobs, heading hierarchy analysis, structural OOXML validation, tag artifact detection, text leak detection
- **`fixture-utils.ts`** — sample answer generation per schema, fixture file loading from `src/test/fixtures/`

**Template integrity tests** (`src/schemas/templateIntegrity.test.ts`) run as part of `npm test` and validate that all `.docx` templates are consistent with their schemas. Three suites run for every registered schema that has a `.docx` template:

- **Template Coverage** — every schema with `docx_template` on disk is registered in the loader; every registered template file exists; every template has a `template_key_map`.
- **Template Integrity** — every `{{TAG}}` in the `.docx` has a `template_key_map` or `content_blocks` entry; every TKM key exists in the template; every TKM value resolves to a real `section_id.field_id`; loop tags map to table-type fields with matching columns.
- **Template Readability** — the `.docx` is a valid ZIP archive; all required OOXML parts are present (`[Content_Types].xml`, `_rels/.rels`, `word/document.xml`, `word/_rels/document.xml.rels`); `word/document.xml` is well-formed XML; `[Content_Types].xml` Override entries reference existing parts; relationship targets in `document.xml.rels` resolve inside the archive; no invalid XML 1.0 control characters exist in template text; all namespace prefixes listed in `mc:Ignorable` are declared on the root element (undeclared prefixes are the root cause of Word's "found unreadable content" errors).
- **Set Consistency** — shared fields have consistent types and table columns across schemas in the same set; `same_as` references resolve within the merged field pool; formula fields don't total tables that would be column-split.

**Document output quality tests** validate that generated Word documents are correct, uncorrupted, and read as coherent whole documents. Four test files run for every schema with a `.docx` template:

- **Extraction Accuracy** (`src/ai/extractionAccuracy.test.ts`) — `coerceValue()` unit tests for all 7 field types; `parseBulkEditResponse()` integration tests covering multi-field parsing, confidence score clamping, code fence stripping, same_as/formula field skipping, skip-reason reporting (unknown fields, coercion failures, identical values, linked fields), and error handling.
- **Structural Validity** (`src/generation/docxOutputQuality.test.ts`) — every generated .docx is validated as a valid ZIP/OOXML package with well-formed XML, correct tag substitution, boolean "Yes"/"No" rendering, and date format verification.
- **Variant Substitution** (`src/generation/variantSubstitution.test.ts`) — STR variant documents verified for no source text leakage, replacement text presence, structural parity with base documents, and field value identity.
- **Document Continuity** (`src/generation/documentContinuity.test.ts`) — heading hierarchy validation, no orphaned loop markers, value echo (every scalar answer appears in document output), cross-reference consistency via `same_as`, every tagged formula field's value in the output, document length sanity, and table completeness.

Optional LLM-gated tests (skipped in CI) evaluate document coherence using AI. Enable with `RUN_LLM_TESTS=true npm test`.

See `docs/RUNBOOK.md` for troubleshooting CI failures.

### End-to-End Tests (Playwright)

```bash
npm run test:e2e          # headless Chromium + Firefox run
npm run test:e2e:headed   # visible browser (useful for debugging)
npm run test:e2e:ui       # Playwright interactive UI
```

Firefox must be installed before running locally:

```bash
npx playwright install firefox
```

E2E tests live in `e2e/` and require the dev server (Playwright starts it automatically):

```
e2e/
  fixtures/
    app.fixture.ts        → base fixture: seeds role, clears IndexedDB between tests
    ai-mock.fixture.ts    → network-level LiteLLM interceptor (streaming + JSON + error codes)
  helpers/
    indexeddb.ts          → seedSession(), getSession(), clearAllDatabases()
    sse.ts                → buildSSEResponse() / buildJsonResponse() for mock AI payloads (Anthropic SSE event format)
  pages/                  → page-object model (HomePage, InterviewPage, ReviewPage, …)
  tests/
    01-home.spec.ts       → role selection, schema cards, navigation
    02-interview-flow.spec.ts → full NDA interview, back-navigation, direct URL access
    03-review.spec.ts     → review page rendering and approval
    04-preview.spec.ts    → document preview and download
    05-ai-draft.spec.ts   → AI bulk-draft streaming, error handling (401/429)
    06-session-resume.spec.ts → resume banner, answer persistence across reload
    07-edge-cases.spec.ts → invalid routes, no-session states, console error detection
    08-ai-degradation.spec.ts → 401/404/500/network/prompt-too-long: message shown, manual entry and .docx download still work
    09-storage-errors.spec.ts → quota-full banner appears and clears on next successful write
    11-number-entry.spec.ts   → number inputs accept commas, reformat on blur, and total correctly (Chromium + Firefox)
```

Playwright configuration is in `playwright.config.ts`. On CI, tests retry up to twice and run single-threaded. Screenshots and traces are saved on failure to `e2e/test-results/`.

### UI Check Agent

Run `/ui-check` in Claude Code to trigger a three-pass automated review:

1. **Unit tests** — runs Vitest and reports failures with file/line context
2. **Static analysis** — reads components for React anti-patterns, accessibility issues, and state bugs
3. **Route integrity** — verifies all navigation targets resolve and no pages render blank

### Ground-Truth Testing

Ground-truth testing validates generated output against a hand-authored reference document for a real case. The tooling ranges from low-level CLI utilities to a fully automated fixture builder.

**CLI tools** (manual, composable):

```bash
# Headless render — feeds an answers file through the real Docxtemplater pipeline (no browser)
npx tsx tools/render-docx.ts <schema-id> <answers.json> <out.docx> [--text]

# Structured text extraction from a .docx (JSON with paragraph/table structure; --text for plain text)
python3 tools/docx-diff.py extract <file.docx> [--text]

# Section-aligned diff of two .docx files; --allow whitelists known-acceptable hunks
python3 tools/docx-diff.py diff <a.docx> <b.docx> [--allow allow.json]
```

**Regression test** (`src/test/groundTruth.test.ts`) — run via `npm test -- groundTruth`. For every fixture under `src/test/fixtures/ground-truth/<schema-id>/<case-id>/`, it renders `answers.json` against the schema template and diffs against `expected.txt`. Any hunk not covered by `allow.json` fails the test, flagging a template or schema defect. Fixtures are scrubbed of PII and committed, so they act as a permanent gate on future template/schema changes.

**Document-set fixtures** live under `src/test/fixtures/ground-truth/sets/<set-slug>/<case-id>/` with `set.json`, one shared `answers.json`, and per-member `expected/<schema-id>.txt` and `allow/<schema-id>.json`. The test renders the shared answers through every member schema of the set and reports one test per member (`sets/<set-slug>/<case-id> > <schema-id>`). Current set fixtures cover TT&E.

**Bootstrap agent** (`gt-bootstrap`) — builds a fixture from a real case:

1. Place case files in `cases/<case-id>/` (gitignored) with subfolders `input/`, `output/`, and `output - ground truth/` (exactly one `.docx` in the ground-truth folder).
2. Run the agent:
   ```
   Agent(subagent_type: "gt-bootstrap", prompt: "Bootstrap cases/<case-id>/ --schema <schema-id>")
   ```
   It reverse-extracts `answers.json` from the ground truth, renders the template, diffs, classifies each hunk (template defect vs. data difference vs. ground-truth deviation), asks you to confirm a PII scrub map, and writes the fixture to `src/test/fixtures/ground-truth/<schema-id>/<case-id>/`.
3. For a whole document set, use `--set <set-id>` instead of `--schema` (one ground-truth `.docx` per member; `output/` is optional).
4. Add `--from-input` to also run live AI extraction on the `input/` files, verifying the extraction step and not just rendering.

**Repair loop** — `/schema-quality-loop <schema-id>` picks up `groundTruth` test failures and feeds them into the schema-judge/repair agents.

---

## Gitlab Pages Access

To request access for new users, submit a request at:
https://helpdesk.sdo.leidos.com/servicedesk/customer/portal/4/create/77

Also, ensure the Pages are enabled in Settings > General > Visibility > Pages

Also, uncheck `use unique domain` in Settings > Deploy > Pages > Domains & settings

## Update Notifications

On first visit a blue notice bar asks you to join the Doc Builder update mailing list so you are notified when new features or schema changes ship. Click **Email me to join** to open a prefilled email, or **Dismiss** to hide the bar permanently.

To sign up after dismissing the bar: open **Help → Get Update Notifications…** in the menu bar. The same prefilled email opens.

Contact and mailing list details are also on the **Help → Contact & Feedback** page.

## Deployment

Pushes to `main` auto-deploy via GitLab CI:

```
npm ci → npm run build → mv dist public → GitLab Pages serves public/
```

After a new deploy, any browser tab still running the previous build may encounter 404s on lazy-loaded chunks (e.g. the pdfjs-dist chunk loaded on first PDF upload) because the old hashed filenames no longer exist. The app detects this via a `vite:preloadError` handler and automatically reloads the page to fetch the latest assets; a `sessionStorage` guard prevents reload loops.

See `.gitlab-ci.yml` for the full pipeline. The pipeline also runs GitLab SAST (semgrep), Secret Detection, Dependency Scanning, and DAST on every MR and on the default branch. These security jobs are defined in `.gitlab-ci.ultimate.yml`, included from the main CI file. Dependency Scanning and DAST need GitLab Ultimate and turn themselves off when the subscription isn't active, so the include can stay on any tier.

A pipeline schedule runs the e2e suite against production every day at 18:00 (`e2e-nightly`; it runs nothing else). Setup, ownership, and failure notifications are in `docs/RUNBOOK.md` → *Scheduled e2e check*.

### Branch Workflow

| Branch | Purpose | URL |
|--------|---------|-----|
| `main` | Production | `https://ams-oot.pages.lsde.leidos.com/doc-builder/` |

**Flow:** feature branch → MR into `main` → deploys directly to production.

## Tech Stack

React 19 · TypeScript · Vite · Tailwind CSS · Dexie (IndexedDB) · Anthropic TypeScript SDK (`@anthropic-ai/sdk`) · LiteLLM proxy for AI features · Node 22

---

## Settings

Open **Edit → Settings** to configure the following:

### Your Information

Enter your name, title, phone, and email. These values are stored in localStorage and used to pre-populate SCS/Preparer fields automatically whenever you start a new document. You can always edit the pre-filled values during the interview.

### AI Endpoint Configuration

Doc Builder supports two LiteLLM endpoints:

| Endpoint | Label | Use for |
|----------|-------|---------|
| `non-cui` | Proprietary (IL2) | Unclassified / commercial data |
| `cui` | CUI (IL5) | Controlled Unclassified Information |

Settings → **AI Endpoints** shows one tab per endpoint. Each tab contains:

- **API Key** field and **Test** button — hits `GET /v1/models` and shows a green "✓ Connected" or a specific error inline.
- **Use this endpoint for AI requests** — explicit action to make that endpoint the active one. The tab bar shows an "In use" badge on whichever endpoint is currently selected.
- **Endpoint URL** — the base URL the app sends requests to.
- **Models for …** — a dropdown for each AI role (Standard, Advanced, Light, and Embeddings — all four rows appear on both endpoints; Light is used for CUI scanning), filled from the proxy's model list and filtered by type (chat models for chat roles, embedding models for Embeddings). **Refresh model list** re-queries the proxy using the key typed in the tab. "Other…" accepts a custom model ID; IDs that look like the wrong type show a warning. A "Newer model available" hint offers a one-click switch — newer models are never applied automatically. Cost per 1M tokens and context window appear when the proxy's `/model/info` allows it (currently blocked for user keys, so they show as unavailable).

Keys are stored in this browser and sent only to their own endpoint's LiteLLM proxy.

#### Automatic Model Substitution

On startup the app queries `/v1/models` on each endpoint and caches the result. If a configured model has been retired by the proxy, the app automatically substitutes the newest same-family model from the discovered list. An amber **"AI model changed"** banner at the top of the page names the old and new model and points to Edit → Settings to choose a different one; it is shown once per change. While the configured model is still listed, the app keeps using it even if a newer one exists.

For full setup instructions including how to obtain a key, see `docs/help/api-key-setup.md`.

#### Automatic CUI Detection

When you upload a document while the Proprietary (IL2) endpoint is active, Doc Builder automatically checks the document for CUI content using a two-step approach:

1. **Regex pre-screen** — scans the full document text for standard CUI markings: `CONTROLLED UNCLASSIFIED INFORMATION`, `CUI` category codes, `FOUO`, `NOFORN`, `ITAR`, distribution statements B–F, and export-control notices. High-confidence results are returned immediately.
2. **AI classification** — if no regex match is found, an AI call via the CUI (IL5) endpoint performs a deeper semantic classification of the document excerpt (up to 12 000 characters). The classification uses a forced tool call (`classify_cui`) for structured, cross-model-compatible output. This step requires the CUI API key to be configured; if it is absent, only regex detection runs.

If CUI content is detected, the document is saved to IndexedDB but its text is **not** sent to any AI endpoint. When you click **Attach** in the document picker, a warning dialog appears listing the flagged documents with three choices:

| Choice | Effect |
|--------|--------|
| **Switch to CUI Mode & Attach** | Switches the active endpoint to CUI (IL5) and attaches the documents |
| **These Are Not CUI — Attach** | Affirms the documents do not contain CUI and attaches them on the current endpoint |
| **Cancel** | Dismisses the dialog; the documents remain saved but unattached |

"Switch to CUI Mode & Attach" is the highlighted, pre-focused default, so pressing Enter takes the safe path; "These Are Not CUI — Attach" is an outline button. If no CUI API key is configured, the switch button is disabled, **Cancel** becomes the highlighted, pre-focused choice, and the dialog links to Settings.

Documents with embedded images that have CUI markings have those images **quarantined** until the user resolves the warning — they are not sent to the vision extraction API until the document is cleared. After resolution the images are extracted automatically.

The **Attach** button in the document picker is disabled (showing a status message) while any selected document is still being parsed or scanned for CUI. Each document row shows its current CUI status with color-coded pills: "Scanning for CUI…", "Potential CUI Content Detected", "Images quarantined", "CUI", or "Potential CUI — scan incomplete".

If no CUI API key is configured, a persistent banner in the document picker notes that AI-based CUI scanning and image text extraction are unavailable, and images in documents with CUI markings will be quarantined pending manual confirmation. The banner links to Settings and cannot be dismissed — the gap it describes persists until a key is configured.

Detection always fails open — if an error occurs during the AI classification step, the upload proceeds without blocking.

#### Endpoint Mode Banner and Document Badges

Both document picker dialogs (AI panel and AI Draft page) display an active-endpoint banner at the top — amber for CUI (IL5) mode, blue for Proprietary (IL2) mode — so you always know which endpoint your uploads will be routed through.

Each document in the picker, setup card, and uploaded-docs library shows a small endpoint pill badge indicating which endpoint was active when that document was saved. Documents uploaded in CUI mode are automatically hidden from the list when you are in Proprietary mode; a note at the bottom of the list reports how many documents are hidden and why.

Documents confirmed as not containing CUI are labelled "Not CUI" in the uploaded-docs library. Documents where the AI scan failed are labelled "Potential CUI — scan incomplete"; the full scan error is shown in a copyable error box inline in the picker.

### AskSage (SharePoint)

> **Note:** The AskSage (SharePoint / OneDrive) integration is currently disabled pending approval from the AskSage team (a CORS allowance for the production origin). It is hidden by the `askSage` feature flag in `src/ai/featureFlags.ts`; the code is kept on purpose. See the STATUS block at the top of `src/ai/asksage.ts` for what's needed and how to re-enable it.

Enter your Leidos email and AskSage API key (JWT) to enable SharePoint / OneDrive search in the document picker. Click **Test** to verify the connection. Credentials are stored in localStorage and sent only to `api.asksage.leidos.com`.

When a connection test or SharePoint search fails, the error is displayed in a styled error box with the full server message in copyable monospace text, plus a prompt to send the message to your Doc Builder administrator if the issue persists.

For step-by-step onboarding instructions, see `docs/help/asksage-setup.md`.

---

## SharePoint / OneDrive Integration

> **Note:** The AskSage (SharePoint / OneDrive) integration is currently disabled pending approval from the AskSage team (a CORS allowance for the production origin). It is hidden by the `askSage` feature flag in `src/ai/featureFlags.ts`; the code is kept on purpose. See the STATUS block at the top of `src/ai/asksage.ts` for what's needed and how to re-enable it.

When AskSage credentials are configured (see Settings above), a **SharePoint / OneDrive** panel appears in the document picker alongside the local file upload zone. Users can:

1. Type a search query (e.g. `"NDA templates"` or `"SOW contract"`)
2. Browse structured results showing filename, site/folder path, size, and last-modified date
3. Click **Add** on any file to fetch its content and route it through the normal extraction pipeline (mammoth for `.docx`, pdf.js for `.pdf`, SheetJS for `.xlsx`, etc.)

The integration uses the AskSage M365 MCP tool API (`api.asksage.leidos.com`). A Vite dev proxy (`/api/asksage`) routes requests in local development to avoid CORS issues. See `docs/asksage-m365-integration.md` for the full API reference and lessons learned during implementation.

---

## In-App Documentation

**Help → Documentation** in the menu bar opens an in-app Markdown viewer backed by `src/docs/docsRegistry.ts`. The registry uses `import.meta.glob` at build time to auto-discover files; no code changes are needed to add or remove pages.

### Publishing a doc in-app

- **`docs/public/`** — project-facing docs (development plan, proposals, tutorial outline, procurement docs). Available to all users under `/docs/public/<name>`.
- **`docs/help/`** — end-user help topics (API key setup, AskSage/SharePoint setup, contact). Available under `/docs/help/<name>`.

Everything else under `docs/` (runbooks, internal notes, integration references) is **not** bundled into the app and remains developer-only. A Vitest test (`src/docs/docsRegistry.test.ts`) enforces this boundary.

### Adding a document

Drop a `.md` file into `docs/public/` or `docs/help/`. The sidebar picks it up automatically on the next build. The first `# ` heading becomes the sidebar title; relative `.md` links between published docs resolve to in-app routes.

### Tutorial outline

`docs/public/tutorial-outline.md` is a 30-minute presenter outline for developer-led live demos. It covers the AI-first intake workflow, setup prerequisites, common pain points, and what a template or schema change request involves (Word template and/or JSON schema edits made by the dev team).
