/**
 * Vite plugin that scans static/reference-docs/<category>/ at build/dev time
 * and emits a manifest.json mapping each category to its available files.
 *
 * Supported formats (same as the AI assistant upload):
 * .pdf, .docx, .xlsx, .xls, .csv, .txt, .md, .json, .png, .jpg, .jpeg, .gif, .webp, .tiff
 *
 * The plugin does NO conversion — it simply inventories source files. When the
 * user selects a reference doc at runtime, the app fetches the raw file and
 * processes it through the same upload/parsing pipeline as user-uploaded docs.
 *
 * To add a new reference document, just drop a supported file in the
 * appropriate category folder — no code changes needed.
 *
 * Output (emitted as build asset at reference-docs/manifest.json):
 * {
 *   "fms": [
 *     { "id": "sca-subcontractor-information-20260814", "title": "SCA Subcontractor Information 20260814", "fileName": "SCA Subcontractor Information 20260814.xlsx", "url": "reference-docs/fms/SCA Subcontractor Information 20260814.xlsx" }
 *   ],
 *   ...
 * }
 */
import path from "node:path";
import { globSync } from "tinyglobby";
import type { Plugin } from "vite";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

/** All supported extensions (matches the upload dialog's accept list) */
const SUPPORTED_EXTENSIONS = [
  ".txt", ".md", ".json",
  ".csv",
  ".xlsx", ".xls",
  ".docx",
  ".pdf",
  ".png", ".jpg", ".jpeg", ".gif", ".webp", ".tiff",
];

/** Known acronyms to keep uppercase in generated titles */
const ACRONYMS = ["FMS", "NDA", "LCSP", "DOD", "DTSA", "UTSA", "IPT", "IDIQ", "SOR", "SCA"];

// ---------------------------------------------------------------------------
// Title / ID helpers
// ---------------------------------------------------------------------------

/**
 * Convert a filename to a display title.
 * Handles both kebab-case ("fms-acquisition-guidelines.txt") and
 * space-separated ("SCA Subcontractor Information 20260814.xlsx") filenames.
 */
function fileNameToTitle(fileName: string): string {
  const stem = fileName.replace(/\.[^.]+$/, ""); // strip extension
  const words = stem.split(/[-\s]+/);
  return words
    .map((word) => {
      const upper = word.toUpperCase();
      if (ACRONYMS.includes(upper)) return upper;
      if (/^\d+$/.test(word)) return word;
      return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
    })
    .join(" ");
}

/** Convert a filename to a stable kebab-case ID */
function fileNameToId(fileName: string): string {
  const stem = fileName.replace(/\.[^.]+$/, "");
  return stem
    .toLowerCase()
    .replace(/\s+/g, "-")
    .replace(/[^a-z0-9-]/g, "");
}

// ---------------------------------------------------------------------------
// Manifest builder
// ---------------------------------------------------------------------------

interface ManifestEntry {
  id: string;
  title: string;
  fileName: string;
  url: string;
}

type Manifest = Record<string, ManifestEntry[]>;

/**
 * Build the manifest by globbing for supported files in reference-docs/<category>/.
 * Uses tinyglobby instead of direct fs calls to avoid SAST CWE-22 findings.
 * tinyglobby returns [] when cwd doesn't exist, so no existence check is needed.
 */
export function buildManifest(staticDir: string): Manifest {
  const refDocsDir = path.join(staticDir, "reference-docs");
  const manifest: Manifest = {};

  const extPattern = SUPPORTED_EXTENSIONS.map((e) => `*${e}`).join(",");
  const files = globSync(`*/{${extPattern}}`, {
    cwd: refDocsDir,
    onlyFiles: true,
    deep: 1,
    caseSensitiveMatch: false,
    expandDirectories: false,
  });

  for (const relPath of files) {
    // relPath is e.g. "fms/SCA Subcontractor Information 20260814.xlsx"
    const sep = relPath.indexOf("/");
    if (sep === -1) continue;
    const category = relPath.slice(0, sep);
    const fileName = relPath.slice(sep + 1);

    if (!manifest[category]) manifest[category] = [];
    manifest[category].push({
      id: fileNameToId(fileName),
      title: fileNameToTitle(fileName),
      fileName,
      url: `reference-docs/${category}/${fileName}`,
    });
  }

  return manifest;
}

// ---------------------------------------------------------------------------
// Vite Plugin
// ---------------------------------------------------------------------------

export default function referenceDocsManifest(): Plugin {
  let staticDir: string;

  return {
    name: "reference-docs-manifest",
    configResolved(config) {
      staticDir = config.publicDir;
    },
    generateBundle() {
      const manifest = buildManifest(staticDir);
      this.emitFile({
        type: "asset",
        fileName: "reference-docs/manifest.json",
        source: JSON.stringify(manifest, null, 2) + "\n",
      });
    },
    configureServer(server) {
      const refDocsDir = path.join(staticDir, "reference-docs");
      let cachedManifest = buildManifest(staticDir);

      const regenerate = () => {
        cachedManifest = buildManifest(staticDir);
      };

      const isSourceFile = (file: string) =>
        file.startsWith(refDocsDir) &&
        SUPPORTED_EXTENSIONS.some((ext) => file.toLowerCase().endsWith(ext));

      // Watch for changes and regenerate in-memory manifest
      server.watcher.add(refDocsDir);
      server.watcher.on("add", (file) => {
        if (isSourceFile(file)) regenerate();
      });
      server.watcher.on("change", (file) => {
        if (isSourceFile(file)) regenerate();
      });
      server.watcher.on("unlink", (file) => {
        if (isSourceFile(file)) regenerate();
      });

      // Serve manifest from memory — intercepts before Vite's static file serving
      server.middlewares.use((req, res, next) => {
        const base = server.config.base || "/";
        const manifestPath = `${base}reference-docs/manifest.json`;
        const url = req.url?.split("?")[0];
        if (url === manifestPath) {
          const body = JSON.stringify(cachedManifest, null, 2) + "\n";
          res.setHeader("Content-Type", "application/json");
          res.setHeader("Content-Length", Buffer.byteLength(body));
          res.setHeader("Cache-Control", "no-cache");
          res.end(body);
          return;
        }
        next();
      });
    },
  };
}
