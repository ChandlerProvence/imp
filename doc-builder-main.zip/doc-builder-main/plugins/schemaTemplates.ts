/**
 * Vite plugin that publishes every built-in schema's Word template at
 * `${BASE_URL}templates/<file>.docx`, where templateSource.ts fetches it.
 *
 * Templates live beside their schemas (src/schemas/<id>/<file>.docx) but are
 * served from one flat directory, so basenames must be unique — enforced by
 * the duplicate-basename check in src/schemas/templateIntegrity.test.ts.
 *
 * - build: each template is emitted as a bundle asset under templates/.
 * - dev:   a middleware serves the same URLs straight from src/schemas/.
 *
 * Replaces vite-plugin-static-copy, whose chokidar 3 → braces dependency
 * carried an unfixed advisory.
 */
import { readFileSync } from "node:fs";
import path from "node:path";
import { globSync } from "tinyglobby";
import type { Plugin } from "vite";

const SCHEMAS_DIR = "src/schemas";
const URL_DIR = "templates";

/** Map of template basename → absolute path, found by globbing src/schemas/. */
export function findTemplates(root: string): Map<string, string> {
  const files = globSync("**/*.docx", {
    cwd: path.join(root, SCHEMAS_DIR),
    absolute: true,
    onlyFiles: true,
    expandDirectories: false,
  });
  return new Map(files.map((file) => [path.basename(file), file]));
}

export default function schemaTemplates(): Plugin {
  let root: string;

  return {
    name: "schema-templates",
    configResolved(config) {
      root = config.root;
    },
    generateBundle() {
      for (const [name, file] of findTemplates(root)) {
        this.emitFile({ type: "asset", fileName: `${URL_DIR}/${name}`, source: readFileSync(file) });
      }
    },
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        const prefix = `${server.config.base || "/"}${URL_DIR}/`;
        const url = req.url?.split("?")[0];
        if (!url?.startsWith(prefix)) return next();

        // Only names found by the glob are served, so the URL can't reach other files.
        // Re-globbing per request picks up added or renamed templates without a watcher.
        const file = findTemplates(root).get(decodeURIComponent(url.slice(prefix.length)));
        if (!file) return next();

        const body = readFileSync(file);
        res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
        res.setHeader("Content-Length", body.length);
        res.setHeader("Cache-Control", "no-cache");
        res.end(body);
      });
    },
  };
}
