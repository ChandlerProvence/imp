# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Answering Questions

When the user asks a question, answer the question. Do not assume a question is a request to change code.

## Planning Rules

When creating implementation plans, always include a final step that asks the user whether they'd like to update documentation (changelog.d/, README.md, docs/public/development-plan.md) to reflect the changes made. Do not auto-run `/update-docs` — just ask.

## Project Overview

Doc Builder is a schema-driven, TurboTax-style SPA for building standardized documents with AI-assisted drafting. It runs entirely client-side (no backend) and deploys as static files to GitLab Pages.

**Status:** Feature-complete and in daily use; sustainment is the current priority. `docs/public/development-plan.md` lists sustainment work first, then remaining MVP-gate items, then the backlog for when feature development resumes; completed work is in collapsed sections at the bottom.

## Tech Stack

- **Framework:** React + TypeScript
- **Build:** Vite (base path: `/doc-builder/` for GitLab Pages sub-path)
- **Styling:** Tailwind CSS
- **Persistence:** IndexedDB via Dexie (no backend database)
- **AI:** Anthropic TypeScript SDK (`@anthropic-ai/sdk`) via LiteLLM proxy at `https://lmg.leadai.leidos.com`
- **Models:** Defaults for the IL2/Proprietary and IL5/CUI endpoints live in `src/ai/endpoints.ts`. Roles are vendor-neutral capability classes: `models.standard` (Sonnet) handles extraction, `models.advanced` (Opus) handles drafting, and `models.light` (Haiku) handles CUI scanning.
- **Routing:** BrowserRouter with `basename` from Vite's `BASE_URL` (404.html fallback for GitLab Pages SPA support)
- **Deployment:** GitLab Pages (static `dist/` → `public/` artifact on push to `main`)

## Build & Dev Commands

```bash
npm ci                # install dependencies
npm run dev           # local dev server
npm run build         # production build (outputs to dist/)
npm test              # run all tests (unit + component)
npm run test:watch    # interactive watch mode
npm run test:coverage # run with V8 coverage report
```

## Architecture

```
/src/
  /schemas/        # Document type definitions (JSON) — the extensibility backbone
  /engine/         # Interview state machine, session tracking, section completion
  /components/     # Wizard shell, field renderer, upload UI, chat panel
  /pages/          # Route-level views (home, interview, review, dashboard)
  /generation/     # .docx generation (Docxtemplater, Markdown → Word XML, TOC, images), preview, legacy Markdown templates
  /extraction/     # File parsing (mammoth, pdf.js, xlsx, csv)
  /ai/             # Embeddings, chunking, semantic retrieval, bulk edit orchestration
  /db/             # Dexie schema and IndexedDB access layer
  /errors/         # AppError type, catalog.ts (all user-facing wording), per-domain classifiers, toAppError, recordError ring buffer
  /test/           # Test infrastructure (setup, mocks, renderWithProviders)
```

### Key Design Decisions

- **Schema-first:** All document types are JSON definitions. Adding a new document type requires only a new `.schema.json` file — zero application code changes. Engine and component changes are not allowed for a new document type.
- **No backend:** All state lives in IndexedDB. The LiteLLM API key lives in localStorage and is sent only to the LiteLLM proxy.
- **Field namespacing:** Answers are keyed as `section_id.field_id` for template substitution (`{{parties.disclosing_party_name}}`).
- **Extraction/interview decoupling:** AI extraction produces answers in the same shape as manual entry — no separate code paths.
- **Provider portability:** OpenAI compatibility is a likely future requirement. Changes that further entrench the app in the Anthropic ecosystem (Anthropic-only request parameters such as `cache_control`, thinking, or structured outputs; the SDK tool runner; SDK-specific helper types leaking into shared code; Zod-based tool definitions) should be reconsidered or kept behind `src/ai/featureFlags.ts` toggles with a portable fallback (forced `tool_choice` is the universal one). Tool definitions stay as raw JSON schema in `src/ai/toolDefinitions.ts`. LiteLLM is the intended compatibility layer — it already translates Anthropic-format requests to GPT models — and is an acceptable way to enable OpenAI backends if that becomes a requirement, so prefer solutions that keep working through the proxy over ones that require Anthropic-direct.
- **Client-side RAG:** Multi-document input uses a hybrid approach — small docs (≤10k chars) are included directly in the prompt; large docs are chunked (800 chars, 200 overlap), embedded via the embedding model, and stored in IndexedDB. At extraction time, relevant chunks are retrieved (top-K=10) and sent alongside full small docs. Combined prompt is capped at 100k characters.
- **Error handling:** Every catch site that surfaces an error calls `toAppError(err, { domain })` from `src/errors/`; user-facing wording lives only in `src/errors/catalog.ts`. Library errors are recognized by per-domain classifiers in `src/errors/classifiers/` — classify by HTTP status and message text, not by SDK class names (provider portability). Code that knows the cause throws `appErrorException(kind)`. Render user-facing errors with `<AppErrorBox>`; background IndexedDB writes go through `trackWrite()` (`src/db/writeStatus.ts`) so failures raise the `SaveErrorBanner`. Adding an error kind = one `catalog.ts` entry + one classifier case + one fixture row in `src/errors/classifiers.contract.test.ts`.

### Schema Format

Document type schemas define `sections` → `fields` with types: `string`, `number`, `boolean`, `date`, `enum` (with `options` array), `multiselect` (checkbox group, value stored as JSON array), `freetext` (multi-paragraph, eligible for AI drafting). Optional `ai_hint` on fields provides guidance to the AI writing assistant. Most schemas render through a `.docx` template, and `template_key_map` maps template tags to `section_id.field_id` answers. Some older schemas use `output_template` instead, which is a Markdown string with `{{section_id.field_id}}` placeholders.

**Calculated values:** a `number` field or table column with `formula` is calculated; schema-level `constants` names numbers formulas can use. One parser, scope resolver, graph (cycle detector and evaluation order), evaluator, and validator live in `src/engine/formula/`; the loader, `resolveEffectiveAnswers`, the `.docx` generator, and the template editor's locks all go through it. Column formulas see sibling columns and constants; field formulas also see `section.field` paths and `SUM`/`AVG`/`MIN`/`MAX`/`COUNT(table.column)`. The old `computed`, `aggregates`, and `derived_fields` shapes are rejected by the loader; stored custom templates and uploads are rewritten on read by `migrateSchemaShape` (`src/schemas/migrateStored.ts`), so a schema-shape change needs a migration rule there rather than a Dexie upgrade.

**Document-set membership** is defined in `src/schemas/sets/*.set.json` files (one file per set), not by the inline `set` field on individual schemas. The inline `set` field is a legacy fallback. To add a schema to a set or create a new set, edit or create a `.set.json` file.

**Inline hints:** Template authors can annotate placeholders with `{{FIELD_NAME: hint text}}` to guide schema generation. The hint becomes the field's `ai_hint`. Hints are stripped from the stored template via `docx-utils.py strip-hints` so Docxtemplater only sees clean `{{FIELD}}` tags.

**Content blocks:** Schemas may declare `content_blocks: Record<string, string | boolean | { when: BlockCondition }>` to control conditional sections in `.docx` templates. Boolean values toggle `{{#TAG}}...{{/TAG}}` sections; string values fill `{{TAG}}` placeholders; `{ when: BlockCondition }` entries are evaluated at runtime against the current answers (see `src/engine/contentBlocks.ts` for operators). Content block keys are NOT in `template_key_map` — they are injected directly into the Docxtemplater data object. Variant resolution shallow-merges `content_blocks` so variants can flip individual blocks. Template integrity tests exclude `content_blocks` keys from orphan-field checks.

**Conditional visibility:** Sections and fields may declare `visible_when: "BLOCK_NAME"` to show/hide based on the named content block's evaluated value. The shared evaluator in `src/engine/contentBlocks.ts` is consumed by the wizard, section outline, Review page, AI prompt builder, and `.docx` generator so all layers agree on visibility.

**Validation rules:** Fields and table columns may declare `validate: [{ "rule": "<name>", ...params }]`. Each rule is one module in `src/engine/validation/rules/` registered in `registry.ts`; the loader, wizard, sidebar, Review page, AI proposal checks, and AI prompt consume rules generically, so a new criterion needs only the rule file, its test, and a registry line. Problems are warnings only — never block generation. Current rules: `range`, `compare`.

## Deployment

CI is in `.gitlab-ci.yml`. A single `pages` job deploys on push to `main` (no separate beta/production branches). The project currently has GitLab Ultimate, but it could be withdrawn at any time: CI must keep working on Free, so Ultimate-only jobs gate on `$GITLAB_FEATURES` (see `.gitlab-ci.ultimate.yml`). Scheduled pipelines run only `e2e-nightly`; give every new job a `$CI_PIPELINE_SOURCE == "schedule"` → `never` rule. Production URL: `https://ams-oot.pages.lsde.leidos.com/doc-builder/`.

**Workflow:** feature branch → MR into `main` → deploys directly to production.

## Documentation

Run `/update-docs` before opening a PR or release to sync the managed doc files:

- **`changelog.d/`** — One markdown fragment per branch; Keep a Changelog format with `### Added` / `### Changed` / `### Fixed` sections. Named `YYYYMMDD-HHMMSS.<branch>.md`.
- **`README.md`** — Reflects current features, usage, and configuration.
- **`docs/public/development-plan.md`** — Tracks completed and planned phases. Note: the update-docs plugin looks for `DEVELOPMENT_PLAN.md` at the repo root by default; this project keeps it under `docs/public/` instead.

## Word Template Editing

After any edit to a `.docx` template file, verify the template is intact. Use your judgment on scope:

- **Text-only changes** (placeholder renames, fixing a typo in a tag): a quick inline check is sufficient — confirm the new tag is present, the old one is gone, and the XML still parses.
- **Structural edits** (adding/removing loop markers, inserting/deleting paragraphs or runs, manipulating relationships or content types, bulk operations across multiple XML files): run the full `template-health` agent.

```
Agent(subagent_type: "template-health", prompt: "Run a deep template health check for schema at src/schemas/<dir>/. Check TKM integrity, template loop syntax, naming conventions, schema structure, and runtime viability.")
```

### User-uploaded templates

Users can upload their own schema + `.docx` pairs at `/templates`. These live only in IndexedDB (`userTemplates`, Dexie v12) and are registered at runtime under the reserved `custom-` id prefix. Built-in schema ids must never start with `custom-` (enforced in `loader.ts`). Upload validation (`src/schemas/userTemplateValidation.ts`) reuses the same checks as `templateIntegrity.test.ts`, which now live in `src/schemas/templateScan.ts`. A new integrity check belongs in `templateScan.ts` so that both CI and uploads get it.

**Promoting a submitted template to a built-in:** users send a `.template-bundle.json` through "Submit for team use".
1. Run `npx tsx tools/import-template-bundle.ts <bundle.json> [--id <id>] [--force] [--dry-run]`. It re-validates the bundle and writes `src/schemas/<id>/`.
2. Add the `loader.ts` lines it prints, and add roles or set membership if they're needed.
3. Run `template-health`.

**AI authoring guide:** `docs/help/template-authoring-guide.md` is what users give a chatbot to edit or create templates. It ships inside every download zip. Update it whenever the schema format or upload validation changes. `templateAuthoringGuide.test.ts` fails if a field type or content-block operator is missing from the guide, or if the guide's worked example stops validating. Every validator issue code needs a fix entry in `src/schemas/issueCatalog.ts`; the type system enforces this.

When the release ships, anyone holding the custom copy is offered "Switch to official". This happens automatically when the built-in id equals the bundle's original id, or when the template's `based_on` names that built-in.

## Ground-Truth Testing

To validate generated output against hand-authored reference documents:

1. **Place case files** in `cases/<case-id>/` (gitignored) with subfolders `input/`, `output/`, `output - ground truth/`.
2. **Run the bootstrap agent:**
   ```
   Agent(subagent_type: "gt-bootstrap", prompt: "Bootstrap cases/<case-id>/ --schema <schema-id>")
   ```
   This reverse-extracts answers from the ground truth, renders the template, diffs, classifies findings, scrubs PII, and writes a fixture to `src/test/fixtures/ground-truth/<schema-id>/<case-id>/`.

   For a whole document set, pass `--set <set-id>` instead of `--schema` (one ground-truth `.docx` per member; `output/` is optional). Set fixtures land in `src/test/fixtures/ground-truth/sets/<set-slug>/<case-id>/` with one shared `answers.json` plus per-member `expected/<schema-id>.txt` and `allow/<schema-id>.json`.
3. **Run the regression test:** `npm test -- groundTruth` — fails on unallowed hunks (template/schema defects). Set fixtures report one test per member (`sets/<set-slug>/<case-id> > <schema-id>`).
4. **Repair via the quality loop:** `/schema-quality-loop <schema-id>` picks up the test failures and feeds them into the existing repair workflow. A repair to one set member must keep the other members' set tests green, because they share `answers.json`.

**CLI tools:**
- `npx tsx tools/render-docx.ts <schema-id> <answers.json> <out.docx> [--text]` — headless render
- `python3 tools/docx-diff.py extract <file.docx> [--text]` — structured text extraction
- `python3 tools/docx-diff.py diff <a.docx> <b.docx> [--allow allow.json]` — section-aligned diff
