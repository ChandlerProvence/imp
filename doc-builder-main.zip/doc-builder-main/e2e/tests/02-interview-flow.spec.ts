import { test, expect } from '../fixtures/app.fixture';
import { seedSession } from '../helpers/indexeddb';
import { InterviewPage } from '../pages/interview.page';

// Seed an empty session so the interview page has context
const EMPTY_NDA_SESSION = {
  id: 'test-interview-session',
  documentTypeId: 'nda',
  answers: {} as Record<string, string | number | boolean>,
  currentSection: 'parties',
  sectionConfirmed: {},
};

test.describe('Interview Flow (NDA)', () => {
  test.beforeEach(async ({ page }) => {
    await seedSession(page, EMPTY_NDA_SESSION);
    await page.reload();
  });

  test('complete NDA interview from start to review', async ({ page }) => {
    const interview = new InterviewPage(page);
    await interview.goto('nda', 'parties');
    await interview.waitForSection();

    // --- Section 1: Parties ---
    await expect(interview.getSectionTitle()).toContainText('Parties');

    await interview.fillField('Disclosing party name', 'Acme Corp');
    await interview.fillField('Receiving party name', 'Widget Inc');
    await interview.toggleBoolean('Is this a mutual NDA?');
    await interview.fillDateField('Effective date', '2025-01-15');

    await interview.clickNext();

    // --- Section 2: Terms ---
    await expect(interview.getSectionTitle()).toContainText('Terms');

    await interview.fillNumberField('Duration (months)', 12);
    await interview.selectEnum('Governing law (state)', 'Virginia');

    await interview.clickNext();

    // --- Section 3: Confidentiality Obligations ---
    await expect(interview.getSectionTitle()).toContainText('Confidentiality Obligations');

    await interview.fillField(
      'Describe the confidentiality obligations',
      'Both parties agree to maintain strict confidentiality of all shared information.',
    );

    // Navigate to Review
    await interview.clickReview();
    await page.waitForURL(/\/review/);
  });

  test('back navigation preserves field values', async ({ page }) => {
    const interview = new InterviewPage(page);
    await interview.goto('nda', 'parties');
    await interview.waitForSection();

    // Fill a field on section 1
    await interview.fillField('Disclosing party name', 'Test Corp');

    // Wait for debounced save
    await page.waitForTimeout(500);

    await interview.clickNext();

    // Go back
    await interview.clickBack();

    // Value should be preserved
    const field = page.getByLabel('Disclosing party name');
    await expect(field).toHaveValue('Test Corp');
  });

  test('direct URL to specific section works', async ({ page }) => {
    const interview = new InterviewPage(page);
    await interview.goto('nda', 'terms');
    await interview.waitForSection();

    await expect(interview.getSectionTitle()).toContainText('Terms');
  });
});
