import { test, expect } from '../fixtures/app.fixture';
import { seedSession } from '../helpers/indexeddb';

/**
 * Storage failures: when browser storage is full, autosave failures must be
 * visible (not silent data loss), and the banner clears once saving recovers.
 */

const SESSION = {
  id: 'test-session-storage',
  documentTypeId: 'nda',
  answers: {} as Record<string, string | number | boolean>,
  currentSection: 'parties',
  sectionConfirmed: {},
};

test('storage-full autosave shows the save banner and clears on recovery', async ({ page }) => {
  await seedSession(page, SESSION);
  await page.reload();
  await page.goto('interview/nda/parties');
  await expect(page.getByText(/open for editing in another tab/)).toBeHidden({ timeout: 10_000 });

  // Simulate a full disk: every IndexedDB write throws QuotaExceededError
  await page.evaluate(() => {
    const w = window as unknown as { __quotaFull: boolean };
    w.__quotaFull = true;
    const quota = () => new DOMException('The quota has been exceeded.', 'QuotaExceededError');
    for (const proto of [IDBObjectStore.prototype, IDBCursor.prototype] as unknown as Record<string, (...a: unknown[]) => unknown>[]) {
      for (const method of ['put', 'add', 'update']) {
        const original = proto[method];
        if (typeof original !== 'function') continue;
        proto[method] = function (this: unknown, ...args: unknown[]) {
          if (w.__quotaFull) throw quota();
          return original.apply(this, args);
        };
      }
    }
  });

  await page.getByLabel(/Disclosing party/i).fill('Acme Corp');
  const banner = page.getByRole('alert').filter({ hasText: "Your changes aren't being saved" });
  await expect(banner).toBeVisible({ timeout: 10_000 });
  await expect(banner).toContainText('Browser storage is full');
  await expect(banner.getByRole('button', { name: 'Export session' })).toBeVisible();

  // Space freed — the next autosave succeeds and the banner clears
  await page.evaluate(() => {
    (window as unknown as { __quotaFull: boolean }).__quotaFull = false;
  });
  await page.getByLabel(/Disclosing party/i).fill('Acme Corporation');
  await expect(banner).toBeHidden({ timeout: 10_000 });
});
