import { test, expect } from '../fixtures/ai-mock.fixture';
import { maxConversationMessageCount } from '../helpers/indexeddb';

const GENERAL_SESSION_ID = '__general__';

/** Wait until the question and its reply have been written to IndexedDB. */
async function waitForSavedExchange(page: import('@playwright/test').Page) {
  await expect.poll(() => maxConversationMessageCount(page, GENERAL_SESSION_ID), { timeout: 10_000 }).toBe(2);
}

/**
 * The AI Assistant without a document session: a general chat on the Home page.
 * The cleanApp fixture leaves no session, so the panel is in general mode.
 */
test.describe('General chat (no document open)', () => {
  test('offers a chat input instead of the "start a document" placeholder', async ({ page }) => {
    await page.goto('./');
    await expect(page.getByPlaceholder(/Ask anything/i)).toBeVisible();
    await expect(page.getByText(/used as a general chatbot/)).toBeVisible();
    await expect(page.getByText(/attach documents to ask about them/)).toBeVisible();
    await expect(page.getByText(/Start a document to use AI-assisted drafting/)).toHaveCount(0);
    await expect(page.getByText(/start drafting/)).toHaveCount(0);
  });

  test('answers a question and restores the conversation after a reload', async ({ page, mockAI }) => {
    await mockAI({ streamContent: 'FMS stands for Foreign Military Sales.' });

    await page.goto('./');
    const chatInput = page.getByPlaceholder(/Ask anything/i);
    await chatInput.fill('What does FMS stand for?');
    await chatInput.press('Enter');

    await expect(page.getByText(/Foreign Military Sales/)).toBeVisible({ timeout: 15_000 });
    await waitForSavedExchange(page);

    await page.reload();
    await expect(page.getByPlaceholder(/Ask anything/i)).toBeVisible();
    await expect(page.getByText(/What does FMS stand for\?/)).toBeVisible({ timeout: 10_000 });
    await expect(page.getByText(/Foreign Military Sales/)).toBeVisible();
  });

  test('starts a fresh chat when a document is opened and again when it is closed', async ({ page, mockAI }) => {
    await mockAI({ streamContent: 'FMS stands for Foreign Military Sales.' });

    await page.goto('./');
    const generalInput = page.getByPlaceholder(/Ask anything/i);
    await generalInput.fill('What does FMS stand for?');
    await generalInput.press('Enter');
    await expect(page.getByText(/Foreign Military Sales/)).toBeVisible({ timeout: 15_000 });

    // Opening a document: drafting mode, on a new empty conversation.
    await page.getByRole('button', { name: 'Non-Disclosure Agreement' }).click();
    const draftInput = page.getByPlaceholder(/Ask the AI to help draft/i);
    await expect(draftInput).toBeVisible();
    await expect(page.getByText(/start drafting/)).toBeVisible();
    await expect(page.getByText(/Foreign Military Sales/)).toHaveCount(0);

    await mockAI({ streamContent: 'Here is a draft for the parties section.' });
    await draftInput.fill('Draft the parties section');
    await draftInput.press('Enter');
    await expect(page.getByText(/draft for the parties section/)).toBeVisible({ timeout: 15_000 });

    // Closing the document: general mode again, on a new empty conversation.
    await page.goto('./');
    await page.getByRole('button', { name: 'Clear' }).click();
    await expect(page.getByPlaceholder(/Ask anything/i)).toBeVisible();
    await expect(page.getByText(/used as a general chatbot/)).toBeVisible();
    await expect(page.getByText(/Foreign Military Sales/)).toHaveCount(0);
    await expect(page.getByText(/draft for the parties section/)).toHaveCount(0);
  });

  test('deletes a prior chat session from the dropdown', async ({ page, mockAI }) => {
    await mockAI({ streamContent: 'FMS stands for Foreign Military Sales.' });

    await page.goto('./');
    const input = page.getByPlaceholder(/Ask anything/i);
    await input.fill('What does FMS stand for?');
    await input.press('Enter');
    await expect(page.getByText(/Foreign Military Sales/)).toBeVisible({ timeout: 15_000 });
    await waitForSavedExchange(page);

    // Start a second chat so the first one becomes a prior session.
    const dropdown = page.getByRole('button', { name: /^Chat Sessions|\d{1,2}:\d{2}/ }).first();
    await dropdown.click();
    await page.getByRole('button', { name: 'New Chat Session' }).click();
    await expect(page.getByText(/Foreign Military Sales/)).toHaveCount(0);

    // Delete the prior session (the one with 2 messages).
    await dropdown.click();
    const priorRow = page.locator('div.group').filter({ hasText: '2 msgs' });
    await expect(priorRow).toHaveCount(1);
    await priorRow.hover();
    await priorRow.getByRole('button', { name: /Delete chat session/ }).click();
    await expect(page.locator('div.group').filter({ hasText: '2 msgs' })).toHaveCount(0);

    // It stays gone after a reload.
    await page.reload();
    await expect(page.getByPlaceholder(/Ask anything/i)).toBeVisible();
    await expect(page.getByText(/Foreign Military Sales/)).toHaveCount(0);
  });

  test('sends the general system prompt and no drafting tools', async ({ page, mockAI }) => {
    await mockAI({ streamContent: 'Hello.' });

    const requestBody = page.waitForRequest((req) => req.url().includes('/v1/messages') && req.method() === 'POST');

    await page.goto('./');
    const chatInput = page.getByPlaceholder(/Ask anything/i);
    await chatInput.fill('Hi');
    await chatInput.press('Enter');

    const body = JSON.parse((await requestBody).postData() ?? '{}') as {
      system?: string | { text: string }[];
      tools?: { name: string }[];
    };
    const system = typeof body.system === 'string' ? body.system : (body.system ?? []).map((b) => b.text).join('\n');
    expect(system).toMatch(/general-purpose assistant/);
    expect(system).not.toMatch(/propose_changes/);
    expect((body.tools ?? []).map((t) => t.name)).toEqual(['search_references', 'ask_user']);
  });
});
