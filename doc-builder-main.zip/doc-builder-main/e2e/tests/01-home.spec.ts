import { test, expect } from '../fixtures/app.fixture';
import { HomePage } from '../pages/home.page';

test.describe('Home Page', () => {
  test('displays the role selection on first visit', async ({ page }) => {
    // Clear role so picker is visible
    await page.evaluate(() => localStorage.removeItem('doc-builder:user-role'));
    await page.reload();

    const home = new HomePage(page);
    await expect(home.heading).toBeVisible();
    await expect(page.getByText('Select Your Group')).toBeVisible();
  });

  test('selecting a role shows schemas for that role', async ({ page }) => {
    // Clear role to show picker
    await page.evaluate(() => localStorage.removeItem('doc-builder:user-role'));
    await page.reload();

    const home = new HomePage(page);
    await home.selectRole('Contracts / Legal');

    // NDA should be visible (it has roles: ["contracts"])
    await expect(page.getByText('Non-Disclosure Agreement')).toBeVisible();
  });

  test('schema card shows metadata (sections, fields)', async ({ page }) => {
    const home = new HomePage(page);

    // With "contracts" role seeded, NDA is visible
    // NDA has 3 sections, 6 fields
    const ndaCard = page.getByRole('button', { name: /Non-Disclosure Agreement/ });
    await expect(ndaCard).toBeVisible();
    await expect(ndaCard).toContainText('sections');
    await expect(ndaCard).toContainText('fields');
  });

  test('clicking a schema navigates to the interview page', async ({ page }) => {
    const home = new HomePage(page);
    await home.clickSchema('Non-Disclosure Agreement');

    // startSession navigates to /interview/:schemaId/:firstSectionId
    await page.waitForURL(/\/interview\/nda\//);
  });

  test('"Change" button resets role selection', async ({ page }) => {
    const home = new HomePage(page);
    await home.changeRoleButton.click();

    await expect(page.getByText('Select Your Group')).toBeVisible();
  });

  test('"Generate full set" navigates to interview', async ({ page }) => {
    // Switch to fms-specialist role which has document sets
    await page.evaluate(() => {
      localStorage.setItem('doc-builder:user-role', 'fms-specialist');
    });
    await page.reload();
    await page.waitForLoadState('networkidle');

    const home = new HomePage(page);
    await home.clickGenerateFullSet();

    // startSetSession navigates to /interview/:schemaId/:firstSectionId
    await page.waitForURL(/\/interview\//);
  });

  test('clicking a sidebar section navigates to that section', async ({ page }) => {
    const home = new HomePage(page);
    await home.clickSchema('Non-Disclosure Agreement');

    // Wait for interview to load
    await page.waitForURL(/\/interview\/nda\//);

    // Click a different section in the sidebar — should stay in interview
    const sidebarSection = page.locator('nav button', { hasText: /Terms|Parties|Confidentiality/ }).first();
    await sidebarSection.click();
    await page.waitForURL(/\/interview\/nda\//);
  });
});
