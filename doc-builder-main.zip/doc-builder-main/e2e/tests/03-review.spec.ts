import { test, expect } from '../fixtures/app.fixture';
import { seedSession } from '../helpers/indexeddb';
import { ReviewPage } from '../pages/review.page';

const COMPLETED_NDA_SESSION = {
  id: 'test-session-review',
  documentTypeId: 'nda',
  answers: {
    'parties.disclosing_party_name': 'Acme Corp',
    'parties.receiving_party_name': 'Widget Inc',
    'parties.is_mutual': true,
    'parties.effective_date': '2025-01-15',
    'terms.duration_months': 12,
    'terms.governing_law': 'Virginia',
    'obligations.obligations_text':
      'Both parties agree to maintain strict confidentiality of all shared information.',
    'obligations.exclusions_text': 'Information that is publicly available.',
  },
  currentSection: 'obligations',
  sectionConfirmed: { parties: true, terms: true, obligations: true },
  reviewApproved: false,
};

test.describe('Review Page', () => {
  test.beforeEach(async ({ page }) => {
    await seedSession(page, COMPLETED_NDA_SESSION);
    await page.reload();
  });

  test('displays all filled answers', async ({ page }) => {
    const review = new ReviewPage(page);
    await review.goto();

    await review.expectContains('Acme Corp');
    await review.expectContains('Widget Inc');
    await review.expectContains('Virginia');
    await review.expectContains('12');
  });

  test('displays freetext content', async ({ page }) => {
    const review = new ReviewPage(page);
    await review.goto();

    await review.expectContains('Both parties agree to maintain strict confidentiality');
  });

  test('approve button navigates to preview', async ({ page }) => {
    const review = new ReviewPage(page);
    await review.goto();

    await review.clickApprove();
    await page.waitForURL(/\/preview/);
  });
});
