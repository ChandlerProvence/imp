import { test, expect } from '../fixtures/app.fixture';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildDocx, headingPara, para, table } from '../../src/test/docxFixtures';
import { seedSession } from '../helpers/indexeddb';

const ROOT = resolve(fileURLToPath(new URL('../..', import.meta.url)));

const schema = {
  id: 'vendor-letter',
  title: 'Vendor Letter',
  version: 1,
  docx_template: 'vendor-letter.docx',
  sections: [
    {
      id: 'main',
      title: 'Main',
      fields: [
        { id: 'vendor', label: 'Vendor name', type: 'string', required: true },
        { id: 'summary', label: 'Summary', type: 'freetext', required: false },
      ],
    },
  ],
  template_key_map: { VENDOR: 'main.vendor', SUMMARY: 'main.summary' },
};

const files = (docxText = 'Dear {{VENDOR: legal name}},') => [
  { name: 'vendor-letter.schema.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify(schema)) },
  {
    name: 'vendor-letter.docx',
    mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    buffer: Buffer.from(buildDocx(para(docxText) + para('{{SUMMARY}}'))),
  },
];

test.describe('Custom templates', () => {
  test('upload, fill in, survive reload, and generate', async ({ page }) => {
    await page.goto('templates');
    await page.getByRole('button', { name: 'Add template…' }).click();
    const [schemaUpload, docxUpload] = files();
    await page.getByTestId('template-docx-input').setInputFiles(docxUpload);
    await expect(page.getByLabel('Word template added')).toBeVisible();
    await expect(page.getByRole('status')).toContainText('Add its .schema.json to check it as is');
    await page.getByTestId('template-schema-input').setInputFiles(schemaUpload);
    await expect(page.getByLabel('Schema added')).toBeVisible();

    // Hint stripped into ai_hint; no errors
    await expect(page.getByText(/Removed 1 inline hint/)).toBeVisible();
    await page.getByRole('button', { name: 'Add template', exact: true }).click();

    // Post-install nudge toward submitting
    await expect(page.getByText('“Vendor Letter” is ready')).toBeVisible();
    await page.getByRole('dialog').getByRole('button', { name: 'Draft document' }).click();

    await expect(page).toHaveURL(/interview\/custom-vendor-letter\/main/);
    await expect(page.getByRole('note')).toContainText('custom template');
    await page.getByLabel('Vendor name').fill('Acme Corp');

    // Cold reload: the template must load from IndexedDB before the session is restored
    await page.waitForTimeout(800); // debounced autosave
    await page.reload();
    await expect(page).toHaveURL(/interview\/custom-vendor-letter\/main/);
    await expect(page.getByLabel('Vendor name')).toHaveValue('Acme Corp');

    // Home lists it as local only
    await page.goto('./');
    await expect(page.getByText('Vendor Letter')).toBeVisible();
    await expect(page.getByText('Local only').first()).toBeVisible();

    // Generation reads the template from IndexedDB
    await page.goto('preview');
    await expect(page.getByText('Dear Acme Corp,')).toBeVisible({ timeout: 15_000 });
  });

  test('downloads an official template with the AI editing guide', async ({ page }) => {
    // Use the plain-download fallback instead of the native save dialog
    await page.addInitScript(() => {
      delete (window as unknown as { showSaveFilePicker?: unknown }).showSaveFilePicker;
    });
    await page.goto('templates');
    await page.getByLabel('Official template').selectOption('lcsp');
    const download = page.waitForEvent('download');
    await page.getByRole('button', { name: 'Download as starting point' }).click();
    const file = await download;
    expect(file.suggestedFilename()).toBe('lcsp-custom-starting-point.zip');

    const { default: PizZip } = await import('pizzip');
    const { readFileSync } = await import('node:fs');
    const zip = new PizZip(readFileSync(await file.path()));
    expect(Object.keys(zip.files).sort()).toEqual(
      ['AI-EDITING-GUIDE.md', 'README.txt', 'lcsp-custom.docx', 'lcsp-custom.schema.json'],
    );
    expect(zip.file('AI-EDITING-GUIDE.md')!.asText()).toContain('Procedure A');
  });

  // Phase 2 acceptance test: a tagged .docx alone → editor → preview → save → generate, with no JSON
  test('builds a template from a tagged Word file in the editor', async ({ page }) => {
    const docx = buildDocx(
      headingPara(1, 'Letter') +
        para('Dear {{VENDOR}},') +
        para('Date: {{LETTER_DATE}}') +
        para('Category: {{CATEGORY}}') +
        para('Urgent: {{URGENT}}') +
        para('{{SUMMARY}}') +
        headingPara(1, 'Items') +
        table([['Item', 'Qty'], ['{{#ITEMS}}{{NAME}}', '{{QTY}}{{/ITEMS}}']]),
    );
    await page.goto('templates');
    await page.getByRole('button', { name: 'Add template…' }).click();
    await page.getByTestId('template-docx-input').setInputFiles({
      name: 'Order Letter - Template.docx',
      mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      buffer: Buffer.from(docx),
    });
    await page.getByRole('button', { name: 'Build the schema from the tags' }).click();
    await expect(page).toHaveURL(/templates\/edit\/draft-/);
    await expect(page.getByLabel('Template name')).toHaveValue('Order Letter');

    const card = (name: string) => page.getByRole('article', { name, exact: true });
    const relabel = async (from: string, to: string) => card(from).getByLabel('Label', { exact: true }).fill(to);

    // Correct two field types
    await card('Category').getByLabel('Category type').selectOption('enum');
    await card('Category').getByRole('button', { name: 'Add a choice' }).click();
    await card('Category').getByLabel('Category choice 1', { exact: true }).fill('Parts');
    await card('Urgent').getByLabel('Urgent type').selectOption('boolean');
    await expect(card('Letter date').getByLabel('Letter date type')).toHaveValue('date');
    await expect(card('Summary').getByLabel('Summary type')).toHaveValue('freetext');

    // Correct every label, columns included
    await relabel('Vendor', 'Vendor name');
    await relabel('Letter date', 'Date of the letter');
    await relabel('Category', 'Purchase category');
    await relabel('Urgent', 'Is this urgent?');
    await relabel('Summary', 'Summary of the request');
    await relabel('Items', 'Items ordered');
    const columns = card('Items ordered').getByLabel('Column label');
    await columns.nth(0).fill('Item name');
    await columns.nth(1).fill('Quantity');

    // Preview shows the new labels where the tags were
    const preview = page.getByTestId('template-preview');
    await expect(preview).toContainText('Dear [Vendor name],', { timeout: 10_000 });
    await expect(preview).toContainText('Date: [Date of the letter]');
    await expect(preview).toContainText('[Item name]');
    await expect(preview).toContainText('[Quantity]');

    await page.getByRole('button', { name: 'Save', exact: true }).click();
    await expect(page).toHaveURL(/\/templates$/);
    await expect(page.getByRole('status')).toContainText('Added "Order Letter"');
    await expect(page.getByTestId('draft-row')).toHaveCount(0);

    // Draft a document from it and generate
    await page.getByTestId('template-row').filter({ hasText: 'Order Letter' }).getByRole('button', { name: 'Draft document' }).click();
    await expect(page).toHaveURL(/interview\/custom-order-letter\/letter/);
    await page.getByLabel('Vendor name').fill('Acme Corp');
    await page.waitForTimeout(800); // debounced autosave
    await page.goto('preview');
    await expect(page.getByText('Dear Acme Corp,')).toBeVisible({ timeout: 15_000 });
  });

  test('a template written with the old calculation shapes still uploads, edits, and calculates', async ({ page }) => {
    // fms-to-mod as an `Edit in app` copy looked before the single formula
    // language: computed formulas, an aggregate computed total.
    const old = JSON.parse(readFileSync(resolve(ROOT, 'src/engine/formula/__fixtures__/fms-to-mod.pre-formula.json'), 'utf-8'));
    old.id = 'to-mod-old';
    old.title = 'TO Mod (old shape)';
    delete old.roles;
    const docx = readFileSync(resolve(ROOT, 'src/schemas/fms-to-mod/TO - P0103xxxxx - Rls x - Mod xx - Subcontractor Name - Template.docx'));

    await page.goto('templates');
    await page.getByRole('button', { name: 'Add template…' }).click();
    await page.getByTestId('template-docx-input').setInputFiles({
      name: 'to-mod-old.docx',
      mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      buffer: docx,
    });
    await page.getByTestId('template-schema-input').setInputFiles({
      name: 'to-mod-old.schema.json',
      mimeType: 'application/json',
      buffer: Buffer.from(JSON.stringify(old)),
    });
    await expect(page.getByLabel('Schema added')).toBeVisible();
    await page.getByRole('button', { name: 'Add template', exact: true }).click();
    await page.getByRole('dialog').getByRole('button', { name: 'Not now' }).click();

    // Edit and save: calculated fields are locked but the template saves
    const row = page.getByTestId('template-row').filter({ hasText: 'TO Mod (old shape)' });
    await row.getByRole('link', { name: 'Edit' }).click();
    await expect(page).toHaveURL(/templates\/edit\/custom-to-mod-old/);
    await expect(page.getByText('Locked').first()).toBeVisible();
    await page.getByLabel('Template name').fill('TO Mod (migrated)');
    await page.getByRole('button', { name: 'Save', exact: true }).click();
    await page.getByRole('button', { name: 'Save changes' }).click();
    await expect(page).toHaveURL(/\/templates$/);
    await expect(page.getByTestId('template-row').filter({ hasText: 'TO Mod (migrated)' })).toHaveCount(1);

    // Generate: SUM(parts) and the price-change formula render as before
    const answers = JSON.parse(readFileSync(resolve(ROOT, 'src/test/fixtures/answers/fms-to-mod.answers.json'), 'utf-8'));
    answers['changes.mod_types'] = JSON.stringify(['Pricing']);
    answers['pricing.includes_tte'] = true;
    answers['pricing.includes_rr'] = false;
    answers['pricing.price_from'] = 120000;
    answers['pricing.parts_list'] = JSON.stringify({ rows: [{ noun: 'Power Supply', nsn: 'x', part_number: 'x', serial: 'SN-1', tat: 45, tte_rate: 150000 }] });
    await seedSession(page, {
      id: 'old-shape-session',
      documentTypeId: 'custom-to-mod-old',
      answers,
      currentSection: 'pricing',
      sectionConfirmed: {},
      reviewApproved: true,
    });
    await page.goto('interview/custom-to-mod-old/pricing');
    await expect(page.getByText('$150,000.00').first()).toBeVisible({ timeout: 15_000 });
    await page.goto('preview');
    await expect(page.getByText(/Increase Price from \$120,000\.00 by \$30,000\.00 to \$150,000\.00/)).toBeVisible({ timeout: 15_000 });
  });

  test('edits a copy of an official template in the app', async ({ page }) => {
    await page.goto('templates');
    await page.getByLabel('Official template').selectOption('lcsp');
    await page.getByRole('button', { name: 'Edit in app' }).click();
    await expect(page).toHaveURL(/templates\/edit\/draft-/);
    await expect(page.getByLabel('Template id')).toHaveValue('lcsp-custom');

    const first = page.getByRole('article').first();
    await first.getByLabel('Label', { exact: true }).fill('Renamed in the editor');
    await page.getByRole('button', { name: 'Save', exact: true }).click();
    await expect(page).toHaveURL(/\/templates$/);

    // The copy remembers its official template
    const row = page.getByTestId('template-row').filter({ hasText: 'based on' });
    await expect(row).toHaveCount(1);
    await row.getByRole('button', { name: 'Switch to official' }).click();
    await page.getByRole('dialog').getByRole('button', { name: 'Switch' }).click();
    await expect(page.getByRole('status')).toContainText('Your custom copy is archived below');
  });

  test('rejects a template whose tags do not match the schema', async ({ page }) => {
    await page.goto('templates');
    await page.getByRole('button', { name: 'Add template…' }).click();
    // Both files on one zone still go to the right slots
    await page.getByTestId('template-schema-input').setInputFiles(files('Dear {{VENDOR}} {{MYSTERY}}'));
    await expect(page.getByTestId('validation-report')).toContainText('{{MYSTERY}}');
    await expect(page.getByRole('button', { name: 'Add template', exact: true })).toBeDisabled();
  });
});
