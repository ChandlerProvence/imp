import { test, expect } from '../fixtures/app.fixture';
import { seedSession } from '../helpers/indexeddb';
import { InterviewPage } from '../pages/interview.page';

/**
 * Number entry with real keystrokes. Native <input type="number"> handled
 * commas differently per browser (Chromium dropped them; Firefox could keep
 * them on screen while reporting ""), so totals could disagree with what was
 * shown. This runs in every configured browser project.
 */

// A Pricing mod saved before `includes_tte` existed: no answer for it.
const PRICING_MOD_SESSION = {
  id: 'test-number-entry',
  documentTypeId: 'fms-to-mod',
  answers: {
    'changes.mod_types': JSON.stringify(['Pricing']),
    'pricing.includes_rr': false,
    'pricing.includes_str': false,
    'pricing.price_from': 1000,
    'pricing.parts_list': JSON.stringify({ rows: [{ noun: 'Power Supply', tte_rate: '' }] }),
  } as Record<string, string | number | boolean>,
  currentSection: 'pricing',
  sectionConfirmed: {},
};

test.describe('Number entry (FMS TO MOD pricing)', () => {
  test.beforeEach(async ({ page }) => {
    await seedSession(page, PRICING_MOD_SESSION);
    await page.reload();
    const interview = new InterviewPage(page);
    await interview.goto('fms-to-mod', 'pricing');
    await interview.waitForSection();
  });

  const rate = (page: import('@playwright/test').Page) => page.getByLabel(/^TT&E Rate/).first();
  const unitTotal = (page: import('@playwright/test').Page) => page.getByLabel(/^Total Unit Cost/).first();
  // Computed values render as "<span>Label</span><span>Value</span>". Scope to
  // the span so the AI panel's scope dropdown (which repeats labels) isn't matched.
  const computedValue = (page: import('@playwright/test').Page, label: string) =>
    page.locator('span', { hasText: label }).locator('xpath=following-sibling::span[1]');
  const firmFixedPrice = (page: import('@playwright/test').Page) => computedValue(page, 'Total firm fixed price ($)');
  const priceChange = (page: import('@playwright/test').Page) => computedValue(page, 'Price change amount ($)');

  async function typeRate(page: import('@playwright/test').Page, text: string) {
    await rate(page).click();
    await rate(page).fill('');
    await rate(page).pressSequentially(text);
  }

  test('unanswered TT&E checkbox shows as checked, matching the visible TT&E column', async ({ page }) => {
    await expect(page.getByLabel(/incorporate Teardown, Test & Evaluation/)).toBeChecked();
    await expect(rate(page)).toBeVisible();
  });

  test('typed thousands separators count toward the total', async ({ page }) => {
    await typeRate(page, '1,234.50');
    await expect(rate(page)).toHaveValue('1,234.50');
    await expect(unitTotal(page)).toHaveValue('1,234.50');
    await expect(firmFixedPrice(page)).toContainText('$1,234.50');
    await expect(priceChange(page)).toContainText('$234.50');
  });

  test('dollar signs are ignored and currency reformats on blur', async ({ page }) => {
    await typeRate(page, '$2000');
    await rate(page).blur();
    await expect(rate(page)).toHaveValue('2,000.00');
    await expect(firmFixedPrice(page)).toContainText('$2,000.00');
  });

  test('a decimal comma is flagged instead of silently misread', async ({ page }) => {
    await typeRate(page, '1234,5');
    await rate(page).blur();
    await expect(rate(page)).toHaveValue('1234,5');
    await expect(page.getByText('Row 1, TT&E Rate ($): Must be a number')).toBeVisible();
    await expect(firmFixedPrice(page)).toContainText('$0.00');
    await expect(priceChange(page)).toContainText('-$1,000.00');
  });
});
