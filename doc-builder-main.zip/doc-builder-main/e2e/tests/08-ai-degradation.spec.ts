import { test, expect, type AIMockConfig } from '../fixtures/ai-mock.fixture';
import { getSession, seedSession } from '../helpers/indexeddb';

/**
 * Graceful degradation: when the AI service fails in any of the common ways,
 * the user sees a specific, actionable message — and manual entry, Review,
 * and Word generation keep working.
 */

const SCHEMA = 'fms-funding-request';

const SESSION = {
  id: 'test-session-degradation',
  documentTypeId: SCHEMA,
  answers: { 'header.subcontractor': 'Widget Inc' } as Record<string, string | number | boolean>,
  currentSection: 'header',
  sectionConfirmed: {},
  reviewApproved: true,
};

const FAILURES: { name: string; mock: AIMockConfig; title: RegExp }[] = [
  { name: 'expired/invalid key (401)', mock: { errorCode: 401 }, title: /AI key rejected/ },
  { name: 'retired model (404)', mock: { errorCode: 404, errorMessage: 'model not found' }, title: /AI model unavailable/ },
  { name: 'server error (500)', mock: { errorCode: 500 }, title: /AI service error/ },
  { name: 'network down', mock: { networkError: true }, title: /Can't reach the AI service/ },
  {
    name: 'prompt too long (400)',
    mock: { errorCode: 400, errorMessage: 'prompt is too long: 250000 tokens > 200000 maximum' },
    title: /Too much text for the AI/,
  },
];

test.describe('AI outage degradation', () => {
  test.beforeEach(async ({ page }) => {
    // Force the file-saver fallback so the .docx save is a Playwright download
    // event instead of a native File System Access dialog.
    await page.addInitScript(() => {
      delete (window as { showSaveFilePicker?: unknown }).showSaveFilePicker;
    });
    await seedSession(page, SESSION);
    await page.reload();
  });

  for (const { name, mock, title } of FAILURES) {
    test(`${name}: clear message, manual entry and .docx download still work`, async ({ page, mockAI }) => {
      await mockAI(mock);
      await page.goto(`interview/${SCHEMA}/header`);

      // 1. AI request fails with the classified, user-facing message
      const chatInput = page.getByPlaceholder(/Ask the AI to help draft/i);
      await chatInput.fill('Draft the BLUF');
      await chatInput.press('Enter');
      await expect(page.getByText(title).first()).toBeVisible({ timeout: 30_000 });

      // 2. Manual entry still works and persists across a reload. The previous
      //    page load can briefly leave a tab lock behind; wait until editable.
      await expect(page.getByText(/open for editing in another tab/)).toBeHidden({ timeout: 10_000 });
      const field = page.getByLabel('Program / Task Order');
      await field.fill('TO-1234 Manual Entry');
      await expect
        .poll(async () => (await getSession(page))?.answers['header.program_task_order'], { timeout: 10_000 })
        .toBe('TO-1234 Manual Entry');
      await page.reload();
      await expect(page.getByLabel('Program / Task Order')).toHaveValue('TO-1234 Manual Entry');

      // 3. Review page still renders the manually entered value
      await page.goto('review');
      await expect(page.getByText('TO-1234 Manual Entry').first()).toBeVisible();

      // 4. Word generation still works
      await page.goto('preview');
      const downloadPromise = page.waitForEvent('download');
      await page.getByRole('button', { name: /Download as Word/ }).click();
      const download = await downloadPromise;
      expect(download.suggestedFilename()).toMatch(/\.docx$/);
    });
  }
});
