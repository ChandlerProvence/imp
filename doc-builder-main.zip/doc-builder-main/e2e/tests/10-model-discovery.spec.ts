import { test, expect } from '../fixtures/ai-mock.fixture';
import { seedSession } from '../helpers/indexeddb';

/**
 * Runtime model discovery: when the proxy no longer lists a configured model,
 * the app switches to the newest same-family model, says so once, and sends
 * requests with the replacement. While the configured model is still listed,
 * it stays pinned even if a newer one exists.
 */

// Mirrors ENDPOINTS["non-cui"].models in src/ai/endpoints.ts
const CONFIGURED_STANDARD = 'claude-sonnet-5-5-aws-comm-il2';
const CONFIGURED_ADVANCED = 'claude-opus-5-5-aws-comm-il2';
const CONFIGURED_LIGHT = 'claude-haiku-5-5-aws-comm-il2';
const EMBEDDING = 'text-embedding-3-small-azure-comm-il2';
const NEWER_STANDARD = 'claude-sonnet-5-9-aws-comm-il2';

const SESSION = {
  id: 'test-session-models',
  documentTypeId: 'nda',
  answers: {} as Record<string, string | number | boolean>,
  currentSection: 'parties',
  sectionConfirmed: {},
};

async function sendAndCaptureModel(page: import('@playwright/test').Page): Promise<string> {
  const requestPromise = page.waitForRequest((req) => req.url().endsWith('/v1/messages') && req.method() === 'POST');
  const chatInput = page.getByPlaceholder(/Ask the AI to help draft/i);
  await chatInput.fill('Fill out the NDA');
  await chatInput.press('Enter');
  const request = await requestPromise;
  return JSON.parse(request.postData() ?? '{}').model;
}

test.describe('Model discovery', () => {
  test.beforeEach(async ({ page }) => {
    await seedSession(page, SESSION);
  });

  test('substitutes a retired model and tells the user once', async ({ page, mockAI }) => {
    await mockAI({ availableModels: [NEWER_STANDARD, CONFIGURED_ADVANCED, CONFIGURED_LIGHT, EMBEDDING] });
    await page.goto('interview/nda/parties');

    const notice = page.getByRole('status').filter({ hasText: 'AI model changed' });
    await expect(notice).toContainText(`${CONFIGURED_STANDARD} is no longer available; using ${NEWER_STANDARD} instead.`);

    expect(await sendAndCaptureModel(page)).toBe(NEWER_STANDARD);

    await notice.getByRole('button', { name: 'Dismiss' }).click();
    await expect(notice).toBeHidden();
    await page.reload();
    await expect(page.getByPlaceholder(/Ask the AI to help draft/i)).toBeVisible();
    await expect(page.getByText('AI model changed')).toBeHidden();
  });

  test('keeps the configured model pinned while it is still available', async ({ page, mockAI }) => {
    await mockAI({ availableModels: [CONFIGURED_STANDARD, NEWER_STANDARD, CONFIGURED_ADVANCED, CONFIGURED_LIGHT, EMBEDDING] });
    await page.goto('interview/nda/parties');

    expect(await sendAndCaptureModel(page)).toBe(CONFIGURED_STANDARD);
    await expect(page.getByText('AI model changed')).toBeHidden();
  });
});
