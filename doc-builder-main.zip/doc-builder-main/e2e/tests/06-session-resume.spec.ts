import { test, expect } from '../fixtures/app.fixture';
import { seedSession } from '../helpers/indexeddb';
import { HomePage } from '../pages/home.page';
import { InterviewPage } from '../pages/interview.page';

test.describe('Session Resume', () => {
  test('shows resume banner when a session exists', async ({ page }) => {
    // Seed a session with some answers
    await seedSession(page, {
      id: 'test-resume-session',
      documentTypeId: 'nda',
      answers: { 'parties.disclosing_party_name': 'Resume Corp' },
      currentSection: 'parties',
      sectionConfirmed: {},
    });
    await page.reload();

    const home = new HomePage(page);
    await home.goto();

    // Resume banner should appear
    await expect(home.resumeLink).toBeVisible();
  });

  test('clicking resume returns to the interview with answers intact', async ({ page }) => {
    // Seed a session with a filled field
    await seedSession(page, {
      id: 'test-resume-session',
      documentTypeId: 'nda',
      answers: { 'parties.disclosing_party_name': 'Persistent Corp' },
      currentSection: 'parties',
      sectionConfirmed: {},
    });
    await page.reload();

    const home = new HomePage(page);
    await home.goto();
    await home.resumeLink.click();
    await page.waitForURL(/\/interview\/nda/);

    // Field value should be preserved
    const interview = new InterviewPage(page);
    await interview.waitForSection();
    const field = page.getByLabel('Disclosing party name');
    await expect(field).toHaveValue('Persistent Corp');
  });

  test('session survives page reload during interview', async ({ page }) => {
    // Seed a session and navigate to interview
    await seedSession(page, {
      id: 'test-reload-session',
      documentTypeId: 'nda',
      answers: {} as Record<string, string | number | boolean>,
      currentSection: 'parties',
      sectionConfirmed: {},
    });
    await page.reload();

    const interview = new InterviewPage(page);
    await interview.goto('nda', 'parties');
    await interview.waitForSection();

    // Fill a field
    await interview.fillField('Disclosing party name', 'Reload Test Corp');

    // Wait for debounced save, then reload
    await page.waitForTimeout(500);
    await page.reload();

    // Value should still be there
    await interview.waitForSection();
    const field = page.getByLabel('Disclosing party name');
    await expect(field).toHaveValue('Reload Test Corp');
  });
});
