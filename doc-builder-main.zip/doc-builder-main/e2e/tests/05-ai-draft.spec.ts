import { test, expect } from '../fixtures/ai-mock.fixture';
import { seedSession } from '../helpers/indexeddb';

const EMPTY_NDA_SESSION = {
  id: 'test-session-draft',
  documentTypeId: 'nda',
  answers: {} as Record<string, string | number | boolean>,
  currentSection: 'parties',
  sectionConfirmed: {},
};

test.describe('AI Panel', () => {
  test.beforeEach(async ({ page }) => {
    await seedSession(page, EMPTY_NDA_SESSION);
    await page.reload();
  });

  test('AI panel shows chat input when session is active', async ({ page }) => {
    // Navigate to interview (which activates the session and shows AI panel)
    await page.goto('interview/nda/parties');

    // AI panel should be visible with the chat input. Wait for the input
    // first: until the session loads, the panel's "no session" placeholder
    // also reads "AI Assistant" and the text locator would match twice.
    await expect(page.getByPlaceholder(/Ask the AI to help draft/i)).toBeVisible();
    await expect(page.getByText('AI Assistant')).toBeVisible();
  });

  test('can send a message and receive a streaming response', async ({ page, mockAI }) => {
    await mockAI({
      streamContent: 'I can help you fill out this NDA. Let me draft the key sections.',
    });

    await page.goto('interview/nda/parties');

    // Type in the chat input and send
    const chatInput = page.getByPlaceholder(/Ask the AI to help draft/i);
    await chatInput.fill('Fill out this NDA for Acme Corp and Widget Inc');
    await chatInput.press('Enter');

    // The AI response text should eventually appear
    await expect(page.getByText(/help you fill out this NDA/)).toBeVisible({ timeout: 15_000 });
  });

  test('handles API error gracefully', async ({ page, mockAI }) => {
    await mockAI({ errorCode: 401 });

    await page.goto('interview/nda/parties');

    const chatInput = page.getByPlaceholder(/Ask the AI to help draft/i);
    await chatInput.fill('Fill out the NDA');
    await chatInput.press('Enter');

    // Should show an error message rather than crashing
    await expect(page.getByText(/AI key rejected/)).toBeVisible({ timeout: 10_000 });
  });

  test('handles rate limiting gracefully', async ({ page, mockAI }) => {
    await mockAI({ errorCode: 429 });

    await page.goto('interview/nda/parties');

    const chatInput = page.getByPlaceholder(/Ask the AI to help draft/i);
    await chatInput.fill('Fill out the NDA');
    await chatInput.press('Enter');

    await expect(page.getByText(/AI rate limit/)).toBeVisible({ timeout: 15_000 });
  });
});
