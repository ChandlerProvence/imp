import { test, expect } from '../fixtures/app.fixture';
import { seedSession } from '../helpers/indexeddb';
import { PreviewPage } from '../pages/preview.page';

const APPROVED_NDA_SESSION = {
  id: 'test-session-preview',
  documentTypeId: 'nda',
  answers: {
    'parties.disclosing_party_name': 'Acme Corp',
    'parties.receiving_party_name': 'Widget Inc',
    'parties.is_mutual': true,
    'parties.effective_date': '2025-01-15',
    'terms.duration_months': 12,
    'terms.governing_law': 'Virginia',
    'obligations.obligations_text':
      'Both parties agree to maintain strict confidentiality of all shared information.',
    'obligations.exclusions_text': 'Information that is publicly available.',
  },
  currentSection: 'obligations',
  sectionConfirmed: { parties: true, terms: true, obligations: true },
  reviewApproved: true,
  generated: false,
};

test.describe('Preview Page', () => {
  test.beforeEach(async ({ page }) => {
    await seedSession(page, APPROVED_NDA_SESSION);
    await page.reload();
  });

  test('renders the document with substituted values', async ({ page }) => {
    const preview = new PreviewPage(page);
    await preview.goto();

    // The output template substitutes {{parties.disclosing_party_name}} etc.
    await preview.expectContains('Acme Corp');
    await preview.expectContains('Widget Inc');
    await preview.expectContains('Virginia');
  });

  test('copy markdown button works', async ({ page, context, browserName }) => {
    // Chromium needs clipboard permissions; Firefox allows writes from a click
    // and Playwright rejects these permission names there.
    if (browserName === 'chromium') {
      await context.grantPermissions(['clipboard-read', 'clipboard-write']);
    }

    const preview = new PreviewPage(page);
    await preview.goto();

    await preview.clickCopy();

    // Button text should change to confirm copy
    await expect(page.getByRole('button', { name: /Copied/i })).toBeVisible();
  });

  test('print/save as PDF button is available', async ({ page }) => {
    const preview = new PreviewPage(page);
    await preview.goto();

    // The NDA schema has no .docx template, so only Print is available
    const printButton = page.getByRole('button', { name: /Print.*Save as PDF/i });
    await expect(printButton).toBeVisible();
  });
});
