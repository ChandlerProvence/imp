import { test, expect } from '../fixtures/app.fixture';

test.describe('Edge Cases', () => {
  test('navigating to invalid schema redirects gracefully', async ({ page }) => {
    await page.goto('interview/nonexistent-schema');

    // Should redirect to home or show an error — not a blank page
    await page.waitForURL(/.*/);
    const content = await page.textContent('body');
    expect(content).not.toBe('');
  });

  test('navigating to review with no session shows appropriate state', async ({ page }) => {
    await page.goto('review');

    // Should redirect to home or show an empty/error state — not crash
    const body = page.locator('body');
    await expect(body).not.toBeEmpty();
  });

  test('navigating to preview without approval shows appropriate state', async ({ page }) => {
    await page.goto('preview');

    // Should redirect or show a message — not a blank page
    const body = page.locator('body');
    await expect(body).not.toBeEmpty();
  });

  test('app renders without errors on first load', async ({ page }) => {
    // Listen for console errors
    const errors: string[] = [];
    page.on('console', (msg) => {
      if (msg.type() === 'error') {
        errors.push(msg.text());
      }
    });

    await page.goto('./');
    await page.waitForLoadState('networkidle');

    // Filter out known non-critical errors (e.g., favicon 404)
    const criticalErrors = errors.filter(
      (e) => !e.includes('favicon') && !e.includes('404'),
    );
    expect(criticalErrors).toHaveLength(0);
  });

  test('no unhandled promise rejections on navigation', async ({ page }) => {
    const errors: string[] = [];
    page.on('pageerror', (error) => {
      errors.push(error.message);
    });

    // Navigate through the main routes
    await page.goto('./');
    await page.goto('review');
    await page.goto('preview');
    await page.goto('./');

    expect(errors).toHaveLength(0);
  });
});
