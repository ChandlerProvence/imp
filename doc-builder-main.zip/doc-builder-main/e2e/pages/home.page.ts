import type { Page, Locator } from '@playwright/test';

export class HomePage {
  readonly page: Page;
  readonly heading: Locator;
  readonly resumeBanner: Locator;
  readonly resumeLink: Locator;
  readonly changeRoleButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.heading = page.getByRole('heading', { name: 'Doc Builder' });
    this.resumeBanner = page.locator('.bg-blue-50');
    this.resumeLink = page.getByRole('link', { name: 'Resume →' });
    this.changeRoleButton = page.getByRole('button', { name: 'Change' });
  }

  async goto() {
    await this.page.goto('./');
  }

  /** Select a role from the role picker (e.g. "Contracts / Legal"). */
  async selectRole(roleLabel: string) {
    await this.page.getByRole('button', { name: roleLabel }).click();
  }

  /** Click "Show All Documents" in the role picker. */
  async showAllDocuments() {
    await this.page.getByRole('button', { name: 'Show All Documents' }).click();
  }

  /** Get all visible schema card buttons. */
  getSchemaCards(): Locator {
    return this.page.locator('ul button, .ml-6 button').filter({ hasText: /sections.*fields/ });
  }

  /** Click a schema card by its title text. */
  async clickSchema(title: string) {
    await this.page.getByRole('button', { name: title }).click();
  }

  /** Click the first "Generate full set" button for a document set. */
  async clickGenerateFullSet() {
    await this.page.getByRole('button', { name: 'Generate full set' }).first().click();
  }

  /** Expand a collapsed category by its label. */
  async expandCategory(label: string) {
    await this.page.getByRole('button', { name: label }).click();
  }
}
