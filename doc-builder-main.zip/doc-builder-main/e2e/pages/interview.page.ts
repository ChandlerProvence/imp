import type { Page, Locator } from '@playwright/test';

export class InterviewPage {
  readonly page: Page;
  readonly nextButton: Locator;
  readonly backButton: Locator;
  readonly reviewLink: Locator;

  constructor(page: Page) {
    this.page = page;
    this.nextButton = page.getByRole('button', { name: /Next/ });
    this.backButton = page.getByRole('button', { name: /← Back/ });
    this.reviewLink = page.getByRole('link', { name: 'Review ✓' });
  }

  /** Navigate directly to a section of the interview. */
  async goto(schemaId: string, sectionId?: string) {
    const path = sectionId
      ? `interview/${schemaId}/${sectionId}`
      : `interview/${schemaId}`;
    await this.page.goto(path);
  }

  /** Get the current section title heading (the .text-lg one in the content area, not the sidebar). */
  getSectionTitle(): Locator {
    return this.page.locator('h2.text-lg').first();
  }

  /** Fill a text or freetext field by its label. */
  async fillField(label: string, value: string) {
    const field = this.page.getByLabel(label);
    await field.fill(value);
  }

  /** Fill a number field by its label. */
  async fillNumberField(label: string, value: number) {
    const field = this.page.getByLabel(label);
    await field.fill(String(value));
  }

  /** Fill a date field by its label. */
  async fillDateField(label: string, value: string) {
    const field = this.page.getByLabel(label);
    await field.fill(value);
  }

  /** Select an enum option by the field label and the option text. */
  async selectEnum(label: string, option: string) {
    const select = this.page.getByLabel(label);
    await select.selectOption({ label: option });
  }

  /** Toggle a boolean (checkbox) field by its label. */
  async toggleBoolean(label: string) {
    const checkbox = this.page.getByLabel(label);
    await checkbox.click();
  }

  /** Click the Next button. */
  async clickNext() {
    await this.nextButton.click();
  }

  /** Click the Back button. */
  async clickBack() {
    await this.backButton.click();
  }

  /** Click "Review ✓" to navigate to the review page. */
  async clickReview() {
    await this.reviewLink.click();
  }

  /** Wait for the interview page to be ready (section title visible). */
  async waitForSection() {
    await this.getSectionTitle().waitFor({ state: 'visible' });
  }
}
