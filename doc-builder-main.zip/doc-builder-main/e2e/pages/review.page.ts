import type { Page, Locator } from '@playwright/test';

export class ReviewPage {
  readonly page: Page;
  readonly approveButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.approveButton = page.getByRole('button', { name: 'Approve ✓' });
  }

  async goto() {
    await this.page.goto('review');
  }

  /** Get the rendered value text for a field on the review page. */
  getFieldValue(label: string): Locator {
    // Field values are rendered after their label in the review layout
    return this.page.getByText(label).locator('..').locator('dd, p, span').last();
  }

  /** Get the full page content text (for searching values). */
  getContent(): Locator {
    return this.page.locator('main, [class*="max-w"]').first();
  }

  /** Click the Approve button. */
  async clickApprove() {
    await this.approveButton.click();
  }

  /** Check that the page contains specific text (a filled field value). */
  async expectContains(text: string) {
    await this.page.getByText(text).first().waitFor({ state: 'visible' });
  }
}
