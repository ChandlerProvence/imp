import type { Page, Locator } from '@playwright/test';

export class AiDraftPage {
  readonly page: Page;
  readonly chatInput: Locator;
  readonly sendButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.chatInput = page.getByRole('textbox').last();
    this.sendButton = page.getByRole('button', { name: /send/i }).or(
      page.locator('button[type="submit"]'),
    );
  }

  async goto(schemaId: string) {
    await this.page.goto(`draft/${schemaId}`);
  }

  /** Type a message in the chat input. */
  async enterPrompt(text: string) {
    await this.chatInput.fill(text);
  }

  /** Send the current message. */
  async sendMessage() {
    await this.sendButton.click();
  }

  /** Wait for streaming response to complete (input becomes re-enabled). */
  async waitForResponse() {
    await this.chatInput.waitFor({ state: 'visible' });
    // Wait until the input is no longer disabled (streaming done)
    await this.page.waitForFunction(
      () => {
        const inputs = document.querySelectorAll('textarea, input[type="text"]');
        const last = inputs[inputs.length - 1] as HTMLElement;
        return last && !last.hasAttribute('disabled');
      },
      { timeout: 15_000 },
    );
  }

  /** Get the proposed changes panel content. */
  getProposedChanges(): Locator {
    return this.page.locator('[class*="proposed"], [class*="changes"]').first();
  }

  /** Click "Accept All" on proposed changes. */
  async acceptAll() {
    await this.page.getByRole('button', { name: /accept all/i }).click();
  }
}
