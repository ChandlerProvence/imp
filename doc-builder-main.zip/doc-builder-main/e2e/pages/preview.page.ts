import type { Page, Locator } from '@playwright/test';

export class PreviewPage {
  readonly page: Page;
  readonly downloadButton: Locator;
  readonly copyButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.downloadButton = page.getByRole('button', { name: /Download as Word/ });
    this.copyButton = page.getByRole('button', { name: /Copy as Markdown/ });
  }

  async goto() {
    await this.page.goto('preview');
  }

  /** Get the rendered document content container. */
  getRenderedContent(): Locator {
    return this.page.locator('.prose, [class*="prose"]').first();
  }

  /** Assert that the rendered output contains specific substituted text. */
  async expectContains(text: string) {
    await this.page.getByText(text).first().waitFor({ state: 'visible' });
  }

  /** Click the Download as Word button. */
  async clickDownload() {
    await this.downloadButton.click();
  }

  /** Click the Copy as Markdown button. */
  async clickCopy() {
    await this.copyButton.click();
  }

  /** Get document tabs (for set sessions with multiple documents). */
  getTabs(): Locator {
    return this.page.getByRole('button').filter({ hasText: /^[^←→✓]/ });
  }
}
