import type { Page } from '@playwright/test';

/**
 * Delete all IndexedDB databases to isolate tests.
 * Must be called after navigating to the app origin.
 */
export async function clearAllDatabases(page: Page): Promise<void> {
  await page.evaluate(async () => {
    const dbs = await indexedDB.databases();
    await Promise.all(
      dbs.map(
        (db) =>
          new Promise<void>((resolve, reject) => {
            if (!db.name) return resolve();
            const req = indexedDB.deleteDatabase(db.name);
            req.onsuccess = () => resolve();
            req.onerror = () => reject(req.error);
          }),
      ),
    );
  });
}

export interface SessionSeed {
  id: string;
  documentTypeId: string;
  answers: Record<string, string | number | boolean>;
  fieldMeta?: Record<string, { confidence: number; source: string; aiSetAt: string }>;
  currentSection: string;
  sectionConfirmed: Record<string, boolean>;
  reviewApproved?: boolean;
  generated?: boolean;
  setId?: string;
  schemaIds?: string[];
}

/**
 * Seed a session directly into IndexedDB.
 * The page must already be on the app origin (so we can open the database).
 *
 * Opens the database without specifying a version so it connects at the current
 * version (Dexie multiplies logical versions by 10, so logical v7 = actual v70).
 */
export async function seedSession(page: Page, session: SessionSeed): Promise<void> {
  await page.evaluate(async (s) => {
    const now = new Date();
    return new Promise<void>((resolve, reject) => {
      // Open without version to connect at the existing version
      const req = indexedDB.open('DocBuilderDB');
      req.onsuccess = () => {
        const db = req.result;
        const tx = db.transaction('sessions', 'readwrite');
        tx.objectStore('sessions').put({
          ...s,
          createdAt: now,
          updatedAt: now,
        });
        tx.oncomplete = () => {
          db.close();
          resolve();
        };
        tx.onerror = () => {
          db.close();
          reject(tx.error);
        };
      };
      req.onerror = () => reject(req.error);
    });
  }, session);
}

/**
 * Largest `messageCount` among the conversations stored for a session, or 0.
 * Chat writes are fire-and-forget, so tests that reload or re-list right after
 * a reply should poll this until the expected count has landed.
 */
export async function maxConversationMessageCount(page: Page, sessionId: string): Promise<number> {
  return page.evaluate(async (sid) => {
    return new Promise<number>((resolve, reject) => {
      const req = indexedDB.open('DocBuilderDB');
      req.onsuccess = () => {
        const db = req.result;
        const tx = db.transaction('conversations', 'readonly');
        const getAll = tx.objectStore('conversations').index('sessionId').getAll(sid);
        getAll.onsuccess = () => {
          db.close();
          const counts = (getAll.result as { messageCount?: number }[]).map((c) => c.messageCount ?? 0);
          resolve(counts.length ? Math.max(...counts) : 0);
        };
        getAll.onerror = () => {
          db.close();
          reject(getAll.error);
        };
      };
      req.onerror = () => reject(req.error);
    });
  }, sessionId);
}

/**
 * Read the first session from IndexedDB (for assertions).
 */
export async function getSession(page: Page): Promise<SessionSeed | null> {
  return page.evaluate(async () => {
    return new Promise<unknown>((resolve, reject) => {
      const req = indexedDB.open('DocBuilderDB');
      req.onsuccess = () => {
        const db = req.result;
        const tx = db.transaction('sessions', 'readonly');
        const getAll = tx.objectStore('sessions').getAll();
        getAll.onsuccess = () => {
          db.close();
          resolve(getAll.result[0] ?? null);
        };
        getAll.onerror = () => {
          db.close();
          reject(getAll.error);
        };
      };
      req.onerror = () => reject(req.error);
    });
  }) as Promise<SessionSeed | null>;
}
