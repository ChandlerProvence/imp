/**
 * Build an Anthropic SSE response body that the SDK's streaming parser can consume.
 * Splits text into word-sized tokens to simulate realistic streaming.
 */
export function buildSSEResponse(text: string): string {
  // Split into tokens (roughly by word/punctuation)
  const tokens = text.match(/.{1,20}/g) ?? [text];
  const lines: string[] = [];

  // message_start event
  lines.push(
    `event: message_start`,
    `data: ${JSON.stringify({
      type: "message_start",
      message: {
        id: "msg_test_123",
        type: "message",
        role: "assistant",
        content: [],
        model: "claude-sonnet-5-5-aws-comm-il2",
        stop_reason: null,
        usage: { input_tokens: 100, output_tokens: 0 },
      },
    })}`,
    "",
  );

  // content_block_start event
  lines.push(
    `event: content_block_start`,
    `data: ${JSON.stringify({
      type: "content_block_start",
      index: 0,
      content_block: { type: "text", text: "" },
    })}`,
    "",
  );

  // content_block_delta events (token by token)
  for (const token of tokens) {
    lines.push(
      `event: content_block_delta`,
      `data: ${JSON.stringify({
        type: "content_block_delta",
        index: 0,
        delta: { type: "text_delta", text: token },
      })}`,
      "",
    );
  }

  // content_block_stop
  lines.push(
    `event: content_block_stop`,
    `data: ${JSON.stringify({ type: "content_block_stop", index: 0 })}`,
    "",
  );

  // message_delta (stop_reason + usage)
  lines.push(
    `event: message_delta`,
    `data: ${JSON.stringify({
      type: "message_delta",
      delta: { stop_reason: "end_turn" },
      usage: { output_tokens: tokens.length * 5 },
    })}`,
    "",
  );

  // message_stop
  lines.push(
    `event: message_stop`,
    `data: ${JSON.stringify({ type: "message_stop" })}`,
    "",
  );

  return lines.join("\n") + "\n";
}

/**
 * Build a non-streaming Anthropic JSON response body.
 */
export function buildJsonResponse(content: string, model = 'claude-sonnet-5-5-aws-comm-il2'): string {
  return JSON.stringify({
    id: "msg_test_123",
    type: "message",
    role: "assistant",
    content: [{ type: "text", text: content }],
    model,
    stop_reason: "end_turn",
    usage: {
      input_tokens: 100,
      output_tokens: 50,
    },
  });
}
