import { test as base } from './app.fixture';
import { buildSSEResponse, buildJsonResponse } from '../helpers/sse';

export interface AIMockConfig {
  /** Text content for streaming responses. */
  streamContent?: string;
  /** Text content for non-streaming responses. */
  jsonContent?: string;
  /** Simulate error status codes (401, 429, 500). */
  errorCode?: number;
  /** Error message in the mocked error body (e.g. "prompt is too long"). */
  errorMessage?: string;
  /** Simulate a network failure (connection refused / DNS / VPN down). */
  networkError?: boolean;
  /** Artificial delay in ms before responding. */
  latency?: number;
  /**
   * Model IDs returned by GET /v1/models. Unaffected by `errorCode` so
   * discovery can succeed while chat requests fail. When omitted, discovery
   * stays unavailable (see app.fixture) and the app uses configured models.
   * Reload the page after `mockAI` for startup discovery to pick this up.
   */
  availableModels?: string[];
  /** Raw `data` entries for GET /model/info (cost/context metadata). */
  modelInfo?: { model_name: string; model_info: Record<string, number> }[];
}

const DEFAULT_STREAM_CONTENT = 'This is a test AI response.';
const DEFAULT_JSON_CONTENT = '{"proposed_changes": []}';

/**
 * Fixture that intercepts all AI API calls at the network level.
 * Matches both the Anthropic SDK endpoint (/v1/messages) and
 * the OpenAI-compatible endpoint (/v1/chat/completions).
 * Use `mockAI` in your test to configure responses.
 */
export const test = base.extend<{ mockAI: (config?: AIMockConfig) => Promise<void> }>({
  mockAI: async ({ page }, use) => {
    const setupMock = async (config: AIMockConfig = {}) => {
      const {
        streamContent = DEFAULT_STREAM_CONTENT,
        jsonContent = DEFAULT_JSON_CONTENT,
        errorCode,
        errorMessage,
        networkError,
        latency = 0,
        availableModels,
        modelInfo,
      } = config;

      const handler = async (route: any) => {
        if (latency > 0) {
          await new Promise((r) => setTimeout(r, latency));
        }

        if (networkError) {
          await route.abort('failed');
          return;
        }

        if (errorCode) {
          await route.fulfill({
            status: errorCode,
            contentType: 'application/json',
            body: JSON.stringify({
              type: 'error',
              error: { type: 'authentication_error', message: errorMessage ?? `Mock error ${errorCode}` },
            }),
          });
          return;
        }

        const request = route.request();
        const body = JSON.parse(request.postData() ?? '{}');

        if (body.stream) {
          await route.fulfill({
            status: 200,
            headers: {
              'Content-Type': 'text/event-stream',
              'Cache-Control': 'no-cache',
              Connection: 'keep-alive',
            },
            body: buildSSEResponse(streamContent),
          });
        } else {
          await route.fulfill({
            status: 200,
            contentType: 'application/json',
            body: buildJsonResponse(jsonContent),
          });
        }
      };

      // Intercept all AI API calls (Anthropic /v1/messages and OpenAI /v1/chat/completions)
      await page.route('**/v1/messages', handler);
      await page.route('**/v1/chat/completions', handler);
      // Also catch the direct production URL pattern
      await page.route('https://lmg.leadai.leidos.com/**', handler);
      await page.route('https://lmg-cui.leadai.leidos.com/**', handler);

      // Model discovery — registered last so it wins over the catch-alls above
      if (availableModels) {
        await page.route('**/v1/models', (route) =>
          route.fulfill({
            status: 200,
            contentType: 'application/json',
            body: JSON.stringify({ object: 'list', data: availableModels.map((id) => ({ id, object: 'model' })) }),
          }),
        );
        await page.route('**/model/info', (route) =>
          modelInfo
            ? route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ data: modelInfo }) })
            : route.fulfill({ status: 200, contentType: 'application/json', body: '{}' }), // no cost data
        );
      }
    };

    await use(setupMock);
  },
});

export { expect } from '@playwright/test';
