import { test as base } from '@playwright/test';
import { clearAllDatabases } from '../helpers/indexeddb';

/**
 * Base fixture for all E2E tests.
 * Clears IndexedDB and localStorage, seeds required localStorage keys,
 * and navigates to the home page ready for interaction.
 */
export const test = base.extend<{ cleanApp: void }>({
  cleanApp: [
    async ({ page }, use) => {
      // Navigate to app origin first (required to access its IndexedDB)
      // Use './' (relative) so Playwright prepends the baseURL path (/doc-builder/)
      await page.goto('./');
      await page.waitForLoadState('domcontentloaded');

      // Clear all persisted state
      await clearAllDatabases(page);
      await page.evaluate(() => localStorage.clear());

      // Seed required localStorage values
      await page.evaluate(() => {
        localStorage.setItem('doc-builder:litellm-api-key', 'test-key-e2e');
        localStorage.setItem('doc-builder:user-role', 'contracts');
      });

      // Model discovery runs on startup once a key exists. Answer it with a
      // body that has no model list, so discovery is a silent no-op (the app
      // keeps its configured models) instead of the dev proxy reaching the
      // real LiteLLM host. A 200 avoids a "Failed to load resource" console
      // error. `mockAI({ availableModels })` registers a later route that wins.
      const unavailable = (route: import('@playwright/test').Route) =>
        route.fulfill({ status: 200, contentType: 'application/json', body: '{}' });
      await page.route('**/v1/models', unavailable);
      await page.route('**/model/info', unavailable);

      // Reload so the app picks up the seeded state
      await page.reload();
      await page.waitForLoadState('networkidle');

      await use();
    },
    { auto: true },
  ],
});

export { expect } from '@playwright/test';
