import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { renderHook, act, waitFor } from "@testing-library/react";
import { useDocumentManager } from "./useDocumentManager";
import { db } from "../db/dexie";
import { getWriteError, resetWriteStatus } from "../db/writeStatus";
import { apiKeyStorageKey } from "../ai/endpoints";
import type { DocumentSchema } from "../schemas/types";

// Track which endpoints resolveImages was called with
let resolveImagesCalls: { endpoint: string; fileName: string }[] = [];

vi.mock("../extraction/parseFileEnhanced", () => ({
  parseFileStructure: vi.fn(async (file: File) => {
    // .docx files with "image" in the name simulate embedded images
    const isDocxWithImages = file.name.endsWith(".docx") && file.name.includes("image");
    // .png/.jpg files are standalone images
    const isStandalone = /\.(png|jpg|jpeg|gif|webp|tiff)$/i.test(file.name);
    // headerFooterText: files with "header-cui" in name get a CUI header
    const headerFooterText = file.name.includes("header-cui")
      ? "CONTROLLED UNCLASSIFIED INFORMATION"
      : "";
    const text = isStandalone
      ? "[IMAGE_0]"
      : isDocxWithImages
        ? `body text of ${file.name} [IMAGE_0] [IMAGE_1]`
        : `content of ${file.name} `.repeat(Math.max(1, Math.ceil(file.size / 24)));
    const images = isStandalone
      ? [{ placeholder: "[IMAGE_0]", dataUrl: "data:image/png;base64,abc" }]
      : isDocxWithImages
        ? [
            { placeholder: "[IMAGE_0]", dataUrl: "data:image/png;base64,img0" },
            { placeholder: "[IMAGE_1]", dataUrl: "data:image/png;base64,img1" },
          ]
        : [];
    return { text, headerFooterText, images, standaloneImage: isStandalone };
  }),
  resolveImages: vi.fn(async ({ parsed, fileName, endpoint }: any) => {
    resolveImagesCalls.push({ endpoint, fileName });
    if (parsed.standaloneImage) {
      return `Extracted text from standalone image ${fileName}`;
    }
    let text = parsed.text as string;
    for (const img of parsed.images) {
      text = text.replace(img.placeholder, `[Image: description of ${img.placeholder}]`);
    }
    return text;
  }),
}));

vi.mock("../ai/cuiDetection", async () => {
  const actual = await vi.importActual<typeof import("../ai/cuiDetection")>("../ai/cuiDetection");
  return {
    ...actual,
    checkForCui: vi.fn(async () => null),
    // Use the real regexCuiPreScreen so quarantine gating works
  };
});

vi.mock("../ai/embeddings", async () => {
  const actual = await vi.importActual<typeof import("../ai/embeddings")>("../ai/embeddings");
  return {
    ...actual,
    embedAndStoreDocument: vi.fn(async ({ docId }: { docId: string }) => {
      embedCalls.push(docId);
      return [{ text: "chunk", docId, docTitle: "t", index: 0, embedding: [0, 0] }];
    }),
  };
});

import { checkForCui } from "../ai/cuiDetection";
import { embedAndStoreDocument } from "../ai/embeddings";
import { resolveImages } from "../extraction/parseFileEnhanced";

let embedCalls: string[] = [];

const schema: DocumentSchema = { id: "test-schema", title: "Test", category: "fms", sections: [] } as any;

function makeFile(name: string, size = 20000) {
  // Content derives from the name so differently named files hash differently
  // (re-uploads are matched by content hash).
  const bytes = new Uint8Array(size);
  bytes.set(new TextEncoder().encode(name).subarray(0, size));
  return new File([bytes], name, { type: "application/pdf" });
}

function setupFetchMock() {
  vi.stubGlobal("fetch", vi.fn(async () => ({ ok: false, json: async () => ({}) })));
}

/** Let the manifest fetch settle. Its state update re-runs the parse effect,
 *  which cancels uploads still in flight (hashing makes that window wider). */
async function settleManifest(): Promise<void> {
  await waitFor(() => expect(fetch).toHaveBeenCalled());
  await act(async () => {
    await new Promise((r) => setTimeout(r, 0));
  });
}

async function renderManager(activeEndpoint: "cui" | "non-cui" = "non-cui") {
  const setActiveEndpoint = vi.fn();
  const { result, rerender } = renderHook(
    (props: { activeEndpoint: "cui" | "non-cui" }) =>
      useDocumentManager({ schema, activeEndpoint: props.activeEndpoint, setActiveEndpoint }),
    { initialProps: { activeEndpoint } },
  );
  await settleManifest();
  return { result, rerender, setActiveEndpoint };
}

describe("useDocumentManager CUI attach flow", () => {
  beforeEach(async () => {
    resolveImagesCalls = [];
    embedCalls = [];
    vi.clearAllMocks();
    setupFetchMock();
    localStorage.clear();
    await db.uploadedDocuments.clear();
    await db.embeddingChunks.clear();
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it("does not embed a clean upload until requestAttach is called", async () => {
    const { result } = await renderManager();

    act(() => {
      result.current.setShowDocPicker(true);
    });
    act(() => {
      result.current.setFiles([makeFile("clean.pdf")]);
    });

    await waitFor(() => expect(result.current.draftDocIds.size).toBe(1));
    await waitFor(() => expect(result.current.attachBlocked).toBe(false));

    expect(embedAndStoreDocument).not.toHaveBeenCalled();
    expect(result.current.selectedDocIds.size).toBe(0);

    act(() => {
      result.current.requestAttach();
    });

    await waitFor(() => expect(result.current.selectedDocIds.size).toBe(1));
    await waitFor(() => expect(embedAndStoreDocument).toHaveBeenCalledTimes(1));
  });

  it("opens the CUI warning on attach when a document is flagged, and cancel keeps the draft intact", async () => {
    (checkForCui as any).mockResolvedValueOnce({
      isCui: true,
      confidence: "high",
      reason: "CUI marking found",
      method: "regex",
      markers: ["CUI"],
    });

    const { result } = await renderManager();

    act(() => result.current.setShowDocPicker(true));
    act(() => result.current.setFiles([makeFile("flagged.pdf")]));

    await waitFor(() => expect(result.current.draftDocIds.size).toBe(1));
    await waitFor(() => expect(result.current.attachBlocked).toBe(false));

    act(() => result.current.requestAttach());

    expect(result.current.showCuiWarning).toBe(true);
    expect(result.current.flaggedDraftDocs.length).toBe(1);
    expect(result.current.selectedDocIds.size).toBe(0);
    expect(embedAndStoreDocument).not.toHaveBeenCalled();
    expect(result.current.buildCombinedDocumentText()).toBeUndefined();

    act(() => result.current.cancelCuiWarning());

    expect(result.current.showCuiWarning).toBe(false);
    expect(result.current.showDocPicker).toBe(true);
    expect(result.current.draftDocIds.size).toBe(1);
  });

  it("affirmNotCuiAndAttach marks the doc not-cui and embeds it", async () => {
    (checkForCui as any).mockResolvedValueOnce({
      isCui: true,
      confidence: "high",
      reason: "CUI marking found",
      method: "regex",
      markers: ["CUI"],
    });

    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    act(() => result.current.setFiles([makeFile("flagged.pdf")]));
    await waitFor(() => expect(result.current.attachBlocked).toBe(false));
    act(() => result.current.requestAttach());
    expect(result.current.showCuiWarning).toBe(true);

    act(() => result.current.affirmNotCuiAndAttach());

    await waitFor(() => expect(result.current.selectedDocIds.size).toBe(1));
    await waitFor(() => expect(embedAndStoreDocument).toHaveBeenCalledTimes(1));
    const [id] = result.current.selectedDocIds;
    const saved = await db.uploadedDocuments.get(id);
    expect(saved?.cuiStatus).toBe("not-cui");
  });

  it("reports a failed CUI status write instead of leaving an unhandled rejection", async () => {
    (checkForCui as any).mockResolvedValueOnce({
      isCui: true,
      confidence: "high",
      reason: "CUI marking found",
      method: "regex",
      markers: ["CUI"],
    });
    resetWriteStatus();
    vi.spyOn(console, "error").mockImplementation(() => {});

    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    act(() => result.current.setFiles([makeFile("flagged.pdf")]));
    await waitFor(() => expect(result.current.attachBlocked).toBe(false));
    act(() => result.current.requestAttach());

    vi.spyOn(db.uploadedDocuments, "update").mockRejectedValueOnce(new Error("QuotaExceededError"));
    act(() => result.current.affirmNotCuiAndAttach());

    await waitFor(() => expect(getWriteError()).not.toBeNull());
    resetWriteStatus();
  });

  it("switchToCuiAndAttach calls setActiveEndpoint, marks cui, and embeds", async () => {
    (checkForCui as any).mockResolvedValueOnce({
      isCui: true,
      confidence: "high",
      reason: "CUI marking found",
      method: "regex",
      markers: ["CUI"],
    });

    const { result, setActiveEndpoint } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    act(() => result.current.setFiles([makeFile("flagged.pdf")]));
    await waitFor(() => expect(result.current.attachBlocked).toBe(false));
    act(() => result.current.requestAttach());
    expect(result.current.showCuiWarning).toBe(true);

    act(() => result.current.switchToCuiAndAttach());

    expect(setActiveEndpoint).toHaveBeenCalledWith("cui");
    await waitFor(() => expect(result.current.selectedDocIds.size).toBe(1));
    await waitFor(() => expect(embedAndStoreDocument).toHaveBeenCalledTimes(1));
    const [id] = result.current.selectedDocIds;
    const saved = await db.uploadedDocuments.get(id);
    expect(saved?.cuiStatus).toBe("cui");
  });

  it("marks scan errors as scan-error with the full message, and flags them", async () => {
    (checkForCui as any).mockResolvedValueOnce({ error: true, message: "AI CUI scan failed: 503 Service Unavailable" });

    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    act(() => result.current.setFiles([makeFile("errored.pdf")]));

    await waitFor(() => expect(result.current.draftDocIds.size).toBe(1));
    await waitFor(() => expect(result.current.attachBlocked).toBe(false));

    const [id] = result.current.draftDocIds;
    const saved = await db.uploadedDocuments.get(id);
    expect(saved?.cuiStatus).toBe("scan-error");
    expect(saved?.cuiScanError).toBe("AI CUI scan failed: 503 Service Unavailable");

    act(() => result.current.requestAttach());
    expect(result.current.showCuiWarning).toBe(true);
    expect(result.current.flaggedDraftDocs[0].cuiScanError).toBe("AI CUI scan failed: 503 Service Unavailable");
  });

  it("skips the CUI scan in CUI mode and saves cui status directly", async () => {
    const { result } = await renderManager("cui");
    act(() => result.current.setShowDocPicker(true));
    act(() => result.current.setFiles([makeFile("doc.pdf")]));

    await waitFor(() => expect(result.current.draftDocIds.size).toBe(1));
    expect(checkForCui).not.toHaveBeenCalled();

    const [id] = result.current.draftDocIds;
    const saved = await db.uploadedDocuments.get(id);
    expect(saved?.cuiStatus).toBe("cui");

    act(() => result.current.requestAttach());
    await waitFor(() => expect(result.current.selectedDocIds.size).toBe(1));
  });

  it.each(["clean", "not-cui"] as const)(
    "attaching a %s Proprietary doc in CUI mode keeps its status and leaves it usable in Proprietary",
    async (status) => {
      const id = crypto.randomUUID();
      await db.uploadedDocuments.add({
        id,
        fileName: "cleared.pdf",
        mimeType: "application/pdf",
        fileSize: 100,
        textContent: "cleared text",
        charCount: 12,
        category: "fms",
        uploadEndpoint: "non-cui",
        cuiStatus: status,
        cuiScannedWithAi: true,
        createdAt: new Date().toISOString(),
        lastUsedAt: new Date().toISOString(),
      });

      const { result, rerender } = await renderManager("cui");
      act(() => result.current.setShowDocPicker(true));
      await waitFor(() => expect(result.current.availableDocs.some((d) => d.id === id)).toBe(true));
      act(() => result.current.toggleDraftDoc(id));
      act(() => result.current.requestAttach());
      await waitFor(() => expect(result.current.selectedDocIds.has(id)).toBe(true));

      expect((await db.uploadedDocuments.get(id))?.cuiStatus).toBe(status);
      expect(result.current.availableDocs.find((d) => d.id === id)?.savedDoc?.cuiStatus).toBe(status);

      rerender({ activeEndpoint: "non-cui" });
      expect(result.current.attachmentErrors.has(id)).toBe(false);
      expect(result.current.hiddenCuiDocCount).toBe(0);
      expect(result.current.availableDocs.some((d) => d.id === id)).toBe(true);
    },
  );

  it("attaching a pending library doc in CUI mode marks it cui", async () => {
    const id = crypto.randomUUID();
    await db.uploadedDocuments.add({
      id,
      fileName: "unscanned.pdf",
      mimeType: "application/pdf",
      fileSize: 100,
      textContent: "unscanned text",
      charCount: 14,
      category: "fms",
      uploadEndpoint: "non-cui",
      cuiStatus: "pending",
      createdAt: new Date().toISOString(),
      lastUsedAt: new Date().toISOString(),
    });

    const { result } = await renderManager("cui");
    act(() => result.current.setShowDocPicker(true));
    await waitFor(() => expect(result.current.availableDocs.some((d) => d.id === id)).toBe(true));
    act(() => result.current.toggleDraftDoc(id));
    act(() => result.current.requestAttach());
    await waitFor(() => expect(result.current.selectedDocIds.has(id)).toBe(true));

    await waitFor(async () => expect((await db.uploadedDocuments.get(id))?.cuiStatus).toBe("cui"));
  });

  it("attachBlocked is true while a scan is pending", async () => {
    let resolveScan!: (v: any) => void;
    (checkForCui as any).mockImplementationOnce(
      () => new Promise((resolve) => { resolveScan = resolve; }),
    );

    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    act(() => result.current.setFiles([makeFile("slow.pdf")]));

    await waitFor(() => expect(result.current.scanningDocIds.size).toBe(1));
    expect(result.current.attachBlocked).toBe(true);

    act(() => resolveScan(null));

    await waitFor(() => expect(result.current.attachBlocked).toBe(false));
  });

  it("closePickerDiscard leaves selectedDocIds unchanged but keeps the doc in the library", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    act(() => result.current.setFiles([makeFile("discard-me.pdf")]));
    await waitFor(() => expect(result.current.draftDocIds.size).toBe(1));

    act(() => result.current.closePickerDiscard());

    expect(result.current.selectedDocIds.size).toBe(0);
    expect(result.current.showDocPicker).toBe(false);
    const saved = await db.uploadedDocuments.toArray();
    expect(saved.some((d) => d.fileName === "discard-me.pdf")).toBe(true);
  });

  it("flags an attached cui doc as an attachment error in IL2 and clears it on removal", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    act(() => result.current.setFiles([makeFile("already-cui.pdf", 500)]));
    await waitFor(() => expect(result.current.draftDocIds.size).toBe(1));
    const [id] = result.current.draftDocIds;
    await db.uploadedDocuments.update(id, { cuiStatus: "cui" });

    act(() => result.current.requestAttach());
    await waitFor(() => expect(result.current.selectedDocIds.size).toBe(1));

    await waitFor(() => expect(result.current.attachmentErrors.has(id)).toBe(true));
    expect(result.current.docsReady).toBe(false);

    act(() => result.current.handleRemoveDocument(id));

    expect(result.current.attachmentErrors.has(id)).toBe(false);
    expect(result.current.docsReady).toBe(true);
  });

  it("surfaces an embedding rejection as a full-message attachment error", async () => {
    (embedAndStoreDocument as any).mockRejectedValueOnce(new Error("Embeddings endpoint returned 500"));

    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    act(() => result.current.setFiles([makeFile("big.pdf", 20000)]));
    await waitFor(() => expect(result.current.attachBlocked).toBe(false));

    act(() => result.current.requestAttach());

    await waitFor(() => expect(result.current.selectedDocIds.size).toBe(1));
    const [id] = result.current.selectedDocIds;

    await waitFor(() => expect(result.current.attachmentErrors.get(id)?.detail).toContain("Embeddings endpoint returned 500"));
    expect(result.current.docsReady).toBe(false);
  });

  it("embeds two large docs concurrently on attach", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    act(() => result.current.setFiles([makeFile("a.pdf", 20000), makeFile("b.pdf", 20000)]));
    await waitFor(() => expect(result.current.draftDocIds.size).toBe(2));
    await waitFor(() => expect(result.current.attachBlocked).toBe(false));

    act(() => result.current.requestAttach());

    await waitFor(() => expect(embedCalls.length).toBe(2));
  });

  it("scans a pending library doc when draft-checked", async () => {
    const saved = await db.uploadedDocuments.add({
      id: crypto.randomUUID(),
      fileName: "library.pdf",
      mimeType: "application/pdf",
      fileSize: 15000,
      textContent: "x".repeat(15000),
      charCount: 15000,
      category: "fms",
      cuiStatus: "pending",
      createdAt: new Date().toISOString(),
      lastUsedAt: new Date().toISOString(),
    } as any);

    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    await waitFor(() => expect(result.current.availableDocs.some((d) => d.id === saved)).toBe(true));

    act(() => result.current.toggleDraftDoc(saved as unknown as string));

    await waitFor(() => expect(checkForCui).toHaveBeenCalled());
  });

  it("routes vision through cui with a CUI key in IL2", async () => {
    localStorage.setItem(apiKeyStorageKey("cui"), "test-cui-key");
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    act(() => result.current.setFiles([new File([new Uint8Array(500)], "image-test.docx", { type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" })]));
    await waitFor(() => expect(result.current.draftDocIds.size).toBe(1));
    expect(resolveImagesCalls.length).toBe(1);
    expect(resolveImagesCalls[0].endpoint).toBe("cui");
  });

  // ---------------------------------------------------------------------------
  // New tests: image quarantine and IL2 image extraction
  // ---------------------------------------------------------------------------

  it("quarantines images when no CUI key and body has a CUI marker", async () => {
    // No CUI key — file name simulates a docx with images
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));

    // Manually create a file with CUI text in body. We need the mock to return
    // text with CUI markers and images. Use a custom mock for this test.
    const { parseFileStructure } = await import("../extraction/parseFileEnhanced");
    (parseFileStructure as any).mockResolvedValueOnce({
      text: "CUI//SP-PRVCY Document content [IMAGE_0]",
      headerFooterText: "",
      images: [{ placeholder: "[IMAGE_0]", dataUrl: "data:image/png;base64,abc" }],
      standaloneImage: false,
    });

    act(() => result.current.setFiles([makeFile("cui-doc-image.docx")]));
    await waitFor(() => expect(result.current.draftDocIds.size).toBe(1));
    await waitFor(() => expect(result.current.attachBlocked).toBe(false));

    // resolveImages should NOT have been called (quarantined)
    expect(resolveImagesCalls.length).toBe(0);

    const [id] = result.current.draftDocIds;
    const saved = await db.uploadedDocuments.get(id);
    expect(saved?.cuiStatus).toBe("flagged");
    expect(saved?.quarantinedImages).toHaveLength(1);
    expect(saved?.textContent).toContain("[Image quarantined");
  });

  it("quarantines when CUI marker only in header/footer (not body)", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));

    const { parseFileStructure } = await import("../extraction/parseFileEnhanced");
    (parseFileStructure as any).mockResolvedValueOnce({
      text: "Clean body text [IMAGE_0]",
      headerFooterText: "CONTROLLED UNCLASSIFIED INFORMATION",
      images: [{ placeholder: "[IMAGE_0]", dataUrl: "data:image/png;base64,abc" }],
      standaloneImage: false,
    });

    act(() => result.current.setFiles([makeFile("header-marked.docx")]));
    await waitFor(() => expect(result.current.draftDocIds.size).toBe(1));
    await waitFor(() => expect(result.current.attachBlocked).toBe(false));

    expect(resolveImagesCalls.length).toBe(0);

    const [id] = result.current.draftDocIds;
    const saved = await db.uploadedDocuments.get(id);
    expect(saved?.cuiStatus).toBe("flagged");
    expect(saved?.quarantinedImages).toHaveLength(1);
  });

  it("resolves images through IL2 when no CUI key and body is clean", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));

    const { parseFileStructure } = await import("../extraction/parseFileEnhanced");
    (parseFileStructure as any).mockResolvedValueOnce({
      text: "Clean document [IMAGE_0]",
      headerFooterText: "",
      images: [{ placeholder: "[IMAGE_0]", dataUrl: "data:image/png;base64,abc" }],
      standaloneImage: false,
    });

    act(() => result.current.setFiles([makeFile("clean-image.docx")]));
    await waitFor(() => expect(result.current.draftDocIds.size).toBe(1));
    await waitFor(() => expect(result.current.attachBlocked).toBe(false));

    // resolveImages was called with non-cui endpoint
    expect(resolveImagesCalls.length).toBe(1);
    expect(resolveImagesCalls[0].endpoint).toBe("non-cui");

    const [id] = result.current.draftDocIds;
    const saved = await db.uploadedDocuments.get(id);
    expect(saved?.quarantinedImages).toBeUndefined();
    // checkForCui should have been called (post-image scan)
    await waitFor(() => expect(checkForCui).toHaveBeenCalled());
  });

  it("routes vision through cui when CUI key is present in IL2", async () => {
    localStorage.setItem(apiKeyStorageKey("cui"), "test-key");
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));

    const { parseFileStructure } = await import("../extraction/parseFileEnhanced");
    (parseFileStructure as any).mockResolvedValueOnce({
      text: "Document [IMAGE_0]",
      headerFooterText: "",
      images: [{ placeholder: "[IMAGE_0]", dataUrl: "data:image/png;base64,abc" }],
      standaloneImage: false,
    });

    act(() => result.current.setFiles([makeFile("with-key.docx")]));
    await waitFor(() => expect(result.current.draftDocIds.size).toBe(1));

    expect(resolveImagesCalls.length).toBe(1);
    expect(resolveImagesCalls[0].endpoint).toBe("cui");

    const [id] = result.current.draftDocIds;
    const saved = await db.uploadedDocuments.get(id);
    expect(saved?.quarantinedImages).toBeUndefined();
  });

  it("affirmNotCuiAndAttach releases quarantine through non-cui, clears quarantinedImages, and embeds", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));

    const { parseFileStructure } = await import("../extraction/parseFileEnhanced");
    (parseFileStructure as any).mockResolvedValueOnce({
      text: "CUI//SP-PRVCY content [IMAGE_0]",
      headerFooterText: "",
      images: [{ placeholder: "[IMAGE_0]", dataUrl: "data:image/png;base64,abc" }],
      standaloneImage: false,
    });

    act(() => result.current.setFiles([makeFile("quarantined.docx", 500)]));
    await waitFor(() => expect(result.current.draftDocIds.size).toBe(1));
    await waitFor(() => expect(result.current.attachBlocked).toBe(false));

    // Should be flagged and quarantined
    const [id] = result.current.draftDocIds;
    let saved = await db.uploadedDocuments.get(id);
    expect(saved?.cuiStatus).toBe("flagged");
    expect(saved?.quarantinedImages).toHaveLength(1);

    // Request attach → shows warning
    act(() => result.current.requestAttach());
    expect(result.current.showCuiWarning).toBe(true);

    // Clear previous calls
    resolveImagesCalls = [];

    // Affirm not CUI
    act(() => result.current.affirmNotCuiAndAttach());
    await waitFor(() => expect(result.current.selectedDocIds.size).toBe(1));

    // resolveImages was called with non-cui
    await waitFor(() => expect(resolveImagesCalls.length).toBe(1));
    expect(resolveImagesCalls[0].endpoint).toBe("non-cui");

    // Quarantined images should be cleared in DB
    saved = await db.uploadedDocuments.get(id);
    expect(saved?.cuiStatus).toBe("not-cui");
    expect(saved?.quarantinedImages).toBeUndefined();

    // Text should be updated (the resolved content from the mock)
    expect(saved?.textContent).toContain("[Image: description of");
  });

  it("switchToCuiAndAttach releases quarantine through cui", async () => {
    // No CUI key — so the quarantine gate fires
    const { result, setActiveEndpoint } = await renderManager();
    act(() => result.current.setShowDocPicker(true));

    const { parseFileStructure } = await import("../extraction/parseFileEnhanced");
    (parseFileStructure as any).mockResolvedValueOnce({
      text: "CUI//SP-PRVCY content [IMAGE_0]",
      headerFooterText: "",
      images: [{ placeholder: "[IMAGE_0]", dataUrl: "data:image/png;base64,abc" }],
      standaloneImage: false,
    });

    act(() => result.current.setFiles([makeFile("quarantined-switch.docx", 500)]));
    await waitFor(() => expect(result.current.draftDocIds.size).toBe(1));
    await waitFor(() => expect(result.current.attachBlocked).toBe(false));

    act(() => result.current.requestAttach());
    expect(result.current.showCuiWarning).toBe(true);

    resolveImagesCalls = [];
    act(() => result.current.switchToCuiAndAttach());

    expect(setActiveEndpoint).toHaveBeenCalledWith("cui");
    await waitFor(() => expect(result.current.selectedDocIds.size).toBe(1));
    await waitFor(() => expect(resolveImagesCalls.length).toBe(1));
    expect(resolveImagesCalls[0].endpoint).toBe("cui");
  });

  it("conversion failure on release shows as attachment error", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));

    const { parseFileStructure } = await import("../extraction/parseFileEnhanced");
    (parseFileStructure as any).mockResolvedValueOnce({
      text: "CUI//SP-PRVCY content [IMAGE_0]",
      headerFooterText: "",
      images: [{ placeholder: "[IMAGE_0]", dataUrl: "data:image/png;base64,abc" }],
      standaloneImage: false,
    });

    act(() => result.current.setFiles([makeFile("fail-release.docx", 500)]));
    await waitFor(() => expect(result.current.draftDocIds.size).toBe(1));
    await waitFor(() => expect(result.current.attachBlocked).toBe(false));

    // Make resolveImages reject on the release call
    (resolveImages as any).mockRejectedValueOnce(new Error("Vision API unavailable"));

    act(() => result.current.requestAttach());
    act(() => result.current.affirmNotCuiAndAttach());

    await waitFor(() => expect(result.current.selectedDocIds.size).toBe(1));
    const [id] = result.current.selectedDocIds;

    await waitFor(() => expect(result.current.attachmentErrors.get(id)?.detail).toContain("Vision API unavailable"));
    expect(result.current.docsReady).toBe(false);
  });

  it("re-upload of a not-cui doc resets status to pending and scans again", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));

    // First upload
    act(() => result.current.setFiles([makeFile("reupload.pdf")]));
    await waitFor(() => expect(result.current.draftDocIds.size).toBe(1));
    await waitFor(() => expect(result.current.attachBlocked).toBe(false));

    const [id] = result.current.draftDocIds;
    // Mark it not-cui
    await db.uploadedDocuments.update(id, { cuiStatus: "not-cui" });

    // Clear mocks
    vi.mocked(checkForCui).mockClear();

    // Re-upload same file (same bytes = content-hash match → replaces content)
    act(() => result.current.setFiles([makeFile("reupload.pdf")]));
    await waitFor(() => {
      const saved = db.uploadedDocuments.get(id);
      return saved;
    });

    // The re-upload should have reset cuiStatus and triggered a scan
    await waitFor(() => {
      const doc = result.current.availableDocs.find((d) => d.id === id);
      return expect(doc?.savedDoc?.cuiStatus).not.toBe("not-cui");
    });

    await waitFor(() => expect(checkForCui).toHaveBeenCalled());
  });

  it("a different file with the same name and size is saved as a separate record", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));

    const bytes = new Uint8Array(20000);
    act(() => result.current.setFiles([new File([bytes], "same.pdf", { type: "application/pdf" })]));
    await waitFor(() => expect(result.current.draftDocIds.size).toBe(1));

    const other = bytes.slice();
    other[0] = 1;
    act(() => result.current.setFiles([new File([other], "same.pdf", { type: "application/pdf" })]));
    await waitFor(() => expect(result.current.draftDocIds.size).toBe(2));

    const saved = await db.uploadedDocuments.toArray();
    expect(saved).toHaveLength(2);
    expect(new Set(saved.map((d) => d.contentHash)).size).toBe(2);
  });

  it("re-upload of an attached doc removes it from selectedDocIds", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));

    // Upload and attach
    act(() => result.current.setFiles([makeFile("attached.pdf")]));
    await waitFor(() => expect(result.current.draftDocIds.size).toBe(1));
    await waitFor(() => expect(result.current.attachBlocked).toBe(false));
    act(() => result.current.requestAttach());
    await waitFor(() => expect(result.current.selectedDocIds.size).toBe(1));
    const [id] = result.current.selectedDocIds;

    // Re-open picker and re-upload
    act(() => result.current.setShowDocPicker(true));
    act(() => result.current.setFiles([makeFile("attached.pdf")]));

    // The re-upload should remove the doc from committed selection
    await waitFor(() => expect(result.current.selectedDocIds.has(id)).toBe(false));
  });

  it("saveUploadedDocument dedup keeps id and createdAt, replaces textContent, resets cuiStatus", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));

    act(() => result.current.setFiles([makeFile("dedup.pdf")]));
    await waitFor(() => expect(result.current.draftDocIds.size).toBe(1));
    const [id] = result.current.draftDocIds;

    const original = await db.uploadedDocuments.get(id);
    const originalCreatedAt = original?.createdAt;

    // Mark not-cui and add detection data
    await db.uploadedDocuments.update(id, {
      cuiStatus: "not-cui",
      cuiDetection: { isCui: false, confidence: "high", reason: "clean", method: "regex", markers: [] },
      cuiScannedWithAi: true,
      quarantinedImages: [{ placeholder: "test", dataUrl: "data:image/png;base64,x" }],
    });

    // Re-upload
    act(() => result.current.setFiles([makeFile("dedup.pdf")]));
    await waitFor(async () => {
      const saved = await db.uploadedDocuments.get(id);
      // cuiStatus should be reset (not "not-cui" anymore)
      return expect(saved?.cuiStatus).not.toBe("not-cui");
    });

    const reUploaded = await db.uploadedDocuments.get(id);
    expect(reUploaded?.id).toBe(id);
    expect(reUploaded?.createdAt).toBe(originalCreatedAt);
    // Stale CUI state from the test setup should be cleared by the re-upload.
    // cuiDetection/quarantinedImages were set manually above; the re-upload
    // doesn't carry them over because saveUploadedDocument uses put() for
    // the full replacement. After the scan runs, cuiScannedWithAi may be
    // set to false (no CUI key), but the manual `true` we set must not survive.
    expect(reUploaded?.cuiDetection).toBeUndefined();
    expect(reUploaded?.quarantinedImages).toBeUndefined();
  });
});
