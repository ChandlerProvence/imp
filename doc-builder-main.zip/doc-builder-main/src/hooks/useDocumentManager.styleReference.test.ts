import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { renderHook, act, waitFor } from "@testing-library/react";
import { STYLE_REFERENCE_SLOT, useDocumentManager } from "./useDocumentManager";
import { db } from "../db/dexie";
import type { DocumentSchema } from "../schemas/types";

vi.mock("../extraction/parseFileEnhanced", () => ({
  parseFileStructure: vi.fn(async (file: File) => {
    const text = `content of ${file.name} `.repeat(Math.max(1, Math.ceil(file.size / 24)));
    return { text, headerFooterText: "", images: [], standaloneImage: false };
  }),
  resolveImages: vi.fn(async ({ parsed }: any) => parsed.text),
}));

vi.mock("../ai/cuiDetection", async () => {
  const actual = await vi.importActual<typeof import("../ai/cuiDetection")>("../ai/cuiDetection");
  return { ...actual, checkForCui: vi.fn(async () => null) };
});

vi.mock("../ai/embeddings", async () => {
  const actual = await vi.importActual<typeof import("../ai/embeddings")>("../ai/embeddings");
  return {
    ...actual,
    embedAndStoreDocument: vi.fn(async ({ docId, docTitle }: { docId: string; docTitle: string }) => [
      { text: "chunk text", docId, docTitle, index: 0, embedding: [0, 0] },
    ]),
    retrieveRelevantChunks: vi.fn(async (_q: string, chunks: unknown[]) => chunks),
  };
});

import { embedAndStoreDocument } from "../ai/embeddings";
import { checkForCui } from "../ai/cuiDetection";
import { mergeSetSchemas } from "../schemas/mergeSet";
import { buildUnifiedSystemPrompt } from "../ai/unifiedPrompt";
import { buildReviewSystemPrompt } from "../ai/documentReviewPrompt";

const STYLE = STYLE_REFERENCE_SLOT.id;

// The style-reference slot is offered only for schemas with a freetext field.
const narrative = [{ id: "approach", title: "Approach", fields: [{ id: "body", label: "Body", type: "freetext" }] }];

const schemaWithSlots: DocumentSchema = {
  id: "test-schema",
  title: "Test",
  category: "fms",
  sections: narrative,
  recommended_uploads: [{ id: "pws", title: "PWS", priority: "recommended" }],
} as any;

const schemaWithoutSlots: DocumentSchema = { id: "bare", title: "Bare", category: "fms", sections: narrative } as any;

const schemaWithoutFreetext: DocumentSchema = {
  id: "form",
  title: "Form",
  category: "fms",
  sections: [{ id: "main", title: "Main", fields: [{ id: "name", label: "Name", type: "string" }] }],
  recommended_uploads: [{ id: "pws", title: "PWS", priority: "recommended" }],
} as any;

/** The name is written into the bytes so equal-size files have distinct content. */
function makeFile(name: string, size = 200) {
  const bytes = new Uint8Array(size);
  bytes.set(new TextEncoder().encode(name).slice(0, size));
  return new File([bytes], name, { type: "application/pdf" });
}

function renderManager(schema = schemaWithSlots) {
  return renderHook(() => useDocumentManager({ schema, activeEndpoint: "non-cui", setActiveEndpoint: vi.fn() }));
}

type Result = ReturnType<typeof renderManager>["result"];

async function idOf(name: string): Promise<string> {
  const doc = (await db.uploadedDocuments.toArray()).find((d) => d.fileName === name);
  if (!doc) throw new Error(`no saved doc ${name}`);
  return doc.id;
}

async function dropOnSlot(result: Result, file: File, slotId?: string) {
  act(() => result.current.addFiles([file], slotId));
  await waitFor(() => expect(result.current.isParsing).toBe(false));
  await waitFor(() => expect(result.current.attachBlocked).toBe(false));
}

describe("useDocumentManager style-reference slot", () => {
  beforeEach(async () => {
    vi.clearAllMocks();
    vi.stubGlobal("fetch", vi.fn(async () => ({ ok: false, json: async () => ({}) })));
    localStorage.clear();
    await db.uploadedDocuments.clear();
    await db.embeddingChunks.clear();
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it("is offered for a schema with no recommended uploads", () => {
    const { result } = renderManager(schemaWithoutSlots);
    expect(result.current.slotDefs.map((d) => d.id)).toEqual([STYLE]);
  });

  it("is not offered for a schema without freetext fields", () => {
    const { result } = renderManager(schemaWithoutFreetext);
    expect(result.current.slotDefs.map((d) => d.id)).toEqual(["pws"]);
  });

  it("keeps the style reference out of the prompt documents and source guidance", async () => {
    const { result } = renderManager();
    act(() => result.current.setShowDocPicker(true));
    await dropOnSlot(result, makeFile("prior-lcsp.pdf"), STYLE);
    await dropOnSlot(result, makeFile("pws.pdf"), "pws");
    const styleId = await idOf("prior-lcsp.pdf");

    act(() => result.current.requestAttach());
    await waitFor(() => expect(result.current.slotAssignments.get(styleId)).toBe(STYLE));
    await waitFor(() => expect(result.current.docsReady).toBe(true));

    const text = result.current.buildCombinedDocumentText()!;
    expect(text).not.toContain("prior-lcsp.pdf");
    expect(text).toContain('<document role="pws" title="PWS" filename="pws.pdf">');
    expect(result.current.buildSourceDocumentRoles().map((r) => r.role)).toEqual(["pws"]);
    expect(result.current.styleReferenceDocs).toEqual([
      expect.objectContaining({ id: styleId, fileName: "prior-lcsp.pdf", text: expect.stringContaining("content of prior-lcsp.pdf") }),
    ]);
  });

  it("never embeds a large style reference and excludes it from search", async () => {
    const { result } = renderManager();
    act(() => result.current.setShowDocPicker(true));
    await dropOnSlot(result, makeFile("big-prior.pdf", 20000), STYLE);
    await dropOnSlot(result, makeFile("big-pws.pdf", 20000), "pws");

    act(() => result.current.requestAttach());
    await waitFor(() => expect(result.current.docsReady).toBe(true));
    await waitFor(() => expect(embedAndStoreDocument).toHaveBeenCalledTimes(1));
    expect(vi.mocked(embedAndStoreDocument).mock.calls[0][0].docTitle).toBe("big-pws.pdf");

    expect(result.current.buildCombinedDocumentText()).not.toContain("big-prior.pdf");
    const { text } = await result.current.handleSearchReferences("anything");
    expect(text).toContain("big-pws.pdf");
    expect(text).not.toContain("big-prior.pdf");
  });

  it("loads a document as a source once it is moved out of the style slot", async () => {
    const { result } = renderManager();
    act(() => result.current.setShowDocPicker(true));
    await dropOnSlot(result, makeFile("moved.pdf"), STYLE);
    const id = await idOf("moved.pdf");
    act(() => result.current.requestAttach());
    await waitFor(() => expect(result.current.slotAssignments.get(id)).toBe(STYLE));

    act(() => result.current.setShowDocPicker(true));
    act(() => result.current.assignDraftSlot("pws", id));
    act(() => result.current.requestAttach());
    await waitFor(() => expect(result.current.slotAssignments.get(id)).toBe("pws"));

    const text = result.current.buildCombinedDocumentText()!;
    expect(text).toContain('<document role="pws" title="PWS" filename="moved.pdf">');
    expect(text).not.toContain('truncated="true"');
    expect(result.current.styleReferenceDocs).toEqual([]);
  });

  it("gives an identical re-upload the same id and changed bytes a new one", async () => {
    // The session note is keyed on these ids: same id = same note, new id = new note.
    const { result } = renderManager();
    act(() => result.current.setShowDocPicker(true));
    await dropOnSlot(result, makeFile("prior.pdf"), STYLE);
    const first = await idOf("prior.pdf");

    await dropOnSlot(result, makeFile("prior.pdf"), STYLE);
    expect((await db.uploadedDocuments.toArray()).map((d) => d.id)).toEqual([first]);

    const changed = new File([new TextEncoder().encode("prior.pdf, revised")], "prior.pdf", { type: "application/pdf" });
    await dropOnSlot(result, changed, STYLE);
    const ids = (await db.uploadedDocuments.toArray()).map((d) => d.id);
    expect(ids).toHaveLength(2);
    expect(ids).toContain(first);
  });

  describe("document sets", () => {
    const member = (id: string, sectionId: string, slots: unknown[]): DocumentSchema =>
      ({
        id,
        title: id.toUpperCase(),
        category: "fms",
        version: 1,
        output_template: "x",
        sections: [{ id: sectionId, title: sectionId, fields: [{ id: "body", label: "Body", type: "freetext" }] }],
        recommended_uploads: slots,
      }) as any;
    const merged = mergeSetSchemas(
      [
        member("doc-a", "approach", [{ id: "pws", title: "PWS", priority: "recommended" }]),
        member("doc-b", "risks", [{ id: "pws", title: "PWS", priority: "optional" }]),
      ],
      "test-set",
    );
    const note = "Bullets for risks; paragraphs elsewhere.";

    it("offers one style slot for the merged set", () => {
      const { result } = renderManager(merged.schema);
      expect(result.current.slotDefs.map((d) => d.id)).toEqual(["pws", STYLE]);
    });

    it("offers the slot when only one member has freetext", () => {
      const form = { ...(schemaWithoutFreetext as any), id: "form", version: 1, output_template: "x" };
      const mixed = mergeSetSchemas([form, member("doc-b", "risks", [])], "mixed-set");
      const { result } = renderManager(mixed.schema);
      expect(result.current.slotDefs.map((d) => d.id)).toContain(STYLE);
    });

    it("excludes a style reference from the set's prompt documents", async () => {
      const { result } = renderManager(merged.schema);
      act(() => result.current.setShowDocPicker(true));
      await dropOnSlot(result, makeFile("prior.pdf"), STYLE);
      await dropOnSlot(result, makeFile("pws.pdf"), "pws");
      act(() => result.current.requestAttach());
      await waitFor(() => expect(result.current.styleReferenceDocs).toHaveLength(1));
      await waitFor(() => expect(result.current.docsReady).toBe(true));
      const text = result.current.buildCombinedDocumentText()!;
      expect(text).toContain("pws.pdf");
      expect(text).not.toContain("prior.pdf");
    });

    it("applies the one note to every member's sections and to the set review", () => {
      const prompt = buildUnifiedSystemPrompt(merged.schema, { type: "document" }, {}, undefined, note);
      expect(prompt.match(/## Drafting Style/g)).toHaveLength(1);
      expect(prompt).toContain(note);
      expect(prompt).toContain("approach");
      expect(prompt).toContain("risks");

      const review = buildReviewSystemPrompt(merged.schema, merged.sourceSchemas, note);
      expect(review).toContain("## Document Set");
      expect(review).toContain(note);
    });
  });

  it("holds a possibly-CUI style reference until the user resolves the warning", async () => {
    vi.mocked(checkForCui).mockResolvedValueOnce({
      isCui: true,
      confidence: "high",
      reason: "marking",
      method: "regex",
      markers: ["CUI"],
    } as any);
    const { result } = renderManager();
    act(() => result.current.setShowDocPicker(true));
    await dropOnSlot(result, makeFile("maybe-cui.pdf"), STYLE);

    act(() => result.current.requestAttach());
    expect(result.current.showCuiWarning).toBe(true);
    expect(result.current.styleReferenceDocs).toEqual([]);

    act(() => result.current.cancelCuiWarning());
    expect(result.current.styleReferenceDocs).toEqual([]);

    act(() => result.current.affirmNotCuiAndAttach());
    await waitFor(() => expect(result.current.styleReferenceDocs).toHaveLength(1));
  });

  it("withholds a CUI style reference outside the CUI endpoint", async () => {
    const { result } = renderManager();
    act(() => result.current.setShowDocPicker(true));
    await dropOnSlot(result, makeFile("cui-prior.pdf"), STYLE);
    const id = await idOf("cui-prior.pdf");
    act(() => result.current.requestAttach());
    await waitFor(() => expect(result.current.styleReferenceDocs).toHaveLength(1));

    await db.uploadedDocuments.update(id, { cuiStatus: "cui" });
    act(() => result.current.setShowDocPicker(true));
    await waitFor(() =>
      expect(result.current.availableDocs.find((d) => d.id === id)?.savedDoc?.cuiStatus).toBe("cui"),
    );
    expect(result.current.styleReferenceDocs).toEqual([]);
    expect(result.current.styleReferencesWithheld).toBe(1);
  });
});
