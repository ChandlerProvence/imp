import { trackWrite } from "../db/writeStatus";
import { appError, appErrorException, toAppError, type AppError } from "../errors";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { DocumentSchema, RecommendedUpload } from "../schemas/types";
import { STYLE_REFERENCE_SLOT_ID } from "../schemas/reservedSlots";
import { hasFreetextFields } from "../schemas/schemaFeatures";
import { parseFileStructure, resolveImages } from "../extraction/parseFileEnhanced";
import type { DocxImageInfo } from "../extraction/parseFile";
import { mapWithLimit } from "../utils/concurrency";
import { sha256Hex } from "../utils/sha256";
import { mapWith, mapWithout, setWithout } from "../utils/stateHelpers";
import {
  SMALL_DOC_THRESHOLD,
  embedAndStoreDocument,
  retrieveRelevantChunks,
  type EmbeddedChunk,
} from "../ai/embeddings";
import {
  saveUploadedDocument,
  updateLastUsed,
  updateCuiStatus,
  updateDocumentContent,
  isCuiFlagged,
  isCuiUnresolved,
  getUploadedDocumentsByCategory,
  getUploadedDocumentByRefId,
  deleteUploadedDocument,
  updateDocumentRole,
} from "../db/uploadedDocuments";
import type { UploadedDocument } from "../db/types";
import { escapeXmlAttr, type SourceDocumentRole } from "../ai/bulkEdit";
import { checkForCui, regexCuiPreScreen } from "../ai/cuiDetection";
import { apiKeyStorageKey, getActiveEndpointId, type EndpointId } from "../ai/endpoints";

/**
 * Built-in slot offered for every schema with a freetext field. Documents in it are never a factual
 * source: they are left out of the prompt's documents, source-document
 * guidance, and RAG, and are only read to derive the session's `draftingStyle`.
 */
export const STYLE_REFERENCE_SLOT: RecommendedUpload = {
  id: STYLE_REFERENCE_SLOT_ID,
  title: "Style reference",
  description: "The customer's previous document. Used only to match writing style — never as a source of facts.",
  priority: "optional",
  multiple: true,
};

/** Concurrency cap for parallel large-document embedding on Attach. */
const EMBED_CONCURRENCY = 3;

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/** A committed (attached) document, for chat chips and the `[Docs: …]` label. */
export interface SelectedDocument {
  id: string;
  name: string;
  source: "reference" | "saved" | "upload" | "generated";
  /** The endpoint active when this document was uploaded (for CUI badge). */
  uploadEndpoint?: EndpointId;
  /** Slot id when the document is attached under a picker slot. */
  roleId?: string;
  /** Slot title when the document is attached under a picker slot. */
  roleTitle?: string;
}

/**
 * Resolve a slot's `default_reference` against the manifest. Manifest ids are
 * derived from filenames and usually end in a date (e.g.
 * "contact-information-sca-sor-tom-260829"), so the schema names a stable
 * prefix and the newest matching file wins.
 */
export function findDefaultReference(docs: ManifestDoc[], ref: string): ManifestDoc | undefined {
  const matches = docs.filter((d) => d.id === ref || d.id.startsWith(`${ref}-`));
  return [...matches].sort((a, b) => a.id.localeCompare(b.id)).pop();
}

/** Sort slot definitions: "recommended" tier first, then "optional" (stable).
 *  Within a tier, slots the user fills come before auto-loaded default references. */
export function sortSlotDefs(defs: RecommendedUpload[]): RecommendedUpload[] {
  const rank = (d: RecommendedUpload) => (d.priority === "optional" ? 2 : 0) + (d.default_reference ? 1 : 0);
  return [...defs].sort((a, b) => rank(a) - rank(b));
}

/** Restrict a docId → slotId map to member docs and known slot ids. */
function pruneSlotMap(
  map: Map<string, string>,
  members: Set<string>,
  slotIds: Set<string>,
): Map<string, string> {
  const out = new Map<string, string>();
  for (const [docId, slotId] of map) {
    if (members.has(docId) && slotIds.has(slotId)) out.set(docId, slotId);
  }
  return out;
}

export interface UseDocumentManagerOptions {
  schema: DocumentSchema | null;
  /** The currently active AI endpoint (reactive — drives CUI gating and doc visibility). */
  activeEndpoint: EndpointId;
  /** Optional: callback to switch the active AI endpoint (needed for CUI detection). */
  setActiveEndpoint?: (ep: EndpointId) => void;
}

/** A reference doc entry from the build-time manifest. */
export interface ManifestDoc {
  id: string;
  title: string;
  fileName: string;
  url: string;
}

/** A unified document item for display in the document picker. */
export interface UnifiedDocItem {
  /** Stable ID: `ref:<manifestId>` for reference docs, UUID for saved docs. */
  id: string;
  /** Display name. */
  title: string;
  /** Origin badge. */
  source: "reference" | "upload" | "generated";
  /** The saved document record, if already processed and cached. */
  savedDoc?: UploadedDocument;
  /** The manifest entry, if this is a reference doc. */
  manifestDoc?: ManifestDoc;
}

/** A committed style-reference document (see `STYLE_REFERENCE_SLOT`). */
export interface StyleReferenceDocument {
  id: string;
  fileName: string;
  text: string;
}

export interface UseDocumentManagerReturn {
  // File upload
  files: File[];
  setFiles: React.Dispatch<React.SetStateAction<File[]>>;
  parsingFiles: Set<File>;
  fileErrors: Map<File, AppError>;

  // Unified document list for the picker (sorted: selected → ref → user)
  availableDocs: UnifiedDocItem[];
  /** Committed/attached document IDs — what's actually in play for drafting. */
  selectedDocIds: Set<string>;
  /** Draft selection shown by the picker's checkboxes. Copied from selectedDocIds
   *  whenever the picker opens; only applied to selectedDocIds on Attach. */
  draftDocIds: Set<string>;
  /** Toggle a document's membership in the draft selection (picker checkbox). */
  toggleDraftDoc: (id: string) => void;

  // Slots (schema `recommended_uploads` entries the user fills in the picker)
  /** Slot definitions from the schema, "recommended" tier first, then "optional". */
  slotDefs: RecommendedUpload[];
  /** Draft slot membership, docId → slotId (only docs in draftDocIds). */
  draftSlotAssignments: Map<string, string>;
  /** Committed slot membership, docId → slotId (only docs in selectedDocIds). */
  slotAssignments: Map<string, string>;
  /** Put a document in a slot (adds it to the draft). A non-multiple slot's previous document is detached. */
  assignDraftSlot: (slotId: string, docId: string) => void;
  /** Remove a document from its slot. The slot is the attachment, so this detaches it from the draft. */
  unassignDraftSlot: (docId: string) => void;
  /** Queue files for parsing, optionally targeting a slot. Duplicates of queued files are re-targeted, not re-queued. */
  addFiles: (files: File[], slotId?: string) => void;
  /** Saved doc IDs currently being CUI-scanned. */
  scanningDocIds: Set<string>;

  // Status for individual docs
  docStatuses: Map<string, "fetching" | "parsing" | "ready" | "error">;
  embeddingProgress: Map<string, string>;
  embeddingErrors: Map<string, AppError>;
  /** Errors blocking the attached (committed) selection: embedding/fetch failures
   *  plus CUI-in-IL2 conflicts. Keyed by doc ID. Must be empty for docsReady. */
  attachmentErrors: Map<string, AppError>;

  // Document picker
  showDocPicker: boolean;
  setShowDocPicker: React.Dispatch<React.SetStateAction<boolean>>;
  /** True while any draft doc is still parsing or scanning — Attach is disabled. */
  attachBlocked: boolean;
  /** Human-readable reason Attach is blocked, or null when it isn't. */
  attachBlockedReason: string | null;
  /** Attempt to attach the draft selection. Opens the CUI warning if anything is flagged. */
  requestAttach: () => void;
  /** Close the picker without committing draft changes (X / Esc / backdrop). */
  closePickerDiscard: () => void;

  // Committed documents (for chat chips)
  setupDocuments: SelectedDocument[];
  documentCount: number;
  isParsing: boolean;

  // Handlers
  handleToggleDoc: (id: string) => void;
  handleRemoveDocument: (id: string) => void;
  handleDeleteDocument: (id: string) => Promise<void>;
  handleSearchReferences: (query: string) => Promise<{ text: string; chunkCount: number; docCount: number }>;

  // For building BulkEditRequest
  buildReferenceDocTexts: () => { title: string; text: string }[];
  buildCombinedDocumentText: () => string | undefined;
  /** Roles (slots) of the committed selection, for the prompt's source-document guidance. */
  buildSourceDocumentRoles: () => SourceDocumentRole[];
  /** Committed documents in the style-reference slot. */
  styleReferenceDocs: StyleReferenceDocument[];
  /** Attached style references withheld because one is CUI and the endpoint is not (0 otherwise). */
  styleReferencesWithheld: number;

  // Reset all selections (used when session changes)
  resetSelections: () => void;

  /** True when all attached docs are fully processed (parsed + embedded) and error-free. */
  docsReady: boolean;
  /** Human-readable status when docs are NOT ready, or null when ready. */
  docsProcessingStatus: string | null;

  /**
   * Index a generated document for RAG-based review.
   * Chunks and embeds the text, making it available via search_references.
   * Returns true on success, false on failure (e.g., embedding API unavailable).
   */
  indexGeneratedDocument: (
    docId: string,
    title: string,
    text: string,
    onProgress?: (message: string) => void,
  ) => Promise<boolean>;

  /** Remove indexed chunks for a generated document (cleanup). */
  removeGeneratedDocumentIndex: (docId: string) => void;

  /** Set a virtual generated document (from Preview rendered output). */
  setGeneratedDocument: (schemaId: string, title: string, content: string) => void;
  /** Remove virtual generated document(s). Pass a schemaId to remove one, or omit to remove all. */
  removeGeneratedDocument: (schemaId?: string) => void;
  /** IDs of all current generated documents. */
  generatedDocIds: string[];

  /** Number of CUI-status docs hidden from the picker because the user is in
   *  Proprietary mode and the doc isn't currently attached. */
  hiddenCuiDocCount: number;

  // CUI
  /** Whether the CUI warning dialog should be shown (opened by requestAttach). */
  showCuiWarning: boolean;
  /** Draft docs that are flagged/scan-error and need resolution before attach. */
  flaggedDraftDocs: UploadedDocument[];
  /** Close the warning dialog without attaching; draft selection is untouched. */
  cancelCuiWarning: () => void;
  /** Mark flagged draft docs "not-cui" and attach. */
  affirmNotCuiAndAttach: () => void;
  /** Switch to the CUI endpoint, mark flagged draft docs "cui", and attach. */
  switchToCuiAndAttach: () => void;
}

// ---------------------------------------------------------------------------
// Hook
// ---------------------------------------------------------------------------

export function useDocumentManager({ schema, activeEndpoint, setActiveEndpoint }: UseDocumentManagerOptions): UseDocumentManagerReturn {
  // File upload state
  const [files, setFiles] = useState<File[]>([]);
  const [parsingFiles, setParsingFiles] = useState<Set<File>>(new Set());
  const [fileErrors, setFileErrors] = useState<Map<File, AppError>>(new Map());

  // Manifest reference docs
  const [manifestDocs, setManifestDocs] = useState<ManifestDoc[]>([]);

  // Committed/attached selection (contains both `ref:<id>` and saved doc UUIDs)
  const [selectedDocIds, setSelectedDocIds] = useState<Set<string>>(new Set());

  // Draft selection shown by the picker's checkboxes. Copied from selectedDocIds
  // whenever the picker opens; only applied to selectedDocIds via commitDraft().
  const [draftDocIds, setDraftDocIds] = useState<Set<string>>(new Set());

  // Mirror of draftDocIds for handlers that must read the latest value.
  const draftDocIdsRef = useRef(draftDocIds);
  draftDocIdsRef.current = draftDocIds;

  // Slot assignments, docId → slotId. Draft mirrors draftDocIds (picker), committed
  // mirrors selectedDocIds. One slot per doc is structural in this shape.
  const [draftSlotByDoc, setDraftSlotByDoc] = useState<Map<string, string>>(new Map());
  const draftSlotByDocRef = useRef(draftSlotByDoc);
  draftSlotByDocRef.current = draftSlotByDoc;
  const [slotByDoc, setSlotByDoc] = useState<Map<string, string>>(new Map());

  // Files dropped on a slot. A ref because the parse pipeline's async callbacks
  // close over the render that started them.
  const fileSlotTargetsRef = useRef<Map<File, string>>(new Map());
  const filesRef = useRef<File[]>([]);

  // The style-reference slot only matters when there is freetext to style.
  const offersStyleReference = hasFreetextFields(schema);
  const slotDefs = useMemo(
    () =>
      sortSlotDefs([
        ...(schema?.recommended_uploads ?? []),
        ...(offersStyleReference ? [STYLE_REFERENCE_SLOT] : []),
      ]),
    [schema?.recommended_uploads, offersStyleReference],
  );
  const slotDefsRef = useRef(slotDefs);
  slotDefsRef.current = slotDefs;
  const slotIds = useMemo(() => new Set(slotDefs.map((d) => d.id)), [slotDefs]);

  // Saved doc IDs currently being CUI-scanned (drives the Attach-blocked state
  // and the per-row "Scanning…" indicator).
  const [scanningDocIds, setScanningDocIds] = useState<Set<string>>(new Set());

  // Document texts (keyed by saved doc ID) — populated only for attached docs.
  const [docTexts, setDocTexts] = useState<Map<string, { fileName: string; text: string }>>(new Map());

  // Status tracking per document
  const [docStatuses, setDocStatuses] = useState<Map<string, "fetching" | "parsing" | "ready" | "error">>(new Map());

  // Embedding state for large docs
  const [embeddedChunks, setEmbeddedChunks] = useState<Map<string, EmbeddedChunk[]>>(new Map());
  const [embeddingProgress, setEmbeddingProgress] = useState<Map<string, string>>(new Map());
  const [embeddingErrors, setEmbeddingErrors] = useState<Map<string, AppError>>(new Map());

  // Saved (previously uploaded) documents from IndexedDB
  const [savedDocs, setSavedDocs] = useState<UploadedDocument[]>([]);

  // Document picker
  const [showDocPicker, setShowDocPicker] = useState(false);
  const prevShowDocPickerRef = useRef(false);

  // CUI warning dialog (opened by requestAttach when the draft has flagged docs)
  const [showCuiWarning, setShowCuiWarning] = useState(false);

  // Keep a ref mirror of the active endpoint so async callbacks (scan/embed
  // completions) read the endpoint current at completion time, not capture time.
  const activeEndpointRef = useRef(activeEndpoint);
  activeEndpointRef.current = activeEndpoint;

  // Virtual generated documents (ephemeral — from the Preview page rendered output).
  // Keyed by generated doc ID (`generated:<schemaId>`).
  const [generatedDocs, setGeneratedDocsState] = useState<Map<string, { id: string; title: string; text: string }>>(new Map());
  /** Tracks the content fingerprint per generated doc to avoid redundant re-embeds. */
  const generatedDocContentRefs = useRef<Map<string, string>>(new Map());
  /** Version counter per generated doc for in-flight embeddings — prevents stale results from overwriting current state. */
  const generatedEmbedVersionRefs = useRef<Map<string, number>>(new Map());


  // ---------------------------------------------------------------------------
  // Effects
  // ---------------------------------------------------------------------------

  // Load reference docs manifest filtered by schema category
  useEffect(() => {
    if (!schema?.category) {
      setManifestDocs([]);
      return;
    }
    const category = schema.category;
    const controller = new AbortController();
    fetch(`${import.meta.env.BASE_URL}reference-docs/manifest.json`, { signal: controller.signal })
      .then((res) => (res.ok ? res.json() : {}))
      .then((manifest: Record<string, ManifestDoc[]>) => {
        setManifestDocs(manifest[category] ?? []);
      })
      .catch((err) => {
        if (err instanceof DOMException && err.name === "AbortError") return;
        setManifestDocs([]);
      });
    return () => controller.abort();
  }, [schema?.category]);

  // Load saved docs when doc picker opens (and on mount for the unified list)
  useEffect(() => {
    if (!schema?.category) return;
    getUploadedDocumentsByCategory(schema.category).then(setSavedDocs);
  }, [showDocPicker, schema?.category]);

  // When the picker opens, start the draft from the current committed selection
  // (discarded if the user closes without clicking Attach).
  useEffect(() => {
    const wasOpen = prevShowDocPickerRef.current;
    prevShowDocPickerRef.current = showDocPicker;
    if (!showDocPicker || wasOpen) return;
    const draftIds = new Set(selectedDocIds);
    const draftSlots = pruneSlotMap(slotByDoc, selectedDocIds, slotIds);
    // Sync the refs now so effects later in this commit (default-reference
    // pre-placement) see the fresh draft rather than the previous open's.
    draftDocIdsRef.current = draftIds;
    draftSlotByDocRef.current = draftSlots;
    setDraftDocIds(draftIds);
    setDraftSlotByDoc(draftSlots);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showDocPicker]);

  /** Whether a CUI API key is currently configured (drives vision routing). */
  const hasCuiKey = useCallback(() => !!localStorage.getItem(apiKeyStorageKey("cui")), []);

  /** Whether any API key is configured (AI CUI scan falls back to IL2 when no CUI key). */
  const hasAnyApiKey = useCallback(
    () => !!localStorage.getItem(apiKeyStorageKey("cui")) || !!localStorage.getItem(apiKeyStorageKey("non-cui")),
    [],
  );

  /** True when a saved doc needs a CUI (re-)scan before it can be attached in IL2. */
  const needsCuiScan = useCallback((doc: UploadedDocument): boolean => {
    if (activeEndpointRef.current === "cui") return false;
    if (doc.cuiStatus === "pending" || doc.cuiStatus === undefined) return true;
    // Rescan if previous scan was regex-only but we now have an API key for AI
    if (doc.cuiStatus === "clean" && !doc.cuiScannedWithAi && hasAnyApiKey()) return true;
    return false;
  }, [hasAnyApiKey]);

  /** Run the CUI scan for a saved doc and persist the resulting status. Returns the updated doc.
   *  Prepends headerFooterText (if set) so CUI banners in headers/footers are caught. */
  const scanDoc = useCallback(async (doc: UploadedDocument): Promise<UploadedDocument> => {
    setScanningDocIds((prev) => new Set([...prev, doc.id]));
    let updated: UploadedDocument;
    try {
      const scanText = doc.headerFooterText
        ? doc.headerFooterText + "\n" + doc.textContent
        : doc.textContent;
      const cuiResult = await checkForCui(scanText, doc.fileName);
      if (cuiResult && "error" in cuiResult) {
        await updateCuiStatus(doc.id, "scan-error", { cuiScanError: cuiResult.message });
        updated = { ...doc, cuiStatus: "scan-error", cuiScanError: cuiResult.message };
      } else if (cuiResult?.isCui) {
        await updateCuiStatus(doc.id, "flagged", { cuiDetection: cuiResult, cuiScannedWithAi: cuiResult.method !== "regex" });
        updated = { ...doc, cuiStatus: "flagged", cuiDetection: cuiResult, cuiScannedWithAi: cuiResult.method !== "regex" };
      } else {
        const scannedWithAi = hasAnyApiKey();
        await updateCuiStatus(doc.id, "clean", { cuiScannedWithAi: scannedWithAi });
        updated = { ...doc, cuiStatus: "clean", cuiScannedWithAi: scannedWithAi };
      }
    } finally {
      setScanningDocIds((prev) => setWithout(prev, doc.id));
    }
    setSavedDocs((prev) => prev.map((d) => (d.id === doc.id ? updated : d)));
    return updated;
  }, [hasAnyApiKey]);

  // Track which files have been queued for parsing to avoid re-processing
  const processedFilesRef = useRef<Set<File>>(new Set());

  // Read by the parse pipeline at call time. As effect dependencies they would
  // cancel in-flight parses whenever the manifest loads or the scan callbacks
  // change identity, and processed files are never retried.
  const manifestDocsRef = useRef(manifestDocs);
  manifestDocsRef.current = manifestDocs;
  const needsCuiScanRef = useRef(needsCuiScan);
  needsCuiScanRef.current = needsCuiScan;
  const scanDocRef = useRef(scanDoc);
  scanDocRef.current = scanDoc;

  // Parse files as they're added. New uploads land in the draft selection
  // (not the committed selection) — text and CUI resolution happen before
  // anything is attached, per the Attach flow in requestAttach/commitDraft.
  //
  // Two-phase pipeline:
  //   1. parseFileStructure() — no network calls
  //   2. Pre-image CUI gate → resolveImages() or quarantine → save → scanDoc
  useEffect(() => {
    let cancelled = false;
    const category = schema?.category;
    const newFiles = files.filter((f) => !processedFilesRef.current.has(f));

    if (newFiles.length > 0) {
      for (const f of newFiles) {
        processedFilesRef.current.add(f);
      }
      setParsingFiles((prev) => new Set([...prev, ...newFiles]));

      const completedFiles: File[] = [];
      const inCuiMode = activeEndpointRef.current === "cui";

      mapWithLimit(newFiles, 2, async (f) => {
        try {
          // Phase 1: structure-only parse (no network), plus the content hash
          // that identifies re-uploads of the same bytes
          const [parsed, contentHash] = await Promise.all([
            parseFileStructure(f),
            f.arrayBuffer().then(sha256Hex),
          ]);
          if (cancelled) return;

          // Bundled reference docs ship publicly on GitLab Pages, so they are
          // never CUI — skip the quarantine gate and scan, in either mode.
          const refEntry = manifestDocsRef.current.find((d) => d.fileName === f.name);

          // Vision endpoint: "cui" in CUI mode or when a CUI key exists, otherwise "non-cui"
          const visionEndpoint: EndpointId = inCuiMode ? "cui" : hasCuiKey() ? "cui" : "non-cui";

          // Phase 2: pre-image CUI gate (IL2, no CUI key, docx with images, not standalone)
          const shouldQuarantine =
            !refEntry &&
            !inCuiMode &&
            !hasCuiKey() &&
            parsed.images.length > 0 &&
            !parsed.standaloneImage;

          let textContent: string;
          let quarantinedImages: { placeholder: string; dataUrl: string }[] | undefined;
          let cuiStatusFromGate: UploadedDocument["cuiStatus"] | undefined;
          let cuiDetectionFromGate: UploadedDocument["cuiDetection"] | undefined;
          let usedVision = false;

          if (shouldQuarantine) {
            // Run regex pre-screen on body + header/footer text
            const preScreenText = parsed.headerFooterText
              ? parsed.text + "\n" + parsed.headerFooterText
              : parsed.text;
            const regexHit = regexCuiPreScreen(preScreenText);

            if (regexHit) {
              // Quarantine: hold images, save with quarantine placeholders
              quarantinedImages = parsed.images.map((img) => ({
                placeholder: `[Image quarantined — pending CUI confirmation (${img.placeholder.slice(1, -1)})]`,
                dataUrl: img.dataUrl,
              }));
              textContent = parsed.text;
              for (let i = 0; i < parsed.images.length; i++) {
                textContent = textContent.replace(
                  parsed.images[i].placeholder,
                  quarantinedImages[i].placeholder,
                );
              }
              cuiStatusFromGate = "flagged";
              cuiDetectionFromGate = regexHit;
            } else {
              // Clean body — resolve images through IL2
              textContent = await resolveImages({
                parsed,
                fileName: f.name,
                endpoint: visionEndpoint,
              });
              usedVision = parsed.images.length > 0;
            }
          } else if (parsed.images.length > 0) {
            // Has images but not quarantined (CUI mode, CUI key, or standalone)
            textContent = await resolveImages({
              parsed,
              fileName: f.name,
              endpoint: visionEndpoint,
            });
            usedVision = true;
          } else {
            textContent = parsed.text;
          }

          if (cancelled) return;
          setParsingFiles((prev) => {
            const next = new Set(prev);
            next.delete(f);
            return next;
          });

          if (!category) return;

          // CUI status: reference doc → "not-cui", CUI mode → "cui",
          // quarantined → "flagged", otherwise "pending"
          const initialStatus: UploadedDocument["cuiStatus"] = refEntry
            ? "not-cui"
            : inCuiMode
              ? "cui"
              : cuiStatusFromGate ?? "pending";

          const saved = await saveUploadedDocument({
            fileName: f.name,
            mimeType: f.type || "application/octet-stream",
            fileSize: f.size,
            contentHash,
            textContent,
            charCount: textContent.length,
            category,
            uploadEndpoint: getActiveEndpointId(),
            cuiStatus: initialStatus,
            headerFooterText: parsed.headerFooterText || undefined,
            createdAt: new Date().toISOString(),
            lastUsedAt: new Date().toISOString(),
            ...(usedVision ? { isImage: true } : {}),
            ...(quarantinedImages ? { quarantinedImages } : {}),
            ...(cuiDetectionFromGate ? { cuiDetection: cuiDetectionFromGate } : {}),
            ...(refEntry ? { source: "reference" as const, refId: refEntry.id } : { source: "upload" as const }),
          });
          completedFiles.push(f);

          // If re-uploading an attached doc, remove it from committed state
          // so the fresh copy goes through Attach again.
          setSelectedDocIds((prev) => {
            if (!prev.has(saved.id)) return prev;
            return setWithout(prev, saved.id);
          });
          setDocTexts((texts) => mapWithout(texts, saved.id));
          setEmbeddedChunks((chunks) => mapWithout(chunks, `upload:${saved.id}`));
          setEmbeddingErrors((errs) => mapWithout(errs, saved.id));

          setSavedDocs((prev) => {
            const withoutStale = prev.filter((d) => d.id !== saved.id);
            return [saved, ...withoutStale];
          });

          if (refEntry) {
            replaceDraftIdRef.current(`ref:${refEntry.id}`, saved.id);
          } else {
            setDraftDocIds((prev) => new Set([...prev, saved.id]));
            setDocStatuses((prev) => mapWith(prev, saved.id, "ready"));
          }

          // Dropped on a slot → place it there now that it has a saved id.
          const targetSlot = fileSlotTargetsRef.current.get(f);
          if (targetSlot) placeInSlotRef.current(targetSlot, saved.id);

          // Scan in IL2 when needed (skip if already quarantined/flagged by the gate).
          // In CUI mode, nothing to scan — it's already "cui".
          if (!inCuiMode && !cuiStatusFromGate && needsCuiScanRef.current(saved)) {
            await scanDocRef.current(saved);
          }
        } catch (err) {
          if (cancelled) return;
          // Parse, vision, storage, or CUI-scan failure — the hint makes
          // ambiguous errors resolve as file problems
          const appErr = toAppError(err, { domain: "file", context: { fileName: f.name } });
          setFileErrors((prev) => new Map([...prev, [f, appErr]]));
          setParsingFiles((prev) => {
            const next = new Set(prev);
            next.delete(f);
            return next;
          });
          // Mark ref doc as error if applicable
          const refEntry = manifestDocsRef.current.find((d) => d.fileName === f.name);
          if (refEntry) {
            const refId = `ref:${refEntry.id}`;
            setDocStatuses((prev) => mapWith(prev, refId, "error"));
          }
        }
      }).then(() => {
        if (!cancelled && completedFiles.length > 0) {
          setFiles((prev) => prev.filter((x) => !completedFiles.includes(x)));
        }
      });
    }

    // Clean up ref entries for removed files
    for (const f of processedFilesRef.current) {
      if (!files.includes(f)) processedFilesRef.current.delete(f);
    }
    filesRef.current = files;
    for (const f of fileSlotTargetsRef.current.keys()) {
      if (!files.includes(f)) fileSlotTargetsRef.current.delete(f);
    }

    return () => {
      cancelled = true;
    };
    // activeEndpoint, manifestDocs, needsCuiScan and scanDoc are read via refs
    // (hasCuiKey via closure) at call time by design — this effect should not
    // re-run (and cancel in-flight parses) on endpoint switch, manifest load, or
    // a scan-callback identity change.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [files, schema?.category]);

  // ---------------------------------------------------------------------------
  // Handlers
  // ---------------------------------------------------------------------------

  /** Move a draft entry from one id to another (`ref:<id>` → saved UUID once the
   *  reference doc is cached/parsed), carrying its status and slot assignment. */
  const replaceDraftId = useCallback((oldId: string, newId: string) => {
    setDraftDocIds((prev) => {
      const next = new Set(prev);
      next.delete(oldId);
      next.add(newId);
      return next;
    });
    setDocStatuses((prev) => {
      const next = new Map(prev);
      next.delete(oldId);
      next.set(newId, "ready");
      return next;
    });
    setDraftSlotByDoc((prev) => {
      const slotId = prev.get(oldId);
      if (slotId === undefined) return prev;
      const next = mapWithout(prev, oldId);
      next.set(newId, slotId);
      return next;
    });
  }, []);
  const replaceDraftIdRef = useRef(replaceDraftId);
  replaceDraftIdRef.current = replaceDraftId;

  /** Remove a document from the draft selection (and from its draft slot).
   *  A still-fetching reference doc is cancelled. */
  const removeFromDraft = useCallback((id: string) => {
    setDraftDocIds((prev) => setWithout(prev, id));
    setDraftSlotByDoc((prev) => (prev.has(id) ? mapWithout(prev, id) : prev));
    if (id.startsWith("ref:")) {
      // Still-fetching ref doc — cancel by removing it from the upload queue
      const manifestId = id.slice(4);
      const doc = manifestDocs.find((d) => d.id === manifestId);
      if (doc) {
        setFiles((prevFiles) => prevFiles.filter((f) => f.name !== doc.fileName));
      }
      setDocStatuses((prevS) => mapWithout(prevS, id));
    }
  }, [manifestDocs]);

  /** Add a document to the draft selection. Reference docs are fetched (or
   *  swapped to their cached copy); library docs with stale CUI status are rescanned.
   *  Never touches committed state — that only happens via commitDraft() on Attach. */
  const addToDraft = useCallback((id: string) => {
    if (draftDocIdsRef.current.has(id)) return;
    setDraftDocIds((prev) => new Set([...prev, id]));
    if (id.startsWith("ref:")) {
      const manifestId = id.slice(4);
      const doc = manifestDocs.find((d) => d.id === manifestId);
      const category = schema?.category;
      if (doc && category) {
        setDocStatuses((prevS) => mapWith(prevS, id, "fetching"));
        getUploadedDocumentByRefId(manifestId, category).then((existing) => {
          if (existing) {
            // Already cached from a prior session — swap the draft id to the saved UUID.
            // Embedding (if needed) happens at commitDraft, not here.
            replaceDraftId(id, existing.id);
            setSavedDocs((prevSaved) => {
              if (prevSaved.some((d) => d.id === existing.id)) return prevSaved;
              return [existing, ...prevSaved];
            });
          } else {
            // Not cached — fetch and feed into the normal upload pipeline
            fetch(`${import.meta.env.BASE_URL}${doc.url}`)
              .then((res) => {
                if (!res.ok) {
                  throw appErrorException("file.fetch-failed", {
                    context: { fileName: doc.fileName },
                    detail: `HTTP ${res.status} fetching ${doc.url}`,
                  });
                }
                return res.blob();
              })
              .then((blob) => {
                setDocStatuses((prevS) => mapWith(prevS, id, "parsing"));
                const file = new File([blob], doc.fileName, { type: blob.type });
                setFiles((prevFiles) => [...prevFiles, file]);
              })
              .catch((err) => {
                setDocStatuses((prevS) => mapWith(prevS, id, "error"));
                setEmbeddingErrors((errs) =>
                  mapWith(errs, id, err instanceof TypeError
                    ? appError("file.fetch-failed", { context: { fileName: doc.fileName }, cause: err })
                    : toAppError(err, { domain: "file", context: { fileName: doc.fileName } })),
                );
              });
          }
        });
      }
    } else if (!id.startsWith("generated:")) {
      // Saved doc UUID (library item) — scan now if its CUI status is stale,
      // so requestAttach has fresh status to check. Fire-and-forget: the
      // scanningDocIds flag blocks Attach until this resolves.
      const doc = savedDocs.find((d) => d.id === id);
      if (doc && needsCuiScan(doc)) {
        scanDoc(doc);
      }
    }
  }, [manifestDocs, schema?.category, savedDocs, needsCuiScan, scanDoc, replaceDraftId]);

  // Default references: slots that name a bundled manifest doc (e.g. the
  // contact sheet) get it pre-placed in the draft when the picker opens. Once
  // the user clicks Attach, the slot is "settled" — if they removed the
  // default, it stays removed for the rest of the session.
  const settledDefaultSlotsRef = useRef<Set<string>>(new Set());
  const prefilledThisOpenRef = useRef<Set<string>>(new Set());
  useEffect(() => {
    if (!showDocPicker) {
      prefilledThisOpenRef.current = new Set();
      return;
    }
    for (const def of slotDefsRef.current) {
      const refId = def.default_reference;
      if (!refId) continue;
      if (settledDefaultSlotsRef.current.has(def.id) || prefilledThisOpenRef.current.has(def.id)) continue;
      // Already occupied (committed selection is copied into the draft on open).
      if ([...slotByDoc.values()].includes(def.id)) continue;
      // Wait for the manifest; the effect re-runs when it loads.
      const manifestDoc = findDefaultReference(manifestDocs, refId);
      if (!manifestDoc) continue;
      prefilledThisOpenRef.current.add(def.id);
      const docId = `ref:${manifestDoc.id}`;
      addToDraft(docId);
      setDraftSlotByDoc((prev) => mapWith(prev, docId, def.id));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showDocPicker, manifestDocs, slotDefs]);

  /** Record a draft slot assignment. A non-multiple slot's previous occupant is detached. */
  const placeInSlot = useCallback((slotId: string, docId: string) => {
    const def = slotDefsRef.current.find((d) => d.id === slotId);
    if (!def) return;
    if (!def.multiple) {
      for (const [otherId, otherSlot] of draftSlotByDocRef.current) {
        if (otherSlot === slotId && otherId !== docId) removeFromDraft(otherId);
      }
    }
    setDraftSlotByDoc((prev) => {
      const next = new Map(prev);
      if (!def.multiple) {
        for (const [otherId, otherSlot] of prev) {
          if (otherSlot === slotId && otherId !== docId) next.delete(otherId);
        }
      }
      next.set(docId, slotId);
      return next;
    });
  }, [removeFromDraft]);
  const placeInSlotRef = useRef(placeInSlot);
  placeInSlotRef.current = placeInSlot;

  /** Toggle a document's membership in the draft selection (the picker's checkboxes).
   *  Checking a document returns it to the slot it was last used as, unless that
   *  would displace the slot's current document. */
  const toggleDraftDoc = useCallback((id: string) => {
    if (draftDocIdsRef.current.has(id)) {
      removeFromDraft(id);
      return;
    }
    addToDraft(id);
    const prevSlotId = savedDocs.find((d) => d.id === id)?.slotRole?.slotId;
    const def = prevSlotId ? slotDefsRef.current.find((d) => d.id === prevSlotId) : undefined;
    if (!def) return;
    const occupied = [...draftSlotByDocRef.current.values()].includes(def.id);
    if (def.multiple || !occupied) placeInSlot(def.id, id);
  }, [addToDraft, removeFromDraft, placeInSlot, savedDocs]);

  const assignDraftSlot = useCallback((slotId: string, docId: string) => {
    if (!slotDefsRef.current.some((d) => d.id === slotId)) return;
    addToDraft(docId);
    placeInSlot(slotId, docId);
  }, [addToDraft, placeInSlot]);

  const unassignDraftSlot = useCallback((docId: string) => {
    removeFromDraft(docId);
  }, [removeFromDraft]);

  const addFiles = useCallback((incoming: File[], slotId?: string) => {
    const def = slotId ? slotDefsRef.current.find((d) => d.id === slotId) : undefined;
    if (slotId && !def) return;
    // A single-document slot takes only the first file.
    const list = def && !def.multiple ? incoming.slice(0, 1) : incoming;
    const queued = filesRef.current;
    const toAdd: File[] = [];
    for (const f of list) {
      const same = (x: File) => x.name === f.name && x.size === f.size;
      const existing = queued.find(same) ?? toAdd.find(same);
      if (!existing) toAdd.push(f);
      // Re-target an already-queued duplicate instead of dropping it silently.
      if (slotId) fileSlotTargetsRef.current.set(existing ?? f, slotId);
    }
    if (toAdd.length > 0) {
      filesRef.current = [...filesRef.current, ...toAdd];
      setFiles((prev) => [...prev, ...toAdd]);
    }
  }, []);

  /** Toggle a generated document's attachment directly (Preview.tsx review flow).
   *  Generated docs are the user's own output — no CUI scan or Attach gate applies. */
  const handleToggleDoc = useCallback((id: string) => {
    setSelectedDocIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
        setDocStatuses((prevS) => mapWithout(prevS, id));
        setSlotByDoc((prevSlots) => (prevSlots.has(id) ? mapWithout(prevSlots, id) : prevSlots));
      } else {
        next.add(id);
        const genDoc = generatedDocs.get(id);
        if (genDoc) {
          setDocStatuses((prevS) => mapWith(prevS, id, "ready"));
          setDocTexts((texts) =>
            texts.has(id) ? texts : mapWith(texts, id, { fileName: genDoc.title, text: genDoc.text }),
          );
        }
      }
      return next;
    });
  }, [generatedDocs]);

  /** Remove a committed (attached) document — used by the chat chip's ✕ button. */
  const handleRemoveDocument = useCallback((id: string) => {
    setSelectedDocIds((prev) => setWithout(prev, id));
    setDraftDocIds((prev) => setWithout(prev, id));
    setSlotByDoc((prev) => (prev.has(id) ? mapWithout(prev, id) : prev));
    setDraftSlotByDoc((prev) => (prev.has(id) ? mapWithout(prev, id) : prev));
    setDocTexts((texts) => mapWithout(texts, id));
    setEmbeddedChunks((chunks) => {
      const next = mapWithout(chunks, `upload:${id}`);
      return mapWithout(next, id);
    });
    setEmbeddingErrors((errs) => mapWithout(errs, id));
    setDocStatuses((prev) => mapWithout(prev, id));
  }, []);

  const handleDeleteDocument = useCallback(
    async (id: string) => {
      const doc = savedDocs.find((d) => d.id === id);
      await deleteUploadedDocument(id);
      setSelectedDocIds((prev) => setWithout(prev, id));
      setDraftDocIds((prev) => setWithout(prev, id));
      setSlotByDoc((prev) => (prev.has(id) ? mapWithout(prev, id) : prev));
      setDraftSlotByDoc((prev) => (prev.has(id) ? mapWithout(prev, id) : prev));
      setDocTexts((texts) => mapWithout(texts, id));
      setSavedDocs((prev) => prev.filter((d) => d.id !== id));
      setEmbeddedChunks((chunks) => mapWithout(chunks, `upload:${id}`));
      setEmbeddingErrors((errs) => mapWithout(errs, id));
      setDocStatuses((prev) => mapWithout(prev, id));
      // Clear stale File from upload queue so same file can be re-uploaded (#78)
      if (doc) {
        setFiles((prev) =>
          prev.filter((f) => !(f.name === doc.fileName && f.size === doc.fileSize)),
        );
        for (const f of processedFilesRef.current) {
          if (f.name === doc.fileName && f.size === doc.fileSize) {
            processedFilesRef.current.delete(f);
          }
        }
      }
    },
    [savedDocs],
  );

  // ---------------------------------------------------------------------------
  // Virtual generated document (from Preview page rendered output)
  // ---------------------------------------------------------------------------

  const setGeneratedDocument = useCallback(
    (schemaId: string, title: string, content: string) => {
      // Skip if content hasn't changed — avoids tearing down and restarting embeddings
      // when the Preview page re-renders (e.g., as docx previews load incrementally).
      const fingerprint = `${schemaId}:${content.length}:${content.slice(0, 200)}:${content.slice(-200)}`;
      if (generatedDocContentRefs.current.get(schemaId) === fingerprint) return;
      generatedDocContentRefs.current.set(schemaId, fingerprint);

      const id = `generated:${schemaId}`;
      setGeneratedDocsState((prev) => mapWith(prev, id, { id, title, text: content }));
      setDocStatuses((prev) => mapWith(prev, id, "ready"));

      if (content.length < SMALL_DOC_THRESHOLD) {
        // Small: store full text in docTexts (included inline in the prompt)
        setDocTexts((texts) => mapWith(texts, id, { fileName: title, text: content }));
      } else {
        // Large: store a truncated preview in docTexts so buildCombinedDocumentText
        // includes a summary, then chunk & embed the full text for search_references.
        const PREVIEW_CHARS = 2000;
        const preview = content.slice(0, PREVIEW_CHARS) +
          "\n[… Document continues. Use search_references to find specific content.]";
        setDocTexts((texts) => mapWith(texts, id, { fileName: title, text: preview }));

        // Version counter prevents stale embedding results from overwriting current state
        const prevVersion = generatedEmbedVersionRefs.current.get(schemaId) ?? 0;
        const version = prevVersion + 1;
        generatedEmbedVersionRefs.current.set(schemaId, version);
        setEmbeddingProgress((prog) => mapWith(prog, id, "Chunking…"));
        embedAndStoreDocument({
          docId: id,
          docTitle: title,
          text: content,
          onProgress: (msg) => {
            if (generatedEmbedVersionRefs.current.get(schemaId) !== version) return;
            setEmbeddingProgress((prog) => mapWith(prog, id, msg));
          },
        })
          .then((embedded) => {
            if (generatedEmbedVersionRefs.current.get(schemaId) !== version) return; // stale
            setEmbeddedChunks((chunks) => mapWith(chunks, id, embedded));
          })
          .catch((err) => {
            if (generatedEmbedVersionRefs.current.get(schemaId) !== version) return; // stale
            setEmbeddingErrors((errs) => mapWith(errs, id, toAppError(err, { domain: "ai", context: { fileName: title } })));
          })
          .finally(() => {
            if (generatedEmbedVersionRefs.current.get(schemaId) !== version) return; // stale
            setEmbeddingProgress((prog) => mapWithout(prog, id));
          });
      }
    },
    [],
  );

  const removeGeneratedDocument = useCallback((schemaId?: string) => {
    if (schemaId) {
      // Remove a single generated document
      const id = `generated:${schemaId}`;
      generatedDocContentRefs.current.delete(schemaId);
      const prev = generatedEmbedVersionRefs.current.get(schemaId) ?? 0;
      generatedEmbedVersionRefs.current.set(schemaId, prev + 1);
      setGeneratedDocsState((prev) => mapWithout(prev, id));
      setDocTexts((texts) => mapWithout(texts, id));
      setEmbeddedChunks((chunks) => mapWithout(chunks, id));
      setSelectedDocIds((prev) => setWithout(prev, id));
      setDocStatuses((prev) => mapWithout(prev, id));
      setSlotByDoc((prev) => (prev.has(id) ? mapWithout(prev, id) : prev));
    } else {
      // Remove all generated documents
      setGeneratedDocsState((prev) => {
        for (const id of prev.keys()) {
          setDocTexts((texts) => mapWithout(texts, id));
          setEmbeddedChunks((chunks) => mapWithout(chunks, id));
          setSelectedDocIds((sel) => setWithout(sel, id));
          setDocStatuses((st) => mapWithout(st, id));
        }
        return new Map();
      });
      generatedDocContentRefs.current.clear();
      // Invalidate all in-flight embeddings
      for (const [key, ver] of generatedEmbedVersionRefs.current) {
        generatedEmbedVersionRefs.current.set(key, ver + 1);
      }
    }
  }, []);

  // ---------------------------------------------------------------------------
  // Slot views
  // ---------------------------------------------------------------------------

  const draftSlotAssignments = useMemo(
    () => pruneSlotMap(draftSlotByDoc, draftDocIds, slotIds),
    [draftSlotByDoc, draftDocIds, slotIds],
  );
  const slotAssignments = useMemo(
    () => pruneSlotMap(slotByDoc, selectedDocIds, slotIds),
    [slotByDoc, selectedDocIds, slotIds],
  );

  /** Slot definition for a committed document, if it's attached under a slot. */
  const roleForDoc = useCallback((docId: string): RecommendedUpload | undefined => {
    const slotId = slotAssignments.get(docId);
    return slotId ? slotDefs.find((d) => d.id === slotId) : undefined;
  }, [slotAssignments, slotDefs]);

  const isStyleRef = useCallback(
    (docId: string) => slotAssignments.get(docId) === STYLE_REFERENCE_SLOT.id,
    [slotAssignments],
  );

  /** Committed style-reference documents, for the style analysis call. Empty
   *  while any of them is CUI outside the CUI endpoint, so CUI text is never
   *  sent to the proprietary endpoint. */
  const { styleReferenceDocs, styleReferencesWithheld } = useMemo(() => {
    const out: StyleReferenceDocument[] = [];
    let cuiOutsideCui = false;
    for (const [docId, slotId] of slotAssignments) {
      if (slotId !== STYLE_REFERENCE_SLOT.id) continue;
      const saved = savedDocs.find((d) => d.id === docId);
      if (!saved) continue;
      if (activeEndpoint !== "cui" && saved.cuiStatus === "cui") cuiOutsideCui = true;
      out.push({ id: docId, fileName: saved.fileName, text: saved.textContent });
    }
    return cuiOutsideCui
      ? { styleReferenceDocs: [], styleReferencesWithheld: out.length }
      : { styleReferenceDocs: out, styleReferencesWithheld: 0 };
  }, [slotAssignments, savedDocs, activeEndpoint]);

  // ---------------------------------------------------------------------------
  // Search references (for BulkEditChatView tool-use)
  // ---------------------------------------------------------------------------

  const handleSearchReferences = useCallback(
    async (query: string): Promise<{ text: string; chunkCount: number; docCount: number }> => {
      const allChunks: EmbeddedChunk[] = [];
      for (const [docId, chunks] of embeddedChunks) {
        if (isStyleRef(docId.replace(/^upload:/, ""))) continue;
        allChunks.push(...chunks);
      }
      if (allChunks.length === 0) {
        return { text: "No large reference documents are indexed for search.", chunkCount: 0, docCount: 0 };
      }
      const relevant = await retrieveRelevantChunks(query, allChunks);
      if (relevant.length === 0) {
        return { text: "No relevant excerpts found for this query.", chunkCount: 0, docCount: 0 };
      }
      const uniqueDocs = new Set(relevant.map((c) => c.docId));
      const text = relevant
        .map((chunk, i) => {
          const role = roleForDoc(chunk.docId.replace(/^upload:/, ""));
          const label = role ? `${role.title} — ${chunk.docTitle}` : chunk.docTitle;
          return `[${i + 1}] (${label}):\n${chunk.text}`;
        })
        .join("\n\n---\n\n");
      return { text, chunkCount: relevant.length, docCount: uniqueDocs.size };
    },
    [embeddedChunks, roleForDoc, isStyleRef],
  );

  // ---------------------------------------------------------------------------
  // Helpers for building BulkEditRequest
  // ---------------------------------------------------------------------------

  const buildReferenceDocTexts = useCallback((): { title: string; text: string }[] => {
    // All documents (reference + user) flow through the unified pipeline.
    // They're included via buildCombinedDocumentText() instead.
    return [];
  }, []);

  const buildCombinedDocumentText = useCallback((): string | undefined => {
    const allDocParts: string[] = [];
    const coveredIds = new Set<string>();

    // docTexts (UUID / generated:* keyed) — filter by committed selection
    const attrs = (id: string, fileName: string) => {
      const role = roleForDoc(id);
      const roleAttrs = role
        ? `role="${escapeXmlAttr(role.id)}" title="${escapeXmlAttr(role.title)}" `
        : "";
      return `${roleAttrs}filename="${escapeXmlAttr(fileName)}"`;
    };

    for (const [id, { fileName, text: txt }] of docTexts.entries()) {
      if (!selectedDocIds.has(id) || isStyleRef(id)) continue;
      allDocParts.push(`<document ${attrs(id, fileName)}>\n${txt}\n</document>`);
      trackWrite(updateLastUsed(id));
      coveredIds.add(id);
    }

    // Truncated previews for large docs that only have embeddings
    const PREVIEW_CHARS = 2000;
    for (const id of selectedDocIds) {
      if (coveredIds.has(id) || isStyleRef(id)) continue;
      const saved = savedDocs.find((d) => d.id === id);
      if (saved?.textContent) {
        const preview = saved.textContent.slice(0, PREVIEW_CHARS);
        const suffix = saved.textContent.length > PREVIEW_CHARS
          ? "\n[… Document continues. Use search_references to find specific content.]"
          : "";
        allDocParts.push(
          `<document ${attrs(id, saved.fileName)} truncated="true" full-length="${saved.charCount}">\n${preview}${suffix}\n</document>`,
        );
        trackWrite(updateLastUsed(id));
      }
    }

    return allDocParts.length > 0 ? allDocParts.join("\n\n") : undefined;
  }, [docTexts, selectedDocIds, savedDocs, roleForDoc, isStyleRef]);

  const buildSourceDocumentRoles = useCallback((): SourceDocumentRole[] => {
    const byRole = new Map<string, string[]>();
    for (const [docId, slotId] of slotAssignments) {
      if (slotId === STYLE_REFERENCE_SLOT.id) continue;
      const name =
        docTexts.get(docId)?.fileName ??
        savedDocs.find((d) => d.id === docId)?.fileName ??
        generatedDocs.get(docId)?.title ??
        docId;
      byRole.set(slotId, [...(byRole.get(slotId) ?? []), name]);
    }
    return slotDefs
      .filter((d) => byRole.has(d.id))
      .map((d) => ({ role: d.id, title: d.title, aiHint: d.ai_hint, filenames: byRole.get(d.id)! }));
  }, [slotAssignments, slotDefs, docTexts, savedDocs, generatedDocs]);

  const resetSelections = useCallback(() => {
    setFiles([]);
    setParsingFiles(new Set());
    setScanningDocIds(new Set());
    setFileErrors(new Map());
    setSelectedDocIds(new Set());
    setDraftDocIds(new Set());
    setSlotByDoc(new Map());
    setDraftSlotByDoc(new Map());
    fileSlotTargetsRef.current = new Map();
    filesRef.current = [];
    setDocTexts(new Map());
    setDocStatuses(new Map());
    setEmbeddedChunks(new Map());
    setEmbeddingProgress(new Map());
    setEmbeddingErrors(new Map());
    setGeneratedDocsState(new Map());
    generatedDocContentRefs.current.clear();
    for (const [key, ver] of generatedEmbedVersionRefs.current) {
      generatedEmbedVersionRefs.current.set(key, ver + 1);
    }
    processedFilesRef.current = new Set();
    setShowCuiWarning(false);
  }, []);

  // ---------------------------------------------------------------------------
  // Attach flow: embed a saved doc, commit the draft selection, resolve CUI warnings
  // ---------------------------------------------------------------------------

  /** Embed one saved doc (large-doc path) and record progress/errors. Shared by
   *  commitDraft() and the endpoint-switch re-embed effect. */
  const embedSavedDoc = useCallback(async (doc: UploadedDocument): Promise<void> => {
    const uploadDocId = `upload:${doc.id}`;
    setEmbeddingProgress((prog) => mapWith(prog, uploadDocId, "Chunking…"));
    try {
      const embedded = await embedAndStoreDocument({
        docId: uploadDocId,
        docTitle: doc.fileName,
        text: doc.textContent,
        onProgress: (msg) => setEmbeddingProgress((prog) => mapWith(prog, uploadDocId, msg)),
      });
      setEmbeddedChunks((chunks) => mapWith(chunks, uploadDocId, embedded));
      setEmbeddingErrors((errs) => mapWithout(errs, doc.id));
    } catch (err) {
      setEmbeddingErrors((errs) => mapWith(errs, doc.id, toAppError(err, { domain: "ai", context: { fileName: doc.fileName } })));
    } finally {
      setEmbeddingProgress((prog) => mapWithout(prog, uploadDocId));
    }
  }, []);

  /** Convert quarantined images for a saved doc and update it in DB. Never re-scans.
   *  Returns the updated doc with fresh textContent and cleared quarantinedImages. */
  const releaseQuarantine = useCallback(async (
    doc: UploadedDocument,
    endpoint: EndpointId,
  ): Promise<UploadedDocument> => {
    if (!doc.quarantinedImages?.length) return doc;

    // Build a ParsedFileStructure-like object for resolveImages
    const images: DocxImageInfo[] = doc.quarantinedImages.map((qi) => ({
      placeholder: qi.placeholder,
      dataUrl: qi.dataUrl,
    }));

    const resolvedText = await resolveImages({
      parsed: { text: doc.textContent, images, standaloneImage: false },
      fileName: doc.fileName,
      endpoint,
    });

    await updateDocumentContent(doc.id, {
      textContent: resolvedText,
      charCount: resolvedText.length,
      quarantinedImages: undefined,
    });

    const updated: UploadedDocument = {
      ...doc,
      textContent: resolvedText,
      charCount: resolvedText.length,
      quarantinedImages: undefined,
    };
    setSavedDocs((prev) => prev.map((d) => (d.id === doc.id ? updated : d)));
    return updated;
  }, []);

  /** Apply the draft selection to the committed selection, close the picker,
   *  and kick off parallel embedding for newly-attached large docs.
   *  Quarantined docs are released (images converted) before embedding.
   *  @param releaseEndpoint — the endpoint to use for quarantine release (when
   *    called from affirmNotCuiAndAttach/switchToCuiAndAttach). */
  const commitDraft = useCallback((releaseEndpoint?: EndpointId) => {
    // A doc leaving the style slot was never loaded as a source, so load it like a new one.
    const leftStyleSlot = (id: string) =>
      slotAssignments.get(id) === STYLE_REFERENCE_SLOT.id && draftSlotAssignments.get(id) !== STYLE_REFERENCE_SLOT.id;
    const added = [...draftDocIds].filter((id) => !selectedDocIds.has(id) || leftStyleSlot(id));
    const removed = [...selectedDocIds].filter((id) => !draftDocIds.has(id));

    for (const id of removed) {
      setDocTexts((texts) => mapWithout(texts, id));
      setEmbeddedChunks((chunks) => mapWithout(chunks, `upload:${id}`));
      setEmbeddingErrors((errs) => mapWithout(errs, id));
      setDocStatuses((prev) => mapWithout(prev, id));
    }

    // Categorise newly-added docs
    const toProcess: { doc: UploadedDocument; hasQuarantine: boolean }[] = [];
    for (const id of added) {
      if (id.startsWith("generated:")) {
        const genDoc = generatedDocs.get(id);
        if (genDoc) {
          setDocStatuses((prev) => mapWith(prev, id, "ready"));
          setDocTexts((texts) =>
            texts.has(id) ? texts : mapWith(texts, id, { fileName: genDoc.title, text: genDoc.text }),
          );
        }
        continue;
      }
      const doc = savedDocs.find((d) => d.id === id);
      if (!doc) continue;
      if (draftSlotAssignments.get(id) === STYLE_REFERENCE_SLOT.id) {
        // Read once for the style note; never put in the prompt or embedded.
        setDocStatuses((prev) => mapWith(prev, id, "ready"));
        continue;
      }
      if (doc.quarantinedImages?.length) {
        // Show spinner while releasing
        setDocStatuses((prev) => mapWith(prev, id, "parsing"));
        setEmbeddingProgress((prog) => mapWith(prog, id, "Extracting images…"));
        toProcess.push({ doc, hasQuarantine: true });
      } else if (doc.charCount < SMALL_DOC_THRESHOLD) {
        setDocTexts((texts) => mapWith(texts, id, { fileName: doc.fileName, text: doc.textContent }));
      } else {
        toProcess.push({ doc, hasQuarantine: false });
      }
    }

    setSelectedDocIds(new Set(draftDocIds));
    setSlotByDoc(new Map(draftSlotAssignments));
    for (const def of slotDefs) {
      if (def.default_reference) settledDefaultSlotsRef.current.add(def.id);
    }
    setShowCuiWarning(false);
    setShowDocPicker(false);

    // Remember each slotted library doc's role so later sessions can label it.
    const roleUpdates = new Map<string, { slotId: string; title: string }>();
    for (const [docId, slotId] of draftSlotAssignments) {
      const doc = savedDocs.find((d) => d.id === docId);
      const def = slotDefs.find((d) => d.id === slotId);
      if (!doc || !def) continue;
      if (doc.slotRole?.slotId === slotId && doc.slotRole.title === def.title) continue;
      const role = { slotId, title: def.title };
      roleUpdates.set(docId, role);
      trackWrite(updateDocumentRole(docId, role));
    }
    if (roleUpdates.size > 0) {
      setSavedDocs((prev) =>
        prev.map((d) => (roleUpdates.has(d.id) ? { ...d, slotRole: roleUpdates.get(d.id) } : d)),
      );
    }

    if (toProcess.length > 0) {
      const ep = releaseEndpoint ?? activeEndpointRef.current;
      mapWithLimit(toProcess, EMBED_CONCURRENCY, async ({ doc, hasQuarantine }) => {
        try {
          let resolvedDoc = doc;
          if (hasQuarantine) {
            resolvedDoc = await releaseQuarantine(doc, ep);
            setEmbeddingProgress((prog) => mapWithout(prog, doc.id));
          }
          if (resolvedDoc.charCount < SMALL_DOC_THRESHOLD) {
            setDocTexts((texts) => mapWith(texts, doc.id, { fileName: resolvedDoc.fileName, text: resolvedDoc.textContent }));
            setDocStatuses((prev) => mapWith(prev, doc.id, "ready"));
          } else {
            setDocStatuses((prev) => mapWith(prev, doc.id, "ready"));
            await embedSavedDoc(resolvedDoc);
          }
        } catch (err) {
          setEmbeddingErrors((errs) => mapWith(errs, doc.id, toAppError(err, { domain: "ai", context: { fileName: doc.fileName } })));
          setEmbeddingProgress((prog) => mapWithout(prog, doc.id));
          setDocStatuses((prev) => mapWith(prev, doc.id, "ready"));
        }
      });
    }
  }, [draftDocIds, selectedDocIds, savedDocs, generatedDocs, embedSavedDoc, releaseQuarantine, draftSlotAssignments, slotAssignments, slotDefs]);

  /** Draft docs that are flagged/scan-error and need resolution before attach. */
  const flaggedDraftDocs = useMemo(
    () => savedDocs.filter((d) => draftDocIds.has(d.id) && isCuiFlagged(d)),
    [savedDocs, draftDocIds],
  );

  const attachBlocked = parsingFiles.size > 0 ||
    scanningDocIds.size > 0 ||
    [...draftDocIds].some((id) => {
      const s = docStatuses.get(id);
      return s === "fetching" || s === "parsing";
    });

  const attachBlockedReason = useMemo(() => {
    if (parsingFiles.size > 0) return "Parsing documents…";
    if (scanningDocIds.size > 0) {
      return `Scanning ${scanningDocIds.size} document${scanningDocIds.size !== 1 ? "s" : ""} for CUI…`;
    }
    const fetching = [...draftDocIds].filter((id) => docStatuses.get(id) === "fetching").length;
    if (fetching > 0) return "Fetching documents…";
    const parsing = [...draftDocIds].filter((id) => docStatuses.get(id) === "parsing").length;
    if (parsing > 0) return "Parsing documents…";
    return null;
  }, [parsingFiles, scanningDocIds, draftDocIds, docStatuses]);

  /** Attempt to attach the draft selection. Opens the CUI warning if anything's flagged. */
  const requestAttach = useCallback(() => {
    if (attachBlocked) return;

    if (activeEndpointRef.current === "cui") {
      // CUI mode: nothing to resolve — mark unresolved docs as cui and commit.
      // Docs already cleared as non-CUI ("clean"/"not-cui") keep that status.
      const toMark = [...draftDocIds]
        .map((id) => savedDocs.find((d) => d.id === id))
        .filter((d): d is UploadedDocument => !!d && isCuiUnresolved(d));
      for (const d of toMark) {
        trackWrite(updateCuiStatus(d.id, "cui"));
      }
      if (toMark.length > 0) {
        const marked = new Set(toMark.map((d) => d.id));
        setSavedDocs((prev) => prev.map((d) => (marked.has(d.id) ? { ...d, cuiStatus: "cui" } : d)));
      }
      commitDraft("cui");
      return;
    }

    const flagged = savedDocs.filter((d) => draftDocIds.has(d.id) && isCuiFlagged(d));
    if (flagged.length > 0) {
      setShowCuiWarning(true);
      return;
    }
    commitDraft();
  }, [attachBlocked, draftDocIds, savedDocs, commitDraft]);

  /** Close the picker without committing draft changes (X / Esc / backdrop). */
  const closePickerDiscard = useCallback(() => {
    setShowCuiWarning(false);
    setShowDocPicker(false);
  }, []);

  /** Close the warning dialog without attaching; the draft and picker stay open. */
  const cancelCuiWarning = useCallback(() => {
    setShowCuiWarning(false);
  }, []);

  /** Mark flagged draft docs "not-cui" and attach. Releases quarantine through IL2. */
  const affirmNotCuiAndAttach = useCallback(() => {
    const flaggedIds = new Set(flaggedDraftDocs.map((d) => d.id));
    for (const id of flaggedIds) {
      trackWrite(updateCuiStatus(id, "not-cui"));
    }
    setSavedDocs((prev) => prev.map((d) => (flaggedIds.has(d.id) ? { ...d, cuiStatus: "not-cui" } : d)));
    commitDraft("non-cui");
  }, [flaggedDraftDocs, commitDraft]);

  /** Switch to the CUI endpoint, mark flagged draft docs "cui", and attach. Releases quarantine through IL5. */
  const switchToCuiAndAttach = useCallback(() => {
    setActiveEndpoint?.("cui");
    const flaggedIds = new Set(flaggedDraftDocs.map((d) => d.id));
    for (const id of flaggedIds) {
      trackWrite(updateCuiStatus(id, "cui"));
    }
    setSavedDocs((prev) => prev.map((d) => (flaggedIds.has(d.id) ? { ...d, cuiStatus: "cui" } : d)));
    commitDraft("cui");
  }, [flaggedDraftDocs, setActiveEndpoint, commitDraft]);

  // ---------------------------------------------------------------------------
  // Unified available docs list (for the picker)
  // ---------------------------------------------------------------------------

  const allAvailableDocs: UnifiedDocItem[] = useMemo(() => {
    const items: UnifiedDocItem[] = [];
    const usedRefIds = new Set<string>();

    // Build set of manifest IDs that are already saved in DB
    const savedRefIds = new Map<string, UploadedDocument>();
    for (const doc of savedDocs) {
      if (doc.refId) savedRefIds.set(doc.refId, doc);
    }

    // Reference docs from manifest
    for (const md of manifestDocs) {
      const savedVersion = savedRefIds.get(md.id);
      usedRefIds.add(md.id);
      items.push({
        id: savedVersion ? savedVersion.id : `ref:${md.id}`,
        title: md.title,
        source: "reference",
        savedDoc: savedVersion,
        manifestDoc: md,
      });
    }

    // User-uploaded docs (excluding ones that are already shown as reference docs)
    for (const doc of savedDocs) {
      if (doc.refId && usedRefIds.has(doc.refId)) continue; // Already shown as a reference doc
      // Cached copy of a reference doc that has since been removed or renamed in the
      // manifest — hide it so stale bundled content doesn't resurface as an upload.
      if (doc.source === "reference" && manifestDocs.length > 0) continue;
      items.push({
        id: doc.id,
        title: doc.fileName,
        source: "upload",
        savedDoc: doc,
      });
    }

    // Sort: reference docs first, then uploaded; within each group by upload time (newest first)
    items.sort((a, b) => {
      const aRef = a.source === "reference" ? 0 : 1;
      const bRef = b.source === "reference" ? 0 : 1;
      if (aRef !== bRef) return aRef - bRef;

      // Within same group, sort by upload time (newest first)
      const aTime = a.savedDoc ? new Date(a.savedDoc.createdAt).getTime() : 0;
      const bTime = b.savedDoc ? new Date(b.savedDoc.createdAt).getTime() : 0;
      return bTime - aTime;
    });

    // Generated documents (from Preview page) — always shown first
    const genEntries = [...generatedDocs.values()];
    for (let i = genEntries.length - 1; i >= 0; i--) {
      items.unshift({
        id: genEntries[i].id,
        title: `Generated: ${genEntries[i].title}`,
        source: "generated",
      });
    }

    return items;
  }, [manifestDocs, savedDocs, generatedDocs]);

  // ---------------------------------------------------------------------------
  // Endpoint-aware filtering: hide CUI-uploaded docs in Proprietary mode
  // ---------------------------------------------------------------------------

  const currentEndpoint = activeEndpoint;

  const { filteredAvailableDocs, hiddenCuiDocCount } = useMemo(() => {
    if (currentEndpoint === "cui") {
      // CUI mode sees everything
      return { filteredAvailableDocs: allAvailableDocs, hiddenCuiDocCount: 0 };
    }
    // Proprietary mode hides CUI-status library docs that aren't attached.
    // Attached CUI docs stay visible — they show as an attachment error so
    // the user can remove them (rather than vanishing silently).
    let hidden = 0;
    const visible = allAvailableDocs.filter((item) => {
      if (item.savedDoc?.cuiStatus === "cui" && !selectedDocIds.has(item.id)) {
        hidden++;
        return false;
      }
      return true;
    });
    return { filteredAvailableDocs: visible, hiddenCuiDocCount: hidden };
  }, [allAvailableDocs, currentEndpoint, selectedDocIds]);

  // ---------------------------------------------------------------------------
  // Derived state
  // ---------------------------------------------------------------------------

  const setupDocuments: SelectedDocument[] = useMemo(() => {
    const docs: SelectedDocument[] = [];

    for (const id of selectedDocIds) {
      const genDoc = generatedDocs.get(id);
      const role = roleForDoc(id);
      const roleFields = role ? { roleId: role.id, roleTitle: role.title } : {};
      if (id.startsWith("generated:") && genDoc) {
        docs.push({ id, name: `Generated: ${genDoc.title}`, source: "generated", ...roleFields });
        continue;
      }
      if (id.startsWith("ref:")) {
        // ref: entries are still fetching/parsing — they're already shown as
        // file-parsing chips, so skip them here to avoid duplicates.
        // They'll appear here once processing completes and the ID swaps to a UUID.
        continue;
      }

      const entry = docTexts.get(id);
      const savedDoc = savedDocs.find((d) => d.id === id);
      const name = entry?.fileName ?? savedDoc?.fileName ?? id;
      const source = savedDoc?.source === "reference" ? "reference" : "saved";
      docs.push({ id, name, source, uploadEndpoint: savedDoc?.uploadEndpoint, ...roleFields });
    }
    return docs;
  }, [selectedDocIds, docTexts, savedDocs, generatedDocs, roleForDoc]);

  const documentCount = selectedDocIds.size + files.length;
  const isParsing = parsingFiles.size > 0;

  // ---------------------------------------------------------------------------
  // Attachment errors: embedding/fetch failures plus CUI-in-IL2 conflicts,
  // for every currently-attached (committed) document.
  // ---------------------------------------------------------------------------

  const attachmentErrors: Map<string, AppError> = useMemo(() => {
    const errors = new Map<string, AppError>();
    for (const id of selectedDocIds) {
      const embedErr = embeddingErrors.get(id) ?? embeddingErrors.get(`upload:${id}`);
      if (embedErr) {
        errors.set(id, embedErr);
        continue;
      }
      if (activeEndpoint !== "cui") {
        const savedDoc = savedDocs.find((d) => d.id === id);
        if (savedDoc?.cuiStatus === "cui") {
          errors.set(id, appError("ai.cui-in-proprietary", { context: { fileName: savedDoc.fileName } }));
        }
      }
    }
    return errors;
  }, [selectedDocIds, embeddingErrors, activeEndpoint, savedDocs]);

  // ---------------------------------------------------------------------------
  // Document readiness (are all attached docs fully processed and error-free?)
  // ---------------------------------------------------------------------------

  const { docsReady, docsProcessingStatus } = useMemo(() => {
    if (parsingFiles.size > 0) {
      return { docsReady: false, docsProcessingStatus: "Parsing documents…" };
    }
    if (embeddingProgress.size > 0) {
      return { docsReady: false, docsProcessingStatus: "Embedding documents…" };
    }
    for (const id of selectedDocIds) {
      const status = docStatuses.get(id);
      if (status === "fetching") {
        return { docsReady: false, docsProcessingStatus: "Fetching documents…" };
      }
      if (status === "parsing") {
        return { docsReady: false, docsProcessingStatus: "Parsing documents…" };
      }
    }
    if (attachmentErrors.size > 0) {
      return { docsReady: false, docsProcessingStatus: "Remove or replace documents with errors to continue." };
    }
    return { docsReady: true, docsProcessingStatus: null };
  }, [parsingFiles, embeddingProgress, selectedDocIds, docStatuses, attachmentErrors]);

  // ---------------------------------------------------------------------------
  // Re-embed attached large docs on endpoint switch. IL2 and IL5 use different
  // embedding models, so cross-endpoint vectors are meaningless — embedSavedDoc's
  // cache check (sourceHash + model) naturally forces a re-embed here. CUI-status
  // docs are skipped in IL2 (they're an attachment error, not embeddable there).
  // ---------------------------------------------------------------------------

  useEffect(() => {
    for (const id of selectedDocIds) {
      const doc = savedDocs.find((d) => d.id === id);
      if (!doc || doc.charCount < SMALL_DOC_THRESHOLD) continue;
      if (activeEndpoint !== "cui" && doc.cuiStatus === "cui") continue;
      if (isStyleRef(id)) continue;
      embedSavedDoc(doc);
    }
    for (const [id, genDoc] of generatedDocs) {
      if (!selectedDocIds.has(id) || genDoc.text.length < SMALL_DOC_THRESHOLD) continue;
      setEmbeddingProgress((prog) => mapWith(prog, id, "Chunking…"));
      embedAndStoreDocument({
        docId: id,
        docTitle: genDoc.title,
        text: genDoc.text,
        onProgress: (msg) => setEmbeddingProgress((prog) => mapWith(prog, id, msg)),
      })
        .then((embedded) => setEmbeddedChunks((chunks) => mapWith(chunks, id, embedded)))
        .catch((err) => {
          setEmbeddingErrors((errs) => mapWith(errs, id, toAppError(err, { domain: "ai", context: { fileName: genDoc.title } })));
        })
        .finally(() => setEmbeddingProgress((prog) => mapWithout(prog, id)));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeEndpoint]);

  // ---------------------------------------------------------------------------
  // Generated document indexing (for RAG-based document review)
  // ---------------------------------------------------------------------------

  const indexGeneratedDocument = useCallback(
    async (
      docId: string,
      title: string,
      text: string,
      onProgress?: (message: string) => void,
    ): Promise<boolean> => {
      try {
        const chunks = await embedAndStoreDocument({
          docId,
          docTitle: title,
          text,
          onProgress,
        });
        setEmbeddedChunks((prev) => {
          const next = new Map(prev);
          next.set(docId, chunks);
          return next;
        });
        return true;
      } catch (err) {
        console.error("Failed to index generated document:", err);
        return false;
      }
    },
    [],
  );

  const removeGeneratedDocumentIndex = useCallback((docId: string) => {
    setEmbeddedChunks((prev) => {
      if (!prev.has(docId)) return prev;
      const next = new Map(prev);
      next.delete(docId);
      return next;
    });
  }, []);

  return {
    files,
    setFiles,
    parsingFiles,
    fileErrors,
    availableDocs: filteredAvailableDocs,
    selectedDocIds,
    draftDocIds,
    toggleDraftDoc,
    slotDefs,
    draftSlotAssignments,
    slotAssignments,
    assignDraftSlot,
    unassignDraftSlot,
    addFiles,
    scanningDocIds,
    docStatuses,
    embeddingProgress,
    embeddingErrors,
    attachmentErrors,
    showDocPicker,
    setShowDocPicker,
    attachBlocked,
    attachBlockedReason,
    requestAttach,
    closePickerDiscard,
    setupDocuments,
    documentCount,
    isParsing,
    handleToggleDoc,
    handleRemoveDocument,
    handleDeleteDocument,
    handleSearchReferences,
    buildReferenceDocTexts,
    buildCombinedDocumentText,
    buildSourceDocumentRoles,
    styleReferenceDocs,
    styleReferencesWithheld,
    resetSelections,
    docsReady,
    docsProcessingStatus,
    indexGeneratedDocument,
    removeGeneratedDocumentIndex,
    setGeneratedDocument,
    removeGeneratedDocument,
    generatedDocIds: [...generatedDocs.values()].map((d) => d.id),
    hiddenCuiDocCount,
    // CUI
    showCuiWarning,
    flaggedDraftDocs,
    cancelCuiWarning,
    affirmNotCuiAndAttach,
    switchToCuiAndAttach,
  };
}
