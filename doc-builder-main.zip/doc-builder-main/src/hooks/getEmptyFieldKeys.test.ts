import { describe, it, expect } from "vitest";
import { getEmptyFieldKeys } from "./useAiChat";
import type { DocumentSchema } from "../schemas/types";
import type { ProposedChange } from "../ai/bulkEdit";

const schema = {
  id: "test-doc",
  title: "Test Document",
  sections: [
    {
      id: "main",
      title: "Main",
      fields: [
        { id: "name", label: "Name", type: "string" },
        { id: "narrative", label: "Narrative", type: "freetext" },
        { id: "figure", label: "Figure", type: "image" },
        { id: "total", label: "Total", type: "number", formula: "1", format: "currency" },
        { id: "alias", label: "Alias", type: "string", same_as: "main.name" },
      ],
    },
    {
      id: "other",
      title: "Other",
      fields: [{ id: "notes", label: "Notes", type: "freetext" }],
    },
  ],
  output_template: "",
} as unknown as DocumentSchema;

const proposal = (fieldKey: string) => ({ fieldKey }) as ProposedChange;

describe("getEmptyFieldKeys", () => {
  it("reports only fields the model can fill — skips image, computed, and linked fields", () => {
    const keys = getEmptyFieldKeys(schema, ["main"], {}, []).map((f) => f.key);
    expect(keys).toEqual(["main.name", "main.narrative"]);
  });

  it("excludes fields with an existing answer or a pending proposal", () => {
    const keys = getEmptyFieldKeys(
      schema,
      ["main", "other"],
      { "main.name": "Acme" },
      [proposal("main.narrative")],
    ).map((f) => f.key);
    expect(keys).toEqual(["other.notes"]);
  });

  it("treats an empty-string answer as empty", () => {
    const keys = getEmptyFieldKeys(schema, ["main"], { "main.name": "" }, []).map((f) => f.key);
    expect(keys).toContain("main.name");
  });

  it("only checks the focused field in field-scope mode", () => {
    const keys = getEmptyFieldKeys(schema, ["main"], {}, [], "main.narrative").map((f) => f.key);
    expect(keys).toEqual(["main.narrative"]);
  });

  it("returns each field's type", () => {
    const fields = getEmptyFieldKeys(schema, ["main"], {}, []);
    expect(fields.map((f) => f.type)).toEqual(["string", "freetext"]);
  });

  it("returns nothing when the focused field is an image", () => {
    expect(getEmptyFieldKeys(schema, ["main"], {}, [], "main.figure")).toEqual([]);
  });
});
