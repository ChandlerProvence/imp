import { trackWrite } from "../db/writeStatus";
import { useCallback, useEffect, useRef, useState } from "react";
import { appError, toAppError, type AppError } from "../errors";
import type { DocumentSchema } from "../schemas/types";
import type { LiteLLMMessage, ResponseStep, ResponseTimings, ToolCall, ToolDefinition } from "../ai/types";
import type { BulkEditRequest, ProposedChange } from "../ai/bulkEdit";
import type { DetectedObservation } from "../ai/observationTypes";
import type { PendingQuestion, QuestionAnswer } from "../ai/askUserTypes";
import {
  parseAskUserArgs,
  formatAnswersToolResult,
  findPendingAskUser,
} from "../ai/askUserTypes";
import {
  parseBulkEditResponse,
  accumulateChanges,
} from "../ai/bulkEdit";
import { streamChatCompletion } from "../ai/litellm";
import { extractProposedChangesJson } from "../ai/parseProposedChanges";
import { addMessage, getConversation, upsertConversation } from "../db/chatHistory";
import type { ChatMessage } from "../db/types";
import type { AiScope } from "../ai/unifiedPrompt";
import type { EffortTier } from "../ai/effortTiers";
import { resolveEffortConfig } from "../ai/effortTiers";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface AiChatMessage {
  id: string;
  role: "user" | "assistant" | "tool";
  content: string;
  /** Short display label for long user messages (e.g., "Uploaded contract.pdf"). */
  displayLabel?: string;
  /** Tool calls made by the assistant (for API conversation history). */
  toolCalls?: ToolCall[];
  /** For tool messages: the tool_call_id this responds to. */
  toolCallId?: string;
  /** Timing breakdown (only present on the final assistant message of a response). */
  timings?: ResponseTimings;
}

/** Create a tool-result message for the AI conversation. */
function createToolResultMessage(toolCallId: string, content: string): AiChatMessage {
  return { id: crypto.randomUUID(), role: "tool", content, toolCallId };
}

/** Parse a tool call's JSON arguments; `null` when the model sent malformed JSON. */
function parseToolArgs<T>(call: ToolCall): T | null {
  try {
    return JSON.parse(call.function.arguments) as T;
  } catch {
    return null;
  }
}

function invalidArgsResult(call: ToolCall): AiChatMessage {
  return createToolResultMessage(call.id, JSON.stringify({
    error: `Could not parse arguments for "${call.function.name}" — send valid JSON matching the tool schema.`,
  }));
}

/**
 * Build a validated LiteLLM message array from chat messages.
 *
 * Ensures every tool_use has a matching tool_result (strips orphaned tool_calls
 * to avoid Bedrock "Expected toolResult" errors) and removes orphaned tool
 * messages with no matching assistant tool_call.
 */
function buildApiMessages(
  chatMessages: AiChatMessage[],
  systemPrompt: string,
): LiteLLMMessage[] {
  const mapped: LiteLLMMessage[] = chatMessages.map((m) => {
    const content = m.role === "assistant" && m.toolCalls && !m.content ? null : m.content;
    const msg: LiteLLMMessage = { role: m.role as LiteLLMMessage["role"], content };
    if (m.toolCalls) msg.tool_calls = m.toolCalls;
    if (m.toolCallId) msg.tool_call_id = m.toolCallId;
    return msg;
  });

  // Strip tool_calls without matching tool results
  const toolResultIds = new Set(
    mapped.filter((m) => m.role === "tool" && m.tool_call_id).map((m) => m.tool_call_id!),
  );
  for (const msg of mapped) {
    if (msg.role === "assistant" && msg.tool_calls) {
      const allHaveResults = msg.tool_calls.every((tc) => toolResultIds.has(tc.id));
      if (!allHaveResults) {
        const matched = msg.tool_calls.filter((tc) => toolResultIds.has(tc.id));
        msg.tool_calls = matched.length > 0 ? matched : undefined;
      }
    }
  }

  // Remove orphaned tool messages
  const assistantToolCallIds = new Set(
    mapped.filter((m) => m.tool_calls).flatMap((m) => m.tool_calls!.map((tc) => tc.id)),
  );
  return [
    { role: "system", content: systemPrompt },
    ...mapped.filter((m) => m.role !== "tool" || assistantToolCallIds.has(m.tool_call_id!)),
  ];
}

/** Options that can be passed per-message to override default behavior. */
export interface SendMessageOptions {
  // Reserved for future per-message options.
}

export interface UseAiChatOptions {
  /** Session ID for persisting conversation to IndexedDB. */
  sessionId: string;
  /** Field key for this conversation in IndexedDB (e.g., "__bulk_edit:<uuid>"). */
  conversationKey: string;
  /** Document type schema. */
  schema: DocumentSchema;
  /** Builds the system prompt for the LLM call. Called on each send. */
  buildSystemPrompt: () => string;
  /** Tool definitions to send with each request. */
  tools: ToolDefinition[];
  /** BulkEditRequest used for parsing proposed changes (field validation, coercion). */
  request: BulkEditRequest;
  /** Callback to handle search_references tool calls. Returns text content for the tool result. */
  onSearchReferences?: (query: string) => Promise<{ text: string; chunkCount: number; docCount: number }>;
  /** Callback to handle get_field_info tool calls. Returns formatted field info text. */
  onGetFieldInfo?: (args: { section_ids?: string[]; include_answers?: boolean; include_outline?: boolean }) => string;
  /** Callback to handle get_template_context tool calls. Returns template text around a field/line/search. */
  onGetTemplateContext?: (args: {
    schema_id?: string;
    field_key?: string;
    from_line?: number;
    search?: string;
    lines?: number;
  }) => Promise<string>;
  /** Called whenever accumulated proposed changes are updated. */
  onChangesUpdate?: (changes: ProposedChange[]) => void;
  /** Called whenever detected observations are updated. */
  onObservationsUpdate?: (observations: DetectedObservation[]) => void;
  /** Conversation type label for persistence. */
  conversationType?: "field-chat" | "bulk-edit";
  /** Initial user message to auto-send on mount (if no existing conversation). */
  initialMessage?: { content: string; displayLabel?: string };
  /** AI scope — determines which sections/fields are in context. */
  scope?: AiScope;
  /** User-selected effort tier. Defaults to "medium" (Sonnet, medium effort). */
  effortTier?: EffortTier;
  /** Whether the first message is an extraction (forces tool use). */
  isExtraction?: boolean;
}

export interface UseAiChatReturn {
  messages: AiChatMessage[];
  isStreaming: boolean;
  streamingContent: string | null;
  isSearching: boolean;
  retrievalMeta: { chunkCount: number; docCount: number } | null;
  error: AppError | null;
  accumulatedChanges: ProposedChange[];
  setAccumulatedChanges: React.Dispatch<React.SetStateAction<ProposedChange[]>>;
  detectedObservations: DetectedObservation[];
  clearObservations: () => void;
  /** A pending `ask_user` question awaiting the user's answer, if any. */
  pendingQuestion: PendingQuestion | null;
  /** Answer the pending question, resuming the conversation. */
  answerQuestion: (answers: QuestionAnswer[]) => void;
  /** Send a user follow-up message. */
  sendMessage: (text: string, displayLabel?: string, options?: SendMessageOptions) => void;
  /** Abort the in-flight stream. */
  stopStreaming: () => void;
  /** Inject a document notification as a user message and auto-send. */
  injectDocumentNotification: (notification: { id: string; content: string; displayLabel: string }) => void;
  /** True while a tool-call → tool-result → continuation cycle is active. */
  isToolCycleActive: boolean;
  /** True while the model is in its "thinking" phase (extended thinking). */
  isThinking: boolean;
  /** Steps completed so far in the current response (live, for real-time display). */
  completedSteps: ResponseStep[];
  /** The kind of step currently in-flight (null if idle). */
  activeStepKind: ResponseStep["kind"] | null;
}

// ---------------------------------------------------------------------------
// Field-gap detection
// ---------------------------------------------------------------------------

/** Field types the model drafts even without a source stating the value. */
/**
 * Field types the model must always draft, even when no source covers them.
 * Tables are deliberately excluded: every table in the FMS schemas is a fact
 * table (parts lists, mod logs), where an invented row is worse than an
 * empty one. Compose-style tables return via the two-stance plan's `ai_mode`.
 */
const DRAFTABLE_FIELD_TYPES = new Set(["freetext"]);

/** Tool-result instruction sent while draftable fields in scope are still empty. */
function continueDraftingMessage(count: number): string {
  return (
    `${count} freetext field${count !== 1 ? "s" : ""} in scope ${count !== 1 ? "are" : "is"} still empty: ` +
    "call `propose_changes` again for them (a few per call) before you finish. " +
    "Fields under fields_awaiting_source_facts may stay empty if no source states a value."
  );
}

/**
 * Return in-scope fields that have no existing answer AND no proposed change.
 * Used to inform the model of remaining gaps so it doesn't skip fields.
 * Excludes fields the model can never fill (linked, computed, image uploads) —
 * listing those as "still empty" invites the model to stop and explain.
 */
export function getEmptyFieldKeys(
  schema: DocumentSchema,
  selectedSectionIds: string[],
  currentAnswers: Record<string, string | number | boolean>,
  proposedChanges: ProposedChange[],
  /** When scope is a single field, only check that field — not the whole section. */
  focusFieldKey?: string,
): { key: string; label: string; type: string }[] {
  const proposedKeys = new Set(proposedChanges.map((c) => c.fieldKey));
  const empty: { key: string; label: string; type: string }[] = [];
  for (const section of schema.sections) {
    if (!selectedSectionIds.includes(section.id)) continue;
    for (const field of section.fields) {
      if (field.same_as || field.formula !== undefined || field.type === "image") continue;
      const key = `${section.id}.${field.id}`;
      // In field-scope mode, only check the focused field
      if (focusFieldKey && key !== focusFieldKey) continue;
      const answer = currentAnswers[key];
      const hasAnswer = answer !== undefined && answer !== "";
      const hasProposal = proposedKeys.has(key);
      if (!hasAnswer && !hasProposal) {
        empty.push({ key, label: field.label, type: field.type });
      }
    }
  }
  return empty;
}

// ---------------------------------------------------------------------------
// Hook
// ---------------------------------------------------------------------------

export function useAiChat({
  sessionId,
  conversationKey,
  schema,
  buildSystemPrompt,
  tools,
  request,
  onSearchReferences,
  onGetFieldInfo,
  onGetTemplateContext,
  onChangesUpdate,
  onObservationsUpdate,
  conversationType = "bulk-edit",
  initialMessage,
  scope = { type: "document" },
  effortTier = "medium",
  isExtraction = false,
}: UseAiChatOptions): UseAiChatReturn {
  const [messages, setMessages] = useState<AiChatMessage[]>([]);
  const [streamingContent, setStreamingContent] = useState<string | null>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const [retrievalMeta, setRetrievalMeta] = useState<{ chunkCount: number; docCount: number } | null>(null);
  const [error, setError] = useState<AppError | null>(null);
  const [accumulatedChanges, setAccumulatedChanges] = useState<ProposedChange[]>([]);
  const accumulatedChangesRef = useRef<ProposedChange[]>([]);
  const [detectedObservations, setDetectedObservations] = useState<DetectedObservation[]>([]);
  const [pendingQuestion, setPendingQuestion] = useState<PendingQuestion | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const streamingContentRef = useRef<string | null>(null);

  // Generation counter — incremented each time sendToLLM is called.
  // Callbacks from a previous generation are ignored (stale stream protection).
  const generationRef = useRef(0);

  // ---------------------------------------------------------------------------
  // Response timing instrumentation
  // ---------------------------------------------------------------------------
  interface TimingState {
    responseStartedAt: number;
    steps: ResponseStep[];
    currentStepStartedAt: number | null;
    currentStepKind: ResponseStep["kind"] | null;
    currentStepLabel?: string;
    /** Token usage accumulated across this sequence's LLM calls. */
    usage?: ResponseTimings["usage"];
    /** Usage of the latest call only; attached to the message that call produced. */
    lastCallUsage?: ResponseTimings["callUsage"];
  }
  const timingRef = useRef<TimingState | null>(null);

  // Live step state — exposed to the UI for real-time activity display
  const [completedSteps, setCompletedSteps] = useState<ResponseStep[]>([]);
  const [activeStepKind, setActiveStepKind] = useState<ResponseStep["kind"] | null>(null);

  /** Finish the current in-progress timing step and push it to the steps array. */
  function finishCurrentStep() {
    const t = timingRef.current;
    if (!t || t.currentStepStartedAt === null || t.currentStepKind === null) return;
    const step: ResponseStep = {
      kind: t.currentStepKind,
      durationMs: Math.round(performance.now() - t.currentStepStartedAt),
      label: t.currentStepLabel,
    };
    t.steps.push(step);
    setCompletedSteps((prev) => [...prev, step]);
    setActiveStepKind(null);
    t.currentStepStartedAt = null;
    t.currentStepKind = null;
    t.currentStepLabel = undefined;
  }

  // True while the model is in a tool-call → tool-result → continuation cycle.
  const toolCycleActiveRef = useRef(false);



  // Notify parent of accumulated changes
  useEffect(() => {
    onChangesUpdate?.(accumulatedChanges);
    accumulatedChangesRef.current = accumulatedChanges;
  }, [accumulatedChanges, onChangesUpdate]);

  // Notify parent of detected observations
  useEffect(() => {
    onObservationsUpdate?.(detectedObservations);
  }, [detectedObservations, onObservationsUpdate]);

  // Persist a message to IndexedDB (fire-and-forget).
  const createdAtLabel = useRef(
    new Date().toLocaleString(undefined, {
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "2-digit",
    }),
  );
  const persistMessage = useCallback(
    (msg: AiChatMessage) => {
      trackWrite(addMessage({
        sessionId,
        fieldKey: conversationKey,
        role: msg.role,
        content: msg.content,
        displayLabel: msg.displayLabel,
        toolCalls: msg.toolCalls,
        toolCallId: msg.toolCallId,
        timings: msg.timings,
      }).then(() =>
        upsertConversation({
          sessionId,
          fieldKey: conversationKey,
          documentTypeId: schema.id,
          documentTypeTitle: schema.title,
          label: createdAtLabel.current,
          conversationType,
        }),
      ));
    },
    [sessionId, conversationKey, schema.id, schema.title, conversationType],
  );

  // Ref to always access the latest sendToLLM from recursive calls inside
  // setMessages callbacks, avoiding stale closures.
  const sendToLLMRef = useRef<(allMessages: AiChatMessage[]) => void>(() => {});

  // Core LLM send function
  const sendToLLM = useCallback(
    (allMessages: AiChatMessage[]) => {
      // Abort any in-flight stream before starting a new one
      if (abortRef.current) {
        abortRef.current.abort();
        abortRef.current = null;
      }

      // Increment generation — callbacks from previous generations will be discarded
      const thisGeneration = ++generationRef.current;

      setError(null);
      setIsStreaming(true);
      setStreamingContent("");
      streamingContentRef.current = "";

      const systemPrompt = buildSystemPrompt();
      const apiMessages = buildApiMessages(allMessages, systemPrompt);

      // Resolve model/effort/thinking from tier (extraction forces "low")
      const config = resolveEffortConfig(isExtraction ? "low" : effortTier);

      const effectiveToolChoice = isExtraction
        ? { type: "tool" as const, name: "propose_changes" }
        : ("auto" as const);

      abortRef.current = streamChatCompletion(
        apiMessages,
        {
          onToken(token) {
            if (generationRef.current !== thisGeneration) return;
            setIsThinking(false); // Text started — thinking phase is over
            // Start a "generating" timing step on first token (if not already active)
            if (timingRef.current && timingRef.current.currentStepKind !== "generating") {
              finishCurrentStep();
              timingRef.current.currentStepStartedAt = performance.now();
              timingRef.current.currentStepKind = "generating";
              setActiveStepKind("generating");
            }
            setStreamingContent((prev) => {
              const next = (prev ?? "") + token;
              streamingContentRef.current = next;
              return next;
            });
          },
          onThinking() {
            if (generationRef.current !== thisGeneration) return;
            setIsThinking(true);
            // Start a "thinking" timing step
            if (timingRef.current) {
              finishCurrentStep();
              timingRef.current.currentStepStartedAt = performance.now();
              timingRef.current.currentStepKind = "thinking";
              setActiveStepKind("thinking");
            }
          },
          onThinkingDone() {
            if (generationRef.current !== thisGeneration) return;
            setIsThinking(false);
            finishCurrentStep();
          },
          onUsage(usage) {
            if (generationRef.current !== thisGeneration || !timingRef.current) return;
            // promptTokens tracks the latest call (current context size);
            // completionTokens accumulates across the sequence's tool-cycle calls.
            const prev = timingRef.current.usage;
            timingRef.current.usage = {
              promptTokens: usage.promptTokens,
              completionTokens: (prev?.completionTokens ?? 0) + usage.completionTokens,
              cacheReadTokens: usage.cacheReadTokens ?? prev?.cacheReadTokens ?? 0,
            };
            timingRef.current.lastCallUsage = {
              promptTokens: usage.promptTokens,
              completionTokens: usage.completionTokens,
              cacheReadTokens: usage.cacheReadTokens ?? 0,
              cacheCreationTokens: usage.cacheCreationTokens ?? 0,
            };
          },
          onDone(fullText) {
            if (generationRef.current !== thisGeneration) return;
            setIsStreaming(false);
            setIsThinking(false);
            toolCycleActiveRef.current = false;
            setStreamingContent(null);
            streamingContentRef.current = null;

            // Finalize timing
            finishCurrentStep();
            const timings: ResponseTimings | undefined = timingRef.current
              ? {
                  totalMs: Math.round(performance.now() - timingRef.current.responseStartedAt),
                  steps: timingRef.current.steps,
                  usage: timingRef.current.usage,
                  callUsage: timingRef.current.lastCallUsage,
                }
              : undefined;
            timingRef.current = null;
            // Clear live step state (timings are persisted on the message)
            setCompletedSteps([]);
            setActiveStepKind(null);

            const assistantMsg: AiChatMessage = {
              id: crypto.randomUUID(),
              role: "assistant",
              content: fullText,
              timings,
            };
            setMessages((prev) => [...prev, assistantMsg]);
            persistMessage(assistantMsg);

            // Legacy fallback: extract <proposed-changes> XML if model didn't use tool
            const json = extractProposedChangesJson(fullText);
            if (json) {
              try {
                const { changes } = parseBulkEditResponse(json, request);
                setAccumulatedChanges((prev) => accumulateChanges(prev, changes));
              } catch {
                setError(appError("ai.bad-response", { context: { what: "field proposals" } }));
              }
            }

          },
          onToolCalls(calls: ToolCall[], meta) {
            if (generationRef.current !== thisGeneration) return;
            toolCycleActiveRef.current = true;
            setIsStreaming(false);
            // Finish the "generating" step, start "tool_processing"
            finishCurrentStep();
            if (timingRef.current) {
              timingRef.current.currentStepStartedAt = performance.now();
              timingRef.current.currentStepKind = "tool_processing";
              setActiveStepKind("tool_processing");
            }
            const preToolText = streamingContentRef.current ?? "";
            setStreamingContent(null);
            streamingContentRef.current = null;

            // Snapshot accumulated steps onto this intermediate message, then reset
            const stepsBeforeThisMsg = timingRef.current ? [...timingRef.current.steps] : [];
            const callUsage = timingRef.current?.lastCallUsage;
            if (timingRef.current) {
              timingRef.current.steps = [];
              timingRef.current.lastCallUsage = undefined;
            }
            setCompletedSteps([]);

            // Record assistant message with ALL tool calls + steps that preceded it
            const assistantMsg: AiChatMessage = {
              id: crypto.randomUUID(),
              role: "assistant",
              content: preToolText,
              toolCalls: calls,
              timings: stepsBeforeThisMsg.length > 0 || callUsage
                ? { steps: stepsBeforeThisMsg, ...(callUsage ? { callUsage } : {}) }
                : undefined,
            };
            persistMessage(assistantMsg);
            setMessages((prev) => [...prev, assistantMsg]);

            // Process each tool call and collect results
            const toolResults: AiChatMessage[] = [];
            const searchPromises: Promise<AiChatMessage>[] = [];
            const toolSummaryParts: string[] = [];
            // Set when an ask_user call is parsed — pauses the tool cycle until answered.
            let askedQuestion: PendingQuestion | null = null;

            for (const call of calls) {
              if (call.function.name === "ask_user") {
                const questions = parseAskUserArgs(call.function.arguments);
                if (questions) {
                  askedQuestion = { toolCallId: call.id, questions };
                  toolSummaryParts.push(`Asked ${questions.length} question${questions.length !== 1 ? "s" : ""}`);
                } else {
                  toolResults.push(
                    createToolResultMessage(call.id, JSON.stringify({
                      error: "Could not parse questions. Provide 1-4 questions, each with a header, question text, and 2-6 options.",
                    })),
                  );
                }
              } else if (call.function.name === "propose_changes") {
                let parsedChanges: ProposedChange[] = [];
                let actionableSkips: { key: string; reason: string }[] = [];
                // When the stream hit the output cap, only the LAST tool call can
                // be clipped, and within it the LAST key is the partial one. The
                // SDK partial-parses truncated JSON into a complete-looking object,
                // so we must drop that trailing key or we'd persist a corrupt value.
                const truncatedHere = meta?.stopReason === "max_tokens" && call === calls[calls.length - 1];
                let droppedField: string | undefined;
                try {
                  const args = JSON.parse(call.function.arguments) as { changes: Record<string, unknown> };
                  const changesObj = args.changes ?? {};
                  if (truncatedHere) {
                    droppedField = Object.keys(changesObj).at(-1);
                    if (droppedField) delete changesObj[droppedField];
                  }
                  const changesJson = JSON.stringify(changesObj);
                  const { changes, skipped } = parseBulkEditResponse(changesJson, request);
                  parsedChanges = changes;
                  setAccumulatedChanges((prev) => accumulateChanges(prev, changes));
                  toolSummaryParts.push(`Proposed ${changes.length} change${changes.length !== 1 ? "s" : ""}`);
                  // Non-actionable skips (identical value, linked/computed) are expected — don't surface them
                  actionableSkips = skipped
                    .filter((s) => s.reason !== "identical to current value" && s.reason !== "linked/computed field (auto-filled)")
                    .map((s) => ({ key: s.fieldKey, reason: s.reason }));
                } catch {
                  setError(appError("ai.bad-response", { context: { what: "proposed field changes" } }));
                  toolSummaryParts.push("Proposed changes");
                }
                // Compute remaining empty fields so the model knows what's still missing
                const allProposed = [...accumulatedChangesRef.current, ...parsedChanges];
                const focusFieldKey = scope.type === "field" ? scope.fieldKey : undefined;
                const emptyFields = getEmptyFieldKeys(
                  request.schema,
                  request.selectedSectionIds,
                  request.currentAnswers,
                  allProposed,
                  focusFieldKey,
                );
                // Narrative fields can always be drafted; other fields (including
                // tables) need a stated fact and may legitimately stay empty.
                const toDraft = emptyFields.filter((f) => DRAFTABLE_FIELD_TYPES.has(f.type)).map((f) => f.key);
                const awaitingFacts = emptyFields.filter((f) => !DRAFTABLE_FIELD_TYPES.has(f.type)).map((f) => f.key);
                const received = actionableSkips.length > 0
                  ? `${parsedChanges.length} change${parsedChanges.length !== 1 ? "s" : ""} applied. ${actionableSkips.length} entr${actionableSkips.length !== 1 ? "ies" : "y"} skipped (see skipped_entries).`
                  : `${parsedChanges.length} change${parsedChanges.length !== 1 ? "s" : ""} received and displayed to user.`;
                const resultPayload: Record<string, unknown> = {
                  status: "ok",
                  message: toDraft.length > 0 ? `${received} ${continueDraftingMessage(toDraft.length)}` : received,
                };
                if (actionableSkips.length > 0) {
                  resultPayload.skipped_entries = actionableSkips;
                }
                if (toDraft.length > 0) {
                  resultPayload.fields_to_draft = toDraft;
                  resultPayload.fields_to_draft_count = toDraft.length;
                }
                if (awaitingFacts.length > 0) {
                  resultPayload.fields_awaiting_source_facts = awaitingFacts;
                }
                if (truncatedHere) {
                  resultPayload.truncated = true;
                  if (droppedField) resultPayload.dropped_field = droppedField;
                  resultPayload.message =
                    `${received} Your output hit the length limit` +
                    `${droppedField ? ` and the last field ("${droppedField}") was dropped as incomplete` : ""}. ` +
                    `Re-propose any dropped field, and use smaller batches so your output isn't truncated.` +
                    (toDraft.length > 0 ? ` ${continueDraftingMessage(toDraft.length)}` : "");
                }
                toolResults.push(
                  createToolResultMessage(call.id, JSON.stringify(resultPayload)),
                );
              } else if (call.function.name === "report_observations") {
                try {
                  const args = JSON.parse(call.function.arguments) as {
                    observations: Array<{
                      type: string;
                      topic: string;
                      field_key?: string | null;
                      severity: string;
                      description: string;
                      sources: Array<{ document: string; value: string; excerpt?: string }>;
                      recommendation?: string;
                    }>;
                  };
                  const parsed: DetectedObservation[] = (args.observations ?? []).map((obs) => ({
                    type: obs.type as DetectedObservation["type"],
                    topic: obs.topic,
                    fieldKey: obs.field_key ?? null,
                    severity: obs.severity as DetectedObservation["severity"],
                    description: obs.description,
                    sources: obs.sources ?? [],
                    recommendation: obs.recommendation,
                  }));
                  if (parsed.length > 0) {
                    setDetectedObservations((prev) => [...prev, ...parsed]);
                    toolSummaryParts.push(`Reported ${parsed.length} conflict${parsed.length !== 1 ? "s" : ""}`);
                  }
                } catch {
                  // Ignore parse errors — still acknowledge tool call
                  toolSummaryParts.push("Reported observations");
                }
                toolResults.push(
                  createToolResultMessage(call.id, JSON.stringify({
                    status: "ok",
                    message: "Observations reported and displayed to user in the Observations panel. " +
                      "Provide a brief overall assessment if needed — do not repeat individual findings.",
                  })),
                );
              } else if (call.function.name === "search_references" && onSearchReferences) {
                const args = parseToolArgs<{ query: string }>(call);
                if (!args) {
                  toolResults.push(invalidArgsResult(call));
                  continue;
                }
                setIsSearching(true);
                setActiveStepKind("searching");
                const searchStart = performance.now();
                searchPromises.push(
                  onSearchReferences(args.query).then((result) => {
                    // Record a "searching" timing step
                    const step: ResponseStep = {
                      kind: "searching",
                      durationMs: Math.round(performance.now() - searchStart),
                      label: args.query,
                    };
                    if (timingRef.current) {
                      timingRef.current.steps.push(step);
                    }
                    setCompletedSteps((prev) => [...prev, step]);
                    const { text: results, chunkCount, docCount } = result;
                    if (chunkCount > 0) setRetrievalMeta({ chunkCount, docCount });
                    return createToolResultMessage(call.id, results);
                  }).catch((err: unknown) =>
                    // Keyed by this call's own id so the model can continue with other results.
                    createToolResultMessage(call.id, JSON.stringify({
                      error: err instanceof Error ? err.message : "Search failed.",
                    })),
                  ),
                );
              } else if (call.function.name === "get_field_info" && onGetFieldInfo) {
                try {
                  const args = JSON.parse(call.function.arguments) as {
                    section_ids?: string[];
                    include_answers?: boolean;
                    include_outline?: boolean;
                  };
                  const result = onGetFieldInfo(args);
                  toolResults.push(createToolResultMessage(call.id, result));
                  toolSummaryParts.push("Looked up field info");
                } catch {
                  toolResults.push(
                    createToolResultMessage(call.id, JSON.stringify({ error: "Failed to retrieve field info." })),
                  );
                }
              } else if (call.function.name === "get_template_context" && onGetTemplateContext) {
                const args = parseToolArgs<{
                  field_key?: string;
                  from_line?: number;
                  search?: string;
                  lines?: number;
                }>(call);
                if (!args) {
                  toolResults.push(invalidArgsResult(call));
                  continue;
                }
                // Build a descriptive label from the query parameters
                const contextParts: string[] = [];
                if (args.field_key) contextParts.push(`field: ${args.field_key}`);
                if (args.from_line) contextParts.push(`from L${args.from_line}`);
                if (args.search) contextParts.push(`search: "${args.search}"`);
                if (args.lines) contextParts.push(`${args.lines} lines`);
                const contextLabel = contextParts.length > 0
                  ? `Template context (${contextParts.join(", ")})`
                  : "Template context";
                searchPromises.push(
                  onGetTemplateContext(args).then((result) => {
                    toolSummaryParts.push(contextLabel);
                    return createToolResultMessage(call.id, result);
                  }).catch(() =>
                    createToolResultMessage(call.id, JSON.stringify({ error: "Failed to retrieve template context." })),
                  ),
                );
              } else {
                // Without a result, buildApiMessages strips the orphaned call and the
                // model never learns the tool was unavailable.
                toolResults.push(
                  createToolResultMessage(call.id, JSON.stringify({
                    error: `Tool "${call.function.name}" is not available in this context.`,
                  })),
                );
              }
            }

            // Each async tool promise catches its own failure and resolves to an
            // error result for its own call id, so Promise.all never rejects here.
            Promise.all(searchPromises)
              .then((searchResults) => {
                if (generationRef.current !== thisGeneration) return;
                setIsSearching(false);

                const allResults = [...toolResults, ...searchResults];
                for (const msg of allResults) persistMessage(msg);

                // Set the rich label on the tool_processing step before finishing it
                if (timingRef.current && timingRef.current.currentStepKind === "tool_processing" && toolSummaryParts.length > 0) {
                  timingRef.current.currentStepLabel = toolSummaryParts.join(", ");
                }
                finishCurrentStep();

                if (askedQuestion) {
                  // Pause the tool cycle — wait for the user to answer via answerQuestion().
                  toolCycleActiveRef.current = false;
                  timingRef.current = null;
                  setCompletedSteps([]);
                  setActiveStepKind(null);
                  setPendingQuestion(askedQuestion);
                  setMessages((prev) => [...prev, ...allResults]);
                  return;
                }

                // Finish the "tool_processing" step before the recursive call
                setMessages((prev) => {
                  const updated = [...prev, ...allResults];
                  sendToLLMRef.current(updated);
                  return updated;
                });
              })
              .catch((err: unknown) => {
                if (generationRef.current !== thisGeneration) return;
                toolCycleActiveRef.current = false;
                timingRef.current = null;
                setIsSearching(false);
                setCompletedSteps([]);
                setActiveStepKind(null);
                setError(toAppError(err, { domain: "ai" }));
              });
          },
          onError(err) {
            if (generationRef.current !== thisGeneration) return;
            setIsStreaming(false);
            toolCycleActiveRef.current = false;
            timingRef.current = null; // Discard timing for failed responses
            setCompletedSteps([]);
            setActiveStepKind(null);
            setStreamingContent(null);
            setError(toAppError(err, { domain: "ai" }));
          },
        },
        {
          model: config.model,
          maxTokens: 64000,
          tools,
          effort: config.effort,
          enableThinking: config.enableThinking,
          thinkingBudget: config.thinkingBudget,
          toolChoice: effectiveToolChoice,
          streamTimeout: config.streamTimeout,
        },
      );
    },
    [buildSystemPrompt, tools, request, onSearchReferences, onGetFieldInfo, onGetTemplateContext, persistMessage, scope, isExtraction],
  );

  // Keep ref in sync with latest sendToLLM closure
  sendToLLMRef.current = sendToLLM;

  // Load persisted conversation on mount or when conversationKey changes.
  useEffect(() => {
    let cancelled = false;

    // Clear previous conversation state immediately
    setMessages([]);
    setAccumulatedChanges([]);
    setDetectedObservations([]);
    setPendingQuestion(null);
    setError(null);

    async function init() {
      const existing = await getConversation(sessionId, conversationKey);
      if (cancelled) return;
      if (existing.length > 0) {
        // Restore from DB
        const restored: AiChatMessage[] = existing.map((m: ChatMessage) => ({
          id: m.id,
          role: m.role,
          content: m.content,
          displayLabel: m.displayLabel,
          toolCalls: m.toolCalls,
          toolCallId: m.toolCallId,
          timings: m.timings,
        }));
        setMessages(restored);

        // Re-extract accumulated changes from assistant messages (tool calls + legacy XML)
        const changes: ProposedChange[] = [];
        for (const msg of restored) {
          if (msg.role !== "assistant") continue;
          const proposeTc = msg.toolCalls?.find(
            (tc) => tc.function.name === "propose_changes",
          );
          if (proposeTc) {
            try {
              const args = JSON.parse(proposeTc.function.arguments) as { changes: Record<string, unknown> };
              const { changes: parsed } = parseBulkEditResponse(
                JSON.stringify(args.changes),
                request,
              );
              changes.push(...parsed);
            } catch {
              // skip unparseable
            }
            continue;
          }
          const json = extractProposedChangesJson(msg.content);
          if (json) {
            try {
              const { changes: parsed } = parseBulkEditResponse(json, request);
              changes.push(...parsed);
            } catch {
              // skip unparseable
            }
          }
        }
        if (changes.length > 0) {
          setAccumulatedChanges(changes);
        }

        // Re-extract detected observations from persisted tool calls
        const observations: DetectedObservation[] = [];
        for (const msg of restored) {
          if (msg.role !== "assistant") continue;
          const obsTc = msg.toolCalls?.find(
            (tc) => tc.function.name === "report_observations",
          );
          if (obsTc) {
            try {
              const args = JSON.parse(obsTc.function.arguments) as {
                observations: Array<{
                  type: string;
                  topic: string;
                  field_key?: string | null;
                  severity: string;
                  description: string;
                  sources: Array<{ document: string; value: string; excerpt?: string }>;
                  recommendation?: string;
                }>;
              };
              for (const obs of args.observations ?? []) {
                observations.push({
                  type: obs.type as DetectedObservation["type"],
                  topic: obs.topic,
                  fieldKey: obs.field_key ?? null,
                  severity: obs.severity as DetectedObservation["severity"],
                  description: obs.description,
                  sources: obs.sources ?? [],
                  recommendation: obs.recommendation,
                });
              }
            } catch {
              // skip unparseable
            }
          }
        }
        if (observations.length > 0) {
          setDetectedObservations(observations);
        }

        // Restore an unanswered ask_user question, if the conversation was left mid-question.
        setPendingQuestion(findPendingAskUser(restored));
        return;
      }

      // No existing conversation — auto-send initial message if provided
      if (initialMessage) {
        // Initialize timing for this response sequence
        timingRef.current = {
          responseStartedAt: performance.now(),
          steps: [],
          currentStepStartedAt: null,
          currentStepKind: null,
        };

        const userMsg: AiChatMessage = {
          id: crypto.randomUUID(),
          role: "user",
          content: initialMessage.content,
          displayLabel: initialMessage.displayLabel,
        };
        if (cancelled) return;
        setMessages([userMsg]);
        persistMessage(userMsg);
        sendToLLMRef.current([userMsg]);
      }
    }

    init();

    return () => {
      cancelled = true;
      abortRef.current?.abort();
      toolCycleActiveRef.current = false;
    };
    // Re-run when conversationKey changes (e.g., switching conversations)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [conversationKey]);

  // Answer a pending ask_user question — delivers the answer as the tool's
  // deferred result and resumes the conversation.
  const answerQuestion = useCallback(
    (answers: QuestionAnswer[]) => {
      if (!pendingQuestion) return;
      setPendingQuestion(null);
      setRetrievalMeta(null);

      timingRef.current = {
        responseStartedAt: performance.now(),
        steps: [],
        currentStepStartedAt: null,
        currentStepKind: null,
      };
      setCompletedSteps([]);
      setActiveStepKind(null);

      const toolResult = createToolResultMessage(
        pendingQuestion.toolCallId,
        formatAnswersToolResult(answers),
      );
      persistMessage(toolResult);
      setMessages((prev) => {
        const updated = [...prev, toolResult];
        sendToLLMRef.current(updated);
        return updated;
      });
    },
    [pendingQuestion, persistMessage],
  );

  // Handle user follow-up messages
  const sendMessage = useCallback(
    (text: string, displayLabel?: string, _options?: SendMessageOptions) => {
      // If a question is pending, treat the typed text as the answer to its
      // first question (rest marked skipped) so the tool_use always gets a result.
      if (pendingQuestion) {
        const answers: QuestionAnswer[] = pendingQuestion.questions.map((q, i) => ({
          header: q.header,
          question: q.question,
          fieldKey: q.fieldKey,
          selected: [],
          otherText: i === 0 ? text : undefined,
          skipped: i !== 0,
        }));
        answerQuestion(answers);
        return;
      }

      setRetrievalMeta(null);

      // Initialize timing for this response sequence
      timingRef.current = {
        responseStartedAt: performance.now(),
        steps: [],
        currentStepStartedAt: null,
        currentStepKind: null,
      };
      setCompletedSteps([]);
      setActiveStepKind(null);

      const userMsg: AiChatMessage = {
        id: crypto.randomUUID(),
        role: "user",
        content: text,
        displayLabel,
      };
      const updated = [...messages, userMsg];
      setMessages(updated);
      persistMessage(userMsg);
      sendToLLM(updated);
    },
    [messages, sendToLLM, persistMessage, pendingQuestion, answerQuestion],
  );

  // Handle stop
  const stopStreaming = useCallback(() => {
    abortRef.current?.abort();
    toolCycleActiveRef.current = false;
    timingRef.current = null; // Discard timing for aborted responses
    setCompletedSteps([]);
    setActiveStepKind(null);
    setPendingQuestion(null);
    if (streamingContent) {
      const assistantMsg: AiChatMessage = {
        id: crypto.randomUUID(),
        role: "assistant",
        content: streamingContent,
      };
      setMessages((prev) => [...prev, assistantMsg]);
      persistMessage(assistantMsg);
    }
    setIsStreaming(false);
    setStreamingContent(null);
    streamingContentRef.current = null;
  }, [streamingContent, persistMessage]);

  // Inject document notification as a user message and auto-send
  const seenNotificationsRef = useRef<Set<string>>(new Set());
  const injectDocumentNotification = useCallback(
    (notification: { id: string; content: string; displayLabel: string }) => {
      if (seenNotificationsRef.current.has(notification.id)) return;
      if (isStreaming || toolCycleActiveRef.current) return;

      seenNotificationsRef.current.add(notification.id);

      // Initialize timing for this response sequence
      timingRef.current = {
        responseStartedAt: performance.now(),
        steps: [],
        currentStepStartedAt: null,
        currentStepKind: null,
      };
      setCompletedSteps([]);
      setActiveStepKind(null);

      const userMsg: AiChatMessage = {
        id: crypto.randomUUID(),
        role: "user",
        content: notification.content,
        displayLabel: notification.displayLabel,
      };
      persistMessage(userMsg);
      setMessages((prev) => {
        const updated = [...prev, userMsg];
        sendToLLMRef.current(updated);
        return updated;
      });
    },
    [isStreaming, persistMessage],
  );

  const clearObservations = useCallback(() => {
    setDetectedObservations([]);
  }, []);

  return {
    messages,
    isStreaming,
    streamingContent,
    isSearching,
    isThinking,
    retrievalMeta,
    error,
    accumulatedChanges,
    setAccumulatedChanges,
    detectedObservations,
    clearObservations,
    pendingQuestion,
    answerQuestion,
    sendMessage,
    stopStreaming,
    injectDocumentNotification,
    isToolCycleActive: toolCycleActiveRef.current,
    completedSteps,
    activeStepKind,
  };
}
