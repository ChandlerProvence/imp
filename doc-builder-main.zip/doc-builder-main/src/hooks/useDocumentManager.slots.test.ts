import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { renderHook, act, waitFor } from "@testing-library/react";
import { useDocumentManager } from "./useDocumentManager";
import { db } from "../db/dexie";
import { parseFileStructure } from "../extraction/parseFileEnhanced";
import type { DocumentSchema } from "../schemas/types";

vi.mock("../extraction/parseFileEnhanced", () => ({
  parseFileStructure: vi.fn(async (file: File) => {
    if (file.name.includes("broken")) throw new Error("Unreadable file");
    const text = `content of ${file.name} `.repeat(Math.max(1, Math.ceil(file.size / 24)));
    return { text, headerFooterText: "", images: [], standaloneImage: false };
  }),
  resolveImages: vi.fn(async ({ parsed }: any) => parsed.text),
}));

vi.mock("../ai/cuiDetection", async () => {
  const actual = await vi.importActual<typeof import("../ai/cuiDetection")>("../ai/cuiDetection");
  return { ...actual, checkForCui: vi.fn(async () => null) };
});

vi.mock("../ai/embeddings", async () => {
  const actual = await vi.importActual<typeof import("../ai/embeddings")>("../ai/embeddings");
  return {
    ...actual,
    embedAndStoreDocument: vi.fn(async ({ docId, docTitle }: { docId: string; docTitle: string }) => [
      { text: "chunk text", docId, docTitle, index: 0, embedding: [0, 0] },
    ]),
    retrieveRelevantChunks: vi.fn(async (_q: string, chunks: unknown[]) => chunks),
  };
});

import { checkForCui } from "../ai/cuiDetection";

const schema: DocumentSchema = {
  id: "test-schema",
  title: "Test",
  category: "fms",
  sections: [],
  recommended_uploads: [
    { id: "prior-mods", title: "Prior Modifications", priority: "optional", multiple: true },
    {
      id: "pws",
      title: "PWS (Performance Work Statement)",
      priority: "recommended",
      ai_hint: "Authoritative for scope. Do not use for pricing.",
    },
    { id: "pr", title: "PR (Purchase Request)" },
  ],
} as any;

/** Small (inline) document by default; pass a size ≥ 10k chars for the embedding path. */
function makeFile(name: string, size = 200) {
  // Content derives from the name so differently named files hash differently
  // (re-uploads are matched by content hash).
  const bytes = new Uint8Array(size);
  bytes.set(new TextEncoder().encode(name).subarray(0, size));
  return new File([bytes], name, { type: "application/pdf" });
}

/** Renders the hook and lets the manifest fetch settle. Its state update
 *  re-runs the parse effect, which cancels uploads still in flight (hashing
 *  makes that window wider). */
async function renderManager() {
  const rendered = renderHook(() =>
    useDocumentManager({ schema, activeEndpoint: "non-cui", setActiveEndpoint: vi.fn() }),
  );
  await waitFor(() => expect(fetch).toHaveBeenCalled());
  await act(async () => {
    await new Promise((r) => setTimeout(r, 0));
  });
  return rendered;
}

type Result = Awaited<ReturnType<typeof renderManager>>["result"];

async function idOf(name: string): Promise<string> {
  const doc = (await db.uploadedDocuments.toArray()).find((d) => d.fileName === name);
  if (!doc) throw new Error(`no saved doc ${name}`);
  return doc.id;
}

async function dropOnSlot(result: Result, file: File, slotId?: string) {
  act(() => result.current.addFiles([file], slotId));
  await waitFor(() => expect(result.current.isParsing).toBe(false));
  await waitFor(() => expect(result.current.attachBlocked).toBe(false));
}

describe("useDocumentManager slots", () => {
  beforeEach(async () => {
    vi.clearAllMocks();
    vi.stubGlobal("fetch", vi.fn(async () => ({ ok: false, json: async () => ({}) })));
    localStorage.clear();
    await db.uploadedDocuments.clear();
    await db.embeddingChunks.clear();
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it("exposes slot definitions with the recommended tier first", async () => {
    const { result } = await renderManager();
    expect(result.current.slotDefs.map((d) => d.id)).toEqual(["pws", "pr", "prior-mods"]);
  });

  it("a file still parsing when the manifest arrives is not cancelled", async () => {
    let resolveManifest!: () => void;
    const manifestLoaded = new Promise<void>((r) => { resolveManifest = r; });
    vi.stubGlobal("fetch", vi.fn(async () => {
      await manifestLoaded;
      return { ok: true, json: async () => ({ fms: [] }) };
    }));
    let resolveParse!: () => void;
    const parseHeld = new Promise<void>((r) => { resolveParse = r; });
    vi.mocked(parseFileStructure).mockImplementationOnce(async (file: File) => {
      await parseHeld;
      return { text: `content of ${file.name}`, headerFooterText: "", images: [], standaloneImage: false } as any;
    });

    const { result } = renderHook(() =>
      useDocumentManager({ schema, activeEndpoint: "non-cui", setActiveEndpoint: vi.fn() }),
    );
    act(() => result.current.setShowDocPicker(true));
    act(() => result.current.addFiles([makeFile("early.pdf")]));
    await waitFor(() => expect(result.current.isParsing).toBe(true));

    // Manifest lands mid-parse, then the parse finishes.
    await act(async () => {
      resolveManifest();
      await new Promise((r) => setTimeout(r, 0));
    });
    await act(async () => {
      resolveParse();
    });

    await waitFor(() => expect(result.current.draftDocIds.size).toBe(1));
    await waitFor(() => expect(result.current.isParsing).toBe(false));
  });

  it("a file dropped on a slot lands in that slot once parsed", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    await dropOnSlot(result, makeFile("pws_v3.pdf"), "pws");

    const id = await idOf("pws_v3.pdf");
    await waitFor(() => expect(result.current.draftSlotAssignments.get(id)).toBe("pws"));
    expect(result.current.draftDocIds.has(id)).toBe(true);
  });

  it("files dropped without a slot stay unslotted", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    await dropOnSlot(result, makeFile("notes.pdf"));
    const id = await idOf("notes.pdf");
    await waitFor(() => expect(result.current.draftDocIds.has(id)).toBe(true));
    expect(result.current.draftSlotAssignments.size).toBe(0);
  });

  it("commit copies slots, persists the role label, and tags the prompt", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    await dropOnSlot(result, makeFile("pws \"final\".pdf"), "pws");
    await dropOnSlot(result, makeFile("notes.pdf"));
    const pwsId = await idOf("pws \"final\".pdf");

    act(() => result.current.requestAttach());
    await waitFor(() => expect(result.current.slotAssignments.get(pwsId)).toBe("pws"));

    await waitFor(async () => {
      const saved = await db.uploadedDocuments.get(pwsId);
      expect(saved?.slotRole).toEqual({ slotId: "pws", title: "PWS (Performance Work Statement)" });
    });

    const text = result.current.buildCombinedDocumentText()!;
    expect(text).toContain(
      '<document role="pws" title="PWS (Performance Work Statement)" filename="pws &quot;final&quot;.pdf">',
    );
    expect(text).toContain('<document filename="notes.pdf">');

    expect(result.current.buildSourceDocumentRoles()).toEqual([
      {
        role: "pws",
        title: "PWS (Performance Work Statement)",
        aiHint: "Authoritative for scope. Do not use for pricing.",
        filenames: ['pws "final".pdf'],
      },
    ]);

    const chip = result.current.setupDocuments.find((d) => d.id === pwsId);
    expect(chip).toMatchObject({ roleId: "pws", roleTitle: "PWS (Performance Work Statement)" });
  });

  it("a second document in a single-document slot replaces and detaches the first", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    await dropOnSlot(result, makeFile("pr_old.pdf"), "pr");
    await dropOnSlot(result, makeFile("pr_new.pdf"), "pr");
    const oldId = await idOf("pr_old.pdf");
    const newId = await idOf("pr_new.pdf");

    await waitFor(() => expect(result.current.draftSlotAssignments.get(newId)).toBe("pr"));
    expect(result.current.draftSlotAssignments.has(oldId)).toBe(false);
    expect(result.current.draftDocIds.has(oldId)).toBe(false);
  });

  it("a multiple slot keeps every document", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    await dropOnSlot(result, makeFile("mod1.pdf"), "prior-mods");
    await dropOnSlot(result, makeFile("mod2.pdf"), "prior-mods");
    const ids = [await idOf("mod1.pdf"), await idOf("mod2.pdf")];
    await waitFor(() =>
      expect(ids.map((id) => result.current.draftSlotAssignments.get(id))).toEqual(["prior-mods", "prior-mods"]),
    );
  });

  it("a single-document slot takes only the first of several dropped files", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    act(() => result.current.addFiles([makeFile("a.pdf"), makeFile("b.pdf")], "pws"));
    expect(result.current.files.map((f) => f.name)).toEqual(["a.pdf"]);
  });

  it("dropping an already-queued file on a slot re-targets it instead of ignoring it", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    act(() => {
      result.current.addFiles([makeFile("dup.pdf")]);
      result.current.addFiles([makeFile("dup.pdf")], "pr");
    });
    expect(result.current.files).toHaveLength(1);
    await waitFor(() => expect(result.current.isParsing).toBe(false));
    const id = await idOf("dup.pdf");
    await waitFor(() => expect(result.current.draftSlotAssignments.get(id)).toBe("pr"));
  });

  it("a parse failure leaves the slot empty and keeps the error visible", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    const file = makeFile("broken.pdf");
    act(() => result.current.addFiles([file], "pws"));
    await waitFor(() => expect(result.current.fileErrors.size).toBe(1));
    expect(result.current.draftSlotAssignments.size).toBe(0);
    expect(result.current.files).toContain(file);
  });

  it("unassigning detaches the document, and re-checking it later does not restore the slot", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    await dropOnSlot(result, makeFile("pws.pdf"), "pws");
    const id = await idOf("pws.pdf");
    await waitFor(() => expect(result.current.draftSlotAssignments.get(id)).toBe("pws"));

    act(() => result.current.unassignDraftSlot(id));
    expect(result.current.draftDocIds.has(id)).toBe(false);
    expect(result.current.draftSlotAssignments.has(id)).toBe(false);

    act(() => result.current.toggleDraftDoc(id));
    await waitFor(() => expect(result.current.draftDocIds.has(id)).toBe(true));
    expect(result.current.draftSlotAssignments.has(id)).toBe(false);
  });

  it("assignDraftSlot moves an Other document into a slot", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    await dropOnSlot(result, makeFile("misc.pdf"));
    const id = await idOf("misc.pdf");
    await waitFor(() => expect(result.current.draftDocIds.has(id)).toBe(true));

    act(() => result.current.assignDraftSlot("pr", id));
    expect(result.current.draftSlotAssignments.get(id)).toBe("pr");
  });

  it("assignDraftSlot on an unchecked library doc adds it to the draft", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    await dropOnSlot(result, makeFile("lib.pdf"));
    const id = await idOf("lib.pdf");
    await waitFor(() => expect(result.current.draftDocIds.has(id)).toBe(true));
    act(() => result.current.toggleDraftDoc(id));
    expect(result.current.draftDocIds.has(id)).toBe(false);

    act(() => result.current.assignDraftSlot("pws", id));
    await waitFor(() => expect(result.current.draftDocIds.has(id)).toBe(true));
    expect(result.current.draftSlotAssignments.get(id)).toBe("pws");
  });

  it("closing without Attach discards draft slot changes; reopening restores committed slots", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    await dropOnSlot(result, makeFile("pws.pdf"), "pws");
    const id = await idOf("pws.pdf");
    act(() => result.current.requestAttach());
    await waitFor(() => expect(result.current.slotAssignments.get(id)).toBe("pws"));

    act(() => result.current.setShowDocPicker(true));
    await waitFor(() => expect(result.current.draftSlotAssignments.get(id)).toBe("pws"));
    act(() => result.current.unassignDraftSlot(id));
    act(() => result.current.closePickerDiscard());
    expect(result.current.slotAssignments.get(id)).toBe("pws");

    act(() => result.current.setShowDocPicker(true));
    await waitFor(() => expect(result.current.draftSlotAssignments.get(id)).toBe("pws"));
  });

  it("a CUI-flagged slotted document stays slotted after 'not CUI' is affirmed", async () => {
    (checkForCui as any).mockResolvedValueOnce({
      isCui: true,
      confidence: "high",
      reason: "marking",
      method: "regex",
      markers: ["CUI"],
    });
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    await dropOnSlot(result, makeFile("flagged_pws.pdf"), "pws");
    const id = await idOf("flagged_pws.pdf");

    act(() => result.current.requestAttach());
    expect(result.current.showCuiWarning).toBe(true);
    act(() => result.current.affirmNotCuiAndAttach());
    await waitFor(() => expect(result.current.slotAssignments.get(id)).toBe("pws"));
  });

  it("search results are labeled with the slot title", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    await dropOnSlot(result, makeFile("big_pws.pdf", 20000), "pws");
    act(() => result.current.requestAttach());
    await waitFor(() => expect(result.current.docsReady).toBe(true));

    const { text } = await result.current.handleSearchReferences("scope");
    expect(text).toContain("[1] (PWS (Performance Work Statement) — big_pws.pdf):");
  });

  it("the role label survives a new session but nothing is auto-attached", async () => {
    const first = await renderManager();
    act(() => first.result.current.setShowDocPicker(true));
    await dropOnSlot(first.result, makeFile("pws.pdf"), "pws");
    const id = await idOf("pws.pdf");
    act(() => first.result.current.requestAttach());
    await waitFor(async () => expect((await db.uploadedDocuments.get(id))?.slotRole?.slotId).toBe("pws"));
    first.unmount();

    const second = await renderManager();
    act(() => second.result.current.setShowDocPicker(true));
    await waitFor(() =>
      expect(second.result.current.availableDocs.find((d) => d.id === id)?.savedDoc?.slotRole?.slotId).toBe("pws"),
    );
    expect(second.result.current.draftDocIds.size).toBe(0);
    expect(second.result.current.draftSlotAssignments.size).toBe(0);
  });

  /** Attach pws.pdf as the PWS in one session, then open the picker in a fresh one. */
  async function withPriorPws() {
    const first = await renderManager();
    act(() => first.result.current.setShowDocPicker(true));
    await dropOnSlot(first.result, makeFile("pws.pdf"), "pws");
    const id = await idOf("pws.pdf");
    act(() => first.result.current.requestAttach());
    await waitFor(async () => expect((await db.uploadedDocuments.get(id))?.slotRole?.slotId).toBe("pws"));
    first.unmount();

    const second = await renderManager();
    act(() => second.result.current.setShowDocPicker(true));
    await waitFor(() => expect(second.result.current.availableDocs.some((d) => d.id === id)).toBe(true));
    return { result: second.result, id };
  }

  it("checking a doc whose saved role names an empty slot places it there", async () => {
    const { result, id } = await withPriorPws();
    act(() => result.current.toggleDraftDoc(id));
    expect(result.current.draftDocIds.has(id)).toBe(true);
    expect(result.current.draftSlotAssignments.get(id)).toBe("pws");
  });

  it("checking a doc whose saved role names an occupied slot leaves it unslotted", async () => {
    const { result, id } = await withPriorPws();
    await dropOnSlot(result, makeFile("pws_v2.pdf"), "pws");
    const newId = await idOf("pws_v2.pdf");
    await waitFor(() => expect(result.current.draftSlotAssignments.get(newId)).toBe("pws"));

    act(() => result.current.toggleDraftDoc(id));
    expect(result.current.draftDocIds.has(id)).toBe(true);
    expect(result.current.draftSlotAssignments.has(id)).toBe(false);
    expect(result.current.draftSlotAssignments.get(newId)).toBe("pws");
  });

  it("removing an attached chip clears its slot", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    await dropOnSlot(result, makeFile("pws.pdf"), "pws");
    const id = await idOf("pws.pdf");
    act(() => result.current.requestAttach());
    await waitFor(() => expect(result.current.slotAssignments.get(id)).toBe("pws"));

    act(() => result.current.handleRemoveDocument(id));
    expect(result.current.slotAssignments.size).toBe(0);
    expect(result.current.buildSourceDocumentRoles()).toEqual([]);
  });

  it("resetSelections clears all slot state", async () => {
    const { result } = await renderManager();
    act(() => result.current.setShowDocPicker(true));
    await dropOnSlot(result, makeFile("pws.pdf"), "pws");
    act(() => result.current.requestAttach());
    await waitFor(() => expect(result.current.slotAssignments.size).toBe(1));

    act(() => result.current.resetSelections());
    expect(result.current.slotAssignments.size).toBe(0);
    expect(result.current.draftSlotAssignments.size).toBe(0);
    expect(result.current.files).toHaveLength(0);
  });
});
