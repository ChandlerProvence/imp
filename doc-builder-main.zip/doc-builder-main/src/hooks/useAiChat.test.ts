import { describe, it, expect, vi, beforeEach } from "vitest";
import { renderHook, act, waitFor } from "@testing-library/react";
import type { StreamCallbacks, ToolCall } from "../ai/types";
import { createMockSchema } from "../test/mocks";

const streamCalls: StreamCallbacks[] = [];

vi.mock("../ai/litellm", () => ({
  streamChatCompletion: vi.fn((_messages: unknown, callbacks: StreamCallbacks) => {
    streamCalls.push(callbacks);
    return new AbortController();
  }),
}));

vi.mock("../db/chatHistory", () => ({
  addMessage: vi.fn(() => Promise.resolve()),
  upsertConversation: vi.fn(() => Promise.resolve()),
  getConversation: vi.fn(() => Promise.resolve([])),
}));

import { useAiChat, type UseAiChatOptions } from "./useAiChat";
import { streamChatCompletion } from "../ai/litellm";
import { addMessage, getConversation } from "../db/chatHistory";
import type { ChatMessage } from "../db/types";

const schema = createMockSchema();

function call(id: string, name: string, args: unknown): ToolCall {
  return {
    id,
    type: "function",
    function: { name, arguments: typeof args === "string" ? args : JSON.stringify(args) },
  } as ToolCall;
}

function setup(overrides: Partial<UseAiChatOptions> = {}) {
  return renderHook(() =>
    useAiChat({
      sessionId: "s1",
      conversationKey: "__bulk_edit:test",
      schema,
      buildSystemPrompt: () => "system",
      tools: [],
      request: { mode: "prompt", selectedSectionIds: [], schema, currentAnswers: {} },
      ...overrides,
    }),
  );
}

/** Send a user message, then have the model respond with the given tool calls. */
async function runToolTurn(result: ReturnType<typeof setup>["result"], calls: ToolCall[]) {
  act(() => result.current.sendMessage("hello"));
  await waitFor(() => expect(streamCalls).toHaveLength(1));
  act(() => streamCalls[0].onToolCalls!(calls, { stopReason: "tool_use" }));
  // The continuation request fires once every tool result is in.
  await waitFor(() => expect(streamCalls).toHaveLength(2));
}

function toolResults(result: ReturnType<typeof setup>["result"]) {
  return result.current.messages.filter((m) => m.role === "tool");
}

describe("useAiChat tool cycle", () => {
  beforeEach(() => {
    streamCalls.length = 0;
  });

  it("maps a failed search to its own call id when template-context calls come first", async () => {
    const { result } = setup({
      onGetTemplateContext: () => Promise.resolve("template text"),
      onSearchReferences: () => Promise.reject(new Error("index unavailable")),
    });

    await runToolTurn(result, [
      call("tc-1", "get_template_context", { field_key: "a.b" }),
      call("search-1", "search_references", { query: "budget" }),
    ]);

    const results = toolResults(result);
    expect(results.map((m) => m.toolCallId).sort()).toEqual(["search-1", "tc-1"]);
    const search = results.find((m) => m.toolCallId === "search-1")!;
    expect(JSON.parse(search.content)).toEqual({ error: "index unavailable" });
  });

  it("returns an error result for malformed tool arguments instead of hanging", async () => {
    const { result } = setup({
      onGetTemplateContext: () => Promise.resolve("template text"),
      onSearchReferences: () => Promise.resolve({ text: "hits", chunkCount: 1, docCount: 1 }),
    });

    await runToolTurn(result, [
      call("search-1", "search_references", "{not json"),
      call("tc-1", "get_template_context", "{not json"),
    ]);

    const results = toolResults(result);
    expect(results.map((m) => m.toolCallId).sort()).toEqual(["search-1", "tc-1"]);
    for (const m of results) expect(JSON.parse(m.content).error).toMatch(/Could not parse arguments/);
  });

  it("answers unknown tools and tools without a handler", async () => {
    const { result } = setup();

    await runToolTurn(result, [
      call("x-1", "not_a_tool", {}),
      call("search-1", "search_references", { query: "budget" }),
    ]);

    const results = toolResults(result);
    expect(results.map((m) => m.toolCallId).sort()).toEqual(["search-1", "x-1"]);
    for (const m of results) expect(JSON.parse(m.content).error).toMatch(/not available/);
  });

  it("records each call's own token usage on the message it produced", async () => {
    const { result } = setup({ onSearchReferences: () => Promise.resolve({ text: "hits", chunkCount: 1, docCount: 1 }) });
    act(() => result.current.sendMessage("hello"));
    await waitFor(() => expect(streamCalls).toHaveLength(1));
    act(() => {
      streamCalls[0].onUsage!({ promptTokens: 1000, completionTokens: 50, totalTokens: 1050 });
      streamCalls[0].onToolCalls!([call("s-1", "search_references", { query: "q" })], { stopReason: "tool_use" });
    });
    await waitFor(() => expect(streamCalls).toHaveLength(2));
    act(() => {
      streamCalls[1].onUsage!({ promptTokens: 1400, completionTokens: 80, totalTokens: 1480 });
      streamCalls[1].onDone("done");
    });
    const assistants = result.current.messages.filter((m) => m.role === "assistant");
    expect(assistants[0].timings?.callUsage?.promptTokens).toBe(1000);
    expect(assistants[1].timings?.callUsage?.promptTokens).toBe(1400);
    expect(assistants[1].timings?.usage?.completionTokens).toBe(130);
  });
});

describe("useAiChat behavior", () => {
  beforeEach(() => {
    streamCalls.length = 0;
    vi.mocked(streamChatCompletion).mockClear();
    vi.mocked(addMessage).mockClear();
    vi.mocked(getConversation).mockReset();
    vi.mocked(getConversation).mockImplementation(() => Promise.resolve([]));
  });

  it("runs exactly one continuation after a handled tool call and shows the final text", async () => {
    const { result } = setup({ onGetFieldInfo: () => "field info text" });

    await runToolTurn(result, [call("fi-1", "get_field_info", {})]);

    const continuationMessages = vi.mocked(streamChatCompletion).mock.calls[1][0];
    expect(continuationMessages).toContainEqual(
      expect.objectContaining({ role: "tool", tool_call_id: "fi-1", content: "field info text" }),
    );

    act(() => {
      streamCalls[1].onToken("Final ");
      streamCalls[1].onToken("answer");
    });
    act(() => streamCalls[1].onDone("Final answer"));

    await waitFor(() => expect(result.current.isStreaming).toBe(false));
    expect(streamCalls).toHaveLength(2);
    const last = result.current.messages.at(-1)!;
    expect(last.role).toBe("assistant");
    expect(last.content).toBe("Final answer");
  });

  it("stopStreaming aborts the stream and keeps the partial text", async () => {
    const { result } = setup();

    act(() => result.current.sendMessage("hello"));
    await waitFor(() => expect(streamCalls).toHaveLength(1));
    const controller = vi.mocked(streamChatCompletion).mock.results[0].value as AbortController;
    expect(result.current.isStreaming).toBe(true);

    act(() => streamCalls[0].onToken("Partial re"));
    await waitFor(() => expect(result.current.streamingContent).toBe("Partial re"));

    act(() => result.current.stopStreaming());

    expect(controller.signal.aborted).toBe(true);
    expect(result.current.isStreaming).toBe(false);
    expect(result.current.streamingContent).toBeNull();
    const last = result.current.messages.at(-1)!;
    expect(last.role).toBe("assistant");
    expect(last.content).toBe("Partial re");
  });

  it("restores the stored conversation after a remount", async () => {
    const stored = [
      { id: "m1", sessionId: "s1", fieldKey: "__bulk_edit:test", role: "user", content: "earlier question" },
      { id: "m2", sessionId: "s1", fieldKey: "__bulk_edit:test", role: "assistant", content: "earlier answer" },
    ] as unknown as ChatMessage[];
    vi.mocked(getConversation).mockImplementation(() => Promise.resolve(stored));

    const first = setup();
    await waitFor(() => expect(first.result.current.messages).toHaveLength(2));
    first.unmount();

    const second = setup();
    await waitFor(() => expect(second.result.current.messages).toHaveLength(2));
    expect(second.result.current.messages.map((m) => m.content)).toEqual(["earlier question", "earlier answer"]);
    expect(getConversation).toHaveBeenLastCalledWith("s1", "__bulk_edit:test");
    expect(streamCalls).toHaveLength(0);
  });

  it("persists the user message and the completed streamed reply via addMessage", async () => {
    const { result } = setup();

    act(() => result.current.sendMessage("hello"));
    await waitFor(() => expect(streamCalls).toHaveLength(1));
    act(() => streamCalls[0].onToken("Done text"));
    act(() => streamCalls[0].onDone("Done text"));

    await waitFor(() =>
      expect(addMessage).toHaveBeenCalledWith(
        expect.objectContaining({ sessionId: "s1", fieldKey: "__bulk_edit:test", role: "assistant", content: "Done text" }),
      ),
    );
    expect(addMessage).toHaveBeenCalledWith(expect.objectContaining({ role: "user", content: "hello" }));
  });

  describe("propose_changes result", () => {
    const fillSchema = {
      id: "t",
      title: "T",
      version: 1,
      output_template: "x",
      sections: [
        {
          id: "main",
          title: "Main",
          fields: [
            { id: "name", label: "Name", type: "string" },
            { id: "story", label: "Story", type: "freetext" },
            { id: "rows", label: "Rows", type: "table", columns: [{ id: "a", label: "A", type: "string" }] },
          ],
        },
      ],
    } as unknown as UseAiChatOptions["schema"];

    function fillSetup() {
      return setup({
        schema: fillSchema,
        request: { mode: "prompt", selectedSectionIds: ["main"], schema: fillSchema, currentAnswers: {} },
      });
    }

    function proposeResult(result: ReturnType<typeof setup>["result"]) {
      return JSON.parse(toolResults(result).find((m) => m.toolCallId === "p-1")!.content);
    }

    it("splits empty fields into freetext to draft and fields awaiting source facts", async () => {
      const { result } = fillSetup();
      await runToolTurn(result, [
        call("p-1", "propose_changes", { changes: { "main.rows": { value: [{ a: "x" }], confidence: 0.7 } } }),
      ]);
      const payload = proposeResult(result);
      expect(payload.fields_to_draft).toEqual(["main.story"]);
      expect(payload.fields_to_draft_count).toBe(1);
      expect(payload.fields_awaiting_source_facts).toEqual(["main.name"]);
      expect(payload.fields_still_empty).toBeUndefined();
      expect(payload.message).toContain("1 freetext field in scope is still empty");
      expect(payload.message).toContain("call `propose_changes` again");
    });

    it("treats an empty table as awaiting source facts, not as a field to draft", async () => {
      const { result } = fillSetup();
      await runToolTurn(result, [
        call("p-1", "propose_changes", { changes: { "main.story": { value: "Once upon a time.", confidence: 0.7 } } }),
      ]);
      const payload = proposeResult(result);
      expect(payload.fields_to_draft).toBeUndefined();
      expect(payload.fields_awaiting_source_facts).toEqual(["main.name", "main.rows"]);
      expect(payload.message).not.toContain("call `propose_changes` again");
    });
  });
});
