import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { renderHook, act, waitFor } from "@testing-library/react";
import { useDocumentManager } from "./useDocumentManager";
import { db } from "../db/dexie";
import type { DocumentSchema } from "../schemas/types";

vi.mock("../extraction/parseFileEnhanced", () => ({
  parseFileStructure: vi.fn(async (file: File) => ({
    text: `content of ${file.name}`,
    headerFooterText: "",
    images: [],
    standaloneImage: false,
  })),
  resolveImages: vi.fn(async ({ parsed }: any) => parsed.text),
}));

vi.mock("../ai/cuiDetection", async () => {
  const actual = await vi.importActual<typeof import("../ai/cuiDetection")>("../ai/cuiDetection");
  return { ...actual, checkForCui: vi.fn(async () => null) };
});

const MANIFEST = {
  fms: [
    {
      id: "contact-information-sca-sor-tom-260801",
      title: "Contact Information SCA SOR Tom 260801",
      fileName: "Contact-Information-SCA-SOR-TOM-260801.xlsx",
      url: "reference-docs/fms/Contact-Information-SCA-SOR-TOM-260801.xlsx",
    },
    {
      id: "contact-information-sca-sor-tom-260829",
      title: "Contact Information SCA SOR Tom 260829",
      fileName: "Contact-Information-SCA-SOR-TOM-260829.xlsx",
      url: "reference-docs/fms/Contact-Information-SCA-SOR-TOM-260829.xlsx",
    },
  ],
};

const schema: DocumentSchema = {
  id: "test-schema",
  title: "Test",
  category: "fms",
  sections: [],
  recommended_uploads: [
    { id: "pws", title: "PWS" },
    { id: "contact-info", title: "Contact Information", default_reference: "contact-information" },
  ],
} as any;

function renderManager() {
  return renderHook(() =>
    useDocumentManager({ schema, activeEndpoint: "non-cui", setActiveEndpoint: vi.fn() }),
  );
}

type Result = ReturnType<typeof renderManager>["result"];

function contactSlotDocs(result: Result): string[] {
  return [...result.current.draftSlotAssignments]
    .filter(([, slot]) => slot === "contact-info")
    .map(([id]) => id);
}

async function openPicker(result: Result) {
  act(() => result.current.setShowDocPicker(true));
  await waitFor(() => expect(contactSlotDocs(result)).toHaveLength(1));
  await waitFor(() => expect(result.current.isParsing).toBe(false));
  await waitFor(() => expect(result.current.attachBlocked).toBe(false));
}

describe("useDocumentManager default references", () => {
  beforeEach(async () => {
    vi.clearAllMocks();
    vi.stubGlobal(
      "fetch",
      vi.fn(async (url: string) => {
        if (url.endsWith("manifest.json")) return { ok: true, json: async () => MANIFEST };
        return { ok: true, blob: async () => new Blob(["xlsx"]) };
      }),
    );
    localStorage.clear();
    await db.uploadedDocuments.clear();
    await db.embeddingChunks.clear();
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it("pre-places the newest matching bundled reference in its slot when the picker opens", async () => {
    const { result } = renderManager();
    await openPicker(result);
    const [id] = contactSlotDocs(result);
    expect(result.current.draftDocIds.has(id)).toBe(true);
    const saved = await db.uploadedDocuments.get(id);
    expect(saved?.refId).toBe("contact-information-sca-sor-tom-260829");
  });

  it("attaches with its role when the user clicks Attach", async () => {
    const { result } = renderManager();
    await openPicker(result);
    act(() => result.current.requestAttach());
    await waitFor(() => expect(result.current.showDocPicker).toBe(false));
    expect(result.current.buildSourceDocumentRoles().map((r) => r.role)).toEqual(["contact-info"]);
  });

  it("does not refill the slot after the user removes it and attaches", async () => {
    const { result } = renderManager();
    await openPicker(result);
    const [id] = contactSlotDocs(result);
    act(() => result.current.unassignDraftSlot(id));
    act(() => result.current.requestAttach());
    await waitFor(() => expect(result.current.showDocPicker).toBe(false));

    act(() => result.current.setShowDocPicker(true));
    // Give the effect (and manifest-driven re-runs) a chance to fire.
    await new Promise((r) => setTimeout(r, 50));
    expect(contactSlotDocs(result)).toHaveLength(0);
  });

  it("refills the slot when the picker was closed without attaching", async () => {
    const { result } = renderManager();
    await openPicker(result);
    act(() => result.current.setShowDocPicker(false));
    await openPicker(result);
    expect(contactSlotDocs(result)).toHaveLength(1);
  });
});

describe("sortSlotDefs", () => {
  it("puts auto-loaded slots after user-filled slots in each tier", async () => {
    const { sortSlotDefs } = await import("./useDocumentManager");
    const order = sortSlotDefs([
      { id: "contact", title: "C", default_reference: "x" },
      { id: "opt", title: "O", priority: "optional" },
      { id: "pws", title: "P" },
    ]).map((d) => d.id);
    expect(order).toEqual(["pws", "contact", "opt"]);
  });
});

describe("findDefaultReference", () => {
  it("matches an exact id or a dash-separated prefix, newest last", async () => {
    const { findDefaultReference } = await import("./useDocumentManager");
    const docs = MANIFEST.fms.concat([{ id: "contact-informationx", title: "", fileName: "", url: "" }]);
    expect(findDefaultReference(docs, "contact-information")?.id).toBe("contact-information-sca-sor-tom-260829");
    expect(findDefaultReference(docs, "missing")).toBeUndefined();
  });
});
