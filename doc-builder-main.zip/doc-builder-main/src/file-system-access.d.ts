/**
 * Type declarations for the File System Access API's showSaveFilePicker.
 * FileSystemFileHandle and FileSystemWritableFileStream are already in lib.dom.d.ts.
 */

interface FilePickerAcceptType {
  description?: string;
  accept: Record<string, string[]>;
}

interface SaveFilePickerOptions {
  suggestedName?: string;
  types?: FilePickerAcceptType[];
  excludeAcceptAllOption?: boolean;
}

declare function showSaveFilePicker(
  options?: SaveFilePickerOptions,
): Promise<FileSystemFileHandle>;

interface Window {
  showSaveFilePicker?: typeof showSaveFilePicker;
}
