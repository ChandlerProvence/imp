/**
 * Build identity injected at build time by Vite `define` (see vite.config.ts).
 * CI sets `CI_COMMIT_SHORT_SHA`; local dev and tests have no SHA and report "dev".
 */
export interface BuildInfo {
  sha: string;
  builtAt?: string;
}

export function getBuildInfo(): BuildInfo {
  const sha = import.meta.env.VITE_BUILD_SHA || "dev";
  const builtAt = import.meta.env.VITE_BUILD_TIME || undefined;
  return builtAt ? { sha, builtAt } : { sha };
}

/** Short human-readable label, e.g. "Build f8d1c10 · 2026-10-20". */
export function formatBuildLabel(info: BuildInfo = getBuildInfo()): string {
  return info.builtAt ? `Build ${info.sha} · ${info.builtAt.slice(0, 10)}` : `Build ${info.sha}`;
}
