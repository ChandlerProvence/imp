/**
 * Where users send feedback, error reports (SUPPORT_CONTACT in
 * src/errors/catalog.ts), and template submissions. Keep in sync with
 * docs/help/contact.md (enforced by contact.test.ts).
 */
export const CONTACT_NAME = "Winston Chu";
export const CONTACT_EMAIL = "winston.chu@leidos.com";
