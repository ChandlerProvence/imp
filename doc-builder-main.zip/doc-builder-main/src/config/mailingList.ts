/**
 * The "add me to the update mailing list" email, shared by the first-visit
 * notice, the Help menu, and docs/help/contact.md (enforced by contact.test.ts).
 */
import { CONTACT_EMAIL } from "./contact";

export const MAILING_LIST_SUBJECT = "[Doc Builder] Add me to the update mailing list";
export const MAILING_LIST_BODY = "Please add me to the Doc Builder mailing list for update notifications.";
export const MAILING_LIST_MAILTO = `mailto:${CONTACT_EMAIL}?subject=${encodeURIComponent(MAILING_LIST_SUBJECT)}&body=${encodeURIComponent(MAILING_LIST_BODY)}`;
