import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { CONTACT_EMAIL } from "./contact";
import { MAILING_LIST_SUBJECT } from "./mailingList";

describe("contact config", () => {
  it("matches the address on the Contact & Feedback help page", () => {
    const page = readFileSync(resolve(__dirname, "../../docs/help/contact.md"), "utf-8");
    expect(page).toContain(`mailto:${CONTACT_EMAIL}`);
  });

  it("documents the mailing-list subject on the Contact & Feedback help page", () => {
    const page = readFileSync(resolve(__dirname, "../../docs/help/contact.md"), "utf-8");
    expect(page).toContain(MAILING_LIST_SUBJECT);
    expect(page).toContain(`mailto:${CONTACT_EMAIL}?subject=${encodeURIComponent(MAILING_LIST_SUBJECT)}`);
  });
});
