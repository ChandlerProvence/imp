import Dexie, { type EntityTable, type Table } from "dexie";
import type {
  Session,
  ChatMessage,
  Conversation,
  EmbeddingChunkRecord,
  UploadedDocument,
  SessionImage,
  UserTemplate,
  TemplateDraft,
} from "./types";

const db = new Dexie("DocBuilderDB") as Dexie & {
  sessions: EntityTable<Session, "id">;
  chatMessages: EntityTable<ChatMessage, "id">;
  conversations: EntityTable<Conversation, "id">;
  embeddingChunks: EntityTable<EmbeddingChunkRecord, "id">;
  uploadedDocuments: EntityTable<UploadedDocument, "id">;
  sessionImages: Table<SessionImage, [string, string]>;
  userTemplates: EntityTable<UserTemplate, "id">;
  templateDrafts: EntityTable<TemplateDraft, "id">;
};

db.version(1).stores({
  sessions: "id, documentTypeId, updatedAt",
});

db.version(2).stores({
  sessions: "id, documentTypeId, updatedAt",
  chatMessages: "id, [sessionId+fieldKey], createdAt",
});

// v3: adds optional fieldMeta to sessions (no index change needed)
db.version(3).stores({
  sessions: "id, documentTypeId, updatedAt",
  chatMessages: "id, [sessionId+fieldKey], createdAt",
});

// v4: adds embeddingChunks table for RAG
db.version(4).stores({
  sessions: "id, documentTypeId, updatedAt",
  chatMessages: "id, [sessionId+fieldKey], createdAt",
  embeddingChunks: "id, docId, [docId+index]",
});

// v5: adds uploadedDocuments table for persisted user uploads
db.version(5).stores({
  sessions: "id, documentTypeId, updatedAt",
  chatMessages: "id, [sessionId+fieldKey], createdAt",
  embeddingChunks: "id, docId, [docId+index]",
  uploadedDocuments: "id, category, createdAt, lastUsedAt",
});

// v6: adds conversations metadata table and sessionId index on chatMessages
db.version(6).stores({
  sessions: "id, documentTypeId, updatedAt",
  chatMessages: "id, [sessionId+fieldKey], sessionId, createdAt",
  conversations: "id, [sessionId+fieldKey], sessionId, documentTypeId, updatedAt",
  embeddingChunks: "id, docId, [docId+index]",
  uploadedDocuments: "id, category, createdAt, lastUsedAt",
});

// v7: adds setId index on sessions for multi-document set sessions
db.version(7).stores({
  sessions: "id, documentTypeId, setId, updatedAt",
  chatMessages: "id, [sessionId+fieldKey], sessionId, createdAt",
  conversations: "id, [sessionId+fieldKey], sessionId, documentTypeId, updatedAt",
  embeddingChunks: "id, docId, [docId+index]",
  uploadedDocuments: "id, category, createdAt, lastUsedAt",
});

// v8: adds optional isImage field to uploadedDocuments (no index change)
db.version(8).stores({
  sessions: "id, documentTypeId, setId, updatedAt",
  chatMessages: "id, [sessionId+fieldKey], sessionId, createdAt",
  conversations: "id, [sessionId+fieldKey], sessionId, documentTypeId, updatedAt",
  embeddingChunks: "id, docId, [docId+index]",
  uploadedDocuments: "id, category, createdAt, lastUsedAt",
});

// v9: adds optional uploadEndpoint to uploadedDocuments (no index change)
db.version(9).stores({
  sessions: "id, documentTypeId, setId, updatedAt",
  chatMessages: "id, [sessionId+fieldKey], sessionId, createdAt",
  conversations: "id, [sessionId+fieldKey], sessionId, documentTypeId, updatedAt",
  embeddingChunks: "id, docId, [docId+index]",
  uploadedDocuments: "id, category, createdAt, lastUsedAt",
});

// v10: adds sessionImages table for user-uploaded figures in image fields;
// also adds optional cuiOverride to uploadedDocuments (no index change —
// queried via filter on category, not indexed directly)
db.version(10).stores({
  sessions: "id, documentTypeId, setId, updatedAt",
  chatMessages: "id, [sessionId+fieldKey], sessionId, createdAt",
  conversations: "id, [sessionId+fieldKey], sessionId, documentTypeId, updatedAt",
  embeddingChunks: "id, docId, [docId+index]",
  uploadedDocuments: "id, category, createdAt, lastUsedAt",
  sessionImages: "[sessionId+fieldKey], sessionId",
});

// v11: replaces cuiOverride with cuiStatus (no index change). Migrates:
//   uploadEndpoint === "cui" && cuiOverride !== false -> "cui"
//   cuiOverride === false                             -> "not-cui"
//   otherwise                                          -> "pending"
db.version(11)
  .stores({
    sessions: "id, documentTypeId, setId, updatedAt",
    chatMessages: "id, [sessionId+fieldKey], sessionId, createdAt",
    conversations: "id, [sessionId+fieldKey], sessionId, documentTypeId, updatedAt",
    embeddingChunks: "id, docId, [docId+index]",
    uploadedDocuments: "id, category, createdAt, lastUsedAt",
  })
  .upgrade(async (tx) => {
    await tx
      .table("uploadedDocuments")
      .toCollection()
      .modify((doc: UploadedDocument & { cuiOverride?: boolean }) => {
        if (doc.uploadEndpoint === "cui" && doc.cuiOverride !== false) {
          doc.cuiStatus = "cui";
        } else if (doc.cuiOverride === false) {
          doc.cuiStatus = "not-cui";
        } else {
          doc.cuiStatus = "pending";
        }
        delete doc.cuiOverride;
      });
  });

// v12: adds userTemplates (uploaded schema + .docx pairs). No data migration.
db.version(12).stores({
  sessions: "id, documentTypeId, setId, updatedAt",
  chatMessages: "id, [sessionId+fieldKey], sessionId, createdAt",
  conversations: "id, [sessionId+fieldKey], sessionId, documentTypeId, updatedAt",
  embeddingChunks: "id, docId, [docId+index]",
  uploadedDocuments: "id, category, createdAt, lastUsedAt",
  sessionImages: "[sessionId+fieldKey], sessionId",
  userTemplates: "id, originalId, updatedAt",
});

// v13: adds templateDrafts (templates being built in the editor). No data migration.
db.version(13).stores({
  sessions: "id, documentTypeId, setId, updatedAt",
  chatMessages: "id, [sessionId+fieldKey], sessionId, createdAt",
  conversations: "id, [sessionId+fieldKey], sessionId, documentTypeId, updatedAt",
  embeddingChunks: "id, docId, [docId+index]",
  uploadedDocuments: "id, category, createdAt, lastUsedAt",
  sessionImages: "[sessionId+fieldKey], sessionId",
  userTemplates: "id, originalId, updatedAt",
  templateDrafts: "id, updatedAt",
});

// v14: indexes uploadedDocuments.contentHash (re-upload matching). No data
// migration — older records can't be backfilled because the original bytes
// aren't stored.
db.version(14).stores({
  sessions: "id, documentTypeId, setId, updatedAt",
  chatMessages: "id, [sessionId+fieldKey], sessionId, createdAt",
  conversations: "id, [sessionId+fieldKey], sessionId, documentTypeId, updatedAt",
  embeddingChunks: "id, docId, [docId+index]",
  uploadedDocuments: "id, category, createdAt, lastUsedAt, contentHash",
  sessionImages: "[sessionId+fieldKey], sessionId",
  userTemplates: "id, originalId, updatedAt",
  templateDrafts: "id, updatedAt",
});

export { db };
