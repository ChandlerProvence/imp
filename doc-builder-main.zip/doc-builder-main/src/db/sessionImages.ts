import { db } from "./dexie";
import type { SessionImage } from "./types";

/**
 * Save or update an image for a session field.
 * Overwrites any existing image for the same session + fieldKey combination.
 */
export async function saveSessionImage(image: SessionImage): Promise<void> {
  await db.sessionImages.put(image);
}

/**
 * Get an image for a specific session field.
 */
export async function getSessionImage(
  sessionId: string,
  fieldKey: string,
): Promise<SessionImage | undefined> {
  return db.sessionImages.get([sessionId, fieldKey]);
}

/**
 * Get all images for a session.
 */
export async function getSessionImages(
  sessionId: string,
): Promise<SessionImage[]> {
  return db.sessionImages.where("sessionId").equals(sessionId).toArray();
}

/**
 * Delete a specific image by session + fieldKey.
 */
export async function deleteSessionImage(
  sessionId: string,
  fieldKey: string,
): Promise<void> {
  await db.sessionImages.delete([sessionId, fieldKey]);
}

/**
 * Delete all images for a session (cascade on session delete).
 */
export async function deleteAllSessionImages(
  sessionId: string,
): Promise<void> {
  await db.sessionImages.where("sessionId").equals(sessionId).delete();
}
