import { db } from "./dexie";
import type { EmbeddingChunkRecord } from "./types";

/**
 * Get all cached embedding chunks for a reference doc.
 */
export async function getChunksForDoc(docId: string): Promise<EmbeddingChunkRecord[]> {
  return db.embeddingChunks.where("docId").equals(docId).sortBy("index");
}

/**
 * Get the sourceHash of the first cached chunk for a doc (for invalidation check).
 * Returns null if no cached chunks exist.
 */
export async function getCachedSourceHash(docId: string): Promise<string | null> {
  const first = await db.embeddingChunks.where("docId").equals(docId).first();
  return first?.sourceHash ?? null;
}

/**
 * Get the sourceHash + embedding model of the first cached chunk for a doc.
 * A cache hit requires BOTH to match — IL2 and IL5 use different embedding
 * models, so vectors computed under one are meaningless (and incompatible
 * dimensionally) under the other.
 */
export async function getCachedChunkMeta(
  docId: string,
): Promise<{ sourceHash: string; model: string } | null> {
  const first = await db.embeddingChunks.where("docId").equals(docId).first();
  if (!first) return null;
  return { sourceHash: first.sourceHash, model: first.model };
}

/**
 * Store embedding chunks in IndexedDB (replaces any existing chunks for this docId).
 */
export async function storeChunks(chunks: EmbeddingChunkRecord[]): Promise<void> {
  if (chunks.length === 0) return;
  const docId = chunks[0].docId;
  await db.transaction("rw", db.embeddingChunks, async () => {
    await db.embeddingChunks.where("docId").equals(docId).delete();
    await db.embeddingChunks.bulkAdd(chunks);
  });
}

/**
 * Delete all cached chunks for a reference doc.
 */
export async function deleteChunksForDoc(docId: string): Promise<void> {
  await db.embeddingChunks.where("docId").equals(docId).delete();
}
