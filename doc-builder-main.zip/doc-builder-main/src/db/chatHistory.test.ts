import { beforeEach, describe, expect, it } from "vitest";
import { db } from "./dexie";
import {
  addMessage,
  clearConversation,
  deleteAllConversationsForSession,
  deleteConversation,
  getAllConversations,
  getConversation,
  getConversationsForSession,
  upsertConversation,
} from "./chatHistory";
import type { Conversation } from "./types";

function meta(sessionId: string, fieldKey: string, label = "Label") {
  return {
    sessionId,
    fieldKey,
    documentTypeId: "test-schema",
    documentTypeTitle: "Test Document",
    label,
    conversationType: "field-chat" as const,
  };
}

function conv(overrides: Partial<Conversation>): Conversation {
  return {
    id: crypto.randomUUID(),
    ...meta("s1", "a.b"),
    messageCount: 0,
    createdAt: new Date("2026-01-01"),
    updatedAt: new Date("2026-01-01"),
    ...overrides,
  };
}

function msg(sessionId: string, fieldKey: string, content: string) {
  return addMessage({ sessionId, fieldKey, role: "user", content });
}

describe("chatHistory", () => {
  beforeEach(async () => {
    await db.chatMessages.clear();
    await db.conversations.clear();
  });

  describe("messages", () => {
    it("addMessage returns the stored record with id and timestamp", async () => {
      const rec = await addMessage({
        sessionId: "s1",
        fieldKey: "a.b",
        role: "assistant",
        content: "hi",
        displayLabel: "Hi",
        toolCallId: "t1",
      });
      expect(rec.id).toEqual(expect.any(String));
      expect(rec.createdAt).toBeInstanceOf(Date);
      expect(await db.chatMessages.get(rec.id)).toMatchObject({
        sessionId: "s1",
        fieldKey: "a.b",
        role: "assistant",
        content: "hi",
        displayLabel: "Hi",
        toolCallId: "t1",
      });
    });

    it("getConversation returns messages in createdAt order regardless of insert order", async () => {
      await db.chatMessages.bulkAdd([
        { id: "m3", sessionId: "s1", fieldKey: "a.b", role: "user", content: "third", createdAt: new Date(3000) },
        { id: "m1", sessionId: "s1", fieldKey: "a.b", role: "user", content: "first", createdAt: new Date(1000) },
        { id: "m2", sessionId: "s1", fieldKey: "a.b", role: "assistant", content: "second", createdAt: new Date(2000) },
      ]);
      expect((await getConversation("s1", "a.b")).map((m) => m.content)).toEqual(["first", "second", "third"]);
    });

    it("isolates conversations by (sessionId, fieldKey)", async () => {
      await msg("s1", "a.b", "s1-ab");
      await msg("s1", "a.c", "s1-ac");
      await msg("s2", "a.b", "s2-ab");
      expect((await getConversation("s1", "a.b")).map((m) => m.content)).toEqual(["s1-ab"]);
      expect((await getConversation("s1", "a.c")).map((m) => m.content)).toEqual(["s1-ac"]);
      expect((await getConversation("s2", "a.b")).map((m) => m.content)).toEqual(["s2-ab"]);
      expect(await getConversation("s3", "a.b")).toEqual([]);
    });

    it("clearConversation removes only that conversation's messages", async () => {
      await msg("s1", "a.b", "x");
      await msg("s1", "a.b", "y");
      await msg("s1", "a.c", "keep");
      await clearConversation("s1", "a.b");
      expect(await getConversation("s1", "a.b")).toEqual([]);
      expect(await getConversation("s1", "a.c")).toHaveLength(1);
    });
  });

  describe("conversation metadata", () => {
    it("upsertConversation inserts with the current message count", async () => {
      await msg("s1", "a.b", "one");
      await msg("s1", "a.b", "two");
      await upsertConversation(meta("s1", "a.b", "Field B"));
      const rows = await db.conversations.toArray();
      expect(rows).toHaveLength(1);
      expect(rows[0]).toMatchObject({ sessionId: "s1", fieldKey: "a.b", label: "Field B", messageCount: 2 });
      expect(rows[0].createdAt).toBeInstanceOf(Date);
    });

    it("upsertConversation updates count and updatedAt only, without duplicating", async () => {
      await db.conversations.add(conv({ id: "c1", messageCount: 0, label: "Original" }));
      await msg("s1", "a.b", "one");
      await upsertConversation(meta("s1", "a.b", "Changed"));
      const rows = await db.conversations.toArray();
      expect(rows).toHaveLength(1);
      expect(rows[0].id).toBe("c1");
      expect(rows[0].messageCount).toBe(1);
      expect(rows[0].label).toBe("Original");
      expect(rows[0].createdAt).toEqual(new Date("2026-01-01"));
      expect(rows[0].updatedAt.getTime()).toBeGreaterThan(new Date("2026-01-01").getTime());
    });

    it("getAllConversations returns most recently updated first", async () => {
      await db.conversations.bulkAdd([
        conv({ id: "old", fieldKey: "a.1", updatedAt: new Date(1000) }),
        conv({ id: "new", sessionId: "s2", fieldKey: "a.2", updatedAt: new Date(3000) }),
        conv({ id: "mid", fieldKey: "a.3", updatedAt: new Date(2000) }),
      ]);
      expect((await getAllConversations()).map((c) => c.id)).toEqual(["new", "mid", "old"]);
    });

    it("getConversationsForSession filters by session, most recent first", async () => {
      await db.conversations.bulkAdd([
        conv({ id: "a", fieldKey: "a.1", updatedAt: new Date(1000) }),
        conv({ id: "b", fieldKey: "a.2", updatedAt: new Date(3000) }),
        conv({ id: "other", sessionId: "s2", fieldKey: "a.3", updatedAt: new Date(5000) }),
      ]);
      expect((await getConversationsForSession("s1")).map((c) => c.id)).toEqual(["b", "a"]);
      expect(await getConversationsForSession("nope")).toEqual([]);
    });

    it("deleteConversation removes messages and metadata for that pair only", async () => {
      await msg("s1", "a.b", "x");
      await msg("s1", "a.c", "y");
      await upsertConversation(meta("s1", "a.b"));
      await upsertConversation(meta("s1", "a.c"));
      await deleteConversation("s1", "a.b");
      expect(await getConversation("s1", "a.b")).toEqual([]);
      expect(await getConversation("s1", "a.c")).toHaveLength(1);
      expect((await db.conversations.toArray()).map((c) => c.fieldKey)).toEqual(["a.c"]);
    });

    it("deleteConversation without metadata just clears messages", async () => {
      await msg("s1", "a.b", "x");
      await deleteConversation("s1", "a.b");
      expect(await db.chatMessages.count()).toBe(0);
    });

    it("deleteAllConversationsForSession only touches that session", async () => {
      await msg("s1", "a.b", "x");
      await msg("s1", "a.c", "y");
      await msg("s2", "a.b", "z");
      await upsertConversation(meta("s1", "a.b"));
      await upsertConversation(meta("s1", "a.c"));
      await upsertConversation(meta("s2", "a.b"));
      await deleteAllConversationsForSession("s1");
      expect((await db.chatMessages.toArray()).map((m) => m.sessionId)).toEqual(["s2"]);
      expect((await db.conversations.toArray()).map((c) => c.sessionId)).toEqual(["s2"]);
    });
  });
});
