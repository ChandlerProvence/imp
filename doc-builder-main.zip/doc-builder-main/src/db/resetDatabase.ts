/**
 * Last-resort recovery: delete the IndexedDB database and localStorage, then
 * reload. Shared by the root ErrorBoundary and the storage-open failure page.
 */
export async function clearDataAndReload(): Promise<void> {
  try {
    const { db } = await import("./dexie");
    await db.delete();
  } catch {
    // If Dexie fails, try raw IndexedDB API
    indexedDB.deleteDatabase("DocBuilderDB");
  }
  localStorage.clear();
  window.location.reload();
}
