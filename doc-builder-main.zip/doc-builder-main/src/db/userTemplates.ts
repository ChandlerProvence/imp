import { db } from "./dexie";
import type { UserTemplate } from "./types";
import { migrateStoredRecord } from "../schemas/migrateStored";

// Reads run every stored schema through migrateStoredRecord, so templates
// saved before a schema-shape change load in the current shape everywhere
// (startup registration, the editor, Manage Templates, export). The stored
// record is rewritten the next time it is saved.

/** All stored user templates, newest first. */
export async function listUserTemplates(): Promise<UserTemplate[]> {
  return (await db.userTemplates.orderBy("updatedAt").reverse().toArray()).map(migrateStoredRecord);
}

export async function getUserTemplate(id: string): Promise<UserTemplate | undefined> {
  const record = await db.userTemplates.get(id);
  return record && migrateStoredRecord(record);
}

/** Insert or overwrite a user template record. */
export async function putUserTemplate(template: UserTemplate): Promise<void> {
  await db.userTemplates.put(template);
}

export async function updateUserTemplate(id: string, changes: Partial<UserTemplate>): Promise<void> {
  await db.userTemplates.update(id, changes);
}

export async function deleteUserTemplateRecord(id: string): Promise<void> {
  await db.userTemplates.delete(id);
}

/** Number of sessions whose document type is the given schema. */
export async function countSessionsForSchema(schemaId: string): Promise<number> {
  return db.sessions.where("documentTypeId").equals(schemaId).count();
}
