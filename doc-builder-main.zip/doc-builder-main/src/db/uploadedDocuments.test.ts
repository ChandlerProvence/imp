import { beforeEach, describe, expect, it } from "vitest";
import { db } from "./dexie";
import {
  getUploadedDocumentByRefId,
  getUploadedDocumentsByCategory,
  saveUploadedDocument,
  updateDocumentRole,
} from "./uploadedDocuments";
import type { UploadedDocument } from "./types";

function doc(overrides: Partial<UploadedDocument> = {}): Omit<UploadedDocument, "id"> {
  const now = new Date().toISOString();
  return {
    fileName: "pws.pdf",
    mimeType: "application/pdf",
    fileSize: 100,
    textContent: "v1",
    charCount: 2,
    category: "fms",
    createdAt: now,
    lastUsedAt: now,
    ...overrides,
  };
}

describe("uploadedDocuments slot role label", () => {
  beforeEach(async () => {
    await db.uploadedDocuments.clear();
  });

  it("sets and clears the role label", async () => {
    const saved = await saveUploadedDocument(doc());
    await updateDocumentRole(saved.id, { slotId: "pws", title: "PWS" });
    expect((await db.uploadedDocuments.get(saved.id))?.slotRole).toEqual({ slotId: "pws", title: "PWS" });

    await updateDocumentRole(saved.id, null);
    expect((await db.uploadedDocuments.get(saved.id))?.slotRole).toBeUndefined();
  });

  it("keeps the role label when the same file is re-uploaded", async () => {
    const saved = await saveUploadedDocument(doc({ contentHash: "aaa" }));
    await updateDocumentRole(saved.id, { slotId: "pws", title: "PWS" });

    const again = await saveUploadedDocument(doc({ contentHash: "aaa", textContent: "v2", charCount: 2 }));
    expect(again.id).toBe(saved.id);
    expect(again.slotRole).toEqual({ slotId: "pws", title: "PWS" });
    expect((await db.uploadedDocuments.get(saved.id))?.textContent).toBe("v2");
  });
});

describe("bundled reference docs are locked as not CUI", () => {
  beforeEach(async () => {
    await db.uploadedDocuments.clear();
  });

  it("repairs a cached reference copy stamped CUI", async () => {
    const saved = await saveUploadedDocument(
      doc({ fileName: "contacts.xlsx", source: "reference", refId: "contacts", cuiStatus: "cui" }),
    );

    const [listed] = await getUploadedDocumentsByCategory("fms");
    expect(listed.cuiStatus).toBe("not-cui");
    expect((await db.uploadedDocuments.get(saved.id))?.cuiStatus).toBe("not-cui");
  });

  it("repairs a flagged copy found by ref id and drops the detection", async () => {
    await saveUploadedDocument(
      doc({
        fileName: "contacts.xlsx",
        source: "reference",
        refId: "contacts",
        cuiStatus: "flagged",
        cuiDetection: { isCui: true, markers: ["CUI"], method: "regex" } as UploadedDocument["cuiDetection"],
      }),
    );

    const found = await getUploadedDocumentByRefId("contacts", "fms");
    expect(found?.cuiStatus).toBe("not-cui");
    expect(found?.cuiDetection).toBeUndefined();
  });

  it("leaves user uploads alone", async () => {
    await saveUploadedDocument(doc({ source: "upload", cuiStatus: "cui" }));
    const [listed] = await getUploadedDocumentsByCategory("fms");
    expect(listed.cuiStatus).toBe("cui");
  });
});

describe("re-upload matching by content hash", () => {
  beforeEach(async () => {
    await db.uploadedDocuments.clear();
  });

  it("keeps same-name, same-size files with different content as separate records", async () => {
    const a = await saveUploadedDocument(doc({ contentHash: "aaa", textContent: "first" }));
    const b = await saveUploadedDocument(doc({ contentHash: "bbb", textContent: "second" }));
    expect(b.id).not.toBe(a.id);
    expect(await db.uploadedDocuments.count()).toBe(2);
    expect((await db.uploadedDocuments.get(a.id))?.textContent).toBe("first");
  });

  it("reuses the record for the same content under a new name and updates the name", async () => {
    const saved = await saveUploadedDocument(
      doc({ contentHash: "aaa", createdAt: "2026-01-01T00:00:00.000Z" }),
    );
    await updateDocumentRole(saved.id, { slotId: "pws", title: "PWS" });

    const again = await saveUploadedDocument(
      doc({ contentHash: "aaa", fileName: "pws-renamed.pdf", textContent: "v2" }),
    );
    expect(again.id).toBe(saved.id);
    expect(await db.uploadedDocuments.count()).toBe(1);
    const stored = await db.uploadedDocuments.get(saved.id);
    expect(stored?.fileName).toBe("pws-renamed.pdf");
    expect(stored?.textContent).toBe("v2");
    expect(stored?.contentHash).toBe("aaa");
    expect(stored?.createdAt).toBe("2026-01-01T00:00:00.000Z");
    expect(stored?.slotRole).toEqual({ slotId: "pws", title: "PWS" });
  });

  it("reuses a legacy record with the same name and text and gives it the hash", async () => {
    await db.uploadedDocuments.add({ id: "legacy", ...doc({ createdAt: "2026-01-01T00:00:00.000Z" }) });
    await updateDocumentRole("legacy", { slotId: "pws", title: "PWS" });

    const saved = await saveUploadedDocument(doc({ contentHash: "aaa" }));
    expect(saved.id).toBe("legacy");
    expect(await db.uploadedDocuments.count()).toBe(1);
    const stored = await db.uploadedDocuments.get("legacy");
    expect(stored?.contentHash).toBe("aaa");
    expect(stored?.createdAt).toBe("2026-01-01T00:00:00.000Z");
    expect(stored?.slotRole).toEqual({ slotId: "pws", title: "PWS" });
  });

  it("does not match a legacy record with the same name but different text", async () => {
    await db.uploadedDocuments.add({ id: "legacy", ...doc({ textContent: "old" }) });
    const saved = await saveUploadedDocument(doc({ contentHash: "aaa", textContent: "new" }));
    expect(saved.id).not.toBe("legacy");
    expect(await db.uploadedDocuments.count()).toBe(2);
    expect((await db.uploadedDocuments.get("legacy"))?.contentHash).toBeUndefined();
  });

  it("picks the most recently used legacy candidate", async () => {
    await db.uploadedDocuments.add({ id: "older", ...doc({ lastUsedAt: "2026-01-01T00:00:00.000Z" }) });
    await db.uploadedDocuments.add({ id: "newer", ...doc({ lastUsedAt: "2026-06-01T00:00:00.000Z" }) });
    const saved = await saveUploadedDocument(doc({ contentHash: "aaa" }));
    expect(saved.id).toBe("newer");
    expect((await db.uploadedDocuments.get("older"))?.contentHash).toBeUndefined();
  });

  it("does not match a legacy record in another category", async () => {
    await db.uploadedDocuments.add({ id: "legacy", ...doc({ category: "legal" }) });
    const saved = await saveUploadedDocument(doc({ contentHash: "aaa", category: "fms" }));
    expect(saved.id).not.toBe("legacy");
    expect(await db.uploadedDocuments.count()).toBe(2);
  });

  it("an identical user upload does not take over a bundled reference doc", async () => {
    const ref = await saveUploadedDocument(
      doc({ contentHash: "aaa", fileName: "contacts.xlsx", source: "reference", refId: "contacts", cuiStatus: "not-cui", lastUsedAt: "2026-01-01T00:00:00.000Z" }),
    );
    const again = await saveUploadedDocument(
      doc({ contentHash: "aaa", fileName: "my-contacts.xlsx", source: "upload", cuiStatus: "pending" }),
    );
    expect(again.id).toBe(ref.id);
    expect(await db.uploadedDocuments.count()).toBe(1);
    const stored = await db.uploadedDocuments.get(ref.id);
    expect(stored?.source).toBe("reference");
    expect(stored?.refId).toBe("contacts");
    expect(stored?.cuiStatus).toBe("not-cui");
    expect(stored?.fileName).toBe("contacts.xlsx");
    expect(stored?.lastUsedAt).not.toBe("2026-01-01T00:00:00.000Z");
  });

  it("creates a new record when the caller passes no content hash", async () => {
    const a = await saveUploadedDocument(doc());
    const b = await saveUploadedDocument(doc());
    expect(b.id).not.toBe(a.id);
    expect(await db.uploadedDocuments.count()).toBe(2);
  });

  it("keeps the same content in a different category as a separate record", async () => {
    const a = await saveUploadedDocument(doc({ contentHash: "aaa", category: "fms" }));
    const b = await saveUploadedDocument(doc({ contentHash: "aaa", category: "legal" }));
    expect(b.id).not.toBe(a.id);
    expect((await db.uploadedDocuments.get(a.id))?.category).toBe("fms");
    expect((await db.uploadedDocuments.get(b.id))?.category).toBe("legal");
  });
});
