import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("../ai/endpoints", () => ({
  getActiveEndpointConfig: vi.fn(() => ({
    id: "non-cui",
    label: "Proprietary",
    shortLabel: "Prop",
    description: "",
    baseUrl: "https://proxy.example",
    devProxyPath: "/proxy",
  })),
}));
vi.mock("../ai/models", () => ({
  getModelResolution: vi.fn(() => [
    { role: "standard", id: "model-std", source: "default", configured: "model-std" },
  ]),
}));
vi.mock("../schemas/loader", () => ({ getSchema: vi.fn() }));
vi.mock("../utils/fileSave", () => ({ saveFile: vi.fn() }));

import { db } from "./dexie";
import { downloadChatTroubleshoot, exportChatForTroubleshooting } from "./chatTroubleshootExport";
import { getSchema } from "../schemas/loader";
import { getModelResolution } from "../ai/models";
import { saveFile } from "../utils/fileSave";
import { createMockSchema, createMockSession } from "../test/mocks";
import type { Conversation } from "./types";

const conversation: Conversation = {
  id: "c1",
  sessionId: "session-1",
  fieldKey: "sec.field",
  documentTypeId: "test-schema",
  documentTypeTitle: "Test Document",
  label: "Field Chat",
  conversationType: "bulk-edit",
  messageCount: 2,
  config: { mode: "prompt", prompt: "do it", selectedSectionIds: ["sec"] },
  createdAt: new Date("2026-02-01T00:00:00Z"),
  updatedAt: new Date("2026-02-02T00:00:00Z"),
};

async function seed() {
  await db.sessions.add(
    createMockSession({
      answers: { "sec.a": "secret value", "sec.b": "", "sec.c": 0, "sec.d": false },
      setId: "set-x",
    }),
  );
  await db.chatMessages.bulkAdd([
    {
      id: "m2",
      sessionId: "session-1",
      fieldKey: "sec.field",
      role: "tool",
      content: "tool result",
      toolCallId: "call-1",
      createdAt: new Date("2026-02-01T00:00:02Z"),
    },
    {
      id: "m1",
      sessionId: "session-1",
      fieldKey: "sec.field",
      role: "assistant",
      content: "calling",
      toolCalls: [{ id: "call-1", type: "function", function: { name: "t", arguments: "{}" } }],
      createdAt: new Date("2026-02-01T00:00:01Z"),
    },
    {
      id: "other",
      sessionId: "session-1",
      fieldKey: "sec.other",
      role: "user",
      content: "not included",
      createdAt: new Date("2026-02-01T00:00:00Z"),
    },
  ]);
}

describe("exportChatForTroubleshooting", () => {
  beforeEach(async () => {
    await db.sessions.clear();
    await db.chatMessages.clear();
    await db.conversations.clear();
    vi.mocked(getSchema).mockReset();
    vi.mocked(saveFile).mockReset();
  });

  it("throws when the session does not exist", async () => {
    await expect(exportChatForTroubleshooting("missing", "x")).rejects.toThrow("Session not found: missing");
  });

  it("builds the envelope from db rows", async () => {
    await seed();
    await db.conversations.add(conversation);
    vi.mocked(getSchema).mockReturnValue(createMockSchema({ title: "Pretty Title" }));

    const out = await exportChatForTroubleshooting("session-1", "sec.field");

    expect(out._type).toBe("doc-builder-chat-troubleshoot");
    expect(out.version).toBe(1);
    expect(new Date(out.exportedAt).toISOString()).toBe(out.exportedAt);
    expect(out._humanSummary).toBe('2 messages in "Field Chat" for "Pretty Title" on Proprietary endpoint');
    expect(out.endpoint).toEqual({
      id: "non-cui",
      label: "Proprietary",
      baseUrl: "https://proxy.example",
      models: [{ role: "standard", id: "model-std", source: "default", configured: "model-std" }],
    });
    expect(getModelResolution).toHaveBeenCalledWith("non-cui");
    expect(out.session).toEqual({
      id: "session-1",
      documentTypeId: "test-schema",
      schemaTitle: "Pretty Title",
      answeredFieldKeys: ["sec.a", "sec.c", "sec.d"],
      setId: "set-x",
      createdAt: "2026-01-01T00:00:00.000Z",
      updatedAt: "2026-01-01T00:00:00.000Z",
    });
    expect(out.conversation).toEqual({
      fieldKey: "sec.field",
      label: "Field Chat",
      conversationType: "bulk-edit",
      messageCount: 2,
      config: conversation.config,
      createdAt: "2026-02-01T00:00:00.000Z",
      updatedAt: "2026-02-02T00:00:00.000Z",
    });
    expect(out.messages).toEqual([
      {
        role: "assistant",
        content: "calling",
        toolCalls: [{ id: "call-1", type: "function", function: { name: "t", arguments: "{}" } }],
        createdAt: "2026-02-01T00:00:01.000Z",
      },
      { role: "tool", content: "tool result", toolCallId: "call-1", createdAt: "2026-02-01T00:00:02.000Z" },
    ]);
    expect(out.environment).toEqual({
      userAgent: navigator.userAgent,
      timestamp: expect.any(String),
      url: window.location.href,
    });
  });

  it("redacts answer values and does not include API keys", async () => {
    localStorage.setItem("litellm-api-key", "sk-super-secret");
    await seed();
    const json = JSON.stringify(await exportChatForTroubleshooting("session-1", "sec.field"));
    expect(json).not.toContain("secret value");
    expect(json).not.toContain("sk-super-secret");
  });

  it("falls back to fieldKey/documentTypeId and null conversation when metadata and schema are missing", async () => {
    await seed();
    vi.mocked(getSchema).mockReturnValue(undefined);
    const out = await exportChatForTroubleshooting("session-1", "sec.other");
    expect(out.conversation).toBeNull();
    expect(out.session.schemaTitle).toBe("test-schema");
    expect(out._humanSummary).toBe('1 message in "sec.other" for "test-schema" on Proprietary endpoint');
    expect(out.session).not.toHaveProperty("customSchema");
  });

  it("includes the schema for custom templates only", async () => {
    await seed();
    const custom = createMockSchema({ id: "custom-abc", title: "Mine" });
    vi.mocked(getSchema).mockReturnValue(custom);
    const out = await exportChatForTroubleshooting("session-1", "sec.field");
    expect(out.session.customSchema).toEqual(custom);
  });

  it("stringifies non-Date timestamps", async () => {
    await db.sessions.add(
      createMockSession({ createdAt: "2026-03-01" as unknown as Date, updatedAt: "2026-03-02" as unknown as Date }),
    );
    const out = await exportChatForTroubleshooting("session-1", "sec.field");
    expect(out.session.createdAt).toBe("2026-03-01");
    expect(out.session.updatedAt).toBe("2026-03-02");
    expect(out.messages).toEqual([]);
    expect(out._humanSummary).toMatch(/^0 messages /);
  });
});

describe("downloadChatTroubleshoot", () => {
  beforeEach(async () => {
    await db.sessions.clear();
    await db.chatMessages.clear();
    await db.conversations.clear();
    vi.mocked(saveFile).mockReset();
    vi.mocked(saveFile).mockResolvedValue(true);
  });

  it("saves pretty JSON under a slugged, timestamped filename", async () => {
    await seed();
    const ok = await downloadChatTroubleshoot("session-1", "sec.field", "My <Doc>: Title");
    expect(ok).toBe(true);

    const { blob, filename, types } = vi.mocked(saveFile).mock.calls[0][0];
    expect(filename).toMatch(/^my-doc-title-chat-troubleshoot-\d{4}-\d{2}-\d{2}T\d{4}\.json$/);
    expect(types).toEqual([{ description: "JSON files", accept: { "application/json": [".json"] } }]);
    expect(blob.type).toBe("application/json;charset=utf-8");
    const text = await blob.text();
    expect(text).toContain('\n  "_type": "doc-builder-chat-troubleshoot"');
    expect(JSON.parse(text).messages).toHaveLength(2);
  });

  it("strips control characters from the filename", async () => {
    await seed();
    await downloadChatTroubleshoot("session-1", "sec.field", "A\u0001B\tC");
    expect(vi.mocked(saveFile).mock.calls[0][0].filename).toMatch(/^abc-chat-troubleshoot-/);
  });

  it("returns false when the user cancels", async () => {
    await seed();
    vi.mocked(saveFile).mockResolvedValue(false);
    expect(await downloadChatTroubleshoot("session-1", "sec.field", "X")).toBe(false);
  });
});
