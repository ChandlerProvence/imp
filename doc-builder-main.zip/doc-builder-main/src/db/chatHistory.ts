import { db } from "./dexie";
import type { ChatMessage, Conversation } from "./types";

// ---------------------------------------------------------------------------
// Chat Messages
// ---------------------------------------------------------------------------

/** Retrieve all messages for a given session + field, in chronological order. */
export async function getConversation(
  sessionId: string,
  fieldKey: string,
): Promise<ChatMessage[]> {
  return db.chatMessages
    .where("[sessionId+fieldKey]")
    .equals([sessionId, fieldKey])
    .sortBy("createdAt");
}

/** Persist a new message and return it with generated id + timestamp. */
export async function addMessage(
  msg: Pick<ChatMessage, "sessionId" | "fieldKey" | "role" | "content"> &
    Partial<Pick<ChatMessage, "displayLabel" | "toolCalls" | "toolCallId" | "timings">>,
): Promise<ChatMessage> {
  const record: ChatMessage = {
    id: crypto.randomUUID(),
    sessionId: msg.sessionId,
    fieldKey: msg.fieldKey,
    role: msg.role,
    content: msg.content,
    displayLabel: msg.displayLabel,
    toolCalls: msg.toolCalls,
    toolCallId: msg.toolCallId,
    timings: msg.timings,
    createdAt: new Date(),
  };
  await db.chatMessages.add(record);
  return record;
}

/** Delete all messages for a given session + field (start new conversation). */
export async function clearConversation(
  sessionId: string,
  fieldKey: string,
): Promise<void> {
  const ids = await db.chatMessages
    .where("[sessionId+fieldKey]")
    .equals([sessionId, fieldKey])
    .primaryKeys();
  await db.chatMessages.bulkDelete(ids);
}

// ---------------------------------------------------------------------------
// Conversation Metadata
// ---------------------------------------------------------------------------

/**
 * Create or update the conversation metadata record for a session + field.
 * Call this when adding messages to keep the metadata in sync.
 * Uses a transaction to avoid duplicate records from concurrent calls.
 */
export async function upsertConversation(
  meta: Omit<Conversation, "id" | "messageCount" | "createdAt" | "updatedAt">,
): Promise<void> {
  await db.transaction("rw", [db.conversations, db.chatMessages], async () => {
    const existing = await db.conversations
      .where("[sessionId+fieldKey]")
      .equals([meta.sessionId, meta.fieldKey])
      .first();

    const count = await db.chatMessages
      .where("[sessionId+fieldKey]")
      .equals([meta.sessionId, meta.fieldKey])
      .count();

    if (existing) {
      await db.conversations.update(existing.id, {
        messageCount: count,
        updatedAt: new Date(),
      });
    } else {
      const record: Conversation = {
        id: crypto.randomUUID(),
        ...meta,
        messageCount: count,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      await db.conversations.add(record);
    }
  });
}

/** Return all conversation metadata records, most recently updated first. */
export async function getAllConversations(): Promise<Conversation[]> {
  return db.conversations.orderBy("updatedAt").reverse().toArray();
}

/** Return conversation metadata for a single session. */
export async function getConversationsForSession(
  sessionId: string,
): Promise<Conversation[]> {
  return db.conversations
    .where("sessionId")
    .equals(sessionId)
    .reverse()
    .sortBy("updatedAt");
}

/** Delete a single conversation (messages + metadata). */
export async function deleteConversation(
  sessionId: string,
  fieldKey: string,
): Promise<void> {
  // Delete messages
  await clearConversation(sessionId, fieldKey);
  // Delete metadata
  const meta = await db.conversations
    .where("[sessionId+fieldKey]")
    .equals([sessionId, fieldKey])
    .first();
  if (meta) {
    await db.conversations.delete(meta.id);
  }
}

/** Delete all conversations for a session (explicit user action only — NOT called on session delete). */
export async function deleteAllConversationsForSession(
  sessionId: string,
): Promise<void> {
  // Delete all messages for this session
  const msgIds = await db.chatMessages
    .where("sessionId")
    .equals(sessionId)
    .primaryKeys();
  await db.chatMessages.bulkDelete(msgIds);

  // Delete all metadata for this session
  const metaIds = await db.conversations
    .where("sessionId")
    .equals(sessionId)
    .primaryKeys();
  await db.conversations.bulkDelete(metaIds);
}
