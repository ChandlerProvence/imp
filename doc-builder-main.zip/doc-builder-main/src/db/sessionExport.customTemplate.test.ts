import { describe, it, expect, beforeEach } from "vitest";
import { db } from "./dexie";
import { createSession, updateSession } from "./session";
import { exportSession, importSession, validateImportFile } from "./sessionExport";
import { installTemplate, reloadUserSchemas } from "../schemas/userSchemas";
import { validateUserTemplatePair } from "../schemas/userTemplateValidation";
import { getSchema } from "../schemas/loader";
import { buildDocx, para } from "../test/docxFixtures";

const schemaJson = (title = "Vendor Letter") =>
  JSON.stringify({
    id: "vendor-letter",
    title,
    version: 1,
    docx_template: "x.docx",
    sections: [{ id: "main", title: "Main", fields: [{ id: "vendor", label: "Vendor", type: "string", required: true }] }],
    template_key_map: { VENDOR: "main.vendor" },
  });

async function install(text = "Dear {{VENDOR}}") {
  const { prepared } = await validateUserTemplatePair({ schemaText: schemaJson(), docx: buildDocx(para(text)) });
  return installTemplate(prepared!);
}

/** Export a session on the custom template as it would be written to disk. */
async function exportCustomSession() {
  const session = await createSession("custom-vendor-letter", "main");
  await updateSession(session.id, { answers: { "main.vendor": "Acme" } });
  return JSON.parse(JSON.stringify(await exportSession(session.id)));
}

async function wipeToFreshMachine() {
  await db.userTemplates.clear();
  await db.sessions.clear();
  await reloadUserSchemas();
}

beforeEach(wipeToFreshMachine);

describe("session export with a custom template", () => {
  it("embeds the template with its original id", async () => {
    await install();
    const file = await exportCustomSession();
    expect(file.customTemplates).toHaveLength(1);
    expect(file.customTemplates[0].originalId).toBe("vendor-letter");
    expect(file.customTemplates[0].schema.id).toBe("vendor-letter");
    expect(file.customTemplates[0].docxBase64.length).toBeGreaterThan(0);
  });

  it("installs the embedded template when importing on a machine without it", async () => {
    await install();
    const file = await exportCustomSession();
    await wipeToFreshMachine();
    expect(getSchema("custom-vendor-letter")).toBeUndefined();

    const result = await validateImportFile(file);
    expect(result.errors).toEqual([]);
    expect(result.valid).toBe(true);
    expect(result.templateToInstall?.id).toBe("custom-vendor-letter");
    expect(result.warnings.join(" ")).toMatch(/will be added to this browser/);
    // Nothing is stored until the user confirms the import
    expect(await db.userTemplates.count()).toBe(0);

    const { sessionId } = await importSession(result.data!);
    expect(getSchema("custom-vendor-letter")?.title).toBe("Vendor Letter");
    const imported = await db.sessions.get(sessionId);
    expect(imported?.documentTypeId).toBe("custom-vendor-letter");
    expect(imported?.answers).toEqual({ "main.vendor": "Acme" });
  });

  it("keeps the installed version and warns when the file's version differs", async () => {
    await install("Dear {{VENDOR}}");
    const file = await exportCustomSession();
    await install("Hello {{VENDOR}}"); // replace locally → different bytes

    const result = await validateImportFile(file);
    expect(result.valid).toBe(true);
    expect(result.templateToInstall).toBeUndefined();
    expect(result.warnings.join(" ")).toMatch(/different version/);
  });

  it("rejects a custom-template session whose file has no embedded template", async () => {
    await install();
    const file = await exportCustomSession();
    delete file.customTemplates;
    await wipeToFreshMachine();
    const result = await validateImportFile(file);
    expect(result.valid).toBe(false);
  });

  it("rejects an embedded template that fails validation", async () => {
    await install();
    const file = await exportCustomSession();
    file.customTemplates[0].schema.template_key_map = { NOT_IN_TEMPLATE: "main.vendor" };
    await wipeToFreshMachine();
    const result = await validateImportFile(file);
    expect(result.valid).toBe(false);
    expect(result.errors[0]).toMatch(/can't be installed/);
  });

  it("does not embed anything for built-in sessions", async () => {
    const session = await createSession("lcsp", getSchema("lcsp")!.sections[0].id);
    const file = await exportSession(session.id);
    expect(file.customTemplates).toBeUndefined();
  });
});
