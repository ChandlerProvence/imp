import { db } from "./dexie";
import type { Conversation, ConversationConfig } from "./types";
import type { ToolCall, ResponseTimings } from "../ai/types";
import type { EndpointId } from "../ai/endpoints";
import { getActiveEndpointConfig } from "../ai/endpoints";
import { getModelResolution, type RoleResolution } from "../ai/models";
import { getSchema } from "../schemas/loader";
import { isCustomSchemaId } from "../schemas/customIds";
import type { DocumentSchema } from "../schemas/types";
import { filenameTimestamp } from "../utils/timestamp";
import { saveFile } from "../utils/fileSave";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/** Self-describing JSON envelope for a chat troubleshooting export. */
export interface ChatTroubleshootExportFile {
  /** Fixed magic identifier — distinct from session export. */
  _type: "doc-builder-chat-troubleshoot";
  /** Export format version for forward compatibility. */
  version: 1;
  /** ISO timestamp of when the export was created. */
  exportedAt: string;
  /** Human-readable one-liner for quick triage. */
  _humanSummary: string;

  endpoint: {
    id: EndpointId;
    label: string;
    baseUrl: string;
    models: RoleResolution[];
  };

  session: {
    id: string;
    documentTypeId: string;
    schemaTitle: string;
    /** Field keys that have non-empty values (presence only — no actual values). */
    answeredFieldKeys: string[];
    setId?: string;
    createdAt: string;
    updatedAt: string;
    /**
     * Custom templates only: the schema, since the developer won't have it.
     * The .docx is left out to keep the file small.
     */
    customSchema?: DocumentSchema;
  };

  /** Conversation metadata — null if no metadata row exists yet. */
  conversation: {
    fieldKey: string;
    label: string;
    conversationType: string;
    messageCount: number;
    config?: ConversationConfig;
    createdAt: string;
    updatedAt: string;
  } | null;

  /** All messages in the conversation (including tool messages hidden in the UI). */
  messages: Array<{
    role: "user" | "assistant" | "tool";
    content: string;
    displayLabel?: string;
    toolCalls?: ToolCall[];
    toolCallId?: string;
    timings?: ResponseTimings;
    createdAt: string;
  }>;

  environment: {
    userAgent: string;
    timestamp: string;
    url: string;
  };
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Sanitize a string for use as a filename (strip illegal chars). */
function sanitizeFilename(name: string): string {
  return name.replace(/[<>:"/\\|?*\x00-\x1f]/g, "").trim();
}

// ---------------------------------------------------------------------------
// Export
// ---------------------------------------------------------------------------

/**
 * Build the troubleshooting export envelope for a single conversation.
 * Includes all messages (even tool-role), tool calls, timings, and session
 * context — but redacts actual answer values (only presence keys).
 */
export async function exportChatForTroubleshooting(
  sessionId: string,
  fieldKey: string,
): Promise<ChatTroubleshootExportFile> {
  const session = await db.sessions.get(sessionId);
  if (!session) {
    throw new Error(`Session not found: ${sessionId}`);
  }

  // Schema title
  const schema = getSchema(session.documentTypeId);
  const schemaTitle = schema?.title ?? session.documentTypeId;

  // Endpoint snapshot (current at export time)
  const ep = getActiveEndpointConfig();

  // Conversation metadata (may not exist for brand-new chats)
  const convRows = await db.conversations
    .where("[sessionId+fieldKey]")
    .equals([sessionId, fieldKey])
    .toArray();
  const conv: Conversation | undefined = convRows[0];

  // All messages for this conversation, ordered chronologically
  const messages = await db.chatMessages
    .where("[sessionId+fieldKey]")
    .equals([sessionId, fieldKey])
    .sortBy("createdAt");

  // Redacted answer presence
  const answeredFieldKeys = Object.entries(session.answers)
    .filter(([, v]) => v !== "" && v !== undefined && v !== null)
    .map(([k]) => k);

  // Human summary
  const label = conv?.label ?? fieldKey;
  const _humanSummary = `${messages.length} message${messages.length !== 1 ? "s" : ""} in "${label}" for "${schemaTitle}" on ${ep.label} endpoint`;

  return {
    _type: "doc-builder-chat-troubleshoot",
    version: 1,
    exportedAt: new Date().toISOString(),
    _humanSummary,

    endpoint: {
      id: ep.id,
      label: ep.label,
      baseUrl: ep.baseUrl,
      models: getModelResolution(ep.id),
    },

    session: {
      id: sessionId,
      documentTypeId: session.documentTypeId,
      schemaTitle,
      answeredFieldKeys,
      setId: session.setId,
      ...(schema && isCustomSchemaId(schema.id) ? { customSchema: schema } : {}),
      createdAt: session.createdAt instanceof Date ? session.createdAt.toISOString() : String(session.createdAt),
      updatedAt: session.updatedAt instanceof Date ? session.updatedAt.toISOString() : String(session.updatedAt),
    },

    conversation: conv
      ? {
          fieldKey: conv.fieldKey,
          label: conv.label,
          conversationType: conv.conversationType,
          messageCount: conv.messageCount,
          config: conv.config,
          createdAt: conv.createdAt instanceof Date ? conv.createdAt.toISOString() : String(conv.createdAt),
          updatedAt: conv.updatedAt instanceof Date ? conv.updatedAt.toISOString() : String(conv.updatedAt),
        }
      : null,

    messages: messages.map(({ id: _id, sessionId: _sid, fieldKey: _fk, ...rest }) => ({
      ...rest,
      createdAt: rest.createdAt instanceof Date ? rest.createdAt.toISOString() : String(rest.createdAt),
    })),

    environment: {
      userAgent: navigator.userAgent,
      timestamp: new Date().toISOString(),
      url: window.location.href,
    },
  };
}

/**
 * Export the active conversation for troubleshooting and trigger a file download.
 *
 * Returns `true` if saved, `false` if the user cancelled the file picker.
 */
export async function downloadChatTroubleshoot(
  sessionId: string,
  fieldKey: string,
  schemaTitle: string,
): Promise<boolean> {
  const data = await exportChatForTroubleshooting(sessionId, fieldKey);

  const slug = sanitizeFilename(schemaTitle).replace(/\s+/g, "-").toLowerCase();
  const filename = `${slug}-chat-troubleshoot-${filenameTimestamp()}.json`;

  const blob = new Blob([JSON.stringify(data, null, 2)], {
    type: "application/json;charset=utf-8",
  });
  return saveFile({
    blob,
    filename,
    types: [{ description: "JSON files", accept: { "application/json": [".json"] } }],
  });
}
