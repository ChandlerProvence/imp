import { describe, it, expect, beforeEach } from "vitest";
import { db } from "./dexie";
import { createSession, updateSession } from "./session";
import { exportSession, importSession } from "./sessionExport";
import { getSchema } from "../schemas/loader";

const source = { docIds: ["doc-1"], fileNames: ["prior-lcsp.docx"], derivedAt: "2026-10-20T12:00:00.000Z" };

async function exportStyledSession() {
  const session = await createSession("lcsp", getSchema("lcsp")!.sections[0].id);
  await updateSession(session.id, { draftingStyle: "- Bullets for requirements.", draftingStyleSource: source });
  return JSON.parse(JSON.stringify(await exportSession(session.id)));
}

beforeEach(async () => {
  await db.sessions.clear();
});

describe("session export — drafting style", () => {
  it("round-trips the note and its source", async () => {
    const file = await exportStyledSession();
    expect(file.version).toBe(1);
    expect(file.session.draftingStyle).toBe("- Bullets for requirements.");

    const { sessionId } = await importSession(file);
    const imported = await db.sessions.get(sessionId);
    expect(imported?.draftingStyle).toBe("- Bullets for requirements.");
    expect(imported?.draftingStyleSource).toEqual(source);
  });

  it("round-trips the edited flag and drops a non-boolean one", async () => {
    const session = await createSession("lcsp", getSchema("lcsp")!.sections[0].id);
    await updateSession(session.id, { draftingStyle: "Mine.", draftingStyleSource: source, draftingStyleEdited: true });
    const file = JSON.parse(JSON.stringify(await exportSession(session.id)));
    expect(file.session.draftingStyleEdited).toBe(true);
    let imported = await db.sessions.get((await importSession(file)).sessionId);
    expect(imported?.draftingStyleEdited).toBe(true);

    file.session.draftingStyleEdited = "yes";
    imported = await db.sessions.get((await importSession(file)).sessionId);
    expect(imported?.draftingStyle).toBe("Mine.");
    expect(imported?.draftingStyleEdited).toBeUndefined();
  });

  it("drops malformed drafting style fields on import", async () => {
    const file = await exportStyledSession();
    file.session.draftingStyle = 123;
    file.session.draftingStyleSource = {};
    let imported = await db.sessions.get((await importSession(file)).sessionId);
    expect(imported?.draftingStyle).toBeUndefined();
    expect(imported?.draftingStyleSource).toBeUndefined();

    file.session.draftingStyle = "Kept.";
    file.session.draftingStyleSource = { docIds: "x" };
    imported = await db.sessions.get((await importSession(file)).sessionId);
    expect(imported?.draftingStyle).toBe("Kept.");
    expect(imported?.draftingStyleSource).toBeUndefined();
  });

  it("imports an older file without the fields", async () => {
    const file = await exportStyledSession();
    delete file.session.draftingStyle;
    delete file.session.draftingStyleSource;

    const { sessionId } = await importSession(file);
    const imported = await db.sessions.get(sessionId);
    expect(imported?.draftingStyle).toBeUndefined();
    expect(imported?.draftingStyleSource).toBeUndefined();
  });
});
