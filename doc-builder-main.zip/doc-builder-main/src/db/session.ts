import { db } from "./dexie";
import type { Session } from "./types";

/**
 * Create a new session for the given document type.
 * Returns the created session.
 */
export async function createSession(
  documentTypeId: string,
  firstSectionId: string,
): Promise<Session> {
  const session: Session = {
    id: crypto.randomUUID(),
    documentTypeId,
    answers: {},
    currentSection: firstSectionId,
    sectionConfirmed: {},
    createdAt: new Date(),
    updatedAt: new Date(),
  };
  await db.sessions.add(session);
  return session;
}

/**
 * Create a session for a document set (multi-document generation).
 * The first schema in the set serves as the anchor `documentTypeId` for
 * backwards-compatible lookups.
 */
export async function createSetSession(
  setId: string,
  schemaIds: string[],
  firstSectionId: string,
): Promise<Session> {
  const session: Session = {
    id: crypto.randomUUID(),
    documentTypeId: schemaIds[0],
    setId,
    schemaIds,
    answers: {},
    currentSection: firstSectionId,
    sectionConfirmed: {},
    createdAt: new Date(),
    updatedAt: new Date(),
  };
  await db.sessions.add(session);
  return session;
}

/** Get the most recent session (by updatedAt). */
export async function getLatestSession(): Promise<Session | undefined> {
  return db.sessions.orderBy("updatedAt").last();
}

/** Get a session by id. */
export async function getSession(id: string): Promise<Session | undefined> {
  return db.sessions.get(id);
}

/** Patch session fields and bump updatedAt. */
export async function updateSession(
  id: string,
  patch: Partial<Pick<Session, "answers" | "fieldMeta" | "draftingStyle" | "draftingStyleSource" | "draftingStyleEdited" | "currentSection" | "sectionConfirmed" | "reviewApproved" | "generated">>,
): Promise<void> {
  await db.sessions.update(id, { ...patch, updatedAt: new Date() });
}

/** Delete a session by id, including all associated images. */
export async function deleteSession(id: string): Promise<void> {
  await db.sessionImages.where("sessionId").equals(id).delete();
  await db.sessions.delete(id);
}
