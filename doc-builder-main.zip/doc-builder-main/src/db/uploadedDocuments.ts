import { db } from "./dexie";
import type { UploadedDocument } from "./types";
import { deleteChunksForDoc } from "./embeddings";

/**
 * Save a newly uploaded document. Deduplicates within a category:
 * - by contentHash, so a re-upload of the same bytes (even under a new name)
 *   replaces the existing record — unless that record is a bundled reference
 *   doc, which only has its lastUsedAt bumped so it keeps its reference identity;
 * - failing that, against legacy records saved before contentHash existed, by
 *   identical fileName + textContent (newest lastUsedAt wins). The match gains
 *   the new contentHash.
 * Without a contentHash nothing matches and a new record is created.
 * Returns the matched record, or the newly created one.
 */
export async function saveUploadedDocument(
  doc: Omit<UploadedDocument, "id">,
): Promise<UploadedDocument> {
  const { contentHash } = doc;
  if (!contentHash) return addUploadedDocument(doc);

  const hashMatch = await db.uploadedDocuments
    .where("contentHash")
    .equals(contentHash)
    .filter((d) => d.category === doc.category)
    .first();

  if (hashMatch?.source === "reference") {
    const touched: UploadedDocument = { ...hashMatch, lastUsedAt: new Date().toISOString() };
    await db.uploadedDocuments.update(hashMatch.id, { lastUsedAt: touched.lastUsedAt });
    return touched;
  }

  const existing = hashMatch ?? (await findLegacyMatch(doc));

  if (existing) {
    // Re-upload: replace content and reset CUI state. Keep id and createdAt
    // so the library doesn't fill with duplicates. Use `put()` to fully
    // replace the record — Dexie's `update()` ignores undefined values, so
    // stale optional fields (cuiDetection, quarantinedImages, etc.) wouldn't
    // be cleared otherwise.
    const replacement: UploadedDocument = {
      id: existing.id,
      createdAt: existing.createdAt,
      fileName: doc.fileName,
      mimeType: doc.mimeType,
      fileSize: doc.fileSize,
      contentHash,
      textContent: doc.textContent,
      charCount: doc.charCount,
      category: doc.category,
      uploadEndpoint: doc.uploadEndpoint,
      lastUsedAt: new Date().toISOString(),
      // Only carry over optional fields that are explicitly set on the new save
      ...(doc.isImage !== undefined ? { isImage: doc.isImage } : {}),
      ...(doc.source !== undefined ? { source: doc.source } : {}),
      ...(doc.refId !== undefined ? { refId: doc.refId } : {}),
      ...(doc.cuiStatus !== undefined ? { cuiStatus: doc.cuiStatus } : {}),
      ...(doc.cuiDetection !== undefined ? { cuiDetection: doc.cuiDetection } : {}),
      ...(doc.cuiScanError !== undefined ? { cuiScanError: doc.cuiScanError } : {}),
      ...(doc.cuiScannedWithAi !== undefined ? { cuiScannedWithAi: doc.cuiScannedWithAi } : {}),
      ...(doc.quarantinedImages !== undefined ? { quarantinedImages: doc.quarantinedImages } : {}),
      ...(doc.headerFooterText !== undefined ? { headerFooterText: doc.headerFooterText } : {}),
      // The role label describes the document, not its content version — keep it.
      ...(existing.slotRole !== undefined ? { slotRole: existing.slotRole } : {}),
    };
    await db.uploadedDocuments.put(replacement);
    return replacement;
  }

  return addUploadedDocument(doc);
}

async function addUploadedDocument(doc: Omit<UploadedDocument, "id">): Promise<UploadedDocument> {
  const id = crypto.randomUUID();
  const record: UploadedDocument = { id, ...doc };
  await db.uploadedDocuments.add(record);
  return record;
}

/** A pre-contentHash record of the same file: same name and identical extracted text. */
async function findLegacyMatch(
  doc: Omit<UploadedDocument, "id">,
): Promise<UploadedDocument | undefined> {
  const candidates = await db.uploadedDocuments
    .where("category")
    .equals(doc.category)
    .filter(
      (d) => !d.contentHash && d.fileName === doc.fileName && d.textContent === doc.textContent,
    )
    .toArray();
  return candidates.sort(
    (a, b) => new Date(b.lastUsedAt).getTime() - new Date(a.lastUsedAt).getTime(),
  )[0];
}

/**
 * Get all uploaded documents for a category, sorted by lastUsedAt descending.
 */
export async function getUploadedDocumentsByCategory(
  category: string,
): Promise<UploadedDocument[]> {
  const docs = await Promise.all(
    (await db.uploadedDocuments.where("category").equals(category).toArray())
      .map(lockReferenceDocStatus),
  );
  return docs.sort(
    (a, b) => new Date(b.lastUsedAt).getTime() - new Date(a.lastUsedAt).getTime(),
  );
}

/**
 * Update the lastUsedAt timestamp for a document.
 */
export async function updateLastUsed(id: string): Promise<void> {
  await db.uploadedDocuments.update(id, {
    lastUsedAt: new Date().toISOString(),
  });
}

/**
 * Find a previously saved reference doc by its manifest ID.
 * Returns the saved record if it exists (already fetched/parsed in a prior session).
 */
export async function getUploadedDocumentByRefId(
  refId: string,
  category: string,
): Promise<UploadedDocument | undefined> {
  const doc = await db.uploadedDocuments
    .where("category")
    .equals(category)
    .filter((d) => d.refId === refId)
    .first();
  return doc && lockReferenceDocStatus(doc);
}

/**
 * Bundled reference docs are public (served from GitLab Pages), so they are
 * always "not-cui". Repairs cached copies stamped otherwise — e.g. first
 * fetched in CUI mode — which would be hidden in Proprietary mode.
 */
async function lockReferenceDocStatus(doc: UploadedDocument): Promise<UploadedDocument> {
  if (doc.source !== "reference" || doc.cuiStatus === "not-cui") return doc;
  const fixed: UploadedDocument = { ...doc, cuiStatus: "not-cui" };
  delete fixed.cuiDetection;
  delete fixed.cuiScanError;
  await db.uploadedDocuments.put(fixed);
  return fixed;
}

/**
 * Set the CUI scan/classification status on a document, optionally along with
 * detection detail or scan-error text.
 */
export async function updateCuiStatus(
  id: string,
  status: UploadedDocument["cuiStatus"],
  extras?: Pick<UploadedDocument, "cuiDetection" | "cuiScanError" | "cuiScannedWithAi">,
): Promise<void> {
  await db.uploadedDocuments.update(id, { cuiStatus: status, ...extras });
}

/**
 * Set (or clear, with `null`) the slot role label on a document. The label is
 * display-only metadata; it never causes the document to be attached.
 */
export async function updateDocumentRole(
  id: string,
  role: UploadedDocument["slotRole"] | null,
): Promise<void> {
  await db.uploadedDocuments.update(id, { slotRole: role ?? undefined });
}

/** True when a document's CUI status requires user resolution before attach. */
export function isCuiFlagged(doc: Pick<UploadedDocument, "cuiStatus">): boolean {
  return doc.cuiStatus === "flagged" || doc.cuiStatus === "scan-error";
}

/** True when a document has no settled non-CUI classification, so attaching it in CUI mode makes it CUI. */
export function isCuiUnresolved(doc: Pick<UploadedDocument, "cuiStatus">): boolean {
  return doc.cuiStatus === undefined || doc.cuiStatus === "pending" || isCuiFlagged(doc);
}

/**
 * Update content-related fields on an existing document. Setting a field to
 * `undefined` clears it (Dexie replaces with undefined → deletes the key).
 */
export async function updateDocumentContent(
  id: string,
  fields: Pick<Partial<UploadedDocument>, "textContent" | "charCount" | "quarantinedImages" | "headerFooterText">,
): Promise<void> {
  await db.uploadedDocuments.update(id, fields);
}

/**
 * Delete an uploaded document and its cached embedding chunks.
 */
export async function deleteUploadedDocument(id: string): Promise<void> {
  await deleteChunksForDoc(`upload:${id}`);
  await db.uploadedDocuments.delete(id);
}
