import { useSyncExternalStore } from "react";
import { toAppError, type AppError } from "../errors";

/**
 * Tracks whether background IndexedDB writes (autosave, chat history, …) are
 * succeeding. A failed write sets `writeError`; the next successful tracked
 * write clears it. Module-level (not a React context) so non-React code such
 * as the global `unhandledrejection` handler can report into it.
 */

let writeError: AppError | null = null;
const listeners = new Set<() => void>();

function emit() {
  for (const l of listeners) l();
}

export function reportWriteError(err: unknown): void {
  writeError = toAppError(err, { domain: "db" });
  emit();
}

function reportWriteSuccess(): void {
  if (writeError === null) return;
  writeError = null;
  emit();
}

/**
 * Wrap a fire-and-forget write. The returned promise never rejects, so call
 * sites can drop it without creating an unhandled rejection.
 */
export function trackWrite(promise: Promise<unknown>): Promise<void> {
  return promise.then(reportWriteSuccess, (err) => {
    console.error("[storage] Background write failed:", err);
    reportWriteError(err);
  });
}

export function getWriteError(): AppError | null {
  return writeError;
}

function subscribe(listener: () => void): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function useWriteError(): AppError | null {
  return useSyncExternalStore(subscribe, getWriteError, getWriteError);
}

/** Test helper. */
export function resetWriteStatus(): void {
  writeError = null;
  emit();
}
