import { describe, it, expect, afterEach } from "vitest";
import Dexie from "dexie";

const DB_NAME = "DocBuilderDB";

afterEach(async () => {
  await Dexie.delete(DB_NAME);
});

/** Open the database at the legacy v10 schema (cuiOverride, no cuiStatus) and seed a record. */
async function seedLegacyRecord(record: Record<string, unknown>) {
  const legacy = new Dexie(DB_NAME);
  legacy.version(10).stores({
    sessions: "id, documentTypeId, setId, updatedAt",
    chatMessages: "id, [sessionId+fieldKey], sessionId, createdAt",
    conversations: "id, [sessionId+fieldKey], sessionId, documentTypeId, updatedAt",
    embeddingChunks: "id, docId, [docId+index]",
    uploadedDocuments: "id, category, createdAt, lastUsedAt",
  });
  await legacy.open();
  await (legacy as any).uploadedDocuments.add(record);
  legacy.close();
}

describe("Dexie v10 -> v11 cuiStatus migration", () => {
  it("migrates a CUI-endpoint upload (not overridden) to cuiStatus 'cui'", async () => {
    await seedLegacyRecord({
      id: "doc-cui",
      fileName: "a.pdf",
      mimeType: "application/pdf",
      fileSize: 100,
      textContent: "x",
      charCount: 1,
      category: "fms",
      uploadEndpoint: "cui",
      createdAt: new Date().toISOString(),
      lastUsedAt: new Date().toISOString(),
    });

    const { db } = await import("./dexie");
    const doc = await db.uploadedDocuments.get("doc-cui");
    expect(doc?.cuiStatus).toBe("cui");
    expect((doc as any).cuiOverride).toBeUndefined();
  });

  it("migrates a cuiOverride=false record to cuiStatus 'not-cui'", async () => {
    await seedLegacyRecord({
      id: "doc-not-cui",
      fileName: "b.pdf",
      mimeType: "application/pdf",
      fileSize: 100,
      textContent: "x",
      charCount: 1,
      category: "fms",
      uploadEndpoint: "non-cui",
      cuiOverride: false,
      createdAt: new Date().toISOString(),
      lastUsedAt: new Date().toISOString(),
    });

    const { db } = await import("./dexie");
    const doc = await db.uploadedDocuments.get("doc-not-cui");
    expect(doc?.cuiStatus).toBe("not-cui");
    expect((doc as any).cuiOverride).toBeUndefined();
  });

  it("migrates a plain non-CUI record with no override to cuiStatus 'pending'", async () => {
    await seedLegacyRecord({
      id: "doc-plain",
      fileName: "c.pdf",
      mimeType: "application/pdf",
      fileSize: 100,
      textContent: "x",
      charCount: 1,
      category: "fms",
      uploadEndpoint: "non-cui",
      createdAt: new Date().toISOString(),
      lastUsedAt: new Date().toISOString(),
    });

    const { db } = await import("./dexie");
    const doc = await db.uploadedDocuments.get("doc-plain");
    expect(doc?.cuiStatus).toBe("pending");
  });

  it("migrates a CUI-endpoint upload that was overridden back to 'not-cui', not 'cui'", async () => {
    await seedLegacyRecord({
      id: "doc-cui-overridden",
      fileName: "d.pdf",
      mimeType: "application/pdf",
      fileSize: 100,
      textContent: "x",
      charCount: 1,
      category: "fms",
      uploadEndpoint: "cui",
      cuiOverride: false,
      createdAt: new Date().toISOString(),
      lastUsedAt: new Date().toISOString(),
    });

    const { db } = await import("./dexie");
    const doc = await db.uploadedDocuments.get("doc-cui-overridden");
    expect(doc?.cuiStatus).toBe("not-cui");
  });
});

describe("Dexie v11 -> v12 userTemplates", () => {
  it("keeps existing data and adds the userTemplates store", async () => {
    const legacy = new Dexie(DB_NAME);
    legacy.version(11).stores({
      sessions: "id, documentTypeId, setId, updatedAt",
      chatMessages: "id, [sessionId+fieldKey], sessionId, createdAt",
      conversations: "id, [sessionId+fieldKey], sessionId, documentTypeId, updatedAt",
      embeddingChunks: "id, docId, [docId+index]",
      uploadedDocuments: "id, category, createdAt, lastUsedAt",
      sessionImages: "[sessionId+fieldKey], sessionId",
    });
    await legacy.open();
    await (legacy as any).sessions.add({ id: "s1", documentTypeId: "lcsp", answers: { "a.b": "kept" } });
    legacy.close();

    const { db } = await import("./dexie");
    expect((await db.sessions.get("s1"))?.answers).toEqual({ "a.b": "kept" });
    await db.userTemplates.put({ id: "custom-x", originalId: "x" } as any);
    expect((await db.userTemplates.get("custom-x"))?.originalId).toBe("x");
  });
});

describe("Dexie v12 -> v13 templateDrafts", () => {
  it("keeps existing templates and adds the templateDrafts store", async () => {
    const legacy = new Dexie(DB_NAME);
    legacy.version(12).stores({
      sessions: "id, documentTypeId, setId, updatedAt",
      chatMessages: "id, [sessionId+fieldKey], sessionId, createdAt",
      conversations: "id, [sessionId+fieldKey], sessionId, documentTypeId, updatedAt",
      embeddingChunks: "id, docId, [docId+index]",
      uploadedDocuments: "id, category, createdAt, lastUsedAt",
      sessionImages: "[sessionId+fieldKey], sessionId",
      userTemplates: "id, originalId, updatedAt",
    });
    await legacy.open();
    await (legacy as any).userTemplates.add({ id: "custom-x", originalId: "x" });
    legacy.close();

    const { db } = await import("./dexie");
    expect((await db.userTemplates.get("custom-x"))?.originalId).toBe("x");
    await db.templateDrafts.put({ id: "draft-1", updatedAt: "2026-10-09T00:00:00Z" } as any);
    expect(await db.templateDrafts.count()).toBe(1);
  });
});
