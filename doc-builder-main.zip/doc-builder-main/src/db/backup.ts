/**
 * Whole-database backup and restore: every IndexedDB table except derived
 * embeddings, plus allow-listed localStorage settings, in one JSON file.
 * Restoring replaces everything (API keys excepted); the caller reloads the
 * page afterwards so the normal startup path picks up the restored data.
 */
import { db } from "./dexie";
import type { UserTemplate } from "./types";
import { appError, type AppError } from "../errors";
import { toEmbedded, validateEmbedded } from "../schemas/userTemplateBundle";
import { parseUntrustedJson } from "../schemas/userTemplateValidation";
import { base64ToBytes, bytesToBase64 } from "../utils/base64";
import { filenameTimestamp } from "../utils/timestamp";
import { saveFile } from "../utils/fileSave";

export const BACKUP_TYPE = "doc-builder-backup";
export const BACKUP_FORMAT_VERSION = 1;

/**
 * Dexie versions whose records restore as-is. Before bumping `db.verno`, add
 * the new version here — and if its `.upgrade()` reshapes records, convert
 * older backups in `validateBackup` the same way.
 */
export const BACKUP_DB_VERSIONS: readonly number[] = [12, 13, 14];

/** Tables left out of backups: derived data, rebuilt when documents are next attached. */
export const EXCLUDED_TABLES: ReadonlySet<string> = new Set(["embeddingChunks"]);

/**
 * localStorage keys carried in a backup. Everything else stays out: API keys
 * (credentials don't belong in a file), caches, and per-tab state.
 */
export const BACKED_UP_SETTINGS: readonly string[] = [
  "doc-builder:user-profile",
  "doc-builder:user-role",
  "doc-builder:active-endpoint",
  "doc-builder:model-overrides",
  "doc-builder:ai-feature-flags",
  "doc-builder:show-ai-hints",
  "doc-builder:show-field-destinations",
  "doc-builder:sidebar-open",
  "doc-builder:sidebar-width",
  "doc-builder:ai-panel-open",
  "doc-builder:ai-panel-width",
  "doc-builder:chat-panel-width",
  "doc-builder:asksage-email",
];

export const LAST_BACKUP_KEY = "doc-builder:last-backup-at";

/** CUI statuses that mean a document is, or may be, CUI. */
const CUI_STATUSES = new Set(["cui", "flagged", "scan-error"]);

export interface BackupSummary {
  sessions: number;
  /** Uploaded documents (bundled reference docs excluded). */
  documents: number;
  /** Documents marked or flagged as CUI. */
  cuiDocuments: number;
  templates: number;
}

export interface BackupFile {
  _type: typeof BACKUP_TYPE;
  version: typeof BACKUP_FORMAT_VERSION;
  exportedAt: string;
  dbVersion: number;
  /** Table name → records, with Dates and binary data tagged (see `encode`). */
  tables: Record<string, unknown[]>;
  settings: Record<string, string>;
  summary: BackupSummary;
}

/** A parsed backup ready to restore: records decoded back to Dates/Blobs/ArrayBuffers. */
export interface ParsedBackup {
  exportedAt: string;
  tables: Record<string, Record<string, unknown>[]>;
  settings: Record<string, string>;
  summary: BackupSummary;
  /** Problems that don't block the restore (e.g. a damaged template that will be skipped). */
  warnings: string[];
}

export type BackupValidation = { ok: true; backup: ParsedBackup } | { ok: false; error: AppError };

// ---------------------------------------------------------------------------
// Value encoding — Dates and binary data don't survive JSON on their own
// ---------------------------------------------------------------------------

type Tagged =
  | { __backup: "date"; value: string }
  | { __backup: "blob"; type: string; data: string }
  | { __backup: "bytes"; data: string };

// Tag checks instead of instanceof: records read through fake-indexeddb (tests)
// or another realm fail instanceof against this window's constructors.
const tagOf = (v: unknown) => Object.prototype.toString.call(v);

export async function encode(value: unknown): Promise<unknown> {
  const tag = tagOf(value);
  if (tag === "[object Date]") return { __backup: "date", value: (value as Date).toISOString() } satisfies Tagged;
  if (tag === "[object Blob]") {
    const blob = value as Blob;
    return { __backup: "blob", type: blob.type, data: bytesToBase64(new Uint8Array(await blob.arrayBuffer())) } satisfies Tagged;
  }
  if (tag === "[object ArrayBuffer]") {
    return { __backup: "bytes", data: bytesToBase64(new Uint8Array(value as ArrayBuffer)) } satisfies Tagged;
  }
  if (Array.isArray(value)) return Promise.all(value.map(encode));
  if (value && typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value)) out[k] = await encode(v);
    return out;
  }
  return value;
}

export function decode(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(decode);
  if (!value || typeof value !== "object") return value;
  const obj = value as Record<string, unknown>;
  switch (obj.__backup) {
    case "date": {
      const date = new Date(obj.value as string);
      if (Number.isNaN(date.getTime())) throw new Error(`Invalid date: ${String(obj.value)}`);
      return date;
    }
    case "blob":
      return new Blob([base64ToBytes(obj.data as string) as BlobPart], { type: String(obj.type ?? "") });
    case "bytes": {
      const bytes = base64ToBytes(obj.data as string);
      return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
    }
  }
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(obj)) out[k] = decode(v);
  return out;
}

// ---------------------------------------------------------------------------
// Backup
// ---------------------------------------------------------------------------

function backedUpTables() {
  return db.tables.filter((t) => !EXCLUDED_TABLES.has(t.name));
}

function summarize(tables: Record<string, unknown[]>): BackupSummary {
  const docs = (tables.uploadedDocuments ?? []) as { source?: string; cuiStatus?: string }[];
  const uploads = docs.filter((d) => d.source !== "reference");
  return {
    sessions: tables.sessions?.length ?? 0,
    documents: uploads.length,
    cuiDocuments: uploads.filter((d) => d.cuiStatus && CUI_STATUSES.has(d.cuiStatus)).length,
    templates: tables.userTemplates?.length ?? 0,
  };
}

/** Counts for the backup dialog, read straight from the database. */
export async function getCurrentSummary(): Promise<BackupSummary> {
  const [sessions, docs, templates] = await Promise.all([
    db.sessions.count(),
    db.uploadedDocuments.toArray(),
    db.userTemplates.count(),
  ]);
  const summary = summarize({ uploadedDocuments: docs });
  return { ...summary, sessions, templates };
}

/** Snapshot every backed-up table and setting. */
export async function buildBackup(): Promise<BackupFile> {
  // Read everything in one transaction for a consistent snapshot, then encode
  // outside it (awaiting Blob reads inside would commit the transaction early).
  const tables = backedUpTables();
  const raw: Record<string, unknown[]> = {};
  await db.transaction("r", tables, async () => {
    for (const table of tables) raw[table.name] = await table.toArray();
  });

  const encoded: Record<string, unknown[]> = {};
  for (const [name, rows] of Object.entries(raw)) encoded[name] = (await encode(rows)) as unknown[];

  const settings: Record<string, string> = {};
  for (const key of BACKED_UP_SETTINGS) {
    const value = localStorage.getItem(key);
    if (value !== null) settings[key] = value;
  }

  return {
    _type: BACKUP_TYPE,
    version: BACKUP_FORMAT_VERSION,
    exportedAt: new Date().toISOString(),
    dbVersion: db.verno,
    tables: encoded,
    settings,
    summary: summarize(raw),
  };
}

/**
 * Build a backup and save it via the native file picker (or browser download).
 * Returns `false` if the user cancelled the picker.
 */
export async function downloadBackup(): Promise<boolean> {
  const backup = await buildBackup();
  const blob = new Blob([JSON.stringify(backup)], { type: "application/json;charset=utf-8" });
  const saved = await saveFile({
    blob,
    filename: `doc-builder-backup-${filenameTimestamp()}.json`,
    types: [{ description: "Doc Builder backup", accept: { "application/json": [".json"] } }],
  });
  if (saved) localStorage.setItem(LAST_BACKUP_KEY, new Date().toISOString());
  return saved;
}

// ---------------------------------------------------------------------------
// Restore
// ---------------------------------------------------------------------------

const isPlainObject = (v: unknown): v is Record<string, unknown> =>
  typeof v === "object" && v !== null && !Array.isArray(v);

/** Parse and check a backup file's text. Never touches the database. */
export async function validateBackup(text: string): Promise<BackupValidation> {
  const invalid = (detail: string): BackupValidation => ({
    ok: false,
    error: appError("db.backup-invalid", { detail }),
  });

  let raw: unknown;
  try {
    raw = parseUntrustedJson(text);
  } catch (err) {
    return invalid(`Not valid JSON: ${err instanceof Error ? err.message : String(err)}`);
  }
  if (!isPlainObject(raw) || raw._type !== BACKUP_TYPE) return invalid("Missing doc-builder-backup marker.");
  if (raw.version !== BACKUP_FORMAT_VERSION || typeof raw.dbVersion !== "number") {
    return invalid(`Unsupported backup format version ${String(raw.version)}.`);
  }
  if (raw.dbVersion > db.verno) {
    return {
      ok: false,
      error: appError("db.backup-newer-version", { detail: `Backup database v${raw.dbVersion}, this app v${db.verno}.` }),
    };
  }
  if (!BACKUP_DB_VERSIONS.includes(raw.dbVersion)) return invalid(`Unsupported database version ${raw.dbVersion}.`);
  if (!isPlainObject(raw.tables) || !isPlainObject(raw.settings)) return invalid("Missing tables or settings.");

  const known = new Set(backedUpTables().map((t) => t.name));
  const tables: ParsedBackup["tables"] = {};
  for (const [name, rows] of Object.entries(raw.tables)) {
    if (!known.has(name)) return invalid(`Unknown table "${name}".`);
    if (!Array.isArray(rows) || !rows.every(isPlainObject)) return invalid(`Table "${name}" is not a list of records.`);
    try {
      tables[name] = decode(rows) as Record<string, unknown>[];
    } catch (err) {
      return invalid(`Table "${name}" is damaged: ${err instanceof Error ? err.message : String(err)}`);
    }
  }

  // Re-check custom templates as on upload; skip (don't install) damaged ones.
  const warnings: string[] = [];
  if (tables.userTemplates) {
    const kept: Record<string, unknown>[] = [];
    for (const row of tables.userTemplates) {
      const record = row as unknown as UserTemplate;
      if (record.archivedAt) {
        kept.push(row);
        continue;
      }
      let ok = false;
      try {
        ok = (await validateEmbedded(toEmbedded(record), { allowBuiltInId: true })).ok;
      } catch {
        ok = false;
      }
      if (ok) kept.push(row);
      else warnings.push(`The custom template "${record.schema?.title ?? record.id}" is damaged and won't be restored.`);
    }
    tables.userTemplates = kept;
  }

  const settings: Record<string, string> = {};
  for (const key of BACKED_UP_SETTINGS) {
    const value = raw.settings[key];
    if (typeof value === "string") settings[key] = value;
  }

  return {
    ok: true,
    backup: {
      exportedAt: typeof raw.exportedAt === "string" ? raw.exportedAt : "",
      tables,
      settings,
      summary: summarize(tables),
      warnings,
    },
  };
}

/**
 * Replace all data with the backup: clear every table (embeddings too, so
 * none are left stale) and the backed-up settings, then write the backup's
 * records and settings. API keys are untouched. Reload the page afterwards.
 */
export async function restoreBackup(backup: ParsedBackup): Promise<void> {
  await db.transaction("rw", db.tables, async () => {
    for (const table of db.tables) await table.clear();
    for (const [name, rows] of Object.entries(backup.tables)) {
      if (rows.length > 0) await db.table(name).bulkAdd(rows);
    }
  });
  for (const key of BACKED_UP_SETTINGS) localStorage.removeItem(key);
  for (const [key, value] of Object.entries(backup.settings)) localStorage.setItem(key, value);
  // The restored data is covered by the file it came from
  const exported = new Date(backup.exportedAt);
  const last = getLastBackupAt();
  if (!Number.isNaN(exported.getTime()) && (!last || last < exported)) {
    localStorage.setItem(LAST_BACKUP_KEY, exported.toISOString());
  }
}

// ---------------------------------------------------------------------------
// Last backup
// ---------------------------------------------------------------------------

const DAY_MS = 24 * 60 * 60 * 1000;
/** Settings shows the last-backup date in red once a backup is older than this. */
export const BACKUP_STALE_DAYS = 14;

export function getLastBackupAt(): Date | null {
  const raw = localStorage.getItem(LAST_BACKUP_KEY);
  if (!raw) return null;
  const date = new Date(raw);
  return Number.isNaN(date.getTime()) ? null : date;
}

/** Whole days since the last backup, or null if there has never been one. */
export function daysSinceBackup(now: Date = new Date()): number | null {
  const last = getLastBackupAt();
  return last ? Math.floor((now.getTime() - last.getTime()) / DAY_MS) : null;
}
