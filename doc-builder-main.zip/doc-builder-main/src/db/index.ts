export { db } from "./dexie";
export {
  createSession,
  createSetSession,
  getLatestSession,
  getSession,
  updateSession,
  deleteSession,
} from "./session";
export {
  getConversation,
  addMessage,
  clearConversation,
  upsertConversation,
  getAllConversations,
  getConversationsForSession,
  deleteConversation,
  deleteAllConversationsForSession,
} from "./chatHistory";
export {
  saveUploadedDocument,
  getUploadedDocumentsByCategory,
  updateLastUsed,
  updateCuiStatus,
  isCuiFlagged,
  updateDocumentContent,
  updateDocumentRole,
  deleteUploadedDocument,
} from "./uploadedDocuments";
export {
  exportSession,
  downloadSessionExport,
  validateImportFile,
  importSession,
} from "./sessionExport";
export {
  buildBackup,
  downloadBackup,
  validateBackup,
  restoreBackup,
  getCurrentSummary,
  getLastBackupAt,
  daysSinceBackup,
} from "./backup";
export type { BackupSummary, ParsedBackup } from "./backup";
export {
  saveSessionImage,
  getSessionImage,
  getSessionImages,
  deleteSessionImage,
  deleteAllSessionImages,
} from "./sessionImages";
export type { Session, ChatMessage, Conversation, ConversationConfig, UploadedDocument, SessionExportFile, SessionImage } from "./types";
