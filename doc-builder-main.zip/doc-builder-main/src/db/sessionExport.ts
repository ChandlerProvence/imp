import { db } from "./dexie";
import type { DraftingStyleSource, EmbeddedTemplate, Session, SessionExportFile, SessionExportSchemaRef } from "./types";
import { getUserTemplate } from "./userTemplates";
import { isCustomSchemaId } from "../schemas/customIds";
import { hydrateUserSchemas, installTemplate } from "../schemas/userSchemas";
import { installedIdFor, toEmbedded, validateEmbedded } from "../schemas/userTemplateBundle";
import type { PreparedTemplate } from "../schemas/userTemplateValidation";
import { getSchema } from "../schemas/loader";
import type { DocumentSchema } from "../schemas/types";
import { filenameTimestamp } from "../utils/timestamp";
import { saveFile } from "../utils/fileSave";
import { base64ToBytes, bytesToBase64 } from "../utils/base64";
import { buildFieldManifest } from "../schemas/fieldManifest";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Sanitize a string for use as a filename (strip illegal chars). */
function sanitizeFilename(name: string): string {
  return name.replace(/[<>:"/\\|?*\x00-\x1f]/g, "").trim();
}

/** Build a schema fingerprint for the export envelope. */
/** The imported drafting style, or nothing if the file's fields aren't well-formed. */
function importedDraftingStyle(
  s: SessionExportFile["session"],
): Pick<Session, "draftingStyle" | "draftingStyleSource" | "draftingStyleEdited"> {
  if (typeof s.draftingStyle !== "string") return {};
  const src = s.draftingStyleSource as Partial<DraftingStyleSource> | undefined;
  const sourceOk =
    !!src &&
    Array.isArray(src.docIds) && src.docIds.every((x) => typeof x === "string") &&
    Array.isArray(src.fileNames) && src.fileNames.every((x) => typeof x === "string") &&
    typeof src.derivedAt === "string";
  return {
    draftingStyle: s.draftingStyle,
    ...(sourceOk ? { draftingStyleSource: src as DraftingStyleSource } : {}),
    ...(typeof s.draftingStyleEdited === "boolean" ? { draftingStyleEdited: s.draftingStyleEdited } : {}),
  };
}

function buildSchemaRef(schema: DocumentSchema): SessionExportSchemaRef {
  const fields = buildFieldManifest(schema);
  return {
    id: schema.id,
    title: schema.title,
    version: schema.version,
    sectionCount: schema.sections.length,
    fieldCount: fields.length,
    fields,
  };
}

// ---------------------------------------------------------------------------
// Export
// ---------------------------------------------------------------------------

/**
 * In-memory values that take precedence over the stored session — used when
 * background saves are failing, so the export includes unsaved edits.
 */
export type SessionExportOverrides = Partial<Pick<Session, "answers" | "fieldMeta">>;

/**
 * Build the export envelope for a session, including conversations and chat
 * messages. Strips internal IDs (regenerated on import).
 */
export async function exportSession(
  sessionId: string,
  overrides?: SessionExportOverrides,
): Promise<SessionExportFile> {
  const stored = await db.sessions.get(sessionId);
  if (!stored) {
    throw new Error(`Session not found: ${sessionId}`);
  }
  const session = { ...stored, ...overrides };

  // Resolve schema for the schemaRef fingerprint
  await hydrateUserSchemas();
  const schema = getSchema(session.documentTypeId);
  if (!schema) {
    throw new Error(
      `Schema not found for document type: ${session.documentTypeId}`,
    );
  }

  // Fetch conversations and messages
  const conversations = await db.conversations
    .where("sessionId")
    .equals(sessionId)
    .toArray();

  const chatMessages = await db.chatMessages
    .where("sessionId")
    .equals(sessionId)
    .toArray();

  // Fetch session images for export
  const sessionImages = await db.sessionImages
    .where("sessionId")
    .equals(sessionId)
    .toArray();

  // Convert image blobs to base64 for JSON serialization
  const images: SessionExportFile["images"] = [];
  for (const img of sessionImages) {
    const bytes = new Uint8Array(await img.blob.arrayBuffer());
    images.push({
      fieldKey: img.fieldKey,
      fileName: img.fileName,
      mimeType: img.mimeType,
      dataBase64: bytesToBase64(bytes),
      naturalWidth: img.naturalWidth,
      naturalHeight: img.naturalHeight,
    });
  }

  // Carry the custom template so the file opens on machines without it
  const customTemplates: EmbeddedTemplate[] = [];
  if (isCustomSchemaId(session.documentTypeId)) {
    const record = await getUserTemplate(session.documentTypeId);
    if (record) customTemplates.push(toEmbedded(record));
  }

  // Build the export envelope
  const exportData: SessionExportFile = {
    _type: "doc-builder-session-export",
    version: 1,
    exportedAt: new Date().toISOString(),
    session: {
      documentTypeId: session.documentTypeId,
      answers: session.answers,
      fieldMeta: session.fieldMeta,
      draftingStyle: session.draftingStyle,
      draftingStyleSource: session.draftingStyleSource,
      draftingStyleEdited: session.draftingStyleEdited,
      currentSection: session.currentSection,
      sectionConfirmed: session.sectionConfirmed,
      reviewApproved: session.reviewApproved,
      generated: session.generated,
      setId: session.setId,
      schemaIds: session.schemaIds,
      createdAt: session.createdAt.toISOString(),
      updatedAt: session.updatedAt.toISOString(),
    },
    schemaRef: buildSchemaRef(schema),
    conversations: conversations.map(({ id: _id, ...rest }) => ({
      ...rest,
      createdAt: rest.createdAt instanceof Date ? rest.createdAt.toISOString() : String(rest.createdAt),
      updatedAt: rest.updatedAt instanceof Date ? rest.updatedAt.toISOString() : String(rest.updatedAt),
    })),
    chatMessages: chatMessages.map(({ id: _id, ...rest }) => ({
      ...rest,
      createdAt: rest.createdAt instanceof Date ? rest.createdAt.toISOString() : String(rest.createdAt),
    })),
    ...(images.length > 0 ? { images } : {}),
    ...(customTemplates.length > 0 ? { customTemplates } : {}),
  };

  return exportData;
}

/**
 * Export the session and trigger a file download via the native file picker
 * (or fallback browser download).
 *
 * Returns `true` if saved, `false` if the user cancelled the file picker.
 */
export async function downloadSessionExport(
  sessionId: string,
  overrides?: SessionExportOverrides,
): Promise<boolean> {
  const data = await exportSession(sessionId, overrides);

  // Build filename: "{name}-session-{datetime}.json"
  // For set sessions, use the set name; otherwise use the schema title.
  const displayName = data.session.setId ?? data.schemaRef.title;
  const slug = sanitizeFilename(displayName).replace(/\s+/g, "-").toLowerCase();
  const filename = `${slug}-progress-${filenameTimestamp()}.json`;

  const blob = new Blob([JSON.stringify(data, null, 2)], {
    type: "application/json;charset=utf-8",
  });
  return saveFile({
    blob,
    filename,
    types: [{ description: "JSON files", accept: { "application/json": [".json"] } }],
  });
}

// ---------------------------------------------------------------------------
// Validation
// ---------------------------------------------------------------------------

export interface ValidationResult {
  valid: boolean;
  data?: SessionExportFile;
  errors: string[];
  warnings: string[];
  /** Custom template from the file that importSession will install. */
  templateToInstall?: PreparedTemplate;
}

/** Templates validated by validateImportFile, reused by importSession. */
const pendingInstalls = new WeakMap<SessionExportFile, { prepared: PreparedTemplate; basedOn?: string }>();

/**
 * Validate a parsed JSON object as a session export file.
 * Returns errors (block import) and warnings (inform user but allow import).
 *
 * Sessions built on a custom template carry it in `customTemplates`; when it
 * isn't installed here it is validated like a fresh upload and installed by
 * importSession.
 */
export async function validateImportFile(raw: unknown): Promise<ValidationResult> {
  await hydrateUserSchemas();
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!raw || typeof raw !== "object") {
    return { valid: false, errors: ["File content is not a valid JSON object."], warnings };
  }

  const obj = raw as Record<string, unknown>;

  // Magic type check
  if (obj._type !== "doc-builder-session-export") {
    return {
      valid: false,
      errors: ["This does not appear to be a Doc Builder progress file."],
      warnings,
    };
  }

  // Version check
  if (obj.version !== 1) {
    return {
      valid: false,
      errors: [
        `This file uses format version ${obj.version}, but only version 1 is supported. ` +
        "Please update the app to a newer version.",
      ],
      warnings,
    };
  }

  // Session presence
  if (!obj.session || typeof obj.session !== "object") {
    return { valid: false, errors: ["The file is missing session data."], warnings };
  }

  const session = obj.session as Record<string, unknown>;
  if (!session.documentTypeId || typeof session.documentTypeId !== "string") {
    return { valid: false, errors: ["The file is missing a document type ID."], warnings };
  }

  if (!session.answers || typeof session.answers !== "object") {
    return { valid: false, errors: ["The file is missing answer data."], warnings };
  }

  // Schema reference
  if (!obj.schemaRef || typeof obj.schemaRef !== "object") {
    return { valid: false, errors: ["The file is missing schema reference information."], warnings };
  }

  const schemaRef = obj.schemaRef as Record<string, unknown>;

  // Custom template: install from the file if missing, warn if it differs
  const documentTypeId = session.documentTypeId as string;
  let pending: { prepared: PreparedTemplate; basedOn?: string } | undefined;
  if (isCustomSchemaId(documentTypeId)) {
    const embedded = Array.isArray(obj.customTemplates)
      ? (obj.customTemplates as EmbeddedTemplate[]).find((t) => t && installedIdFor(t) === documentTypeId)
      : undefined;
    const installed = await getUserTemplate(documentTypeId);
    if (!installed && embedded) {
      // The template may have been promoted to a built-in since it was saved
      const check = await validateEmbedded(embedded, { allowBuiltInId: true });
      if (!check.ok || !check.prepared) {
        const problems = check.issues.filter((i) => i.severity === "error").map((i) => i.message);
        return {
          valid: false,
          errors: [`The custom template in this file can't be installed: ${problems.slice(0, 3).join(" ")}`],
          warnings,
        };
      }
      pending = { prepared: check.prepared, basedOn: embedded.basedOn };
      warnings.push(
        `This file includes the custom template "${check.prepared.schema.title}", which will be added to this browser. ` +
          "It came from a file, not from Doc Builder, and its field hints are sent to the AI assistant — review it before relying on it.",
      );
    } else if (installed?.archivedAt) {
      warnings.push(
        `This file uses the custom template "${installed.schema.title}", which you archived. Restore it from Manage Custom Templates to open this file.`,
      );
    } else if (installed && embedded && embedded.docxSha256 && embedded.docxSha256 !== installed.docxSha256) {
      warnings.push(
        `This file was saved with a different version of the custom template "${installed.schema.title}" ` +
          `(revision ${embedded.revision}; you have revision ${installed.revision}). Your installed version will be used.`,
      );
    }
  }

  // Check schema exists locally
  const localSchema = getSchema(documentTypeId) ?? pending?.prepared.schema;
  if (!localSchema) {
    return {
      valid: false,
      errors: [
        `This file requires the schema "${schemaRef.title ?? session.documentTypeId}" ` +
        `which is not available in this installation.`,
      ],
      warnings,
    };
  }

  // Check schema compatibility via field manifest diff
  const exportedFields = Array.isArray(schemaRef.fields)
    ? (schemaRef.fields as Array<{ key: string; type: string }>)
    : null;

  if (exportedFields) {
    // Precise diff: compare exported manifest against local schema
    const localManifest = buildFieldManifest(localSchema);
    const localByKey = new Map(localManifest.map((f) => [f.key, f.type]));

    // Only report issues for fields the user actually has answers for
    const savedAnswers = (session.answers ?? {}) as Record<string, unknown>;

    const orphanedWithData: string[] = [];
    const typeMismatches: string[] = [];

    for (const { key, type: exportedType } of exportedFields) {
      const localType = localByKey.get(key);
      if (localType === undefined) {
        // Field no longer exists — only warn if user had an answer
        if (key in savedAnswers && savedAnswers[key] !== "" && savedAnswers[key] !== undefined) {
          orphanedWithData.push(key);
        }
      } else if (localType !== exportedType) {
        // Type changed — only warn if user had an answer
        if (key in savedAnswers && savedAnswers[key] !== "" && savedAnswers[key] !== undefined) {
          typeMismatches.push(`${key} (was ${exportedType}, now ${localType})`);
        }
      }
    }

    if (orphanedWithData.length > 0) {
      const listed = orphanedWithData.slice(0, 5).join(", ");
      const more = orphanedWithData.length > 5 ? ` and ${orphanedWithData.length - 5} more` : "";
      warnings.push(
        `${orphanedWithData.length} of your saved answers no longer have matching fields: ${listed}${more}. ` +
        "These values will be ignored on import. " +
        "Tip: you can attach the saved progress file in the AI chat and ask it to resolve the mapping issues.",
      );
    }

    if (typeMismatches.length > 0) {
      const listed = typeMismatches.slice(0, 5).join(", ");
      const more = typeMismatches.length > 5 ? ` and ${typeMismatches.length - 5} more` : "";
      warnings.push(
        `${typeMismatches.length} fields changed type: ${listed}${more}. Values may not display correctly.`,
      );
    }

    // Informational: note version bump even if no data issues
    if (
      typeof schemaRef.version === "number" &&
      schemaRef.version !== localSchema.version &&
      orphanedWithData.length === 0 &&
      typeMismatches.length === 0
    ) {
      // Version changed but no breaking data issues — no warning needed
    }
  } else {
    // Fallback for old export files without field manifest: use count-based heuristic
    const localFieldCount = localSchema.sections.reduce(
      (sum, s) => sum + s.fields.length,
      0,
    );
    const versionChanged =
      typeof schemaRef.version === "number" &&
      schemaRef.version !== localSchema.version;
    const structureChanged =
      typeof schemaRef.sectionCount === "number" &&
      typeof schemaRef.fieldCount === "number" &&
      (localSchema.sections.length !== schemaRef.sectionCount ||
        localFieldCount !== schemaRef.fieldCount);

    if (versionChanged || structureChanged) {
      const parts: string[] = [];

      if (versionChanged) {
        parts.push(
          `This file was saved with schema version ${schemaRef.version}, but you have version ${localSchema.version}.`,
        );
      }

      if (structureChanged) {
        parts.push(
          `The schema structure has changed (was ${schemaRef.sectionCount} sections / ${schemaRef.fieldCount} fields, now ${localSchema.sections.length} / ${localFieldCount}). Fields that no longer exist will be ignored; new fields will be empty.`,
        );
      }

      parts.push(
        "Tip: you can attach the saved progress file in the AI chat and ask it to resolve any mapping issues.",
      );

      warnings.push(parts.join(" "));
    }
  }

  // Set session: check all schemaIds exist
  if (session.setId && Array.isArray(session.schemaIds)) {
    const missing = (session.schemaIds as string[]).filter(
      (id) => !getSchema(id),
    );
    if (missing.length > 0) {
      warnings.push(
        `This is a multi-document session. ${missing.length} of ${(session.schemaIds as string[]).length} ` +
        "member schemas are missing. Some sections may not appear.",
      );
    }
  }

  const data = obj as unknown as SessionExportFile;
  if (pending) pendingInstalls.set(data, pending);
  return { valid: true, data, errors, warnings, ...(pending ? { templateToInstall: pending.prepared } : {}) };
}

// ---------------------------------------------------------------------------
// Import
// ---------------------------------------------------------------------------

export interface ImportResult {
  sessionId: string;
  warnings: string[];
}

/**
 * Import a validated session export file into IndexedDB.
 * Generates new IDs for session, conversations, and messages.
 * Returns the new session ID.
 */
export async function importSession(
  data: SessionExportFile,
): Promise<ImportResult> {
  const warnings: string[] = [];
  const newSessionId = crypto.randomUUID();

  // Install the custom template validated by validateImportFile
  const pending = pendingInstalls.get(data);
  if (pending && !(await getUserTemplate(pending.prepared.id))) {
    await installTemplate(pending.prepared, { basedOn: pending.basedOn });
  }

  // Reconstruct the Session object
  const session = {
    id: newSessionId,
    documentTypeId: data.session.documentTypeId,
    answers: data.session.answers,
    fieldMeta: data.session.fieldMeta,
    ...importedDraftingStyle(data.session),
    currentSection: data.session.currentSection,
    sectionConfirmed: data.session.sectionConfirmed ?? {},
    reviewApproved: data.session.reviewApproved,
    generated: data.session.generated,
    setId: data.session.setId,
    schemaIds: data.session.schemaIds,
    createdAt: new Date(data.session.createdAt),
    updatedAt: new Date(), // Mark as "just updated" so it becomes the latest
  };

  await db.sessions.add(session);

  // Import conversations
  for (const conv of data.conversations) {
    await db.conversations.add({
      ...conv,
      id: crypto.randomUUID(),
      sessionId: newSessionId,
      createdAt: new Date(conv.createdAt as unknown as string),
      updatedAt: new Date(conv.updatedAt as unknown as string),
    });
  }

  // Import chat messages
  for (const msg of data.chatMessages) {
    await db.chatMessages.add({
      ...msg,
      id: crypto.randomUUID(),
      sessionId: newSessionId,
      createdAt: new Date(msg.createdAt),
    });
  }

  // Import session images (base64 → Blob)
  if (data.images) {
    for (const img of data.images) {
      const blob = new Blob([base64ToBytes(img.dataBase64) as BlobPart], { type: img.mimeType });
      await db.sessionImages.add({
        sessionId: newSessionId,
        fieldKey: img.fieldKey,
        fileName: img.fileName,
        mimeType: img.mimeType,
        blob,
        naturalWidth: img.naturalWidth,
        naturalHeight: img.naturalHeight,
      });
    }
  }

  return { sessionId: newSessionId, warnings };
}
