import { db } from "./dexie";
import type { TemplateDraft } from "./types";
import { migrateStoredRecord } from "../schemas/migrateStored";

// Reads migrate old schema shapes (see userTemplates.ts); autosave writes
// the current shape back.

/** All template drafts, most recently edited first. */
export async function listTemplateDrafts(): Promise<TemplateDraft[]> {
  return (await db.templateDrafts.orderBy("updatedAt").reverse().toArray()).map(migrateStoredRecord);
}

export async function getTemplateDraft(id: string): Promise<TemplateDraft | undefined> {
  const draft = await db.templateDrafts.get(id);
  return draft && migrateStoredRecord(draft);
}

/** Insert or overwrite a draft. */
export async function putTemplateDraft(draft: TemplateDraft): Promise<void> {
  await db.templateDrafts.put(draft);
}

export async function deleteTemplateDraft(id: string): Promise<void> {
  await db.templateDrafts.delete(id);
}
