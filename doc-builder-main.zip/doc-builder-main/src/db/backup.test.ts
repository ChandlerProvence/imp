import { beforeEach, describe, expect, it } from "vitest";
import { db } from "./dexie";
import {
  BACKED_UP_SETTINGS,
  BACKUP_DB_VERSIONS,
  EXCLUDED_TABLES,
  LAST_BACKUP_KEY,
  buildBackup,
  daysSinceBackup,
  decode,
  encode,
  restoreBackup,
  validateBackup,
} from "./backup";
import { installTemplate } from "../schemas/userSchemas";
import { validateUserTemplatePair } from "../schemas/userTemplateValidation";
import { buildDocx, para } from "../test/docxFixtures";
import type { UploadedDocument } from "./types";

const schemaJson = JSON.stringify({
  id: "vendor-letter",
  title: "Vendor Letter",
  version: 1,
  docx_template: "x.docx",
  sections: [{ id: "main", title: "Main", fields: [{ id: "vendor", label: "Vendor", type: "string", required: true }] }],
  template_key_map: { VENDOR: "main.vendor" },
});

function doc(overrides: Partial<UploadedDocument> = {}): UploadedDocument {
  const now = new Date().toISOString();
  return {
    id: crypto.randomUUID(),
    fileName: "pws.pdf",
    mimeType: "application/pdf",
    fileSize: 100,
    textContent: "text",
    charCount: 4,
    category: "fms",
    createdAt: now,
    lastUsedAt: now,
    ...overrides,
  };
}

async function wipe() {
  await db.transaction("rw", db.tables, async () => {
    for (const table of db.tables) await table.clear();
  });
  localStorage.clear();
}

/** One record in every table, including a Blob, an ArrayBuffer, Dates, and a CUI document. */
async function seed() {
  const created = new Date("2026-09-01T12:00:00Z");
  await db.sessions.add({
    id: "s1",
    documentTypeId: "custom-vendor-letter",
    answers: { "main.vendor": "Acme" },
    currentSection: "main",
    sectionConfirmed: { main: true },
    createdAt: created,
    updatedAt: created,
  });
  await db.conversations.add({
    id: "c1",
    sessionId: "s1",
    fieldKey: "__bulk_edit",
    documentTypeId: "custom-vendor-letter",
    documentTypeTitle: "Vendor Letter",
    label: "Bulk Edit",
    conversationType: "bulk-edit",
    messageCount: 1,
    createdAt: created,
    updatedAt: created,
  });
  await db.chatMessages.add({ id: "m1", sessionId: "s1", fieldKey: "__bulk_edit", role: "user", content: "hi", createdAt: created });
  await db.sessionImages.add({
    sessionId: "s1",
    fieldKey: "main.figure",
    fileName: "fig.png",
    mimeType: "image/png",
    blob: new Blob([new Uint8Array([137, 80, 78, 71, 0, 255])], { type: "image/png" }),
    naturalWidth: 10,
    naturalHeight: 20,
  });
  await db.uploadedDocuments.bulkAdd([doc({ id: "d1" }), doc({ id: "d2", cuiStatus: "cui" }), doc({ id: "ref", source: "reference" })]);
  await db.embeddingChunks.add({ id: "e1", docId: "d1", index: 0, text: "t", embedding: [0.1], sourceHash: "h", model: "m" } as never);
  const { prepared } = await validateUserTemplatePair({ schemaText: schemaJson, docx: buildDocx(para("Dear {{VENDOR}}")) });
  await installTemplate(prepared!);
}

async function snapshot() {
  const out: Record<string, unknown[]> = {};
  for (const table of db.tables) {
    if (EXCLUDED_TABLES.has(table.name)) continue;
    const rows = await table.toArray();
    // Compare template bytes directly. (fake-indexeddb can't store Blobs, so
    // image bytes are covered by the encode/decode test instead.)
    out[table.name] = rows.map((row: Record<string, unknown>) =>
      row.docx ? { ...row, docx: Array.from(new Uint8Array(row.docx as ArrayBuffer)) } : row,
    );
  }
  return out;
}

/** Build a backup and round-trip it through JSON, as it would be written to disk. */
async function backupText() {
  return JSON.stringify(await buildBackup());
}

beforeEach(wipe);

describe("whole-database backup", () => {
  it("restores every table exactly, including Dates and binary data", async () => {
    await seed();
    const before = await snapshot();
    const text = await backupText();

    await wipe();
    const result = await validateBackup(text);
    if (!result.ok) throw new Error(result.error.detail);
    expect(result.backup.warnings).toEqual([]);
    await restoreBackup(result.backup);

    const after = await snapshot();
    expect(after).toEqual(before);
    const session = await db.sessions.get("s1");
    expect(session?.createdAt).toBeInstanceOf(Date);
  });

  it("encodes Dates, Blobs, and ArrayBuffers so they survive JSON", async () => {
    const value = {
      at: new Date("2026-09-01T12:00:00Z"),
      blob: new Blob([new Uint8Array([137, 80, 0, 255])], { type: "image/png" }),
      docx: new Uint8Array([80, 75, 3, 4]).buffer,
      nested: [{ n: 1, s: "x", none: null }],
    };
    const back = decode(JSON.parse(JSON.stringify(await encode(value)))) as typeof value;
    expect(back.at).toEqual(value.at);
    expect(back.blob.type).toBe("image/png");
    expect(Array.from(new Uint8Array(await back.blob.arrayBuffer()))).toEqual([137, 80, 0, 255]);
    expect(Array.from(new Uint8Array(back.docx))).toEqual([80, 75, 3, 4]);
    expect(back.nested).toEqual(value.nested);
  });

  it("summarizes sessions, uploaded and CUI documents, and templates", async () => {
    await seed();
    const backup = await buildBackup();
    expect(backup.summary).toEqual({ sessions: 1, documents: 2, cuiDocuments: 1, templates: 1 });
  });

  it("leaves out embeddings and clears stale ones on restore", async () => {
    await seed();
    const backup = await buildBackup();
    expect(backup.tables).not.toHaveProperty("embeddingChunks");

    const result = await validateBackup(JSON.stringify(backup));
    if (!result.ok) throw new Error(result.error.detail);
    await restoreBackup(result.backup);
    expect(await db.embeddingChunks.count()).toBe(0);
  });

  it("carries allow-listed settings but never API keys or caches", async () => {
    localStorage.setItem("doc-builder:user-profile", '{"name":"Pat"}');
    localStorage.setItem("doc-builder:model-overrides", "{}");
    localStorage.setItem("doc-builder:api-key-noncui", "secret");
    localStorage.setItem("doc-builder:api-key-cui", "secret");
    localStorage.setItem("doc-builder:discovered-models", "[]");
    const backup = await buildBackup();
    expect(backup.settings).toEqual({ "doc-builder:user-profile": '{"name":"Pat"}', "doc-builder:model-overrides": "{}" });
    expect(JSON.stringify(backup)).not.toContain("secret");
  });

  it("restore replaces settings and keeps this browser's API keys", async () => {
    localStorage.setItem("doc-builder:user-profile", '{"name":"Old"}');
    const text = await backupText();

    localStorage.setItem("doc-builder:user-profile", '{"name":"New"}');
    localStorage.setItem("doc-builder:user-role", "sca");
    localStorage.setItem("doc-builder:api-key-noncui", "keep-me");
    const result = await validateBackup(text);
    if (!result.ok) throw new Error(result.error.detail);
    await restoreBackup(result.backup);

    expect(localStorage.getItem("doc-builder:user-profile")).toBe('{"name":"Old"}');
    expect(localStorage.getItem("doc-builder:user-role")).toBeNull();
    expect(localStorage.getItem("doc-builder:api-key-noncui")).toBe("keep-me");
  });

  it("restore replaces records that aren't in the backup", async () => {
    const text = await backupText();
    await db.uploadedDocuments.add(doc({ id: "later" }));
    const result = await validateBackup(text);
    if (!result.ok) throw new Error(result.error.detail);
    await restoreBackup(result.backup);
    expect(await db.uploadedDocuments.count()).toBe(0);
  });
});

describe("backup validation", () => {
  async function parsed() {
    await seed();
    return JSON.parse(await backupText());
  }

  it.each([
    ["not JSON", "{oops"],
    ["wrong marker", JSON.stringify({ _type: "doc-builder-session-export", version: 1 })],
  ])("rejects %s", async (_label, text) => {
    const result = await validateBackup(text);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error.kind).toBe("db.backup-invalid");
  });

  it("rejects a backup from a newer database version", async () => {
    const file = await parsed();
    file.dbVersion = db.verno + 1;
    const result = await validateBackup(JSON.stringify(file));
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error.kind).toBe("db.backup-newer-version");
  });

  it("rejects unknown tables and malformed records", async () => {
    const file = await parsed();
    for (const tables of [{ ...file.tables, mystery: [] }, { ...file.tables, sessions: ["nope"] }]) {
      const result = await validateBackup(JSON.stringify({ ...file, tables }));
      expect(result.ok).toBe(false);
    }
  });

  it("skips a damaged custom template with a warning", async () => {
    const file = await parsed();
    file.tables.userTemplates[0].docx.data = btoa("not a docx");
    const result = await validateBackup(JSON.stringify(file));
    if (!result.ok) throw new Error(result.error.detail);
    expect(result.backup.tables.userTemplates).toEqual([]);
    expect(result.backup.warnings.join(" ")).toMatch(/Vendor Letter.*won't be restored/);
  });

  it("ignores settings outside the allow-list", async () => {
    const file = await parsed();
    file.settings["doc-builder:api-key-cui"] = "injected";
    const result = await validateBackup(JSON.stringify(file));
    if (!result.ok) throw new Error(result.error.detail);
    expect(result.backup.settings).not.toHaveProperty("doc-builder:api-key-cui");
  });

  it("knows how to restore the current database version", () => {
    // Bumping the Dexie version? Add it to BACKUP_DB_VERSIONS, converting
    // older backups in validateBackup if the upgrade reshapes records.
    expect(BACKUP_DB_VERSIONS).toContain(db.verno);
  });

  it("allow-lists only doc-builder settings, never API keys", () => {
    for (const key of BACKED_UP_SETTINGS) {
      expect(key.startsWith("doc-builder:")).toBe(true);
      expect(key).not.toMatch(/api-key/);
    }
  });
});

describe("last backup", () => {
  const now = new Date("2026-10-09T12:00:00Z");

  it("is null before the first backup", () => {
    expect(daysSinceBackup(now)).toBeNull();
  });

  it("counts whole days since the last backup", () => {
    localStorage.setItem(LAST_BACKUP_KEY, new Date(now.getTime() - 14.5 * 24 * 60 * 60 * 1000).toISOString());
    expect(daysSinceBackup(now)).toBe(14);
  });

  it("is set to the backup's date after a restore", async () => {
    const text = await backupText();
    localStorage.removeItem(LAST_BACKUP_KEY);
    const result = await validateBackup(text);
    if (!result.ok) throw new Error(result.error.detail);
    await restoreBackup(result.backup);
    expect(localStorage.getItem(LAST_BACKUP_KEY)).toBe(new Date(result.backup.exportedAt).toISOString());
  });
});
