/** Metadata attached to a field value when set by an AI tool. */
export interface FieldMeta {
  /** AI confidence score: 0.0 (no confidence) to 1.0 (certain). */
  confidence: number;
  /** Origin of this value. */
  source: "bulk-edit" | "chat-draft" | "manual";
  /** ISO timestamp when the AI set this value. */
  aiSetAt: string;
}

/** Where a session's drafting style note came from, when it was derived from style references. */
export interface DraftingStyleSource {
  /**
   * Saved document IDs of the style-reference set the note accounts for: the
   * set it was derived from, or the set the user chose to keep a hand-edited
   * note over.
   */
  docIds: string[];
  fileNames: string[];
  /** ISO timestamp of the analysis call. */
  derivedAt: string;
}

/** Persisted session — one per in-progress document. */
export interface Session {
  id: string;
  documentTypeId: string;
  answers: Record<string, string | number | boolean>;
  /** Per-field AI metadata. Keys mirror `answers` keys ("section_id.field_id"). */
  fieldMeta?: Record<string, FieldMeta>;
  /**
   * Customer style preferences for freetext drafting, injected into every
   * drafting prompt. Derived from the attached style references or written by
   * the user, and kept like any other session content (across reloads and
   * endpoint switches).
   */
  draftingStyle?: string;
  /** Set when `draftingStyle` was derived from style-reference documents. */
  draftingStyleSource?: DraftingStyleSource;
  /**
   * True once the user wrote or edited the note (typed it or picked a preset).
   * A new style reference then asks before replacing it.
   */
  draftingStyleEdited?: boolean;
  currentSection: string;
  /** Per-section user confirmation (explicit "done" click). */
  sectionConfirmed: Record<string, boolean>;
  /** True once the user approves the review. */
  reviewApproved?: boolean;
  /** True once the document has been generated/previewed. */
  generated?: boolean;
  /**
   * Document set name (e.g. "Shipping Hub"). When present, this session
   * produces multiple documents — one per schema in the set.
   */
  setId?: string;
  /**
   * Ordered list of schema IDs belonging to this set session.
   * Only present when `setId` is defined.
   */
  schemaIds?: string[];
  createdAt: Date;
  updatedAt: Date;
}

/** A single message in an AI drafting conversation. */
export interface ChatMessage {
  id: string;
  sessionId: string;
  /** Namespaced field key: "section_id.field_id" for per-field chats, "__bulk_edit" for bulk edit. */
  fieldKey: string;
  role: "user" | "assistant" | "tool";
  content: string;
  /** Short display label for condensed view (e.g., summarized user message in bulk edit). */
  displayLabel?: string;
  /** Tool calls made by the assistant (for API conversation replay). */
  toolCalls?: import("../ai/types").ToolCall[];
  /** For tool messages: the tool_call_id this responds to. */
  toolCallId?: string;
  /** Timing breakdown (only present on the final assistant message of a response). */
  timings?: import("../ai/types").ResponseTimings;
  createdAt: Date;
}

/** Configuration snapshot for a bulk-edit conversation (persisted for resume). */
export interface ConversationConfig {
  mode: "prompt" | "document";
  prompt?: string;
  documentText?: string;
  selectedSectionIds: string[];
  referenceDocTexts?: { title: string; text: string }[];
}

/** Metadata record for a conversation — enables the history view without scanning all messages. */
export interface Conversation {
  id: string;
  sessionId: string;
  /** Same as ChatMessage.fieldKey: "section_id.field_id" or "__bulk_edit". */
  fieldKey: string;
  /** Document type ID (denormalized for orphan survival after session delete). */
  documentTypeId: string;
  /** Human-readable document type title. */
  documentTypeTitle: string;
  /** Human-readable label: field/section name, or "Bulk Edit". */
  label: string;
  /** Conversation kind. */
  conversationType: "field-chat" | "bulk-edit";
  /** Number of messages in this conversation. */
  messageCount: number;
  /** Persisted BulkEditRequest config (for resuming with full context). */
  config?: ConversationConfig;
  createdAt: Date;
  updatedAt: Date;
}

/** A user-uploaded document persisted for reuse across sessions. */
export interface UploadedDocument {
  id: string;
  /** Original filename (e.g., "contract.pdf"). */
  fileName: string;
  /** MIME type. */
  mimeType: string;
  /** File size in bytes. */
  fileSize: number;
  /**
   * SHA-256 hex of the original file bytes. Identifies re-uploads of the same
   * file. Absent on records saved before this field existed.
   */
  contentHash?: string;
  /** Extracted plain text content (from parseFile). */
  textContent: string;
  /** Character count of textContent (for quick display). */
  charCount: number;
  /** Document category: "fms" | "legal" | "program-management". Shared across schemas in the same category. */
  category: string;
  /** True when this document contained images processed by the vision API. */
  isImage?: boolean;
  /** Origin of the document: "upload" for user-uploaded, "reference" for bundled reference docs. */
  source?: "upload" | "reference";
  /** For reference docs: the manifest ID (e.g., "sca-subcontractor-information-20260814"). Used to deduplicate. */
  refId?: string;
  /** The endpoint that was active when this document was uploaded/saved. */
  uploadEndpoint?: import("../ai/endpoints").EndpointId;
  /**
   * CUI scan/classification status:
   * - "pending": not yet scanned (IL2, scan not run)
   * - "clean": scanned, no CUI indicators found
   * - "flagged": scanned, CUI indicators found — needs user resolution
   * - "scan-error": AI scan failed — treated as flagged (conservative)
   * - "not-cui": user affirmed the document is not CUI
   * - "cui": document is treated as CUI (uploaded in CUI mode, or user switched to CUI mode)
   */
  cuiStatus?: "pending" | "clean" | "flagged" | "scan-error" | "not-cui" | "cui";
  /** Detection detail when cuiStatus is "flagged" (markers/reason/confidence). */
  cuiDetection?: import("../ai/cuiDetection").CuiDetectionResult;
  /** Full AI scan error message when cuiStatus is "scan-error". */
  cuiScanError?: string;
  /** Whether the AI classifier (not just regex) was able to run on this doc. */
  cuiScannedWithAi?: boolean;
  /**
   * Images quarantined pending CUI confirmation. Present when the pre-image
   * regex gate flagged the document's body or header/footer text. Each entry
   * holds the quarantine placeholder text (stored in `textContent`) and the
   * original image data URL so `resolveImages` can convert them later.
   */
  quarantinedImages?: { placeholder: string; dataUrl: string }[];
  /**
   * Raw text extracted from DOCX headers/footers. Prepended to `textContent`
   * for CUI scanning so banner markings in headers are always caught.
   */
  headerFooterText?: string;
  /**
   * The document-picker slot (schema `recommended_uploads` entry) this document
   * was last attached under, e.g. `{ slotId: "pws", title: "PWS (...)" }`.
   * Display label only — shown next to the filename in later sessions and used
   * to sort "Choose existing" candidates. Never auto-attaches.
   */
  slotRole?: { slotId: string; title: string };
  /** ISO timestamp when uploaded. */
  createdAt: string;
  /** ISO timestamp of last use in a draft session. */
  lastUsedAt: string;
}

// ---------------------------------------------------------------------------
// Session export/import
// ---------------------------------------------------------------------------

/** Schema reference embedded in the export file for compatibility checking. */
export interface SessionExportSchemaRef {
  id: string;
  title: string;
  version: number;
  sectionCount: number;
  fieldCount: number;
  /** Structural manifest: every field key + type at time of export. Used for precise diff on import. */
  fields?: Array<{ key: string; type: string }>;
}

/** Self-describing JSON envelope for a saved session + chat history. */
export interface SessionExportFile {
  /** Fixed magic identifier for file type detection. */
  _type: "doc-builder-session-export";
  /** Export format version for forward compatibility. */
  version: 1;
  /** ISO timestamp of when the export was created. */
  exportedAt: string;

  /** Core session data (id stripped — regenerated on import). */
  session: {
    documentTypeId: string;
    answers: Record<string, string | number | boolean>;
    fieldMeta?: Record<string, FieldMeta>;
    draftingStyle?: string;
    draftingStyleSource?: DraftingStyleSource;
    draftingStyleEdited?: boolean;
    currentSection: string;
    sectionConfirmed: Record<string, boolean>;
    reviewApproved?: boolean;
    generated?: boolean;
    setId?: string;
    schemaIds?: string[];
    createdAt: string;
    updatedAt: string;
  };

  /** Schema fingerprint for compatibility checking on import. */
  schemaRef: SessionExportSchemaRef;

  /** Conversation metadata records for this session (id stripped, dates as ISO strings). */
  conversations: Array<Omit<Conversation, "id" | "createdAt" | "updatedAt"> & { createdAt: string; updatedAt: string }>;

  /** All chat messages for this session (id stripped, dates as ISO strings). */
  chatMessages: Array<Omit<ChatMessage, "id" | "createdAt"> & { createdAt: string }>;

  /** Images uploaded for image fields, stored as base64 for portability. */
  images?: Array<{
    fieldKey: string;
    fileName: string;
    mimeType: string;
    /** Base64-encoded image data. */
    dataBase64: string;
    naturalWidth: number;
    naturalHeight: number;
  }>;

  /**
   * Custom templates the session was built on, so it can be imported on a
   * machine that doesn't have them yet. Absent for built-in document types.
   */
  customTemplates?: EmbeddedTemplate[];
}

// ---------------------------------------------------------------------------
// User Templates (uploaded schema + .docx pairs)
// ---------------------------------------------------------------------------

/** Details a user attached when submitting a template for team-wide use. */
export interface TemplateSubmission {
  /** What the template is for, who uses it, how urgent it is. */
  notes: string;
  /** Id of the built-in schema it was derived from, if any. */
  basedOn?: string;
  submittedAt: string;
}

/** A user-uploaded document type: validated schema plus its Word template. */
export interface UserTemplate {
  /** Registered schema id: "custom-<originalId>". */
  id: string;
  /** Id as written in the uploaded schema (used to detect promotion to built-in). */
  originalId: string;
  /** Normalized schema (id, category, docx_template rewritten). */
  schema: import("../schemas/types").DocumentSchema;
  /** Cleaned .docx bytes (hints stripped, split tags merged). */
  docx: ArrayBuffer;
  docxSha256: string;
  /** Increments each time the template is replaced. */
  revision: number;
  createdAt: string;
  updatedAt: string;
  /** Built-in schema the user started from ("Download as starting point"). */
  basedOn?: string;
  /** Set when the user sends the template to the developers. */
  submission?: TemplateSubmission;
  /** Set when the user switched to the built-in that replaced this template. */
  archivedAt?: string;
}

/**
 * A template being built or edited in the app before it is installed: a
 * schema scaffolded from a tagged .docx, or a copy of an official template.
 * Installing validates it and moves it to `userTemplates`.
 */
export interface TemplateDraft {
  /** "draft-<uuid>". */
  id: string;
  /** Schema as the user is editing it, with its original (unprefixed) id. */
  schema: import("../schemas/types").DocumentSchema;
  /** Cleaned .docx bytes (hints stripped, split tags merged). */
  docx: ArrayBuffer;
  /** Uploaded file name, or the official template's title. */
  sourceName: string;
  /** Built-in schema the draft was copied from. */
  basedOn?: string;
  /** Messages from the scaffold, shown once at the top of the editor. */
  notes: import("../schemas/scaffoldSchema").ScaffoldNote[];
  createdAt: string;
  updatedAt: string;
}

/** Portable form of a UserTemplate, used in bundles and session exports. */
export interface EmbeddedTemplate {
  originalId: string;
  /** Schema as uploaded (with its original id). */
  schema: import("../schemas/types").DocumentSchema;
  docxBase64: string;
  docxSha256: string;
  revision: number;
  basedOn?: string;
  submission?: TemplateSubmission;
}

/** A single custom template, shared as a file. */
export interface TemplateBundleFile {
  _type: "doc-builder-template-bundle";
  version: 1;
  exportedAt: string;
  template: EmbeddedTemplate;
}

// ---------------------------------------------------------------------------
// Session Images (user-uploaded figures)
// ---------------------------------------------------------------------------

/** An image uploaded by the user for an `image` field in a session. */
export interface SessionImage {
  /** Session ID this image belongs to. */
  sessionId: string;
  /** Namespaced field key: "section_id.field_id". */
  fieldKey: string;
  /** Original filename (e.g., "figure-4-1.png"). */
  fileName: string;
  /** MIME type (e.g., "image/png"). */
  mimeType: string;
  /** Raw image data. */
  blob: Blob;
  /** Intrinsic image width in pixels. */
  naturalWidth: number;
  /** Intrinsic image height in pixels. */
  naturalHeight: number;
}

// ---------------------------------------------------------------------------
// Embeddings
// ---------------------------------------------------------------------------

/** A stored embedding chunk for RAG retrieval. */
export interface EmbeddingChunkRecord {
  id: string;
  /** Reference doc id (from schema's reference_docs). */
  docId: string;
  /** Chunk index within the document. */
  index: number;
  /** Chunk text content. */
  text: string;
  /** Float vector from embeddings API. */
  embedding: number[];
  /** Hash of the full doc text for cache invalidation. */
  sourceHash: string;
  /** Embedding model used. */
  model: string;
  /** ISO timestamp. */
  createdAt: string;
}
