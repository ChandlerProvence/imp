import { describe, it, expect } from "vitest";
import { markdownToWordXml } from "./markdownToWordXml";

describe("markdownToWordXml", () => {
  describe("empty/falsy input", () => {
    it("returns empty string for empty input", () => {
      expect(markdownToWordXml("")).toBe("");
    });

    it("returns empty string for whitespace-only input", () => {
      expect(markdownToWordXml("   \n\n  ")).toBe("");
    });

    it("returns empty string for null-ish input", () => {
      // @ts-expect-error testing runtime safety
      expect(markdownToWordXml(null)).toBe("");
      // @ts-expect-error testing runtime safety
      expect(markdownToWordXml(undefined)).toBe("");
    });
  });

  describe("headings", () => {
    it("converts # to Heading1 style", () => {
      const result = markdownToWordXml("# Title");
      expect(result).toContain('<w:pStyle w:val="Heading1"/>');
      expect(result).toContain("Title");
    });

    it("converts ## to Heading2 style", () => {
      const result = markdownToWordXml("## Subtitle");
      expect(result).toContain('<w:pStyle w:val="Heading2"/>');
      expect(result).toContain("Subtitle");
    });

    it("converts ### to Heading3 style", () => {
      const result = markdownToWordXml("### Section");
      expect(result).toContain('<w:pStyle w:val="Heading3"/>');
    });

    it("converts #### to Heading4 style", () => {
      const result = markdownToWordXml("#### Subsection");
      expect(result).toContain('<w:pStyle w:val="Heading4"/>');
    });

    it("converts ##### to Heading5 style", () => {
      const result = markdownToWordXml("##### Deep");
      expect(result).toContain('<w:pStyle w:val="Heading5"/>');
    });

    it("converts ###### to Heading6 style", () => {
      const result = markdownToWordXml("###### Deepest");
      expect(result).toContain('<w:pStyle w:val="Heading6"/>');
    });

    it("wraps heading in a single <w:p> element", () => {
      const result = markdownToWordXml("## Test");
      expect(result).toMatch(/^<w:p>.*<\/w:p>$/);
    });
  });

  describe("paragraphs", () => {
    it("converts plain text to a paragraph", () => {
      const result = markdownToWordXml("Hello world");
      expect(result).toContain("<w:p>");
      expect(result).toContain("Hello world");
      expect(result).not.toContain("w:pStyle");
    });

    it("separates multiple paragraphs into multiple <w:p> elements", () => {
      const result = markdownToWordXml("First paragraph.\n\nSecond paragraph.");
      const pCount = (result.match(/<w:p>/g) || []).length;
      expect(pCount).toBe(2);
      expect(result).toContain("First paragraph.");
      expect(result).toContain("Second paragraph.");
    });
  });

  describe("mixed headings and paragraphs", () => {
    it("produces correct order of elements", () => {
      const md = "## Overview\n\nThis is the overview.\n\n### Details\n\nSome details.";
      const result = markdownToWordXml(md);

      // Should have 4 <w:p> elements: heading2, para, heading3, para
      const pCount = (result.match(/<w:p>/g) || []).length;
      expect(pCount).toBe(4);

      // Heading2 should come before Heading3
      const h2Pos = result.indexOf("Heading2");
      const h3Pos = result.indexOf("Heading3");
      expect(h2Pos).toBeLessThan(h3Pos);
    });
  });

  describe("inline formatting", () => {
    it("renders bold with <w:b/>", () => {
      const result = markdownToWordXml("This is **bold** text.");
      expect(result).toContain("<w:b/>");
      expect(result).toContain("bold");
    });

    it("renders italic with <w:i/>", () => {
      const result = markdownToWordXml("This is *italic* text.");
      expect(result).toContain("<w:i/>");
      expect(result).toContain("italic");
    });

    it("renders bold+italic with both <w:b/> and <w:i/>", () => {
      const result = markdownToWordXml("This is ***bold italic*** text.");
      expect(result).toContain("<w:b/>");
      expect(result).toContain("<w:i/>");
    });

    it("renders inline code with Courier New font", () => {
      const result = markdownToWordXml("Use `npm install` to install.");
      expect(result).toContain('w:ascii="Courier New"');
      expect(result).toContain("npm install");
    });

    it("renders bold within headings", () => {
      const result = markdownToWordXml("## **Important** heading");
      expect(result).toContain('<w:pStyle w:val="Heading2"/>');
      expect(result).toContain("<w:b/>");
      expect(result).toContain("Important");
    });
  });

  describe("lists", () => {
    it("renders unordered list items with bullet prefix", () => {
      const result = markdownToWordXml("- Item one\n- Item two\n- Item three");
      expect(result).toContain("• ");
      expect(result).toContain("Item one");
      expect(result).toContain("Item two");
      expect(result).toContain("Item three");
      // 3 list paragraphs
      const pCount = (result.match(/<w:p>/g) || []).length;
      expect(pCount).toBe(3);
    });

    it("renders ordered list items with number prefix", () => {
      const result = markdownToWordXml("1. First\n2. Second\n3. Third");
      expect(result).toContain("1. ");
      expect(result).toContain("2. ");
      expect(result).toContain("3. ");
      expect(result).toContain("First");
    });

    it("applies ListBullet style to unordered items", () => {
      const result = markdownToWordXml("- Item");
      expect(result).toContain('<w:pStyle w:val="ListBullet"/>');
    });

    it("applies ListNumber style to ordered items", () => {
      const result = markdownToWordXml("1. Item");
      expect(result).toContain('<w:pStyle w:val="ListNumber"/>');
    });
  });

  describe("code blocks", () => {
    it("renders fenced code blocks with monospace font", () => {
      const result = markdownToWordXml("```\nconst x = 1;\nconst y = 2;\n```");
      expect(result).toContain('w:ascii="Courier New"');
      expect(result).toContain("const x = 1;");
      expect(result).toContain("const y = 2;");
    });

    it("renders each line of a code block as a separate paragraph", () => {
      const result = markdownToWordXml("```\nline1\nline2\nline3\n```");
      const pCount = (result.match(/<w:p>/g) || []).length;
      expect(pCount).toBe(3);
    });
  });

  describe("XML escaping", () => {
    it("escapes ampersands", () => {
      const result = markdownToWordXml("Tom & Jerry");
      expect(result).toContain("Tom &amp; Jerry");
      expect(result).not.toContain("Tom & Jerry");
    });

    it("escapes angle brackets", () => {
      const result = markdownToWordXml("Use <div> for containers");
      expect(result).toContain("&lt;div&gt;");
    });

    it("escapes quotes", () => {
      const result = markdownToWordXml('He said "hello"');
      expect(result).toContain("&quot;hello&quot;");
    });

    it("escapes special chars inside headings", () => {
      const result = markdownToWordXml("## Items & Services <2024>");
      expect(result).toContain("Items &amp; Services &lt;2024&gt;");
    });
  });

  describe("edge cases", () => {
    it("handles content with only headings (no body)", () => {
      const result = markdownToWordXml("## A\n\n## B\n\n## C");
      const pCount = (result.match(/<w:p>/g) || []).length;
      expect(pCount).toBe(3);
      expect(result).toContain("Heading2");
    });

    it("handles single-line plain text", () => {
      const result = markdownToWordXml("Just some text.");
      expect(result).toContain("<w:p>");
      expect(result).toContain("Just some text.");
      expect(result).not.toContain("w:pStyle");
    });

    it("preserves spaces via xml:space preserve", () => {
      const result = markdownToWordXml("Hello world");
      expect(result).toContain('xml:space="preserve"');
    });

    it("handles horizontal rules", () => {
      const result = markdownToWordXml("Above\n\n---\n\nBelow");
      expect(result).toContain("w:pBdr");
      expect(result).toContain("Above");
      expect(result).toContain("Below");
    });
  });

  describe("heading style mapping", () => {
    const styleMap: Record<number, string> = {
      1: "Heading1NoNumbers",
      2: "Heading2Manual",
      3: "Heading3Manual",
      4: "Heading4Manual",
      5: "Heading5Manual",
    };

    it("uses custom style names when headingStyleMap is provided", () => {
      const result = markdownToWordXml("## Sub-heading", { headingStyleMap: styleMap });
      expect(result).toContain('w:pStyle w:val="Heading2Manual"');
      expect(result).not.toContain('w:val="Heading2"');
    });

    it("falls back to generic Heading{N} when no map provided", () => {
      const result = markdownToWordXml("## Sub-heading");
      expect(result).toContain('w:pStyle w:val="Heading2"');
    });

    it("falls back to generic style for unmapped depths", () => {
      const result = markdownToWordXml("###### Deepest", { headingStyleMap: styleMap });
      // Depth 6 is not in the map → falls back to Heading6
      expect(result).toContain('w:pStyle w:val="Heading6"');
    });

    it("applies baseLevel offset to heading depth", () => {
      // # (depth 1) + baseLevel 2 = effective depth 3 → Heading3Manual
      const result = markdownToWordXml("# Topic", { baseLevel: 2, headingStyleMap: styleMap });
      expect(result).toContain('w:pStyle w:val="Heading3Manual"');
    });

    it("applies baseLevel without style map", () => {
      // # (depth 1) + baseLevel 2 = effective depth 3 → Heading3 (generic)
      const result = markdownToWordXml("# Topic", { baseLevel: 2 });
      expect(result).toContain('w:pStyle w:val="Heading3"');
    });

    it("clamps effective depth to 9", () => {
      // ###### (depth 6) + baseLevel 5 = 11 → clamped to 9
      const result = markdownToWordXml("###### Deep", { baseLevel: 5 });
      expect(result).toContain('w:pStyle w:val="Heading9"');
    });

    it("maps multiple headings in a single document", () => {
      const md = "# First\n\nSome text.\n\n## Second\n\nMore text.";
      const result = markdownToWordXml(md, { baseLevel: 1, headingStyleMap: styleMap });
      // # → depth 1+1=2 → Heading2Manual
      expect(result).toContain('w:pStyle w:val="Heading2Manual"');
      // ## → depth 2+1=3 → Heading3Manual
      expect(result).toContain('w:pStyle w:val="Heading3Manual"');
    });

    it("does not affect non-heading elements", () => {
      const result = markdownToWordXml("Plain text.\n\n- List item", {
        headingStyleMap: styleMap,
        baseLevel: 2,
      });
      // No heading styles should appear
      expect(result).not.toContain("Heading");
      expect(result).toContain("Plain text.");
      expect(result).toContain("List item");
    });
  });
});
