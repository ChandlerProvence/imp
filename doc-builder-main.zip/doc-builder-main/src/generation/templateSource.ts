/**
 * Where a schema's .docx template bytes come from.
 *
 * - Built-in schemas: the static file vite.config.ts copies to
 *   `${BASE_URL}templates/`, fetched by URL.
 * - User-uploaded schemas (`custom-` ids): the bytes stored in IndexedDB.
 *   These never become a URL, so an uploaded schema can't steer a fetch.
 *
 * Consumers that cache derived data (templateTextService) subscribe to
 * onTemplateChanged so a replaced or deleted upload isn't served stale.
 */
import type { DocumentSchema } from "../schemas/types";
import { getSchema, isBuiltInSchema } from "../schemas/loader";
import { isCustomSchemaId } from "../schemas/customIds";
import { assertAllowedFetchUrl } from "../utils/urlAllowlist";
import { appErrorException } from "../errors";

const listeners = new Set<(schemaId: string) => void>();

/** Subscribe to template replacement/removal. Returns an unsubscribe function. */
export function onTemplateChanged(listener: (schemaId: string) => void): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

/** Tell caches that a schema's template bytes changed or were removed. */
export function invalidateTemplate(schemaId: string): void {
  for (const listener of listeners) listener(schemaId);
}

/** Load a schema's Word template. Throws if the schema has none or it can't be found. */
export async function loadTemplateBuffer(schema: DocumentSchema): Promise<ArrayBuffer> {
  if (isCustomSchemaId(schema.id)) {
    // Dynamic import keeps headless Node tools free of IndexedDB
    const { getUserTemplate } = await import("../db/userTemplates");
    const record = await getUserTemplate(schema.id);
    if (!record) {
      throw appErrorException("generation.custom-template-missing", {
        context: { schema: schema.title },
        detail: `No stored template for "${schema.id}".`,
      });
    }
    return record.docx.slice(0);
  }

  // Resolve the file name from the registry, not the passed object
  const registered = isBuiltInSchema(schema.id) ? getSchema(schema.id) : undefined;
  if (!registered?.docx_template) {
    throw appErrorException("generation.template-missing", {
      context: { schema: schema.id },
      detail:
        `Schema "${schema.id}" has no pre-registered template URL. ` +
        `Ensure the schema has a docx_template field and is loaded by the registry.`,
    });
  }
  const templateUrl = `${import.meta.env.BASE_URL}templates/${registered.docx_template}`;
  assertAllowedFetchUrl(templateUrl);
  let response: Response;
  try {
    // nosemgrep: nodejs_scan.javascript-ssrf-rule-node_ssrf — URL is build-time BASE_URL + a built-in schema's filename, validated by allowlist above
    response = await fetch(templateUrl);
  } catch (err) {
    throw appErrorException("generation.template-missing", { context: { schema: schema.title }, cause: err });
  }
  if (!response.ok) {
    throw appErrorException("generation.template-missing", {
      context: { schema: schema.title },
      detail: `Failed to fetch Word template ${templateUrl}: ${response.status} ${response.statusText}`,
    });
  }
  return response.arrayBuffer();
}
