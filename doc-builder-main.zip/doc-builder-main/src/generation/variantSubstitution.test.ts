/**
 * Suite 2b: Variant Schema Substitution Correctness
 *
 * For each variant schema (those with template_text_replace), verifies:
 * 1. No source text leakage — replaced "from" strings do not appear in output
 * 2. Replacement text present — non-empty "to" strings appear in output
 * 3. Structural parity with base — paragraph counts are within tolerance
 * 4. Field value identity — scalar answer values appear in both base and variant
 * 5. From-pattern existence — every "from" string actually appears in the base template
 *
 * Note: extractDocxText decodes XML entities before returning text, so
 * comparisons here use plain text. assertNoLeakedText checks raw <w:t>
 * content instead (template_text_replace operates on raw XML), so its
 * "from" patterns are separately XML-encoded via xmlEncode below.
 */
import { describe, it, expect } from "vitest";
import { schemas } from "../schemas/loader";
import { renderDocxFromArrayBuffer } from "./generateDocx";
import {
  loadTemplateBuffer,
  extractDocxText,
  assertNoLeakedText,
  countParagraphs,
} from "../test/docx-test-utils";
import { loadAnswerFixture, generateSampleAnswers } from "../test/fixture-utils";
import type { DocumentSchema } from "../schemas/types";

// ---------------------------------------------------------------------------
// XML entity helpers
// ---------------------------------------------------------------------------

/** XML-encode a string the way Word XML stores text content. */
function xmlEncode(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// ---------------------------------------------------------------------------
// Schema discovery
// ---------------------------------------------------------------------------

/** Collect all variant schemas (those with non-empty template_text_replace). */
const variantSchemas: DocumentSchema[] = [];
for (const [, schema] of schemas) {
  if (schema.template_text_replace && schema.template_text_replace.length > 0) {
    variantSchemas.push(schema);
  }
}

/**
 * Find the base schema for a variant: same docx_template filename but without
 * template_text_replace (or the one that the variant was derived from).
 */
function findBaseSchema(variant: DocumentSchema): DocumentSchema | undefined {
  if (!variant.docx_template) return undefined;
  for (const [, schema] of schemas) {
    if (schema.id === variant.id) continue;
    if (schema.docx_template !== variant.docx_template) continue;
    // Prefer the one without template_text_replace (the true base)
    if (!schema.template_text_replace || schema.template_text_replace.length === 0) {
      return schema;
    }
  }
  // Fallback: any schema sharing the same template (different replacements)
  for (const [, schema] of schemas) {
    if (schema.id === variant.id) continue;
    if (schema.docx_template === variant.docx_template) return schema;
  }
  return undefined;
}

// ---------------------------------------------------------------------------
// Fixture helpers
// ---------------------------------------------------------------------------

/**
 * Load answers for a schema: prefer a fixture, fall back to generated samples.
 */
function loadAnswers(
  schema: DocumentSchema,
): Record<string, string | number | boolean> {
  return loadAnswerFixture(schema.id) ?? generateSampleAnswers(schema);
}

/**
 * Extract scalar (non-table, non-freetext) answer values for identity checks.
 * Returns only primitive string/number/boolean values that should appear as-is
 * in the generated document text.
 */
function scalarAnswerValues(
  schema: DocumentSchema,
  answers: Record<string, string | number | boolean>,
): { key: string; value: string }[] {
  const skipKeys = new Set<string>();
  for (const section of schema.sections) {
    for (const field of section.fields) {
      const key = `${section.id}.${field.id}`;
      // Skip non-scalar types, computed fields, and date/number fields
      // whose stored values differ from their rendered form (dates are
      // reformatted, numbers may get locale formatting).
      if (
        field.type === "table" ||
        field.type === "freetext" ||
        field.type === "date" ||
        field.type === "number" ||
        field.formula !== undefined ||
        field.same_as
      ) {
        skipKeys.add(key);
      }
    }
  }

  const results: { key: string; value: string }[] = [];
  for (const [key, value] of Object.entries(answers)) {
    if (skipKeys.has(key)) continue;
    const strVal = String(value);
    // Skip empty, very short (single char), or boolean text representations
    // that could false-positive match unrelated text
    if (strVal === "" || strVal === "true" || strVal === "false") continue;
    if (strVal.length < 3) continue;
    results.push({ key, value: strVal });
  }
  return results;
}

// ---------------------------------------------------------------------------
// Content blocks conditional removal
// ---------------------------------------------------------------------------

describe("content_blocks conditional removal", () => {
  const base = schemas.get("fms-tte-no-sow-memo");
  const variant = schemas.get("fms-str-no-sow-memo");

  it.skipIf(!base || !variant)(
    "base (TT&E) output contains the TTE process detail paragraph",
    async () => {
      const answers = loadAnswers(base!);
      const blob = renderDocxFromArrayBuffer(loadTemplateBuffer(base!), base!, answers);
      const text = await extractDocxText(blob);
      expect(text).toContain("repair quote");
      expect(text).toContain("obligate repair funding");
    },
  );

  it.skipIf(!base || !variant)(
    "variant (STR) output removes the TTE process detail paragraph via content_blocks",
    async () => {
      const answers = loadAnswers(variant!);
      const blob = renderDocxFromArrayBuffer(loadTemplateBuffer(variant!), variant!, answers);
      const text = await extractDocxText(blob);
      expect(text).not.toContain("repair quote");
      expect(text).not.toContain("obligate repair funding");
    },
  );
});

// Guard: skip the entire suite if no variant schemas were loaded
describe.skipIf(variantSchemas.length === 0)(
  "Suite 2b: variant schema substitution correctness",
  () => {
    for (const variant of variantSchemas) {
      describe(`variant: ${variant.id}`, () => {
        const replacements = variant.template_text_replace!;
        const answers = loadAnswers(variant);

        it("generates a document without errors", () => {
          const buffer = loadTemplateBuffer(variant);
          const blob = renderDocxFromArrayBuffer(buffer, variant, answers);
          expect(blob).toBeInstanceOf(Blob);
          expect(blob.size).toBeGreaterThan(0);
        });

        it("does not leak source text from template_text_replace", async () => {
          const buffer = loadTemplateBuffer(variant);
          const blob = renderDocxFromArrayBuffer(buffer, variant, answers);
          // assertNoLeakedText checks raw <w:t> content, so we must supply
          // both the plain and XML-encoded forms of each "from" pattern to
          // catch leaks regardless of how the template stores the text.
          const fromPatternsExpanded = replacements.flatMap((r) => {
            const encoded = xmlEncode(r.from);
            return encoded !== r.from ? [r.from, encoded] : [r.from];
          });
          await assertNoLeakedText(blob, fromPatternsExpanded);
        });

        it("contains replacement text in the output", async () => {
          const buffer = loadTemplateBuffer(variant);
          const blob = renderDocxFromArrayBuffer(buffer, variant, answers);
          const text = await extractDocxText(blob);
          for (const { to } of replacements) {
            // Skip removal rules (empty "to") — nothing to look for
            if (!to) continue;
            expect(
              text,
              `Expected replacement text "${to}" to appear in variant output`,
            ).toContain(to);
          }
        });

        it("has template_text_replace 'from' patterns that exist in the base template", async () => {
          const base = findBaseSchema(variant);
          expect(base, "Variant must have a discoverable base schema").toBeDefined();
          const baseBuffer = loadTemplateBuffer(base!);
          const baseAnswers = loadAnswers(base!);
          const baseBlob = renderDocxFromArrayBuffer(baseBuffer, base!, baseAnswers);
          const text = await extractDocxText(baseBlob);
          for (const { from } of replacements) {
            expect(
              text,
              `template_text_replace "from" pattern not found in base template: "${from}"`,
            ).toContain(from);
          }
        });

        describe("structural parity with base", () => {
          const base = findBaseSchema(variant);

          it.skipIf(!base)(
            "has a similar paragraph count (within +/-5)",
            async () => {
              const baseSchema = base!;
              // Use the variant's answers for both — the schemas share the
              // same fields, so the same answer keys work.
              const buffer = loadTemplateBuffer(variant);
              const variantBlob = renderDocxFromArrayBuffer(
                buffer,
                variant,
                answers,
              );

              const baseBuffer = loadTemplateBuffer(baseSchema);
              const baseBlob = renderDocxFromArrayBuffer(
                baseBuffer,
                baseSchema,
                answers,
              );

              const variantParas = await countParagraphs(variantBlob);
              const baseParas = await countParagraphs(baseBlob);

              expect(
                Math.abs(variantParas - baseParas),
                `Paragraph count diverged: base=${baseParas}, variant=${variantParas}`,
              ).toBeLessThanOrEqual(5);
            },
          );

          it.skipIf(!base)(
            "preserves field values in both base and variant output",
            async () => {
              const baseSchema = base!;

              const buffer = loadTemplateBuffer(variant);
              const variantBlob = renderDocxFromArrayBuffer(
                buffer,
                variant,
                answers,
              );
              const variantText = await extractDocxText(variantBlob);

              const baseBuffer = loadTemplateBuffer(baseSchema);
              const baseBlob = renderDocxFromArrayBuffer(
                baseBuffer,
                baseSchema,
                answers,
              );
              const baseText = await extractDocxText(baseBlob);

              const scalars = scalarAnswerValues(variant, answers);
              // Require at least some scalar values to check (sanity guard)
              expect(
                scalars.length,
                "Expected at least one scalar answer to verify",
              ).toBeGreaterThan(0);

              for (const { key, value } of scalars) {
                expect(
                  variantText,
                  `Scalar "${key}" = "${value}" missing from variant output`,
                ).toContain(value);
                expect(
                  baseText,
                  `Scalar "${key}" = "${value}" missing from base output`,
                ).toContain(value);
              }
            },
          );
        });
      });
    }
  },
);
