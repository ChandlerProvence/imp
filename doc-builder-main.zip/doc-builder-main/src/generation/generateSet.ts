import type { DocumentSchema } from "../schemas/types";
import { resolveAliasedAnswers } from "../schemas/mergeSet";
import { substituteTemplate } from "./substitute";

/** A single generated document from a set session. */
export interface GeneratedDocument {
  schemaId: string;
  title: string;
  /** Substituted markdown. Undefined for docx-only schemas. */
  markdown?: string;
  /** Whether this schema has a Word template available for download. */
  hasDocx: boolean;
}

/**
 * Generate all documents for a set session.
 *
 * Each source schema receives the full shared answers map, with any
 * disambiguated table answers remapped to their original keys via tableAliases.
 */
export function generateSetDocuments(
  schemas: DocumentSchema[],
  answers: Record<string, string | number | boolean>,
  tableAliases?: Map<string, Record<string, string>>,
): GeneratedDocument[] {
  return schemas.map((schema) => {
    const doc: GeneratedDocument = {
      schemaId: schema.id,
      title: schema.title,
      hasDocx: Boolean(schema.docx_template),
    };

    // Resolve aliased table fields for this schema
    const resolved = tableAliases
      ? resolveAliasedAnswers(schema.id, answers, tableAliases)
      : answers;

    if (schema.output_template) {
      doc.markdown = substituteTemplate(schema.output_template, resolved, schema);
    }

    return doc;
  });
}
