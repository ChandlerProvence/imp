import { describe, it, expect } from "vitest";
import PizZip from "pizzip";
import { embedImages, prepareImageData } from "./imageEmbed";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";

function makeZip(bodyXml: string): PizZip {
  const zip = new PizZip();
  zip.file("word/document.xml", `<w:document xmlns:w="${W_NS}" ><w:body>${bodyXml}</w:body></w:document>`);
  zip.file("word/_rels/document.xml.rels", "<Relationships></Relationships>");
  zip.file("[Content_Types].xml", "<Types></Types>");
  return zip;
}

const image = (tag: string) => prepareImageData(tag, new Uint8Array([1, 2, 3]), "image/png", 100, 50);

function body(zip: PizZip): string {
  const xml = zip.file("word/document.xml")!.asText();
  return xml.slice(xml.indexOf("<w:body>") + "<w:body>".length, xml.indexOf("</w:body>"));
}

const DRAWING = /<w:drawing>[\s\S]*?<\/w:drawing>/g;

// ---------------------------------------------------------------------------
// Tag replacement
// ---------------------------------------------------------------------------

describe("embedImages tag replacement", () => {
  it("replaces a run that holds only the tag", () => {
    const zip = makeZip("<w:p><w:r><w:t>{{FIG}}</w:t></w:r></w:p>");
    embedImages(zip, [image("FIG")]);
    expect(body(zip).replace(DRAWING, "[IMG]")).toBe("<w:p><w:r>[IMG]</w:r></w:p>");
  });

  it("replaces a formatted run (with <w:rPr>) that holds only the tag", () => {
    const zip = makeZip('<w:p><w:r w:rsidR="00A1"><w:rPr><w:i/></w:rPr><w:t xml:space="preserve">{{FIG}}</w:t></w:r></w:p>');
    embedImages(zip, [image("FIG")]);
    expect(body(zip).replace(DRAWING, "[IMG]")).toBe("<w:p><w:r>[IMG]</w:r></w:p>");
  });

  it("does not swallow earlier runs or paragraphs", () => {
    // Regression: the previous regex started at the document's first <w:r> and
    // its lazy <w:rPr> match spanned paragraphs, deleting everything up to the tag.
    const zip = makeZip(
      "<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Keep me</w:t></w:r></w:p>" +
        "<w:p><w:r><w:t>And me</w:t></w:r></w:p>" +
        "<w:p><w:r><w:rPr><w:i/></w:rPr><w:t>{{FIG}}</w:t></w:r></w:p>",
    );
    embedImages(zip, [image("FIG")]);
    expect(body(zip).replace(DRAWING, "[IMG]")).toBe(
      "<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Keep me</w:t></w:r></w:p>" +
        "<w:p><w:r><w:t>And me</w:t></w:r></w:p>" +
        "<w:p><w:r>[IMG]</w:r></w:p>",
    );
  });

  it("splits the run when the tag shares it with other text", () => {
    const zip = makeZip("<w:p><w:r><w:t>See {{FIG}} below</w:t></w:r></w:p>");
    embedImages(zip, [image("FIG")]);
    expect(body(zip).replace(DRAWING, "[IMG]")).toBe(
      "<w:p><w:r><w:t>See </w:t></w:r><w:r>[IMG]</w:r><w:r><w:t> below</w:t></w:r></w:p>",
    );
  });

  it("leaves the document unchanged when the tag is absent", () => {
    const xml = "<w:p><w:r><w:t>No images here</w:t></w:r></w:p>";
    const zip = makeZip(xml);
    embedImages(zip, [image("FIG")]);
    expect(body(zip)).toBe(xml);
  });
});

// ---------------------------------------------------------------------------
// Drawing ids
// ---------------------------------------------------------------------------

describe("embedImages drawing ids", () => {
  it("assigns ids above any existing drawing, unique per image", () => {
    const zip = makeZip(
      '<w:p><w:r><w:drawing><wp:inline><wp:docPr id="7" name="logo"/></wp:inline></w:drawing></w:r></w:p>' +
        "<w:p><w:r><w:t>{{A}}</w:t></w:r></w:p>" +
        "<w:p><w:r><w:t>{{B}}</w:t></w:r></w:p>",
    );
    embedImages(zip, [image("A"), image("B")]);
    const ids = [...body(zip).matchAll(/<wp:docPr id="(\d+)"/g)].map((m) => Number(m[1]));
    expect(ids).toEqual([7, 8, 9]);
  });
});
