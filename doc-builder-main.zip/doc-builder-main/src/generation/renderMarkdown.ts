import { marked } from "marked";

/**
 * Convert a Markdown string to HTML using `marked`.
 * Runs synchronously — safe for use in render paths.
 *
 * NOTE: This produces raw HTML strings. For rendering in React components,
 * prefer `<ReactMarkdown>` which avoids dangerouslySetInnerHTML entirely.
 * This utility remains for non-DOM contexts (e.g. Word XML generation).
 */
export function renderMarkdown(markdown: string): string {
  return marked.parse(markdown, { async: false }) as string;
}
