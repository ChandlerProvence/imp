/**
 * Suite 2d: Round-trip integrity testing.
 *
 * Verifies that answers survive the generate -> extract text round-trip,
 * specifically checking formatted display values. This is a strengthened
 * version of the value-echo test from Suite 2c, focusing on:
 *
 * 1. Date fields appear in their display_format form
 * 2. Freetext content words survive markdown -> Word XML conversion
 * 3. Field values appear the correct number of times per template_key_map
 *
 * 4. LLM-gated: full round-trip extraction (skipped unless RUN_LLM_TESTS=true)
 */
import { describe, it, expect } from "vitest";
import { schemas } from "../schemas/loader";
import { renderDocxFromArrayBuffer } from "./generateDocx";
import {
  loadTemplateBuffer,
  extractDocxText,
  countOccurrences,
} from "../test/docx-test-utils";
import {
  loadAnswerFixture,
  generateSampleAnswers,
  resolveExpectedDisplayValue,
  extractContentWords,
  tkmDateFormatOverrides,
} from "../test/fixture-utils";
import type { DocumentSchema, FieldDef } from "../schemas/types";

// ---------------------------------------------------------------------------
// Collect schemas that have a docx_template
// ---------------------------------------------------------------------------

const docxSchemas: DocumentSchema[] = [];
for (const [, schema] of schemas) {
  if (schema.docx_template) docxSchemas.push(schema);
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Load answers: prefer hand-curated fixture, fall back to generated sample. */
function loadAnswers(
  schema: DocumentSchema,
): Record<string, string | number | boolean> {
  return loadAnswerFixture(schema.id) ?? generateSampleAnswers(schema);
}

/** Resolve a field definition from a "section_id.field_id" answer key. */
function getFieldDef(
  schema: DocumentSchema,
  answerKey: string,
): FieldDef | undefined {
  const [sectionId, fieldId] = answerKey.split(".");
  const section = schema.sections.find((s) => s.id === sectionId);
  return section?.fields.find((f) => f.id === fieldId);
}

// ---------------------------------------------------------------------------
// Pre-render all blobs (one per schema) so individual assertions are fast
// ---------------------------------------------------------------------------

const rendered = new Map<
  string,
  { blob: Blob; answers: Record<string, string | number | boolean> }
>();

for (const schema of docxSchemas) {
  const answers = loadAnswers(schema);
  const templateBuffer = loadTemplateBuffer(schema);
  const blob = renderDocxFromArrayBuffer(templateBuffer, schema, answers);
  rendered.set(schema.id, { blob, answers });
}

// ---------------------------------------------------------------------------
// Deterministic round-trip checks (CI)
// ---------------------------------------------------------------------------

describe("Suite 2d: Round-trip integrity", () => {
  describe.each(docxSchemas.map((s) => [s.id, s]))(
    "%s",
    (_id, schema) => {
      const s = schema as DocumentSchema;
      const entry = rendered.get(s.id)!;

      // 1. Date fields appear in their display_format form
      it("date fields appear in their display_format form", async () => {
        const text = await extractDocxText(entry.blob);

        // Collect ISO dates that live inside table cell data — table column
        // dates are not formatted by the pipeline, so skip them.
        const tableFieldKeys = new Set<string>();
        for (const section of s.sections) {
          for (const field of section.fields) {
            if (field.type === "table") {
              tableFieldKeys.add(`${section.id}.${field.id}`);
            }
          }
        }

        // A field may be rendered via multiple TKM entries, each with its
        // own date_format override (e.g. "long" in one spot, default
        // elsewhere) — any one of the resulting strings is an acceptable match.
        const dateFormatOverrides = tkmDateFormatOverrides(s);

        let checkedCount = 0;

        for (const section of s.sections) {
          for (const field of section.fields) {
            // Skip non-date fields
            if (field.type !== "date") continue;

            // Skip same_as and computed fields — they transform values
            if (field.same_as || field.formula !== undefined) continue;

            const key = `${section.id}.${field.id}`;
            const value = entry.answers[key];

            // Skip empty values
            if (value === undefined || value === null || value === "") continue;

            // Skip dates in table columns (covered by table field keys)
            if (tableFieldKeys.has(key)) continue;

            const formats = dateFormatOverrides.get(key) ?? new Set([undefined]);
            const candidates = Array.from(formats)
              .map((fmt) => resolveExpectedDisplayValue(field, value, fmt))
              .filter((s) => s !== "");
            if (candidates.length === 0) continue;

            checkedCount++;
            expect(
              candidates.some((c) => text.includes(c)),
              `Date field "${key}" should appear as one of [${candidates.map((c) => `"${c}"`).join(", ")}] in the document, but was not found`,
            ).toBe(true);
          }
        }

        // If no date fields were checkable, the test passes vacuously
        if (checkedCount === 0) return;
      });

      // 2. Freetext content words survive markdown -> Word XML conversion
      it("freetext content words survive markdown→Word XML conversion", async () => {
        const text = await extractDocxText(entry.blob);
        let checkedAnyField = false;

        for (const section of s.sections) {
          for (const field of section.fields) {
            if (field.type !== "freetext") continue;

            const key = `${section.id}.${field.id}`;
            const value = entry.answers[key];

            // Skip if the freetext value is empty
            if (value === undefined || value === null || value === "") continue;

            const words = extractContentWords(String(value));
            // Only check words >= 4 chars to avoid false positives from
            // short common words. Also skip words with XML special chars
            // (&, <, >) that get entity-encoded in Word XML and won't
            // match the plain text extraction.
            const significantWords = words.filter(
              (w) => w.length >= 4 && !/[&<>"']/.test(w),
            );

            if (significantWords.length === 0) continue;

            checkedAnyField = true;

            for (const word of significantWords) {
              expect(
                text.includes(word),
                `Freetext field "${key}": content word "${word}" should survive markdown→Word XML conversion but was not found in the extracted text`,
              ).toBe(true);
            }
          }
        }

        // If no freetext fields were checkable, the test passes vacuously
        if (!checkedAnyField) return;
      });

      // 3. Field values appear the correct number of times per template_key_map
      if (s.template_key_map) {
        it("field values appear the correct number of times per template_key_map", async () => {
          const text = await extractDocxText(entry.blob);

          // Build a map: field path -> count of TKM entries pointing to it
          const fieldOccurrenceCounts = new Map<string, number>();
          for (const [, mapping] of Object.entries(s.template_key_map!)) {
            const fieldPath =
              typeof mapping === "string" ? mapping : mapping.field;
            fieldOccurrenceCounts.set(
              fieldPath,
              (fieldOccurrenceCounts.get(fieldPath) ?? 0) + 1,
            );
          }

          for (const [fieldPath, expectedCount] of fieldOccurrenceCounts) {
            const fieldDef = getFieldDef(s, fieldPath);
            if (!fieldDef) continue;

            // Skip table, freetext, date, number, boolean, computed,
            // same_as fields — they transform values
            if (fieldDef.type === "table") continue;
            if (fieldDef.type === "freetext") continue;
            if (fieldDef.type === "date") continue;
            if (fieldDef.type === "number") continue;
            if (fieldDef.type === "boolean") continue;
            if (fieldDef.formula !== undefined) continue;
            if (fieldDef.same_as) continue;

            const value = entry.answers[fieldPath];
            if (value === undefined || value === null || value === "") continue;

            const stringValue = String(value);

            // Only check string values with length >= 4 to avoid false matches
            if (stringValue.length < 4) continue;

            const actual = countOccurrences(text, stringValue);
            expect(
              actual,
              `Field "${fieldPath}" (value="${stringValue}") should appear at least ${expectedCount} time(s) per TKM, but found ${actual} occurrence(s)`,
            ).toBeGreaterThanOrEqual(expectedCount);
          }
        });
      }
    },
  );
});

// ---------------------------------------------------------------------------
// LLM-gated round-trip tests (skipped in CI)
// ---------------------------------------------------------------------------

const RUN_LLM_TESTS = process.env.RUN_LLM_TESTS === "true";

describe.skipIf(!RUN_LLM_TESTS)("Suite 2d (LLM): Full round-trip", () => {
  it.todo("answers survive full LLM re-extraction round-trip");
});
