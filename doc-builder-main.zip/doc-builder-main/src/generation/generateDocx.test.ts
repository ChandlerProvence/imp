import { describe, it, expect } from "vitest";
import { buildReverseColumnMap } from "./generateDocx";
import type { DocumentSchema } from "../schemas/types";

/** Minimal schema factory for column-map tests. */
function makeSchema(opts: {
  templateKeyMap?: Record<string, string>;
  templateColumnMap?: Record<string, Record<string, string>>;
}): DocumentSchema {
  return {
    id: "test",
    title: "Test",
    version: 1,
    sections: [
      {
        id: "scope",
        title: "Scope",
        fields: [
          {
            id: "parts_list",
            label: "Parts",
            type: "table",
            required: true,
            columns: [
              { id: "nsn", label: "NSN", type: "string", required: true },
              { id: "noun", label: "Noun", type: "string", required: true },
              { id: "quantity", label: "Qty", type: "number", required: true },
            ],
          },
        ],
      },
    ],
    template_key_map: opts.templateKeyMap,
    template_column_map: opts.templateColumnMap,
  };
}

describe("buildReverseColumnMap", () => {
  it("returns undefined when no template_column_map is defined", () => {
    const schema = makeSchema({
      templateKeyMap: { PARTS_LIST: "scope.parts_list" },
    });
    expect(buildReverseColumnMap(schema, "PARTS_LIST")).toBeUndefined();
  });

  it("returns undefined when the tag has no entry in the column map", () => {
    const schema = makeSchema({
      templateKeyMap: { PARTS_LIST: "scope.parts_list" },
      templateColumnMap: { OTHER_TABLE: { FOO: "bar" } },
    });
    expect(buildReverseColumnMap(schema, "PARTS_LIST")).toBeUndefined();
  });

  it("returns reversed mapping (schema col ID → Word tag) when column map exists", () => {
    const schema = makeSchema({
      templateKeyMap: { PARTS_LIST: "scope.parts_list" },
      templateColumnMap: {
        PARTS_LIST: { NSN: "nsn", NOMENCLATURE: "noun" },
      },
    });
    const result = buildReverseColumnMap(schema, "PARTS_LIST");
    expect(result).toEqual({ nsn: "NSN", noun: "NOMENCLATURE" });
  });

  it("unmapped columns pass through unchanged", () => {
    const schema = makeSchema({
      templateKeyMap: { PARTS_LIST: "scope.parts_list" },
      templateColumnMap: {
        PARTS_LIST: { NSN: "nsn" }, // only nsn is remapped
      },
    });
    const reverseMap = buildReverseColumnMap(schema, "PARTS_LIST")!;
    // "noun" has no entry → should fall through
    expect(reverseMap["noun"]).toBeUndefined();
    expect(reverseMap["nsn"]).toBe("NSN");
    // Simulate the generation loop behavior:
    const row = { nsn: "1234", noun: "Motor", quantity: 2 };
    const formatted: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(row)) {
      const outputKey = reverseMap[k] ?? k;
      formatted[outputKey] = v;
    }
    expect(formatted).toEqual({ NSN: "1234", noun: "Motor", quantity: 2 });
  });
});

describe("table rows missing a column", () => {
  it("renders an optional missing column blank and keeps a required one's tag", async () => {
    const { renderDocxFromArrayBuffer } = await import("./generateDocx");
    const { buildDocx, para } = await import("../test/docxFixtures");
    const { extractDocxText } = await import("../test/docx-test-utils");
    const schema: DocumentSchema = {
      id: "test",
      title: "Test",
      version: 1,
      sections: [
        {
          id: "s",
          title: "S",
          fields: [
            {
              id: "rows",
              label: "Rows",
              type: "table",
              required: true,
              columns: [
                { id: "noun", label: "Noun", type: "string", required: true },
                { id: "nsn", label: "NSN", type: "string", required: true },
                { id: "status", label: "Status", type: "string", required: false },
              ],
            },
          ],
        },
      ],
      template_key_map: { R: "s.rows" },
    };
    const bytes = buildDocx(para("{{#R}}[{{noun}}|{{nsn}}|{{status}}]{{/R}}"));
    const buf = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
    const blob = renderDocxFromArrayBuffer(buf, schema, {
      "s.rows": JSON.stringify({ rows: [{ noun: "Widget" }] }),
    });
    const text = await extractDocxText(blob);
    expect(text).toContain("[Widget|{{nsn}}|]");
  });
});
