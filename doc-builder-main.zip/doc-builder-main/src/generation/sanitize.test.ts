import { describe, it, expect } from "vitest";
import { stripInvalidXmlChars, sanitizeDataForXml } from "./sanitize";

describe("stripInvalidXmlChars", () => {
  it("returns the same string when no invalid chars are present", () => {
    const input = "Hello, world! Tabs\tand newlines\nare fine.";
    expect(stripInvalidXmlChars(input)).toBe(input);
  });

  it("preserves tab (U+0009), newline (U+000A), and carriage return (U+000D)", () => {
    const input = "line1\tindented\nline2\r\nline3";
    expect(stripInvalidXmlChars(input)).toBe(input);
  });

  it("strips NULL (U+0000)", () => {
    expect(stripInvalidXmlChars("a\x00b")).toBe("ab");
  });

  it("strips SOH through BS (U+0001–U+0008)", () => {
    const input = "a\x01\x02\x03\x04\x05\x06\x07\x08b";
    expect(stripInvalidXmlChars(input)).toBe("ab");
  });

  it("strips VT (U+000B) and FF (U+000C)", () => {
    expect(stripInvalidXmlChars("a\x0Bb\x0Cc")).toBe("abc");
  });

  it("strips SO through US (U+000E–U+001F)", () => {
    let input = "start";
    for (let i = 0x0e; i <= 0x1f; i++) {
      input += String.fromCharCode(i);
    }
    input += "end";
    expect(stripInvalidXmlChars(input)).toBe("startend");
  });

  it("strips multiple invalid chars scattered throughout a string", () => {
    const input = "Name:\x1C John\x1E Doe\x00";
    expect(stripInvalidXmlChars(input)).toBe("Name: John Doe");
  });

  it("handles empty string", () => {
    expect(stripInvalidXmlChars("")).toBe("");
  });

  it("handles string that is entirely invalid chars", () => {
    expect(stripInvalidXmlChars("\x00\x01\x02\x03")).toBe("");
  });

  it("preserves Unicode and special characters above U+001F", () => {
    const input = "Ünîcödé — «quotes» ™ © 🎉";
    expect(stripInvalidXmlChars(input)).toBe(input);
  });
});

describe("sanitizeDataForXml", () => {
  it("sanitizes string values in a flat data object", () => {
    const data = {
      NAME: "Hello\x00World",
      CLEAN: "No issues here",
    };
    const result = sanitizeDataForXml(data);
    expect(result.NAME).toBe("HelloWorld");
    expect(result.CLEAN).toBe("No issues here");
  });

  it("sanitizes string values in table row arrays", () => {
    const data: Record<
      string,
      string | Record<string, string | number | boolean>[]
    > = {
      ITEMS: [
        { col1: "a\x01b", col2: 42, col3: true },
        { col1: "clean", col2: 0, col3: false },
      ],
    };
    const result = sanitizeDataForXml(data);
    const rows = result.ITEMS as Record<string, string | number | boolean>[];
    expect(rows[0].col1).toBe("ab");
    expect(rows[0].col2).toBe(42);
    expect(rows[0].col3).toBe(true);
    expect(rows[1].col1).toBe("clean");
  });

  it("does not mutate the original data object", () => {
    const original: Record<
      string,
      string | Record<string, string | number | boolean>[]
    > = {
      NAME: "test\x00value",
      TABLE: [{ cell: "a\x01b" }],
    };
    sanitizeDataForXml(original);
    expect(original.NAME).toBe("test\x00value");
    expect((original.TABLE as Record<string, string>[])[0].cell).toBe(
      "a\x01b",
    );
  });

  it("handles empty data object", () => {
    expect(sanitizeDataForXml({})).toEqual({});
  });

  it("preserves empty string values", () => {
    const data = { EMPTY: "" };
    const result = sanitizeDataForXml(data);
    expect(result.EMPTY).toBe("");
  });

  it("passes boolean values through unchanged (content_blocks)", () => {
    const data: Record<
      string,
      string | boolean | Record<string, string | number | boolean>[]
    > = {
      SHOW_SECTION: true,
      HIDE_SECTION: false,
      NAME: "Alice",
    };
    const result = sanitizeDataForXml(data);
    expect(result.SHOW_SECTION).toBe(true);
    expect(result.HIDE_SECTION).toBe(false);
    expect(result.NAME).toBe("Alice");
  });
});
