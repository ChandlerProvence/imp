import { describe, it, expect } from "vitest";
import { schemas } from "../schemas/loader";
import { setDefs } from "../schemas/sets";
import { mergeSetSchemas, resolveAliasedAnswers } from "../schemas/mergeSet";
import { renderDocxFromArrayBuffer } from "./generateDocx";
import { loadTemplateBuffer, extractDocxText } from "../test/docx-test-utils";
import { loadAnswerFixture, generateSampleAnswers } from "../test/fixture-utils";
import { resolveEffectiveAnswers } from "../engine/effectiveAnswers";
import { buildCalcGraph, resolveAggregate, resolveName, type FormulaNode } from "../engine/formula";
import { parseTableData } from "../engine/tableData";
import { toNumber } from "../engine/validation/coerce";
import { discoverDateOrderingPairs } from "../test/schema-invariant-utils";
import type { DocumentSchema } from "../schemas/types";

// ---------------------------------------------------------------------------
// Shared setup
// ---------------------------------------------------------------------------

const docxSchemas: DocumentSchema[] = [];
for (const [, schema] of schemas) {
  if (schema.docx_template) docxSchemas.push(schema);
}

function loadAnswers(schema: DocumentSchema) {
  return loadAnswerFixture(schema.id) ?? generateSampleAnswers(schema);
}

// ---------------------------------------------------------------------------
// Suite 3a: Formula field math verification
// ---------------------------------------------------------------------------

/** Independent recursive evaluator over the AST, for checking the engine. */
function recompute(
  schema: DocumentSchema,
  key: string,
  answers: Record<string, string | number | boolean>,
  seen = new Set<string>(),
): number | null {
  const graph = buildCalcGraph(schema);
  const node = graph.nodes.get(key);
  // `seen` holds the current path only, so shared inputs (a diamond) still resolve
  if (!node || node.kind !== "field" || !node.ast || seen.has(key)) return null;
  const path = new Set(seen).add(key);
  const filled = resolveEffectiveAnswers(schema, answers).answers;
  const walk = (n: FormulaNode): number | null => {
    switch (n.type) {
      case "number":
        return n.value;
      case "name": {
        const r = resolveName(graph.index, node.place, n.name);
        if (!r.ok) return null;
        if (r.target.kind === "constant") return r.target.value;
        if (r.target.kind !== "field") return null;
        return graph.nodes.has(r.target.key)
          ? recompute(schema, r.target.key, answers, path)
          : toNumber(filled[r.target.key]);
      }
      case "aggregate": {
        const r = resolveAggregate(graph.index, node.place, n);
        if (!r.ok) return null;
        const rows = parseTableData(filled[r.target.key]).rows;
        if (rows.length === 0) return null;
        if (n.name === "COUNT") return r.target.column ? rows.filter((x) => String(x[r.target.column!.id] ?? "") !== "").length : rows.length;
        const vals = rows.map((x) => toNumber(x[r.target.column!.id])).filter((v): v is number => v !== null);
        if (vals.length === 0) return null;
        if (n.name === "SUM") return vals.reduce((x, y) => x + y, 0);
        if (n.name === "AVG") return vals.reduce((x, y) => x + y, 0) / vals.length;
        return n.name === "MIN" ? Math.min(...vals) : Math.max(...vals);
      }
      case "binary": {
        const l = walk(n.left);
        const r = walk(n.right);
        if (l === null || r === null) return null;
        if (n.op === "/" && r === 0) return null;
        const v = n.op === "+" ? l + r : n.op === "-" ? l - r : n.op === "*" ? l * r : n.op === "/" ? l / r : l ** r;
        return Number.isFinite(v) ? v : null;
      }
      case "call": {
        if (n.name === "ABS") {
          const v = walk(n.args[0]);
          return v === null ? null : Math.abs(v);
        }
        for (const arg of n.args) {
          const v = walk(arg);
          if (v !== null) return v;
        }
        return null;
      }
    }
  };
  return walk(node.ast);
}

describe("Suite 3a: Formula field math verification", () => {
  const withFormulas = docxSchemas.filter((s) => s.sections.some((sec) => sec.fields.some((f) => f.formula !== undefined)));

  describe.each(withFormulas.map((s) => [s.id, s]))("%s", (_id, schema) => {
    const s = schema as DocumentSchema;
    const answers = loadAnswers(s);

    it("formula field values match an independent recalculation", () => {
      const { computed } = resolveEffectiveAnswers(s, answers);
      for (const [key, value] of Object.entries(computed)) {
        const independent = recompute(s, key, answers);
        if (value === null || independent === null) {
          expect(value, `${key}: engine and recalculation disagree on null`).toBe(independent);
          continue;
        }
        // Currency results are rounded to cents by the engine
        expect(value, `${key}: expected ${independent}, got ${value}`).toBeCloseTo(independent, 2);
      }
    });
  });
});

// ---------------------------------------------------------------------------
// Suite 3b: Date ordering constraints
// ---------------------------------------------------------------------------

describe("Suite 3b: Date ordering constraints", () => {
  describe.each(docxSchemas.map(s => [s.id, s]))("%s", (_id, schema) => {
    const s = schema as DocumentSchema;
    const answers = loadAnswers(s);
    const pairs = discoverDateOrderingPairs(s);

    // Only run if there are discoverable date ordering pairs
    if (pairs.length === 0) {
      it("no date ordering constraints to verify", () => {
        // Intentionally empty — no constraints discovered
      });
      return;
    }

    it("date pairs satisfy chronological ordering", () => {
      for (const { earlier, later, reason } of pairs) {
        const d1 = answers[earlier];
        const d2 = answers[later];
        if (!d1 || !d2) continue; // Skip if either missing

        const t1 = new Date(String(d1) + "T00:00:00Z").getTime();
        const t2 = new Date(String(d2) + "T00:00:00Z").getTime();

        // Skip if either date is invalid
        if (isNaN(t1) || isNaN(t2)) continue;

        expect(
          t1,
          `${reason}: "${earlier}" (${d1}) should be ≤ "${later}" (${d2})`
        ).toBeLessThanOrEqual(t2);
      }
    });
  });
});

// ---------------------------------------------------------------------------
// Suite 3c: Cross-schema field consistency within sets
// ---------------------------------------------------------------------------

describe("Suite 3c: Cross-schema field consistency within sets", () => {
  for (const setDef of setDefs) {
    describe(`set: ${setDef.id}`, () => {
      // Get member schemas that have docx_templates
      const memberSchemas = setDef.schemas
        .map(id => schemas.get(id))
        .filter((s): s is DocumentSchema => s !== undefined && s.docx_template !== undefined);

      if (memberSchemas.length < 2) {
        it("fewer than 2 renderable schemas — skipping cross-check", () => {});
        return;
      }

      it("shared scalar fields produce identical values across schemas", async () => {
        // Merge schemas to find shared fields
        const merged = mergeSetSchemas(memberSchemas, setDef.id);

        // Generate answers from the merged schema
        const mergedAnswers = generateSampleAnswers(merged.schema);

        // Find shared scalar fields (in fieldUsage with >1 schema)
        const sharedFields: string[] = [];
        for (const [fieldKey, schemaIds] of merged.fieldUsage) {
          if (schemaIds.length < 2) continue;
          // Only check scalar string/enum fields (most reliable for text comparison)
          const [sectionId, fieldId] = fieldKey.split(".");
          const section = merged.schema.sections.find(s => s.id === sectionId);
          const field = section?.fields.find(f => f.id === fieldId);
          if (!field) continue;
          if (field.type !== "string" && field.type !== "enum") continue;
          if (field.same_as || field.formula !== undefined) continue;
          const value = mergedAnswers[fieldKey];
          if (!value || String(value).length < 3) continue;
          sharedFields.push(fieldKey);
        }

        if (sharedFields.length === 0) return; // No shared scalar fields to check

        // Render each member schema and check shared fields appear
        const mismatches: string[] = [];
        for (const memberSchema of memberSchemas) {
          // Resolve answers for this specific schema (handle table aliases)
          const schemaAnswers = merged.tableAliases.has(memberSchema.id)
            ? resolveAliasedAnswers(memberSchema.id, mergedAnswers, merged.tableAliases)
            : { ...mergedAnswers };

          const buffer = loadTemplateBuffer(memberSchema);
          const blob = renderDocxFromArrayBuffer(buffer, memberSchema, schemaAnswers);
          const text = await extractDocxText(blob);

          for (const fieldKey of sharedFields) {
            // Only check if this member schema actually maps this field
            // in its template_key_map (a field can be shared for data entry
            // but only appear in some schemas' templates)
            const tkm = memberSchema.template_key_map;
            if (!tkm) continue;
            const fieldMapped = Object.values(tkm).some((mapping) => {
              const path = typeof mapping === "string" ? mapping : mapping.field;
              return path === fieldKey;
            });
            if (!fieldMapped) continue;

            const value = String(mergedAnswers[fieldKey]);
            if (!text.includes(value)) {
              mismatches.push(
                `"${fieldKey}" = "${value}" missing from ${memberSchema.id}`
              );
            }
          }
        }

        expect(
          mismatches,
          `Shared fields with inconsistent rendering: ${mismatches.join("; ")}`
        ).toEqual([]);
      });
    });
  }
});
