import { describe, it, expect } from "vitest";
import { updateTableOfContents } from "./tocUpdate";
import type { TocConfig } from "../schemas/types";

// ---------------------------------------------------------------------------
// Test helpers: build minimal Word XML documents
// ---------------------------------------------------------------------------

/** Build a heading paragraph with the given style and text. */
function h(style: string, text: string): string {
  return (
    `<w:p><w:pPr><w:pStyle w:val="${style}"/></w:pPr>` +
    `<w:r><w:t>${text}</w:t></w:r></w:p>`
  );
}

/** Build a plain body paragraph (no heading style). */
function p(text: string, style = "LeidosBody"): string {
  return (
    `<w:p><w:pPr><w:pStyle w:val="${style}"/></w:pPr>` +
    `<w:r><w:t>${text}</w:t></w:r></w:p>`
  );
}

/** Build a minimal document.xml with the given paragraph elements. */
function doc(...paras: string[]): string {
  return (
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<w:document><w:body>${paras.join("")}</w:body></w:document>`
  );
}

/** Extract TOC-styled paragraph texts from rendered XML. */
function extractTocEntries(xml: string): Array<{ style: string; text: string }> {
  const entries: Array<{ style: string; text: string }> = [];
  const pRegex = /<w:p[\s>][\s\S]*?<\/w:p>/g;
  const styleRegex = /<w:pStyle\s+w:val="(TOC\d+)"\s*\/>/;
  const tRegex = /<w:t(?:\s[^>]*)?(?<!\/)>([\s\S]*?)<\/w:t>/g;
  let match: RegExpExecArray | null;
  while ((match = pRegex.exec(xml)) !== null) {
    const paraXml = match[0];
    const styleMatch = styleRegex.exec(paraXml);
    if (!styleMatch) continue;
    let text = "";
    let tMatch: RegExpExecArray | null;
    tRegex.lastIndex = 0;
    while ((tMatch = tRegex.exec(paraXml)) !== null) {
      text += tMatch[1];
    }
    entries.push({ style: styleMatch[1], text });
  }
  return entries;
}

// ---------------------------------------------------------------------------
// Default config used in most tests
// ---------------------------------------------------------------------------

const DEFAULT_CONFIG: TocConfig = {
  heading_text: "Table of Contents",
  max_depth: 3,
  exclude_texts: ["Table of Contents", "List of Tables", "List of Figures"],
};

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe("updateTableOfContents", () => {
  it("returns XML unchanged when TOC heading is not found", () => {
    const xml = doc(
      h("Heading1", "1 Introduction"),
      p("Some body text."),
    );
    const result = updateTableOfContents(xml, DEFAULT_CONFIG);
    expect(result).toBe(xml);
  });

  it("replaces static TOC entries with headings from the body", () => {
    const xml = doc(
      h("Heading1NoNumbers", "Table of Contents"),
      p("1 Introduction"),
      p("2 Strategy"),
      h("Heading1NoNumbers", "1 Introduction"),
      p("Body paragraph under intro."),
      h("Heading1NoNumbers", "2 Strategy"),
      p("Body paragraph under strategy."),
    );

    const result = updateTableOfContents(xml, DEFAULT_CONFIG);
    const toc = extractTocEntries(result);

    expect(toc).toEqual([
      { style: "TOC1", text: "1 Introduction" },
      { style: "TOC1", text: "2 Strategy" },
    ]);
  });

  it("includes headings at multiple depths", () => {
    const xml = doc(
      h("Heading1NoNumbers", "Table of Contents"),
      p("Old TOC entry 1"),
      p("Old TOC entry 2"),
      h("Heading1NoNumbers", "1 Introduction"),
      p("Body text."),
      h("Heading2Manual", "1.1 Background"),
      p("More text."),
      h("Heading3Manual", "1.1.1 Details"),
      p("Even more text."),
    );

    const result = updateTableOfContents(xml, DEFAULT_CONFIG);
    const toc = extractTocEntries(result);

    expect(toc).toEqual([
      { style: "TOC1", text: "1 Introduction" },
      { style: "TOC2", text: "1.1 Background" },
      { style: "TOC3", text: "1.1.1 Details" },
    ]);
  });

  it("respects max_depth and excludes deeper headings", () => {
    const xml = doc(
      h("Heading1NoNumbers", "Table of Contents"),
      p("Old entry"),
      h("Heading1NoNumbers", "1 Introduction"),
      h("Heading2Manual", "1.1 Background"),
      h("Heading3Manual", "1.1.1 Details"),
      h("Heading4Manual", "1.1.1.1 Sub-details"),
    );

    const config: TocConfig = { ...DEFAULT_CONFIG, max_depth: 2 };
    const result = updateTableOfContents(xml, config);
    const toc = extractTocEntries(result);

    expect(toc).toEqual([
      { style: "TOC1", text: "1 Introduction" },
      { style: "TOC2", text: "1.1 Background" },
    ]);
    // Heading3 and Heading4 should not appear
    expect(toc).not.toContainEqual(expect.objectContaining({ text: "1.1.1 Details" }));
  });

  it("respects exclude_texts", () => {
    const xml = doc(
      h("Heading1NoNumbers", "Table of Contents"),
      p("Old entry"),
      h("Heading1NoNumbers", "List of Tables"),
      p("Table of tables entries..."),
      h("Heading1NoNumbers", "List of Figures"),
      p("Figure entries..."),
      h("Heading1NoNumbers", "1 Introduction"),
      p("Body text."),
    );

    const result = updateTableOfContents(xml, DEFAULT_CONFIG);
    const toc = extractTocEntries(result);

    // Only "1 Introduction" should appear — the others are excluded
    expect(toc).toEqual([
      { style: "TOC1", text: "1 Introduction" },
    ]);
  });

  it("uses correct TOC styles for each heading level", () => {
    const xml = doc(
      h("Heading1NoNumbers", "Table of Contents"),
      p("Old entry"),
      h("Heading1NoNumbers", "Section 1"),
      h("Heading2Manual", "Section 1.1"),
      h("Heading3Manual", "Section 1.1.1"),
    );

    const result = updateTableOfContents(xml, DEFAULT_CONFIG);
    const toc = extractTocEntries(result);

    expect(toc[0].style).toBe("TOC1");
    expect(toc[1].style).toBe("TOC2");
    expect(toc[2].style).toBe("TOC3");
  });

  it("supports custom toc_style_map", () => {
    const xml = doc(
      h("Heading1NoNumbers", "Table of Contents"),
      p("Old entry"),
      h("Heading1NoNumbers", "Section 1"),
      h("Heading2Manual", "Section 1.1"),
    );

    const config: TocConfig = {
      ...DEFAULT_CONFIG,
      toc_style_map: { 1: "CustomTOC1", 2: "CustomTOC2" },
    };

    const result = updateTableOfContents(xml, config);
    const toc = extractTocEntries(result);

    // Custom styles won't match our "TOC\d+" regex, so check raw XML
    expect(result).toContain('w:pStyle w:val="CustomTOC1"');
    expect(result).toContain('w:pStyle w:val="CustomTOC2"');
    // Standard TOC styles should NOT appear
    expect(toc).toHaveLength(0); // extractTocEntries only matches TOC\d
  });

  it("handles XML-entity text in headings", () => {
    const xml = doc(
      h("Heading1NoNumbers", "Table of Contents"),
      p("Old entry"),
      h("Heading1NoNumbers", "4.2 PHS&amp;T Planning"),
    );

    const result = updateTableOfContents(xml, DEFAULT_CONFIG);
    const toc = extractTocEntries(result);

    // The TOC entry text should contain the properly escaped ampersand
    expect(toc).toHaveLength(1);
    expect(toc[0].text).toContain("PHS&amp;T Planning");
  });

  it("preserves the TOC heading paragraph itself", () => {
    const tocHeading = h("Heading1NoNumbers", "Table of Contents");
    const xml = doc(
      tocHeading,
      p("Old TOC entry"),
      h("Heading1NoNumbers", "1 Introduction"),
    );

    const result = updateTableOfContents(xml, DEFAULT_CONFIG);

    // The TOC heading should still be present
    expect(result).toContain(">Table of Contents<");
    expect(result).toContain('w:pStyle w:val="Heading1NoNumbers"');
  });

  it("preserves all body content after the TOC section", () => {
    const bodyContent = '<w:p><w:r><w:t>Important body text SENTINEL</w:t></w:r></w:p>';
    const xml = doc(
      h("Heading1NoNumbers", "Table of Contents"),
      p("Old TOC entry 1"),
      p("Old TOC entry 2"),
      h("Heading1NoNumbers", "1 Introduction"),
      bodyContent,
    );

    const result = updateTableOfContents(xml, DEFAULT_CONFIG);

    // Body content must be preserved exactly
    expect(result).toContain("Important body text SENTINEL");
    // Old TOC entries should be gone
    expect(result).not.toContain("Old TOC entry 1");
    expect(result).not.toContain("Old TOC entry 2");
  });

  it("picks up AI-injected headings from rawXml", () => {
    // Simulate headings injected by markdownToWordXml via rawXml ({@TAG})
    const aiHeading =
      `<w:p><w:pPr><w:pStyle w:val="Heading3Manual"/></w:pPr>` +
      `<w:r><w:t xml:space="preserve">3.1.1 AI-Generated Sub-heading</w:t></w:r></w:p>`;

    const xml = doc(
      h("Heading1NoNumbers", "Table of Contents"),
      p("Old entry"),
      h("Heading1NoNumbers", "3 Performance"),
      h("Heading2Manual", "3.1 Requirements"),
      aiHeading,
      p("AI-drafted content under the heading."),
    );

    const result = updateTableOfContents(xml, DEFAULT_CONFIG);
    const toc = extractTocEntries(result);

    expect(toc).toEqual([
      { style: "TOC1", text: "3 Performance" },
      { style: "TOC2", text: "3.1 Requirements" },
      { style: "TOC3", text: "3.1.1 AI-Generated Sub-heading" },
    ]);
  });

  it("produces an empty TOC when no headings exist after the TOC section", () => {
    const xml = doc(
      h("Heading1NoNumbers", "Table of Contents"),
      p("Old TOC entry"),
      // No heading after TOC — just body paragraphs (unusual but defensive)
      p("Some random text."),
    );

    const result = updateTableOfContents(xml, DEFAULT_CONFIG);
    const toc = extractTocEntries(result);

    expect(toc).toHaveLength(0);
    // Old TOC entry should be removed
    expect(result).not.toContain("Old TOC entry");
  });

  it("defaults max_depth to 3 when not specified", () => {
    const xml = doc(
      h("Heading1NoNumbers", "Table of Contents"),
      p("Old entry"),
      h("Heading1NoNumbers", "Section 1"),
      h("Heading2Manual", "Section 1.1"),
      h("Heading3Manual", "Section 1.1.1"),
      h("Heading4Manual", "Section 1.1.1.1"),
    );

    const config: TocConfig = { heading_text: "Table of Contents" };
    const result = updateTableOfContents(xml, config);
    const toc = extractTocEntries(result);

    expect(toc).toHaveLength(3);
    expect(toc.map((t) => t.text)).toEqual([
      "Section 1",
      "Section 1.1",
      "Section 1.1.1",
    ]);
  });

  it("handles headings with text split across multiple <w:t> runs", () => {
    // Word XML often splits text across multiple runs due to formatting changes
    const splitHeading =
      `<w:p><w:pPr><w:pStyle w:val="Heading2Manual"/></w:pPr>` +
      `<w:r><w:t>3.1 Performance </w:t></w:r>` +
      `<w:r><w:rPr><w:b/></w:rPr><w:t>Requirements</w:t></w:r></w:p>`;

    const xml = doc(
      h("Heading1NoNumbers", "Table of Contents"),
      p("Old entry"),
      h("Heading1NoNumbers", "3 Performance"),
      splitHeading,
    );

    const result = updateTableOfContents(xml, DEFAULT_CONFIG);
    const toc = extractTocEntries(result);

    expect(toc).toContainEqual(
      expect.objectContaining({ text: "3.1 Performance Requirements" }),
    );
  });
});
