import type { TocConfig } from "../schemas/types";

// ─── Regex patterns ─────────────────────────────────────────────────────────
// Match patterns consistent with src/test/docx-test-utils.ts (lines 134-136).

/** Matches a single `<w:p>` element (including nested runs, etc.). */
const P_REGEX = /<w:p[\s>][\s\S]*?<\/w:p>/g;

/** Detects heading styles and captures the numeric depth. */
const HEADING_REGEX = /<w:pStyle\s+w:val="Heading(\d)\w*"\s*\/>/;

/** Extracts text content from `<w:t>` elements. */
const TEXT_REGEX = /<w:t(?:\s[^>]*)?(?<!\/)>([\s\S]*?)<\/w:t>/g;

// ─── Helpers ────────────────────────────────────────────────────────────────

/** Extract the full text content of a `<w:p>` element. */
function extractParagraphText(paraXml: string): string {
  let text = "";
  for (const match of paraXml.matchAll(TEXT_REGEX)) {
    text += match[1];
  }
  return decodeXmlEntities(text);
}

/** Decode common XML entities to plain text. */
function decodeXmlEntities(s: string): string {
  return s
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'");
}

/** Escape text for safe inclusion in Word XML. */
function escapeXml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/** Get the heading depth (1–9) from a paragraph, or null if not a heading. */
function getHeadingLevel(paraXml: string): number | null {
  const match = HEADING_REGEX.exec(paraXml);
  return match ? parseInt(match[1], 10) : null;
}

/** Check if a paragraph has any paragraph style set. */
function hasHeadingStyle(paraXml: string): boolean {
  return HEADING_REGEX.test(paraXml);
}

/** Resolve the TOC paragraph style for a heading at the given depth. */
function resolveTocStyle(
  level: number,
  styleMap?: Record<number, string>,
): string {
  return styleMap?.[level] ?? `TOC${level}`;
}

/** Build a TOC entry `<w:p>` element for a heading. */
function buildTocEntry(
  text: string,
  level: number,
  styleMap?: Record<number, string>,
): string {
  const style = resolveTocStyle(level, styleMap);
  return (
    `<w:p><w:pPr><w:pStyle w:val="${style}"/></w:pPr>` +
    `<w:r><w:t xml:space="preserve">${escapeXml(text)}</w:t></w:r></w:p>`
  );
}

// ─── Public API ─────────────────────────────────────────────────────────────

/** A heading entry extracted from the document body. */
export interface TocHeadingEntry {
  level: number;
  text: string;
}

/**
 * Scan the rendered `word/document.xml` for heading paragraphs and replace
 * the static TOC section with dynamically generated TOC entries.
 *
 * The function locates the TOC section by finding the heading paragraph whose
 * text matches `tocConfig.heading_text`, then replaces all paragraphs between
 * that heading and the next heading-styled paragraph with new TOC entries
 * derived from the document's actual heading structure.
 *
 * Returns the XML unchanged (no-op) if the TOC heading is not found.
 */
export function updateTableOfContents(
  documentXml: string,
  tocConfig: TocConfig,
): string {
  const maxDepth = tocConfig.max_depth ?? 3;
  const excludeTexts = new Set(tocConfig.exclude_texts ?? []);

  // ── Step 1: Find all paragraphs and their positions ───────────────────
  const paragraphs: Array<{
    xml: string;
    start: number;
    end: number;
  }> = [];
  for (const match of documentXml.matchAll(P_REGEX)) {
    paragraphs.push({
      xml: match[0],
      start: match.index,
      end: match.index + match[0].length,
    });
  }

  // ── Step 2: Locate the TOC heading paragraph ──────────────────────────
  let tocHeadingIdx = -1;
  for (let i = 0; i < paragraphs.length; i++) {
    const p = paragraphs[i];
    if (!hasHeadingStyle(p.xml)) continue;
    const text = extractParagraphText(p.xml);
    if (text.trim() === tocConfig.heading_text) {
      tocHeadingIdx = i;
      break;
    }
  }

  if (tocHeadingIdx === -1) {
    // TOC heading not found — return unchanged
    return documentXml;
  }

  // ── Step 3: Find the TOC entry range ──────────────────────────────────
  // TOC entries are all paragraphs after the TOC heading until the next
  // heading-styled paragraph.
  const tocEntriesStart = tocHeadingIdx + 1;
  let tocEntriesEnd = paragraphs.length; // default: end of document
  for (let i = tocEntriesStart; i < paragraphs.length; i++) {
    if (hasHeadingStyle(paragraphs[i].xml)) {
      tocEntriesEnd = i;
      break;
    }
  }

  // ── Step 4: Collect headings from the document body ───────────────────
  // Start scanning from the end of the TOC section onwards.
  const headings: TocHeadingEntry[] = [];
  for (let i = tocEntriesEnd; i < paragraphs.length; i++) {
    const level = getHeadingLevel(paragraphs[i].xml);
    if (level === null) continue;
    if (level > maxDepth) continue;
    const text = extractParagraphText(paragraphs[i].xml).trim();
    if (!text) continue;
    if (excludeTexts.has(text)) continue;
    headings.push({ level, text });
  }

  // ── Step 5: Build replacement TOC entries ─────────────────────────────
  const newTocXml = headings
    .map((h) => buildTocEntry(h.text, h.level, tocConfig.toc_style_map))
    .join("");

  // ── Step 6: Splice into the document XML ──────────────────────────────
  // Replace everything between the end of the TOC heading paragraph and
  // the start of the next heading paragraph (the TOC entry range).
  const spliceStart = paragraphs[tocHeadingIdx].end;
  const spliceEnd =
    tocEntriesEnd < paragraphs.length
      ? paragraphs[tocEntriesEnd].start
      : paragraphs[paragraphs.length - 1].end;

  return (
    documentXml.slice(0, spliceStart) +
    newTocXml +
    documentXml.slice(spliceEnd)
  );
}
