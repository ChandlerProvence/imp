import { describe, it, expect } from "vitest";
import { resolveOutputFilename } from "./resolveOutputFilename";
import type { DocumentSchema } from "../schemas/types";

/** Minimal schema factory for tests. */
function makeSchema(overrides: Partial<DocumentSchema> = {}): DocumentSchema {
  return {
    id: "test",
    title: "Test Schema – Title!",
    version: 1,
    sections: [],
    ...overrides,
  };
}

describe("resolveOutputFilename", () => {
  it("falls back to sanitized schema.title when output_filename is undefined", () => {
    const schema = makeSchema({ title: "FMS TT&E – Task Order Award" });
    const result = resolveOutputFilename(schema, {});
    expect(result).toBe("FMS TTE  Task Order Award");
  });

  it("substitutes all placeholders with matching answer values", () => {
    const schema = makeSchema({
      output_filename:
        "TO - {{header.idiq_number}} - Rls. {{header.to_release_num}} - {{header.subcontractor_name}} - TT&E",
    });
    const answers = {
      "header.idiq_number": "P010333366",
      "header.to_release_num": "133",
      "header.subcontractor_name": "Acme Corp",
    };
    const result = resolveOutputFilename(schema, answers);
    expect(result).toBe("TO - P010333366 - Rls. 133 - Acme Corp - TT&E");
  });

  it("replaces missing values with DRAFT", () => {
    const schema = makeSchema({
      output_filename: "Price Reasonableness Memo for {{header.idiq_number}} R{{header.to_release_num}} - TT&E",
    });
    const result = resolveOutputFilename(schema, {});
    expect(result).toBe("Price Reasonableness Memo for DRAFT RDRAFT - TT&E");
  });

  it("replaces empty string values with DRAFT", () => {
    const schema = makeSchema({
      output_filename: "Doc - {{header.name}}",
    });
    const answers = { "header.name": "" };
    const result = resolveOutputFilename(schema, answers);
    expect(result).toBe("Doc - DRAFT");
  });

  it("handles mixed present and missing values", () => {
    const schema = makeSchema({
      output_filename: "{{a.one}} - {{a.two}} - {{a.three}}",
    });
    const answers = { "a.one": "Hello", "a.three": "World" };
    const result = resolveOutputFilename(schema, answers);
    expect(result).toBe("Hello - DRAFT - World");
  });

  it("converts numeric values to string", () => {
    const schema = makeSchema({
      output_filename: "Release {{header.num}}",
    });
    const answers = { "header.num": 42 };
    const result = resolveOutputFilename(schema, answers);
    expect(result).toBe("Release 42");
  });

  it("strips filesystem-unsafe characters from the resolved name", () => {
    const schema = makeSchema({
      output_filename: "File: {{a.name}}",
    });
    const answers = { "a.name": 'bad<>:"/\\|?*chars' };
    const result = resolveOutputFilename(schema, answers);
    expect(result).toBe("File badchars");
  });

  it("trims leading and trailing whitespace", () => {
    const schema = makeSchema({
      output_filename: "  {{a.val}}  ",
    });
    const answers = { "a.val": "trimmed" };
    const result = resolveOutputFilename(schema, answers);
    expect(result).toBe("trimmed");
  });

  it("handles placeholder keys with extra whitespace", () => {
    const schema = makeSchema({
      output_filename: "{{ header.name }}",
    });
    const answers = { "header.name": "Test" };
    const result = resolveOutputFilename(schema, answers);
    expect(result).toBe("Test");
  });

  it("strips commas from the resolved filename", () => {
    const schema = makeSchema({
      output_filename: "Proposal {{header.catena_num}}",
    });
    const answers = { "header.catena_num": "C2A.123, C2B.456" };
    const result = resolveOutputFilename(schema, answers);
    expect(result).toBe("Proposal C2A.123 C2B.456");
  });
});
