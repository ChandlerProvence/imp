import type { DocumentSchema } from "../schemas/types";

/**
 * Resolve the output filename for a schema given the current answers.
 *
 * If the schema defines `output_filename`, substitutes `{{section_id.field_id}}`
 * placeholders with answer values. Unresolved placeholders become "DRAFT".
 * The result is sanitized for filesystem safety.
 *
 * If `output_filename` is not defined, falls back to sanitized `schema.title`.
 *
 * Returns the filename WITHOUT extension — callers append `.docx` or `.md`.
 */
export function resolveOutputFilename(
  schema: DocumentSchema,
  answers: Record<string, string | number | boolean>,
): string {
  if (!schema.output_filename) {
    return schema.title.replace(/[^a-zA-Z0-9 -]/g, "").trim();
  }

  const resolved = schema.output_filename.replace(
    /\{\{([^}]+)\}\}/g,
    (_match, key: string) => {
      const trimmedKey = key.trim();
      const value = answers[trimmedKey];
      if (value === undefined || value === null || value === "") {
        return "DRAFT";
      }
      return String(value);
    },
  );

  // Strip characters invalid or awkward in filenames on Windows/macOS/Linux
  return resolved
    .replace(/,/g, "")
    .replace(/[<>:"/\\|?*\x00-\x1f]/g, "")
    .trim();
}
