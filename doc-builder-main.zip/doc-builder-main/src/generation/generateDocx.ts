import Docxtemplater from "docxtemplater";
import PizZip from "pizzip";
import type { DocumentSchema, FieldDef } from "../schemas/types";
import { parseTableData } from "../engine/tableData";
import { formatCalculated, formatNumberForTemplate } from "../engine/formula/format";
import { resolveEffectiveAnswers } from "../engine/effectiveAnswers";
import { sanitizeDataForXml } from "./sanitize";
import { resolveOutputFilename } from "./resolveOutputFilename";
import { markdownToWordXml, type MarkdownToWordXmlOptions } from "./markdownToWordXml";
import { updateTableOfContents } from "./tocUpdate";
import { isFieldRequired } from "../engine/fieldLookup";
import { formatDateForDisplay, type DateDisplayFormat } from "../utils/dateFormat";
import { embedImages, prepareImageData, type ImageData } from "./imageEmbed";
import { isImageSentinel } from "../components/ImageField";
import { appErrorException } from "../errors";

/**
 * Load the .docx template, substitute placeholder tags with interview answers,
 * and return the filled document as a Blob.
 *
 * Table fields are passed as arrays of row objects so Docxtemplater can
 * loop over them using its native `{#TAG}{col}{/TAG}` syntax.
 */
export async function generateDocxBlob(
  schema: DocumentSchema,
  answers: Record<string, string | number | boolean>,
  /** Session ID — when provided, images are fetched from IndexedDB. */
  sessionId?: string,
): Promise<Blob> {
  // Static asset for built-ins, IndexedDB for uploaded templates. Dynamic
  // import keeps renderDocxFromArrayBuffer usable from headless Node tools.
  const { loadTemplateBuffer } = await import("./templateSource");
  const arrayBuffer = await loadTemplateBuffer(schema);

  // Collect image data for image fields
  const imageDataList: ImageData[] = [];
  if (sessionId && schema.template_key_map) {
    // Dynamic import to keep headless/test environments working
    const { getSessionImages } = await import("../db/sessionImages");
    const sessionImages = await getSessionImages(sessionId);
    const imagesByKey = new Map(sessionImages.map((img) => [img.fieldKey, img]));

    for (const [tag, mapping] of Object.entries(schema.template_key_map)) {
      const answerKey = typeof mapping === "string" ? mapping : mapping.field;
      if (!isImageSentinel(answers[answerKey])) continue;
      const img = imagesByKey.get(answerKey);
      if (!img) continue;

      const fieldDef = getFieldDef(schema, answerKey);
      const bytes = new Uint8Array(await img.blob.arrayBuffer());
      imageDataList.push(
        prepareImageData(
          tag,
          bytes,
          img.mimeType,
          img.naturalWidth,
          img.naturalHeight,
          fieldDef?.max_width_inches,
          fieldDef?.max_height_inches,
        ),
      );
    }
  }

  return renderDocxFromArrayBuffer(arrayBuffer, schema, answers, imageDataList);
}

/**
 * Render a filled Word document from a pre-loaded template buffer.
 *
 * This is the core rendering pipeline extracted from `generateDocxBlob` so that
 * tests can call it directly with a `Buffer` from `readFileSync()` without
 * needing browser `fetch()` or the URL allowlist.
 *
 * @param templateBuffer - Raw bytes of the .docx template (ArrayBuffer or Buffer)
 * @param schema - The document schema defining sections, fields, and mappings
 * @param answers - Field values keyed as `section_id.field_id`
 * @param images - Optional image data to embed after rendering
 * @returns The filled .docx as a Blob
 */
export function renderDocxFromArrayBuffer(
  templateBuffer: ArrayBuffer,
  schema: DocumentSchema,
  answers: Record<string, string | number | boolean>,
  images?: ImageData[],
): Blob {
  let zip: PizZip;
  try {
    zip = new PizZip(templateBuffer);
  } catch (err) {
    throw appErrorException("generation.template-damaged", { context: { schema: schema.title }, cause: err });
  }

  // ── Template text replacements ────────────────────────────────────────────
  // Variant schemas reuse a base template and declare text substitutions
  // (e.g., "TT&E" → "Straight to Repair") applied to all word/*.xml parts
  // before Docxtemplater rendering.
  if (schema.template_text_replace?.length) {
    applyTemplateTextReplace(zip, schema.template_text_replace);
  }

  // ── Freetext raw XML mutation ──────────────────────────────────────────────
  // Identify freetext field tags and mutate the template to use Docxtemplater's
  // rawXml syntax ({@TAG}) so we can inject multi-paragraph Word XML with
  // proper heading styles, bold, italic, etc.
  const freetextFieldKeys = new Set<string>();
  for (const section of schema.sections) {
    for (const field of section.fields) {
      if (field.type === "freetext") {
        freetextFieldKeys.add(`${section.id}.${field.id}`);
      }
    }
  }

  const freetextTags = new Set<string>();
  if (schema.template_key_map) {
    for (const [tag, mapping] of Object.entries(schema.template_key_map)) {
      const key = typeof mapping === "string" ? mapping : mapping.field;
      if (freetextFieldKeys.has(key)) {
        freetextTags.add(tag);
      }
    }
  }

  if (freetextTags.size > 0) {
    const docXmlFile = zip.file("word/document.xml");
    if (docXmlFile) {
      let docXml = docXmlFile.asText();
      for (const tag of freetextTags) {
        // Replace {{TAG}} with {{@TAG}} for rawXml injection.
        // Must keep double-brace delimiters since Docxtemplater is configured
        // with delimiters: { start: "{{", end: "}}" }.
        docXml = docXml.split(`{{${tag}}}`).join(`{{@${tag}}}`);
      }
      zip.file("word/document.xml", docXml);
    }
  }

  const doc = newDocxtemplater(schema, zip, {
    delimiters: { start: "{{", end: "}}" },
    // Preserve original template tags for unfilled fields so the exported doc
    // can be re-imported to continue filling in a new session.
    nullGetter: (part: { value: string }) => `{{${part.value}}}`,
    paragraphLoop: true,
    linebreaks: true,
    // Strip control characters that are invalid in XML 1.0 (U+0000–U+0008,
    // U+000B–U+000C, U+000E–U+001F). Without this, pasted or AI-generated
    // text containing these chars corrupts the .docx XML and Word shows
    // "found unreadable content".
    stripInvalidXMLChars: true,
  });

  // Build the set of table field answer keys for detection
  const tableFieldKeys = new Set<string>();
  for (const section of schema.sections) {
    for (const field of section.fields) {
      if (field.type === "table") {
        tableFieldKeys.add(`${section.id}.${field.id}`);
      }
    }
  }

  // ── Effective answers ──────────────────────────────────────────────────────
  // Hidden column inputs blanked, row formulas recomputed, and formula fields
  // evaluated from those masked answers, so the document's totals and
  // "Increase"/"Reduce" blocks match what the interview showed. Formula values
  // stay numeric so conditions (e.g. `gte: 0`) see the sign; formatting (incl.
  // `display: "abs"`) happens at template substitution below.
  const effective = resolveEffectiveAnswers(schema, answers);
  answers = effective.answers;
  const { computed } = effective;

  // Build the data object by mapping template tags → answer values
  const data: Record<string, string | boolean | Record<string, string | number | boolean>[]> = {};

  // ── Heading style options for markdownToWordXml ──────────────────────────
  // Parse the schema-level heading_style_map (string keys → numeric keys) once
  // so each freetext field can get per-field options with the correct baseLevel.
  const headingStyleMap: Record<number, string> | undefined =
    schema.heading_style_map
      ? Object.fromEntries(
          Object.entries(schema.heading_style_map).map(([k, v]) => [Number(k), v]),
        )
      : undefined;

  /** Build markdownToWordXml options for a specific freetext field. */
  function mdOptionsForField(answerKey: string): MarkdownToWordXmlOptions | undefined {
    if (!headingStyleMap) return undefined;
    const fieldDef = getFieldDef(schema, answerKey);
    return { headingStyleMap, baseLevel: fieldDef?.heading_level ?? 0 };
  }

  if (schema.template_key_map) {
    for (const [tag, mapping] of Object.entries(schema.template_key_map)) {
      // Resolve answerKey and optional date_format override from the mapping.
      const answerKey = typeof mapping === "string" ? mapping : mapping.field;
      const dateFormatOverride: DateDisplayFormat | undefined =
        typeof mapping === "object" ? mapping.date_format : undefined;

      // Image fields: skip entirely so the {{TAG}} survives Docxtemplater
      // rendering via nullGetter. embedImages() replaces them afterwards.
      if (isImageSentinel(answers[answerKey])) {
        continue;
      }

      if (tableFieldKeys.has(answerKey)) {
        // Table field: pass rows array for Docxtemplater loop
        const tableData = parseTableData(answers[answerKey]);
        // Build reverse column map: schema column ID → Word template tag
        const reverseColMap = buildReverseColumnMap(schema, tag);
        const columns = getFieldDef(schema, answerKey)?.columns ?? [];
        const columnFormats = new Map(
          columns
            .filter((c) => c.type === "number" && c.format)
            .map((c) => [c.id, c] as const),
        );
        data[tag] = tableData.rows.map((row) => {
          const formatted: Record<string, string | number | boolean> = {};
          for (const [k, v] of Object.entries(row)) {
            if (k === "_rowId") continue;
            const outputKey = reverseColMap?.[k] ?? k;
            if (typeof v === "boolean") {
              formatted[outputKey] = v ? "Yes" : "No";
            } else if (columnFormats.has(k) && v !== "" && v != null) {
              const col = columnFormats.get(k)!;
              formatted[outputKey] = formatNumberForTemplate(v, col.format, col.decimals);
            } else {
              formatted[outputKey] = v;
            }
          }
          // Optional columns missing from a stored row (e.g. a column added to
          // the schema after the row was saved) render blank instead of leaking
          // the literal {{tag}} via nullGetter. Required ones keep the tag, which
          // matches the scalar-field policy below.
          for (const col of columns) {
            if (col.required || col.id in row) continue;
            const outputKey = reverseColMap?.[col.id] ?? col.id;
            if (!(outputKey in formatted)) formatted[outputKey] = "";
          }
          return formatted;
        });
      } else if (freetextTags.has(tag)) {
        // Freetext field: convert markdown to Word XML paragraphs.
        // Must always set a value since the template uses {@TAG} (rawXml) —
        // nullGetter would return invalid XML for rawXml tags.
        const value = answers[answerKey];
        const formatted = formatAnswerValue(value);
        if (formatted !== "") {
          data[tag] = markdownToWordXml(formatted, mdOptionsForField(answerKey));
        } else if (isFieldRequired(schema, answerKey)) {
          // Required + empty: preserve the original tag for re-import
          data[tag] = `<w:p><w:r><w:t>{{${tag}}}</w:t></w:r></w:p>`;
        } else {
          // Optional + empty: render blank
          data[tag] = `<w:p></w:p>`;
        }
      } else if (answerKey in computed) {
        // Formula field: format the resolved number (no $ — lives in template).
        const fieldDef = getFieldDef(schema, answerKey);
        const formatted = fieldDef ? formatCalculated(computed[answerKey], fieldDef) : "";
        if (formatted !== "") {
          data[tag] = formatted;
        } else if (!isFieldRequired(schema, answerKey)) {
          data[tag] = "";
        }
        // Required + unresolvable: omit → nullGetter preserves {{TAG}}
      } else {
        const value = answers[answerKey];
        let formatted = formatAnswerValue(value);
        if (formatted !== "") {
          const fieldDef = getFieldDef(schema, answerKey);
          // Apply date formatting when the field is a date type.
          if (fieldDef?.type === "date" && typeof value === "string") {
            formatted = formatDateForDisplay(
              value,
              dateFormatOverride ?? fieldDef.display_format ?? "MM-DD-YYYY",
            );
          } else if (fieldDef?.type === "number" && fieldDef.format) {
            // Apply number formatting (e.g. currency → "12,300.00").
            formatted = String(formatNumberForTemplate(value as string | number, fieldDef.format, fieldDef.decimals));
          }
        }
        if (formatted !== "") {
          data[tag] = formatted;
        } else if (!isFieldRequired(schema, answerKey)) {
          // Optional + unfilled: explicitly set empty string so the tag
          // renders blank instead of preserving {{TAG}} via nullGetter.
          data[tag] = "";
        }
        // Required + unfilled: omit from data → nullGetter preserves {{TAG}}
      }
    }
  }

  // ── Content blocks injection ───────────────────────────────────────────
  // Boolean blocks control {{#TAG}}...{{/TAG}} sections; string blocks fill
  // {{TAG}} placeholders. The same evaluator drives interview visibility, so
  // the document and the UI can never disagree. Applied last so a block can
  // override a field tag of the same name (deterministic).
  Object.assign(data, effective.blocks);

  try {
    doc.render(sanitizeDataForXml(data));
  } catch (err: unknown) {
    throw appErrorException("generation.render", {
      context: { schema: schema.title },
      cause: err,
      detail: formatDocxtemplaterError(err),
    });
  }

  // ── Table of Contents update ──────────────────────────────────────────
  // After rendering, scan the final document for heading paragraphs and
  // replace the static TOC section with dynamically generated entries.
  if (schema.toc) {
    const renderedZip = doc.getZip();
    const docXmlFile = renderedZip.file("word/document.xml");
    if (docXmlFile) {
      const updatedXml = updateTableOfContents(docXmlFile.asText(), schema.toc);
      renderedZip.file("word/document.xml", updatedXml);
    }
  }

  // ── Image embedding ──────────────────────────────────────────────────
  // After Docxtemplater rendering, image field tags survive as literal
  // {{TAG}} text (via nullGetter). Replace each with an inline <w:drawing>
  // and inject the image binary into the zip's word/media/ directory.
  if (images && images.length > 0) {
    embedImages(doc.getZip(), images);
  }

  return doc.getZip().generate({
    type: "blob",
    mimeType:
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  });
}

/**
 * Generate a filled Word document and trigger a browser download via the
 * native file picker (or fallback browser download).
 * Convenience wrapper around `generateDocxBlob`.
 */
export async function generateDocx(
  schema: DocumentSchema,
  answers: Record<string, string | number | boolean>,
  sessionId?: string,
): Promise<void> {
  const blob = await generateDocxBlob(schema, answers, sessionId);
  const filename = `${resolveOutputFilename(schema, answers)}.docx`;

  // Dynamic import: saveFile depends on the browser-only `file-saver` package.
  // Deferring the import keeps the module importable in headless Node/tsx
  // environments (e.g., render-docx.ts CLI, vitest without jsdom for saveFile).
  const { saveFile } = await import("../utils/fileSave");

  await saveFile({
    blob,
    filename,
    types: [{
      description: "Word documents",
      accept: {
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"],
      },
    }],
  });
}

/**
 * Build a reverse column map for a table loop tag: schema column ID → Word tag.
 * Returns undefined when no remapping is needed (backward-compatible default).
 * @internal Exported for testing.
 */
export function buildReverseColumnMap(
  schema: DocumentSchema,
  tag: string,
): Record<string, string> | undefined {
  const colMap = schema.template_column_map?.[tag];
  if (!colMap) return undefined;
  // colMap is { wordTag → schemaColId }, reverse to { schemaColId → wordTag }
  return Object.fromEntries(
    Object.entries(colMap).map(([wordTag, colId]) => [colId, wordTag]),
  );
}

const xmlEscape = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

/**
 * Apply a variant's text substitutions to every word/*.xml part in place.
 * Used at render time and when baking a variant into a downloadable template.
 */
export function applyTemplateTextReplace(
  zip: PizZip,
  replacements: { from: string; to: string }[],
): void {
  for (const [name, entry] of Object.entries(zip.files)) {
    if (!name.startsWith("word/") || !name.endsWith(".xml")) continue;
    if ((entry as { dir?: boolean }).dir) continue;
    let xml = (entry as { asText(): string }).asText();
    for (const { from, to } of replacements) {
      // Replace both the literal pattern and its XML-encoded form.
      // Word XML stores special characters as entities (e.g., & → &amp;),
      // so a search for "TT&E" must also match "TT&amp;E" in the raw XML.
      xml = xml.replaceAll(from, to);
      const xmlFrom = xmlEscape(from);
      if (xmlFrom !== from) xml = xml.replaceAll(xmlFrom, xmlEscape(to));
    }
    zip.file(name, xml);
  }
}

/**
 * Construct Docxtemplater, which compiles the template eagerly — tag syntax
 * errors (unclosed loops, bad delimiters) surface here, before render.
 */
function newDocxtemplater(
  schema: DocumentSchema,
  zip: PizZip,
  options: Docxtemplater.DXT.ConstructorOptions,
): Docxtemplater {
  try {
    return new Docxtemplater(zip, options);
  } catch (err) {
    throw appErrorException("generation.template-damaged", {
      context: { schema: schema.title },
      cause: err,
      detail: formatDocxtemplaterError(err),
    });
  }
}

/**
 * Docxtemplater throws a single "Multi error" whose real issues are nested in
 * `err.properties.errors`. This helper unwraps them into a human-readable
 * string listing each individual problem (bad tag syntax, unclosed loops, etc.).
 */
function formatDocxtemplaterError(err: unknown): string {
  if (
    err &&
    typeof err === "object" &&
    "properties" in err &&
    (err as { properties?: { errors?: unknown[] } }).properties?.errors
  ) {
    const nested = (err as { properties: { errors: { message: string }[] } })
      .properties.errors;
    const details = nested
      .map((e, i) => `${i + 1}. ${e.message}`)
      .join("\n");
    return `Word template rendering failed with ${nested.length} error(s):\n${details}`;
  }
  if (err instanceof Error) return err.message;
  return "Unknown Word template error";
}

/** Format an answer value to a display string for the Word document. */
function formatAnswerValue(
  value: string | number | boolean | undefined,
): string {
  if (value === undefined || value === null || value === "") {
    return "";
  }
  if (typeof value === "boolean") {
    return value ? "Yes" : "No";
  }
  return String(value);
}

/** Look up a FieldDef from a "section_id.field_id" answer key. */
function getFieldDef(schema: DocumentSchema, answerKey: string): FieldDef | undefined {
  const [sectionId, fieldId] = answerKey.split(".");
  const section = schema.sections.find((s) => s.id === sectionId);
  return section?.fields.find((f) => f.id === fieldId);
}
