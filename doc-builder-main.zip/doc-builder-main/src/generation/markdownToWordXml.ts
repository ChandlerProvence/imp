import { Lexer, type Token, type Tokens } from "marked";

/**
 * Options for controlling heading style output.
 *
 * - `headingStyleMap` — maps heading depth (1–6) to the Word paragraph style
 *   ID used in the template (e.g., `{ 2: "Heading2Manual" }`). Falls back to
 *   generic `Heading{depth}` for unmapped depths.
 * - `baseLevel` — added to each markdown heading depth so that AI-authored
 *   `#` headings never collide with the template's own section headings.
 *   For example, a field under a Heading2 parent uses `baseLevel: 2` so
 *   `#` → depth 3, `##` → depth 4, etc.
 */
export interface MarkdownToWordXmlOptions {
  headingStyleMap?: Record<number, string>;
  baseLevel?: number;
}

/**
 * Convert a Markdown string into Word Open XML paragraph elements.
 *
 * Used for freetext fields: instead of rendering markdown as plain text with
 * line breaks, this produces proper `<w:p>` elements with heading styles,
 * bold/italic runs, list items, and code blocks.
 *
 * The returned string is injected via Docxtemplater's rawXml (`{@TAG}`) module,
 * which replaces the entire placeholder paragraph with the provided XML.
 */
export function markdownToWordXml(
  markdown: string,
  options?: MarkdownToWordXmlOptions,
): string {
  if (!markdown || !markdown.trim()) {
    return "";
  }

  const tokens = Lexer.lex(markdown);
  return tokens.map((t) => renderBlockToken(t, options)).join("");
}

/**
 * Resolve the Word paragraph style for a heading at the given markdown depth.
 * Applies the baseLevel offset (so `#` in AI content doesn't collide with the
 * template's own section heading) and then looks up the custom style name.
 */
function resolveHeadingStyle(
  markdownDepth: number,
  opts?: MarkdownToWordXmlOptions,
): string {
  const effective = Math.min(markdownDepth + (opts?.baseLevel ?? 0), 9);
  return opts?.headingStyleMap?.[effective] ?? `Heading${effective}`;
}

/** Render a single block-level token to Word XML paragraph(s). */
function renderBlockToken(
  token: Token,
  opts?: MarkdownToWordXmlOptions,
): string {
  switch (token.type) {
    case "heading": {
      const t = token as Tokens.Heading;
      const runs = renderInlineTokens(t.tokens ?? []);
      const style = resolveHeadingStyle(t.depth, opts);
      return `<w:p><w:pPr><w:pStyle w:val="${style}"/></w:pPr>${runs}</w:p>`;
    }
    case "paragraph": {
      const t = token as Tokens.Paragraph;
      const runs = renderInlineTokens(t.tokens ?? []);
      return `<w:p>${runs}</w:p>`;
    }
    case "list": {
      const t = token as Tokens.List;
      return t.items
        .map((item, idx) => renderListItem(item, t.ordered, idx))
        .join("");
    }
    case "code": {
      const t = token as Tokens.Code;
      // Render each line as a separate paragraph with monospace font
      const lines = t.text.split("\n");
      return lines
        .map(
          (line) =>
            `<w:p><w:pPr><w:pStyle w:val="ListParagraph"/></w:pPr>` +
            `<w:r><w:rPr><w:rFonts w:ascii="Courier New" w:hAnsi="Courier New"/></w:rPr>` +
            `<w:t xml:space="preserve">${escapeXml(line)}</w:t></w:r></w:p>`,
        )
        .join("");
    }
    case "blockquote": {
      const t = token as Tokens.Blockquote;
      // Render blockquote content as indented paragraphs
      return (t.tokens ?? []).map((bt) => renderBlockToken(bt, opts)).join("");
    }
    case "hr":
      // Horizontal rule → paragraph with bottom border
      return (
        `<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="4" w:space="1" w:color="auto"/></w:pBdr></w:pPr>` +
        `<w:r><w:t></w:t></w:r></w:p>`
      );
    case "space":
      // Skip — paragraph boundaries are handled by token structure
      return "";
    default: {
      // Fallback: render raw text as a plain paragraph
      const raw = (token as { raw?: string }).raw;
      if (raw && raw.trim()) {
        return `<w:p><w:r><w:t xml:space="preserve">${escapeXml(raw.trim())}</w:t></w:r></w:p>`;
      }
      return "";
    }
  }
}

/** Render a list item as a Word paragraph with list styling. */
function renderListItem(
  item: Tokens.ListItem,
  ordered: boolean,
  index: number,
): string {
  const style = ordered ? "ListNumber" : "ListBullet";
  const runs = renderInlineTokens(flattenListItemTokens(item));
  // Use numbering prefix for ordered lists since we can't rely on w:numPr
  const prefix = ordered
    ? `<w:r><w:t xml:space="preserve">${index + 1}. </w:t></w:r>`
    : `<w:r><w:t xml:space="preserve">• </w:t></w:r>`;
  return `<w:p><w:pPr><w:pStyle w:val="${style}"/></w:pPr>${prefix}${runs}</w:p>`;
}

/**
 * Flatten a list item's tokens to inline tokens.
 * List items contain paragraph tokens wrapping the actual inline content.
 */
function flattenListItemTokens(item: Tokens.ListItem): Token[] {
  const result: Token[] = [];
  for (const t of item.tokens ?? []) {
    if (t.type === "text" && "tokens" in t && (t as Tokens.Text).tokens) {
      result.push(...((t as Tokens.Text).tokens ?? []));
    } else if (t.type === "paragraph" && "tokens" in t) {
      result.push(...((t as Tokens.Paragraph).tokens ?? []));
    } else {
      result.push(t);
    }
  }
  return result;
}

/** Render an array of inline tokens into Word XML runs. */
function renderInlineTokens(tokens: Token[]): string {
  return tokens.map(renderInlineToken).join("");
}

/** Render a single inline token to a Word XML run. */
function renderInlineToken(token: Token): string {
  switch (token.type) {
    case "text": {
      const t = token as Tokens.Text;
      // Text tokens may have nested tokens (e.g., from softbreaks)
      if (t.tokens && t.tokens.length > 0) {
        return renderInlineTokens(t.tokens);
      }
      return makeRun(escapeXml(t.text));
    }
    case "strong": {
      const t = token as Tokens.Strong;
      // Recursively render children with bold applied
      return renderInlineWithProps(t.tokens ?? [], "<w:b/>");
    }
    case "em": {
      const t = token as Tokens.Em;
      return renderInlineWithProps(t.tokens ?? [], "<w:i/>");
    }
    case "codespan": {
      const t = token as Tokens.Codespan;
      return `<w:r><w:rPr><w:rFonts w:ascii="Courier New" w:hAnsi="Courier New"/></w:rPr><w:t xml:space="preserve">${escapeXml(t.text)}</w:t></w:r>`;
    }
    case "br":
      return `<w:r><w:br/></w:r>`;
    case "escape": {
      const t = token as Tokens.Escape;
      return makeRun(escapeXml(t.text));
    }
    case "link": {
      // Render link text only (Word hyperlinks need relationships, skip for now)
      const t = token as Tokens.Link;
      return renderInlineTokens(t.tokens ?? []);
    }
    default: {
      const raw = (token as { raw?: string; text?: string }).text ??
        (token as { raw?: string }).raw ?? "";
      if (raw) {
        return makeRun(escapeXml(raw));
      }
      return "";
    }
  }
}

/**
 * Render inline tokens with additional run properties applied.
 * Used for bold/italic wrapping — flattens nested inlines with extra rPr.
 */
function renderInlineWithProps(tokens: Token[], rPr: string): string {
  return tokens
    .map((token) => {
      switch (token.type) {
        case "text": {
          const t = token as Tokens.Text;
          if (t.tokens && t.tokens.length > 0) {
            return renderInlineWithProps(t.tokens, rPr);
          }
          return `<w:r><w:rPr>${rPr}</w:rPr><w:t xml:space="preserve">${escapeXml(t.text)}</w:t></w:r>`;
        }
        case "em": {
          const t = token as Tokens.Em;
          // Bold + italic
          return renderInlineWithProps(t.tokens ?? [], `${rPr}<w:i/>`);
        }
        case "strong": {
          const t = token as Tokens.Strong;
          return renderInlineWithProps(t.tokens ?? [], `${rPr}<w:b/>`);
        }
        case "codespan": {
          const t = token as Tokens.Codespan;
          return `<w:r><w:rPr>${rPr}<w:rFonts w:ascii="Courier New" w:hAnsi="Courier New"/></w:rPr><w:t xml:space="preserve">${escapeXml(t.text)}</w:t></w:r>`;
        }
        case "br":
          return `<w:r><w:br/></w:r>`;
        default: {
          const raw = (token as { text?: string; raw?: string }).text ??
            (token as { raw?: string }).raw ?? "";
          return `<w:r><w:rPr>${rPr}</w:rPr><w:t xml:space="preserve">${escapeXml(raw)}</w:t></w:r>`;
        }
      }
    })
    .join("");
}

/** Create a simple text run with no formatting. */
function makeRun(escapedText: string): string {
  return `<w:r><w:t xml:space="preserve">${escapedText}</w:t></w:r>`;
}

/** Escape XML-unsafe characters. */
function escapeXml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
