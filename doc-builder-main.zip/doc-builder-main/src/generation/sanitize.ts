/**
 * Sanitization utilities for Word document generation.
 *
 * .docx files are ZIP archives containing XML. XML 1.0 forbids control
 * characters in ranges U+0000–U+0008, U+000B–U+000C, U+000E–U+001F.
 * When these leak into template data (from user input or AI output),
 * Word reports "unreadable content" and refuses to open the file.
 */

/**
 * Regex matching characters invalid in XML 1.0.
 * Notably, tab (U+0009), newline (U+000A), and carriage return (U+000D)
 * are valid and preserved.
 */
const INVALID_XML_CHARS = /[\x00-\x08\x0B\x0C\x0E-\x1F]/g;

/**
 * Strip characters that are invalid in XML 1.0 from a string.
 * Returns the input unchanged when no invalid characters are present (fast path).
 */
export function stripInvalidXmlChars(value: string): string {
  INVALID_XML_CHARS.lastIndex = 0;
  if (!INVALID_XML_CHARS.test(value)) {
    return value;
  }
  INVALID_XML_CHARS.lastIndex = 0;
  return value.replace(INVALID_XML_CHARS, "");
}

/**
 * Recursively sanitize all string values in a render-data object.
 * Handles flat string values and table row arrays (the two shapes
 * produced by generateDocxBlob's data-building logic).
 *
 * Returns a new object — does not mutate the input.
 */
export function sanitizeDataForXml(
  data: Record<string, string | boolean | Record<string, string | number | boolean>[]>,
): Record<string, string | boolean | Record<string, string | number | boolean>[]> {
  const sanitized: Record<
    string,
    string | boolean | Record<string, string | number | boolean>[]
  > = {};

  for (const [key, value] of Object.entries(data)) {
    if (typeof value === "string") {
      sanitized[key] = stripInvalidXmlChars(value);
    } else if (typeof value === "boolean") {
      sanitized[key] = value;
    } else if (Array.isArray(value)) {
      sanitized[key] = value.map((row) => sanitizeRow(row));
    } else {
      sanitized[key] = value;
    }
  }

  return sanitized;
}

/** Sanitize all string cell values in a single table row. */
function sanitizeRow(
  row: Record<string, string | number | boolean>,
): Record<string, string | number | boolean> {
  const sanitized: Record<string, string | number | boolean> = {};
  for (const [key, value] of Object.entries(row)) {
    sanitized[key] =
      typeof value === "string" ? stripInvalidXmlChars(value) : value;
  }
  return sanitized;
}
