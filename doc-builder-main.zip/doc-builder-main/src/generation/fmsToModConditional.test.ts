/**
 * Conditional rendering of the FMS Task Order Modification letter.
 *
 * The mod template wraps each change type in a `{{#BLOCK}}…{{/BLOCK}}`
 * content block, and picks "Increase"/"Reduce" wording from the sign of a
 * computed delta. These tests render the real template under three answer
 * sets and assert on the extracted text so regressions in the block
 * evaluator, computed-field formatting, or the schema wiring are caught here
 * rather than by a human opening the .docx.
 */
import { describe, it, expect } from "vitest";
import { schemas } from "../schemas/loader";
import { renderDocxFromArrayBuffer } from "./generateDocx";
import { loadTemplateBuffer, extractDocxText, findRemainingTags } from "../test/docx-test-utils";
import { loadAnswerFixture } from "../test/fixture-utils";

const schema = schemas.get("fms-to-mod")!;
const template = loadTemplateBuffer(schema);

/** The committed fixture: all five change types, price + funding increases. */
const increaseAll = loadAnswerFixture("fms-to-mod")!;

type Answers = Record<string, string | number | boolean>;

function withMods(base: Answers, mods: string[], overrides: Answers = {}): Answers {
  return { ...base, "changes.mod_types": JSON.stringify(mods), ...overrides };
}

/**
 * `pricing.total_ff_price` is a SUM over `parts_list.total_unit_cost`, so the
 * only way to steer the new price is through the line items. Build a table of
 * TT&E-only units (no R&R) whose rates sum to `total`.
 */
function partsTotaling(total: number, units = 2): string {
  const rate = total / units;
  const rows = Array.from({ length: units }, (_, i) => ({
    noun: "Power Supply",
    nsn: "6130-01-234-5678",
    part_number: "PS-4471-B",
    serial: `SN-000${i + 1}`,
    tat: 45,
    tte_rate: rate,
  }));
  return JSON.stringify({ rows });
}

async function render(answers: Answers) {
  const blob = renderDocxFromArrayBuffer(template, schema, answers);
  return { text: await extractDocxText(blob), tags: await findRemainingTags(blob) };
}

// Prose that only appears inside a given block (from the template body).
const PROSE = {
  SOW_CHANGE: "Update 1.0 STATEMENT OF WORK",
  PRICE_CHANGE: "Update 4.0 PRICE",
  FUNDING_CHANGE: "Update 5.0 FUNDING",
  BUYER_REPS: "Update 6.0 BUYER REPRESENTATIVES",
  PRECEDENCE: "Update 10.0 ORDER OF PRECEDENCE",
} as const;

describe("fms-to-mod conditional rendering", () => {
  it("increase-all: every block renders, deltas positive and unsigned", async () => {
    const { text, tags } = await render(increaseAll);

    for (const prose of Object.values(PROSE)) expect(text).toContain(prose);

    expect(text).toMatch(/Update 4\.0 PRICE: Increase Price from \$120,000\.00 by \$30,000\.00 to \$150,000\.00/);
    expect(text).toMatch(/Update 5\.0 FUNDING: Increase funding in the amount of \$30,000\.00 from \$130,000\.00/);
    expect(text).not.toContain("Reduce");
    expect(text).not.toContain("-30,000");
    expect(tags).toEqual([]);
  });

  it("decrease-price-and-funding: 'Reduce' wording, absolute deltas, unrelated blocks removed", async () => {
    const answers = withMods(increaseAll, ["Pricing", "Funding"], {
      "pricing.includes_rr": false,
      "pricing.parts_list": partsTotaling(95000),
      "pricing.price_from": 120000,
      "funding.funding_from": 130000,
      "funding.funded_amount": 100000,
    });
    const { text, tags } = await render(answers);

    expect(text).toMatch(/Update 4\.0 PRICE: Reduce Price from \$120,000\.00 by \$25,000\.00 to \$95,000\.00/);
    expect(text).toMatch(/Update 5\.0 FUNDING: Reduce funding in the amount of \$30,000\.00 from \$130,000\.00/);
    expect(text).not.toMatch(/Increase (Price|funding)/);
    expect(text).not.toMatch(/by \$-|-\$\d|\$-\d/); // no stray minus signs on amounts

    expect(text).not.toContain(PROSE.SOW_CHANGE);
    expect(text).not.toContain(PROSE.BUYER_REPS);
    expect(text).not.toContain(PROSE.PRECEDENCE);
    // Hidden sections' values must not leak
    expect(text).not.toContain(increaseAll["buyer_reps.rep_from"] as string);
    expect(text).not.toContain(increaseAll["precedence.precedence_reason"] as string);
    expect(tags).toEqual([]);
  });

  it("sow-only: only the SOW block renders; pricing table absent", async () => {
    const answers = withMods(increaseAll, ["SOW"]);
    const { text, tags } = await render(answers);

    expect(text).toContain(PROSE.SOW_CHANGE);
    expect(text).toContain("1.0 STATEMENT OF WORK: Seller shall provide all services");
    for (const key of ["PRICE_CHANGE", "FUNDING_CHANGE", "BUYER_REPS", "PRECEDENCE"] as const) {
      expect(text).not.toContain(PROSE[key]);
    }
    expect(text).not.toContain("Power Supply"); // parts_list rows live inside PRICE_CHANGE
    expect(text).not.toMatch(/(Increase|Reduce) (Price|funding)/);
    expect(tags).toEqual([]);
  });

  it("zero delta counts as an increase (gte 0) and renders $0.00", async () => {
    const answers = withMods(increaseAll, ["Pricing"], {
      "pricing.includes_rr": false,
      "pricing.parts_list": partsTotaling(120000),
      "pricing.price_from": 120000,
    });
    const { text } = await render(answers);
    expect(text).toMatch(/Increase Price from \$120,000\.00 by \$0\.00 to \$120,000\.00/);
  });

  it("floating-point leftovers never flip an unchanged price to 'Reduce'", async () => {
    // 0.7 + 0.1 === 0.7999999999999999 in IEEE-754, a hair under price_from.
    const rows = [0.7, 0.1].map((tte_rate, i) => ({ noun: "Power Supply", nsn: "x", part_number: "x", serial: `SN-${i}`, tat: 45, tte_rate }));
    const answers = withMods(increaseAll, ["Pricing"], {
      "pricing.includes_rr": false,
      "pricing.parts_list": JSON.stringify({ rows }),
      "pricing.price_from": 0.8,
    });
    const { text } = await render(answers);
    expect(text).toMatch(/Increase Price from \$0\.80 by \$0\.00 to \$0\.80/);
    expect(text).not.toContain("Reduce Price");
  });

  it("new price is the sum of line items, not a free-entered value", async () => {
    // A stale/incorrect total_ff_price answer must be ignored in favour of the table sum.
    const answers = withMods(increaseAll, ["Pricing"], {
      "pricing.total_ff_price": 999999,
      "pricing.includes_rr": false,
      "pricing.parts_list": partsTotaling(6000), // e.g. 3 cancelled units → TT&E-only remainder
      "pricing.price_from": 12300,
    });
    const { text, tags } = await render(answers);
    expect(text).toMatch(/Reduce Price from \$12,300\.00 by \$6,300\.00 to \$6,000\.00/);
    expect(text).toMatch(/firm fixed price for the work to be performed under this Subcontract is \$6,000\.00/);
    expect(text).not.toContain("999,999");
    expect(tags).toEqual([]);
  });

  it("R&R columns render and feed the total when includes_rr is true", async () => {
    // Fixture: 2 units × (50,000 TT&E + 25,000 R&R) = 150,000
    const { text } = await render(increaseAll);
    expect(text).toMatch(/R&(?:amp;)?R Rate/);
    expect(text).toContain("$25,000.00");
    expect(text).toContain("$75,000.00"); // total_unit_cost per row
    expect(text).toMatch(/Increase Price from \$120,000\.00 by \$30,000\.00 to \$150,000\.00/);
  });

  it("R&R columns hidden and excluded from the total when includes_rr is false", async () => {
    // Stale R&R rates (and their stale unit totals) are still in the stored
    // table, but this mod doesn't incorporate R&R — they must not render or count.
    const rows = [1, 2].map((i) => ({
      noun: "Power Supply",
      nsn: "6130-01-234-5678",
      part_number: "PS-4471-B",
      serial: `SN-000${i}`,
      tat: 45,
      tte_rate: 50000,
      rr_rate: 25000,
      total_unit_cost: 75000,
    }));
    const answers = withMods(increaseAll, ["Pricing"], {
      "pricing.includes_rr": false,
      "pricing.parts_list": JSON.stringify({ rows }),
      "pricing.price_from": 120000,
    });
    const { text } = await render(answers);
    expect(text).not.toMatch(/R&(?:amp;)?R Rate/);
    expect(text).not.toContain("$25,000.00");
    expect(text).not.toContain("$75,000.00");
    // The table header and data rows still render (only R&R columns are hidden)
    expect(text).toMatch(/TT&(?:amp;)?E Rate/);
    expect(text).toContain("Power Supply");
    expect(text).toMatch(/Reduce Price from \$120,000\.00 by \$20,000\.00 to \$100,000\.00/);
  });

  it("STR column renders and feeds the total when includes_str is true", async () => {
    // 2 units × (10,000 TT&E + 40,000 STR) = 100,000
    const rows = [1, 2].map((i) => ({
      noun: "Power Supply",
      nsn: "6130-01-234-5678",
      part_number: "PS-4471-B",
      serial: `SN-000${i}`,
      tat: 45,
      tte_rate: 10000,
      str_rate: 40000,
    }));
    const answers = withMods(increaseAll, ["Pricing"], {
      "pricing.includes_rr": false,
      "pricing.includes_str": true,
      "pricing.parts_list": JSON.stringify({ rows }),
      "pricing.price_from": 120000,
    });
    const { text, tags } = await render(answers);
    expect(text).toContain("STR Rate");
    expect(text).toContain("$40,000.00");
    expect(text).toContain("$50,000.00"); // total_unit_cost per row
    expect(text).not.toMatch(/R&(?:amp;)?R Rate/);
    expect(text).toMatch(/Reduce Price from \$120,000\.00 by \$20,000\.00 to \$100,000\.00/);
    expect(tags).toEqual([]);
  });

  it("TT&E column hidden and excluded from the total when includes_tte is false", async () => {
    // STR-only mod: stale TT&E rates in the table must not render or count.
    const rows = [1, 2].map((i) => ({
      noun: "Power Supply",
      nsn: "6130-01-234-5678",
      part_number: "PS-4471-B",
      serial: `SN-000${i}`,
      tat: 45,
      tte_rate: 12345,
      str_rate: 40000,
    }));
    const answers = withMods(increaseAll, ["Pricing"], {
      "pricing.includes_tte": false,
      "pricing.includes_rr": false,
      "pricing.includes_str": true,
      "pricing.parts_list": JSON.stringify({ rows }),
      "pricing.price_from": 120000,
    });
    const { text, tags } = await render(answers);
    expect(text).not.toMatch(/TT&(?:amp;)?E Rate/);
    expect(text).not.toContain("$12,345.00");
    expect(text).toContain("STR Rate");
    expect(text).toMatch(/Reduce Price from \$120,000\.00 by \$40,000\.00 to \$80,000\.00/);
    expect(tags).toEqual([]);
  });

  it("unset includes_tte keeps the TT&E column and counts it (pre-TT&E-toggle sessions)", async () => {
    // Sessions saved before includes_tte existed have no answer for it. Their
    // TT&E rates must still render and count instead of silently totalling $0.
    const answers = withMods(increaseAll, ["Pricing"], {
      "pricing.includes_rr": false,
      "pricing.parts_list": partsTotaling(100000),
      "pricing.price_from": 120000,
    });
    delete answers["pricing.includes_tte"];
    const { text, tags } = await render(answers);
    expect(text).toMatch(/TT&(?:amp;)?E Rate/);
    expect(text).toContain("$50,000.00");
    expect(text).toMatch(/Reduce Price from \$120,000\.00 by \$20,000\.00 to \$100,000\.00/);
    expect(tags).toEqual([]);
  });

  it("STR column hidden and excluded from the total when includes_str is false", async () => {
    const rows = [{ noun: "Power Supply", nsn: "x", part_number: "x", serial: "SN-1", tat: 45, tte_rate: 10000, str_rate: 40000 }];
    const answers = withMods(increaseAll, ["Pricing"], {
      "pricing.includes_rr": false,
      "pricing.includes_str": false,
      "pricing.parts_list": JSON.stringify({ rows }),
      "pricing.price_from": 10000,
    });
    const { text } = await render(answers);
    expect(text).not.toContain("STR Rate");
    expect(text).not.toContain("$40,000.00");
    expect(text).toMatch(/Increase Price from \$10,000\.00 by \$0\.00 to \$10,000\.00/);
  });

  it("Current Status column renders its header and values; rows without it render blank", async () => {
    const rows = [
      { noun: "Power Supply", nsn: "x", part_number: "x", serial: "SN-1", tat: 45, tte_rate: 10000, current_status: "Awaiting repair quote" },
      { noun: "Power Supply", nsn: "x", part_number: "x", serial: "SN-2", tat: 45, tte_rate: 10000 },
    ];
    const answers = withMods(increaseAll, ["Pricing"], {
      "pricing.includes_rr": false,
      "pricing.parts_list": JSON.stringify({ rows }),
      "pricing.price_from": 20000,
    });
    const { text, tags } = await render(answers);
    expect(text).toContain("Current Status");
    expect(text).toContain("Awaiting repair quote");
    expect(text).toContain("Total: $20,000.00");
    expect(tags).toEqual([]);
  });
});
