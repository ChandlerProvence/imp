import { appErrorException, toAppError, type AppError } from "../errors";
import PizZip from "pizzip";
import type { DocumentSchema } from "../schemas/types";
import { resolveAliasedAnswers } from "../schemas/mergeSet";
import { substituteTemplate } from "./substitute";
import { generateDocxBlob } from "./generateDocx";
import { filenameTimestamp } from "../utils/timestamp";
import { resolveOutputFilename } from "./resolveOutputFilename";
import { saveFile } from "../utils/fileSave";

export interface DownloadAllResult {
  /** Document titles that failed to generate. */
  errors: { title: string; error: AppError }[];
  /** Number of documents successfully included in the zip. */
  successCount: number;
}

/** One line per failed document, for error detail text. */
export function formatDocErrors(errors: DownloadAllResult["errors"]): string {
  return errors.map((e) => `• ${e.title}: ${e.error.message}\n  ${e.error.detail}`).join("\n");
}

/**
 * Zip entry name for `base.ext`, adding " (2)", " (3)", … when an earlier
 * member already used it, so members with the same filename don't overwrite
 * each other.
 */
function uniqueEntryName(used: Set<string>, base: string, ext: string): string {
  let name = `${base}.${ext}`;
  for (let n = 2; used.has(name); n++) name = `${base} (${n}).${ext}`;
  used.add(name);
  return name;
}

/**
 * Generate all documents in a set and download them as a single .zip file.
 *
 * For schemas with a docx_template: generates the filled Word document blob.
 * For schemas with only an output_template: includes the substituted markdown as a .md file.
 * Members that resolve to the same filename are numbered, e.g. "Memo (2).docx".
 *
 * If individual documents fail, generation continues for the remaining documents.
 * The zip is still produced (if at least one document succeeded) and per-document
 * errors are returned in the result.
 */
export async function downloadAllAsZip(
  schemas: DocumentSchema[],
  answers: Record<string, string | number | boolean>,
  setName: string,
  tableAliases?: Map<string, Record<string, string>>,
  sessionId?: string,
): Promise<DownloadAllResult> {
  const zip = new PizZip();
  const errors: DownloadAllResult["errors"] = [];
  let successCount = 0;
  const usedNames = new Set<string>();

  for (const schema of schemas) {
    // Resolve aliased table answers for this schema
    const resolved = tableAliases
      ? resolveAliasedAnswers(schema.id, answers, tableAliases)
      : answers;
    const safeName = resolveOutputFilename(schema, resolved);

    try {
      if (schema.docx_template) {
        const blob = await generateDocxBlob(schema, resolved, sessionId);
        const buffer = await blob.arrayBuffer();
        zip.file(uniqueEntryName(usedNames, safeName, "docx"), buffer);
      } else if (schema.output_template) {
        const md = substituteTemplate(schema.output_template, resolved, schema);
        zip.file(uniqueEntryName(usedNames, safeName, "md"), md);
      }
      successCount++;
    } catch (err) {
      errors.push({
        title: schema.title,
        error: toAppError(err, { domain: "generation", context: { schema: schema.title } }),
      });
    }
  }

  if (successCount === 0) {
    throw appErrorException("generation.render", {
      detail: `All documents failed to generate:\n${formatDocErrors(errors)}`,
    });
  }

  const content = zip.generate({
    type: "blob",
    mimeType: "application/zip",
  });

  const zipName = setName.replace(/[^a-zA-Z0-9 -]/g, "").trim();
  await saveFile({
    blob: content,
    filename: `${zipName} ${filenameTimestamp()}.zip`,
    types: [{ description: "ZIP archives", accept: { "application/zip": [".zip"] } }],
  });

  return { errors, successCount };
}
