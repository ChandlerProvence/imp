/**
 * Suite 2c: Document coherence and continuity testing.
 *
 * Generated documents must read as coherent wholes, not just collections of
 * correctly substituted fields. For every schema with a `docx_template`, this
 * suite generates a filled .docx and runs continuity / coherence assertions:
 *
 * 1. Heading hierarchy — no impossible jumps (e.g., H1 → H4)
 * 2. No excessive empty paragraphs (max run ≤ 5)
 * 3. No orphaned loop markers ({{#TAG}} or {{/TAG}})
 * 4. Value echo — every non-empty scalar answer appears in the document text
 * 5. Cross-reference consistency via same_as fields
 * 6. Computed field math (derived fields) — formattedValue appears in text
 * 7. Document length sanity — ≥ 50 chars per populated field
 * 8. Table completeness — at least one cell value per row present in text
 *
 * 9–10. LLM-gated coherence tests (skipped unless RUN_LLM_TESTS=true)
 */
import { describe, it, expect } from "vitest";
import { schemas } from "../schemas/loader";
import { renderDocxFromArrayBuffer } from "./generateDocx";
import {
  loadTemplateBuffer,
  extractDocxText,
  extractHeadingHierarchy,
  countMaxEmptyParagraphRun,
  findRemainingTags,
} from "../test/docx-test-utils";
import {
  loadAnswerFixture,
  generateSampleAnswers,
} from "../test/fixture-utils";
import { resolveEffectiveAnswers } from "../engine/effectiveAnswers";
import { formatCalculated } from "../engine/formula";
import type { DocumentSchema } from "../schemas/types";

// ---------------------------------------------------------------------------
// Collect schemas that have a docx_template
// ---------------------------------------------------------------------------

const docxSchemas: DocumentSchema[] = [];
for (const [, schema] of schemas) {
  if (schema.docx_template) {
    docxSchemas.push(schema);
  }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Load answers: prefer hand-curated fixture, fall back to generated sample. */
function loadAnswers(
  schema: DocumentSchema,
): Record<string, string | number | boolean> {
  return loadAnswerFixture(schema.id) ?? generateSampleAnswers(schema);
}

/** Collect all field keys of a given type from a schema. */
function fieldKeysOfType(schema: DocumentSchema, type: string): string[] {
  const keys: string[] = [];
  for (const section of schema.sections) {
    for (const field of section.fields) {
      if (field.type === type) {
        keys.push(`${section.id}.${field.id}`);
      }
    }
  }
  return keys;
}

/** Build a set of field paths that appear in the template_key_map values. */
function templateMappedFields(schema: DocumentSchema): Set<string> {
  const paths = new Set<string>();
  for (const v of Object.values(schema.template_key_map ?? {})) {
    paths.add(typeof v === "string" ? v : v.field);
  }
  return paths;
}

/** Count the number of populated (non-empty) answer fields for a schema. */
function countPopulatedFields(
  schema: DocumentSchema,
  answers: Record<string, string | number | boolean>,
): number {
  let count = 0;
  for (const section of schema.sections) {
    for (const field of section.fields) {
      const key = `${section.id}.${field.id}`;
      const value = answers[key];
      if (value !== undefined && value !== null && value !== "") {
        count++;
      }
    }
  }
  return count;
}

// ---------------------------------------------------------------------------
// Pre-render all blobs (one per schema) so individual assertions are fast
// ---------------------------------------------------------------------------

const rendered = new Map<
  string,
  { blob: Blob; answers: Record<string, string | number | boolean> }
>();

for (const schema of docxSchemas) {
  const answers = loadAnswers(schema);
  const templateBuffer = loadTemplateBuffer(schema);
  const blob = renderDocxFromArrayBuffer(templateBuffer, schema, answers);
  rendered.set(schema.id, { blob, answers });
}

// ---------------------------------------------------------------------------
// Deterministic continuity checks (CI)
// ---------------------------------------------------------------------------

describe("Suite 2c: Document coherence and continuity", () => {
  describe.each(docxSchemas.map((s) => [s.id, s]))(
    "%s",
    (_id, schema) => {
      const s = schema as DocumentSchema;
      const entry = rendered.get(s.id)!;

      // 1. Heading hierarchy — no impossible jumps
      it("has a valid heading hierarchy (no jumps > 2 levels)", async () => {
        const headings = await extractHeadingHierarchy(entry.blob);

        // Skip if the document has no headings (some templates are flat)
        if (headings.length === 0) return;

        for (let i = 1; i < headings.length; i++) {
          const prev = headings[i - 1];
          const curr = headings[i];
          // Going deeper: allow a gap of at most 1 (e.g., H1→H3 is OK, H1→H4 is not)
          if (curr.level > prev.level) {
            const jump = curr.level - prev.level;
            expect(
              jump,
              `Heading hierarchy jump from H${prev.level} ("${prev.text}") to H${curr.level} ("${curr.text}") — gap of ${jump} levels exceeds the allowed maximum of 2`,
            ).toBeLessThanOrEqual(2);
          }
        }
      });

      // 2. No excessive empty paragraphs
      it("has no excessive empty paragraph runs (max 6 consecutive)", async () => {
        const maxRun = await countMaxEmptyParagraphRun(entry.blob);
        expect(
          maxRun,
          `Longest consecutive empty paragraph run is ${maxRun}, which exceeds the threshold of 6 — indicates broken sections or formatting gaps`,
        ).toBeLessThanOrEqual(6);
      });

      // 3. No orphaned loop markers
      it("has no orphaned loop markers ({{#TAG}} or {{/TAG}})", async () => {
        const remaining = await findRemainingTags(entry.blob);
        const loopArtifacts = remaining.filter(
          (tag) => tag.startsWith("{{#") || tag.startsWith("{{/"),
        );
        expect(
          loopArtifacts,
          `Found orphaned loop markers in output: ${loopArtifacts.join(", ")}`,
        ).toEqual([]);
      });

      // 4. Value echo — every non-empty scalar answer appears in the document
      it("echoes non-empty scalar answer values in the document text", async () => {
        const text = await extractDocxText(entry.blob);
        const mapped = templateMappedFields(s);

        for (const section of s.sections) {
          for (const field of section.fields) {
            const key = `${section.id}.${field.id}`;
            const value = entry.answers[key];

            // Skip empty, undefined, table, freetext, and multiselect fields
            // (multiselect values are JSON arrays used as UI gates, not document text)
            if (value === undefined || value === null || value === "") continue;
            if (field.type === "table" || field.type === "freetext" || field.type === "multiselect") continue;

            // Skip computed and same_as fields — they may transform values
            if (field.formula !== undefined || field.same_as) continue;

            // Handle booleans: check for "Yes"/"No" instead of "true"/"false".
            // Skip booleans that are interview-only gates (no template mapping).
            if (typeof value === "boolean") {
              if (!mapped.has(key)) continue;
              const expected = value ? "Yes" : "No";
              expect(
                text,
                `Boolean field "${key}" (value=${value}) should appear as "${expected}" in the document`,
              ).toContain(expected);
              continue;
            }

            // Enum fields that drive content_blocks (not in template_key_map)
            // render as checkbox marks, not the raw option string — skip them.
            if (field.type === "enum" && !mapped.has(key)) continue;

            // For date fields, the value is formatted (not raw ISO), so skip
            // raw value check — the date format test in Suite 2a covers this
            if (field.type === "date") continue;

            // Number fields with a format (e.g. currency) are displayed with
            // commas/decimals, so the raw numeric string won't match.
            if (field.type === "number" && field.format) continue;

            // An untagged number that only feeds formulas reaches the document
            // through them (check 6), not as its own text.
            if (field.type === "number" && !mapped.has(key)) continue;

            const strValue = String(value);
            // Skip very short values that could match coincidentally
            if (strValue.length < 2) continue;

            expect(
              text,
              `Field "${key}" with value "${strValue}" should appear somewhere in the generated document`,
            ).toContain(strValue);
          }
        }
      });

      // 5. Cross-reference consistency via same_as
      it("maintains same_as cross-reference consistency", async () => {
        const text = await extractDocxText(entry.blob);

        for (const section of s.sections) {
          for (const field of section.fields) {
            if (!field.same_as) continue;

            const followerKey = `${section.id}.${field.id}`;
            const sourceKey = field.same_as;

            // Verify the answer map has them equal (engine invariant)
            const sourceValue = entry.answers[sourceKey];
            const followerValue = entry.answers[followerKey];

            // If source has a value, the follower should match
            if (sourceValue !== undefined && sourceValue !== "") {
              expect(
                followerValue,
                `same_as field "${followerKey}" should mirror source "${sourceKey}" — source="${sourceValue}", follower="${followerValue}"`,
              ).toEqual(sourceValue);
            }

            // If both are in the template_key_map, verify both values appear
            if (s.template_key_map && sourceValue !== undefined && sourceValue !== "") {
              const sourceInTkm = Object.values(s.template_key_map).some(
                (mapping) => {
                  const field = typeof mapping === "string" ? mapping : mapping.field;
                  return field === sourceKey;
                },
              );
              const followerInTkm = Object.values(s.template_key_map).some(
                (mapping) => {
                  const field = typeof mapping === "string" ? mapping : mapping.field;
                  return field === followerKey;
                },
              );

              if (sourceInTkm && followerInTkm) {
                const strValue = typeof sourceValue === "boolean"
                  ? (sourceValue ? "Yes" : "No")
                  : String(sourceValue);

                // The value should appear in the text (at least once for each reference)
                if (strValue.length >= 2) {
                  expect(
                    text,
                    `same_as pair "${sourceKey}" / "${followerKey}" value "${strValue}" should appear in the document`,
                  ).toContain(strValue);
                }
              }
            }
          }
        }
      });

      // 6. Formula field values reach the document
      if (s.sections.some((sec) => sec.fields.some((f) => f.formula !== undefined))) {
        it("includes every tagged formula field's formatted value in the document text", async () => {
          const text = await extractDocxText(entry.blob);
          const { computed } = resolveEffectiveAnswers(s, entry.answers);
          const tagged = new Set(
            Object.values(s.template_key_map ?? {}).map((v) => (typeof v === "string" ? v : v.field)),
          );
          for (const sec of s.sections) {
            for (const f of sec.fields) {
              const key = `${sec.id}.${f.id}`;
              if (f.formula === undefined || !tagged.has(key)) continue;
              const formatted = formatCalculated(computed[key] ?? null, f);
              if (formatted === "") continue;
              expect(
                text,
                `Formula field "${key}" (label="${f.label}") should have its formatted value "${formatted}" in the document`,
              ).toContain(formatted);
            }
          }
        });
      }

      // 7. Document length sanity
      it("has sufficient document length relative to populated fields", async () => {
        const text = await extractDocxText(entry.blob);
        const populatedCount = countPopulatedFields(s, entry.answers);

        // Minimum 50 chars per populated field — template boilerplate + answers
        // should produce substantial text
        const minLength = populatedCount * 50;
        expect(
          text.length,
          `Document text is ${text.length} chars but expected at least ${minLength} (${populatedCount} populated fields × 50 chars)`,
        ).toBeGreaterThanOrEqual(minLength);
      });

      // 8. Table completeness
      const tableKeys = fieldKeysOfType(s, "table");
      const populatedTableKeys = tableKeys.filter((key) => {
        const raw = entry.answers[key];
        if (raw === undefined || raw === "") return false;
        try {
          const parsed = JSON.parse(String(raw)) as {
            rows?: unknown[];
          };
          return Array.isArray(parsed.rows) && parsed.rows.length > 0;
        } catch {
          return false;
        }
      });

      if (populatedTableKeys.length > 0) {
        it("includes at least one cell value from each table row in the output", async () => {
          const text = await extractDocxText(entry.blob);

          for (const key of populatedTableKeys) {
            const raw = entry.answers[key];
            const tableData = JSON.parse(String(raw)) as {
              rows: Record<string, string | number | boolean>[];
            };

            for (let rowIdx = 0; rowIdx < tableData.rows.length; rowIdx++) {
              const row = tableData.rows[rowIdx];
              const cellValues = Object.entries(row)
                .filter(([k]) => k !== "_rowId")
                .map(([, v]) => {
                  // Booleans render as Yes/No
                  if (typeof v === "boolean") return v ? "Yes" : "No";
                  return String(v);
                })
                .filter((v) => v.length > 0);

              if (cellValues.length === 0) continue;

              const found = cellValues.some((val) => text.includes(val));
              expect(
                found,
                `Table "${key}" row ${rowIdx}: expected at least one cell value in output. Values tried: ${cellValues.join(", ")}`,
              ).toBe(true);
            }
          }
        });
      }
    },
  );
});

// ---------------------------------------------------------------------------
// LLM-gated coherence tests (skipped in CI)
// ---------------------------------------------------------------------------

describe.skipIf(process.env.RUN_LLM_TESTS !== "true")(
  "Suite 2c (LLM): AI-assisted coherence review",
  () => {
    describe.each(docxSchemas.map((s) => [s.id, s]))(
      "%s",
      (_id, _schema) => {
        // 9. LLM coherence review — have an LLM read the generated document
        // and flag any passages that feel disjointed, contradictory, or
        // obviously machine-generated (broken mid-sentence, repeated phrases,
        // tonal inconsistency between sections).
        it.todo(
          "LLM coherence review: document reads as a unified whole with no disjointed passages",
        );

        // 10. LLM answer-to-output consistency — provide the LLM with the
        // answer map and the generated document text, and ask it to verify
        // that every answer is faithfully represented (no transpositions,
        // truncations, or semantic distortions).
        it.todo(
          "LLM answer-to-output consistency: all answer values are faithfully represented in the document",
        );
      },
    );
  },
);
