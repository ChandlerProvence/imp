import { beforeEach, describe, expect, it, vi } from "vitest";
import PizZip from "pizzip";

vi.mock("./generateDocx", () => ({ generateDocxBlob: vi.fn() }));
vi.mock("../utils/fileSave", () => ({ saveFile: vi.fn() }));

import { downloadAllAsZip, formatDocErrors } from "./downloadAll";
import { generateDocxBlob } from "./generateDocx";
import { saveFile } from "../utils/fileSave";
import { appError, isAppErrorException } from "../errors";
import { createMockSchema } from "../test/mocks";

const generate = vi.mocked(generateDocxBlob);
const save = vi.mocked(saveFile);

async function savedZip(): Promise<{ zip: PizZip; filename: string }> {
  const { blob, filename } = save.mock.calls[0][0];
  return { zip: new PizZip(await blob.arrayBuffer()), filename };
}

function docxSchema(id: string, title: string, extra: object = {}) {
  return createMockSchema({ id, title, docx_template: `${id}.docx`, ...extra });
}

describe("formatDocErrors", () => {
  it("formats one bullet per error with message and indented detail", () => {
    const errors = [
      { title: "Doc A", error: appError("generation.render", { detail: "bad tag" }) },
      { title: "Doc B", error: appError("generation.render", { detail: "missing loop" }) },
    ];
    expect(formatDocErrors(errors)).toBe(
      "• Doc A: The Word document couldn't be generated from the template.\n  bad tag\n" +
        "• Doc B: The Word document couldn't be generated from the template.\n  missing loop",
    );
  });

  it("returns an empty string for no errors", () => {
    expect(formatDocErrors([])).toBe("");
  });
});

describe("downloadAllAsZip", () => {
  beforeEach(() => {
    generate.mockReset();
    save.mockReset();
    save.mockResolvedValue(true);
    generate.mockImplementation(async (schema) => new Blob([`docx:${schema.id}`]));
  });

  it("zips one .docx per schema under the resolved filename", async () => {
    const schemas = [
      docxSchema("a", "Doc A"),
      docxSchema("b", "Doc B", { output_filename: "Report {{s.name}}, {{s.missing}}" }),
    ];
    const result = await downloadAllAsZip(schemas, { "s.name": "Acme" }, "My Set", undefined, "sess-1");

    expect(result).toEqual({ errors: [], successCount: 2 });
    expect(generate).toHaveBeenCalledWith(schemas[0], { "s.name": "Acme" }, "sess-1");
    const { zip } = await savedZip();
    expect(Object.keys(zip.files).sort()).toEqual(["Doc A.docx", "Report Acme DRAFT.docx"]);
    expect(zip.file("Doc A.docx")!.asText()).toBe("docx:a");
  });

  it("includes output_template-only schemas as substituted markdown", async () => {
    const schema = createMockSchema({ id: "md", title: "Notes", output_template: "Hello {{s.name}}" });
    await downloadAllAsZip([schema], { "s.name": "World" }, "Set");
    expect(generate).not.toHaveBeenCalled();
    const { zip } = await savedZip();
    expect(Object.keys(zip.files)).toEqual(["Notes.md"]);
    expect(zip.file("Notes.md")!.asText()).toBe("Hello World");
  });

  it("counts a schema with no template as a success but adds no entry", async () => {
    const result = await downloadAllAsZip([docxSchema("a", "Doc A"), createMockSchema({ id: "x", title: "Empty" })], {}, "Set");
    expect(result.successCount).toBe(2);
    const { zip } = await savedZip();
    expect(Object.keys(zip.files)).toEqual(["Doc A.docx"]);
  });

  it("names the zip from the sanitized set name plus a timestamp", async () => {
    await downloadAllAsZip([docxSchema("a", "Doc A")], {}, "  Shipping/Hub: #1  ");
    const { filename, zip } = await savedZip();
    expect(filename).toMatch(/^ShippingHub 1 \d{4}-\d{2}-\d{2}T\d{4}\.zip$/);
    expect(zip).toBeDefined();
    expect(save.mock.calls[0][0].types).toEqual([
      { description: "ZIP archives", accept: { "application/zip": [".zip"] } },
    ]);
  });

  it("reports a failing member and still ships the others", async () => {
    generate.mockImplementation(async (schema) => {
      if (schema.id === "b") throw new Error("template exploded");
      return new Blob([`docx:${schema.id}`]);
    });
    const schemas = [docxSchema("a", "Doc A"), docxSchema("b", "Doc B"), docxSchema("c", "Doc C")];
    const result = await downloadAllAsZip(schemas, {}, "Set");

    expect(result.successCount).toBe(2);
    expect(result.errors).toHaveLength(1);
    expect(result.errors[0].title).toBe("Doc B");
    // An unrecognized Error stays "unknown" even with the generation domain hint
    expect(result.errors[0].error.kind).toBe("unknown");
    expect(result.errors[0].error.detail).toContain("template exploded");
    expect(result.errors[0].error.context).toMatchObject({ schema: "Doc B" });
    const { zip } = await savedZip();
    expect(Object.keys(zip.files).sort()).toEqual(["Doc A.docx", "Doc C.docx"]);
  });

  it("throws generation.render and saves nothing when every member fails", async () => {
    generate.mockRejectedValue(new Error("nope"));
    const err = await downloadAllAsZip([docxSchema("a", "Doc A"), docxSchema("b", "Doc B")], {}, "Set").catch((e) => e);
    expect(isAppErrorException(err)).toBe(true);
    expect(err.appError.kind).toBe("generation.render");
    expect(err.appError.detail).toContain("All documents failed to generate:");
    expect(err.appError.detail).toContain("• Doc A:");
    expect(err.appError.detail).toContain("• Doc B:");
    expect(save).not.toHaveBeenCalled();
  });

  it("resolves table aliases per schema before generating", async () => {
    const aliases = new Map([["b", { "items__b.rows": "items.rows" }]]);
    const answers = { "items.rows": "[]", "items__b.rows": '[{"x":1}]' };
    await downloadAllAsZip([docxSchema("a", "Doc A"), docxSchema("b", "Doc B")], answers, "Set", aliases);
    expect(generate.mock.calls[0][1]).toBe(answers);
    expect(generate.mock.calls[1][1]).toEqual({ ...answers, "items.rows": '[{"x":1}]' });
  });

  it("keeps both documents when two members resolve to the same filename", async () => {
    const result = await downloadAllAsZip([docxSchema("a", "Same"), docxSchema("b", "Same")], {}, "Set");
    expect(result.successCount).toBe(2);
    const { zip } = await savedZip();
    expect(Object.keys(zip.files).sort()).toEqual(["Same (2).docx", "Same.docx"]);
  });

  it("numbers every repeat of a filename", async () => {
    await downloadAllAsZip([docxSchema("a", "Same"), docxSchema("b", "Same"), docxSchema("c", "Same")], {}, "Set");
    const { zip } = await savedZip();
    expect(Object.keys(zip.files).sort()).toEqual(["Same (2).docx", "Same (3).docx", "Same.docx"]);
  });
});
