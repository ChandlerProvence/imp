/**
 * Lightweight inline image embedding for Docxtemplater-rendered .docx files.
 *
 * Instead of depending on a third-party image module (stale, deprecated deps),
 * this module directly injects image binaries into the PizZip archive and
 * replaces placeholder tags with Word-compliant `<w:drawing>` XML.
 *
 * The approach:
 * 1. Add the image blob as `word/media/imageN.ext` in the zip
 * 2. Register the relationship in `word/_rels/document.xml.rels`
 * 3. Replace `{{TAG}}` in `word/document.xml` with a `<w:drawing>` inline element
 *
 * All of this happens AFTER Docxtemplater renders (so we don't conflict with
 * its tag parser) — the placeholder tags survive rendering via `nullGetter`.
 */

import type PizZip from "pizzip";

/** EMU per inch (English Metric Units). */
const EMU_PER_INCH = 914400;

/** Default bounding box when no schema dimensions specified. */
const DEFAULT_MAX_WIDTH_IN = 6.5;
const DEFAULT_MAX_HEIGHT_IN = 4;

/** Image data prepared for embedding. */
export interface ImageData {
  /** The template tag name (e.g., "FIGURE_4_1"). */
  tag: string;
  /** Raw image bytes. */
  data: Uint8Array;
  /** MIME type (e.g., "image/png"). */
  mimeType: string;
  /** File extension without dot (e.g., "png"). */
  extension: string;
  /** Intrinsic pixel width. */
  naturalWidth: number;
  /** Intrinsic pixel height. */
  naturalHeight: number;
  /** Max display width in inches from schema. */
  maxWidthInches: number;
  /** Max display height in inches from schema. */
  maxHeightInches: number;
}

/** Map MIME types to file extensions. */
function mimeToExt(mime: string): string {
  const map: Record<string, string> = {
    "image/png": "png",
    "image/jpeg": "jpeg",
    "image/jpg": "jpeg",
    "image/gif": "gif",
    "image/svg+xml": "svg",
    "image/webp": "webp",
    "image/bmp": "bmp",
    "image/tiff": "tiff",
  };
  return map[mime] ?? "png";
}

/** Map file extension to the OOXML content type. */
function extToContentType(ext: string): string {
  const map: Record<string, string> = {
    png: "image/png",
    jpeg: "image/jpeg",
    gif: "image/gif",
    svg: "image/svg+xml",
    webp: "image/webp",
    bmp: "image/bmp",
    tiff: "image/tiff",
  };
  return map[ext] ?? "image/png";
}

/**
 * Compute display dimensions (in EMU) that fit within the bounding box
 * while preserving aspect ratio. Does NOT upscale.
 */
function computeDisplaySize(
  naturalWidth: number,
  naturalHeight: number,
  maxWidthIn: number,
  maxHeightIn: number,
): { cx: number; cy: number } {
  // Assume 96 DPI for pixel→inch conversion (standard screen DPI)
  const DPI = 96;
  const naturalWidthIn = naturalWidth / DPI;
  const naturalHeightIn = naturalHeight / DPI;

  let displayWidthIn = naturalWidthIn;
  let displayHeightIn = naturalHeightIn;

  // Scale down if wider than box
  if (displayWidthIn > maxWidthIn) {
    const scale = maxWidthIn / displayWidthIn;
    displayWidthIn = maxWidthIn;
    displayHeightIn *= scale;
  }

  // Scale down if taller than box
  if (displayHeightIn > maxHeightIn) {
    const scale = maxHeightIn / displayHeightIn;
    displayHeightIn = maxHeightIn;
    displayWidthIn *= scale;
  }

  return {
    cx: Math.round(displayWidthIn * EMU_PER_INCH),
    cy: Math.round(displayHeightIn * EMU_PER_INCH),
  };
}

/**
 * Find the next available media index by scanning existing word/media/ files.
 */
function nextMediaIndex(zip: PizZip): number {
  let max = 0;
  for (const name of Object.keys(zip.files)) {
    const m = name.match(/^word\/media\/image(\d+)\./);
    if (m) max = Math.max(max, parseInt(m[1], 10));
  }
  return max + 1;
}

/**
 * Find the next available relationship ID in word/_rels/document.xml.rels.
 */
function nextRelId(relsXml: string): number {
  let max = 0;
  const re = /Id="rId(\d+)"/g;
  let m;
  while ((m = re.exec(relsXml)) !== null) {
    max = Math.max(max, parseInt(m[1], 10));
  }
  return max + 1;
}

/**
 * Build the `<w:drawing>` XML for an inline image.
 * Uses a self-contained inline drawing element that Word renders as an
 * in-line image at the specified dimensions.
 */
function buildDrawingXml(
  relId: string,
  docPrId: number,
  cx: number,
  cy: number,
  description: string,
): string {
  return (
    `<w:drawing>` +
    `<wp:inline distT="0" distB="0" distL="0" distR="0">` +
    `<wp:extent cx="${cx}" cy="${cy}"/>` +
    `<wp:docPr id="${docPrId}" name="${description}"/>` +
    `<a:graphic>` +
    `<a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">` +
    `<pic:pic>` +
    `<pic:nvPicPr>` +
    `<pic:cNvPr id="${docPrId}" name="${description}"/>` +
    `<pic:cNvPicPr/>` +
    `</pic:nvPicPr>` +
    `<pic:blipFill>` +
    `<a:blip r:embed="${relId}"/>` +
    `<a:stretch><a:fillRect/></a:stretch>` +
    `</pic:blipFill>` +
    `<pic:spPr>` +
    `<a:xfrm><a:off x="0" y="0"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm>` +
    `<a:prstGeom prst="rect"><a:avLst/></a:prstGeom>` +
    `</pic:spPr>` +
    `</pic:pic>` +
    `</a:graphicData>` +
    `</a:graphic>` +
    `</wp:inline>` +
    `</w:drawing>`
  );
}

/**
 * Embed images into a rendered .docx PizZip archive.
 *
 * Call this AFTER `doc.render()` — the image tags survive as literal text
 * via the `nullGetter` (or are injected as rawXml). This function replaces
 * each `{{TAG}}` occurrence in word/document.xml with a `<w:drawing>`.
 *
 * Mutates the zip in-place.
 */
export function embedImages(
  zip: PizZip,
  images: ImageData[],
): void {
  if (images.length === 0) return;

  const docXmlFile = zip.file("word/document.xml");
  if (!docXmlFile) return;

  let docXml = docXmlFile.asText();
  let relsXml = zip.file("word/_rels/document.xml.rels")?.asText() ?? "";
  let contentTypesXml = zip.file("[Content_Types].xml")?.asText() ?? "";

  // ── Ensure required namespace declarations on the root element ────────
  // Templates that have no existing drawings won't have the wp:, a:, pic:,
  // or r: namespace prefixes declared. Without them, Word rejects the file
  // as corrupt when it encounters our injected <w:drawing> elements.
  const requiredNs: [string, string][] = [
    ["xmlns:wp", "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"],
    ["xmlns:a", "http://schemas.openxmlformats.org/drawingml/2006/main"],
    ["xmlns:pic", "http://schemas.openxmlformats.org/drawingml/2006/picture"],
    ["xmlns:r", "http://schemas.openxmlformats.org/officeDocument/2006/relationships"],
  ];
  for (const [attr, uri] of requiredNs) {
    if (!docXml.includes(uri)) {
      // Insert the namespace into the opening <w:document ...> tag
      docXml = docXml.replace("<w:document ", `<w:document ${attr}="${uri}" `);
    }
  }

  let mediaIdx = nextMediaIndex(zip);
  let relIdx = nextRelId(relsXml);
  // Word requires drawing ids to be unique within the document
  let docPrId = nextDocPrId(docXml);

  // Track which extensions we've already added to [Content_Types].xml
  const addedExtensions = new Set<string>();

  for (const img of images) {
    const ext = img.extension || mimeToExt(img.mimeType);
    const mediaPath = `word/media/image${mediaIdx}.${ext}`;
    const relId = `rId${relIdx}`;

    // 1. Add image to zip
    zip.file(mediaPath, img.data);

    // 2. Add relationship
    const newRel =
      `<Relationship Id="${relId}" ` +
      `Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" ` +
      `Target="media/image${mediaIdx}.${ext}"/>`;
    relsXml = relsXml.replace("</Relationships>", `${newRel}</Relationships>`);

    // 3. Ensure content type is registered
    if (!addedExtensions.has(ext) && !contentTypesXml.includes(`Extension="${ext}"`)) {
      const ct = extToContentType(ext);
      contentTypesXml = contentTypesXml.replace(
        "</Types>",
        `<Default Extension="${ext}" ContentType="${ct}"/></Types>`,
      );
      addedExtensions.add(ext);
    }

    // 4. Compute display size
    const { cx, cy } = computeDisplaySize(
      img.naturalWidth,
      img.naturalHeight,
      img.maxWidthInches || DEFAULT_MAX_WIDTH_IN,
      img.maxHeightInches || DEFAULT_MAX_HEIGHT_IN,
    );

    // 5. Build drawing XML
    const drawingXml = buildDrawingXml(relId, docPrId++, cx, cy, img.tag);

    // 6. Replace the tag in document.xml
    // After Docxtemplater rendering, the tag appears as literal text inside
    // <w:t>{{TAG}}</w:t>.
    const tagLiteralXml = `{{${img.tag}}}`
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
    docXml = replaceTagWithDrawing(docXml, tagLiteralXml, drawingXml);

    mediaIdx++;
    relIdx++;
  }

  // Write back modified files
  zip.file("word/document.xml", docXml);
  zip.file("word/_rels/document.xml.rels", relsXml);
  zip.file("[Content_Types].xml", contentTypesXml);
}

/** A run's opening tag through its `<w:t>` opening tag, with an optional `<w:rPr>` between. */
const TAG_RUN_PREFIX_RE = /^<w:r(?:\s[^>]*)?>(?:<w:rPr>[\s\S]*?<\/w:rPr>)?<w:t(?:\s[^>]*)?>$/;

/** `<w:t>` / `<w:t ...>` opening tags (not `<w:tab/>`, `<w:tbl>`, etc.). */
const T_OPEN_RE = /<w:t[\s>]/g;

/**
 * Replace the first occurrence of an image tag with a drawing.
 *
 * When the tag is the only text of its run (`<w:r>[<w:rPr>…</w:rPr>]<w:t>{{TAG}}</w:t></w:r>`)
 * the whole run is replaced. The run is found by walking back from the tag to
 * the nearest `<w:r>` opening, so the match can never start in an earlier run
 * or paragraph. Otherwise the drawing is spliced in by closing and reopening
 * the surrounding run around the tag.
 */
function replaceTagWithDrawing(docXml: string, tagXml: string, drawingXml: string): string {
  const at = docXml.indexOf(tagXml);
  if (at === -1) return docXml;
  const after = at + tagXml.length;

  const runStart = Math.max(docXml.lastIndexOf("<w:r>", at), docXml.lastIndexOf("<w:r ", at));
  // nosemgrep: nodejs_scan.javascript-dos-rule-regex_dos — TAG_RUN_PREFIX_RE is anchored with one lazy group and runs on a single-run slice; client-only, so worst case stalls the uploader's own tab
  const prefix = runStart === -1 ? "" : docXml.slice(runStart, at);
  const ownsRun =
    docXml.startsWith("</w:t></w:r>", after) &&
    !prefix.includes("</w:r>") &&
    (prefix.match(T_OPEN_RE) ?? []).length === 1 &&
    TAG_RUN_PREFIX_RE.test(prefix);

  if (ownsRun) {
    return docXml.slice(0, runStart) + `<w:r>${drawingXml}</w:r>` + docXml.slice(after + "</w:t></w:r>".length);
  }
  // Fallback: split the run around the tag (keeps surrounding text in place)
  return docXml.slice(0, at) + `</w:t></w:r><w:r>${drawingXml}</w:r><w:r><w:t>` + docXml.slice(after);
}

/** One past the highest `<wp:docPr id>` already in the document. */
function nextDocPrId(docXml: string): number {
  let max = 0;
  for (const m of docXml.matchAll(/<wp:docPr\s[^>]*\bid="(\d+)"/g)) {
    max = Math.max(max, Number(m[1]));
  }
  return max + 1;
}

/** Prepare an ImageData entry from a SessionImage + field schema info. */
export function prepareImageData(
  tag: string,
  blob: Uint8Array,
  mimeType: string,
  naturalWidth: number,
  naturalHeight: number,
  maxWidthInches?: number,
  maxHeightInches?: number,
): ImageData {
  return {
    tag,
    data: blob,
    mimeType,
    extension: mimeToExt(mimeType),
    naturalWidth,
    naturalHeight,
    maxWidthInches: maxWidthInches ?? DEFAULT_MAX_WIDTH_IN,
    maxHeightInches: maxHeightInches ?? DEFAULT_MAX_HEIGHT_IN,
  };
}
