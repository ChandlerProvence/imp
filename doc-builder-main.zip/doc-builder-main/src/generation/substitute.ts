import type { DocumentSchema, FieldDef } from "../schemas/types";
import { parseTableData } from "../engine/tableData";
import { isFieldRequired } from "../engine/fieldLookup";
import { formatDateForDisplay } from "../utils/dateFormat";

/**
 * Replace all `{{section_id.field_id}}` placeholders in a template
 * with formatted answer values from the session.
 *
 * Table fields use block syntax for row iteration:
 *   {{#section_id.field_id}}...{{/section_id.field_id}}
 * Within the block, {{.column_id}} references the current row's column value
 * and {{.#row_index}} provides a 1-based row number.
 */
export function substituteTemplate(
  template: string,
  answers: Record<string, string | number | boolean>,
  schema: DocumentSchema,
): string {
  // Phase 1: Process table blocks (before scalar placeholders)
  let result = processTableBlocks(template, answers, schema);

  // Phase 2: Process scalar placeholders (skip # and / prefixed keys)
  result = result.replace(/\{\{([^}#/][^}]*)\}\}/g, (_match, key: string) => {
    const trimmedKey = key.trim();
    const value = answers[trimmedKey];
    const fieldDef = getFieldDef(trimmedKey, schema);
    // Don't render raw JSON for table fields referenced as scalar
    if (fieldDef?.type === "table") {
      return "[Table]";
    }
    return formatValue(value, fieldDef, isFieldRequired(schema, trimmedKey));
  });

  return result;
}

/**
 * Process table iteration blocks: {{#section_id.field_id}}...{{/section_id.field_id}}
 * Within the block, {{.column_id}} references the current row's column value.
 * {{.#row_index}} provides 1-based row numbering.
 */
function processTableBlocks(
  template: string,
  answers: Record<string, string | number | boolean>,
  _schema: DocumentSchema,
): string {
  const blockRe = /\{\{#([^}]+)\}\}([\s\S]*?)\{\{\/\1\}\}/g;

  return template.replace(blockRe, (_match, key: string, body: string) => {
    const trimmedKey = key.trim();
    const tableData = parseTableData(answers[trimmedKey]);

    if (tableData.rows.length === 0) {
      return "*(No data)*";
    }

    return tableData.rows
      .map((row, index) => {
        let rowOutput = body;
        // Replace {{.column_id}} with cell values, {{.#row_index}} with 1-based index
        rowOutput = rowOutput.replace(
          /\{\{\.([^}]+)\}\}/g,
          (_m, col: string) => {
            const trimmedCol = col.trim();
            if (trimmedCol === "#row_index") return String(index + 1);
            const val = row[trimmedCol];
            if (val === undefined || val === null || val === "") return "";
            if (typeof val === "boolean") return val ? "Yes" : "No";
            return String(val);
          },
        );
        return rowOutput;
      })
      .join("");
  });
}

/** Look up the FieldDef for a namespaced key like "parties.is_mutual". */
function getFieldDef(
  key: string,
  schema: DocumentSchema,
): FieldDef | undefined {
  const [sectionId, fieldId] = key.split(".");
  const section = schema.sections.find((s) => s.id === sectionId);
  if (!section) return undefined;
  return section.fields.find((f) => f.id === fieldId);
}

/** Format a value for template output based on its field type. */
function formatValue(
  value: string | number | boolean | undefined,
  fieldDef: FieldDef | undefined,
  required: boolean = true,
): string {
  if (value === undefined || value === null || value === "") {
    // Required unfilled → visible placeholder; optional unfilled → blank
    return required ? "[Not provided]" : "";
  }
  if (fieldDef?.type === "boolean" || typeof value === "boolean") {
    return value ? "Yes" : "No";
  }
  if (fieldDef?.type === "date" && typeof value === "string") {
    return formatDateForDisplay(value, fieldDef.display_format ?? "MM-DD-YYYY");
  }
  return String(value);
}
