import { describe, it, expect } from "vitest";
import { substituteTemplate } from "./substitute";
import type { DocumentSchema } from "../schemas/types";

/** Minimal schema factory for tests. */
function makeSchema(
  fields: { sectionId: string; fieldId: string; type: string; required?: boolean }[],
): DocumentSchema {
  const sectionMap = new Map<string, { id: string; type: string; required: boolean }[]>();
  for (const f of fields) {
    const list = sectionMap.get(f.sectionId) ?? [];
    list.push({ id: f.fieldId, type: f.type, required: f.required ?? true });
    sectionMap.set(f.sectionId, list);
  }

  return {
    id: "test",
    title: "Test",
    version: 1,
    sections: [...sectionMap.entries()].map(([sId, flds]) => ({
      id: sId,
      title: sId,
      fields: flds.map((f) => ({
        id: f.id,
        label: f.id,
        type: f.type as any,
        required: f.required,
      })),
    })),
  };
}

// ---------------------------------------------------------------------------
// Scalar placeholders
// ---------------------------------------------------------------------------

describe("substituteTemplate — scalar", () => {
  const schema = makeSchema([
    { sectionId: "info", fieldId: "name", type: "string" },
    { sectionId: "info", fieldId: "count", type: "number" },
    { sectionId: "info", fieldId: "active", type: "boolean" },
  ]);

  it("replaces string placeholder with value", () => {
    const result = substituteTemplate(
      "Hello {{info.name}}!",
      { "info.name": "World" },
      schema,
    );
    expect(result).toBe("Hello World!");
  });

  it("replaces number placeholder", () => {
    const result = substituteTemplate(
      "Count: {{info.count}}",
      { "info.count": 42 },
      schema,
    );
    expect(result).toBe("Count: 42");
  });

  it("replaces boolean true with Yes", () => {
    const result = substituteTemplate(
      "Active: {{info.active}}",
      { "info.active": true },
      schema,
    );
    expect(result).toBe("Active: Yes");
  });

  it("replaces boolean false with No", () => {
    const result = substituteTemplate(
      "Active: {{info.active}}",
      { "info.active": false },
      schema,
    );
    expect(result).toBe("Active: No");
  });

  it("shows [Not provided] for missing required value", () => {
    const result = substituteTemplate("Name: {{info.name}}", {}, schema);
    expect(result).toBe("Name: [Not provided]");
  });

  it("shows [Not provided] for empty string on required field", () => {
    const result = substituteTemplate(
      "Name: {{info.name}}",
      { "info.name": "" },
      schema,
    );
    expect(result).toBe("Name: [Not provided]");
  });

  it("renders blank for missing optional field", () => {
    const optionalSchema = makeSchema([
      { sectionId: "info", fieldId: "nickname", type: "string", required: false },
    ]);
    const result = substituteTemplate(
      "Nickname: {{info.nickname}}",
      {},
      optionalSchema,
    );
    expect(result).toBe("Nickname: ");
  });

  it("renders blank for empty string on optional field", () => {
    const optionalSchema = makeSchema([
      { sectionId: "info", fieldId: "nickname", type: "string", required: false },
    ]);
    const result = substituteTemplate(
      "Nickname: {{info.nickname}}",
      { "info.nickname": "" },
      optionalSchema,
    );
    expect(result).toBe("Nickname: ");
  });

  it("handles multiple placeholders in same template", () => {
    const result = substituteTemplate(
      "{{info.name}} ({{info.count}})",
      { "info.name": "Alice", "info.count": 7 },
      schema,
    );
    expect(result).toBe("Alice (7)");
  });
});

// ---------------------------------------------------------------------------
// Table field as scalar reference
// ---------------------------------------------------------------------------

describe("substituteTemplate — table as scalar", () => {
  const schema = makeSchema([
    { sectionId: "data", fieldId: "items", type: "table" },
  ]);

  it("renders [Table] when a table field is referenced as scalar", () => {
    const tableJson = JSON.stringify({ rows: [{ col: "val" }] });
    const result = substituteTemplate(
      "Items: {{data.items}}",
      { "data.items": tableJson },
      schema,
    );
    expect(result).toBe("Items: [Table]");
  });
});

// ---------------------------------------------------------------------------
// Table block iteration
// ---------------------------------------------------------------------------

describe("substituteTemplate — table blocks", () => {
  const schema = makeSchema([
    { sectionId: "data", fieldId: "items", type: "table" },
    { sectionId: "info", fieldId: "name", type: "string" },
  ]);

  it("renders *(No data)* for empty table", () => {
    const tableJson = JSON.stringify({ rows: [] });
    const template = "{{#data.items}}Row: {{.col}}\n{{/data.items}}";
    const result = substituteTemplate(
      template,
      { "data.items": tableJson },
      schema,
    );
    expect(result).toBe("*(No data)*");
  });

  it("iterates rows and substitutes column values", () => {
    const tableJson = JSON.stringify({
      rows: [
        { name: "Alice", role: "Dev" },
        { name: "Bob", role: "PM" },
      ],
    });
    const template = "{{#data.items}}{{.name}} - {{.role}}\n{{/data.items}}";
    const result = substituteTemplate(
      template,
      { "data.items": tableJson },
      schema,
    );
    expect(result).toBe("Alice - Dev\nBob - PM\n");
  });

  it("substitutes {{.#row_index}} with 1-based index", () => {
    const tableJson = JSON.stringify({
      rows: [{ name: "A" }, { name: "B" }],
    });
    const template =
      "{{#data.items}}{{.#row_index}}. {{.name}}\n{{/data.items}}";
    const result = substituteTemplate(
      template,
      { "data.items": tableJson },
      schema,
    );
    expect(result).toBe("1. A\n2. B\n");
  });

  it("renders empty string for missing column values", () => {
    const tableJson = JSON.stringify({ rows: [{ name: "A" }] });
    const template = "{{#data.items}}{{.name}}|{{.missing}}{{/data.items}}";
    const result = substituteTemplate(
      template,
      { "data.items": tableJson },
      schema,
    );
    expect(result).toBe("A|");
  });

  it("renders boolean column value as Yes/No", () => {
    const tableJson = JSON.stringify({ rows: [{ done: true }, { done: false }] });
    const template = "{{#data.items}}{{.done}}\n{{/data.items}}";
    const result = substituteTemplate(
      template,
      { "data.items": tableJson },
      schema,
    );
    expect(result).toBe("Yes\nNo\n");
  });

  it("processes table block and scalar placeholders together", () => {
    const tableJson = JSON.stringify({ rows: [{ item: "X" }] });
    const template =
      "Author: {{info.name}}\n{{#data.items}}* {{.item}}{{/data.items}}";
    const result = substituteTemplate(
      template,
      { "info.name": "Charlie", "data.items": tableJson },
      schema,
    );
    expect(result).toBe("Author: Charlie\n* X");
  });
});
