import mammoth from "mammoth";

/**
 * Convert a generated .docx Blob into an HTML string for inline preview.
 *
 * Uses mammoth to produce a lightweight HTML representation of the Word
 * document — suitable for display in a prose container but not a pixel-perfect
 * replica of the final Word layout.
 */
export async function docxToHtmlPreview(blob: Blob): Promise<string> {
  const buffer = await blob.arrayBuffer();
  const result = await mammoth.convertToHtml({ arrayBuffer: buffer });
  return result.value;
}
