import { describe, it, expect, beforeEach } from "vitest";
import Anthropic from "@anthropic-ai/sdk";
import {
  AppErrorException,
  appError,
  appErrorException,
  isAbortError,
  isRetryable,
  toAppError,
  toAppErrorException,
} from "./index";
import { clearRecentErrors, getRecentErrors } from "./recordError";
import { interpolate } from "./catalog";

beforeEach(() => clearRecentErrors());

describe("toAppError", () => {
  it("passes an AppErrorException through unchanged", () => {
    const thrown = appErrorException("file.encrypted-pdf", { context: { fileName: "a.pdf" } });
    expect(toAppError(thrown)).toBe(thrown.appError);
  });

  it("merges caller context into an AppErrorException without overriding the source's", () => {
    const thrown = appErrorException("ai.model-unavailable", { context: { model: "m1" } });
    const out = toAppError(thrown, { context: { model: "other", fileName: "x.docx" } });
    expect(out.context).toEqual({ model: "m1", fileName: "x.docx" });
    expect(out.message).toContain("m1");
  });

  it("falls back to `unknown` and keeps the raw message as detail", () => {
    const out = toAppError(new Error("kaboom"));
    expect(out.kind).toBe("unknown");
    expect(out.domain).toBe("unknown");
    expect(out.detail).toBe("kaboom");
    expect(out.title).toBeTruthy();
  });

  it("handles non-Error values", () => {
    expect(toAppError("plain string").detail).toBe("plain string");
    expect(toAppError({ weird: true }).detail).toBe('{"weird":true}');
    expect(toAppError(undefined).detail).toBe("");
  });

  it("prefers the hinted domain's classifier", () => {
    // A Dexie-style error that also carries an HTTP-like status: without a
    // hint the db classifier (registered first) wins; with an "ai" hint the AI
    // classifier is consulted first.
    const err = Object.assign(new Error("x"), { name: "QuotaExceededError", status: 500 });
    expect(toAppError(err).kind).toBe("db.quota");
    expect(toAppError(err, { domain: "ai" }).kind).toBe("ai.server");
  });

  it("interpolates context into catalog text", () => {
    const out = toAppError(Object.assign(new Error("not found"), { status: 404 }), {
      domain: "ai",
      context: { model: "claude-x" },
    });
    expect(out.kind).toBe("ai.model-unavailable");
    expect(out.message).toBe("The AI model claude-x is no longer available on the proxy.");
  });

  it("drops placeholders with no value cleanly", () => {
    const out = appError("ai.model-unavailable");
    expect(out.message).toBe("The AI model is no longer available on the proxy.");
  });
});

describe("recordError", () => {
  it("records each distinct error exactly once", () => {
    const raw = new Error("boom");
    toAppError(raw);
    toAppError(raw);
    const wrapped = toAppErrorException(raw);
    toAppError(wrapped);
    expect(getRecentErrors()).toHaveLength(1);
  });

  it("records errors built from a kind", () => {
    appError("db.quota");
    expect(getRecentErrors().map((e) => e.kind)).toEqual(["db.quota"]);
  });
});

describe("AppErrorException", () => {
  it("is an Error whose message is the user-facing message", () => {
    const e = appErrorException("ai.no-key");
    expect(e).toBeInstanceOf(Error);
    expect(e).toBeInstanceOf(AppErrorException);
    expect(e.message).toBe(e.appError.message);
  });
});

describe("helpers", () => {
  it("isRetryable follows the catalog and does not record", () => {
    expect(isRetryable(Object.assign(new Error(""), { status: 503 }), "ai")).toBe(true);
    expect(isRetryable(Object.assign(new Error(""), { status: 401 }), "ai")).toBe(false);
    expect(getRecentErrors()).toHaveLength(0);
  });

  it("isAbortError recognises DOM and SDK aborts", () => {
    expect(isAbortError(new DOMException("Aborted", "AbortError"))).toBe(true);
    expect(isAbortError(Object.assign(new Error(""), { name: "APIUserAbortError" }))).toBe(true);
    expect(isAbortError(new Anthropic.APIUserAbortError())).toBe(true);
    expect(isAbortError(new Error("x"))).toBe(false);
  });

  it("interpolate tidies spacing around removed placeholders", () => {
    expect(interpolate("A {x} b.", {})).toBe("A b.");
    expect(interpolate("A {x}.", {})).toBe("A.");
  });
});
