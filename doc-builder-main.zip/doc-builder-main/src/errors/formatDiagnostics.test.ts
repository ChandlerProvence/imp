import { describe, it, expect, beforeEach } from "vitest";
import { buildDiagnosticsData, buildDiagnosticsReport } from "./formatDiagnostics";
import { clearRecentErrors } from "./recordError";
import { appError } from "./index";

beforeEach(() => clearRecentErrors());

describe("buildDiagnosticsData", () => {
  it("returns the correct type and version", () => {
    const data = buildDiagnosticsData();
    expect(data.type).toBe("doc-builder-diagnostics");
    expect(data.version).toBe(1);
    expect(data.capturedAt).toBeTruthy();
  });

  it("returns empty errors array when buffer is empty", () => {
    expect(buildDiagnosticsData().errors).toEqual([]);
  });

  it("includes recent errors when present", () => {
    appError("ai.auth");
    appError("db.quota");
    const data = buildDiagnosticsData();
    expect(data.errors).toHaveLength(2);
    expect(data.errors[0].kind).toBe("ai.auth");
    expect(data.errors[1].kind).toBe("db.quota");
  });

  it("includes context on errors that have it", () => {
    appError("ai.model-unavailable", { context: { model: "claude-x" } });
    const data = buildDiagnosticsData();
    expect(data.errors[0].context).toEqual({ model: "claude-x" });
  });

  it("omits context when error has none", () => {
    appError("unknown");
    const data = buildDiagnosticsData();
    expect(data.errors[0].context).toBeUndefined();
  });

  it("includes schemaId in environment when provided", () => {
    const data = buildDiagnosticsData({ schemaId: "nda" });
    expect(data.environment.schemaId).toBe("nda");
  });

  it("omits optional environment fields when not provided", () => {
    const data = buildDiagnosticsData();
    expect(data.environment.schemaId).toBeUndefined();
    expect(data.environment.endpoint).toBeUndefined();
    expect(data.environment.featureFlags).toBeUndefined();
  });

  it("includes endpoint and featureFlags when provided", () => {
    const data = buildDiagnosticsData({
      endpoint: { id: "non-cui", label: "Proprietary (IL2)", baseUrl: "https://proxy.example.com" },
      featureFlags: { promptCaching: true, effort: false },
    });
    expect(data.environment.endpoint?.label).toBe("Proprietary (IL2)");
    expect(data.environment.featureFlags?.effort).toBe(false);
  });

  it("includes url and userAgent in environment", () => {
    const data = buildDiagnosticsData();
    expect(data.environment.url).toBeTruthy();
    expect(data.environment.userAgent).toBeTruthy();
  });

  it("includes the build identity, 'dev' outside CI", () => {
    expect(buildDiagnosticsData().environment.build.sha).toBe("dev");
  });
});

describe("buildDiagnosticsReport", () => {
  it("contains the human-readable header", () => {
    const report = buildDiagnosticsReport();
    expect(report).toContain("Doc Builder Diagnostic Report");
    expect(report).toContain("Captured:");
    expect(report).toContain("Build: dev");
    expect(report).toContain("0 errors");
  });

  it("contains a parseable JSON block", () => {
    appError("ai.network");
    const report = buildDiagnosticsReport();
    // Extract the JSON between the code fences
    const match = report.match(/```json\n([\s\S]+?)\n```/);
    expect(match).toBeTruthy();
    const parsed = JSON.parse(match![1]);
    expect(parsed.type).toBe("doc-builder-diagnostics");
    expect(parsed.errors).toHaveLength(1);
    expect(parsed.errors[0].kind).toBe("ai.network");
  });

  it("pluralizes correctly for 1 error", () => {
    appError("unknown");
    const report = buildDiagnosticsReport();
    expect(report).toContain("1 error\n");
  });
});
