import { describe, it, expect } from "vitest";
import { fileClassifier } from "./file";

const named = (name: string, message = "") => Object.assign(new Error(message), { name });

describe("fileClassifier", () => {
  it("maps pdf.js exceptions by name", () => {
    expect(fileClassifier.classify(named("PasswordException", "No password given"))?.kind).toBe("file.encrypted-pdf");
    expect(fileClassifier.classify(named("InvalidPDFException", "Invalid PDF structure."))?.kind).toBe("file.corrupt-pdf");
    expect(fileClassifier.classify(named("MissingPDFException"))?.kind).toBe("file.corrupt-pdf");
  });

  it("maps zip/mammoth failures to corrupt-docx", () => {
    expect(fileClassifier.classify(new Error("End of data reached (data length = 0, asked index = 4). Corrupted zip ?"))?.kind).toBe(
      "file.corrupt-docx",
    );
    expect(fileClassifier.classify(new Error("Could not find file in options"))?.kind).toBe("file.corrupt-docx");
  });

  it("ignores unrelated errors", () => {
    expect(fileClassifier.classify(new Error("network down"))).toBeNull();
    expect(fileClassifier.classify(undefined)).toBeNull();
  });
});
