import { describe, it, expect } from "vitest";
import { aiClassifier, classifyHttpStatus } from "./ai";

describe("classifyHttpStatus", () => {
  it.each([
    [401, "", "ai.auth"],
    [403, "", "ai.auth"],
    [429, "", "ai.rate-limit"],
    [404, "", "ai.model-unavailable"],
    [408, "", "ai.timeout"],
    [504, "", "ai.timeout"],
    [400, "something malformed", "ai.bad-request"],
    [400, "prompt is too long: 210000 tokens > 200000 maximum", "ai.context-too-long"],
    [400, "input is too long for requested model", "ai.context-too-long"],
    [413, "", "ai.context-too-long"],
    [400, "model claude-4-6-opus does not exist", "ai.model-unavailable"],
    [400, "Invalid model name passed in model=foo", "ai.model-unavailable"],
    [500, "Internal Server Error", "ai.server"],
    [503, "", "ai.server"],
    [500, "litellm.NotFoundError: model_not_found", "ai.model-unavailable"],
  ] as const)("%i %j → %s", (status, body, kind) => {
    expect(classifyHttpStatus(status, body)).toBe(kind);
  });
});

describe("aiClassifier", () => {
  it("classifies anything with an HTTP status, not just SDK classes", () => {
    expect(aiClassifier.classify({ status: 401, message: "Unauthorized" })?.kind).toBe("ai.auth");
    expect(aiClassifier.classify(Object.assign(new Error("x"), { status: 503 }))?.kind).toBe("ai.server");
  });

  it("ignores status codes below 400", () => {
    expect(aiClassifier.classify({ status: 200 })).toBeNull();
  });

  it("recognises connection and timeout errors by name", () => {
    expect(aiClassifier.classify(Object.assign(new Error(""), { name: "APIConnectionError" }))?.kind).toBe("ai.network");
    expect(aiClassifier.classify(Object.assign(new Error(""), { name: "APIConnectionTimeoutError" }))?.kind).toBe("ai.timeout");
    expect(aiClassifier.classify(new DOMException("timed out", "TimeoutError"))?.kind).toBe("ai.timeout");
  });

  it("recognises browser fetch failures", () => {
    expect(aiClassifier.classify(new TypeError("Failed to fetch"))?.kind).toBe("ai.network");
    expect(aiClassifier.classify(new TypeError("NetworkError when attempting to fetch resource."))?.kind).toBe("ai.network");
    expect(aiClassifier.classify(new TypeError("x is not a function"))).toBeNull();
  });
});
