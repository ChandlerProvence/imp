import type { ErrorClassifier } from "../types";

/**
 * File-parsing library errors (pdf.js, JSZip/mammoth, SheetJS). Cases the
 * parsers can detect themselves (size, extension, no text) are thrown as
 * `appErrorException(...)` at the source and never reach this classifier.
 */

const ZIP_RE = /end of central directory|is this a zip file|corrupted zip|end of data reached|could not find (main )?document|could not find file in options/i;

export const fileClassifier: ErrorClassifier = {
  domain: "file",
  classify(err) {
    const name = err && typeof err === "object" && "name" in err ? String((err as { name: unknown }).name) : "";
    const message = err instanceof Error ? err.message : "";

    if (name === "PasswordException") return { kind: "file.encrypted-pdf" };
    if (name === "InvalidPDFException" || name === "MissingPDFException" || /invalid pdf structure/i.test(message)) {
      return { kind: "file.corrupt-pdf" };
    }
    if (ZIP_RE.test(message)) return { kind: "file.corrupt-docx" };
    return null;
  },
};
