import { describe, it, expect } from "vitest";
import { dbClassifier } from "./db";

const named = (name: string, extra: Record<string, unknown> = {}) =>
  Object.assign(new Error(name), { name }, extra);

describe("dbClassifier", () => {
  it("finds quota errors anywhere in the inner/cause chain", () => {
    expect(dbClassifier.classify(new DOMException("q", "QuotaExceededError"))?.kind).toBe("db.quota");
    expect(dbClassifier.classify(named("AbortError", { inner: named("QuotaExceededError") }))?.kind).toBe("db.quota");
    expect(dbClassifier.classify(named("BulkError", { cause: named("AbortError", { inner: named("QuotaExceededError") }) }))?.kind).toBe("db.quota");
  });

  it("prefers the specific inner cause over the OpenFailedError wrapper", () => {
    expect(dbClassifier.classify(named("OpenFailedError", { inner: named("MissingAPIError") }))?.kind).toBe("db.unavailable");
    expect(dbClassifier.classify(named("OpenFailedError", { inner: named("VersionError") }))?.kind).toBe("db.version");
  });

  it.each([
    ["DatabaseClosedError", "db.closed"],
    ["VersionError", "db.version"],
    ["UpgradeError", "db.version"],
    ["MissingAPIError", "db.unavailable"],
    ["OpenFailedError", "db.open-failed"],
  ])("%s → %s", (name, kind) => {
    expect(dbClassifier.classify(named(name))?.kind).toBe(kind);
  });

  it("ignores plain aborts and unrelated errors", () => {
    expect(dbClassifier.classify(new DOMException("Aborted", "AbortError"))).toBeNull();
    expect(dbClassifier.classify(new Error("x"))).toBeNull();
    expect(dbClassifier.classify(null)).toBeNull();
  });

  it("does not loop forever on cyclic chains", () => {
    const a: Record<string, unknown> = { name: "AbortError" };
    a.inner = a;
    expect(dbClassifier.classify(a)).toBeNull();
  });
});
