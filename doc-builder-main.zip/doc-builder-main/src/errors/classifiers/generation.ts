import type { ErrorClassifier } from "../types";

/**
 * Docxtemplater errors. These carry `properties.id` (e.g. "multi_error",
 * "unclosed_tag"), which no other library uses. PizZip load failures are
 * wrapped as `generation.template-damaged` at the source in `generateDocx.ts`
 * because their messages are indistinguishable from JSZip upload errors.
 */
export const generationClassifier: ErrorClassifier = {
  domain: "generation",
  classify(err) {
    if (!err || typeof err !== "object" || !("properties" in err)) return null;
    const props = (err as { properties?: unknown }).properties;
    if (props && typeof props === "object" && "id" in props) {
      return { kind: "generation.render" };
    }
    return null;
  },
};
