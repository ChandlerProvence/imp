import type { ErrorClassifier, ErrorKind } from "../types";

/**
 * AI service errors. Classifies by HTTP status and message/body text rather
 * than SDK error classes so it keeps working for proxy-translated or
 * OpenAI-format responses (provider portability — see CLAUDE.md). Duck-typed
 * on `status`, which every Anthropic/OpenAI SDK APIError carries.
 */

const MODEL_UNAVAILABLE_RE =
  /model[^.]{0,80}(not found|does not exist|not available|unavailable|no longer|invalid|unknown)|(invalid|unknown|no such) model|model_not_found/i;
const CONTEXT_TOO_LONG_RE =
  /prompt is too long|context.{0,10}(length|window)|maximum context|too many (input )?tokens|input is too long|request too large/i;
const NETWORK_RE = /failed to fetch|networkerror|network error|load failed|connection error|ECONNRESET|ERR_NETWORK/i;
// The SDK's APIConnectionError / APIConnectionTimeoutError keep name "Error"
// and no status (and class names are minified in production), so their fixed
// messages are the only reliable signal.
const SDK_CONNECTION_RE = /^Connection error\.?$/;
const SDK_TIMEOUT_RE = /^Request timed out\.?$/;

/** Map an HTTP status (+ response body text) to an AI error kind. */
export function classifyHttpStatus(status: number, body = ""): ErrorKind {
  if (status === 401 || status === 403) return "ai.auth";
  if (status === 429) return "ai.rate-limit";
  if (status === 404) return "ai.model-unavailable";
  if (status === 408 || status === 504) return "ai.timeout";
  if (status === 400 || status === 413 || status === 422) {
    if (CONTEXT_TOO_LONG_RE.test(body)) return "ai.context-too-long";
    if (MODEL_UNAVAILABLE_RE.test(body)) return "ai.model-unavailable";
    return status === 413 ? "ai.context-too-long" : "ai.bad-request";
  }
  if (status >= 500) {
    // LiteLLM reports some upstream model errors as 500 with a descriptive body
    if (MODEL_UNAVAILABLE_RE.test(body)) return "ai.model-unavailable";
    if (CONTEXT_TOO_LONG_RE.test(body)) return "ai.context-too-long";
    return "ai.server";
  }
  return "ai.bad-request";
}

function errorName(err: unknown): string {
  return err && typeof err === "object" && "name" in err ? String((err as { name: unknown }).name) : "";
}

function errorMessage(err: unknown): string {
  if (err instanceof Error) return err.message;
  if (err && typeof err === "object" && "message" in err) return String((err as { message: unknown }).message);
  return "";
}

export const aiClassifier: ErrorClassifier = {
  domain: "ai",
  classify(err) {
    const name = errorName(err);
    const message = errorMessage(err);

    // SDK APIError (and anything shaped like one) — has a numeric status
    const status = err && typeof err === "object" && "status" in err ? (err as { status: unknown }).status : undefined;
    if (typeof status === "number" && status >= 400) {
      return { kind: classifyHttpStatus(status, message) };
    }

    // SDK connection errors carry no status
    if (name === "APIConnectionTimeoutError" || SDK_TIMEOUT_RE.test(message)) return { kind: "ai.timeout" };
    if (name === "APIConnectionError" || SDK_CONNECTION_RE.test(message)) return { kind: "ai.network" };
    if (name === "TimeoutError") return { kind: "ai.timeout" };

    // Browser fetch network failure
    if (err instanceof TypeError && NETWORK_RE.test(message)) return { kind: "ai.network" };

    return null;
  },
};
