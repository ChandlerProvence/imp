import { describe, it, expect } from "vitest";
import { generationClassifier } from "./generation";

describe("generationClassifier", () => {
  it("recognises Docxtemplater errors by properties.id", () => {
    const multi = Object.assign(new Error("Multi error"), { properties: { id: "multi_error", errors: [] } });
    const single = Object.assign(new Error("Unclosed tag"), { properties: { id: "unclosed_tag" } });
    expect(generationClassifier.classify(multi)?.kind).toBe("generation.render");
    expect(generationClassifier.classify(single)?.kind).toBe("generation.render");
  });

  it("ignores errors without Docxtemplater properties", () => {
    expect(generationClassifier.classify(new Error("x"))).toBeNull();
    expect(generationClassifier.classify(Object.assign(new Error("x"), { properties: {} }))).toBeNull();
    expect(generationClassifier.classify("x")).toBeNull();
  });
});
