import type { ErrorClassifier, ErrorKind } from "../types";

/**
 * IndexedDB / Dexie errors. Dexie wraps native DOMExceptions (e.g. an
 * `AbortError` whose `inner` is a `QuotaExceededError`), so the chain of
 * `inner` / `cause` is walked a few levels deep.
 */

const NAME_TO_KIND: Record<string, ErrorKind> = {
  QuotaExceededError: "db.quota",
  DatabaseClosedError: "db.closed",
  VersionError: "db.version",
  VersionChangeError: "db.version",
  UpgradeError: "db.version",
  MissingAPIError: "db.unavailable",
  OpenFailedError: "db.open-failed",
};

function names(err: unknown, depth = 0): string[] {
  if (!err || typeof err !== "object" || depth > 4) return [];
  const e = err as { name?: unknown; inner?: unknown; cause?: unknown };
  return [
    typeof e.name === "string" ? e.name : "",
    ...names(e.inner, depth + 1),
    ...names(e.cause, depth + 1),
  ];
}

export const dbClassifier: ErrorClassifier = {
  domain: "db",
  classify(err) {
    const chain = names(err);
    // Most specific cause wins: quota/missing API deep in the chain beat the
    // generic OpenFailedError/AbortError wrapper.
    if (chain.includes("QuotaExceededError")) return { kind: "db.quota" };
    if (chain.includes("MissingAPIError")) return { kind: "db.unavailable" };
    // Firefox private browsing rejects open() with InvalidStateError
    if (chain.includes("OpenFailedError") && chain.includes("InvalidStateError")) {
      return { kind: "db.unavailable" };
    }
    for (const name of [...chain].reverse()) {
      if (NAME_TO_KIND[name]) return { kind: NAME_TO_KIND[name] };
    }
    return null;
  },
};
