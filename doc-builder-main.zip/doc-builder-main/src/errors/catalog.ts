/**
 * All user-facing error wording lives here. `{placeholder}` tokens are filled
 * from `AppError.context`; any placeholder without a value is removed.
 *
 * To add a new error: add an entry here, teach the matching classifier in
 * `classifiers/` (or throw `appErrorException(kind)` at the source), and add
 * a fixture row to `classifiers.contract.test.ts`.
 */

import { CONTACT_EMAIL } from "../config/contact";

/** Who to contact about errors. The address lives in src/config/contact.ts. */
export const SUPPORT_CONTACT = `Winston T. Chu (${CONTACT_EMAIL})`;

const ADMIN = `If this keeps happening, copy the Error Report and send it to ${SUPPORT_CONTACT}.`;
const REPORT = `If that doesn't help, copy the Error Report and contact ${SUPPORT_CONTACT}.`;

export interface CatalogEntry {
  title: string;
  message: string;
  help?: string;
  retryable: boolean;
}

const entries = {
  // --- AI -------------------------------------------------------------------
  "ai.no-key": {
    title: "No API key",
    message: "No API key is configured for the AI service.",
    help: "Follow the instructions in Help → API Key Setup to get one.",
    retryable: false,
  },
  "ai.auth": {
    title: "AI key rejected",
    message: "Your API key was rejected — it may be expired or mistyped.",
    help: `Follow the instructions in Help → API Key Setup to get a new key. Manual entry and Word generation still work without AI. ${REPORT}`,
    retryable: false,
  },
  "ai.rate-limit": {
    title: "AI rate limit",
    message: "The AI service is rate limiting requests.",
    help: `Wait a moment and try again. ${REPORT}`,
    retryable: true,
  },
  "ai.model-unavailable": {
    title: "AI model unavailable",
    message: "The AI model {model} is no longer available on the proxy.",
    help: `Try again — Doc Builder switches to a replacement model when one is available — or pick a different model in Edit → Settings → AI Models. Manual entry and Word generation still work. ${REPORT}`,
    retryable: true,
  },
  "ai.context-too-long": {
    title: "Too much text for the AI",
    message: "The request is larger than the AI model can accept.",
    help: `Remove or shorten attached documents, or start a new conversation, and try again. ${REPORT}`,
    retryable: false,
  },
  "ai.bad-request": {
    title: "AI request rejected",
    message: "The AI service rejected the request.",
    help: ADMIN,
    retryable: false,
  },
  "ai.server": {
    title: "AI service error",
    message: "The AI service is having problems. Your work is saved.",
    help: `Try again in a few minutes. ${ADMIN}`,
    retryable: true,
  },
  "ai.network": {
    title: "Can't reach the AI service",
    message: "The AI service could not be reached.",
    help: `Check your network or VPN connection and try again. Manual entry and Word generation still work. ${REPORT}`,
    retryable: true,
  },
  "ai.timeout": {
    title: "AI service timed out",
    message: "The AI service did not respond within {seconds}s.",
    help: `The service may be overloaded or unavailable — try again. ${ADMIN}`,
    retryable: true,
  },

  "ai.bad-response": {
    title: "Couldn't read the AI's reply",
    message: "The AI's reply couldn't be understood ({what}).",
    help: `Try again, or rephrase the request. ${REPORT}`,
    retryable: true,
  },

  "ai.cui-in-proprietary": {
    title: "CUI document in Proprietary mode",
    message: "\"{fileName}\" is a CUI document and can't be used in Proprietary (IL2) mode.",
    help: "Remove it, or switch to CUI mode in Edit → Settings.",
    retryable: false,
  },
  "file.fetch-failed": {
    title: "Couldn't load document",
    message: "{fileName} couldn't be downloaded.",
    help: `Check your network connection and reload the page. ${REPORT}`,
    retryable: true,
  },

  // --- File parsing -----------------------------------------------------------
  "file.too-large": {
    title: "File too large",
    message: "{fileName} is {sizeMb} MB. The limit is {limitMb} MB.",
    help: `Split the file or remove unneeded pages and upload it again. ${REPORT}`,
    retryable: false,
  },
  "file.unsupported": {
    title: "Unsupported file type",
    message: "{fileName}: .{ext} files can't be read.",
    help: "Use .pdf, .docx, .xlsx, .xls, .csv, .txt, .json, or an image (.png, .jpg, .gif, .webp).",
    retryable: false,
  },
  "file.legacy-doc": {
    title: "Old Word format",
    message: "{fileName} is an old-style .doc file, which can't be read.",
    help: "Open it in Word and use File → Save As → Word Document (.docx), then upload the .docx.",
    retryable: false,
  },
  "file.corrupt-docx": {
    title: "Can't read Word file",
    message: "{fileName} couldn't be read — it may be corrupt, password-protected, or not really a .docx.",
    help: `Open it in Word, save a fresh copy without a password, and upload that. ${REPORT}`,
    retryable: false,
  },
  "file.encrypted-pdf": {
    title: "Password-protected PDF",
    message: "{fileName} is password-protected.",
    help: "Remove the password (e.g. print to a new PDF) and upload it again.",
    retryable: false,
  },
  "file.corrupt-pdf": {
    title: "Can't read PDF",
    message: "{fileName} couldn't be read — it may be corrupt or not really a PDF.",
    help: `Re-export or re-download the PDF and upload it again. ${REPORT}`,
    retryable: false,
  },
  "file.no-text": {
    title: "No selectable text",
    message: "{fileName} has no selectable text — it is probably a scanned image.",
    help: `Run OCR on it first (e.g. Adobe Acrobat → Scan & OCR), or upload the pages as images. ${REPORT}`,
    retryable: false,
  },
  "file.spreadsheet": {
    title: "Can't read spreadsheet",
    message: "{fileName} couldn't be read as a spreadsheet.",
    help: `Open it in Excel, save a fresh copy as .xlsx or .csv, and upload that. ${REPORT}`,
    retryable: false,
  },

  // --- IndexedDB --------------------------------------------------------------
  "db.quota": {
    title: "Browser storage is full",
    message: "Browser storage is full, so changes can't be saved.",
    help: `Export this session to keep a copy, then delete unused uploaded documents or old sessions to free space. ${REPORT}`,
    retryable: true,
  },
  "db.closed": {
    title: "Storage connection lost",
    message: "The connection to browser storage was closed, so changes can't be saved.",
    help: `Reload the page. If another Doc Builder tab is open, reload that one too. ${REPORT}`,
    retryable: false,
  },
  "db.version": {
    title: "Storage version mismatch",
    message: "Browser storage was created by a newer or older version of Doc Builder.",
    help: `Close other Doc Builder tabs and reload the page. ${REPORT}`,
    retryable: false,
  },
  "db.open-failed": {
    title: "Can't open browser storage",
    message: "Doc Builder couldn't open its browser storage.",
    help: `Reload the page. If that doesn't help, use "Clear data & reload" (this deletes saved sessions) or contact ${SUPPORT_CONTACT}.`,
    retryable: false,
  },
  "db.unavailable": {
    title: "Browser storage unavailable",
    message: "This browser isn't allowing Doc Builder to store data — usually because of private/InPrivate browsing or a storage policy.",
    help: "Open Doc Builder in a normal (non-private) browser window.",
    retryable: false,
  },
  "db.backup-invalid": {
    title: "Not a usable backup",
    message: "This file isn't a Doc Builder backup, or it's damaged.",
    help: `Choose a file saved with "Back up all data" (named doc-builder-backup-…json). Nothing in this browser was changed. ${REPORT}`,
    retryable: false,
  },
  "db.backup-newer-version": {
    title: "Backup is from a newer version",
    message: "This backup was made by a newer version of Doc Builder than the one running here.",
    help: `Reload the page to get the latest version, then restore again. Nothing in this browser was changed. ${REPORT}`,
    retryable: false,
  },

  // --- Word generation --------------------------------------------------------
  "generation.template-missing": {
    title: "Word template not found",
    message: "The Word template for {schema} couldn't be loaded.",
    help: `Reload the page and try again. ${ADMIN}`,
    retryable: true,
  },
  "generation.custom-template-missing": {
    title: "Custom template not installed",
    message: "The custom template {schema} isn't installed in this browser.",
    help: "Add it again from File › Manage Custom Templates (or load a progress file that includes it).",
    retryable: false,
  },
  "generation.template-damaged": {
    title: "Word template damaged",
    message: "The Word template for {schema} is damaged and can't be filled in.",
    help: `Report this to ${SUPPORT_CONTACT}.`,
    retryable: false,
  },
  "generation.render": {
    title: "Word generation failed",
    message: "The Word document couldn't be generated from the template.",
    help: ADMIN,
    retryable: false,
  },

  "generation.partial": {
    title: "Some documents failed",
    message: "The zip was downloaded, but {count} document(s) couldn't be generated: {titles}.",
    help: ADMIN,
    retryable: false,
  },

  // --- Fallback ---------------------------------------------------------------
  unknown: {
    title: "Something went wrong",
    message: "An unexpected error occurred.",
    help: ADMIN,
    retryable: false,
  },
} satisfies Record<string, CatalogEntry>;

export type ErrorKind = keyof typeof entries;

export const CATALOG: Record<ErrorKind, CatalogEntry> = entries;

/** Fill `{placeholder}` tokens from context; drop any that have no value. */
export function interpolate(text: string, context?: Record<string, string>): string {
  return text
    .replace(/\{(\w+)\}/g, (_, key: string) => context?.[key] ?? "")
    .replace(/\s{2,}/g, " ")
    .replace(/\s+([.,:])(?=\s|$)/g, "$1")
    .trim();
}
