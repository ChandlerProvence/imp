import { getRecentErrors, type RecordedError } from "./recordError";
import { getBuildInfo, type BuildInfo } from "../buildInfo";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface DiagnosticsReport {
  type: "doc-builder-diagnostics";
  version: 1;
  capturedAt: string;
  environment: {
    url: string;
    userAgent: string;
    build: BuildInfo;
    schemaId?: string;
    endpoint?: { id: string; label: string; baseUrl: string };
    featureFlags?: Record<string, boolean>;
    models?: DiagnosticsModel[];
  };
  errors: RecordedError[];
}

/** Resolved model per role, with where it came from (default/override/substituted/missing). */
export interface DiagnosticsModel {
  role: string;
  id: string;
  source: string;
  configured: string;
}

export interface DiagnosticsOptions {
  schemaId?: string;
  endpoint?: { id: string; label: string; baseUrl: string };
  featureFlags?: Record<string, boolean>;
  models?: DiagnosticsModel[];
}

// ---------------------------------------------------------------------------
// Builders
// ---------------------------------------------------------------------------

/** Build the structured diagnostics report object. */
export function buildDiagnosticsData(opts?: DiagnosticsOptions): DiagnosticsReport {
  const errors = getRecentErrors();

  const environment: DiagnosticsReport["environment"] = {
    url: window.location.href,
    userAgent: navigator.userAgent,
    build: getBuildInfo(),
  };
  if (opts?.schemaId) environment.schemaId = opts.schemaId;
  if (opts?.endpoint) environment.endpoint = opts.endpoint;
  if (opts?.featureFlags) environment.featureFlags = opts.featureFlags;
  if (opts?.models) environment.models = opts.models;

  return {
    type: "doc-builder-diagnostics",
    version: 1,
    capturedAt: new Date().toISOString(),
    environment,
    errors: [...errors],
  };
}

/** Format the report as a clipboard-ready string (header + fenced JSON). */
export function buildDiagnosticsReport(opts?: DiagnosticsOptions): string {
  const data = buildDiagnosticsData(opts);
  const count = data.errors.length;
  const ts = data.capturedAt.replace("T", " ").replace(/\.\d+Z$/, " UTC");

  const header = [
    "Doc Builder Diagnostic Report",
    `Captured: ${ts} | Build: ${data.environment.build.sha} | ${count} error${count !== 1 ? "s" : ""}`,
    "",
    "Paste the block below into a support request or AI assistant:",
    "",
  ].join("\n");

  return `${header}\`\`\`json\n${JSON.stringify(data, null, 2)}\n\`\`\``;
}
