import type { AppError } from "./types";

/**
 * Single feed of every normalized error. `toAppError()` calls this once per
 * error. Currently keeps a small in-memory ring buffer; the planned
 * "Copy diagnostics" report (docs/public/development-plan.md → Sustainment)
 * will read it via `getRecentErrors()`.
 */

const MAX_RECENT = 50;

export interface RecordedError {
  at: string;
  domain: AppError["domain"];
  kind: AppError["kind"];
  detail: string;
  context?: Record<string, string>;
}

const recent: RecordedError[] = [];

export function recordError(error: AppError): void {
  const entry: RecordedError = { at: new Date().toISOString(), domain: error.domain, kind: error.kind, detail: error.detail };
  if (error.context && Object.keys(error.context).length > 0) entry.context = error.context;
  recent.push(entry);
  if (recent.length > MAX_RECENT) recent.shift();
}

export function getRecentErrors(): readonly RecordedError[] {
  return recent;
}

/** Test helper. */
export function clearRecentErrors(): void {
  recent.length = 0;
}
