import type { ErrorKind } from "./catalog";

export type { ErrorKind } from "./catalog";

export type ErrorDomain = "ai" | "file" | "db" | "generation" | "unknown";

/** Placeholder values interpolated into catalog text, e.g. `{ fileName, model }`. */
export type ErrorContext = Record<string, string>;

/**
 * The single shape every caught error is normalized into before it reaches
 * the UI. Built by `toAppError()` — never construct one by hand outside
 * `src/errors/`.
 */
export interface AppError {
  domain: ErrorDomain;
  /** Namespaced catalog id, e.g. "ai.auth", "file.encrypted-pdf", "db.quota". */
  kind: ErrorKind;
  /** Short bold line, e.g. "AI key rejected". */
  title: string;
  /** What happened, in plain language. */
  message: string;
  /** What to do next. */
  help?: string;
  /** Raw technical text for administrators (copyable). */
  detail: string;
  /** Whether repeating the same operation could succeed. */
  retryable: boolean;
  context?: ErrorContext;
  cause: unknown;
}

/**
 * A classifier recognises errors from one domain (SDK errors, Dexie errors,
 * pdf.js exceptions, …) and maps them to a catalog kind. Pure — no side effects.
 * Return null for anything it doesn't recognise.
 */
export interface ErrorClassifier {
  domain: ErrorDomain;
  classify(err: unknown): { kind: ErrorKind; context?: ErrorContext } | null;
}
