/**
 * Contract tests for the error framework. These keep future additions honest:
 * every classifier is registered and tested, every sample error is claimed by
 * exactly one domain, and every catalog entry is complete.
 */
import { describe, it, expect } from "vitest";
import { readdirSync } from "node:fs";
import { join } from "node:path";
import Anthropic from "@anthropic-ai/sdk";
import { CLASSIFIERS } from "./index";
import { CATALOG, type ErrorKind } from "./catalog";
import type { ErrorDomain } from "./types";

const named = (name: string, message = "", extra: Record<string, unknown> = {}) =>
  Object.assign(new Error(message), { name }, extra);

/** Representative real-world errors → the one domain/kind that must claim them. */
const FIXTURES: { label: string; err: unknown; domain: ErrorDomain; kind: ErrorKind }[] = [
  {
    label: "SDK AuthenticationError",
    err: new Anthropic.AuthenticationError(401, { error: { message: "bad key" } }, "bad key", new Headers()),
    domain: "ai",
    kind: "ai.auth",
  },
  {
    label: "SDK RateLimitError",
    err: new Anthropic.RateLimitError(429, undefined, "slow down", new Headers()),
    domain: "ai",
    kind: "ai.rate-limit",
  },
  { label: "plain {status: 404} (proxy-translated)", err: { status: 404, message: "Not Found" }, domain: "ai", kind: "ai.model-unavailable" },
  {
    label: "400 prompt too long",
    err: { status: 400, message: "prompt is too long: 250000 tokens > 200000 maximum" },
    domain: "ai",
    kind: "ai.context-too-long",
  },
  {
    label: "400 OpenAI-style context length",
    err: { status: 400, message: "This model's maximum context length is 128000 tokens" },
    domain: "ai",
    kind: "ai.context-too-long",
  },
  {
    label: "400 LiteLLM invalid model",
    err: { status: 400, message: "Invalid model name passed in model=claude-4-6-sonnet" },
    domain: "ai",
    kind: "ai.model-unavailable",
  },
  { label: "502 gateway", err: { status: 502, message: "Bad Gateway" }, domain: "ai", kind: "ai.server" },
  { label: "SDK APIConnectionError", err: new Anthropic.APIConnectionError({ cause: new TypeError("Failed to fetch") }), domain: "ai", kind: "ai.network" },
  { label: "SDK APIConnectionTimeoutError", err: new Anthropic.APIConnectionTimeoutError(), domain: "ai", kind: "ai.timeout" },
  { label: "fetch TypeError", err: new TypeError("Failed to fetch"), domain: "ai", kind: "ai.network" },
  { label: "Safari fetch TypeError", err: new TypeError("Load failed"), domain: "ai", kind: "ai.network" },
  { label: "native QuotaExceededError", err: new DOMException("quota", "QuotaExceededError"), domain: "db", kind: "db.quota" },
  {
    label: "Dexie AbortError wrapping quota",
    err: named("AbortError", "Transaction aborted", { inner: new DOMException("quota", "QuotaExceededError") }),
    domain: "db",
    kind: "db.quota",
  },
  { label: "Dexie DatabaseClosedError", err: named("DatabaseClosedError", "Database has been closed"), domain: "db", kind: "db.closed" },
  { label: "Dexie VersionError", err: named("VersionError", "The requested version is less than the existing version"), domain: "db", kind: "db.version" },
  {
    label: "Dexie OpenFailedError wrapping MissingAPIError",
    err: named("OpenFailedError", "open failed", { inner: named("MissingAPIError", "IndexedDB API missing") }),
    domain: "db",
    kind: "db.unavailable",
  },
  {
    label: "Dexie OpenFailedError (Firefox private)",
    err: named("OpenFailedError", "open failed", { inner: named("InvalidStateError", "A mutation operation was attempted") }),
    domain: "db",
    kind: "db.unavailable",
  },
  { label: "Dexie OpenFailedError", err: named("OpenFailedError", "UnknownError"), domain: "db", kind: "db.open-failed" },
  { label: "pdf.js PasswordException", err: named("PasswordException", "No password given"), domain: "file", kind: "file.encrypted-pdf" },
  { label: "pdf.js InvalidPDFException", err: named("InvalidPDFException", "Invalid PDF structure."), domain: "file", kind: "file.corrupt-pdf" },
  {
    label: "JSZip not a zip",
    err: new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html"),
    domain: "file",
    kind: "file.corrupt-docx",
  },
  {
    label: "mammoth missing document part",
    err: new Error("Could not find main document part. Are you sure this is a valid .docx file?"),
    domain: "file",
    kind: "file.corrupt-docx",
  },
  {
    label: "Docxtemplater Multi error",
    err: Object.assign(new Error("Multi error"), { name: "TemplateError", properties: { id: "multi_error", errors: [] } }),
    domain: "generation",
    kind: "generation.render",
  },
];

/** Errors no classifier should claim (they must fall through to `unknown`). */
const UNCLAIMED: { label: string; err: unknown }[] = [
  { label: "plain Error", err: new Error("something odd") },
  { label: "DOM AbortError", err: new DOMException("Aborted", "AbortError") },
  { label: "TypeError unrelated to fetch", err: new TypeError("Cannot read properties of undefined") },
  { label: "string", err: "oops" },
  { label: "null", err: null },
];

describe("classifier contract", () => {
  it.each(FIXTURES)("$label is claimed by exactly the $domain classifier as $kind", ({ err, domain, kind }) => {
    const claims = CLASSIFIERS.map((c) => ({ domain: c.domain, hit: c.classify(err) })).filter((c) => c.hit);
    expect(claims.map((c) => c.domain)).toEqual([domain]);
    expect(claims[0].hit!.kind).toBe(kind);
  });

  it.each(UNCLAIMED)("$label is claimed by no classifier", ({ err }) => {
    for (const c of CLASSIFIERS) expect(c.classify(err)).toBeNull();
  });

  it("every classifier file in classifiers/ is registered and has a test file", () => {
    const dir = join(__dirname, "classifiers");
    const files = readdirSync(dir);
    const sources = files.filter((f) => f.endsWith(".ts") && !f.endsWith(".test.ts"));
    expect(sources.length).toBe(CLASSIFIERS.length);
    for (const src of sources) {
      expect(files, `${src} needs a matching test file`).toContain(src.replace(/\.ts$/, ".test.ts"));
    }
    const domains = CLASSIFIERS.map((c) => c.domain);
    expect(new Set(domains).size, "one classifier per domain").toBe(domains.length);
  });
});

describe("catalog contract", () => {
  const DOCUMENTED_PLACEHOLDERS = new Set(["model", "seconds", "what", "fileName", "sizeMb", "limitMb", "ext", "schema", "count", "titles"]);

  it.each(Object.entries(CATALOG))("%s has complete, well-formed wording", (kind, entry) => {
    expect(entry.title.trim()).not.toBe("");
    expect(entry.message.trim()).not.toBe("");
    const domain = kind.split(".")[0];
    expect(["ai", "file", "db", "generation", "unknown"]).toContain(domain);
    for (const text of [entry.title, entry.message, entry.help ?? ""]) {
      for (const [, name] of text.matchAll(/\{(\w+)\}/g)) {
        expect(DOCUMENTED_PLACEHOLDERS, `undocumented placeholder {${name}} in ${kind}`).toContain(name);
      }
    }
  });
});
