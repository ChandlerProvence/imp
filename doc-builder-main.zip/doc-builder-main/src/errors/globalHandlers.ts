import { isAbortError, toAppError } from "./index";
import { reportWriteError } from "../db/writeStatus";

let installed = false;

/**
 * Safety net for errors that escape every catch. Each one is normalized (and
 * so recorded for diagnostics); storage failures also raise the save banner,
 * because an unhandled IndexedDB rejection almost always means lost data.
 */
export function installGlobalErrorHandlers(target: Window = window): void {
  if (installed) return;
  installed = true;

  target.addEventListener("unhandledrejection", (event) => {
    if (isAbortError(event.reason)) return;
    const error = toAppError(event.reason);
    if (error.domain === "db") reportWriteError(event.reason);
  });

  target.addEventListener("error", (event) => {
    if (event.error) toAppError(event.error);
  });
}

/** Test helper. */
export function resetGlobalErrorHandlersForTest(): void {
  installed = false;
}
