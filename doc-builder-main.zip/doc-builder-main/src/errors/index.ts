/**
 * Error-handling framework. Every caught error that reaches the UI goes
 * through `toAppError(err, { domain })`, which produces one `AppError` shape
 * rendered by `<AppErrorBox>`.
 *
 * - Wording lives in `catalog.ts`.
 * - Library errors are recognised by the per-domain classifiers in
 *   `classifiers/`, registered below.
 * - Code that already knows what went wrong throws `appErrorException(kind)`.
 */
import { CATALOG, interpolate, type ErrorKind } from "./catalog";
import { aiClassifier } from "./classifiers/ai";
import { dbClassifier } from "./classifiers/db";
import { fileClassifier } from "./classifiers/file";
import { generationClassifier } from "./classifiers/generation";
import { recordError } from "./recordError";
import type { AppError, ErrorClassifier, ErrorContext, ErrorDomain } from "./types";

export type { AppError, ErrorDomain, ErrorKind, ErrorContext } from "./types";
export { classifyHttpStatus } from "./classifiers/ai";
export { getRecentErrors } from "./recordError";

/** One line per domain. Order matters only when no domain hint is given. */
export const CLASSIFIERS: readonly ErrorClassifier[] = [
  dbClassifier,
  fileClassifier,
  generationClassifier,
  aiClassifier,
];

/**
 * An `Error` carrying an `AppError`. `message` is the user-facing message so
 * code that still reads `err.message` shows friendly text.
 */
export class AppErrorException extends Error {
  readonly appError: AppError;
  constructor(appError: AppError) {
    super(appError.message);
    this.name = "AppErrorException";
    this.appError = appError;
  }
}

export function isAppErrorException(err: unknown): err is AppErrorException {
  return err instanceof AppErrorException;
}

function domainOf(kind: ErrorKind): ErrorDomain {
  const prefix = kind.split(".")[0];
  return prefix === "ai" || prefix === "file" || prefix === "db" || prefix === "generation" ? prefix : "unknown";
}

function rawDetail(err: unknown): string {
  if (err == null) return "";
  if (err instanceof AppErrorException) return err.appError.detail;
  if (err instanceof Error) {
    return err.name && err.name !== "Error" ? `${err.name}: ${err.message}` : err.message;
  }
  if (typeof err === "string") return err;
  try {
    return JSON.stringify(err) ?? String(err);
  } catch {
    return String(err);
  }
}

const recorded = new WeakSet<object>();

function build(kind: ErrorKind, cause: unknown, context?: ErrorContext, detail?: string): AppError {
  const entry = CATALOG[kind];
  const error: AppError = {
    domain: domainOf(kind),
    kind,
    title: interpolate(entry.title, context),
    message: interpolate(entry.message, context),
    ...(entry.help ? { help: interpolate(entry.help, context) } : {}),
    detail: detail ?? rawDetail(cause),
    retryable: entry.retryable,
    ...(context ? { context } : {}),
    cause,
  };
  const key = cause && typeof cause === "object" ? cause : null;
  if (!key || !recorded.has(key)) {
    if (key) recorded.add(key);
    recordError(error);
  }
  return error;
}

/** Build an `AppError` for a known kind (for code that knows what went wrong). */
export function appError(
  kind: ErrorKind,
  opts: { context?: ErrorContext; cause?: unknown; detail?: string } = {},
): AppError {
  return build(kind, opts.cause, opts.context, opts.detail);
}

/** Build a throwable for a known kind. */
export function appErrorException(
  kind: ErrorKind,
  opts: { context?: ErrorContext; cause?: unknown; detail?: string } = {},
): AppErrorException {
  return new AppErrorException(appError(kind, opts));
}

/**
 * Normalize any caught value into an `AppError`.
 *
 * @param opts.domain  The caller's domain. Its classifier is tried first, so
 *                     ambiguous errors (e.g. `TypeError: Failed to fetch`)
 *                     resolve by context rather than registry order.
 * @param opts.context Placeholder values (fileName, model, schema, …).
 */
export function toAppError(
  err: unknown,
  opts: { domain?: ErrorDomain; context?: ErrorContext } = {},
): AppError {
  if (err instanceof AppErrorException) {
    if (!opts.context) return err.appError;
    const merged = { ...opts.context, ...err.appError.context };
    return { ...err.appError, ...rebuildText(err.appError.kind, merged), context: merged };
  }

  const hit = classify(err, opts.domain);
  const context = hit.context || opts.context ? { ...opts.context, ...hit.context } : undefined;
  return build(hit.kind, err, context);
}

/** Run the classifiers (hinted domain first). Pure — does not record. */
function classify(err: unknown, domain?: ErrorDomain): { kind: ErrorKind; context?: ErrorContext } {
  if (err instanceof AppErrorException) return { kind: err.appError.kind, context: err.appError.context };
  const ordered = domain
    ? [...CLASSIFIERS.filter((c) => c.domain === domain), ...CLASSIFIERS.filter((c) => c.domain !== domain)]
    : CLASSIFIERS;
  for (const classifier of ordered) {
    const hit = classifier.classify(err);
    if (hit) return hit;
  }
  return { kind: "unknown" };
}

function rebuildText(kind: ErrorKind, context: ErrorContext) {
  const entry = CATALOG[kind];
  return {
    title: interpolate(entry.title, context),
    message: interpolate(entry.message, context),
    ...(entry.help ? { help: interpolate(entry.help, context) } : {}),
  };
}

/** `toAppError` wrapped in a throwable, for re-throwing from library code. */
export function toAppErrorException(
  err: unknown,
  opts: { domain?: ErrorDomain; context?: ErrorContext } = {},
): AppErrorException {
  if (err instanceof AppErrorException && !opts.context) return err;
  return new AppErrorException(toAppError(err, opts));
}

/** Whether retrying the same operation could succeed. */
export function isRetryable(err: unknown, domain?: ErrorDomain): boolean {
  return CATALOG[classify(err, domain).kind].retryable;
}

/**
 * True for user/caller cancellation, which should never be shown as an error.
 * The SDK's APIUserAbortError keeps name "Error" (and its class name is
 * minified in production), so its fixed message is matched too.
 */
export function isAbortError(err: unknown): boolean {
  if (!err || typeof err !== "object") return false;
  const { name, message } = err as { name?: unknown; message?: unknown };
  return name === "AbortError" || name === "APIUserAbortError" || message === "Request was aborted.";
}
