import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("../db/writeStatus", () => ({ reportWriteError: vi.fn() }));

import { reportWriteError } from "../db/writeStatus";
import { installGlobalErrorHandlers, resetGlobalErrorHandlersForTest } from "./globalHandlers";
import { getRecentErrors } from "./index";

function rejection(reason: unknown): Event {
  const event = new Event("unhandledrejection");
  Object.assign(event, { reason, promise: Promise.resolve() });
  return event;
}

function named(name: string, message = "boom"): Error {
  const err = new Error(message);
  err.name = name;
  return err;
}

describe("installGlobalErrorHandlers", () => {
  let target: EventTarget;

  beforeEach(() => {
    resetGlobalErrorHandlersForTest();
    vi.mocked(reportWriteError).mockClear();
    target = new EventTarget();
  });

  afterEach(() => {
    resetGlobalErrorHandlersForTest();
  });

  function install(t: EventTarget = target) {
    installGlobalErrorHandlers(t as unknown as Window);
  }

  it("reports unhandled rejections that classify to the db domain", () => {
    install();
    const err = named("QuotaExceededError");
    target.dispatchEvent(rejection(err));
    expect(reportWriteError).toHaveBeenCalledTimes(1);
    expect(reportWriteError).toHaveBeenCalledWith(err);
  });

  it("does not report non-db rejections but still records them", () => {
    install();
    target.dispatchEvent(rejection(new Error("some unrelated failure xyz-123")));
    expect(reportWriteError).not.toHaveBeenCalled();
    expect(getRecentErrors().some((e) => e.detail.includes("xyz-123"))).toBe(true);
  });

  it("ignores abort rejections", () => {
    install();
    target.dispatchEvent(rejection(named("AbortError")));
    target.dispatchEvent(rejection({ message: "Request was aborted." }));
    expect(reportWriteError).not.toHaveBeenCalled();
  });

  it("records error events without raising the save banner", () => {
    install();
    target.dispatchEvent(new ErrorEvent("error", { error: new Error("window error abc-987") }));
    expect(reportWriteError).not.toHaveBeenCalled();
    expect(getRecentErrors().some((e) => e.detail.includes("abc-987"))).toBe(true);
  });

  it("ignores error events with no error object", () => {
    install();
    const before = getRecentErrors().length;
    target.dispatchEvent(new ErrorEvent("error", { message: "script error" }));
    expect(getRecentErrors().length).toBe(before);
  });

  it("does not raise the save banner for a db-named error event (only rejections do)", () => {
    install();
    target.dispatchEvent(new ErrorEvent("error", { error: named("QuotaExceededError") }));
    expect(reportWriteError).not.toHaveBeenCalled();
  });

  it("installing twice does not double-report", () => {
    install();
    install();
    target.dispatchEvent(rejection(named("DatabaseClosedError")));
    expect(reportWriteError).toHaveBeenCalledTimes(1);
  });

  it("a second install on another target is a no-op until reset", () => {
    install();
    const other = new EventTarget();
    install(other);
    other.dispatchEvent(rejection(named("DatabaseClosedError")));
    expect(reportWriteError).not.toHaveBeenCalled();

    resetGlobalErrorHandlersForTest();
    install(other);
    other.dispatchEvent(rejection(named("DatabaseClosedError")));
    expect(reportWriteError).toHaveBeenCalledTimes(1);
  });
});
