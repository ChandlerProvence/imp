import { describe, it, expect, vi, afterEach } from "vitest";
import { getBuildInfo, formatBuildLabel } from "./buildInfo";

afterEach(() => vi.unstubAllEnvs());

describe("getBuildInfo", () => {
  it("falls back to 'dev' when no SHA was injected", () => {
    vi.stubEnv("VITE_BUILD_SHA", "");
    vi.stubEnv("VITE_BUILD_TIME", "");
    expect(getBuildInfo()).toEqual({ sha: "dev" });
  });

  it("reports the injected SHA and build time", () => {
    vi.stubEnv("VITE_BUILD_SHA", "abc1234");
    vi.stubEnv("VITE_BUILD_TIME", "2026-10-20T12:00:00.000Z");
    expect(getBuildInfo()).toEqual({ sha: "abc1234", builtAt: "2026-10-20T12:00:00.000Z" });
  });
});

describe("formatBuildLabel", () => {
  it("shows SHA and build date", () => {
    expect(formatBuildLabel({ sha: "abc1234", builtAt: "2026-10-20T12:00:00.000Z" })).toBe(
      "Build abc1234 · 2026-10-20",
    );
  });

  it("shows only the SHA when the build time is unknown", () => {
    expect(formatBuildLabel({ sha: "dev" })).toBe("Build dev");
  });
});
