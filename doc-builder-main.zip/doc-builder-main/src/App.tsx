import { lazy, Suspense } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { UserPreferencesProvider } from "./context/UserPreferencesContext";
import { AiConfigProvider } from "./context/AiConfigContext";
import { SessionProvider } from "./context/SessionContext";
import { AiPanelProvider } from "./context/AiPanelContext";
import { AskSageProvider } from "./context/AskSageContext";
import Home from "./pages/Home";
import Interview from "./pages/Interview";
import PrepPage from "./pages/prep/PrepPage";
import Review from "./pages/Review";
import Preview from "./pages/Preview";
import Documentation from "./pages/Documentation";
import ManageTemplates from "./pages/ManageTemplates";
import AppMenuBar from "./components/AppMenuBar";
import AppSidebar from "./components/AppSidebar";
import RequireSession from "./components/RequireSession";
import { AiPanel } from "./components/ai-panel";
import ErrorBoundary from "./components/ErrorBoundary";
import SaveErrorBanner from "./components/SaveErrorBanner";
import ModelSubstitutionNotice from "./components/ModelSubstitutionNotice";
import MailingListNotice from "./components/MailingListNotice";

// Only template authors open the editor; keep it out of the main bundle
const TemplateEditorPage = lazy(() => import("./pages/TemplateEditorPage"));

export default function App() {
  return (
    <ErrorBoundary>
    <BrowserRouter basename={import.meta.env.BASE_URL}>
      <UserPreferencesProvider>
        <AiConfigProvider>
        <AskSageProvider>
        <SessionProvider>
        <AiPanelProvider>
          <div className="flex flex-col h-screen">
            <AppMenuBar />
            <SaveErrorBanner />
            <ModelSubstitutionNotice />
            <MailingListNotice />
            <div className="flex flex-1 min-h-0 overflow-hidden">
              <AppSidebar />
              <div className="flex flex-col flex-1 min-h-0 min-w-0 overflow-hidden">
                <Routes>
                  <Route path="/" element={<Home />} />
                  <Route path="/interview/:docTypeId" element={<RequireSession />}>
                    <Route path="prep/:prepId" element={<PrepPage />} />
                    <Route path=":sectionId" element={<Interview />} />
                    <Route index element={<Interview />} />
                  </Route>
                  <Route path="/review" element={<Review />} />
                  <Route path="/preview" element={<Preview />} />
                  <Route path="/docs/*" element={<Documentation />} />
                  <Route path="/templates" element={<ManageTemplates />} />
                  <Route
                    path="/templates/edit/:id"
                    element={
                      <Suspense fallback={<p className="p-8 text-sm text-gray-500">Loading the editor…</p>}>
                        <TemplateEditorPage />
                      </Suspense>
                    }
                  />
                </Routes>
              </div>
              <AiPanel />
            </div>
          </div>
        </AiPanelProvider>
        </SessionProvider>
        </AskSageProvider>
        </AiConfigProvider>
      </UserPreferencesProvider>
    </BrowserRouter>
    </ErrorBoundary>
  );
}
