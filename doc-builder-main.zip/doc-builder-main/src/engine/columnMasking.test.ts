import { describe, it, expect } from "vitest";
import { maskHiddenColumns } from "./columnMasking";
import { evaluateContentBlocks } from "./contentBlocks";
import { createMockSchema, createMockSection } from "../test/mocks";

const schema = createMockSchema({
  content_blocks: {
    RR: { when: { field: "price.includes_rr", is_truthy: true } },
    INCREASE: { when: { field: "price.delta", gte: 0 } },
  },
  sections: [
    createMockSection({
      id: "price",
      fields: [
        { id: "includes_rr", label: "Includes R&R", type: "boolean", required: false },
        {
          id: "lines",
          label: "Lines",
          type: "table",
          required: true,
          columns: [
            { id: "tte", label: "TT&E", type: "number" },
            { id: "rr", label: "R&R", type: "number", visible_when: "RR" },
            { id: "unit_total", label: "Unit Total", type: "number", formula: "COALESCE(tte, 0) + COALESCE(rr, 0)" },
          ],
        },
        { id: "total", label: "Total", type: "number", required: true, formula: "SUM(lines.unit_total)", format: "currency" },
        { id: "from", label: "From", type: "number", required: true },
        { id: "delta", label: "Delta", type: "number", required: true, formula: "total - from", format: "currency" },
      ],
    }),
    createMockSection({
      id: "other",
      fields: [
        {
          id: "items",
          label: "Items",
          type: "table",
          required: false,
          columns: [
            { id: "qty", label: "Qty", type: "number" },
            { id: "rate", label: "Rate", type: "number" },
            { id: "amount", label: "Amount", type: "number", formula: "qty * rate" },
          ],
        },
      ],
    }),
  ],
});

type Answers = Record<string, string | number | boolean>;
const rowsOf = (answers: Answers, key: string) => JSON.parse(answers[key] as string).rows;
const lines = (...rows: object[]) => JSON.stringify({ rows });
const mask = (answers: Answers) => maskHiddenColumns(schema, answers, evaluateContentBlocks(schema, answers));

describe("maskHiddenColumns", () => {
  it("blanks hidden input columns and recomputes the formula column", () => {
    // R&R entered then unchecked: stored unit_total (150) is stale.
    const out = mask({ "price.includes_rr": false, "price.lines": lines({ tte: 100, rr: 50, unit_total: 150 }) });
    expect(rowsOf(out, "price.lines")).toEqual([{ tte: 100, rr: "", unit_total: 100 }]);
  });

  it("leaves visible inputs alone and recomputes from them", () => {
    const out = mask({ "price.includes_rr": true, "price.lines": lines({ tte: 100, rr: 50, unit_total: 0 }) });
    expect(rowsOf(out, "price.lines")).toEqual([{ tte: 100, rr: 50, unit_total: 150 }]);
  });

  it("fills in formula values missing from stored rows", () => {
    const out = mask({ "price.includes_rr": true, "price.lines": lines({ tte: "$1,000", rr: 25 }) });
    expect(rowsOf(out, "price.lines")[0].unit_total).toBe(1025);
  });

  it("computes formulas in tables that have no gated columns", () => {
    const out = mask({ "other.items": lines({ qty: 3, rate: 20 }) });
    expect(rowsOf(out, "other.items")[0].amount).toBe(60);
  });

  it("does not mutate the input answers", () => {
    const answers = { "price.includes_rr": false, "price.lines": lines({ tte: 100, rr: 50, unit_total: 150 }) };
    const before = JSON.stringify(answers);
    mask(answers);
    expect(JSON.stringify(answers)).toBe(before);
  });

  it("returns the same object when there are no table rows", () => {
    const answers = { "price.includes_rr": true };
    expect(mask(answers)).toBe(answers);
  });
});
