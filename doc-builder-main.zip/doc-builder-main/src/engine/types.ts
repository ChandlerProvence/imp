/** Status of a section based on field completeness. */
export type SectionStatus = "empty" | "in-progress" | "complete";
