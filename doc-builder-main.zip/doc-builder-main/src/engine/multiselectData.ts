/**
 * Utilities for parsing and serializing multiselect field values.
 *
 * Multiselect values are stored as JSON-encoded string arrays within the
 * standard `Record<string, string | number | boolean>` answer map — the
 * same serialization strategy used by `tableData.ts`.
 */

/** Parse a raw answer value into a string array. Returns `[]` on failure. */
export function parseMultiselectValue(
  raw: string | number | boolean | undefined,
): string[] {
  if (raw === undefined || raw === null) return [];
  if (typeof raw !== "string") return [];
  if (raw.trim() === "") return [];
  try {
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.every((v) => typeof v === "string")) {
      return parsed;
    }
    return [];
  } catch {
    return [];
  }
}

/** Serialize a string array into a JSON string for storage. */
export function serializeMultiselectValue(values: string[]): string {
  return JSON.stringify(values);
}
