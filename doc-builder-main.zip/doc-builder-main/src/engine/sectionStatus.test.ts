import { describe, it, expect } from "vitest";
import { computeSectionStatus, countUnfilledFields } from "./sectionStatus";
import type { DocumentSchema, SectionDef } from "../schemas/types";

/** Compute status for a single-section schema. */
function status(section: SectionDef, answers: Record<string, string | number | boolean>) {
  return computeSectionStatus(section, { sections: [section] } as DocumentSchema, answers);
}

/** Helper to build a minimal section definition. */
function makeSection(
  id: string,
  fields: { id: string; type?: string; required?: boolean }[],
): SectionDef {
  return {
    id,
    title: id,
    fields: fields.map((f) => ({
      id: f.id,
      label: f.id,
      type: (f.type ?? "string") as any,
      required: f.required ?? false,
    })),
  };
}

describe("computeSectionStatus", () => {
  it("returns 'empty' when no fields have values", () => {
    const section = makeSection("s", [
      { id: "a", required: true },
      { id: "b" },
    ]);
    expect(status(section,{})).toBe("empty");
  });

  it("returns 'empty' when all values are empty strings", () => {
    const section = makeSection("s", [{ id: "a", required: true }]);
    expect(status(section,{ "s.a": "" })).toBe("empty");
  });

  it("returns 'empty' when values are whitespace-only", () => {
    const section = makeSection("s", [{ id: "a", required: true }]);
    expect(status(section,{ "s.a": "   " })).toBe("empty");
  });

  it("returns 'in-progress' when some but not all required fields filled", () => {
    const section = makeSection("s", [
      { id: "a", required: true },
      { id: "b", required: true },
    ]);
    expect(status(section,{ "s.a": "filled" })).toBe(
      "in-progress",
    );
  });

  it("returns 'complete' when all required fields have values", () => {
    const section = makeSection("s", [
      { id: "a", required: true },
      { id: "b", required: true },
    ]);
    expect(
      status(section,{ "s.a": "yes", "s.b": "yes" }),
    ).toBe("complete");
  });

  it("returns 'complete' when section has no required fields but has values", () => {
    const section = makeSection("s", [{ id: "a" }, { id: "b" }]);
    expect(status(section,{ "s.a": "hi" })).toBe("complete");
  });

  it("considers boolean true as having a value", () => {
    const section = makeSection("s", [
      { id: "flag", type: "boolean", required: true },
    ]);
    expect(status(section,{ "s.flag": true })).toBe("complete");
  });

  it("considers boolean false as having a value", () => {
    const section = makeSection("s", [
      { id: "flag", type: "boolean", required: true },
    ]);
    // Boolean false is still a valid entry (user made a choice)
    expect(status(section,{ "s.flag": false })).toBe(
      "complete",
    );
  });

  it("considers number 0 as having a value", () => {
    const section = makeSection("s", [
      { id: "qty", type: "number", required: true },
    ]);
    expect(status(section,{ "s.qty": 0 })).toBe("complete");
  });

  it("handles table fields — empty table means empty", () => {
    const section: SectionDef = {
      id: "s",
      title: "s",
      fields: [
        {
          id: "tbl",
          label: "Table",
          type: "table",
          required: true,
          columns: [{ id: "name", label: "Name", type: "string", required: true }],
        },
      ],
    };
    const emptyTable = JSON.stringify({ rows: [] });
    expect(status(section,{ "s.tbl": emptyTable })).toBe(
      "empty",
    );
  });

  it("handles table fields — populated table with required cols filled is complete", () => {
    const section: SectionDef = {
      id: "s",
      title: "s",
      fields: [
        {
          id: "tbl",
          label: "Table",
          type: "table",
          required: true,
          columns: [{ id: "name", label: "Name", type: "string", required: true }],
        },
      ],
    };
    const filledTable = JSON.stringify({ rows: [{ name: "Alice" }] });
    expect(status(section,{ "s.tbl": filledTable })).toBe(
      "complete",
    );
  });
});

describe("countUnfilledFields", () => {
  const section: SectionDef = {
    id: "s",
    title: "s",
    fields: [
      {
        id: "tbl",
        label: "tbl",
        type: "table",
        required: true,
        columns: [
          { id: "name", label: "Name", type: "string", required: true },
          { id: "role", label: "Role", type: "string", required: true },
        ],
      },
      { id: "note", label: "note", type: "string", required: false },
    ],
  };
  const schema = { sections: [section] } as DocumentSchema;
  const partialTable = JSON.stringify({ rows: [{ name: "Alice" }] });

  it("counts a partially filled required table as unfilled, matching the sidebar", () => {
    const answers = { "s.tbl": partialTable };
    expect(computeSectionStatus(section, schema, answers)).toBe("in-progress");
    expect(countUnfilledFields(schema, answers)).toMatchObject({
      required: 1,
      optional: 1,
      bySectionId: { s: { required: 1, optional: 1 } },
    });
  });

  it("counts a complete required table as filled", () => {
    const answers = { "s.tbl": JSON.stringify({ rows: [{ name: "Alice", role: "PM" }] }), "s.note": "hi" };
    expect(countUnfilledFields(schema, answers)).toMatchObject({ total: 0, required: 0, optional: 0 });
  });
});
