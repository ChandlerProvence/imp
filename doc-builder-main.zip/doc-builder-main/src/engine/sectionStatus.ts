import type { DocumentSchema, FieldDef, SectionDef } from "../schemas/types";
import type { SectionStatus } from "./types";
import { tableHasValue, tableIsComplete } from "./tableData";
import { parseMultiselectValue } from "./multiselectData";
import { getVisibleFields, getVisibleSections, isSectionVisible } from "./visibility";
import { evaluateContentBlocks, type BlockValues } from "./contentBlocks";

/**
 * Compute the status of a section based on current answers.
 *
 * Hidden sections (via `visible_when`) are reported as `"complete"` so they
 * don't block wizard completion.
 *
 * Only visible fields are considered when computing status — hidden fields
 * within a visible section are ignored.
 *
 * - "empty" — no visible fields have values
 * - "in-progress" — some visible fields have values but not all required
 * - "complete" — all required visible fields have non-empty values (or section is hidden)
 *
 * Callers computing status for many sections should pass a pre-evaluated
 * `blocks` map so content blocks are resolved once, not per section.
 */
export function computeSectionStatus(
  section: SectionDef,
  schema: DocumentSchema,
  answers: Record<string, string | number | boolean>,
  blocks: BlockValues = evaluateContentBlocks(schema, answers),
): SectionStatus {
  // Hidden sections are always "complete" — they don't block the wizard.
  if (!isSectionVisible(section, schema, answers, blocks)) return "complete";

  const visibleFields = getVisibleFields(section, schema, answers, blocks);
  const requiredFields = visibleFields.filter((f) => f.required && f.formula === undefined);

  const hasAnyValue = visibleFields.some((f) => {
    const key = `${section.id}.${f.id}`;
    return fieldHasValue(answers[key], f);
  });

  if (!hasAnyValue) return "empty";

  const allRequiredFilled = requiredFields.every((f) => {
    const key = `${section.id}.${f.id}`;
    return fieldIsComplete(answers[key], f);
  });

  return allRequiredFilled ? "complete" : "in-progress";
}

/** True when the field has any value (a table with at least one filled cell counts). */
export function fieldHasValue(val: unknown, field: FieldDef): boolean {
  if (field.type === "table") {
    return tableHasValue(val as string | number | boolean | undefined);
  }
  if (field.type === "multiselect") {
    return parseMultiselectValue(val as string | number | boolean | undefined).length > 0;
  }
  return hasValue(val);
}

/** True when a required field is satisfied (a table must be complete, not just started). */
export function fieldIsComplete(val: unknown, field: FieldDef): boolean {
  if (field.type === "table") {
    return tableIsComplete(val as string | number | boolean | undefined, field);
  }
  if (field.type === "multiselect") {
    return parseMultiselectValue(val as string | number | boolean | undefined).length > 0;
  }
  return hasValue(val);
}

export interface UnfilledFieldCounts {
  total: number;
  required: number;
  optional: number;
  bySectionId: Record<string, { required: number; optional: number }>;
}

/**
 * Count unfilled fields across visible sections and fields, split by required
 * vs optional. Required fields use the same completeness rule as
 * `computeSectionStatus`, so the Review page and the sidebar agree. Computed
 * fields are skipped — they are calculated, not user-filled.
 */
export function countUnfilledFields(
  schema: DocumentSchema,
  answers: Record<string, string | number | boolean>,
  blocks: BlockValues = evaluateContentBlocks(schema, answers),
): UnfilledFieldCounts {
  const bySectionId: UnfilledFieldCounts["bySectionId"] = {};
  let required = 0;
  let optional = 0;
  for (const section of getVisibleSections(schema, answers)) {
    let sectionRequired = 0;
    let sectionOptional = 0;
    for (const field of getVisibleFields(section, schema, answers, blocks)) {
      if (field.formula !== undefined) continue;
      const val = answers[`${section.id}.${field.id}`];
      if (field.required) {
        if (!fieldIsComplete(val, field)) sectionRequired++;
      } else if (!fieldHasValue(val, field)) {
        sectionOptional++;
      }
    }
    bySectionId[section.id] = { required: sectionRequired, optional: sectionOptional };
    required += sectionRequired;
    optional += sectionOptional;
  }
  return { total: required + optional, required, optional, bySectionId };
}

function hasValue(val: unknown): boolean {
  if (val === undefined || val === null) return false;
  if (typeof val === "string") return val.trim().length > 0;
  return true; // numbers, booleans are always considered "filled"
}
