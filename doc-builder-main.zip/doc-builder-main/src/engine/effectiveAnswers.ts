/**
 * The answers every consumer should compute from: hidden table columns
 * blanked, row formulas recomputed, then content blocks and formula fields
 * resolved from those masked answers. The wizard, Review page, validation,
 * and .docx generator all start here so a total can never be computed from
 * values the user can't see.
 */

import type { DocumentSchema } from "../schemas/types";
import { evaluateContentBlocks, type BlockValues } from "./contentBlocks";
import { maskHiddenColumns } from "./columnMasking";
import { evaluateFormulas } from "./formula/evaluate";

type Answers = Record<string, string | number | boolean>;

export interface EffectiveAnswers {
  /** Answers with hidden column inputs blanked and row formulas recomputed. */
  answers: Answers;
  /** Every content block, evaluated against the masked answers. */
  blocks: BlockValues;
  /** Every formula field's value (`section.field` → number | null; currency rounded to cents). */
  computed: Record<string, number | null>;
}

export function resolveEffectiveAnswers(schema: DocumentSchema, answers: Answers): EffectiveAnswers {
  // evaluateContentBlocks masks internally before its numeric (gte/lt) blocks,
  // so these blocks already agree with the masked totals.
  const blocks = evaluateContentBlocks(schema, answers);
  const masked = maskHiddenColumns(schema, answers, blocks);
  const { answers: filled, values } = evaluateFormulas(schema, masked);
  return { answers: filled, blocks, computed: values };
}
