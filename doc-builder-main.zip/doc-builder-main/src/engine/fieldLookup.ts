import type { DocumentSchema, FieldDef } from "../schemas/types";

/**
 * Look up a field definition by its namespaced answer key ("section_id.field_id").
 * Returns undefined when the key doesn't resolve to a known field.
 */
export function lookupField(
  schema: DocumentSchema,
  answerKey: string,
): FieldDef | undefined {
  const [sectionId, fieldId] = answerKey.split(".");
  const section = schema.sections.find((s) => s.id === sectionId);
  if (!section) return undefined;
  return section.fields.find((f) => f.id === fieldId);
}

/**
 * Check whether a field identified by its answer key is required.
 * Returns true when the field is not found (fail-safe: treat unknown as required).
 */
export function isFieldRequired(
  schema: DocumentSchema,
  answerKey: string,
): boolean {
  const field = lookupField(schema, answerKey);
  return field?.required ?? true;
}
