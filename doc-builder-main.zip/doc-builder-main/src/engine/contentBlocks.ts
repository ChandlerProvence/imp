/**
 * Evaluates schema `content_blocks` into their runtime values.
 *
 * This is the single evaluator for conditional content. The interview UI,
 * section status, AI gate inference, and the .docx generator all consume
 * the map returned by `evaluateContentBlocks`, so they can never disagree
 * about whether a block (and any section/field gated on it) is active.
 *
 * Pure functions — no side effects, fully unit-testable.
 */

import type { BlockCondition, DocumentSchema } from "../schemas/types";
import { isConditionalBlock } from "../schemas/types";
import { parseMultiselectValue } from "./multiselectData";
import { evaluateFormulas } from "./formula/evaluate";
import { maskHiddenColumns } from "./columnMasking";
import { toNumber as coerceNumber } from "./validation/coerce";

export type BlockValues = Record<string, boolean | string>;

/** Coerce an answer or formula value to a number, or null when absent/invalid. */
function toNumber(
  key: string,
  answers: Record<string, string | number | boolean>,
  computed: Record<string, number | null>,
): number | null {
  if (key in computed) return computed[key];
  return coerceNumber(answers[key]);
}

/** Evaluate a single block condition against answers + formula field values. */
export function evaluateBlockCondition(
  condition: BlockCondition,
  answers: Record<string, string | number | boolean>,
  computed: Record<string, number | null> = {},
): boolean {
  const raw = answers[condition.field];

  if (condition.contains !== undefined) {
    return parseMultiselectValue(raw).includes(condition.contains);
  }
  if (condition.equals !== undefined) {
    return String(raw ?? "") === condition.equals;
  }
  if (condition.not_equals !== undefined) {
    return String(raw ?? "") !== condition.not_equals;
  }
  if (condition.is_truthy !== undefined) {
    const truthy = raw !== undefined && raw !== null && raw !== "" && raw !== false;
    return condition.is_truthy ? truthy : !truthy;
  }
  if (condition.gte !== undefined) {
    const n = toNumber(condition.field, answers, computed);
    return n !== null && n >= condition.gte;
  }
  if (condition.lt !== undefined) {
    const n = toNumber(condition.field, answers, computed);
    return n !== null && n < condition.lt;
  }
  // No recognised operator (loader validation should prevent this).
  return false;
}

/**
 * Resolve every content block to its runtime value. Literal blocks pass
 * through; `{ when }` blocks are evaluated. Callers that also need the masked
 * answers or formula values should use `resolveEffectiveAnswers` instead.
 *
 * Two passes:
 * 1. Evaluate non-numeric blocks (contains, is_truthy, …) with raw answers.
 * 2. Mask hidden table columns using those blocks and recompute row formulas,
 *    evaluate formula fields on the masked answers, then evaluate numeric
 *    blocks (gte, lt).
 * This ensures `PRICE_INCREASE` sees the masked total — not the raw one.
 */
export function evaluateContentBlocks(
  schema: DocumentSchema,
  answers: Record<string, string | number | boolean>,
): BlockValues {
  const blocks = schema.content_blocks;
  if (!blocks) return {};

  const needsComputed = Object.values(blocks).some(
    (v) => isConditionalBlock(v) && (v.when.gte !== undefined || v.when.lt !== undefined),
  );

  // Pass 1: non-numeric blocks (no formula values needed)
  const pass1: BlockValues = {};
  for (const [name, value] of Object.entries(blocks)) {
    if (isConditionalBlock(value)) {
      const cond = value.when;
      if (cond.gte !== undefined || cond.lt !== undefined) continue; // deferred
      pass1[name] = evaluateBlockCondition(cond, answers);
    } else {
      pass1[name] = value;
    }
  }
  if (!needsComputed) return pass1;

  // Blank hidden non-formula input columns and recompute row formulas (also
  // for tables with no hidden columns, so stale or missing formula cells
  // can't skew a total).
  const masked = maskHiddenColumns(schema, answers, pass1);
  const computedValues = evaluateFormulas(schema, masked).values;

  // Pass 2: fill in numeric blocks using masked formula values
  const out: BlockValues = { ...pass1 };
  for (const [name, value] of Object.entries(blocks)) {
    if (!isConditionalBlock(value)) continue;
    const cond = value.when;
    if (cond.gte === undefined && cond.lt === undefined) continue;
    out[name] = evaluateBlockCondition(cond, masked, computedValues);
  }
  return out;
}

/**
 * Multiselect gate values that make a given block true, if the block is a
 * `contains` condition. Returns undefined for literal or non-multiselect blocks.
 */
export function getBlockGate(
  schema: DocumentSchema,
  blockName: string,
): { field: string; value: string } | undefined {
  const block = schema.content_blocks?.[blockName];
  if (!block || !isConditionalBlock(block) || block.when.contains === undefined) return undefined;
  return { field: block.when.field, value: block.when.contains };
}
