/**
 * Schema field defaults (`default` on a field). A default stands in for an
 * answer the user hasn't given yet, so the interview control shows the same
 * value the document, totals, and content blocks will use.
 */

import type { DocumentSchema } from "../schemas/types";

type Answers = Record<string, string | number | boolean>;

/**
 * Return `answers` with every unanswered defaulted field filled in. Answers
 * that exist — including `false` and `""` — are never overridden. Returns the
 * same object when nothing was missing, so callers can skip a save.
 */
export function applyFieldDefaults(schema: DocumentSchema, answers: Answers): Answers {
  let result: Answers | undefined;
  for (const section of schema.sections) {
    for (const field of section.fields) {
      if (field.default === undefined) continue;
      const key = `${section.id}.${field.id}`;
      if (key in answers && answers[key] !== undefined && answers[key] !== null) continue;
      if (!result) result = { ...answers };
      result[key] = field.default;
    }
  }
  return result ?? answers;
}
