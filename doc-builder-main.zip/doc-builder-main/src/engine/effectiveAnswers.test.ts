import { describe, it, expect } from "vitest";
import { resolveEffectiveAnswers } from "./effectiveAnswers";
import { createMockSchema, createMockSection } from "../test/mocks";

const schema = createMockSchema({
  content_blocks: {
    RR: { when: { field: "price.includes_rr", is_truthy: true } },
    INCREASE: { when: { field: "price.delta", gte: 0 } },
    LABEL: "Fixed text",
  },
  sections: [
    createMockSection({
      id: "price",
      fields: [
        { id: "includes_rr", label: "Includes R&R", type: "boolean", required: false },
        {
          id: "lines",
          label: "Lines",
          type: "table",
          required: true,
          columns: [
            { id: "tte", label: "TT&E", type: "number" },
            { id: "rr", label: "R&R", type: "number", visible_when: "RR" },
            { id: "unit_total", label: "Unit Total", type: "number", formula: "COALESCE(tte, 0) + COALESCE(rr, 0)" },
          ],
        },
        { id: "total", label: "Total", type: "number", required: true, formula: "SUM(lines.unit_total)", format: "currency" },
        { id: "from", label: "From", type: "number", required: true },
        { id: "delta", label: "Delta", type: "number", required: true, formula: "total - from", format: "currency" },
      ],
    }),
  ],
});

const lines = (...rows: object[]) => JSON.stringify({ rows });
const rowsOf = (answers: Record<string, unknown>) => JSON.parse(answers["price.lines"] as string).rows;

describe("resolveEffectiveAnswers", () => {
  it("returns masked answers, blocks, and computed values that agree", () => {
    // R&R entered then unchecked: raw rows sum to 150 (an increase over 120),
    // what's shown sums to 100 (a decrease). Every output must use 100.
    const eff = resolveEffectiveAnswers(schema, {
      "price.includes_rr": false,
      "price.from": 120,
      "price.lines": lines({ tte: 100, rr: 50, unit_total: 150 }),
    });
    expect(rowsOf(eff.answers)).toEqual([{ tte: 100, rr: "", unit_total: 100 }]);
    expect(eff.computed["price.total"]).toBe(100);
    expect(eff.computed["price.delta"]).toBe(-20);
    expect(eff.blocks).toEqual({ RR: false, INCREASE: false, LABEL: "Fixed text" });
  });

  it("computes formula columns even when no column is hidden", () => {
    const eff = resolveEffectiveAnswers(schema, {
      "price.includes_rr": true,
      "price.from": 100,
      "price.lines": lines({ tte: 100, rr: 50 }),
    });
    expect(rowsOf(eff.answers)[0].unit_total).toBe(150);
    expect(eff.computed["price.total"]).toBe(150);
    expect(eff.blocks.INCREASE).toBe(true);
  });

  it("numeric blocks see recomputed formula columns when no column is gated", () => {
    // Stored unit totals are missing (e.g. an AI-written table); the SUM and
    // the INCREASE block must use the recomputed values.
    const ungated = createMockSchema({
      content_blocks: { INCREASE: { when: { field: "s.delta", gte: 0 } } },
      sections: [
        createMockSection({
          id: "s",
          fields: [
            {
              id: "items",
              label: "Items",
              type: "table",
              required: true,
              columns: [
                { id: "qty", label: "Qty", type: "number" },
                { id: "rate", label: "Rate", type: "number" },
                { id: "amount", label: "Amount", type: "number", formula: "qty * rate" },
              ],
            },
            { id: "total", label: "Total", type: "number", required: true, formula: "SUM(items.amount)", format: "currency" },
            { id: "from", label: "From", type: "number", required: true },
            { id: "delta", label: "Delta", type: "number", required: true, formula: "total - from", format: "currency" },
          ],
        }),
      ],
    });
    const eff = resolveEffectiveAnswers(ungated, { "s.from": 50, "s.items": JSON.stringify({ rows: [{ qty: 3, rate: 20 }] }) });
    expect(eff.computed["s.total"]).toBe(60);
    expect(eff.blocks.INCREASE).toBe(true);
  });

  it("does not mutate the input answers", () => {
    const answers = { "price.includes_rr": false, "price.lines": lines({ tte: 100, rr: 50 }) };
    const before = JSON.stringify(answers);
    resolveEffectiveAnswers(schema, answers);
    expect(JSON.stringify(answers)).toBe(before);
  });

  it("handles schemas without content blocks", () => {
    const plain = createMockSchema({
      sections: [createMockSection({ id: "s", fields: [{ id: "n", label: "N", type: "number", required: false }] })],
    });
    const answers = { "s.n": 5 };
    expect(resolveEffectiveAnswers(plain, answers)).toEqual({ answers, blocks: {}, computed: {} });
  });
});
