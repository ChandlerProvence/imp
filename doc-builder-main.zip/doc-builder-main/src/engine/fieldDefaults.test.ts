import { describe, it, expect } from "vitest";
import { applyFieldDefaults } from "./fieldDefaults";
import { createMockSchema, createMockSection } from "../test/mocks";

const schema = createMockSchema({
  sections: [
    createMockSection({
      id: "price",
      fields: [
        { id: "includes_tte", label: "TT&E", type: "boolean", required: true, default: true },
        { id: "includes_rr", label: "R&R", type: "boolean", required: true },
        { id: "note", label: "Note", type: "string", required: false, default: "N/A" },
      ],
    }),
  ],
});

describe("applyFieldDefaults", () => {
  it("fills unanswered fields that declare a default", () => {
    expect(applyFieldDefaults(schema, {})).toEqual({ "price.includes_tte": true, "price.note": "N/A" });
  });

  it("never overrides an answer, including false and empty string", () => {
    const answers = { "price.includes_tte": false, "price.note": "" };
    expect(applyFieldDefaults(schema, answers)).toBe(answers);
  });

  it("returns the same object when nothing is missing (so callers can skip a save)", () => {
    const answers = { "price.includes_tte": true, "price.note": "x" };
    expect(applyFieldDefaults(schema, answers)).toBe(answers);
  });

  it("does not mutate the input", () => {
    const answers = { "price.includes_rr": false };
    applyFieldDefaults(schema, answers);
    expect(answers).toEqual({ "price.includes_rr": false });
  });
});
