import { describe, it, expect } from "vitest";
import { parseMultiselectValue, serializeMultiselectValue } from "./multiselectData";

describe("multiselectData", () => {
  describe("parseMultiselectValue", () => {
    it("parses a valid JSON array of strings", () => {
      expect(parseMultiselectValue('["SOW","Pricing"]')).toEqual(["SOW", "Pricing"]);
    });

    it("returns empty array for undefined", () => {
      expect(parseMultiselectValue(undefined)).toEqual([]);
    });

    it("returns empty array for null", () => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      expect(parseMultiselectValue(null as any)).toEqual([]);
    });

    it("returns empty array for empty string", () => {
      expect(parseMultiselectValue("")).toEqual([]);
    });

    it("returns empty array for whitespace-only string", () => {
      expect(parseMultiselectValue("   ")).toEqual([]);
    });

    it("returns empty array for non-string types", () => {
      expect(parseMultiselectValue(42)).toEqual([]);
      expect(parseMultiselectValue(true)).toEqual([]);
    });

    it("returns empty array for invalid JSON", () => {
      expect(parseMultiselectValue("not json")).toEqual([]);
    });

    it("returns empty array for a JSON object (not array)", () => {
      expect(parseMultiselectValue('{"a":1}')).toEqual([]);
    });

    it("returns empty array for an array containing non-strings", () => {
      expect(parseMultiselectValue("[1, 2, 3]")).toEqual([]);
    });

    it("handles single-element arrays", () => {
      expect(parseMultiselectValue('["Funding"]')).toEqual(["Funding"]);
    });

    it("handles empty arrays", () => {
      expect(parseMultiselectValue("[]")).toEqual([]);
    });
  });

  describe("serializeMultiselectValue", () => {
    it("serializes an array of strings to JSON", () => {
      expect(serializeMultiselectValue(["SOW", "Pricing"])).toBe('["SOW","Pricing"]');
    });

    it("serializes an empty array", () => {
      expect(serializeMultiselectValue([])).toBe("[]");
    });
  });

  describe("round-trip", () => {
    it("preserves values through serialize → parse", () => {
      const original = ["SOW", "Pricing", "Funding"];
      const serialized = serializeMultiselectValue(original);
      const parsed = parseMultiselectValue(serialized);
      expect(parsed).toEqual(original);
    });
  });
});
