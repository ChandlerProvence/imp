/**
 * Table-column masking: blank inputs in columns hidden by `visible_when` and
 * recompute row formulas, so every total is computed from what is shown.
 *
 * Kept free of runtime imports from contentBlocks.ts / visibility.ts so both
 * can use it without a circular import.
 */

import type { DocumentSchema } from "../schemas/types";
import type { BlockValues } from "./contentBlocks";
import { parseTableData, serializeTableData } from "./tableData";
import { computeTableFormulas, constantsOf } from "./formula/evaluate";

/**
 * Resolve a `visible_when` block reference. Undefined → visible (default).
 * An unknown or non-boolean block → hidden (loader validation should
 * prevent this, but fail closed rather than leak content).
 */
export function evaluateVisibleWhen(
  ref: string | undefined,
  blocks: BlockValues,
): boolean {
  if (ref === undefined) return true;
  return blocks[ref] === true;
}

/**
 * Return a copy of `answers` where hidden table-column inputs are blanked and
 * row formulas recomputed. This makes every downstream consumer (formula
 * fields, content-block conditions, generated .docx) see the *masked* price
 * without each consumer knowing about column visibility.
 *
 * Rules:
 * - Only tables with a gated column or a formula column are touched.
 * - Formula columns are never masked (they are derived).
 * - Hidden non-formula columns are set to `""`.
 * - Row formulas are recomputed on the masked row so `total_unit_cost`
 *   drops the hidden rate (`COALESCE("", 0)` = 0).
 * - The original `answers` object is not mutated.
 */
export function maskHiddenColumns(
  schema: DocumentSchema,
  answers: Record<string, string | number | boolean>,
  blocks: BlockValues,
): Record<string, string | number | boolean> {
  let result: Record<string, string | number | boolean> | undefined;
  const constants = constantsOf(schema);

  for (const section of schema.sections) {
    for (const field of section.fields) {
      if (field.type !== "table" || !field.columns) continue;
      // Process tables with gated columns OR formula columns (formulas must be
      // pre-computed so downstream SUM aggregates see values).
      const hasGated = field.columns.some((c) => c.visible_when);
      const hasFormulas = field.columns.some((c) => c.formula);
      if (!hasGated && !hasFormulas) continue;

      const key = `${section.id}.${field.id}`;
      const tableData = parseTableData(answers[key]);
      if (tableData.rows.length === 0) continue;

      // Build set of hidden non-formula column IDs
      const hiddenInputs = new Set<string>();
      if (hasGated) {
        for (const col of field.columns) {
          if (col.visible_when && !col.formula && !evaluateVisibleWhen(col.visible_when, blocks)) {
            hiddenInputs.add(col.id);
          }
        }
      }

      // Mask hidden inputs → "" and recompute formulas
      const maskedRows = hiddenInputs.size > 0
        ? tableData.rows.map((row) => {
            const masked = { ...row };
            for (const id of hiddenInputs) masked[id] = "";
            return masked;
          })
        : tableData.rows;
      const recomputed = hasFormulas
        ? computeTableFormulas(field.columns, maskedRows, constants)
        : maskedRows;

      if (!result) result = { ...answers };
      result[key] = serializeTableData({ rows: recomputed });
    }
  }

  return result ?? answers;
}
