import { describe, it, expect } from "vitest";
import type { DocumentSchema, SectionDef, FieldDef } from "../schemas/types";
import {
  evaluateVisibleWhen,
  isSectionVisible,
  isFieldVisible,
  getVisibleSections,
  getVisibleFields,
  inferMultiselectGateUpdates,
} from "./visibility";
import { serializeMultiselectValue } from "./multiselectData";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function makeSection(id: string, opts?: { visible_when?: string; fields?: FieldDef[] }): SectionDef {
  return {
    id,
    title: `Section ${id}`,
    fields: opts?.fields ?? [],
    ...(opts?.visible_when ? { visible_when: opts.visible_when } : {}),
  };
}

function makeField(id: string, opts?: Partial<FieldDef>): FieldDef {
  return {
    id,
    label: `Field ${id}`,
    type: "string",
    required: true,
    ...opts,
  };
}

// Minimal schema that mirrors the FMS TO Mod pattern:
//   changes.mod_types (multiselect) drives named content blocks; sections
//   and fields reference blocks by name.
const modSchema = {
  content_blocks: {
    SOW_CHANGE: { when: { field: "changes.mod_types", contains: "SOW" } },
    PRICE_CHANGE: { when: { field: "changes.mod_types", contains: "Pricing" } },
    FUNDING_CHANGE: { when: { field: "changes.mod_types", contains: "Funding" } },
    PRECEDENCE: { when: { field: "changes.mod_types", contains: "Precedence" } },
    ALWAYS: true,
    NEVER: false,
    LABEL: "some text",
  },
  sections: [
    makeSection("header", { fields: [makeField("idiq_number")] }),
    makeSection("changes", {
      fields: [
        makeField("mod_types", { type: "multiselect" }),
        makeField("price_note", { visible_when: "PRICE_CHANGE" }),
        makeField("funding_note", { visible_when: "FUNDING_CHANGE" }),
      ],
    }),
    makeSection("sow", { visible_when: "SOW_CHANGE", fields: [makeField("sow_date")] }),
    makeSection("pricing", { visible_when: "PRICE_CHANGE", fields: [makeField("parts_list")] }),
    makeSection("funding", { visible_when: "FUNDING_CHANGE", fields: [makeField("funded_amount")] }),
    makeSection("precedence", {
      visible_when: "PRECEDENCE",
      fields: [makeField("precedence_reason"), makeField("precedence_sow_date", { type: "date" })],
    }),
    makeSection("always", { visible_when: "ALWAYS" }),
    makeSection("never", { visible_when: "NEVER" }),
    makeSection("mod_log"),
  ],
} as unknown as DocumentSchema;

const mods = (...v: string[]) => ({ "changes.mod_types": serializeMultiselectValue(v) });

// ---------------------------------------------------------------------------
// evaluateVisibleWhen
// ---------------------------------------------------------------------------

describe("evaluateVisibleWhen", () => {
  it("returns true when no reference is set (backward-compatible default)", () => {
    expect(evaluateVisibleWhen(undefined, {})).toBe(true);
  });

  it("resolves a block reference to its boolean value", () => {
    expect(evaluateVisibleWhen("X", { X: true })).toBe(true);
    expect(evaluateVisibleWhen("X", { X: false })).toBe(false);
  });

  it("fails closed for unknown or non-boolean blocks", () => {
    expect(evaluateVisibleWhen("MISSING", {})).toBe(false);
    expect(evaluateVisibleWhen("LABEL", { LABEL: "text" })).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// isSectionVisible / isFieldVisible
// ---------------------------------------------------------------------------

describe("isSectionVisible", () => {
  it("returns true for sections without visible_when", () => {
    expect(isSectionVisible(makeSection("header"), modSchema, {})).toBe(true);
  });

  it("evaluates the referenced block", () => {
    const sow = modSchema.sections.find((s) => s.id === "sow")!;
    expect(isSectionVisible(sow, modSchema, mods("SOW"))).toBe(true);
    expect(isSectionVisible(sow, modSchema, mods("Pricing"))).toBe(false);
  });

  it("honours literal blocks", () => {
    const always = modSchema.sections.find((s) => s.id === "always")!;
    const never = modSchema.sections.find((s) => s.id === "never")!;
    expect(isSectionVisible(always, modSchema, {})).toBe(true);
    expect(isSectionVisible(never, modSchema, {})).toBe(false);
  });
});

describe("isFieldVisible", () => {
  it("returns true for fields without visible_when", () => {
    expect(isFieldVisible(makeField("name"), modSchema, {})).toBe(true);
  });

  it("evaluates the referenced block", () => {
    const field = makeField("price_note", { visible_when: "PRICE_CHANGE" });
    expect(isFieldVisible(field, modSchema, mods("Pricing"))).toBe(true);
    expect(isFieldVisible(field, modSchema, mods("SOW"))).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// getVisibleSections / getVisibleFields
// ---------------------------------------------------------------------------

describe("getVisibleSections", () => {
  it("hides all gated sections when the gate is empty", () => {
    const result = getVisibleSections(modSchema, {});
    expect(result.map((s) => s.id)).toEqual(["header", "changes", "always", "mod_log"]);
  });

  it("shows matching sections when the gate includes SOW", () => {
    const result = getVisibleSections(modSchema, mods("SOW"));
    expect(result.map((s) => s.id)).toEqual(["header", "changes", "sow", "always", "mod_log"]);
  });

  it("shows all gated sections when every option is selected", () => {
    const result = getVisibleSections(modSchema, mods("SOW", "Pricing", "Funding", "Precedence"));
    expect(result.map((s) => s.id)).toEqual([
      "header", "changes", "sow", "pricing", "funding", "precedence", "always", "mod_log",
    ]);
  });
});

describe("getVisibleFields", () => {
  const changes = modSchema.sections.find((s) => s.id === "changes")!;

  it("returns only unconditional fields when the gate is empty", () => {
    expect(getVisibleFields(changes, modSchema, {}).map((f) => f.id)).toEqual(["mod_types"]);
  });

  it("returns matching fields when the gate includes Pricing", () => {
    expect(getVisibleFields(changes, modSchema, mods("Pricing")).map((f) => f.id)).toEqual([
      "mod_types",
      "price_note",
    ]);
  });

  it("returns all fields when the gate includes all options", () => {
    expect(getVisibleFields(changes, modSchema, mods("Pricing", "Funding")).map((f) => f.id)).toEqual([
      "mod_types",
      "price_note",
      "funding_note",
    ]);
  });
});

// ---------------------------------------------------------------------------
// inferMultiselectGateUpdates
// ---------------------------------------------------------------------------

describe("inferMultiselectGateUpdates", () => {
  it("infers 'Precedence' when a precedence-section field is updated but mod_types is empty", () => {
    const updates = { "precedence.precedence_sow_date": "2026-02-15" };
    const result = inferMultiselectGateUpdates(modSchema, updates, mods());
    expect(result).toEqual(mods("Precedence"));
  });

  it("infers 'Pricing' when a field-level gated field is updated", () => {
    const updates = { "changes.price_note": "incorporate R&R rates" };
    const result = inferMultiselectGateUpdates(modSchema, updates, mods());
    expect(result).toEqual(mods("Pricing"));
  });

  it("returns empty when the gate already includes the required value", () => {
    const updates = { "pricing.parts_list": "some data" };
    expect(inferMultiselectGateUpdates(modSchema, updates, mods("Pricing"))).toEqual({});
  });

  it("combines multiple gated sections into a single multiselect update", () => {
    const updates = {
      "precedence.precedence_sow_date": "2026-02-15",
      "funding.funded_amount": 50000,
    };
    const result = inferMultiselectGateUpdates(modSchema, updates, mods());
    const values = JSON.parse(result["changes.mod_types"]) as string[];
    expect(values).toContain("Precedence");
    expect(values).toContain("Funding");
  });

  it("preserves existing multiselect values when adding new ones", () => {
    const updates = { "precedence.precedence_sow_date": "2026-02-15" };
    const result = inferMultiselectGateUpdates(modSchema, updates, mods("Pricing", "SOW"));
    expect(JSON.parse(result["changes.mod_types"])).toEqual(["Pricing", "SOW", "Precedence"]);
  });

  it("returns empty for ungated sections and for literal-block sections", () => {
    expect(inferMultiselectGateUpdates(modSchema, { "header.idiq_number": "P0103" }, {})).toEqual({});
    expect(inferMultiselectGateUpdates(modSchema, { "always.x": "y" }, {})).toEqual({});
  });

  it("reads the gate value from the updates batch if it was already modified", () => {
    const updates: Record<string, string | number | boolean> = {
      ...mods("Pricing"),
      "precedence.precedence_sow_date": "2026-02-15",
    };
    const result = inferMultiselectGateUpdates(modSchema, updates, {});
    expect(JSON.parse(result["changes.mod_types"])).toEqual(["Pricing", "Precedence"]);
  });

  it("returns empty for schemas without content_blocks", () => {
    const plain = { sections: [makeSection("a", { fields: [makeField("b")] })] } as DocumentSchema;
    expect(inferMultiselectGateUpdates(plain, { "a.b": "x" }, {})).toEqual({});
  });
});
