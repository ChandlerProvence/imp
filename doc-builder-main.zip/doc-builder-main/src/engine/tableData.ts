import type { FieldDef, TableColumnDef } from "../schemas/types";

/** A single row in a table. Keys are column IDs, values are cell values. */
export type TableRow = Record<string, string | number | boolean>;

/** The structured table value stored as a JSON string in answers. */
export interface TableData {
  rows: TableRow[];
}

/** Parse the JSON string stored in answers back to structured data. */
export function parseTableData(
  raw: string | number | boolean | undefined,
): TableData {
  if (typeof raw !== "string" || raw === "") {
    return { rows: [] };
  }
  try {
    const parsed = JSON.parse(raw);
    if (parsed && Array.isArray(parsed.rows)) {
      return parsed as TableData;
    }
    return { rows: [] };
  } catch {
    return { rows: [] };
  }
}

/** Serialize table data to a JSON string for answer storage. */
export function serializeTableData(data: TableData): string {
  return JSON.stringify(data);
}

/**
 * Create an empty row for a table field.
 * For dynamic tables, all cells are empty.
 * The optional `rowId` is used for fixed-row tables to tag the row.
 */
export function createEmptyRow(
  columns: TableColumnDef[],
  rowId?: string,
): TableRow {
  const row: TableRow = {};
  if (rowId) {
    row._rowId = rowId;
  }
  for (const col of columns) {
    if (col.type === "boolean") {
      row[col.id] = false;
    } else if (col.type === "number") {
      row[col.id] = "";
    } else {
      row[col.id] = "";
    }
  }
  return row;
}

/**
 * Initialize table data for a fixed-row table, ensuring all defined rows exist.
 */
export function initFixedRowTable(field: FieldDef): TableData {
  if (!field.rows || !field.columns) return { rows: [] };
  return {
    rows: field.rows.map((r) => createEmptyRow(field.columns!, r.id)),
  };
}

/**
 * Check if a table has any non-empty cell value (for section status "hasValue").
 */
export function tableHasValue(
  raw: string | number | boolean | undefined,
): boolean {
  const data = parseTableData(raw);
  return (
    data.rows.length > 0 &&
    data.rows.some((row) =>
      Object.entries(row)
        .filter(([k]) => k !== "_rowId")
        .some(([, v]) => v !== undefined && v !== null && v !== "" && v !== false),
    )
  );
}

/**
 * Check if a required table field is complete (for section status "complete").
 * - Must have at least `min_rows` rows (default 1)
 * - All required columns must have values in every row
 * - For fixed-row tables: all defined rows must be present
 */
export function tableIsComplete(
  raw: string | number | boolean | undefined,
  field: FieldDef,
): boolean {
  const data = parseTableData(raw);
  const minRows = field.min_rows ?? 1;
  const columns = field.columns ?? [];

  // Fixed-row check: all defined rows must exist
  if (field.rows) {
    if (data.rows.length !== field.rows.length) return false;
  } else {
    if (data.rows.length < minRows) return false;
  }

  // Formula columns are auto-computed — never block completion
  const requiredCols = columns.filter((c) => c.required && !c.formula);
  if (requiredCols.length === 0) return data.rows.length >= minRows;

  return data.rows.every((row) =>
    requiredCols.every((col) => {
      const val = row[col.id];
      if (val === undefined || val === null) return false;
      if (typeof val === "string") return val.trim().length > 0;
      return true; // numbers, booleans are always considered filled
    }),
  );
}
