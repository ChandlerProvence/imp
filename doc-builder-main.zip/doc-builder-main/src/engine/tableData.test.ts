import { describe, it, expect } from "vitest";
import {
  parseTableData,
  serializeTableData,
  createEmptyRow,
  initFixedRowTable,
  tableHasValue,
  tableIsComplete,
} from "./tableData";
import type { FieldDef, TableColumnDef } from "../schemas/types";

// ---------------------------------------------------------------------------
// parseTableData
// ---------------------------------------------------------------------------

describe("parseTableData", () => {
  it("returns empty rows for undefined input", () => {
    expect(parseTableData(undefined)).toEqual({ rows: [] });
  });

  it("returns empty rows for empty string", () => {
    expect(parseTableData("")).toEqual({ rows: [] });
  });

  it("returns empty rows for non-string input (number)", () => {
    expect(parseTableData(42)).toEqual({ rows: [] });
  });

  it("returns empty rows for non-string input (boolean)", () => {
    expect(parseTableData(true)).toEqual({ rows: [] });
  });

  it("returns empty rows for invalid JSON", () => {
    expect(parseTableData("not json")).toEqual({ rows: [] });
  });

  it("returns empty rows for JSON without rows array", () => {
    expect(parseTableData(JSON.stringify({ other: "data" }))).toEqual({
      rows: [],
    });
  });

  it("returns empty rows when rows is not an array", () => {
    expect(parseTableData(JSON.stringify({ rows: "nope" }))).toEqual({
      rows: [],
    });
  });

  it("parses valid JSON with rows", () => {
    const input = JSON.stringify({ rows: [{ col1: "a", col2: "b" }] });
    expect(parseTableData(input)).toEqual({ rows: [{ col1: "a", col2: "b" }] });
  });

  it("parses valid JSON with multiple rows", () => {
    const input = JSON.stringify({
      rows: [
        { name: "Alice", age: 30 },
        { name: "Bob", age: 25 },
      ],
    });
    const result = parseTableData(input);
    expect(result.rows).toHaveLength(2);
    expect(result.rows[0]).toEqual({ name: "Alice", age: 30 });
  });
});

// ---------------------------------------------------------------------------
// serializeTableData
// ---------------------------------------------------------------------------

describe("serializeTableData", () => {
  it("serializes empty table", () => {
    const result = serializeTableData({ rows: [] });
    expect(result).toBe('{"rows":[]}');
  });

  it("round-trips with parseTableData", () => {
    const original = { rows: [{ a: "1", b: "2" }, { a: "3", b: "4" }] };
    const serialized = serializeTableData(original);
    expect(parseTableData(serialized)).toEqual(original);
  });
});

// ---------------------------------------------------------------------------
// createEmptyRow
// ---------------------------------------------------------------------------

describe("createEmptyRow", () => {
  it("creates row with empty strings for string columns", () => {
    const columns: TableColumnDef[] = [
      { id: "name", label: "Name", type: "string" },
      { id: "date", label: "Date", type: "date" },
    ];
    expect(createEmptyRow(columns)).toEqual({ name: "", date: "" });
  });

  it("creates row with false for boolean columns", () => {
    const columns: TableColumnDef[] = [
      { id: "active", label: "Active", type: "boolean" },
    ];
    expect(createEmptyRow(columns)).toEqual({ active: false });
  });

  it("creates row with empty string for number columns", () => {
    const columns: TableColumnDef[] = [
      { id: "qty", label: "Quantity", type: "number" },
    ];
    expect(createEmptyRow(columns)).toEqual({ qty: "" });
  });

  it("includes _rowId when provided", () => {
    const columns: TableColumnDef[] = [
      { id: "val", label: "Value", type: "string" },
    ];
    expect(createEmptyRow(columns, "row-1")).toEqual({
      _rowId: "row-1",
      val: "",
    });
  });

  it("omits _rowId when not provided", () => {
    const columns: TableColumnDef[] = [
      { id: "val", label: "Value", type: "string" },
    ];
    const row = createEmptyRow(columns);
    expect(row).not.toHaveProperty("_rowId");
  });
});

// ---------------------------------------------------------------------------
// initFixedRowTable
// ---------------------------------------------------------------------------

describe("initFixedRowTable", () => {
  it("returns empty rows when field has no rows defined", () => {
    const field: FieldDef = {
      id: "t",
      label: "T",
      type: "table",
      required: true,
      columns: [{ id: "a", label: "A", type: "string" }],
    };
    expect(initFixedRowTable(field)).toEqual({ rows: [] });
  });

  it("returns empty rows when field has no columns defined", () => {
    const field: FieldDef = {
      id: "t",
      label: "T",
      type: "table",
      required: true,
      rows: [{ id: "r1", label: "Row 1" }],
    };
    expect(initFixedRowTable(field)).toEqual({ rows: [] });
  });

  it("creates one row per defined row with correct rowIds", () => {
    const field: FieldDef = {
      id: "t",
      label: "T",
      type: "table",
      required: true,
      columns: [
        { id: "name", label: "Name", type: "string" },
        { id: "done", label: "Done", type: "boolean" },
      ],
      rows: [
        { id: "r1", label: "Row 1" },
        { id: "r2", label: "Row 2" },
      ],
    };
    const result = initFixedRowTable(field);
    expect(result.rows).toHaveLength(2);
    expect(result.rows[0]).toEqual({ _rowId: "r1", name: "", done: false });
    expect(result.rows[1]).toEqual({ _rowId: "r2", name: "", done: false });
  });
});

// ---------------------------------------------------------------------------
// tableHasValue
// ---------------------------------------------------------------------------

describe("tableHasValue", () => {
  it("returns false for undefined", () => {
    expect(tableHasValue(undefined)).toBe(false);
  });

  it("returns false for empty rows", () => {
    expect(tableHasValue(JSON.stringify({ rows: [] }))).toBe(false);
  });

  it("returns false when rows only have _rowId", () => {
    const data = JSON.stringify({ rows: [{ _rowId: "r1" }] });
    expect(tableHasValue(data)).toBe(false);
  });

  it("returns false when all cells are empty strings", () => {
    const data = JSON.stringify({ rows: [{ _rowId: "r1", name: "" }] });
    expect(tableHasValue(data)).toBe(false);
  });

  it("returns false when boolean cells are false", () => {
    const data = JSON.stringify({ rows: [{ done: false }] });
    expect(tableHasValue(data)).toBe(false);
  });

  it("returns true when a string cell has content", () => {
    const data = JSON.stringify({ rows: [{ name: "Alice" }] });
    expect(tableHasValue(data)).toBe(true);
  });

  it("returns true when a boolean cell is true", () => {
    const data = JSON.stringify({ rows: [{ done: true }] });
    expect(tableHasValue(data)).toBe(true);
  });

  it("returns true when a number cell has a value", () => {
    const data = JSON.stringify({ rows: [{ qty: 5 }] });
    expect(tableHasValue(data)).toBe(true);
  });
});

// ---------------------------------------------------------------------------
// tableIsComplete
// ---------------------------------------------------------------------------

describe("tableIsComplete", () => {
  const columns: TableColumnDef[] = [
    { id: "name", label: "Name", type: "string", required: true },
    { id: "notes", label: "Notes", type: "string" },
  ];

  const baseField: FieldDef = {
    id: "t",
    label: "T",
    type: "table",
    required: true,
    columns,
  };

  it("returns false when there are fewer rows than min_rows", () => {
    const field = { ...baseField, min_rows: 2 };
    const data = JSON.stringify({ rows: [{ name: "A", notes: "" }] });
    expect(tableIsComplete(data, field)).toBe(false);
  });

  it("returns false when required columns are empty", () => {
    const data = JSON.stringify({ rows: [{ name: "", notes: "hi" }] });
    expect(tableIsComplete(data, baseField)).toBe(false);
  });

  it("returns false when required columns are whitespace-only", () => {
    const data = JSON.stringify({ rows: [{ name: "   ", notes: "" }] });
    expect(tableIsComplete(data, baseField)).toBe(false);
  });

  it("returns true when all required columns are filled", () => {
    const data = JSON.stringify({ rows: [{ name: "Alice", notes: "" }] });
    expect(tableIsComplete(data, baseField)).toBe(true);
  });

  it("returns true with multiple rows meeting requirements", () => {
    const field = { ...baseField, min_rows: 2 };
    const data = JSON.stringify({
      rows: [
        { name: "Alice", notes: "" },
        { name: "Bob", notes: "" },
      ],
    });
    expect(tableIsComplete(data, field)).toBe(true);
  });

  it("handles fixed-row tables — requires exact row count", () => {
    const field: FieldDef = {
      ...baseField,
      rows: [
        { id: "r1", label: "Row 1" },
        { id: "r2", label: "Row 2" },
      ],
    };
    // Only 1 row present but 2 expected
    const data = JSON.stringify({ rows: [{ name: "A", notes: "" }] });
    expect(tableIsComplete(data, field)).toBe(false);
  });

  it("returns true for fixed-row table with correct count and filled required cols", () => {
    const field: FieldDef = {
      ...baseField,
      rows: [
        { id: "r1", label: "Row 1" },
        { id: "r2", label: "Row 2" },
      ],
    };
    const data = JSON.stringify({
      rows: [
        { _rowId: "r1", name: "A", notes: "" },
        { _rowId: "r2", name: "B", notes: "" },
      ],
    });
    expect(tableIsComplete(data, field)).toBe(true);
  });

  it("returns true with no required columns if row count is met", () => {
    const field: FieldDef = {
      id: "t",
      label: "T",
      type: "table",
      required: true,
      columns: [{ id: "notes", label: "Notes", type: "string" }],
    };
    const data = JSON.stringify({ rows: [{ notes: "" }] });
    expect(tableIsComplete(data, field)).toBe(true);
  });

  it("returns false for undefined value", () => {
    expect(tableIsComplete(undefined, baseField)).toBe(false);
  });
});
