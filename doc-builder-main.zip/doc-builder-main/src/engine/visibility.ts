/**
 * Section / field visibility.
 *
 * A section or field with `visible_when: "BLOCK_NAME"` is visible while that
 * content block evaluates to `true`. All conditional logic lives in
 * `content_blocks` (see ./contentBlocks.ts); this module only resolves the
 * name reference.
 *
 * Pure functions — no side effects, fully unit-testable.
 */

import type { DocumentSchema, FieldDef, SectionDef, TableColumnDef } from "../schemas/types";
import { evaluateContentBlocks, getBlockGate, type BlockValues } from "./contentBlocks";
import { parseMultiselectValue, serializeMultiselectValue } from "./multiselectData";
import { evaluateVisibleWhen } from "./columnMasking";

export { evaluateVisibleWhen } from "./columnMasking";

/** Check whether a section is visible given the current answers. */
export function isSectionVisible(
  section: SectionDef,
  schema: DocumentSchema,
  answers: Record<string, string | number | boolean>,
  blocks: BlockValues = evaluateContentBlocks(schema, answers),
): boolean {
  return evaluateVisibleWhen(section.visible_when, blocks);
}

/** Check whether a field is visible given the current answers. */
export function isFieldVisible(
  field: FieldDef,
  schema: DocumentSchema,
  answers: Record<string, string | number | boolean>,
  blocks: BlockValues = evaluateContentBlocks(schema, answers),
): boolean {
  return evaluateVisibleWhen(field.visible_when, blocks);
}

/** Return only the visible sections for a schema given the current answers. */
export function getVisibleSections(
  schema: DocumentSchema,
  answers: Record<string, string | number | boolean>,
): SectionDef[] {
  const blocks = evaluateContentBlocks(schema, answers);
  return schema.sections.filter((s) => evaluateVisibleWhen(s.visible_when, blocks));
}

/** Return only the visible fields for a section given the current answers. */
export function getVisibleFields(
  section: SectionDef,
  schema: DocumentSchema,
  answers: Record<string, string | number | boolean>,
  blocks: BlockValues = evaluateContentBlocks(schema, answers),
): FieldDef[] {
  return section.fields.filter((f) => evaluateVisibleWhen(f.visible_when, blocks));
}

// ---------------------------------------------------------------------------
// Column visibility
// ---------------------------------------------------------------------------

/** Return only the visible columns for a table field given the current blocks. */
export function getVisibleColumns(
  field: FieldDef,
  blocks: BlockValues,
): TableColumnDef[] {
  return (field.columns ?? []).filter((c) => evaluateVisibleWhen(c.visible_when, blocks));
}

// ---------------------------------------------------------------------------
// Multiselect gate inference
// ---------------------------------------------------------------------------

/**
 * Given a batch of answer updates, find any multiselect gate fields that
 * need values added to keep visibility consistent.
 *
 * If an update targets a field in a section (or a field) gated on a block
 * whose condition is `{ field: "X.Y", contains: "Value" }` and the current
 * multiselect at X.Y doesn't include "Value", returns
 * `{ "X.Y": newSerializedArray }` to merge into the batch.
 *
 * This prevents a common AI extraction gap: the model fills gated fields
 * without ticking the gate, leaving the section invisible in both the
 * interview UI and the generated document.
 */
export function inferMultiselectGateUpdates(
  schema: DocumentSchema,
  updates: Record<string, string | number | boolean>,
  currentAnswers: Record<string, string | number | boolean>,
): Record<string, string> {
  // gate field key → values that must be present
  const required = new Map<string, Set<string>>();

  const addRequired = (blockRef: string | undefined) => {
    if (!blockRef) return;
    const gate = getBlockGate(schema, blockRef);
    if (!gate) return;
    if (!required.has(gate.field)) required.set(gate.field, new Set<string>());
    required.get(gate.field)!.add(gate.value);
  };

  for (const key of Object.keys(updates)) {
    const dotIdx = key.indexOf(".");
    if (dotIdx < 0) continue;
    const sectionId = key.substring(0, dotIdx);
    const fieldId = key.substring(dotIdx + 1);

    const section = schema.sections.find((s) => s.id === sectionId);
    if (!section) continue;

    addRequired(section.visible_when);
    addRequired(section.fields.find((f) => f.id === fieldId)?.visible_when);
  }

  if (required.size === 0) return {};

  const result: Record<string, string> = {};
  for (const [gateKey, neededValues] of required) {
    // Start from the batch value if present, otherwise from current answers
    const base = gateKey in updates ? updates[gateKey] : currentAnswers[gateKey];
    const existing = parseMultiselectValue(base);

    let changed = false;
    for (const v of neededValues) {
      if (!existing.includes(v)) {
        existing.push(v);
        changed = true;
      }
    }
    if (changed) result[gateKey] = serializeMultiselectValue(existing);
  }
  return result;
}
