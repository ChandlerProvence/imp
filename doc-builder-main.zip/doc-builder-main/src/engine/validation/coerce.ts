/**
 * Value coercion helpers shared by validation rules and content-block
 * conditions, so both layers agree on what a "number" or "date" answer is.
 */

export type AnswerValue = string | number | boolean;

/** True when a value counts as "not entered" (rules are never run on these). */
export function isEmptyValue(val: unknown): boolean {
  if (val === undefined || val === null) return true;
  if (typeof val === "string") return val.trim().length === 0;
  return false;
}

/** A whole number: optional sign, digits with optional thousands commas, optional decimals. */
const NUMBER_TEXT = /^[-+]?(?:(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d*)?|\.\d+)$/;

/**
 * Coerce an answer value to a number, or null when absent/invalid. Dollar
 * signs and whitespace are ignored, and commas are allowed only as thousands
 * separators, so "$1,234.50" reads as 1234.5. The whole text must be a
 * number: "12abc", "45 days", and "1234,5" (a decimal comma) are null rather
 * than half-read, so what a user sees is never silently totalled differently.
 */
export function toNumber(raw: unknown): number | null {
  if (raw === undefined || raw === null || raw === "" || typeof raw === "boolean") return null;
  if (typeof raw === "number") return Number.isFinite(raw) ? raw : null;
  const text = String(raw).replace(/[$\s]/g, "");
  if (!NUMBER_TEXT.test(text)) return null;
  return Number(text.replace(/,/g, ""));
}

const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;

/** Return the value as a "YYYY-MM-DD" string when it is a real calendar date, else null. */
export function toIsoDate(raw: unknown): string | null {
  if (typeof raw !== "string" || !ISO_DATE.test(raw)) return null;
  const d = new Date(`${raw}T00:00:00Z`);
  if (isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== raw) return null;
  return raw;
}
