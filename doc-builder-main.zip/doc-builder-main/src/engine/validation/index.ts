/**
 * Validation engine — runs schema-declared `validate` rules against answers.
 *
 * Rule-agnostic: every rule is looked up in ./registry.ts. Consumers:
 * - loader.ts → `checkRuleSpecs` (load-time param checks)
 * - SessionContext → `validateAnswers` (inline errors, sidebar, Review)
 * - bulkEdit.ts → `validateProposedValue` (AI proposal warnings)
 * - bulkEdit.ts prompt / FieldRenderer → `describeRules`, `inputAttrsFor`
 *
 * Validation never blocks: issues are surfaced as warnings only.
 * Pure functions — no side effects, fully unit-testable.
 */

import type { DocumentSchema, FieldDef, RuleSpec, SectionDef, TableColumnDef } from "../../schemas/types";
import type { BlockValues } from "../contentBlocks";
import { resolveEffectiveAnswers } from "../effectiveAnswers";
import { parseTableData, type TableRow } from "../tableData";
import { evaluateVisibleWhen } from "../visibility";
import { isEmptyValue, toNumber, type AnswerValue } from "./coerce";
import { getRule } from "./registry";
import type { RuleTarget, SchemaContext, ValidationIssue, ValidationIssues, ValueContext } from "./types";

export type { ValidationIssue, ValidationIssues, ValidationRule } from "./types";
export { RULE_REGISTRY, getRule } from "./registry";

type Answers = Record<string, AnswerValue>;

// ─── Load time ──────────────────────────────────────────────────────────────

/**
 * Check a raw `validate` value from a schema file. Returns error strings
 * without a location prefix (the loader adds it).
 */
export function checkRuleSpecs(raw: unknown, ctx: SchemaContext): string[] {
  if (raw === undefined) return [];
  if (!Array.isArray(raw)) return ["`validate` must be an array of rule objects"];
  const errors: string[] = [];
  raw.forEach((item, i) => {
    const where = `validate[${i}]`;
    if (typeof item !== "object" || item === null || Array.isArray(item)) {
      errors.push(`${where}: must be an object with a \`rule\` name`);
      return;
    }
    const spec = item as RuleSpec;
    const rule = typeof spec.rule === "string" ? getRule(spec.rule) : undefined;
    if (!rule) {
      errors.push(`${where}: unknown rule "${String(spec.rule)}"`);
      return;
    }
    if (!rule.appliesTo.includes(ctx.target.type)) {
      errors.push(
        `${where}: rule "${rule.id}" does not apply to ${ctx.target.type} ${ctx.isColumn ? "columns" : "fields"} (allowed: ${rule.appliesTo.join(", ")})`,
      );
      return;
    }
    if (spec.message !== undefined && (typeof spec.message !== "string" || spec.message.length === 0)) {
      errors.push(`${where}: \`message\` must be a non-empty string`);
    }
    if (spec.severity !== undefined && spec.severity !== "warning" && spec.severity !== "info") {
      errors.push(`${where}: \`severity\` must be "warning" or "info"`);
    }
    for (const e of rule.checkParams(spec, ctx)) errors.push(`${where}: ${e}`);
  });
  return errors;
}

// ─── Runtime ────────────────────────────────────────────────────────────────

function fieldTarget(field: FieldDef): RuleTarget {
  return { type: field.type, label: field.label, computed: field.formula !== undefined };
}

function columnTarget(col: TableColumnDef): RuleTarget {
  return { type: col.type, label: col.label, computed: !!col.formula };
}

/** Resolved state shared by every rule evaluation in one pass. */
interface Env {
  answers: Answers;
  computed: Record<string, number | null>;
  /** Visible, existing fields by answer key. */
  visible: Map<string, FieldDef>;
  blocks: BlockValues;
}

function buildEnv(schema: DocumentSchema, answers: Answers): Env {
  // Rules check what the user entered (`answers`), but compare against
  // computed values and visibility as the user sees them.
  const { blocks: resolvedBlocks, computed } = resolveEffectiveAnswers(schema, answers);
  const visible = new Map<string, FieldDef>();
  for (const section of schema.sections) {
    if (!evaluateVisibleWhen(section.visible_when, resolvedBlocks)) continue;
    for (const field of section.fields) {
      if (evaluateVisibleWhen(field.visible_when, resolvedBlocks)) {
        visible.set(`${section.id}.${field.id}`, field);
      }
    }
  }
  return { answers, computed, visible, blocks: resolvedBlocks };
}

function fieldValue(env: Env, ref: string): AnswerValue | undefined {
  if (!env.visible.has(ref)) return undefined;
  if (ref in env.computed) return env.computed[ref] ?? undefined;
  const v = env.answers[ref];
  return isEmptyValue(v) ? undefined : v;
}

function runSpecs(
  specs: RuleSpec[] | undefined,
  value: unknown,
  ctx: ValueContext,
  row?: number,
  prefix = "",
): ValidationIssue[] {
  if (!specs || isEmptyValue(value)) return [];
  const issues: ValidationIssue[] = [];
  for (const spec of specs) {
    const rule = getRule(spec.rule);
    if (!rule) {
      // The loader rejects unknown rules; this only guards hand-built schemas.
      console.warn(`[doc-builder] Unknown validation rule "${spec.rule}" on ${ctx.fieldKey}`);
      continue;
    }
    if (!rule.appliesTo.includes(ctx.target.type)) continue;
    const failure = rule.check(value as AnswerValue, spec, ctx);
    if (failure === null) continue;
    issues.push({
      rule: rule.id,
      message: prefix + (spec.message ?? failure),
      severity: spec.severity ?? "warning",
      ...(row !== undefined ? { row } : {}),
    });
  }
  return issues;
}

function fieldContext(env: Env, fieldKey: string, field: FieldDef): ValueContext {
  return {
    fieldKey,
    target: fieldTarget(field),
    getValue: (ref) => fieldValue(env, ref),
    getLabel: (ref) => env.visible.get(ref)?.label ?? ref,
  };
}

function rowLabel(field: FieldDef, row: TableRow, index: number): string {
  const fixed = typeof row._rowId === "string" ? field.rows?.find((r) => r.id === row._rowId) : undefined;
  return fixed?.label ?? `Row ${index + 1}`;
}

/**
 * Built-in check for every user-entered number: text that doesn't parse as a
 * whole number (e.g. "12abc", or "1234,5" with a decimal comma) is flagged,
 * since totals would otherwise silently treat it as empty.
 */
function notANumber(type: string, value: unknown, row?: number, prefix = ""): ValidationIssue | null {
  if (type !== "number" || isEmptyValue(value) || toNumber(value) !== null) return null;
  return { rule: "number", message: `${prefix}Must be a number`, severity: "warning", ...(row !== undefined ? { row } : {}) };
}

/** Validate one field (scalar or table) against its rules. */
function validateOne(env: Env, fieldKey: string, field: FieldDef, value: unknown): ValidationIssue[] {
  if (field.type !== "table") {
    const nan = notANumber(field.type, value);
    if (nan) return [nan];
    return runSpecs(field.validate, value, fieldContext(env, fieldKey, field));
  }
  const columns = (field.columns ?? []).filter(
    (c) =>
      (c.validate?.length || (c.type === "number" && !c.formula)) &&
      evaluateVisibleWhen(c.visible_when, env.blocks),
  );
  if (columns.length === 0) return [];
  const visibleCols = new Map(
    (field.columns ?? [])
      .filter((c) => evaluateVisibleWhen(c.visible_when, env.blocks))
      .map((c) => [c.id, c]),
  );
  const issues: ValidationIssue[] = [];
  parseTableData(value as AnswerValue | undefined).rows.forEach((row, i) => {
    for (const col of columns) {
      const ctx: ValueContext = {
        fieldKey,
        target: columnTarget(col),
        getValue: (ref) => {
          if (visibleCols.has(ref)) return isEmptyValue(row[ref]) ? undefined : row[ref];
          return fieldValue(env, ref);
        },
        getLabel: (ref) => visibleCols.get(ref)?.label ?? env.visible.get(ref)?.label ?? ref,
      };
      const prefix = `${rowLabel(field, row, i)}, ${col.label}: `;
      const nan = col.formula ? null : notANumber(col.type, row[col.id], i, prefix);
      if (nan) {
        issues.push(nan);
        continue;
      }
      issues.push(...runSpecs(col.validate, row[col.id], ctx, i, prefix));
    }
  });
  return issues;
}

function skipField(field: FieldDef): boolean {
  return field.formula !== undefined || !!field.same_as || field.type === "image";
}

/**
 * Validate every visible, user-entered field. Computed and `same_as`
 * fields are skipped (their sources are validated instead).
 */
export function validateAnswers(schema: DocumentSchema, answers: Answers): ValidationIssues {
  const env = buildEnv(schema, answers);
  const out: ValidationIssues = {};
  for (const [key, field] of env.visible) {
    if (skipField(field)) continue;
    const issues = validateOne(env, key, field, answers[key]);
    if (issues.length > 0) out[key] = issues;
  }
  return out;
}

/**
 * Validate a single proposed value (e.g. from the AI) in the context of the
 * current answers. Returns [] for unknown, hidden, or rule-less fields.
 */
export function validateProposedValue(
  schema: DocumentSchema,
  fieldKey: string,
  value: AnswerValue,
  answers: Answers,
): ValidationIssue[] {
  const env = buildEnv(schema, { ...answers, [fieldKey]: value });
  const field = env.visible.get(fieldKey);
  if (!field || skipField(field)) return [];
  return validateOne(env, fieldKey, field, value);
}

/** Count warning-level issues, optionally restricted to one section. */
export function countWarnings(issues: ValidationIssues, sectionId?: string): number {
  let n = 0;
  for (const [key, list] of Object.entries(issues)) {
    if (sectionId !== undefined && !key.startsWith(`${sectionId}.`)) continue;
    n += list.filter((i) => i.severity === "warning").length;
  }
  return n;
}

// ─── Presentation helpers ───────────────────────────────────────────────────

/**
 * Plain-text constraint summary for AI prompts, e.g. "≥ 0; less than or equal
 * to Funded Amount". Empty string when there are no describable rules.
 */
export function describeRules(
  specs: RuleSpec[] | undefined,
  schema: DocumentSchema,
  siblingColumns: TableColumnDef[] = [],
): string {
  if (!specs?.length) return "";
  const getLabel = (ref: string) =>
    siblingColumns.find((c) => c.id === ref)?.label ?? findFieldLabel(schema, ref) ?? ref;
  return specs
    .map((spec) => getRule(spec.rule)?.describe?.(spec, { getLabel }) ?? "")
    .filter(Boolean)
    .join("; ");
}

/** Merged native input attributes (min/max/…) for a set of rules. */
export function inputAttrsFor(specs: RuleSpec[] | undefined): Record<string, string | number> {
  const attrs: Record<string, string | number> = {};
  for (const spec of specs ?? []) Object.assign(attrs, getRule(spec.rule)?.inputAttrs?.(spec));
  return attrs;
}

function findFieldLabel(schema: DocumentSchema, ref: string): string | undefined {
  const [sectionId, fieldId] = ref.split(".");
  const section: SectionDef | undefined = schema.sections.find((s) => s.id === sectionId);
  return section?.fields.find((f) => f.id === fieldId)?.label;
}
