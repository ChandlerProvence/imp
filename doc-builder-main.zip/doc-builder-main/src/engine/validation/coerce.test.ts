import { describe, it, expect } from "vitest";
import { toNumber } from "./coerce";

describe("toNumber", () => {
  it("passes numbers through", () => {
    expect(toNumber(1234.5)).toBe(1234.5);
    expect(toNumber(0)).toBe(0);
  });

  it("ignores thousands separators, dollar signs, and whitespace", () => {
    expect(toNumber("1,234.50")).toBe(1234.5);
    expect(toNumber("$2,000")).toBe(2000);
    expect(toNumber(" $ 50,000.00 ")).toBe(50000);
    expect(toNumber("-$6,300.00")).toBe(-6300);
  });

  it("accepts signs, leading decimals, and long thousands groups", () => {
    expect(toNumber("1,234,567.89")).toBe(1234567.89);
    expect(toNumber("$-6,300")).toBe(-6300);
    expect(toNumber("+42")).toBe(42);
    expect(toNumber(".5")).toBe(0.5);
    expect(toNumber("12.")).toBe(12);
  });

  it("rejects text that is only partly a number", () => {
    expect(toNumber("12abc")).toBeNull();
    expect(toNumber("45 days")).toBeNull();
    expect(toNumber("approx. 5,000")).toBeNull();
    expect(toNumber("1.2.3")).toBeNull();
    expect(toNumber("1e3")).toBeNull();
    expect(toNumber("0x10")).toBeNull();
  });

  it("rejects commas outside thousands positions (e.g. a decimal comma)", () => {
    expect(toNumber("1234,5")).toBeNull();
    expect(toNumber("12,34")).toBeNull();
    expect(toNumber("1,2345")).toBeNull();
    expect(toNumber(",123")).toBeNull();
  });

  it("returns null for empty, boolean, or non-numeric input", () => {
    expect(toNumber(undefined)).toBeNull();
    expect(toNumber("")).toBeNull();
    expect(toNumber("   ")).toBeNull();
    expect(toNumber(true)).toBeNull();
    expect(toNumber("abc")).toBeNull();
  });
});
