/**
 * `range` — inclusive lower/upper bound on a number or date.
 *
 *   { "rule": "range", "min": 0 }
 *   { "rule": "range", "min": "2020-01-01", "max": "2035-12-31" }
 *
 * Number fields take numeric bounds; date fields take "YYYY-MM-DD" bounds.
 */

import type { RuleSpec, ValidationRule } from "../types";
import { toIsoDate, toNumber } from "../coerce";

interface RangeSpec extends RuleSpec {
  min?: number | string;
  max?: number | string;
}

export const rangeRule: ValidationRule<RangeSpec> = {
  id: "range",
  appliesTo: ["number", "date"],

  checkParams(spec, ctx) {
    const errors: string[] = [];
    if (spec.min === undefined && spec.max === undefined) {
      errors.push("range requires `min` and/or `max`");
      return errors;
    }
    const isDate = ctx.target.type === "date";
    for (const key of ["min", "max"] as const) {
      const bound = spec[key];
      if (bound === undefined) continue;
      if (isDate ? toIsoDate(bound) === null : typeof bound !== "number" || !Number.isFinite(bound)) {
        errors.push(`range \`${key}\` must be ${isDate ? 'a "YYYY-MM-DD" date' : "a finite number"}`);
      }
    }
    if (errors.length === 0 && spec.min !== undefined && spec.max !== undefined && spec.min > spec.max) {
      errors.push("range `min` must not exceed `max`");
    }
    return errors;
  },

  check(value, spec, ctx) {
    if (ctx.target.type === "date") {
      const date = toIsoDate(value);
      if (date === null) return "Must be a valid date (YYYY-MM-DD)";
      if (typeof spec.min === "string" && date < spec.min) return `Must be on or after ${spec.min}`;
      if (typeof spec.max === "string" && date > spec.max) return `Must be on or before ${spec.max}`;
      return null;
    }
    const num = toNumber(value);
    if (num === null) return "Must be a number";
    if (typeof spec.min === "number" && num < spec.min) return `Must be at least ${spec.min}`;
    if (typeof spec.max === "number" && num > spec.max) return `Must be at most ${spec.max}`;
    return null;
  },

  describe(spec) {
    const parts: string[] = [];
    if (spec.min !== undefined) parts.push(`≥ ${spec.min}`);
    if (spec.max !== undefined) parts.push(`≤ ${spec.max}`);
    return parts.join(", ");
  },

  inputAttrs(spec) {
    const attrs: Record<string, string | number> = {};
    if (spec.min !== undefined) attrs.min = spec.min;
    if (spec.max !== undefined) attrs.max = spec.max;
    return attrs;
  },
};
