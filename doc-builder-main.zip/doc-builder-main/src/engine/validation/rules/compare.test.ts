import { describe, it, expect } from "vitest";
import { compareRule } from "./compare";
import type { AnswerValue, RuleTarget, SchemaContext, ValidationRule, ValueContext } from "../types";

// Exercised through the generic interface, as the engine calls it (specs come from JSON).
const rule = compareRule as unknown as ValidationRule;

const num: RuleTarget = { type: "number", label: "Funded", computed: false };
const date: RuleTarget = { type: "date", label: "End", computed: false };

function schemaCtx(target: RuleTarget, refs: Record<string, RuleTarget>): SchemaContext {
  return { fieldKey: "s.self", target, isColumn: false, resolveRef: (r) => refs[r] ?? null };
}
function valueCtx(target: RuleTarget, values: Record<string, AnswerValue>): ValueContext {
  return {
    fieldKey: "s.self",
    target,
    getValue: (r) => values[r],
    getLabel: (r) => (r === "s.other" ? "Other Field" : r),
  };
}

describe("compare rule", () => {
  describe("checkParams", () => {
    it("accepts a numeric comparison against a number or computed field", () => {
      expect(
        rule.checkParams({ rule: "compare", op: "lte", other: "s.other" }, schemaCtx(num, { "s.other": num })),
      ).toEqual([]);
      expect(
        rule.checkParams(
          { rule: "compare", op: "lte", other: "s.other" },
          schemaCtx(num, { "s.other": { type: "number", label: "T", computed: true } }),
        ),
      ).toEqual([]);
    });
    it("rejects unknown op, missing/unknown other, self-reference, incomparable types", () => {
      const refs = { "s.other": num, "s.d": date, "s.self": num };
      expect(rule.checkParams({ rule: "compare", op: "lessthan", other: "s.other" }, schemaCtx(num, refs))[0]).toMatch(/op/);
      expect(rule.checkParams({ rule: "compare", op: "lt" }, schemaCtx(num, refs))[0]).toMatch(/requires `other`/);
      expect(rule.checkParams({ rule: "compare", op: "lt", other: "s.nope" }, schemaCtx(num, refs))[0]).toMatch(/non-existent/);
      expect(rule.checkParams({ rule: "compare", op: "lt", other: "s.self" }, schemaCtx(num, refs))[0]).toMatch(/itself/);
      expect(rule.checkParams({ rule: "compare", op: "lt", other: "s.d" }, schemaCtx(num, refs))[0]).toMatch(/not comparable/);
    });
  });

  describe("check", () => {
    it.each([
      ["lt", 4, null],
      ["lt", 5, "Must be less than Other Field"],
      ["lte", 5, null],
      ["lte", 6, "Must be less than or equal to Other Field"],
      ["gt", 6, null],
      ["gte", 4, "Must be greater than or equal to Other Field"],
      ["eq", 5, null],
      ["neq", 5, "Must be different from Other Field"],
    ] as const)("numeric %s with value %s", (op, value, expected) => {
      expect(rule.check(value, { rule: "compare", op, other: "s.other" }, valueCtx(num, { "s.other": 5 }))).toBe(expected);
    });

    it("compares dates with date wording", () => {
      const spec = { rule: "compare", op: "gte", other: "s.other" };
      const ctx = valueCtx(date, { "s.other": "2026-06-01" });
      expect(rule.check("2026-06-01", spec, ctx)).toBeNull();
      expect(rule.check("2026-05-31", spec, ctx)).toBe("Must be on or after Other Field");
    });

    it("skips when the other value is empty, hidden, or unparseable", () => {
      const spec = { rule: "compare", op: "lt", other: "s.other" };
      expect(rule.check(99, spec, valueCtx(num, {}))).toBeNull();
      expect(rule.check(99, spec, valueCtx(num, { "s.other": "n/a" }))).toBeNull();
    });
  });

  it("describes the comparison with the other field's label", () => {
    expect(
      rule.describe!({ rule: "compare", op: "lte", other: "s.other" }, { getLabel: () => "Total Price" }),
    ).toBe("less than or equal to Total Price");
  });
});
