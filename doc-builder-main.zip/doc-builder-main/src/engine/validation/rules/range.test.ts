import { describe, it, expect } from "vitest";
import { rangeRule } from "./range";
import type { RuleTarget, SchemaContext, ValueContext } from "../types";

const num: RuleTarget = { type: "number", label: "Amount", computed: false };
const date: RuleTarget = { type: "date", label: "Date", computed: false };

function schemaCtx(target: RuleTarget): SchemaContext {
  return { fieldKey: "s.f", target, isColumn: false, resolveRef: () => null };
}
function valueCtx(target: RuleTarget): ValueContext {
  return { fieldKey: "s.f", target, getValue: () => undefined, getLabel: (r) => r };
}

describe("range rule", () => {
  describe("checkParams", () => {
    it("accepts numeric bounds on number fields", () => {
      expect(rangeRule.checkParams({ rule: "range", min: 0, max: 10 }, schemaCtx(num))).toEqual([]);
    });
    it("accepts ISO bounds on date fields", () => {
      expect(rangeRule.checkParams({ rule: "range", min: "2020-01-01" }, schemaCtx(date))).toEqual([]);
    });
    it("requires at least one bound", () => {
      expect(rangeRule.checkParams({ rule: "range" }, schemaCtx(num))).toHaveLength(1);
    });
    it("rejects wrong bound types", () => {
      expect(rangeRule.checkParams({ rule: "range", min: "0" }, schemaCtx(num))[0]).toMatch(/finite number/);
      expect(rangeRule.checkParams({ rule: "range", max: 5 }, schemaCtx(date))[0]).toMatch(/YYYY-MM-DD/);
      expect(rangeRule.checkParams({ rule: "range", min: "2020-02-30" }, schemaCtx(date))).toHaveLength(1);
    });
    it("rejects min > max", () => {
      expect(rangeRule.checkParams({ rule: "range", min: 5, max: 1 }, schemaCtx(num))[0]).toMatch(/must not exceed/);
    });
  });

  describe("check (number)", () => {
    const spec = { rule: "range", min: 0, max: 100 };
    it.each([0, 50, 100, "75"])("accepts %s", (v) => {
      expect(rangeRule.check(v, spec, valueCtx(num))).toBeNull();
    });
    it("flags values below min / above max", () => {
      expect(rangeRule.check(-1, spec, valueCtx(num))).toBe("Must be at least 0");
      expect(rangeRule.check(100.01, spec, valueCtx(num))).toBe("Must be at most 100");
    });
    it("parses numeric strings with commas", () => {
      expect(rangeRule.check("-1,000", spec, valueCtx(num))).toBe("Must be at least 0");
    });
    it("flags non-numeric values", () => {
      expect(rangeRule.check("abc", spec, valueCtx(num))).toBe("Must be a number");
    });
  });

  describe("check (date)", () => {
    const spec = { rule: "range", min: "2026-01-01", max: "2026-12-31" };
    it("accepts in-range dates including bounds", () => {
      expect(rangeRule.check("2026-01-01", spec, valueCtx(date))).toBeNull();
      expect(rangeRule.check("2026-12-31", spec, valueCtx(date))).toBeNull();
    });
    it("flags out-of-range dates", () => {
      expect(rangeRule.check("2025-12-31", spec, valueCtx(date))).toBe("Must be on or after 2026-01-01");
      expect(rangeRule.check("2027-01-01", spec, valueCtx(date))).toBe("Must be on or before 2026-12-31");
    });
    it("flags invalid calendar dates", () => {
      expect(rangeRule.check("2026-02-30", spec, valueCtx(date))).toMatch(/valid date/);
    });
  });

  it("describes and exposes native attrs", () => {
    const spec = { rule: "range", min: 0 };
    expect(rangeRule.describe!(spec, { getLabel: (r) => r })).toBe("≥ 0");
    expect(rangeRule.inputAttrs!(spec)).toEqual({ min: 0 });
  });
});
