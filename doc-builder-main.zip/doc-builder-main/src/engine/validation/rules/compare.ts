/**
 * `compare` — order this value against another field (or, in a table, a
 * sibling column in the same row).
 *
 *   { "rule": "compare", "op": "lte", "other": "funding.funded_amount" }
 *   { "rule": "compare", "op": "gte", "other": "pop.start_date" }
 *   { "rule": "compare", "op": "lte", "other": "unit_max" }   // column rule: sibling column
 *
 * Both sides must be numeric (number or computed) or both dates. The rule is
 * skipped while the other value is empty or hidden.
 */

import type { RuleSpec, RuleTarget, ValidationRule } from "../types";
import { toIsoDate, toNumber } from "../coerce";

const OPS = {
  lt: { test: (c: number) => c < 0, text: "less than" },
  lte: { test: (c: number) => c <= 0, text: "less than or equal to" },
  gt: { test: (c: number) => c > 0, text: "greater than" },
  gte: { test: (c: number) => c >= 0, text: "greater than or equal to" },
  eq: { test: (c: number) => c === 0, text: "equal to" },
  neq: { test: (c: number) => c !== 0, text: "different from" },
} as const;

const DATE_OPS: Record<keyof typeof OPS, string> = {
  lt: "before",
  lte: "on or before",
  gt: "after",
  gte: "on or after",
  eq: "the same date as",
  neq: "a different date from",
};

type Op = keyof typeof OPS;

interface CompareSpec extends RuleSpec {
  op: Op;
  other: string;
}

const isNumeric = (t: RuleTarget) => t.type === "number" || t.computed;

export const compareRule: ValidationRule<CompareSpec> = {
  id: "compare",
  appliesTo: ["number", "date"],

  checkParams(spec, ctx) {
    const errors: string[] = [];
    if (typeof spec.op !== "string" || !(spec.op in OPS)) {
      errors.push(`compare \`op\` must be one of: ${Object.keys(OPS).join(", ")}`);
    }
    if (typeof spec.other !== "string" || spec.other.length === 0) {
      errors.push("compare requires `other` (a field reference)");
      return errors;
    }
    const other = ctx.resolveRef(spec.other);
    if (!other) {
      errors.push(`compare \`other\` references non-existent ${ctx.isColumn ? "field or column" : "field"} "${spec.other}"`);
    } else if (spec.other === ctx.fieldKey && !ctx.isColumn) {
      errors.push("compare `other` cannot reference the field itself");
    } else {
      const comparable =
        ctx.target.type === "date" ? other.type === "date" : isNumeric(other);
      if (!comparable) {
        errors.push(
          `compare \`other\` "${spec.other}" (type "${other.type}") is not comparable with a ${ctx.target.type} value`,
        );
      }
    }
    return errors;
  },

  check(value, spec, ctx) {
    const otherRaw = ctx.getValue(spec.other);
    if (otherRaw === undefined) return null;
    let cmp: number;
    let isDate = false;
    if (ctx.target.type === "date") {
      const a = toIsoDate(value);
      const b = toIsoDate(otherRaw);
      if (a === null || b === null) return null; // invalid dates are `range`'s concern
      cmp = a < b ? -1 : a > b ? 1 : 0;
      isDate = true;
    } else {
      const a = toNumber(value);
      const b = toNumber(otherRaw);
      if (a === null || b === null) return null;
      cmp = a - b;
    }
    if (OPS[spec.op].test(cmp)) return null;
    const label = ctx.getLabel(spec.other);
    return isDate
      ? `Must be ${DATE_OPS[spec.op]} ${label}`
      : `Must be ${OPS[spec.op].text} ${label}`;
  },

  describe(spec, ctx) {
    const op = OPS[spec.op];
    return op ? `${op.text} ${ctx.getLabel(spec.other)}` : "";
  },
};
