import { describe, it, expect } from "vitest";
import { readdirSync } from "node:fs";
import { resolve } from "node:path";
import { RULE_REGISTRY } from "./registry";

const RULES_DIR = resolve(__dirname, "rules");

describe("validation rule registry contract", () => {
  const files = readdirSync(RULES_DIR);
  const ruleFiles = files.filter((f) => f.endsWith(".ts") && !f.endsWith(".test.ts"));

  it.each(Object.entries(RULE_REGISTRY))("rule %s is well-formed", (key, rule) => {
    expect(rule.id).toBe(key);
    expect(rule.appliesTo.length).toBeGreaterThan(0);
    expect(typeof rule.checkParams).toBe("function");
    expect(typeof rule.check).toBe("function");
  });

  it("every rule module is registered", () => {
    expect(ruleFiles.length).toBe(Object.keys(RULE_REGISTRY).length);
  });

  it.each(ruleFiles)("%s has a colocated test file", (file) => {
    expect(files).toContain(file.replace(/\.ts$/, ".test.ts"));
  });
});
