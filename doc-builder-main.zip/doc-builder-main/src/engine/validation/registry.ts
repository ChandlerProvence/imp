/**
 * Registry of validation rules, keyed by `RuleSpec.rule`.
 *
 * To add a validation criterion:
 *   1. Create `rules/<name>.ts` exporting a `ValidationRule`.
 *   2. Add it to `RULES` below.
 *   3. Add `rules/<name>.test.ts` (enforced by registry.test.ts).
 * The loader, field UI, Review page, AI proposals, and AI prompt pick it up
 * automatically.
 */

import type { ValidationRule } from "./types";
import { rangeRule } from "./rules/range";
import { compareRule } from "./rules/compare";

const RULES: ValidationRule<never>[] = [rangeRule, compareRule];

export const RULE_REGISTRY: Record<string, ValidationRule> = Object.fromEntries(
  RULES.map((r) => [r.id, r as unknown as ValidationRule]),
);

export function getRule(id: string): ValidationRule | undefined {
  return Object.prototype.hasOwnProperty.call(RULE_REGISTRY, id) ? RULE_REGISTRY[id] : undefined;
}
