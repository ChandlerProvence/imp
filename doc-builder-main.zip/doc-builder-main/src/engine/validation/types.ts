/**
 * Validation rule framework — shared types.
 *
 * A validation criterion is one `ValidationRule` module registered in
 * ./registry.ts. Schemas opt in per field/column via `validate: RuleSpec[]`.
 * The loader, field UI, sidebar, Review page, AI proposal checks, and AI
 * prompt all consume rules through this interface, so adding a rule never
 * touches those layers.
 */

import type { FieldType, RuleSpec } from "../../schemas/types";
import type { AnswerValue } from "./coerce";

export type { RuleSpec, RuleSeverity } from "../../schemas/types";
export type { AnswerValue } from "./coerce";

/** Minimal description of a field or column, as rules see it. */
export interface RuleTarget {
  /** Field or column type. */
  type: FieldType;
  label: string;
  /** True for computed fields (aggregate or formula). */
  computed: boolean;
}

/** Load-time context passed to `checkParams`. */
export interface SchemaContext {
  /** Answer key of the field ("section.field"); for columns, the table's key. */
  fieldKey: string;
  /** The field or column declaring the rule. */
  target: RuleTarget;
  /** True when the rule is declared on a table column. */
  isColumn: boolean;
  /**
   * Resolve a reference to another field ("section.field") or, for column
   * rules, a sibling column (bare id). Null when it doesn't exist.
   */
  resolveRef(ref: string): RuleTarget | null;
}

/** Runtime context passed to `check`. */
export interface ValueContext {
  fieldKey: string;
  target: RuleTarget;
  /**
   * Current value of another field (computed values included) or, inside a
   * table row, a sibling column. Undefined when empty, unknown, or hidden.
   */
  getValue(ref: string): AnswerValue | undefined;
  /** Label of a referenced field/column (falls back to the ref itself). */
  getLabel(ref: string): string;
}

export interface ValidationRule<P extends RuleSpec = RuleSpec> {
  /** Matches `RuleSpec.rule`. */
  id: string;
  /** Field/column types that may declare this rule. */
  appliesTo: readonly FieldType[];
  /** Load-time parameter checks. Return loader error strings (no context prefix). */
  checkParams(spec: P, ctx: SchemaContext): string[];
  /**
   * Runtime check. Return null when valid, otherwise a default message
   * (overridden by `spec.message`). Never called with an empty value.
   */
  check(value: AnswerValue, spec: P, ctx: ValueContext): string | null;
  /** Short constraint text for AI prompts, e.g. "≥ 0". */
  describe?(spec: P, ctx: { getLabel(ref: string): string }): string;
  /** Native input attributes used as UX hints (the rule remains the source of truth). */
  inputAttrs?(spec: P): Record<string, string | number>;
}

/** One validation problem attached to a field. */
export interface ValidationIssue {
  rule: string;
  message: string;
  severity: "warning" | "info";
  /** 0-based table row index for column rules. */
  row?: number;
}

/** Issues keyed by answer key ("section.field"). Fields without issues are absent. */
export type ValidationIssues = Record<string, ValidationIssue[]>;
