import { describe, it, expect, vi } from "vitest";
import type { DocumentSchema } from "../../schemas/types";
import {
  countWarnings,
  describeRules,
  inputAttrsFor,
  validateAnswers,
  validateProposedValue,
} from "./index";

const schema = {
  id: "t",
  title: "T",
  version: 1,
  content_blocks: { SHOW_EXTRA: { when: { field: "pricing.show_extra", is_truthy: true } } },
  sections: [
    {
      id: "pricing",
      title: "Pricing",
      fields: [
        { id: "show_extra", label: "Show extra", type: "boolean", required: false },
        { id: "price", label: "Price", type: "number", required: true, validate: [{ rule: "range", min: 0 }] },
        {
          id: "funded",
          label: "Funded",
          type: "number",
          required: true,
          validate: [{ rule: "compare", op: "lte", other: "pricing.total", message: "Funded cannot exceed total" }],
        },
        { id: "total", label: "Total", type: "number", required: false, formula: "price * 2", format: "currency" },
        {
          id: "extra",
          label: "Extra",
          type: "number",
          required: false,
          visible_when: "SHOW_EXTRA",
          validate: [{ rule: "range", min: 0 }],
        },
        {
          id: "mirror",
          label: "Mirror",
          type: "number",
          required: false,
          same_as: "pricing.price",
          validate: [{ rule: "range", min: 0 }],
        },
        {
          id: "note_amt",
          label: "Note",
          type: "number",
          required: false,
          validate: [{ rule: "range", max: 10, severity: "info" }],
        },
      ],
    },
    {
      id: "pop",
      title: "PoP",
      fields: [
        { id: "start", label: "Start", type: "date", required: false },
        { id: "end", label: "End", type: "date", required: false, validate: [{ rule: "compare", op: "gte", other: "pop.start" }] },
        {
          id: "lines",
          label: "Lines",
          type: "table",
          required: false,
          rows: [{ id: "base", label: "Base Year" }],
          columns: [
            { id: "qty", label: "Qty", type: "number", validate: [{ rule: "range", min: 1 }] },
            { id: "max_qty", label: "Max Qty", type: "number" },
            { id: "cap", label: "Cap", type: "number", validate: [{ rule: "compare", op: "lte", other: "max_qty" }] },
          ],
        },
      ],
    },
  ],
} as unknown as DocumentSchema;

const table = (rows: Record<string, unknown>[]) => JSON.stringify({ rows });

describe("validateAnswers", () => {
  it("returns no issues for empty answers", () => {
    expect(validateAnswers(schema, {})).toEqual({});
  });

  it("flags field-level rule failures with default or custom messages", () => {
    const issues = validateAnswers(schema, { "pricing.price": -5, "pricing.funded": 1 });
    expect(issues["pricing.price"]).toEqual([{ rule: "range", message: "Must be at least 0", severity: "warning" }]);
    // total = -10, funded 1 > total
    expect(issues["pricing.funded"][0].message).toBe("Funded cannot exceed total");
  });

  it("compares against computed fields", () => {
    expect(validateAnswers(schema, { "pricing.price": 10, "pricing.funded": 20 })["pricing.funded"]).toBeUndefined();
    expect(validateAnswers(schema, { "pricing.price": 10, "pricing.funded": 21 })["pricing.funded"]).toHaveLength(1);
  });

  it("skips hidden fields, same_as followers, and empty values", () => {
    const answers = { "pricing.extra": -1, "pricing.mirror": -1, "pricing.price": "" };
    expect(validateAnswers(schema, answers)).toEqual({});
    expect(validateAnswers(schema, { ...answers, "pricing.show_extra": true })["pricing.extra"]).toHaveLength(1);
  });

  it("skips cross-field rules while the other field is empty", () => {
    expect(validateAnswers(schema, { "pop.end": "2026-01-01" })).toEqual({});
    expect(validateAnswers(schema, { "pop.start": "2026-02-01", "pop.end": "2026-01-01" })["pop.end"][0].message).toBe(
      "Must be on or after Start",
    );
  });

  it("validates table cells with row/column prefixes and sibling-column refs", () => {
    const issues = validateAnswers(schema, {
      "pop.lines": table([
        { _rowId: "base", qty: 0, max_qty: 5, cap: 6 },
        { qty: 2, max_qty: 5, cap: 5 },
        { qty: "", max_qty: "", cap: 9 },
      ]),
    });
    expect(issues["pop.lines"]).toEqual([
      { rule: "range", message: "Base Year, Qty: Must be at least 1", severity: "warning", row: 0 },
      { rule: "compare", message: "Base Year, Cap: Must be less than or equal to Max Qty", severity: "warning", row: 0 },
    ]);
  });

  it("passes severity through and excludes info from warning counts", () => {
    const issues = validateAnswers(schema, { "pricing.note_amt": 11, "pricing.price": -1 });
    expect(issues["pricing.note_amt"][0].severity).toBe("info");
    expect(countWarnings(issues)).toBe(1);
    expect(countWarnings(issues, "pop")).toBe(0);
  });

  it("ignores unknown rules at runtime with a warning", () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    const bad = {
      ...schema,
      sections: [{ id: "s", title: "S", fields: [{ id: "f", label: "F", type: "number", required: false, validate: [{ rule: "nope" }] }] }],
    } as unknown as DocumentSchema;
    expect(validateAnswers(bad, { "s.f": 1 })).toEqual({});
    expect(warn).toHaveBeenCalled();
    warn.mockRestore();
  });
});

describe("validateAnswers — values that aren't numbers", () => {
  const NAN = "Must be a number";

  it("flags non-numeric text in a number field even without rules", () => {
    expect(validateAnswers(schema, { "pricing.funded": "abc" })["pricing.funded"]).toEqual([
      { rule: "number", message: NAN, severity: "warning" },
    ]);
  });

  it("reports a ruled field once, not again from its range rule", () => {
    expect(validateAnswers(schema, { "pricing.price": "12abc" })["pricing.price"]).toEqual([
      { rule: "number", message: NAN, severity: "warning" },
    ]);
  });

  it("accepts formatted numbers", () => {
    expect(validateAnswers(schema, { "pricing.price": "$1,234.50", "pricing.funded": "1,000" })).toEqual({});
  });

  it("flags table cells, including columns without rules", () => {
    const issues = validateAnswers(schema, {
      "pop.lines": table([{ _rowId: "base", qty: "1234,5", max_qty: "lots", cap: "" }]),
    });
    expect(issues["pop.lines"]).toEqual([
      { rule: "number", message: `Base Year, Qty: ${NAN}`, severity: "warning", row: 0 },
      { rule: "number", message: `Base Year, Max Qty: ${NAN}`, severity: "warning", row: 0 },
    ]);
  });

  it("skips hidden and formula columns", () => {
    const gated = {
      id: "g",
      title: "G",
      version: 1,
      content_blocks: { ON: { when: { field: "s.on", is_truthy: true } } },
      sections: [
        {
          id: "s",
          title: "S",
          fields: [
            { id: "on", label: "On", type: "boolean", required: false },
            {
              id: "t",
              label: "T",
              type: "table",
              required: false,
              columns: [
                { id: "a", label: "A", type: "number", visible_when: "ON" },
                { id: "b", label: "B", type: "number", formula: "COALESCE(a, 0)" },
              ],
            },
          ],
        },
      ],
    } as unknown as DocumentSchema;
    const answers = { "s.t": table([{ a: "abc", b: "" }]) };
    expect(validateAnswers(gated, answers)).toEqual({});
    expect(validateAnswers(gated, { ...answers, "s.on": true })["s.t"]).toEqual([
      { rule: "number", message: `Row 1, A: ${NAN}`, severity: "warning", row: 0 },
    ]);
  });

  it("flags non-numeric AI proposals", () => {
    expect(validateProposedValue(schema, "pricing.funded", "about 5k", {})).toEqual([
      { rule: "number", message: NAN, severity: "warning" },
    ]);
  });
});

describe("validateProposedValue", () => {
  it("validates the proposed value in the context of current answers", () => {
    expect(validateProposedValue(schema, "pricing.price", -1, {})[0].message).toBe("Must be at least 0");
    expect(validateProposedValue(schema, "pricing.funded", 50, { "pricing.price": 10 })).toHaveLength(1);
    expect(validateProposedValue(schema, "pricing.funded", 5, { "pricing.price": 10 })).toEqual([]);
  });

  it("returns [] for unknown or hidden fields", () => {
    expect(validateProposedValue(schema, "pricing.nope", -1, {})).toEqual([]);
    expect(validateProposedValue(schema, "pricing.extra", -1, {})).toEqual([]);
  });
});

describe("presentation helpers", () => {
  it("describeRules resolves labels for fields and sibling columns", () => {
    const funded = schema.sections[0].fields[2];
    expect(describeRules(funded.validate, schema)).toBe("less than or equal to Total");
    const lines = schema.sections[1].fields[2];
    expect(describeRules(lines.columns![2].validate, schema, lines.columns)).toBe("less than or equal to Max Qty");
    expect(describeRules(undefined, schema)).toBe("");
  });

  it("inputAttrsFor merges native attributes", () => {
    expect(inputAttrsFor([{ rule: "range", min: 0 }, { rule: "compare", op: "lt", other: "x" }])).toEqual({ min: 0 });
  });
});
