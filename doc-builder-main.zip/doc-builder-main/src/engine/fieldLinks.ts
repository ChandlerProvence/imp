import type { DocumentSchema } from "../schemas/types";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface FieldLinkMap {
  /** source key → all follower keys that directly point to it */
  followers: Map<string, string[]>;
  /** follower key → its immediate source key */
  sourceOf: Map<string, string>;
}

// ---------------------------------------------------------------------------
// Build
// ---------------------------------------------------------------------------

/**
 * Build forward and reverse link maps from a schema's `same_as` declarations.
 * Called once per schema load; the result is memoized in SessionContext.
 */
export function buildFieldLinkMap(schema: DocumentSchema): FieldLinkMap {
  const followers = new Map<string, string[]>();
  const sourceOf = new Map<string, string>();

  for (const section of schema.sections) {
    for (const field of section.fields) {
      if (field.same_as) {
        const followerKey = `${section.id}.${field.id}`;
        sourceOf.set(followerKey, field.same_as);

        const existing = followers.get(field.same_as) ?? [];
        existing.push(followerKey);
        followers.set(field.same_as, existing);
      }
    }
  }

  return { followers, sourceOf };
}

// ---------------------------------------------------------------------------
// Propagation
// ---------------------------------------------------------------------------

/**
 * Given a key being set, return all transitive follower keys.
 * Handles fan-out (A → B, A → C) and chains (A → B → C).
 */
export function getTransitiveFollowers(
  key: string,
  linkMap: FieldLinkMap,
): string[] {
  const result: string[] = [];
  const queue = [key];
  const visited = new Set<string>();

  while (queue.length > 0) {
    const current = queue.shift()!;
    if (visited.has(current)) continue;
    visited.add(current);
    const directFollowers = linkMap.followers.get(current) ?? [];
    for (const f of directFollowers) {
      result.push(f);
      queue.push(f);
    }
  }

  return result;
}

// ---------------------------------------------------------------------------
// Heal (session hydration)
// ---------------------------------------------------------------------------

/**
 * One-pass "heal" that syncs follower answers to their source values.
 * Used after loading a session from IndexedDB to handle schema changes.
 * Returns the healed answers (or the same reference if no changes needed).
 */
export function healLinkedAnswers(
  answers: Record<string, string | number | boolean>,
  linkMap: FieldLinkMap,
): Record<string, string | number | boolean> {
  let changed = false;
  const healed = { ...answers };

  for (const [follower, source] of linkMap.sourceOf) {
    const sourceVal = healed[source];
    if (sourceVal !== undefined && healed[follower] !== sourceVal) {
      healed[follower] = sourceVal;
      changed = true;
    } else if (sourceVal === undefined && follower in healed) {
      delete healed[follower];
      changed = true;
    }
  }

  return changed ? healed : answers;
}

// ---------------------------------------------------------------------------
// Section helpers
// ---------------------------------------------------------------------------

/**
 * Returns true if every field in a section has `same_as` set
 * (i.e., the entire section is derived from other sections).
 */
export function isSectionFullyLinked(
  section: { fields: { same_as?: string }[] },
): boolean {
  return section.fields.length > 0 && section.fields.every((f) => f.same_as != null);
}
