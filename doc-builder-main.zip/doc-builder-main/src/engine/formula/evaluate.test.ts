import { describe, it, expect } from "vitest";
import type { DocumentSchema, FieldDef } from "../../schemas/types";
import { computeTableFormulas, evaluateFormulas } from "./evaluate";
import { buildCalcGraph, evaluationOrder, findCycle } from "./graph";
import { formatCalculated, formatCalculatedForUi } from "./format";

const num = (id: string, extra: Partial<FieldDef> = {}): FieldDef => ({ id, label: id, type: "number", required: false, ...extra });
const table = (id: string, columns: FieldDef["columns"]): FieldDef => ({ id, label: id, type: "table", required: false, columns });
const rows = (...r: object[]) => JSON.stringify({ rows: r });

function schema(sections: DocumentSchema["sections"], constants?: Record<string, number>): DocumentSchema {
  return { id: "t", title: "t", version: 1, sections, ...(constants ? { constants } : {}) };
}

describe("row scope (table column formulas)", () => {
  const cols = [
    { id: "qty", label: "Qty", type: "number" as const },
    { id: "price", label: "Price", type: "number" as const },
    { id: "line", label: "Line", type: "number" as const, formula: "qty * price" },
    { id: "taxed", label: "Taxed", type: "number" as const, formula: "line * (1 + TAX)" },
  ];

  it("reads sibling columns and constants, in dependency order", () => {
    const out = computeTableFormulas(cols, [{ qty: 2, price: "1,250" }], { TAX: 0.1 });
    expect(out[0].line).toBe(2500);
    expect(out[0].taxed).toBeCloseTo(2750, 10);
  });

  it("evaluates a column declared before the one it reads", () => {
    const reordered = [cols[3], cols[2], cols[0], cols[1]];
    expect(computeTableFormulas(reordered, [{ qty: 3, price: 2 }], { TAX: 0 })[0].taxed).toBe(6);
  });

  it("writes \"\" when an input is empty or not a number", () => {
    const out = computeTableFormulas(cols, [{ qty: "", price: 5 }, { qty: "12abc", price: 5 }, { qty: true, price: 5 }], { TAX: 0 });
    expect(out.map((r) => r.line)).toEqual(["", "", ""]);
  });

  it("returns the same rows when nothing is calculated, and never mutates input", () => {
    const plain = [{ id: "a", label: "a", type: "number" as const }];
    const input = [{ a: 1 }];
    expect(computeTableFormulas(plain, input)).toBe(input);
    const before = JSON.stringify([{ qty: 2, price: 3 }]);
    const data = JSON.parse(before);
    computeTableFormulas(cols, data, { TAX: 0 });
    expect(JSON.stringify(data)).toBe(before);
  });

  it("is null on division by zero and on non-finite results", () => {
    const c = [{ id: "a", label: "a", type: "number" as const }, { id: "r", label: "r", type: "number" as const, formula: "1 / a" }];
    expect(computeTableFormulas(c, [{ a: 0 }])[0].r).toBe("");
    const p = [{ id: "a", label: "a", type: "number" as const }, { id: "r", label: "r", type: "number" as const, formula: "a ^ 0.5" }];
    expect(computeTableFormulas(p, [{ a: -4 }])[0].r).toBe("");
  });
});

describe("field scope", () => {
  const s = schema(
    [
      { id: "header", title: "H", fields: [num("base")] },
      {
        id: "price",
        title: "P",
        fields: [
          table("items", [
            { id: "noun", label: "Noun", type: "string" },
            { id: "cost", label: "Cost", type: "number" },
            { id: "unit", label: "Unit", type: "number", formula: "cost * MULT" },
          ]),
          num("total", { formula: "SUM(items.unit)", format: "currency" }),
          num("from"),
          num("delta", { formula: "total - from", format: "currency" }),
          num("vs_header", { formula: "total - header.base", format: "number" }),
          num("count_rows", { formula: "COUNT(items)", format: "integer" }),
          num("count_nouns", { formula: "COUNT(items.noun)", format: "integer" }),
          num("avg", { formula: "AVG(items.cost)" }),
          num("min", { formula: "MIN(items.cost)" }),
          num("max", { formula: "MAX(price.items.cost)" }),
        ],
      },
    ],
    { MULT: 2 },
  );
  const answers = {
    "header.base": 10,
    "price.from": 100,
    "price.items": rows({ noun: "a", cost: 10 }, { noun: "", cost: "" }, { noun: "c", cost: "1,000" }),
  };

  it("reads sibling fields, section.field paths, constants, and aggregates", () => {
    const { values } = evaluateFormulas(s, answers);
    expect(values["price.total"]).toBe(2020);
    expect(values["price.delta"]).toBe(1920);
    expect(values["price.vs_header"]).toBe(2010);
  });

  it("COUNT(table) counts rows; COUNT(table.column) counts filled cells", () => {
    const { values } = evaluateFormulas(s, answers);
    expect(values["price.count_rows"]).toBe(3);
    expect(values["price.count_nouns"]).toBe(2);
  });

  it("AVG / MIN / MAX skip empty cells; section.table.column works too", () => {
    const { values } = evaluateFormulas(s, answers);
    expect(values["price.avg"]).toBe(505);
    expect(values["price.min"]).toBe(10);
    expect(values["price.max"]).toBe(1000);
  });

  it("fills formula columns into the returned answers", () => {
    const { answers: filled } = evaluateFormulas(s, answers);
    expect(JSON.parse(filled["price.items"] as string).rows.map((r: { unit: unknown }) => r.unit)).toEqual([20, "", 2000]);
  });

  it("every aggregate is null for a table with no rows, and null propagates", () => {
    const { values } = evaluateFormulas(s, { "price.from": 5 });
    expect(values["price.total"]).toBeNull();
    expect(values["price.count_rows"]).toBeNull();
    expect(values["price.delta"]).toBeNull();
  });

  it("rounds currency results to cents so a sign check can't flip on float noise", () => {
    const t = schema([
      {
        id: "p",
        title: "P",
        fields: [
          table("items", [{ id: "c", label: "c", type: "number" }]),
          num("from"),
          num("delta", { formula: "SUM(items.c) - from", format: "currency" }),
          num("ratio", { formula: "from / 3", format: "number" }),
        ],
      },
    ]);
    const { values } = evaluateFormulas(t, { "p.items": rows({ c: 0.7 }, { c: 0.1 }), "p.from": 0.8 });
    expect(values["p.delta"]).toBe(0);
    expect(Object.is(values["p.delta"], -0)).toBe(false);
    expect(values["p.ratio"]).toBeCloseTo(0.8 / 3, 12);
  });

  it("formulas read the unrounded value of another currency formula", () => {
    const t = schema([
      { id: "p", title: "P", fields: [num("a", { formula: "1 / 3", format: "currency" }), num("b", { formula: "a * 3", format: "number" })] },
    ]);
    const { values } = evaluateFormulas(t, {});
    expect(values["p.a"]).toBe(0.33);
    expect(values["p.b"]).toBeCloseTo(1, 12);
  });

  it("resolves a diamond of dependencies (each input read by two formulas)", () => {
    const t = schema([
      {
        id: "s",
        title: "S",
        fields: [
          num("f", { formula: "2" }),
          num("d", { formula: "f + 1" }),
          num("e", { formula: "f * 10" }),
          num("b", { formula: "d + e" }),
          num("a", { formula: "b" }),
        ],
      },
    ]);
    expect(evaluateFormulas(t, {}).values["s.a"]).toBe(23);
  });

  it("evaluates out-of-order declarations and cross-section chains", () => {
    const t = schema([
      { id: "x", title: "X", fields: [num("late", { formula: "y.early * 2" })] },
      { id: "y", title: "Y", fields: [num("early", { formula: "y_in + 1" }), num("y_in")] },
    ]);
    expect(evaluateFormulas(t, { "y.y_in": 4 }).values["x.late"]).toBe(10);
  });

  it("an unparseable or unresolvable formula is null, not a crash", () => {
    const t = schema([{ id: "s", title: "S", fields: [num("bad", { formula: "1 +" }), num("ghost", { formula: "nope * 2" })] }]);
    expect(evaluateFormulas(t, {}).values).toEqual({ "s.bad": null, "s.ghost": null });
  });
});

describe("graph", () => {
  it("finds a cycle across sections and columns, as a closed path", () => {
    const t = schema([
      { id: "a", title: "A", fields: [num("x", { formula: "b.y + 1" })] },
      { id: "b", title: "B", fields: [num("y", { formula: "a.x * 2" })] },
    ]);
    expect(findCycle(buildCalcGraph(t))).toEqual(["a.x", "b.y", "a.x"]);
  });

  it("finds a cycle between columns", () => {
    const t = schema([
      {
        id: "s",
        title: "S",
        fields: [
          table("t", [
            { id: "p", label: "p", type: "number", formula: "q + 1" },
            { id: "q", label: "q", type: "number", formula: "p + 1" },
          ]),
        ],
      },
    ]);
    expect(findCycle(buildCalcGraph(t))).toEqual(["s.t.p", "s.t.q", "s.t.p"]);
  });

  it("links a field total to the column it sums", () => {
    const t = schema([
      {
        id: "s",
        title: "S",
        fields: [
          table("t", [{ id: "a", label: "a", type: "number" }, { id: "b", label: "b", type: "number", formula: "a * 2" }]),
          num("sum", { formula: "SUM(t.b)" }),
        ],
      },
    ]);
    const g = buildCalcGraph(t);
    expect(g.deps.get("s.sum")).toEqual(["s.t.b"]);
    expect(findCycle(g)).toBeNull();
    expect(evaluationOrder(g)).toEqual(["s.t.b", "s.sum"]);
  });

  it("ignores self-references (the validator reports them)", () => {
    const t = schema([{ id: "s", title: "S", fields: [num("a", { formula: "a + 1" })] }]);
    expect(findCycle(buildCalcGraph(t))).toBeNull();
  });
});

describe("formatting a value that rounds to zero", () => {
  it("never prints a minus sign on zero", () => {
    expect(formatCalculated(-1e-9, { format: "number", decimals: 1 })).toBe("0.0");
    expect(formatCalculated(-0.004, { format: "currency" })).toBe("0.00");
    expect(formatCalculated(-0.4, { format: "integer" })).toBe("0");
    expect(formatCalculatedForUi(-0.004, { format: "number" })).toBe("0.00");
    expect(formatCalculated(-1.25, { format: "number", decimals: 1 })).toBe("-1.3");
  });
});
