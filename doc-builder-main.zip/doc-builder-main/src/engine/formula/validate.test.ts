import { describe, it, expect } from "vitest";
import { validateCalculations } from "./validate";

type F = Record<string, unknown>;
const num = (id: string, extra: F = {}): F => ({ id, label: id, type: "number", required: false, ...extra });
const str = (id: string, extra: F = {}): F => ({ id, label: id, type: "string", required: false, ...extra });
const tbl = (id: string, columns: F[], extra: F = {}): F => ({ id, label: id, type: "table", required: false, columns, ...extra });
const col = (id: string, type = "number", extra: F = {}): F => ({ id, label: id, type, ...extra });

function errorsFor(fields: F[], more: { sections?: { id: string; fields: F[] }[]; constants?: unknown } = {}): string[] {
  return validateCalculations({ sections: [{ id: "pricing", fields }, ...(more.sections ?? [])], constants: more.constants });
}

describe("validateCalculations", () => {
  it("accepts every scope", () => {
    expect(
      errorsFor(
        [
          tbl("parts", [col("noun", "string"), col("qty"), col("rate"), col("line", "number", { formula: "qty * rate * MARKUP" })]),
          num("total", { formula: "SUM(parts.line)", format: "currency" }),
          num("count", { formula: "COUNT(parts)", format: "integer" }),
          num("nouns", { formula: "COUNT(parts.noun)", format: "integer" }),
          num("from", { format: "currency" }),
          num("delta", { formula: "ABS(total - COALESCE(from, 0)) + header.fee", format: "number", decimals: 3, display: "abs" }),
        ],
        { sections: [{ id: "header", fields: [num("fee")] }], constants: { MARKUP: 1.1 } },
      ),
    ).toEqual([]);
  });

  describe("number settings", () => {
    it.each([
      [num("a", { format: "money" }), `Section "pricing", field "a": format must be "currency", "number", or "integer" (found "money")`],
      [str("a", { format: "currency" }), `Section "pricing", field "a": format only applies to number fields (this one is type "string")`],
      [num("a", { decimals: 7 }), `Section "pricing", field "a": decimals must be a whole number from 0 to 6 (found 7)`],
      [num("a", { decimals: 1.5 }), `Section "pricing", field "a": decimals must be a whole number from 0 to 6 (found 1.5)`],
      [num("a", { format: "integer", decimals: 2 }), `Section "pricing", field "a": decimals has no effect with format "integer"; remove one of them`],
      [num("a", { display: "abs" }), `Section "pricing", field "a": display "abs" is only allowed on a field with a formula`],
      [num("a", { formula: "1", display: "absolute" }), `Section "pricing", field "a": display must be "abs" (found "absolute")`],
    ])("%j", (field, message) => {
      expect(errorsFor([field])).toEqual([message]);
    });

    it("checks columns too", () => {
      expect(errorsFor([tbl("t", [col("c", "number", { format: "cash" }), col("d", "number", { display: "abs" })])])).toEqual([
        `Section "pricing", field "t", column "c": format must be "currency", "number", or "integer" (found "cash")`,
        `Section "pricing", field "t", column "d": display is not supported on table columns`,
      ]);
    });
  });

  describe("field formulas", () => {
    it("requires a non-empty string and a number type", () => {
      expect(errorsFor([num("a", { formula: "" })])).toEqual([`Section "pricing", field "a": formula must be a non-empty string`]);
      expect(errorsFor([str("a", { formula: "1" })])).toEqual([
        `Section "pricing", field "a": has a formula, so its type must be "number" (found "string")`,
      ]);
    });

    it("rejects formula together with same_as", () => {
      expect(errorsFor([num("b"), num("a", { formula: "b", same_as: "pricing.b" })])).toContain(
        `Section "pricing", field "a": a field can't have both a formula and same_as`,
      );
    });

    it("reports syntax errors with the token and the whole formula", () => {
      expect(errorsFor([num("qty"), num("a", { formula: "qty * " })])).toEqual([
        `Section "pricing", field "a": formula syntax error at "qty * ": the formula ends where a number or name was expected. The whole formula is "qty * "`,
      ]);
    });

    it("names an unknown sibling and lists the number fields and constants available", () => {
      expect(errorsFor([num("qty"), num("rate"), str("note"), num("a", { formula: "qtyy * rate" })], { constants: { K: 1 } })).toEqual([
        `Section "pricing", field "a": formula uses "qtyy", which is not a number field in section "pricing" or a constant. For a field in another section write "section.field". Number fields in this section: qty, rate. Constants: K.`,
      ]);
    });

    it("rejects non-number fields and bare tables", () => {
      expect(errorsFor([str("note"), num("a", { formula: "note + 1" })])).toEqual([
        `Section "pricing", field "a": formula uses "note", which is a string field; only number fields can be used`,
      ]);
      expect(errorsFor([tbl("parts", [col("c")]), num("a", { formula: "parts" })])).toEqual([
        `Section "pricing", field "a": formula uses the table "parts" directly; use SUM(parts.<column>), AVG, MIN, MAX, or COUNT(parts)`,
      ]);
    });

    it("explains section.field misses", () => {
      expect(errorsFor([num("a", { formula: "nope.x" })])).toEqual([`Section "pricing", field "a": formula uses "nope.x", but there is no section "nope"`]);
      expect(errorsFor([num("a", { formula: "pricing.x" })])).toEqual([`Section "pricing", field "a": formula uses "pricing.x", but section "pricing" has no field "x"`]);
      expect(errorsFor([num("a", { formula: "a.b.c" })])).toEqual([
        `Section "pricing", field "a": formula uses "a.b.c"; a name has at most one ".", as in "section.field" (table columns are only reachable through SUM, AVG, MIN, MAX, or COUNT)`,
      ]);
    });

    it("rejects a self-reference by name", () => {
      expect(errorsFor([num("a", { formula: "a + 1" })])).toEqual([`Section "pricing", field "a": formula uses "a", which is this field itself`]);
    });

    it("notes ids containing \"-\"", () => {
      expect(errorsFor([num("unit-cost"), num("a", { formula: "unit_cost" })])[0]).toMatch(/Ids containing "-" can't be used in formulas\.$/);
    });
  });

  describe("aggregates", () => {
    const parts = tbl("parts", [col("noun", "string"), col("cost")]);
    it.each([
      ["SUM(parts.noun)", `SUM(parts.noun): column "noun" is type "string"; SUM needs a number column (COUNT works on any column)`],
      ["SUM(parts.price)", `SUM(parts.price): table "pricing.parts" has no column "price". Columns: noun, cost`],
      ["SUM(partz.cost)", `SUM(partz.cost): "partz" is not a table in section "pricing", and there is no table "partz.cost"`],
      ["SUM(parts)", `SUM(parts) needs a column: write SUM(parts.<column>)`],
      ["COUNT(nope)", `COUNT(nope): there is no table "nope" in section "pricing"`],
      ["SUM(other.qty)", `SUM(other.qty): "other" is not a table in section "pricing", and there is no table "other.qty"`],
      ["SUM(header.fee.x)", `SUM(header.fee.x): "header.fee" is a number field, not a table`],
    ])("%s", (formula, message) => {
      expect(errorsFor([parts, num("a", { formula })], { sections: [{ id: "header", fields: [num("fee")] }] })).toEqual([
        `Section "pricing", field "a": ${message}`,
      ]);
    });

    it("accepts COUNT on a string column and section.table.column from elsewhere", () => {
      expect(errorsFor([parts, num("a", { formula: "COUNT(parts.noun) + SUM(pricing.parts.cost)" })])).toEqual([]);
    });
  });

  describe("column formulas", () => {
    it("allows only sibling number columns and constants", () => {
      expect(
        errorsFor([num("rate"), tbl("t", [col("q"), col("n", "string"), col("x", "number", { formula: "q * pricing.rate" })])]),
      ).toEqual([
        `Section "pricing", field "t", column "x": formula uses "pricing.rate", but a column formula can only use other number columns of this table (q) and constants.`,
      ]);
    });

    it("rejects string columns and aggregates", () => {
      expect(errorsFor([tbl("t", [col("n", "string"), col("x", "number", { formula: "n + SUM(t.n)" })])])).toEqual([
        `Section "pricing", field "t", column "x": formula uses column "n", which is type "string"; only number columns can be used`,
        `Section "pricing", field "t", column "x": column formulas can't use SUM(); put the total in a number field next to the table, with "formula": "SUM(t.<column>)"`,
      ]);
    });

    it("requires type number", () => {
      expect(errorsFor([tbl("t", [col("x", "string", { formula: "1" })])])).toEqual([
        `Section "pricing", field "t", column "x": has a formula, so its type must be "number" (found "string")`,
      ]);
    });
  });

  describe("constants", () => {
    it.each([
      [[1, 2], `constants must be an object of name → number, for example { "TAX_RATE": 0.06 }`],
      [{ RATE: "3" }, `constants.RATE must be a number (found "3")`],
      [{ "1X": 1 }, `constants: "1X" is not a valid name (letters, digits, and "_", not starting with a digit)`],
      [{ qty: 1 }, `constants: "qty" has the same name as field "pricing.qty"; constant names must not match any section or field id`],
      [{ pricing: 1 }, `constants: "pricing" has the same name as section "pricing"; constant names must not match any section or field id`],
    ])("%j", (constants, message) => {
      expect(errorsFor([num("qty")], { constants })).toEqual([message]);
    });
  });

  describe("cycles", () => {
    it("reports the whole path once, across sections and columns", () => {
      expect(
        validateCalculations({
          sections: [
            { id: "a", fields: [num("x", { formula: "b.y + 1" })] },
            { id: "b", fields: [tbl("t", [col("c"), col("d", "number", { formula: "c" })]), num("y", { formula: "a.x + SUM(t.d)" })] },
          ],
        }),
      ).toEqual([`Circular formula: a.x → b.y → a.x. Each formula must be computable from the others without coming back to itself`]);
    });

    it("labels column nodes readably", () => {
      expect(
        errorsFor([tbl("t", [col("p", "number", { formula: "q" }), col("q", "number", { formula: "p" })])]),
      ).toEqual([
        `Circular formula: pricing.t column p → pricing.t column q → pricing.t column p. Each formula must be computable from the others without coming back to itself`,
      ]);
    });
  });
});
