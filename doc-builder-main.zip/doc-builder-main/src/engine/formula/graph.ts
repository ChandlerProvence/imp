/**
 * Dependency graph over every formula in a schema: formula fields
 * (`section.field`) and formula columns (`section.table.column`). One cycle
 * detector and one evaluation order serve the loader and the evaluator.
 */
import type { FieldDef, TableColumnDef } from "../../schemas/types";
import { parseFormula, referencesOf, type FormulaNode } from "./parser";
import { buildScopeIndex, resolveAggregate, resolveName, type Place, type ScopeIndex } from "./scope";

export interface FieldNode {
  kind: "field";
  id: string;
  place: Extract<Place, { kind: "field" }>;
  def: FieldDef;
  ast: FormulaNode | null;
}

export interface ColumnNode {
  kind: "column";
  id: string;
  place: Extract<Place, { kind: "column" }>;
  def: TableColumnDef;
  table: FieldDef;
  ast: FormulaNode | null;
}

export type CalcNode = FieldNode | ColumnNode;

export interface CalcGraph {
  index: ScopeIndex;
  nodes: Map<string, CalcNode>;
  /** node id → ids of formula nodes it reads. */
  deps: Map<string, string[]>;
}

export const columnNodeId = (sectionId: string, tableId: string, columnId: string) =>
  `${sectionId}.${tableId}.${columnId}`;

/** The parts of a schema formulas depend on. */
export interface SchemaLike {
  sections: { id: string; fields: FieldDef[] }[];
  constants?: unknown;
}

/**
 * Build the graph. Unparseable formulas and unresolvable names become nodes
 * without those edges; the validator reports them separately.
 */
export function buildCalcGraph(schema: SchemaLike): CalcGraph {
  const index = buildScopeIndex(schema);
  const nodes = new Map<string, CalcNode>();

  const parse = (text: unknown): FormulaNode | null => {
    if (typeof text !== "string") return null;
    try {
      return parseFormula(text);
    } catch {
      return null;
    }
  };

  for (const sec of schema.sections) {
    for (const f of sec.fields) {
      if (f.formula !== undefined) {
        const id = `${sec.id}.${f.id}`;
        nodes.set(id, { kind: "field", id, place: { kind: "field", section: sec.id, field: f.id }, def: f, ast: parse(f.formula) });
      }
      if (f.type !== "table" || !Array.isArray(f.columns)) continue;
      for (const c of f.columns) {
        if (c.formula === undefined) continue;
        const id = columnNodeId(sec.id, f.id, c.id);
        nodes.set(id, {
          kind: "column",
          id,
          place: { kind: "column", section: sec.id, field: f.id, column: c.id },
          def: c,
          table: f,
          ast: parse(c.formula),
        });
      }
    }
  }

  const deps = new Map<string, string[]>();
  for (const node of nodes.values()) {
    const out = new Set<string>();
    if (node.ast) {
      const refs = referencesOf(node.ast);
      for (const name of refs.names) {
        const r = resolveName(index, node.place, name);
        if (!r.ok) continue;
        const t = r.target;
        if (t.kind === "field" && nodes.has(t.key)) out.add(t.key);
        if (t.kind === "column") {
          const id = columnNodeId(node.place.section, node.place.field, t.id);
          if (nodes.has(id)) out.add(id);
        }
      }
      for (const agg of refs.aggregates) {
        const r = resolveAggregate(index, node.place, agg);
        if (!r.ok || !r.target.column) continue;
        const [secId, tableId] = r.target.key.split(".");
        const id = columnNodeId(secId, tableId, r.target.column.id);
        if (nodes.has(id)) out.add(id);
      }
    }
    out.delete(node.id); // a self-reference is a validation error, not a cycle
    deps.set(node.id, [...out]);
  }

  return { index, nodes, deps };
}

/**
 * The first dependency cycle found, as a closed path of node ids
 * (`[a, b, a]`), or null when there is none. Self-references are not edges
 * (the validator reports them by name).
 */
export function findCycle(graph: CalcGraph): string[] | null {
  const state = new Map<string, "active" | "done">();
  const stack: string[] = [];
  const visit = (id: string): string[] | null => {
    state.set(id, "active");
    stack.push(id);
    for (const dep of graph.deps.get(id) ?? []) {
      const s = state.get(dep);
      if (s === "active") return [...stack.slice(stack.indexOf(dep)), dep];
      if (s === undefined) {
        const found = visit(dep);
        if (found) return found;
      }
    }
    stack.pop();
    state.set(id, "done");
    return null;
  };
  for (const id of graph.nodes.keys()) {
    if (state.has(id)) continue;
    const found = visit(id);
    if (found) return found;
  }
  return null;
}

/**
 * Node ids with every dependency before its dependents. Nodes on a cycle are
 * still included (after what they can reach), so evaluation never loses a
 * value; the loader rejects cyclic schemas anyway.
 */
export function evaluationOrder(graph: CalcGraph): string[] {
  const order: string[] = [];
  const seen = new Set<string>();
  const visit = (id: string) => {
    if (seen.has(id)) return;
    seen.add(id);
    for (const dep of graph.deps.get(id) ?? []) visit(dep);
    order.push(id);
  };
  for (const id of graph.nodes.keys()) visit(id);
  return order;
}
