/**
 * What a name in a formula refers to, by where the formula sits.
 *
 * | Formula on   | Bare `x`                         | `a.b`                     | SUM/AVG/MIN/MAX/COUNT |
 * |--------------|----------------------------------|---------------------------|-----------------------|
 * | table column | sibling column, then constant    | not allowed               | not allowed           |
 * | field        | sibling field, then constant     | field `b` in section `a`  | allowed               |
 *
 * Every referenced field or column must be a number (formula fields are).
 * The validator, the evaluator, and the template editor's locks all resolve
 * names here, so they cannot disagree about what a formula depends on.
 */
import type { FieldDef, TableColumnDef } from "../../schemas/types";
import type { AggregateName } from "./parser";

export interface ScopeIndex {
  /** section id → field id → field */
  sections: Map<string, Map<string, FieldDef>>;
  /** Valid constants only (finite numbers). */
  constants: Map<string, number>;
}

/** Where a formula sits. */
export type Place =
  | { kind: "field"; section: string; field: string }
  | { kind: "column"; section: string; field: string; column: string };

export type NameTarget =
  | { kind: "field"; key: string; def: FieldDef }
  | { kind: "column"; id: string; def: TableColumnDef }
  | { kind: "constant"; name: string; value: number };

export interface AggregateTarget {
  /** `section.table` answer key. */
  key: string;
  table: FieldDef;
  /** Undefined for `COUNT(table)`. */
  column?: TableColumnDef;
}

export type Resolution<T> = { ok: true; target: T } | { ok: false; problem: string };

const ok = <T>(target: T): Resolution<T> => ({ ok: true, target });
const fail = <T>(problem: string): Resolution<T> => ({ ok: false, problem });

/** A name formulas can use: letters, digits, `_`, not starting with a digit. */
export const FORMULA_NAME_RE = /^[A-Za-z_][A-Za-z0-9_]*$/;

interface IndexInput {
  sections: { id: string; fields: FieldDef[] }[];
  constants?: unknown;
}

export function buildScopeIndex(schema: IndexInput): ScopeIndex {
  const sections = new Map<string, Map<string, FieldDef>>();
  for (const sec of schema.sections) {
    const fields = new Map<string, FieldDef>();
    for (const f of sec.fields) fields.set(f.id, f);
    sections.set(sec.id, fields);
  }
  const constants = new Map<string, number>();
  const raw = schema.constants;
  if (raw && typeof raw === "object" && !Array.isArray(raw)) {
    for (const [name, value] of Object.entries(raw as Record<string, unknown>)) {
      if (typeof value === "number" && Number.isFinite(value)) constants.set(name, value);
    }
  }
  return { sections, constants };
}

const LIST_LIMIT = 15;
function list(items: string[]): string {
  const shown = items.slice(0, LIST_LIMIT).join(", ");
  return items.length > LIST_LIMIT ? `${shown}, and ${items.length - LIST_LIMIT} more` : shown;
}

function constantsNote(index: ScopeIndex): string {
  return index.constants.size ? ` Constants: ${list([...index.constants.keys()])}.` : "";
}

/** Usable names for a hint, and whether any were left out for containing "-". */
function usable(ids: string[]): { names: string[]; hyphenated: boolean } {
  return { names: ids.filter((id) => FORMULA_NAME_RE.test(id)), hyphenated: ids.some((id) => id.includes("-")) };
}

const HYPHEN_NOTE = ` Ids containing "-" can't be used in formulas.`;

function checkField(def: FieldDef, key: string, name: string): Resolution<NameTarget> {
  if (def.type === "number") return ok({ kind: "field", key, def });
  if (def.type === "table") {
    return fail(
      `formula uses the table "${name}" directly; use SUM(${name}.<column>), AVG, MIN, MAX, or COUNT(${name})`,
    );
  }
  return fail(`formula uses "${name}", which is a ${def.type} field; only number fields can be used`);
}

/** Resolve a plain name (not an aggregate argument). */
export function resolveName(index: ScopeIndex, place: Place, name: string): Resolution<NameTarget> {
  const section = index.sections.get(place.section);

  if (place.kind === "column") {
    const cols = section?.get(place.field)?.columns ?? [];
    if (!name.includes(".")) {
      const col = cols.find((c) => c.id === name);
      if (col) {
        return col.type === "number"
          ? ok({ kind: "column", id: col.id, def: col })
          : fail(`formula uses column "${name}", which is type "${col.type}"; only number columns can be used`);
      }
      const value = index.constants.get(name);
      if (value !== undefined) return ok({ kind: "constant", name, value });
    }
    const { names, hyphenated } = usable(cols.filter((c) => c.type === "number" && c.id !== place.column).map((c) => c.id));
    return fail(
      `formula uses "${name}", but a column formula can only use other number columns of this table` +
        ` (${names.length ? list(names) : "there are none"}) and constants.${constantsNote(index)}` +
        (hyphenated ? HYPHEN_NOTE : ""),
    );
  }

  if (!name.includes(".")) {
    const sibling = section?.get(name);
    if (sibling) return checkField(sibling, `${place.section}.${name}`, name);
    const value = index.constants.get(name);
    if (value !== undefined) return ok({ kind: "constant", name, value });
    const ids = [...(section?.values() ?? [])].filter((f) => f.type === "number" && f.id !== place.field).map((f) => f.id);
    const { names, hyphenated } = usable(ids);
    return fail(
      `formula uses "${name}", which is not a number field in section "${place.section}" or a constant.` +
        ` For a field in another section write "section.field".` +
        (names.length ? ` Number fields in this section: ${list(names)}.` : " This section has no other number fields.") +
        constantsNote(index) +
        (hyphenated ? HYPHEN_NOTE : ""),
    );
  }

  const parts = name.split(".");
  if (parts.length > 2) {
    return fail(
      `formula uses "${name}"; a name has at most one ".", as in "section.field" (table columns are only reachable through SUM, AVG, MIN, MAX, or COUNT)`,
    );
  }
  const [secId, fieldId] = parts;
  const other = index.sections.get(secId);
  if (!other) return fail(`formula uses "${name}", but there is no section "${secId}"`);
  const def = other.get(fieldId);
  if (!def) return fail(`formula uses "${name}", but section "${secId}" has no field "${fieldId}"`);
  return checkField(def, name, name);
}

/** Resolve the argument of SUM / AVG / MIN / MAX / COUNT. */
export function resolveAggregate(
  index: ScopeIndex,
  place: Place,
  agg: { name: AggregateName; ref: string },
): Resolution<AggregateTarget> {
  const { name, ref } = agg;
  const call = `${name}(${ref})`;
  if (place.kind === "column") {
    return fail(
      `column formulas can't use ${name}(); put the total in a number field next to the table, with "formula": "${name}(${place.field}.<column>)"`,
    );
  }
  const section = index.sections.get(place.section);
  const parts = ref.split(".");
  let table: FieldDef | undefined;
  let key = "";
  let columnId: string | undefined;
  let missing: string;

  if (parts.length === 1) {
    table = section?.get(ref);
    key = `${place.section}.${ref}`;
    missing = `${call}: there is no table "${ref}" in section "${place.section}"`;
  } else if (parts.length === 2) {
    const sibling = section?.get(parts[0]);
    if (sibling?.type === "table") {
      table = sibling;
      key = `${place.section}.${parts[0]}`;
      columnId = parts[1];
    } else {
      table = index.sections.get(parts[0])?.get(parts[1]);
      key = ref;
    }
    missing = `${call}: "${parts[0]}" is not a table in section "${place.section}", and there is no table "${ref}"`;
  } else if (parts.length === 3) {
    table = index.sections.get(parts[0])?.get(parts[1]);
    key = `${parts[0]}.${parts[1]}`;
    columnId = parts[2];
    missing = `${call}: there is no table "${key}"`;
  } else {
    return fail(`${call}: write table.column, or section.table.column for a table in another section`);
  }

  if (!table) return fail(missing);
  if (table.type !== "table") return fail(`${call}: "${key}" is a ${table.type} field, not a table`);
  if (columnId === undefined) {
    return name === "COUNT"
      ? ok({ key, table })
      : fail(`${call} needs a column: write ${name}(${ref}.<column>)`);
  }
  const column = (table.columns ?? []).find((c) => c.id === columnId);
  if (!column) {
    return fail(
      `${call}: table "${key}" has no column "${columnId}". Columns: ${list((table.columns ?? []).map((c) => c.id))}`,
    );
  }
  if (name !== "COUNT" && column.type !== "number") {
    return fail(
      `${call}: column "${columnId}" is type "${column.type}"; ${name} needs a number column (COUNT works on any column)`,
    );
  }
  return ok({ key, table, column });
}
