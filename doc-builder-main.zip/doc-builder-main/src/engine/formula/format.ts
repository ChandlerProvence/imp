/**
 * Number formatting for calculated values and user-entered numbers.
 *
 * Document output never carries a `$` (it lives in the template). A
 * calculated value's `format`:
 * - "currency" and "number": `decimals` (default 2) fraction digits, en-US grouping
 * - "integer": rounded, no grouping
 * - omitted: same as "number"
 * `display: "abs"` drops the sign in the document only; the UI, conditions,
 * and validation rules see the signed value.
 */
import type { NumberFormat } from "../../schemas/types";

export interface CalcFormat {
  format?: NumberFormat;
  decimals?: number;
  display?: "abs";
}

/** Fixed digits with grouping; a value that rounds to zero prints without a minus sign. */
function fixed(n: number, decimals: number): string {
  // nosemgrep: nodejs_scan.javascript-dos-rule-regex_dos — anchored single character class, input is toLocaleString output
  const text = n.toLocaleString("en-US", { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  // "-0.00" → "0.00": a value that rounds to zero has no sign
  return /^-[0.]+$/.test(text) ? text.slice(1) : text;
}

/**
 * The value a calculated field exposes outside formulas: currency is rounded
 * to its displayed precision so a floating-point leftover such as
 * 0.7 + 0.1 - 0.8 = -1e-16 can't flip a `gte: 0` condition. Formulas that
 * read the field use the unrounded value.
 */
export function exposedValue(value: number | null, f: CalcFormat): number | null {
  if (value === null || f.format !== "currency") return value;
  const scale = 10 ** (f.decimals ?? 2);
  return Math.round(value * scale) / scale || 0; // `|| 0` normalizes -0
}

/** A calculated value as it appears in the generated document. Null → "". */
export function formatCalculated(value: number | null, f: CalcFormat): string {
  if (value === null) return "";
  const v = f.display === "abs" ? Math.abs(value) : value;
  if (f.format === "integer") return String(Math.round(v) || 0);
  return fixed(v, f.decimals ?? 2);
}

/**
 * A calculated value as shown in the wizard and on Review. Null → "—".
 * Keeps the sign even with `display: "abs"`, so the user can see whether a
 * change is an increase or a reduction.
 */
export function formatCalculatedForUi(value: number | null, f: CalcFormat): string {
  if (value === null) return "—";
  const v = value;
  const decimals = f.decimals ?? 2;
  switch (f.format) {
    case "currency": {
      // Sign before the symbol: "-$1,000.00", not "$-1,000.00".
      const amount = fixed(Math.abs(v), decimals);
      return v < 0 && Number(amount.replace(/,/g, "")) !== 0 ? `-$${amount}` : `$${amount}`;
    }
    case "integer":
      return String(Math.round(v) || 0);
    default:
      return fixed(v, decimals);
  }
}

/**
 * Format a user-entered number for the document according to a field or
 * column `format`. Omitted format (or "number") passes the value through
 * unchanged so counts, TAT days, and years render as entered. Non-numeric
 * input is returned as-is.
 */
export function formatNumberForTemplate(
  value: string | number,
  format: NumberFormat | undefined,
  decimals?: number,
): string | number {
  if (!format || format === "number") return value;
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(n)) return value;
  return format === "integer" ? String(Math.round(n)) : fixed(n, decimals ?? 2);
}
