import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { migrateSchemaShape, needsShapeMigration } from "./migrate";
import { collectSchemaErrors, schemas } from "../../schemas/loader";
import { renderDocxFromArrayBuffer } from "../../generation/generateDocx";
import { extractDocxText, loadTemplateBuffer } from "../../test/docx-test-utils";
import { scanTemplate } from "../../schemas/templateScan";
import type { DocumentSchema } from "../../schemas/types";

type Obj = Record<string, unknown>;
const base = (fields: Obj[], extra: Obj = {}): Obj => ({
  id: "x",
  title: "X",
  version: 1,
  docx_template: "x.docx",
  sections: [{ id: "s", title: "S", fields }],
  ...extra,
});
const fieldsOf = (schema: unknown) => (schema as { sections: { fields: Obj[] }[] }).sections[0].fields;

describe("migrateSchemaShape", () => {
  it("computed.formula → formula, defaulting format to currency", () => {
    const { schema, changed } = migrateSchemaShape(
      base([{ id: "d", label: "D", type: "number", required: true, computed: { formula: "a - b", display: "abs" } }]),
    );
    expect(changed).toBe(true);
    expect(fieldsOf(schema)[0]).toEqual({ id: "d", label: "D", type: "number", required: true, formula: "a - b", format: "currency", display: "abs" });
  });

  it("keeps an explicit computed.format", () => {
    const { schema } = migrateSchemaShape(base([{ id: "d", label: "D", type: "number", required: true, computed: { formula: "a", format: "integer" } }]));
    expect(fieldsOf(schema)[0].format).toBe("integer");
  });

  it("aggregate computed → SUM / AVG / MIN / MAX formula (currency) or COUNT(table) (integer)", () => {
    const { schema } = migrateSchemaShape(
      base([
        { id: "t", label: "T", type: "table", required: false, columns: [{ id: "c", label: "C", type: "number" }] },
        { id: "sum", label: "Sum", type: "number", required: true, computed: { source: "t", column: "c", function: "SUM" } },
        { id: "avg", label: "Avg", type: "number", required: true, computed: { source: "t", column: "c", function: "avg" } },
        { id: "n", label: "N", type: "number", required: true, computed: { source: "t", column: "c", function: "COUNT" } },
      ]),
    );
    const [, sum, avg, n] = fieldsOf(schema);
    expect([sum.formula, sum.format]).toEqual(["SUM(t.c)", "currency"]);
    expect([avg.formula, avg.format]).toEqual(["AVG(t.c)", "currency"]);
    expect([n.formula, n.format]).toEqual(["COUNT(t)", "integer"]);
    expect(n).not.toHaveProperty("computed");
  });

  it("table aggregates → formula fields after the table, keeping its visibility", () => {
    const { schema } = migrateSchemaShape(
      base([
        {
          id: "t",
          label: "T",
          type: "table",
          required: false,
          visible_when: "SHOW",
          columns: [{ id: "c", label: "C", type: "number", format: "currency" }, { id: "q", label: "Q", type: "number" }],
          aggregates: [
            { column_id: "c", function: "SUM", label: "Grand total" },
            { column_id: "q", function: "COUNT", label: "Lines" },
          ],
        },
        { id: "t_c_sum", label: "Taken", type: "number", required: false },
        { id: "after", label: "After", type: "string", required: false },
      ]),
    );
    const fields = fieldsOf(schema);
    expect(fields.map((f) => f.id)).toEqual(["t", "t_c_sum_2", "t_q_count", "t_c_sum", "after"]);
    expect(fields[0]).not.toHaveProperty("aggregates");
    expect(fields[1]).toEqual({ id: "t_c_sum_2", label: "Grand total", type: "number", required: false, formula: "SUM(t.c)", format: "currency", visible_when: "SHOW" });
    expect(fields[2]).toMatchObject({ formula: "COUNT(t.q)", format: "integer" });
  });

  it("derived_fields → constants + formula fields in the first input's section, mapping only tags the template has", () => {
    const raw = {
      ...base([{ id: "n", label: "N", type: "number", required: true }]),
      template_key_map: { N: "s.n" },
      derived_fields: {
        constants: [{ id: "RATE", value: 2 }],
        inputs: ["s.n"],
        fields: [
          { id: "A", label: "A", formula: "s.n * RATE", format: { type: "currency" } },
          { id: "B", label: "B", formula: "A + 1", format: { type: "number", decimals: 6 } },
          { id: "C", label: "C", formula: "B", format: { type: "string" } },
          { id: "D", label: "D", formula: "B", format: { type: "currency", decimals: 2 } },
        ],
      },
    };
    const { schema } = migrateSchemaShape(raw, { templateTags: new Set(["N", "A", "C"]) });
    const out = schema as Obj;
    expect(out).not.toHaveProperty("derived_fields");
    expect(out.constants).toEqual({ RATE: 2 });
    expect(out.template_key_map).toEqual({ N: "s.n", A: "s.A", C: "s.C" });
    expect(fieldsOf(out).slice(1)).toEqual([
      { id: "A", label: "A", type: "number", required: true, formula: "s.n * RATE", format: "currency" },
      { id: "B", label: "B", type: "number", required: true, formula: "A + 1", format: "number", decimals: 6 },
      { id: "C", label: "C", type: "number", required: true, formula: "B", format: "integer" },
      { id: "D", label: "D", type: "number", required: true, formula: "B", format: "currency" },
    ]);
    expect(collectSchemaErrors(structuredClone(out))).toEqual([]);
  });

  it("maps every derived id when the template's tags are unknown", () => {
    const { schema } = migrateSchemaShape({
      ...base([{ id: "n", label: "N", type: "number", required: true }]),
      derived_fields: { constants: [], inputs: [], fields: [{ id: "A", label: "A", formula: "s.n", format: { type: "currency" } }] },
    });
    expect((schema as Obj).template_key_map).toEqual({ A: "s.A" });
  });

  it("is idempotent and leaves current schemas (and the input object) alone", () => {
    const old = base([{ id: "d", label: "D", type: "number", required: true, computed: { formula: "1" } }]);
    const snapshot = JSON.stringify(old);
    const once = migrateSchemaShape(old).schema;
    expect(JSON.stringify(old)).toBe(snapshot);
    const twice = migrateSchemaShape(once);
    expect(twice.changed).toBe(false);
    expect(twice.schema).toBe(once);
    expect(needsShapeMigration(once)).toBe(false);
  });

  it("passes malformed input through for the loader to reject", () => {
    expect(migrateSchemaShape(null).schema).toBeNull();
    expect(migrateSchemaShape({ sections: "nope" }).changed).toBe(false);
    // A non-object `computed` becomes `formula` as-is, so the loader checks it like any formula
    const { schema } = migrateSchemaShape(base([{ id: "d", label: "D", type: "number", required: true, computed: 42 }]));
    expect(collectSchemaErrors(schema)).toEqual([`Section "s", field "d": formula must be a non-empty string`]);
  });
});

describe("migrating the pre-refactor built-ins", () => {
  const fixture = (name: string) =>
    JSON.parse(readFileSync(resolve(__dirname, "__fixtures__", `${name}.pre-formula.json`), "utf-8")) as DocumentSchema;

  it("fms-sh-price-reasonableness: the migrated copy validates against its own template", async () => {
    // The shipped memo has since gained an entered proposed amount and a
    // calculated delta, so only the migration itself is compared here.
    const shipped = schemas.get("fms-sh-price-reasonableness")!;
    const tags = scanTemplate(loadTemplateBuffer(shipped)).allTags;
    const { schema: migrated } = migrateSchemaShape(fixture("fms-sh-price-reasonableness"), { templateTags: tags });
    expect(collectSchemaErrors(structuredClone(migrated))).toEqual([]);
    expect((migrated as DocumentSchema).constants).toEqual(shipped.constants);
  });

  it.each([["fms-to-mod", "fms-to-mod"]])("%s: the migrated copy validates and renders the same document as the shipped schema", async (name, id) => {
    const shipped = schemas.get(id)!;
    const tpl = loadTemplateBuffer(shipped);
    const { schema: migrated } = migrateSchemaShape(fixture(name), { templateTags: scanTemplate(tpl).allTags });
    expect(collectSchemaErrors(structuredClone(migrated))).toEqual([]);

    const answers = JSON.parse(
      readFileSync(resolve(__dirname, "../../test/fixtures/answers", `${id}.answers.json`), "utf-8"),
    ) as Record<string, string | number | boolean>;
    const want = await extractDocxText(renderDocxFromArrayBuffer(tpl, shipped, answers));
    const got = await extractDocxText(renderDocxFromArrayBuffer(tpl, migrated, answers));
    expect(got).toBe(want);
  });
});
