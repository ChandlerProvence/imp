import { describe, it, expect } from "vitest";
import { FormulaSyntaxError, parseFormula, referencesOf, tryParseFormula } from "./parser";
import { computeTableFormulas } from "./evaluate";

/** Evaluate a constant expression by running it as a one-column row formula. */
function calc(formula: string, row: Record<string, string | number | boolean> = {}): number | "" {
  const columns = [
    ...Object.keys(row).map((id) => ({ id, label: id, type: "number" as const })),
    { id: "out", label: "out", type: "number" as const, formula },
  ];
  return computeTableFormulas(columns, [row])[0].out as number | "";
}

function syntaxError(formula: string): FormulaSyntaxError {
  try {
    parseFormula(formula);
  } catch (e) {
    if (e instanceof FormulaSyntaxError) return e;
    throw e;
  }
  throw new Error(`expected a syntax error for ${formula}`);
}

describe("parseFormula: grammar", () => {
  it("keeps standard precedence", () => {
    expect(calc("2 + 3 * 4")).toBe(14);
    expect(calc("(2 + 3) * 4")).toBe(20);
    expect(calc("10 - 4 - 3")).toBe(3); // left-associative
    expect(calc("12 / 3 / 2")).toBe(2);
  });

  it("makes ^ right-associative and tighter than * /", () => {
    expect(calc("2 ^ 3 ^ 2")).toBe(512);
    expect(calc("2 * 3 ^ 2")).toBe(18);
    expect(calc("4 ^ 0.5")).toBe(2);
  });

  it("reads decimal literals, including a leading dot", () => {
    expect(calc(".5 + 1.25")).toBe(1.75);
  });

  it("reads dotted names as one name", () => {
    expect(referencesOf(parseFormula("pricing.rate * qty")).names).toEqual(["pricing.rate", "qty"]);
  });

  it("parses COALESCE with any number of arguments and ABS with one", () => {
    expect(calc("COALESCE(a, b, 7)", { a: "", b: "" })).toBe(7);
    expect(calc("COALESCE(a, 0) + 1", { a: 4 })).toBe(5);
    expect(calc("ABS(0 - 3)")).toBe(3);
  });

  it("parses aggregate calls with a single table reference", () => {
    const ast = parseFormula("SUM(parts.cost) + COUNT(parts)");
    expect(referencesOf(ast).aggregates).toEqual([
      { name: "SUM", ref: "parts.cost" },
      { name: "COUNT", ref: "parts" },
    ]);
    expect(referencesOf(ast).names).toEqual([]);
  });

  it("de-duplicates references", () => {
    expect(referencesOf(parseFormula("a + a * SUM(t.c) - SUM(t.c)"))).toEqual({
      names: ["a"],
      aggregates: [{ name: "SUM", ref: "t.c" }],
    });
  });

  it("treats a function name not followed by ( as a plain name", () => {
    expect(referencesOf(parseFormula("SUM + 1")).names).toEqual(["SUM"]);
  });
});

describe("parseFormula: syntax errors point at the token", () => {
  it.each([
    ["qty * ", "the formula ends where a number or name was expected", "qty * "],
    ["(a + b", `expected ")" but the formula ended`, "(a + b"],
    ["a + * b", `unexpected "*"`, "a + *"],
    ["a b", `unexpected "b" after a complete expression`, "a b"],
    ["a $ b", `unexpected character "$"`, "$"],
    ["a. + 1", `a name can't end with "."`, "a."],
    ["0 - -1", `unexpected "-"`, "0 - -"],
  ])("%s", (formula, message, at) => {
    const e = syntaxError(formula);
    expect(e.message).toBe(message);
    expect(e.at).toBe(at);
  });

  it("names unknown functions and lists the available ones", () => {
    expect(syntaxError("FOO(1)").message).toBe(
      `"FOO" is not a function. Available: COALESCE, ABS, SUM, AVG, MIN, MAX, COUNT`,
    );
  });

  it("checks argument counts", () => {
    expect(syntaxError("ABS(1, 2)").message).toBe("ABS takes exactly 1 argument (found 2)");
    expect(syntaxError("SUM(t.a, t.b)").message).toBe("SUM takes exactly one table.column reference");
    expect(syntaxError("SUM(1 + 2)").message).toBe(`expected a table reference inside SUM() but found "1"`);
  });

  it("tryParseFormula returns null instead of throwing", () => {
    expect(tryParseFormula("1 +")).toBeNull();
    expect(tryParseFormula("1 + 1")).not.toBeNull();
  });
});
