/**
 * The single formula language for calculated fields and table columns.
 * See `scope.ts` for what a name may refer to and `evaluate.ts` for the
 * evaluation rules.
 */
export {
  AGGREGATE_FUNCTIONS,
  FUNCTIONS,
  FormulaSyntaxError,
  parseFormula,
  referencesOf,
  tryParseFormula,
  type AggregateName,
  type FormulaNode,
  type FormulaRefs,
  type FunctionName,
} from "./parser";
export {
  buildScopeIndex,
  FORMULA_NAME_RE,
  resolveAggregate,
  resolveName,
  type AggregateTarget,
  type NameTarget,
  type Place,
  type ScopeIndex,
} from "./scope";
export { buildCalcGraph, columnNodeId, evaluationOrder, findCycle, type CalcGraph, type CalcNode } from "./graph";
export { computeTableFormulas, constantsOf, evaluateFormulas, type FormulaResults } from "./evaluate";
export {
  exposedValue,
  formatCalculated,
  formatCalculatedForUi,
  formatNumberForTemplate,
  type CalcFormat,
} from "./format";
export { validateCalculations } from "./validate";
export { migrateSchemaShape, needsShapeMigration, type MigrateOptions, type MigrateResult } from "./migrate";
