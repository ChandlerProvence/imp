/**
 * Rewrite schemas written before the single formula language (2026-10) into
 * the current shape. Pure and idempotent; malformed input is returned with
 * whatever could be rewritten, for the loader to reject with its own
 * messages.
 *
 * | Old shape                                                | New shape                                                    |
 * |----------------------------------------------------------|--------------------------------------------------------------|
 * | field `computed: { formula, format?, display? }`         | field `formula`, `format` (default "currency"), `display`    |
 * | field `computed: { source, column, function }`           | field `formula: "FN(source.column)"` / `"COUNT(source)"`     |
 * | table `aggregates: [{ column_id, function, label }]`     | a formula field after the table: `"FN(table.column_id)"`     |
 * | schema `derived_fields: { constants, inputs, fields }`   | schema `constants` map + formula fields in the input section |
 *
 * Derived values used to be filled straight into Word tags named after their
 * ids, with no `template_key_map` entry. Each new field gets one for every
 * tag the template uses (all of them when the tags are not known).
 */

type Obj = Record<string, unknown>;

const isObj = (v: unknown): v is Obj => typeof v === "object" && v !== null && !Array.isArray(v);

export interface MigrateOptions {
  /** Tags the Word template contains. Limits which derived values get a `template_key_map` entry. */
  templateTags?: Set<string>;
}

export interface MigrateResult<T> {
  schema: T;
  changed: boolean;
  /** One line per rewrite, for logs and tests. */
  notes: string[];
}

/** True when the schema uses a shape `migrateSchemaShape` rewrites. */
export function needsShapeMigration(raw: unknown): boolean {
  if (!isObj(raw)) return false;
  if (raw.derived_fields !== undefined) return true;
  if (!Array.isArray(raw.sections)) return false;
  return raw.sections.some(
    (s) => isObj(s) && Array.isArray(s.fields) && s.fields.some((f) => isObj(f) && (f.computed !== undefined || f.aggregates !== undefined)),
  );
}

function uniqueId(base: string, taken: Set<string>): string {
  let id = base;
  for (let n = 2; taken.has(id); n++) id = `${base}_${n}`;
  taken.add(id);
  return id;
}

function migrateComputed(field: Obj, where: string, notes: string[]): void {
  const c = field.computed;
  delete field.computed;
  if (!isObj(c)) {
    // Leave something the loader will flag rather than silently dropping it
    field.formula = c as never;
    notes.push(`${where}: computed was not an object`);
    return;
  }
  if ("formula" in c) {
    field.formula = c.formula;
    field.format = c.format ?? field.format ?? "currency";
    if (c.display !== undefined) field.display = c.display;
    notes.push(`${where}: computed.formula → formula`);
    return;
  }
  const fn = typeof c.function === "string" ? c.function.toUpperCase() : String(c.function);
  const source = String(c.source);
  if (fn === "COUNT") {
    field.formula = `COUNT(${source})`;
    field.format = field.format ?? "integer";
  } else {
    field.formula = `${fn}(${source}.${String(c.column)})`;
    // Totals always rendered with two decimals before
    field.format = field.format ?? "currency";
  }
  notes.push(`${where}: computed ${fn} of ${source} → formula ${String(field.formula)}`);
}

function migrateAggregates(section: Obj, table: Obj, taken: Set<string>, notes: string[]): Obj[] {
  const aggs = table.aggregates;
  delete table.aggregates;
  if (!Array.isArray(aggs)) return [];
  const columns = Array.isArray(table.columns) ? (table.columns as Obj[]) : [];
  const out: Obj[] = [];
  for (const a of aggs) {
    if (!isObj(a)) continue;
    const fn = String(a.function).toUpperCase();
    const col = String(a.column_id);
    const colDef = columns.find((c) => isObj(c) && c.id === col);
    const field: Obj = {
      id: uniqueId(`${String(table.id)}_${col}_${fn.toLowerCase()}`, taken),
      label: typeof a.label === "string" ? a.label : `${fn} of ${col}`,
      type: "number",
      required: false,
      formula: fn === "COUNT" ? `COUNT(${String(table.id)}.${col})` : `${fn}(${String(table.id)}.${col})`,
      format: fn === "COUNT" ? "integer" : (colDef?.format ?? "number"),
    };
    if (table.visible_when !== undefined) field.visible_when = table.visible_when;
    out.push(field);
    notes.push(`${String(section.id)}.${String(table.id)}: aggregate "${String(field.label)}" → field ${String(field.id)}`);
  }
  return out;
}

function derivedFormat(fmt: unknown): Obj {
  if (!isObj(fmt)) return { format: "number" };
  switch (fmt.type) {
    case "currency":
      return fmt.decimals !== undefined && fmt.decimals !== 2 ? { format: "currency", decimals: fmt.decimals } : { format: "currency" };
    case "number":
      return fmt.decimals !== undefined && fmt.decimals !== 2 ? { format: "number", decimals: fmt.decimals } : { format: "number" };
    case "integer":
    case "string":
      // "string" rendered the raw number; every built-in used it for whole numbers
      return { format: "integer" };
    default:
      return { format: "number" };
  }
}

function migrateDerived(schema: Obj, sections: Obj[], opts: MigrateOptions, notes: string[]): void {
  const df = schema.derived_fields;
  delete schema.derived_fields;
  if (!isObj(df)) {
    notes.push("derived_fields was not an object; dropped");
    return;
  }

  // Constants
  if (Array.isArray(df.constants) && df.constants.length) {
    const constants: Obj = isObj(schema.constants) ? { ...schema.constants } : {};
    for (const c of df.constants) {
      if (isObj(c) && typeof c.id === "string") constants[c.id] = c.value;
    }
    schema.constants = constants;
    notes.push(`derived_fields.constants → constants (${Object.keys(constants).length})`);
  }

  const fields = Array.isArray(df.fields) ? (df.fields as unknown[]).filter(isObj) : [];
  if (fields.length === 0) return;

  // Home section: where the first input lives, else the last section
  const inputs = Array.isArray(df.inputs) ? (df.inputs as unknown[]).filter((i): i is string => typeof i === "string") : [];
  const homeId = inputs[0]?.split(".")[0];
  const home = sections.find((s) => s.id === homeId) ?? sections[sections.length - 1];
  if (!home || !Array.isArray(home.fields)) return;
  const homeFields = home.fields as Obj[];
  const taken = new Set(homeFields.map((f) => String(f.id)));

  // Derived formulas already wrote inputs as section.field paths, constants
  // and other derived ids as bare names, which is how a field formula in the
  // home section resolves them, so the formula text carries over unchanged.
  const tkm: Obj = isObj(schema.template_key_map) ? schema.template_key_map : {};
  let addedTags = 0;
  for (const d of fields) {
    const id = String(d.id);
    if (taken.has(id)) notes.push(`derived field ${id} collides with field ${String(home.id)}.${id}; kept the name, the loader will report it`);
    taken.add(id);
    homeFields.push({
      id,
      label: typeof d.label === "string" ? d.label : id,
      type: "number",
      // Derived values never left a tag unfilled on purpose; required keeps the
      // {{TAG}} visible when an input is missing, as before.
      required: true,
      formula: d.formula,
      ...derivedFormat(d.format),
    });
    const tag = id;
    const wanted = opts.templateTags ? opts.templateTags.has(tag) : true;
    if (wanted && !(tag in tkm)) {
      tkm[tag] = `${String(home.id)}.${id}`;
      addedTags++;
    }
  }
  if (addedTags) schema.template_key_map = tkm;
  notes.push(`derived_fields → ${fields.length} formula fields in section ${String(home.id)} (${addedTags} template tags mapped)`);
}

/**
 * Rewrite any old calculation shape in `raw` (deep-copied; the input is not
 * modified). Returns the input itself when nothing needed rewriting.
 */
export function migrateSchemaShape<T>(raw: T, opts: MigrateOptions = {}): MigrateResult<T> {
  if (!needsShapeMigration(raw)) return { schema: raw, changed: false, notes: [] };
  const schema = structuredClone(raw) as unknown as Obj;
  const notes: string[] = [];
  const sections = Array.isArray(schema.sections) ? (schema.sections as unknown[]).filter(isObj) : [];

  for (const section of sections) {
    if (!Array.isArray(section.fields)) continue;
    const fields = section.fields as unknown[];
    const taken = new Set(fields.filter(isObj).map((f) => String(f.id)));
    const next: unknown[] = [];
    fields.forEach((f) => {
      next.push(f);
      if (!isObj(f)) return;
      const where = `${String(section.id)}.${String(f.id)}`;
      if (f.computed !== undefined) migrateComputed(f, where, notes);
      if (f.aggregates !== undefined) next.push(...migrateAggregates(section, f, taken, notes));
    });
    section.fields = next;
  }

  if (schema.derived_fields !== undefined) migrateDerived(schema, sections, opts, notes);

  return { schema: schema as T, changed: true, notes };
}
