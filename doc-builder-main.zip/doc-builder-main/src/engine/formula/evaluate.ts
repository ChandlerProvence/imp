/**
 * Evaluate every formula in a schema against a set of answers.
 *
 * - Empty, missing, or non-numeric inputs are `null`; `null` propagates
 *   through every operator; division by zero is `null`.
 * - `COALESCE(a, b, …)` is the first non-null argument; `ABS(x)` is |x|.
 * - SUM / AVG / MIN / MAX skip empty and non-numeric cells and are `null`
 *   when nothing is left. `COUNT(table)` is the number of rows;
 *   `COUNT(table.column)` is the number of rows with that cell filled. Every
 *   aggregate is `null` for a table with no rows.
 * - Formula columns are filled into each row first, then formula fields are
 *   evaluated in dependency order, so a field can total a calculated column.
 */
import type { TableColumnDef } from "../../schemas/types";
import { parseTableData, serializeTableData, type TableRow } from "../tableData";
import { isEmptyValue, toNumber } from "../validation/coerce";
import { exposedValue } from "./format";
import { buildCalcGraph, evaluationOrder, type CalcGraph, type SchemaLike } from "./graph";
import { tryParseFormula, type FormulaNode } from "./parser";
import { buildScopeIndex, resolveAggregate, resolveName, type Place, type ScopeIndex } from "./scope";

type Answers = Record<string, string | number | boolean>;

export interface FormulaResults {
  /** `answers` with every formula column filled in (input not mutated). */
  answers: Answers;
  /**
   * Every formula field's value (`section.field` → number | null), rounded
   * to cents when its format is currency. What conditions, validation rules,
   * and formatting read.
   */
  values: Record<string, number | null>;
}

type Lookup = (name: string) => number | null;
type AggregateLookup = (name: string, ref: string) => number | null;

function run(ast: FormulaNode, lookup: Lookup, aggregate: AggregateLookup): number | null {
  switch (ast.type) {
    case "number":
      return ast.value;
    case "name":
      return lookup(ast.name);
    case "aggregate":
      return aggregate(ast.name, ast.ref);
    case "binary": {
      const l = run(ast.left, lookup, aggregate);
      const r = run(ast.right, lookup, aggregate);
      if (l === null || r === null) return null;
      let v: number;
      switch (ast.op) {
        case "+": v = l + r; break;
        case "-": v = l - r; break;
        case "*": v = l * r; break;
        case "/": if (r === 0) return null; v = l / r; break;
        case "^": v = l ** r; break;
      }
      return Number.isFinite(v) ? v : null;
    }
    case "call": {
      if (ast.name === "COALESCE") {
        for (const arg of ast.args) {
          const v = run(arg, lookup, aggregate);
          if (v !== null) return v;
        }
        return null;
      }
      const v = run(ast.args[0], lookup, aggregate);
      return v === null ? null : Math.abs(v);
    }
  }
}

const noAggregates: AggregateLookup = () => null;

/** Order formula columns so a column is computed after the columns it reads. */
function columnOrder(columns: TableColumnDef[]): { col: TableColumnDef; ast: FormulaNode | null }[] {
  const formulas = new Map(columns.filter((c) => c.formula !== undefined).map((c) => [c.id, c]));
  const order: { col: TableColumnDef; ast: FormulaNode | null }[] = [];
  const seen = new Set<string>();
  const visit = (col: TableColumnDef) => {
    if (seen.has(col.id)) return;
    seen.add(col.id);
    const ast = tryParseFormula(col.formula!);
    if (ast) {
      const names: string[] = [];
      const walk = (n: FormulaNode): void => {
        if (n.type === "name") names.push(n.name);
        else if (n.type === "binary") { walk(n.left); walk(n.right); }
        else if (n.type === "call") n.args.forEach(walk);
      };
      walk(ast);
      for (const name of names) {
        const dep = formulas.get(name);
        if (dep) visit(dep);
      }
    }
    order.push({ col, ast });
  };
  for (const col of formulas.values()) visit(col);
  return order;
}

/**
 * Fill a table's formula columns into each row. Used by the live table
 * editor as well as `evaluateFormulas`. A column formula sees the row's
 * other columns and the schema's constants. Returns `rows` itself when the
 * table has no formula columns.
 */
export function computeTableFormulas(
  columns: TableColumnDef[],
  rows: TableRow[],
  constants: Record<string, number> | Map<string, number> = {},
): TableRow[] {
  const order = columnOrder(columns);
  if (order.length === 0) return rows;
  const consts = constants instanceof Map ? constants : new Map(Object.entries(constants));
  const colIds = new Set(columns.map((c) => c.id));
  return rows.map((row) => {
    const next: TableRow = { ...row };
    const lookup: Lookup = (name) => {
      if (colIds.has(name)) return toNumber(next[name]);
      return consts.get(name) ?? null;
    };
    for (const { col, ast } of order) {
      const v = ast ? run(ast, lookup, noAggregates) : null;
      next[col.id] = v === null ? "" : v;
    }
    return next;
  });
}

function aggregateRows(fn: string, rows: TableRow[], columnId: string | undefined): number | null {
  if (rows.length === 0) return null;
  if (fn === "COUNT") {
    return columnId === undefined ? rows.length : rows.filter((r) => !isEmptyValue(r[columnId])).length;
  }
  const values: number[] = [];
  for (const row of rows) {
    const n = toNumber(row[columnId!]);
    if (n !== null) values.push(n);
  }
  if (values.length === 0) return null;
  switch (fn) {
    case "SUM": return values.reduce((a, b) => a + b, 0);
    case "AVG": return values.reduce((a, b) => a + b, 0) / values.length;
    case "MIN": return Math.min(...values);
    case "MAX": return Math.max(...values);
    default: return null;
  }
}

/** Evaluate every formula column and formula field. */
export function evaluateFormulas(
  schema: SchemaLike,
  answers: Answers,
  graph: CalcGraph = buildCalcGraph(schema),
): FormulaResults {
  const index: ScopeIndex = graph.index;
  let filled: Answers | undefined;

  // 1. Formula columns, table by table.
  for (const sec of schema.sections) {
    for (const f of sec.fields) {
      if (f.type !== "table" || !f.columns?.some((c) => c.formula !== undefined)) continue;
      const key = `${sec.id}.${f.id}`;
      const { rows } = parseTableData(answers[key]);
      if (rows.length === 0) continue;
      filled ??= { ...answers };
      filled[key] = serializeTableData({ rows: computeTableFormulas(f.columns, rows, index.constants) });
    }
  }
  const current = filled ?? answers;

  // 2. Formula fields, in dependency order.
  const raw = new Map<string, number | null>();
  const tableRows = new Map<string, TableRow[]>();
  const rowsOf = (key: string) => {
    let rows = tableRows.get(key);
    if (!rows) {
      rows = parseTableData(current[key]).rows;
      tableRows.set(key, rows);
    }
    return rows;
  };

  for (const id of evaluationOrder(graph)) {
    const node = graph.nodes.get(id)!;
    if (node.kind !== "field") continue;
    const place: Place = node.place;
    const lookup: Lookup = (name) => {
      const r = resolveName(index, place, name);
      if (!r.ok) return null;
      const t = r.target;
      if (t.kind === "constant") return t.value;
      if (t.kind !== "field") return null;
      if (graph.nodes.has(t.key)) return raw.get(t.key) ?? null;
      return toNumber(current[t.key]);
    };
    const aggregate: AggregateLookup = (fn, ref) => {
      const r = resolveAggregate(index, place, { name: fn as never, ref });
      if (!r.ok) return null;
      return aggregateRows(fn, rowsOf(r.target.key), r.target.column?.id);
    };
    raw.set(id, node.ast ? run(node.ast, lookup, aggregate) : null);
  }

  const values: Record<string, number | null> = {};
  for (const [id, v] of raw) {
    const node = graph.nodes.get(id)!;
    values[id] = exposedValue(v, node.def);
  }
  return { answers: current, values };
}

/** Constants of a schema as a map (invalid entries dropped). */
export function constantsOf(schema: { constants?: unknown }): Map<string, number> {
  return buildScopeIndex({ sections: [], constants: schema.constants }).constants;
}
