/**
 * Load-time checks for every formula, number format, and constant in a
 * schema. Messages name the place, the exact token at fault, and what is
 * allowed there, so whoever fixes the schema (a person or a chatbot) can act
 * on each one without reading the code.
 */
import type { FieldDef } from "../../schemas/types";
import { buildCalcGraph, findCycle, type CalcGraph } from "./graph";
import { FormulaSyntaxError, parseFormula, referencesOf } from "./parser";
import { FORMULA_NAME_RE, resolveAggregate, resolveName, type Place } from "./scope";

const FORMATS = ["currency", "number", "integer"];
const MAX_DECIMALS = 6;

interface RawSection {
  id: string;
  fields: Record<string, unknown>[];
}

function where(place: Place): string {
  return place.kind === "field"
    ? `Section "${place.section}", field "${place.field}"`
    : `Section "${place.section}", field "${place.field}", column "${place.column}"`;
}

function nodeLabel(id: string, graph: CalcGraph): string {
  const node = graph.nodes.get(id);
  if (node?.kind === "column") return `${node.place.section}.${node.place.field} column ${node.place.column}`;
  return id;
}

/** Checks on `format`, `decimals`, and `display` that apply to any number field or column. */
function checkNumberSettings(
  item: Record<string, unknown>,
  context: string,
  isColumn: boolean,
  errors: string[],
): void {
  const has = (k: string) => item[k] !== undefined;
  if (has("format")) {
    if (!FORMATS.includes(item.format as string)) {
      errors.push(`${context}: format must be "currency", "number", or "integer" (found ${JSON.stringify(item.format)})`);
    } else if (item.type !== "number") {
      errors.push(`${context}: format only applies to number ${isColumn ? "columns" : "fields"} (this one is type "${String(item.type)}")`);
    }
  }
  if (has("decimals")) {
    const d = item.decimals;
    if (typeof d !== "number" || !Number.isInteger(d) || d < 0 || d > MAX_DECIMALS) {
      errors.push(`${context}: decimals must be a whole number from 0 to ${MAX_DECIMALS} (found ${JSON.stringify(d)})`);
    } else if (item.format === "integer") {
      errors.push(`${context}: decimals has no effect with format "integer"; remove one of them`);
    }
  }
  if (has("display")) {
    if (isColumn) {
      errors.push(`${context}: display is not supported on table columns`);
    } else if (item.display !== "abs") {
      errors.push(`${context}: display must be "abs" (found ${JSON.stringify(item.display)})`);
    } else if (item.formula === undefined) {
      errors.push(`${context}: display "abs" is only allowed on a field with a formula`);
    }
  }
}

function checkConstants(raw: unknown, sections: RawSection[], errors: string[]): void {
  if (raw === undefined) return;
  if (typeof raw !== "object" || raw === null || Array.isArray(raw)) {
    errors.push(`constants must be an object of name → number, for example { "TAX_RATE": 0.06 }`);
    return;
  }
  const taken = new Map<string, string>();
  for (const sec of sections) {
    taken.set(sec.id, `section "${sec.id}"`);
    for (const f of sec.fields) if (typeof f.id === "string") taken.set(f.id, `field "${sec.id}.${f.id}"`);
  }
  for (const [name, value] of Object.entries(raw as Record<string, unknown>)) {
    if (!FORMULA_NAME_RE.test(name)) {
      errors.push(`constants: "${name}" is not a valid name (letters, digits, and "_", not starting with a digit)`);
    }
    if (typeof value !== "number" || !Number.isFinite(value)) {
      errors.push(`constants.${name} must be a number (found ${JSON.stringify(value)})`);
    }
    const clash = taken.get(name);
    if (clash) {
      errors.push(`constants: "${name}" has the same name as ${clash}; constant names must not match any section or field id`);
    }
  }
}

function checkFormula(text: unknown, place: Place, graph: CalcGraph, errors: string[]): void {
  const at = where(place);
  if (typeof text !== "string" || text.trim().length === 0) {
    errors.push(`${at}: formula must be a non-empty string`);
    return;
  }
  let refs;
  try {
    refs = referencesOf(parseFormula(text));
  } catch (e) {
    if (!(e instanceof FormulaSyntaxError)) throw e;
    errors.push(`${at}: formula syntax error at "${e.at}": ${e.message}. The whole formula is "${text}"`);
    return;
  }
  const self = place.kind === "field" ? place.field : place.column;
  for (const name of refs.names) {
    if (name === self) {
      errors.push(`${at}: formula uses "${name}", which is this ${place.kind} itself`);
      continue;
    }
    const r = resolveName(graph.index, place, name);
    if (!r.ok) errors.push(`${at}: ${r.problem}`);
  }
  for (const agg of refs.aggregates) {
    const r = resolveAggregate(graph.index, place, agg);
    if (!r.ok) errors.push(`${at}: ${r.problem}`);
  }
}

/**
 * Return error messages for every formula, number setting, and constant.
 * Expects `sections` to be an array of `{ id, fields: object[] }` (the
 * loader only calls this once that structure is known to hold).
 */
export function validateCalculations(raw: { sections: unknown; constants?: unknown }): string[] {
  const errors: string[] = [];
  const sections = raw.sections as RawSection[];

  checkConstants(raw.constants, sections, errors);

  for (const sec of sections) {
    for (const f of sec.fields) {
      const fieldPlace: Place = { kind: "field", section: sec.id, field: String(f.id) };
      checkNumberSettings(f, where(fieldPlace), false, errors);
      if (f.formula !== undefined && f.type !== "number") {
        errors.push(`${where(fieldPlace)}: has a formula, so its type must be "number" (found "${String(f.type)}")`);
      }
      if (f.formula !== undefined && f.same_as !== undefined) {
        errors.push(`${where(fieldPlace)}: a field can't have both a formula and same_as`);
      }
      if (f.type === "table" && Array.isArray(f.columns)) {
        for (const c of f.columns as Record<string, unknown>[]) {
          const colPlace: Place = { kind: "column", section: sec.id, field: String(f.id), column: String(c.id) };
          checkNumberSettings(c, where(colPlace), true, errors);
          if (c.formula !== undefined && c.type !== "number") {
            errors.push(`${where(colPlace)}: has a formula, so its type must be "number" (found "${String(c.type)}")`);
          }
        }
      }
    }
  }

  const graph = buildCalcGraph(raw as { sections: { id: string; fields: FieldDef[] }[]; constants?: unknown });
  for (const node of graph.nodes.values()) {
    checkFormula(node.def.formula, node.place, graph, errors);
  }

  // Self-references are reported above; the graph has no self-edges.
  const cycle = findCycle(graph);
  if (cycle) {
    const path = cycle.map((id) => nodeLabel(id, graph)).join(" → ");
    errors.push(`Circular formula: ${path}. Each formula must be computable from the others without coming back to itself`);
  }
  return errors;
}
