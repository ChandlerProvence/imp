/**
 * Formula grammar shared by every calculated field and column.
 *
 *   expr   = term (('+' | '-') term)*
 *   term   = power (('*' | '/') power)*
 *   power  = factor ('^' power)?                      right-associative
 *   factor = number | name | '(' expr ')'
 *          | FN '(' expr (',' expr)* ')'              FN ∈ COALESCE, ABS
 *          | AGG '(' name ')'                         AGG ∈ SUM, AVG, MIN, MAX, COUNT
 *   name   = [A-Za-z_][A-Za-z0-9_]* ('.' [A-Za-z_][A-Za-z0-9_]*)*
 *
 * There is no unary minus: write `0 - x`.
 */

export const FUNCTIONS = ["COALESCE", "ABS"] as const;
export const AGGREGATE_FUNCTIONS = ["SUM", "AVG", "MIN", "MAX", "COUNT"] as const;
export type FunctionName = (typeof FUNCTIONS)[number];
export type AggregateName = (typeof AGGREGATE_FUNCTIONS)[number];

const FUNCTION_SET = new Set<string>(FUNCTIONS);
const AGGREGATE_SET = new Set<string>(AGGREGATE_FUNCTIONS);

export type FormulaNode =
  | { type: "number"; value: number }
  | { type: "name"; name: string }
  | { type: "binary"; op: "+" | "-" | "*" | "/" | "^"; left: FormulaNode; right: FormulaNode }
  | { type: "call"; name: FunctionName; args: FormulaNode[] }
  | { type: "aggregate"; name: AggregateName; ref: string };

/** A syntax problem, with the text the author should look at. */
export class FormulaSyntaxError extends Error {
  /** The formula text up to and including the token the problem was found at. */
  readonly at: string;
  constructor(message: string, at: string) {
    super(message);
    this.name = "FormulaSyntaxError";
    this.at = at;
  }
}

type Token =
  | { type: "number"; text: string; pos: number }
  | { type: "name"; text: string; pos: number }
  | { type: "op"; text: string; pos: number }
  | { type: "("; text: string; pos: number }
  | { type: ")"; text: string; pos: number }
  | { type: ","; text: string; pos: number };

const NAME_RE = /[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*/y;
const NUMBER_RE = /(?:\d+(?:\.\d*)?|\.\d+)/y;

function tokenize(text: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  while (i < text.length) {
    const ch = text[i];
    if (/\s/.test(ch)) {
      i++;
      continue;
    }
    NUMBER_RE.lastIndex = i;
    const num = NUMBER_RE.exec(text);
    if (num) {
      tokens.push({ type: "number", text: num[0], pos: i });
      i += num[0].length;
      continue;
    }
    NAME_RE.lastIndex = i;
    const name = NAME_RE.exec(text);
    if (name) {
      tokens.push({ type: "name", text: name[0], pos: i });
      i += name[0].length;
      if (text[i] === ".") throw new FormulaSyntaxError(`a name can't end with "."`, text.slice(0, i + 1));
      continue;
    }
    if ("+-*/^".includes(ch)) tokens.push({ type: "op", text: ch, pos: i });
    else if (ch === "(" || ch === ")" || ch === ",") tokens.push({ type: ch, text: ch, pos: i });
    else throw new FormulaSyntaxError(`unexpected character "${ch}"`, ch);
    i++;
  }
  return tokens;
}

function parseTokens(tokens: Token[], source: string): FormulaNode {
  let pos = 0;
  const peek = () => tokens[pos];
  const isOp = (...ops: string[]) => peek()?.type === "op" && ops.includes(peek()!.text);
  const upTo = (t: Token | undefined) => (t ? source.slice(0, t.pos + t.text.length) : source);

  function expect(type: Token["type"], what: string): Token {
    const t = peek();
    if (!t) throw new FormulaSyntaxError(`expected ${what} but the formula ended`, source);
    if (t.type !== type) throw new FormulaSyntaxError(`expected ${what} but found "${t.text}"`, upTo(t));
    pos++;
    return t;
  }

  function expr(): FormulaNode {
    let left = term();
    while (isOp("+", "-")) {
      const op = tokens[pos++].text as "+" | "-";
      left = { type: "binary", op, left, right: term() };
    }
    return left;
  }

  function term(): FormulaNode {
    let left = power();
    while (isOp("*", "/")) {
      const op = tokens[pos++].text as "*" | "/";
      left = { type: "binary", op, left, right: power() };
    }
    return left;
  }

  function power(): FormulaNode {
    const base = factor();
    if (isOp("^")) {
      pos++;
      return { type: "binary", op: "^", left: base, right: power() };
    }
    return base;
  }

  function factor(): FormulaNode {
    const t = peek();
    if (!t) throw new FormulaSyntaxError("the formula ends where a number or name was expected", source);
    if (t.type === "number") {
      pos++;
      return { type: "number", value: Number(t.text) };
    }
    if (t.type === "(") {
      pos++;
      const inner = expr();
      expect(")", `")"`);
      return inner;
    }
    if (t.type === "name") {
      pos++;
      if (peek()?.type !== "(") return { type: "name", name: t.text };
      // Function or aggregate call
      pos++;
      if (AGGREGATE_SET.has(t.text)) {
        const ref = expect("name", `a table reference inside ${t.text}()`);
        if (peek()?.type === ",") {
          throw new FormulaSyntaxError(`${t.text} takes exactly one table.column reference`, upTo(peek()));
        }
        expect(")", `")" to close ${t.text}(`);
        return { type: "aggregate", name: t.text as AggregateName, ref: ref.text };
      }
      if (!FUNCTION_SET.has(t.text)) {
        throw new FormulaSyntaxError(
          `"${t.text}" is not a function. Available: ${[...FUNCTIONS, ...AGGREGATE_FUNCTIONS].join(", ")}`,
          t.text,
        );
      }
      const args = [expr()];
      while (peek()?.type === ",") {
        pos++;
        args.push(expr());
      }
      expect(")", `")" to close ${t.text}(`);
      if (t.text === "ABS" && args.length !== 1) {
        throw new FormulaSyntaxError(`ABS takes exactly 1 argument (found ${args.length})`, t.text);
      }
      return { type: "call", name: t.text as FunctionName, args };
    }
    throw new FormulaSyntaxError(`unexpected "${t.text}"`, upTo(t));
  }

  const ast = expr();
  if (pos < tokens.length) {
    const t = tokens[pos];
    throw new FormulaSyntaxError(`unexpected "${t.text}" after a complete expression`, upTo(t));
  }
  return ast;
}

const cache = new Map<string, FormulaNode | FormulaSyntaxError>();

/** Parse a formula. Throws `FormulaSyntaxError`. Results are cached by text. */
export function parseFormula(text: string): FormulaNode {
  let hit = cache.get(text);
  if (!hit) {
    try {
      hit = parseTokens(tokenize(text), text);
    } catch (e) {
      if (!(e instanceof FormulaSyntaxError)) throw e;
      hit = e;
    }
    if (cache.size > 2000) cache.clear();
    cache.set(text, hit);
  }
  if (hit instanceof FormulaSyntaxError) throw hit;
  return hit;
}

/** Parse, returning null instead of throwing. */
export function tryParseFormula(text: string): FormulaNode | null {
  try {
    return parseFormula(text);
  } catch {
    return null;
  }
}

export interface FormulaRefs {
  /** Plain names: sibling ids, `section.field` paths, constants. */
  names: string[];
  /** Aggregate calls and their table reference. */
  aggregates: { name: AggregateName; ref: string }[];
}

/** Every name and aggregate reference in a parsed formula, de-duplicated, in order. */
export function referencesOf(ast: FormulaNode): FormulaRefs {
  const names = new Set<string>();
  const aggregates = new Map<string, { name: AggregateName; ref: string }>();
  const walk = (n: FormulaNode): void => {
    switch (n.type) {
      case "name":
        names.add(n.name);
        break;
      case "aggregate":
        aggregates.set(`${n.name}(${n.ref})`, { name: n.name, ref: n.ref });
        break;
      case "binary":
        walk(n.left);
        walk(n.right);
        break;
      case "call":
        n.args.forEach(walk);
        break;
    }
  };
  walk(ast);
  return { names: [...names], aggregates: [...aggregates.values()] };
}
