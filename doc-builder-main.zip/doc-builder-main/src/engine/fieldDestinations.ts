import type { DocumentSchema } from "../schemas/types";

/** Where a field appears in the output document. */
export interface FieldDestination {
  /** Human-readable heading in the output (e.g., "Confidentiality Obligations"). */
  heading: string;
  /** Document title — relevant for set sessions with multiple output documents. */
  documentTitle?: string;
  /** Whether this destination is from a Markdown template or a Word (.docx) template. */
  source: "markdown" | "docx";
}

/** Map from field key ("section_id.field_id") to its output destinations. */
export type FieldDestinationMap = Map<string, FieldDestination[]>;

// ────────────────────────────────────────────────────────────────────────────

function addDestination(
  map: FieldDestinationMap,
  key: string,
  dest: FieldDestination,
): void {
  const existing = map.get(key);
  if (existing) {
    // Avoid exact duplicates (same heading + same source + same documentTitle)
    if (!existing.some((d) => d.heading === dest.heading && d.source === dest.source && d.documentTitle === dest.documentTitle)) {
      existing.push(dest);
    }
  } else {
    map.set(key, [dest]);
  }
}

/**
 * Parse a Markdown output_template and identify which heading each
 * {{section_id.field_id}} placeholder falls under.
 */
function parseOutputTemplate(
  template: string,
  documentTitle?: string,
): FieldDestinationMap {
  const map: FieldDestinationMap = new Map();
  const lines = template.split("\n");
  let currentHeading = "(Document root)";

  for (const line of lines) {
    // Detect Markdown headings: # … or ## … etc.
    const headingMatch = line.match(/^(#{1,6})\s+(.+)$/);
    if (headingMatch) {
      currentHeading = headingMatch[2].trim();
    }

    // Detect scalar placeholders: {{section_id.field_id}}
    const scalarRe = /\{\{([^#/}][^}]*)\}\}/g;
    let match: RegExpExecArray | null;
    while ((match = scalarRe.exec(line)) !== null) {
      const key = match[1].trim();
      addDestination(map, key, { heading: currentHeading, documentTitle, source: "markdown" });
    }

    // Detect table block starts: {{#section_id.field_id}}
    const blockRe = /\{\{#([^}]+)\}\}/g;
    while ((match = blockRe.exec(line)) !== null) {
      const key = match[1].trim();
      addDestination(map, key, { heading: currentHeading, documentTitle, source: "markdown" });
    }
  }

  return map;
}

/**
 * Parse a template_key_map (Word .docx placeholder → field key) into destinations.
 */
function parseTemplateKeyMap(
  templateKeyMap: Record<string, string | { field: string; date_format: string }>,
  documentTitle?: string,
): FieldDestinationMap {
  const map: FieldDestinationMap = new Map();
  for (const [tag, mapping] of Object.entries(templateKeyMap)) {
    const fieldKey = typeof mapping === "string" ? mapping : mapping.field;
    addDestination(map, fieldKey, {
      heading: tag,
      documentTitle,
      source: "docx",
    });
  }
  return map;
}

/**
 * Merge a source map into a target map in place.
 */
function mergeMaps(target: FieldDestinationMap, source: FieldDestinationMap): void {
  for (const [key, dests] of source) {
    for (const dest of dests) {
      addDestination(target, key, dest);
    }
  }
}

// ────────────────────────────────────────────────────────────────────────────

/**
 * Build a map of field key → output destinations for a single schema.
 *
 * Priority: if a field has a docx tag via `template_key_map`, use that.
 * Only fall back to the Markdown `output_template` heading for fields
 * that don't appear in the key map.
 */
export function buildFieldDestinationMap(schema: DocumentSchema): FieldDestinationMap {
  const map: FieldDestinationMap = new Map();

  // Docx tags take priority — collect the set of fields they cover
  const docxFields = new Set<string>();
  if (schema.template_key_map) {
    const docxMap = parseTemplateKeyMap(schema.template_key_map);
    mergeMaps(map, docxMap);
    for (const key of docxMap.keys()) {
      docxFields.add(key);
    }
  }

  // Only add Markdown heading destinations for fields NOT covered by docx tags
  if (schema.output_template) {
    const mdMap = parseOutputTemplate(schema.output_template);
    for (const [key, dests] of mdMap) {
      if (!docxFields.has(key)) {
        for (const dest of dests) {
          addDestination(map, key, dest);
        }
      }
    }
  }

  return map;
}

/**
 * Build destinations for a set session (multiple schemas merged into one interview).
 * Each destination includes the document title for disambiguation.
 * Docx tags take priority over Markdown headings per-schema.
 */
export function buildSetFieldDestinationMap(schemas: DocumentSchema[]): FieldDestinationMap {
  const map: FieldDestinationMap = new Map();

  for (const schema of schemas) {
    const docxFields = new Set<string>();
    if (schema.template_key_map) {
      const docxMap = parseTemplateKeyMap(schema.template_key_map, schema.title);
      mergeMaps(map, docxMap);
      for (const key of docxMap.keys()) {
        docxFields.add(key);
      }
    }
    if (schema.output_template) {
      const mdMap = parseOutputTemplate(schema.output_template, schema.title);
      for (const [key, dests] of mdMap) {
        if (!docxFields.has(key)) {
          for (const dest of dests) {
            addDestination(map, key, dest);
          }
        }
      }
    }
  }

  return map;
}
