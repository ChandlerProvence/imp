import { describe, it, expect } from "vitest";
import {
  buildFieldDestinationMap,
  buildSetFieldDestinationMap,
} from "./fieldDestinations";
import type { DocumentSchema } from "../schemas/types";

/** Minimal schema helper. */
function makeSchema(overrides: Partial<DocumentSchema> = {}): DocumentSchema {
  return {
    id: "test",
    title: "Test Document",
    version: 1,
    sections: [],
    ...overrides,
  };
}

describe("buildFieldDestinationMap", () => {
  it("maps fields to headings from output_template", () => {
    const schema = makeSchema({
      output_template: [
        "## Parties",
        "**Name:** {{parties.name}}",
        "## Terms",
        "**Duration:** {{terms.duration}}",
      ].join("\n"),
    });

    const map = buildFieldDestinationMap(schema);

    expect(map.get("parties.name")).toEqual([
      { heading: "Parties", source: "markdown", documentTitle: undefined },
    ]);
    expect(map.get("terms.duration")).toEqual([
      { heading: "Terms", source: "markdown", documentTitle: undefined },
    ]);
  });

  it("assigns '(Document root)' when field appears before any heading", () => {
    const schema = makeSchema({
      output_template: "**Title:** {{meta.title}}\n## Body\n{{body.text}}",
    });

    const map = buildFieldDestinationMap(schema);

    expect(map.get("meta.title")?.[0].heading).toBe("(Document root)");
    expect(map.get("body.text")?.[0].heading).toBe("Body");
  });

  it("handles a field appearing under multiple headings", () => {
    const schema = makeSchema({
      output_template: [
        "## Summary",
        "Name: {{parties.name}}",
        "## Signature",
        "Signed by: {{parties.name}}",
      ].join("\n"),
    });

    const map = buildFieldDestinationMap(schema);

    expect(map.get("parties.name")).toHaveLength(2);
    expect(map.get("parties.name")![0].heading).toBe("Summary");
    expect(map.get("parties.name")![1].heading).toBe("Signature");
  });

  it("handles table block syntax {{#key}}", () => {
    const schema = makeSchema({
      output_template: [
        "## Parts List",
        "{{#parts.part_list}}",
        "| {{noun}} | {{nsn}} |",
        "{{/parts.part_list}}",
      ].join("\n"),
    });

    const map = buildFieldDestinationMap(schema);

    expect(map.get("parts.part_list")).toEqual([
      { heading: "Parts List", source: "markdown", documentTitle: undefined },
    ]);
  });

  it("handles template_key_map (docx-only schema)", () => {
    const schema = makeSchema({
      template_key_map: {
        FMS_CASE: "header.fms_case",
        CONTRACTOR: "header.contractor_name",
      },
    });

    const map = buildFieldDestinationMap(schema);

    expect(map.get("header.fms_case")).toEqual([
      { heading: "FMS_CASE", source: "docx", documentTitle: undefined },
    ]);
    expect(map.get("header.contractor_name")).toEqual([
      { heading: "CONTRACTOR", source: "docx", documentTitle: undefined },
    ]);
  });

  it("prefers docx tag over markdown heading when both exist for same field", () => {
    const schema = makeSchema({
      output_template: "## Header\n**Case:** {{header.fms_case}}",
      template_key_map: { FMS_CASE: "header.fms_case" },
    });

    const map = buildFieldDestinationMap(schema);

    // Docx tag wins — markdown heading is not shown
    expect(map.get("header.fms_case")).toHaveLength(1);
    expect(map.get("header.fms_case")![0]).toEqual({
      heading: "FMS_CASE",
      source: "docx",
      documentTitle: undefined,
    });
  });

  it("uses markdown heading for fields not in template_key_map", () => {
    const schema = makeSchema({
      output_template: "## Body\n{{body.text}}\n{{body.notes}}",
      template_key_map: { NOTES: "body.notes" },
    });

    const map = buildFieldDestinationMap(schema);

    // body.text has no docx tag — falls back to markdown heading
    expect(map.get("body.text")).toEqual([
      { heading: "Body", source: "markdown", documentTitle: undefined },
    ]);
    // body.notes has a docx tag — uses that
    expect(map.get("body.notes")).toEqual([
      { heading: "NOTES", source: "docx", documentTitle: undefined },
    ]);
  });

  it("returns empty map for schema with no templates", () => {
    const schema = makeSchema({});
    const map = buildFieldDestinationMap(schema);
    expect(map.size).toBe(0);
  });

  it("field not in any template is not in the map", () => {
    const schema = makeSchema({
      output_template: "## Body\n{{body.text}}",
    });

    const map = buildFieldDestinationMap(schema);

    expect(map.get("other.field")).toBeUndefined();
  });

  it("deduplicates identical destinations", () => {
    // Same heading, same field twice on different lines
    const schema = makeSchema({
      output_template: [
        "## Header",
        "{{parties.name}}",
        "Also: {{parties.name}}",
      ].join("\n"),
    });

    const map = buildFieldDestinationMap(schema);

    // Should not duplicate the same heading+source
    expect(map.get("parties.name")).toHaveLength(1);
  });
});

describe("buildSetFieldDestinationMap", () => {
  it("includes document title for each destination", () => {
    const schemas: DocumentSchema[] = [
      makeSchema({
        id: "doc-a",
        title: "Document A",
        output_template: "## Section One\n{{info.name}}",
      }),
      makeSchema({
        id: "doc-b",
        title: "Document B",
        output_template: "## Header\n{{info.name}}",
      }),
    ];

    const map = buildSetFieldDestinationMap(schemas);

    expect(map.get("info.name")).toHaveLength(2);
    expect(map.get("info.name")![0].documentTitle).toBe("Document A");
    expect(map.get("info.name")![1].documentTitle).toBe("Document B");
  });

  it("handles mix of markdown and docx schemas in a set", () => {
    const schemas: DocumentSchema[] = [
      makeSchema({
        id: "md-doc",
        title: "MD Doc",
        output_template: "## Body\n{{body.text}}",
      }),
      makeSchema({
        id: "docx-doc",
        title: "Word Doc",
        template_key_map: { BODY_TEXT: "body.text" },
      }),
    ];

    const map = buildSetFieldDestinationMap(schemas);

    expect(map.get("body.text")).toHaveLength(2);
    expect(map.get("body.text")![0].source).toBe("markdown");
    expect(map.get("body.text")![1].source).toBe("docx");
  });
});
