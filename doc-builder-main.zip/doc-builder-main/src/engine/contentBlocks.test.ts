import { describe, it, expect } from "vitest";
import type { BlockCondition, DocumentSchema } from "../schemas/types";
import { evaluateBlockCondition, evaluateContentBlocks, getBlockGate } from "./contentBlocks";
import { serializeMultiselectValue } from "./multiselectData";

// ---------------------------------------------------------------------------
// evaluateBlockCondition — one test group per operator
// ---------------------------------------------------------------------------

describe("evaluateBlockCondition", () => {
  describe("contains", () => {
    const c: BlockCondition = { field: "changes.mod_types", contains: "Pricing" };

    it("true when the multiselect includes the value", () => {
      expect(evaluateBlockCondition(c, { "changes.mod_types": serializeMultiselectValue(["SOW", "Pricing"]) })).toBe(true);
    });
    it("false when absent, empty, or unset", () => {
      expect(evaluateBlockCondition(c, { "changes.mod_types": serializeMultiselectValue(["SOW"]) })).toBe(false);
      expect(evaluateBlockCondition(c, { "changes.mod_types": serializeMultiselectValue([]) })).toBe(false);
      expect(evaluateBlockCondition(c, {})).toBe(false);
    });
  });

  describe("equals / not_equals", () => {
    it("equals compares string forms", () => {
      const c: BlockCondition = { field: "header.type", equals: "FFP" };
      expect(evaluateBlockCondition(c, { "header.type": "FFP" })).toBe(true);
      expect(evaluateBlockCondition(c, { "header.type": "T&M" })).toBe(false);
      expect(evaluateBlockCondition(c, {})).toBe(false);
    });
    it("not_equals is the inverse, and missing != value", () => {
      const c: BlockCondition = { field: "header.type", not_equals: "FFP" };
      expect(evaluateBlockCondition(c, { "header.type": "T&M" })).toBe(true);
      expect(evaluateBlockCondition(c, { "header.type": "FFP" })).toBe(false);
      expect(evaluateBlockCondition(c, {})).toBe(true);
    });
  });

  describe("is_truthy", () => {
    const t: BlockCondition = { field: "header.flag", is_truthy: true };
    const f: BlockCondition = { field: "header.flag", is_truthy: false };

    it("treats true / non-empty string / number as truthy", () => {
      expect(evaluateBlockCondition(t, { "header.flag": true })).toBe(true);
      expect(evaluateBlockCondition(t, { "header.flag": "yes" })).toBe(true);
      expect(evaluateBlockCondition(t, { "header.flag": 42 })).toBe(true);
      expect(evaluateBlockCondition(f, { "header.flag": true })).toBe(false);
    });
    it("treats false / empty / missing as falsy", () => {
      expect(evaluateBlockCondition(t, { "header.flag": false })).toBe(false);
      expect(evaluateBlockCondition(t, { "header.flag": "" })).toBe(false);
      expect(evaluateBlockCondition(t, {})).toBe(false);
      expect(evaluateBlockCondition(f, {})).toBe(true);
    });
  });

  describe("gte / lt", () => {
    const gte0: BlockCondition = { field: "pricing.delta", gte: 0 };
    const lt0: BlockCondition = { field: "pricing.delta", lt: 0 };

    it("reads from the computed map first", () => {
      expect(evaluateBlockCondition(gte0, {}, { "pricing.delta": 30000 })).toBe(true);
      expect(evaluateBlockCondition(gte0, {}, { "pricing.delta": 0 })).toBe(true);
      expect(evaluateBlockCondition(gte0, {}, { "pricing.delta": -25000 })).toBe(false);
      expect(evaluateBlockCondition(lt0, {}, { "pricing.delta": -25000 })).toBe(true);
      expect(evaluateBlockCondition(lt0, {}, { "pricing.delta": 5 })).toBe(false);
    });

    it("computed map wins over a stale answer for the same key", () => {
      expect(evaluateBlockCondition(gte0, { "pricing.delta": "999" }, { "pricing.delta": -1 })).toBe(false);
    });

    it("falls back to parsing the answer (numbers and formatted strings)", () => {
      expect(evaluateBlockCondition(gte0, { "pricing.delta": 12 })).toBe(true);
      expect(evaluateBlockCondition(gte0, { "pricing.delta": "1,234.50" })).toBe(true);
      expect(evaluateBlockCondition(gte0, { "pricing.delta": "-1,234.50" })).toBe(false);
    });

    it("null / missing / non-numeric → false for both operators", () => {
      expect(evaluateBlockCondition(gte0, {}, { "pricing.delta": null })).toBe(false);
      expect(evaluateBlockCondition(lt0, {}, { "pricing.delta": null })).toBe(false);
      expect(evaluateBlockCondition(gte0, {})).toBe(false);
      expect(evaluateBlockCondition(gte0, { "pricing.delta": "abc" })).toBe(false);
      expect(evaluateBlockCondition(gte0, { "pricing.delta": true })).toBe(false);
    });
  });

  it("returns false when no recognised operator is set", () => {
    expect(evaluateBlockCondition({ field: "a.b" }, { "a.b": "x" })).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// evaluateContentBlocks
// ---------------------------------------------------------------------------

describe("evaluateContentBlocks", () => {
  const schema = {
    content_blocks: {
      STATIC_ON: true,
      STATIC_OFF: false,
      LABEL: "Straight-to-Repair",
      PRICE_CHANGE: { when: { field: "changes.mod_types", contains: "Pricing" } },
      PRICE_INCREASE: { when: { field: "pricing.delta", gte: 0 } },
    },
    sections: [
      { id: "changes", title: "", fields: [{ id: "mod_types", label: "", type: "multiselect", required: true }] },
      {
        id: "pricing",
        title: "",
        fields: [
          { id: "to", label: "", type: "number", required: true },
          { id: "from", label: "", type: "number", required: true },
          { id: "delta", label: "", type: "number", required: true, formula: "to - from", format: "currency" },
        ],
      },
    ],
  } as unknown as DocumentSchema;

  it("returns {} for schemas without content_blocks", () => {
    expect(evaluateContentBlocks({ sections: [] } as unknown as DocumentSchema, {})).toEqual({});
  });

  it("passes literals through and evaluates conditions", () => {
    const answers = {
      "changes.mod_types": serializeMultiselectValue(["Pricing"]),
      "pricing.to": 150000,
      "pricing.from": 120000,
    };
    expect(evaluateContentBlocks(schema, answers)).toEqual({
      STATIC_ON: true,
      STATIC_OFF: false,
      LABEL: "Straight-to-Repair",
      PRICE_CHANGE: true,
      PRICE_INCREASE: true,
    });
  });

  it("resolves computed fields itself when no computed map is supplied (negative delta)", () => {
    const answers = { "pricing.to": 95000, "pricing.from": 120000 };
    const blocks = evaluateContentBlocks(schema, answers);
    expect(blocks.PRICE_INCREASE).toBe(false);
    expect(blocks.PRICE_CHANGE).toBe(false);
  });

  it("numeric block is false when the computed value is null (inputs missing)", () => {
    expect(evaluateContentBlocks(schema, {}).PRICE_INCREASE).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// getBlockGate
// ---------------------------------------------------------------------------

describe("getBlockGate", () => {
  const schema = {
    content_blocks: {
      PRICE_CHANGE: { when: { field: "changes.mod_types", contains: "Pricing" } },
      PRICE_INCREASE: { when: { field: "pricing.delta", gte: 0 } },
      STATIC: true,
    },
    sections: [],
  } as unknown as DocumentSchema;

  it("returns the multiselect gate for contains blocks", () => {
    expect(getBlockGate(schema, "PRICE_CHANGE")).toEqual({ field: "changes.mod_types", value: "Pricing" });
  });

  it("returns undefined for numeric, literal, or unknown blocks", () => {
    expect(getBlockGate(schema, "PRICE_INCREASE")).toBeUndefined();
    expect(getBlockGate(schema, "STATIC")).toBeUndefined();
    expect(getBlockGate(schema, "NOPE")).toBeUndefined();
  });
});
