import { describe, it, expect } from "vitest";
import {
  buildFieldLinkMap,
  getTransitiveFollowers,
  healLinkedAnswers,
  isSectionFullyLinked,
} from "./fieldLinks";
import type { DocumentSchema } from "../schemas/types";

/** Helper to build a minimal schema with same_as links. */
function makeSchema(
  sections: {
    id: string;
    fields: { id: string; same_as?: string }[];
  }[],
): DocumentSchema {
  return {
    id: "test",
    title: "Test",
    version: 1,
    sections: sections.map((s) => ({
      id: s.id,
      title: s.id,
      fields: s.fields.map((f) => ({
        id: f.id,
        label: f.id,
        type: "string" as const,
        required: false,
        same_as: f.same_as,
      })),
    })),
  };
}

// ---------------------------------------------------------------------------
// buildFieldLinkMap
// ---------------------------------------------------------------------------

describe("buildFieldLinkMap", () => {
  it("returns empty maps when schema has no links", () => {
    const schema = makeSchema([
      { id: "s1", fields: [{ id: "a" }, { id: "b" }] },
    ]);
    const map = buildFieldLinkMap(schema);
    expect(map.followers.size).toBe(0);
    expect(map.sourceOf.size).toBe(0);
  });

  it("creates follower and source entries for a single link", () => {
    const schema = makeSchema([
      { id: "s1", fields: [{ id: "name" }] },
      { id: "s2", fields: [{ id: "name", same_as: "s1.name" }] },
    ]);
    const map = buildFieldLinkMap(schema);
    expect(map.followers.get("s1.name")).toEqual(["s2.name"]);
    expect(map.sourceOf.get("s2.name")).toBe("s1.name");
  });

  it("handles fan-out (A → B, A → C)", () => {
    const schema = makeSchema([
      { id: "s1", fields: [{ id: "x" }] },
      { id: "s2", fields: [{ id: "x", same_as: "s1.x" }] },
      { id: "s3", fields: [{ id: "x", same_as: "s1.x" }] },
    ]);
    const map = buildFieldLinkMap(schema);
    expect(map.followers.get("s1.x")).toEqual(["s2.x", "s3.x"]);
  });

  it("handles chain (A → B → C)", () => {
    const schema = makeSchema([
      { id: "s1", fields: [{ id: "v" }] },
      { id: "s2", fields: [{ id: "v", same_as: "s1.v" }] },
      { id: "s3", fields: [{ id: "v", same_as: "s2.v" }] },
    ]);
    const map = buildFieldLinkMap(schema);
    expect(map.followers.get("s1.v")).toEqual(["s2.v"]);
    expect(map.followers.get("s2.v")).toEqual(["s3.v"]);
    expect(map.sourceOf.get("s3.v")).toBe("s2.v");
  });
});

// ---------------------------------------------------------------------------
// getTransitiveFollowers
// ---------------------------------------------------------------------------

describe("getTransitiveFollowers", () => {
  it("returns empty array when no followers", () => {
    const schema = makeSchema([
      { id: "s1", fields: [{ id: "a" }] },
    ]);
    const map = buildFieldLinkMap(schema);
    expect(getTransitiveFollowers("s1.a", map)).toEqual([]);
  });

  it("returns direct followers", () => {
    const schema = makeSchema([
      { id: "s1", fields: [{ id: "a" }] },
      { id: "s2", fields: [{ id: "a", same_as: "s1.a" }] },
    ]);
    const map = buildFieldLinkMap(schema);
    expect(getTransitiveFollowers("s1.a", map)).toEqual(["s2.a"]);
  });

  it("returns transitive followers through chain", () => {
    const schema = makeSchema([
      { id: "s1", fields: [{ id: "v" }] },
      { id: "s2", fields: [{ id: "v", same_as: "s1.v" }] },
      { id: "s3", fields: [{ id: "v", same_as: "s2.v" }] },
    ]);
    const map = buildFieldLinkMap(schema);
    const result = getTransitiveFollowers("s1.v", map);
    expect(result).toContain("s2.v");
    expect(result).toContain("s3.v");
  });

  it("handles fan-out correctly", () => {
    const schema = makeSchema([
      { id: "s1", fields: [{ id: "x" }] },
      { id: "s2", fields: [{ id: "x", same_as: "s1.x" }] },
      { id: "s3", fields: [{ id: "x", same_as: "s1.x" }] },
    ]);
    const map = buildFieldLinkMap(schema);
    const result = getTransitiveFollowers("s1.x", map);
    expect(result).toHaveLength(2);
    expect(result).toContain("s2.x");
    expect(result).toContain("s3.x");
  });

  it("does not infinite-loop on cycles", () => {
    // Manually construct a cycle (schema validation would prevent this, but test defensively)
    const schema = makeSchema([
      { id: "s1", fields: [{ id: "a", same_as: "s2.a" }] },
      { id: "s2", fields: [{ id: "a", same_as: "s1.a" }] },
    ]);
    const map = buildFieldLinkMap(schema);
    // Should terminate without infinite loop
    const result = getTransitiveFollowers("s1.a", map);
    expect(result).toBeDefined();
  });
});

// ---------------------------------------------------------------------------
// healLinkedAnswers
// ---------------------------------------------------------------------------

describe("healLinkedAnswers", () => {
  const schema = makeSchema([
    { id: "s1", fields: [{ id: "name" }] },
    { id: "s2", fields: [{ id: "name", same_as: "s1.name" }] },
  ]);
  const map = buildFieldLinkMap(schema);

  it("syncs follower to source value", () => {
    const answers = { "s1.name": "Alice", "s2.name": "old" };
    const result = healLinkedAnswers(answers, map);
    expect(result["s2.name"]).toBe("Alice");
  });

  it("deletes follower when source is undefined", () => {
    const answers = { "s2.name": "orphan" } as Record<
      string,
      string | number | boolean
    >;
    const result = healLinkedAnswers(answers, map);
    expect("s2.name" in result).toBe(false);
  });

  it("returns same reference when no changes needed", () => {
    const answers = { "s1.name": "Alice", "s2.name": "Alice" };
    const result = healLinkedAnswers(answers, map);
    expect(result).toBe(answers); // same reference
  });

  it("does not modify original object", () => {
    const answers = { "s1.name": "New", "s2.name": "Old" };
    const result = healLinkedAnswers(answers, map);
    expect(answers["s2.name"]).toBe("Old"); // original unchanged
    expect(result["s2.name"]).toBe("New");
  });
});

// ---------------------------------------------------------------------------
// isSectionFullyLinked
// ---------------------------------------------------------------------------

describe("isSectionFullyLinked", () => {
  it("returns true when all fields have same_as", () => {
    const section = {
      fields: [{ same_as: "s1.a" }, { same_as: "s1.b" }],
    };
    expect(isSectionFullyLinked(section)).toBe(true);
  });

  it("returns false when some fields lack same_as", () => {
    const section = {
      fields: [{ same_as: "s1.a" }, {}],
    };
    expect(isSectionFullyLinked(section)).toBe(false);
  });

  it("returns false for empty fields array", () => {
    const section = { fields: [] as { same_as?: string }[] };
    expect(isSectionFullyLinked(section)).toBe(false);
  });
});
