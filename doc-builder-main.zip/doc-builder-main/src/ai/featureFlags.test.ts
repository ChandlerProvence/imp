import { describe, it, expect, vi, beforeEach } from "vitest";

const STORAGE_KEY = "doc-builder:ai-feature-flags";

// Session overrides are module state, so each test gets a fresh module.
async function load() {
  vi.resetModules();
  return import("./featureFlags");
}

describe("featureFlags", () => {
  beforeEach(() => {
    localStorage.clear();
    vi.spyOn(console, "warn").mockImplementation(() => {});
  });

  it("falls back to defaults when the stored value is corrupt", async () => {
    localStorage.setItem(STORAGE_KEY, "{not json");
    const { getFeatureFlags, isFeatureEnabled } = await load();
    expect(() => getFeatureFlags()).not.toThrow();
    expect(isFeatureEnabled("thinking")).toBe(true);
  });

  it("applies session auto-disables without persisting them", async () => {
    const { disableFeatureForSession, setFeatureFlags, isFeatureEnabled } = await load();
    disableFeatureForSession("thinking");
    expect(isFeatureEnabled("thinking")).toBe(false);

    setFeatureFlags({ effort: false });

    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY)!);
    expect(stored.effort).toBe(false);
    expect(stored.thinking).toBe(true);
  });

  it("keeps AskSage off by default until it is turned on explicitly", async () => {
    const { isFeatureEnabled, setFeatureFlags } = await load();
    expect(isFeatureEnabled("askSage")).toBe(false);
    setFeatureFlags({ askSage: true });
    expect(isFeatureEnabled("askSage")).toBe(true);
  });
});
