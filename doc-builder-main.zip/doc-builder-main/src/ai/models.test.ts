import { describe, it, expect, beforeEach } from "vitest";
import { ENDPOINTS } from "./endpoints";
import {
  DISCOVERED_MODELS_KEY,
  MODEL_OVERRIDES_KEY,
  _resetModelsForTests,
  classifyModel,
  kindMismatch,
  modelsForRole,
  getModelInfo,
  getModelOverrides,
  getModelResolution,
  markModelUnavailable,
  newerModelFor,
  pickSubstitute,
  resolveModel,
  resolveRole,
  setDiscoveredModels,
  setModelOverride,
  subscribeModels,
} from "./models";

const IL2 = ENDPOINTS["non-cui"];
const IL5 = ENDPOINTS.cui;

beforeEach(() => {
  _resetModelsForTests();
});

describe("classifyModel", () => {
  // Real IDs from the IL2 proxy's /v1/models
  it.each([
    ["text-embedding-3-large-azure-comm-il2", "embedding"],
    ["titan-embed-text-v2-aws-comm-il2", "embedding"],
    ["nova-2-multimodal-embeddings-aws-comm-il2", "embedding"],
    ["gpt-image-2-azure-comm-il2", "other"],
    ["gpt-realtime-1-5-azure-comm-il2", "other"],
    ["claude-sonnet-5-5-aws-comm-il2", "chat"],
    ["gpt-5-6-luna-aws-comm-il2", "chat"],
    ["nova-pro-aws-comm-il2", "chat"],
  ] as const)("%s → %s", (id, kind) => {
    expect(classifyModel(id)).toBe(kind);
  });

  it("filters IDs to the type a role needs", () => {
    const ids = ["claude-4-6-opus-aws-comm-il2", "text-embedding-3-small-azure-comm-il2", "gpt-image-2-azure-comm-il2"];
    expect(modelsForRole("advanced", ids)).toEqual(["claude-4-6-opus-aws-comm-il2"]);
    expect(modelsForRole("embedding", ids)).toEqual(["text-embedding-3-small-azure-comm-il2"]);
  });

  it("reports a type mismatch", () => {
    expect(kindMismatch("standard", "text-embedding-3-small-azure-comm-il2")).toBe("embedding");
    expect(kindMismatch("embedding", "claude-4-6-sonnet-aws-comm-il2")).toBe("chat");
    expect(kindMismatch("standard", "claude-4-6-sonnet-aws-comm-il2")).toBeNull();
  });
});

describe("pickSubstitute", () => {
  const configured = "claude-4-6-sonnet-aws-comm-il2";

  it("prefers the same deployment suffix over a higher version elsewhere", () => {
    const ids = ["claude-5-0-sonnet-aws-gov-il5", "claude-4-7-sonnet-aws-comm-il2"];
    expect(pickSubstitute("standard", configured, ids)).toBe("claude-4-7-sonnet-aws-comm-il2");
  });

  it("picks the highest version within the same deployment", () => {
    const ids = ["claude-4-7-sonnet-aws-comm-il2", "claude-4-9-sonnet-aws-comm-il2", "claude-4-8-sonnet-aws-comm-il2"];
    expect(pickSubstitute("standard", configured, ids)).toBe("claude-4-9-sonnet-aws-comm-il2");
  });

  it("only considers the same family", () => {
    expect(pickSubstitute("standard", configured, ["claude-4-9-opus-aws-comm-il2"])).toBeUndefined();
  });

  it("never offers a chat model as an embedding substitute", () => {
    const ids = ["claude-4-9-sonnet-aws-comm-il2", "titan-embed-text-v2-aws-comm-il2"];
    expect(pickSubstitute("embedding", "text-embedding-3-small-azure-comm-il2", ids)).toBe(
      "titan-embed-text-v2-aws-comm-il2",
    );
    expect(pickSubstitute("embedding", "text-embedding-3-small-azure-comm-il2", ["gpt-5-4-azure-comm-il2"])).toBeUndefined();
  });

  it("skips the configured ID and excluded IDs", () => {
    const ids = [configured, "claude-4-7-sonnet-aws-comm-il2"];
    expect(pickSubstitute("standard", configured, ids, new Set(["claude-4-7-sonnet-aws-comm-il2"]))).toBeUndefined();
  });

  describe("family-first IDs", () => {
    const current = "claude-opus-5-5-aws-comm-il2";

    it("ranks by version within the deployment, not by shared version digits", () => {
      const ids = ["claude-opus-4-5-aws-comm-il2", "claude-opus-6-0-aws-comm-il2"];
      expect(pickSubstitute("advanced", current, ids)).toBe("claude-opus-6-0-aws-comm-il2");
    });

    it("prefers the same deployment over a higher version elsewhere", () => {
      const ids = ["claude-opus-6-0-aws-gov-il5", "claude-opus-5-6-aws-comm-il2"];
      expect(pickSubstitute("advanced", current, ids)).toBe("claude-opus-5-6-aws-comm-il2");
    });

    it("keeps to the configured family, not the role name", () => {
      const ids = ["claude-sonnet-5-9-aws-comm-il2", "claude-haiku-5-9-aws-comm-il2"];
      expect(pickSubstitute("advanced", current, ids)).toBeUndefined();
      expect(pickSubstitute("light", "claude-haiku-5-5-aws-comm-il2", ids)).toBe("claude-haiku-5-9-aws-comm-il2");
    });

    it("works for non-Claude IDs", () => {
      const ids = ["gpt-5-6-luna-aws-comm-il2", "gpt-5-6-aws-comm-il2"];
      expect(pickSubstitute("light", "gpt-5-4-luna-aws-comm-il2", ids)).toBe("gpt-5-6-luna-aws-comm-il2");
    });
  });
});

describe("resolveRole", () => {
  const NEWER_STANDARD = "claude-sonnet-5-9-aws-comm-il2";
  const OLDER_STANDARD = "claude-sonnet-5-1-aws-comm-il2";

  it("uses the configured default when nothing has been discovered", () => {
    expect(resolveRole("non-cui", "standard")).toEqual({
      role: "standard",
      id: IL2.models.standard,
      source: "default",
      configured: IL2.models.standard,
    });
  });

  it("keeps the default pinned while the proxy still lists it, even if newer exists", () => {
    setDiscoveredModels("non-cui", [IL2.models.standard, NEWER_STANDARD]);
    expect(resolveModel("non-cui", "standard")).toBe(IL2.models.standard);
  });

  it("substitutes when the default is missing from the discovered list", () => {
    setDiscoveredModels("non-cui", [OLDER_STANDARD]);
    const r = resolveRole("non-cui", "standard");
    expect(r.source).toBe("substituted");
    expect(r.id).toBe(OLDER_STANDARD);
  });

  it("reports missing when no substitute exists", () => {
    setDiscoveredModels("non-cui", ["something-else"]);
    expect(resolveRole("non-cui", "advanced").source).toBe("missing");
    expect(resolveModel("non-cui", "advanced")).toBe(IL2.models.advanced);
  });

  it("an override wins over default and substitution", () => {
    setDiscoveredModels("non-cui", [OLDER_STANDARD]);
    setModelOverride("non-cui", "standard", "my-model");
    expect(resolveRole("non-cui", "standard").source).toBe("override");
    expect(resolveModel("non-cui", "standard")).toBe("my-model");
    expect(resolveRole("non-cui", "standard", { ignoreOverride: true }).source).toBe("substituted");
  });

  it("clearing an override restores the default", () => {
    setModelOverride("non-cui", "advanced", "x");
    setModelOverride("non-cui", "advanced", null);
    expect(resolveModel("non-cui", "advanced")).toBe(IL2.models.advanced);
  });

  it("markModelUnavailable forces a substitute before the next discovery", () => {
    setDiscoveredModels("non-cui", [IL2.models.standard, OLDER_STANDARD]);
    markModelUnavailable("non-cui", IL2.models.standard);
    expect(resolveModel("non-cui", "standard")).toBe(OLDER_STANDARD);
    // A fresh discovery supersedes the session mark
    setDiscoveredModels("non-cui", [IL2.models.standard]);
    expect(resolveModel("non-cui", "standard")).toBe(IL2.models.standard);
  });

  it("light resolves to its configured default on both endpoints", () => {
    expect(resolveModel("non-cui", "light")).toBe(IL2.models.light);
    expect(resolveModel("cui", "light")).toBe(IL5.models.light);
  });

  it("covers every role on every endpoint", () => {
    const roles = ["standard", "advanced", "light", "embedding"];
    expect(getModelResolution("non-cui").map((r) => r.role)).toEqual(roles);
    expect(getModelResolution("cui").map((r) => r.role)).toEqual(roles);
  });

  it("treats malformed storage as empty", () => {
    localStorage.setItem(MODEL_OVERRIDES_KEY, "{not json");
    localStorage.setItem(DISCOVERED_MODELS_KEY, "[1,2]");
    expect(resolveRole("non-cui", "standard").source).toBe("default");
  });
});

describe("legacy override migration", () => {
  it("renames sonnet/opus/luna overrides to standard/advanced/light", () => {
    localStorage.setItem(
      MODEL_OVERRIDES_KEY,
      JSON.stringify({ "non-cui": { sonnet: "s", opus: "o" }, cui: { luna: "l", embedding: "e" } }),
    );
    expect(getModelOverrides("non-cui")).toEqual({ standard: "s", advanced: "o" });
    expect(getModelOverrides("cui")).toEqual({ light: "l", embedding: "e" });
    expect(JSON.parse(localStorage.getItem(MODEL_OVERRIDES_KEY)!)).toEqual({
      "non-cui": { standard: "s", advanced: "o" },
      cui: { light: "l", embedding: "e" },
    });
  });

  it("keeps the new key when both are present", () => {
    localStorage.setItem(MODEL_OVERRIDES_KEY, JSON.stringify({ "non-cui": { sonnet: "old", standard: "new" } }));
    expect(getModelOverrides("non-cui")).toEqual({ standard: "new" });
  });
});

describe("newerModelFor", () => {
  it("suggests a newer same-deployment model without applying it", () => {
    setDiscoveredModels("non-cui", [IL2.models.standard, "claude-sonnet-5-9-aws-comm-il2"]);
    expect(newerModelFor("non-cui", "standard")).toBe("claude-sonnet-5-9-aws-comm-il2");
    expect(resolveModel("non-cui", "standard")).toBe(IL2.models.standard);
  });

  it("does not suggest models from another deployment or older versions", () => {
    setDiscoveredModels("non-cui", [IL2.models.standard, "claude-sonnet-6-0-aws-gov-il5", "claude-sonnet-5-1-aws-comm-il2"]);
    expect(newerModelFor("non-cui", "standard")).toBeUndefined();
  });

  it("returns undefined before discovery", () => {
    expect(newerModelFor("non-cui", "standard")).toBeUndefined();
  });
});

describe("model info cache", () => {
  it("keeps previous info when a refresh omits it", () => {
    setDiscoveredModels("non-cui", ["a"], { a: { inputCostPerMTok: 3, outputCostPerMTok: 15 } });
    setDiscoveredModels("non-cui", ["a", "b"]);
    expect(getModelInfo("non-cui", "a")).toEqual({ inputCostPerMTok: 3, outputCostPerMTok: 15 });
  });
});

describe("subscribeModels", () => {
  it("notifies on override, discovery, and unavailability changes", () => {
    let calls = 0;
    const unsub = subscribeModels(() => calls++);
    setModelOverride("non-cui", "standard", "x");
    setDiscoveredModels("non-cui", ["x"]);
    markModelUnavailable("non-cui", "x");
    markModelUnavailable("non-cui", "x"); // no-op when already marked
    unsub();
    setModelOverride("non-cui", "standard", null);
    expect(calls).toBe(3);
  });
});
