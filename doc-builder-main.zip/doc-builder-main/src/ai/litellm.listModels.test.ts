import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { discoverModels, fetchModelInfo, listModels, testApiKey } from "./litellm";
import { _resetModelsForTests, getDiscoveredModels, getModelInfo } from "./models";
import { jsonResponse, routeFetch } from "../test/fetchMocks";

const MODELS = { data: [{ id: "claude-a" }, { id: "claude-b" }] };
const INFO = {
  data: [
    {
      model_name: "claude-a",
      model_info: { input_cost_per_token: 0.000003, output_cost_per_token: 0.000015, max_input_tokens: 200000 },
    },
    { model_name: "claude-b", model_info: {} },
  ],
};

beforeEach(() => {
  _resetModelsForTests();
});

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("listModels", () => {
  it("returns data[].id", async () => {
    routeFetch({ "/v1/models": () => jsonResponse(MODELS) });
    expect(await listModels("non-cui", "k")).toEqual({ ok: true, ids: ["claude-a", "claude-b"] });
  });

  it("maps 401 to ai.auth", async () => {
    routeFetch({ "/v1/models": () => jsonResponse({ error: "bad key" }, 401) });
    const res = await listModels("non-cui", "k");
    expect(res.ok).toBe(false);
    if (!res.ok) expect(res.error.kind).toBe("ai.auth");
  });

  it("rejects a body without data[]", async () => {
    routeFetch({ "/v1/models": () => jsonResponse({ nope: true }) });
    const res = await listModels("non-cui", "k");
    expect(res.ok).toBe(false);
    if (!res.ok) expect(res.error.kind).toBe("ai.bad-response");
  });
});

describe("fetchModelInfo", () => {
  it("converts per-token costs to per-1M-token and keeps only models with data", async () => {
    routeFetch({ "/model/info": () => jsonResponse(INFO) });
    const info = await fetchModelInfo("non-cui", "k");
    expect(info).toEqual({
      "claude-a": { inputCostPerMTok: 3, outputCostPerMTok: 15, maxInputTokens: 200000 },
    });
  });

  it("returns null when the proxy forbids it", async () => {
    routeFetch({ "/model/info": () => jsonResponse({ error: "admin only" }, 403) });
    expect(await fetchModelInfo("non-cui", "k")).toBeNull();
  });
});

describe("discoverModels / testApiKey", () => {
  it("caches the list and info", async () => {
    routeFetch({ "/v1/models": () => jsonResponse(MODELS), "/model/info": () => jsonResponse(INFO) });
    await discoverModels("non-cui", "k");
    expect(getDiscoveredModels("non-cui")).toEqual(["claude-a", "claude-b"]);
    expect(getModelInfo("non-cui", "claude-a")?.inputCostPerMTok).toBe(3);
  });

  it("still succeeds when /model/info fails", async () => {
    routeFetch({ "/v1/models": () => jsonResponse(MODELS), "/model/info": () => jsonResponse({}, 403) });
    const res = await testApiKey("non-cui", "k");
    expect(res.ok).toBe(true);
    expect(getDiscoveredModels("non-cui")).toEqual(["claude-a", "claude-b"]);
  });

  it("leaves the cache untouched when listing fails", async () => {
    routeFetch({ "/v1/models": () => jsonResponse(MODELS) });
    await discoverModels("non-cui", "k");
    routeFetch({ "/v1/models": () => jsonResponse({}, 500) });
    const res = await testApiKey("non-cui", "k");
    expect(res.ok).toBe(false);
    expect(getDiscoveredModels("non-cui")).toEqual(["claude-a", "claude-b"]);
  });

  it("reports a network failure as ai.network", async () => {
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new TypeError("Failed to fetch")));
    const res = await testApiKey("non-cui", "k");
    expect(res.error?.kind).toBe("ai.network");
  });
});
