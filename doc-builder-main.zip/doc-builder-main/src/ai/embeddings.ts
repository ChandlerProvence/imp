import { getApiKey } from "./litellm";
import { getActiveEndpointId, getResolvedBaseUrl } from "./endpoints";
import { markModelUnavailable, resolveModel } from "./models";
import { appErrorException, classifyHttpStatus, toAppErrorException } from "../errors";
import {
  getCachedChunkMeta,
  getChunksForDoc,
  storeChunks,
  deleteChunksForDoc,
} from "../db/embeddings";
import type { EmbeddingChunkRecord } from "../db/types";
import { sha256Hex } from "../utils/sha256";

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/** Below this char count, docs are stuffed directly into the prompt. */
export const SMALL_DOC_THRESHOLD = 10_000;

/** Target chunk size in characters. */
const CHUNK_SIZE = 800;

/** Overlap between consecutive chunks in characters. */
const CHUNK_OVERLAP = 200;

/** Number of top-scoring chunks to retrieve per query. */
const TOP_K = 10;

/** Max chunks per embedding API call. Keep modest to avoid Azure payload limits. */
const EMBEDDING_BATCH_SIZE = 50;

/** Timeout for a single embedding batch request (ms). */
const EMBEDDING_TIMEOUT_MS = 60_000;

/** Max retries for transient (5xx / timeout) errors. */
const EMBEDDING_MAX_RETRIES = 2;

/** Delay before retry (ms). */
const EMBEDDING_RETRY_DELAY_MS = 3_000;

/** Max concurrent HTTP requests to the /v1/embeddings endpoint.
 *  Caps parallel load across all documents to avoid overwhelming the proxy. */
const MAX_CONCURRENT_EMBEDDING_REQUESTS = 4;

// ---------------------------------------------------------------------------
// Embedding request concurrency gate
// ---------------------------------------------------------------------------

let inflight = 0;
const waiters: (() => void)[] = [];

function acquireSlot(): Promise<void> {
  if (inflight < MAX_CONCURRENT_EMBEDDING_REQUESTS) {
    inflight++;
    return Promise.resolve();
  }
  return new Promise<void>((resolve) => {
    waiters.push(() => {
      inflight++;
      resolve();
    });
  });
}

function releaseSlot(): void {
  inflight--;
  const next = waiters.shift();
  if (next) next();
}

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface TextChunk {
  text: string;
  docId: string;
  docTitle: string;
  index: number;
}

export interface EmbeddedChunk extends TextChunk {
  embedding: number[];
}

// ---------------------------------------------------------------------------
// Chunking
// ---------------------------------------------------------------------------

/**
 * Chunk a document into overlapping segments using paragraph boundaries.
 * Preserves semantic coherence by splitting on \n\n first, then falls back
 * to single-newline splits for long blocks (e.g. markdown tables from Excel).
 */
export function chunkText(text: string, docId: string, docTitle: string): TextChunk[] {
  // Split on double-newlines first; within each block, split on single newlines
  // if the block still exceeds chunk size (handles markdown tables from Excel).
  const blocks = text.split(/\n\n+/);
  const segments: string[] = [];
  for (const block of blocks) {
    const trimmed = block.trim();
    if (!trimmed) continue;
    if (trimmed.length <= CHUNK_SIZE) {
      segments.push(trimmed);
    } else {
      // Break large blocks on single newlines (table rows, long lists)
      const lines = trimmed.split(/\n/);
      for (const line of lines) {
        if (line.trim()) segments.push(line.trim());
      }
    }
  }

  const chunks: TextChunk[] = [];
  let current = "";
  let chunkIndex = 0;

  for (const segment of segments) {
    // If adding this segment exceeds chunk size, flush first
    if (current.length > 0 && current.length + segment.length + 1 > CHUNK_SIZE) {
      chunks.push({ text: current.trim(), docId, docTitle, index: chunkIndex++ });

      // Start next chunk with overlap from the end of the current chunk
      const overlapStart = Math.max(0, current.length - CHUNK_OVERLAP);
      current = current.slice(overlapStart).trim() + "\n" + segment;
    } else {
      current = current ? current + "\n" + segment : segment;
    }

    // Safety: if a single segment is enormous (wider than CHUNK_SIZE), force-flush
    if (current.length > CHUNK_SIZE) {
      chunks.push({ text: current.trim(), docId, docTitle, index: chunkIndex++ });
      const overlapStart = Math.max(0, current.length - CHUNK_OVERLAP);
      current = current.slice(overlapStart).trim();
    }
  }

  // Flush remaining content
  if (current.trim()) {
    chunks.push({ text: current.trim(), docId, docTitle, index: chunkIndex });
  }

  return chunks;
}

// ---------------------------------------------------------------------------
// Embedding API
// ---------------------------------------------------------------------------

/**
 * Call the embeddings endpoint for a batch of texts.
 * Returns one float[] vector per input text.
 *
 * Each batch request has a 30s timeout and retries once on transient errors
 * (5xx, network failure, timeout). Non-retryable errors (401, 429) throw immediately.
 */
export async function createEmbeddings(
  texts: string[],
  onBatchProgress?: (done: number, total: number) => void,
): Promise<number[][]> {
  const apiKey = getApiKey();
  if (!apiKey) {
    throw appErrorException("ai.no-key");
  }

  const results: number[][] = [];

  // Process in batches
  for (let i = 0; i < texts.length; i += EMBEDDING_BATCH_SIZE) {
    const batch = texts.slice(i, i + EMBEDDING_BATCH_SIZE);
    const embeddings = await fetchEmbeddingBatchWithRetry(batch, apiKey);

    // Sort by index to maintain input order
    embeddings.sort((a, b) => a.index - b.index);
    for (const item of embeddings) {
      results.push(item.embedding);
    }

    onBatchProgress?.(results.length, texts.length);
  }

  return results;
}

/** Fetch a single batch with timeout and retry for transient errors.
 *  Acquires a concurrency slot before hitting the network so at most
 *  MAX_CONCURRENT_EMBEDDING_REQUESTS are in flight at once. */
async function fetchEmbeddingBatchWithRetry(
  batch: string[],
  apiKey: string,
): Promise<{ embedding: number[]; index: number }[]> {
  await acquireSlot();
  try {
    return await fetchEmbeddingBatchCore(batch, apiKey);
  } finally {
    releaseSlot();
  }
}

/** Core fetch+retry logic, called while holding a concurrency slot. */
async function fetchEmbeddingBatchCore(
  batch: string[],
  apiKey: string,
): Promise<{ embedding: number[]; index: number }[]> {
  let lastError: Error | null = null;

  for (let attempt = 0; attempt <= EMBEDDING_MAX_RETRIES; attempt++) {
    if (attempt > 0) {
      await new Promise((r) => setTimeout(r, EMBEDDING_RETRY_DELAY_MS));
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), EMBEDDING_TIMEOUT_MS);

    try {
      const baseUrl = getResolvedBaseUrl();
      const embeddingModel = resolveModel(getActiveEndpointId(), "embedding");
      const response = await fetch(`${baseUrl}/v1/embeddings`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: embeddingModel,
          input: batch,
        }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const status = response.status;
        // Extract server error detail for diagnostics and classification
        let detail = "";
        try {
          const errBody = await response.text();
          try {
            const parsed = JSON.parse(errBody);
            detail = parsed?.error?.message || parsed?.message || errBody.slice(0, 200);
          } catch {
            detail = errBody.slice(0, 200);
          }
        } catch {
          // ignore body read failures
        }
        const kind = classifyHttpStatus(status, detail);
        if (kind === "ai.model-unavailable") markModelUnavailable(getActiveEndpointId(), embeddingModel);
        throw appErrorException(kind, {
          context: { model: embeddingModel },
          detail: `Embedding request failed (HTTP ${status})${detail ? `: ${detail}` : ""}`,
        });
      }

      const data = await response.json();
      return data.data as { embedding: number[]; index: number }[];
    } catch (err) {
      clearTimeout(timeoutId);

      // Our own timeout abort → retryable timeout
      const mapped = err instanceof DOMException && err.name === "AbortError"
        ? appErrorException("ai.timeout", {
            context: { seconds: String(Math.round(EMBEDDING_TIMEOUT_MS / 1000)) },
            detail: "Embedding request timed out",
          })
        : toAppErrorException(err, { domain: "ai" });

      // Non-retryable (auth, bad request, rate limit) — rethrow immediately.
      // A missing model is also rethrown: switching models mid-document would
      // mix incompatible vectors; the next embed call uses the substitute.
      if (
        !mapped.appError.retryable ||
        mapped.appError.kind === "ai.rate-limit" ||
        mapped.appError.kind === "ai.model-unavailable"
      ) throw mapped;
      lastError = mapped;
    }
  }

  throw lastError!;
}

// ---------------------------------------------------------------------------
// Vector Similarity
// ---------------------------------------------------------------------------

/** Cosine similarity between two vectors. Returns value in [-1, 1]. */
export function cosineSimilarity(a: number[], b: number[]): number {
  let dot = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  const denom = Math.sqrt(normA) * Math.sqrt(normB);
  return denom === 0 ? 0 : dot / denom;
}

// ---------------------------------------------------------------------------
// Retrieval
// ---------------------------------------------------------------------------

/**
 * Retrieve the top-K most relevant chunks for a query.
 * Embeds the query, computes cosine similarity against all chunks, returns top matches.
 */
export async function retrieveRelevantChunks(
  query: string,
  chunks: EmbeddedChunk[],
  topK: number = TOP_K,
): Promise<EmbeddedChunk[]> {
  if (chunks.length === 0) return [];

  // Embed the query
  const [queryEmbedding] = await createEmbeddings([query]);

  // Score all chunks
  const scored = chunks.map((chunk) => ({
    chunk,
    score: cosineSimilarity(queryEmbedding, chunk.embedding),
  }));

  // Sort by descending similarity and take top-K
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, topK).map((s) => s.chunk);
}

// ---------------------------------------------------------------------------
// Hashing (for cache invalidation)
// ---------------------------------------------------------------------------

/**
 * SHA-256 hex of the UTF-8 text, for cache invalidation: any edit anywhere in
 * the document changes the hash and forces a re-embed.
 */
export function computeSourceHash(text: string): Promise<string> {
  return sha256Hex(new TextEncoder().encode(text));
}

// ---------------------------------------------------------------------------
// Embed & Store Pipeline
// ---------------------------------------------------------------------------

export interface EmbedDocumentOptions {
  /** Unique document ID (used as cache key in IndexedDB). */
  docId: string;
  /** Human-readable document title for chunk metadata. */
  docTitle: string;
  /** Full text content of the document. */
  text: string;
  /** Optional progress callback (e.g., "Chunking…", "Embedding 50/120 chunks…"). */
  onProgress?: (message: string) => void;
}

/** Format the per-batch progress message emitted during embedding. */
function formatEmbeddingProgress(done: number, total: number): string {
  return `Embedding ${done}/${total} chunks…`;
}

/**
 * Parse a progress message produced by `embedAndStoreDocument` into a 0–1
 * fraction, or `null` for indeterminate phases ("Chunking…", etc.).
 * Lets UI consumers render a determinate indicator without changing the
 * string-based progress plumbing.
 */
export function parseEmbeddingProgress(message: string | undefined): number | null {
  const m = message?.match(/^Embedding (\d+)\/(\d+) chunks/);
  if (!m) return null;
  const total = Number(m[2]);
  return total > 0 ? Number(m[1]) / total : null;
}

/**
 * Chunk, embed, and store a document in IndexedDB with cache invalidation.
 *
 * If the document's source hash matches the cached version, chunks are
 * loaded from the cache instead of re-embedding. Returns the embedded chunks.
 */
export async function embedAndStoreDocument({
  docId,
  docTitle,
  text,
  onProgress,
}: EmbedDocumentOptions): Promise<EmbeddedChunk[]> {
  onProgress?.("Chunking…");

  const sourceHash = await computeSourceHash(text);
  const cachedMeta = await getCachedChunkMeta(docId);
  const activeModel = resolveModel(getActiveEndpointId(), "embedding");

  if (cachedMeta?.sourceHash === sourceHash && cachedMeta.model === activeModel) {
    const cached = await getChunksForDoc(docId);
    return cached.map((c) => ({
      text: c.text,
      docId: c.docId,
      docTitle,
      index: c.index,
      embedding: c.embedding,
    }));
  }

  const chunks = chunkText(text, docId, docTitle);
  onProgress?.(formatEmbeddingProgress(0, chunks.length));

  const embeddings = await createEmbeddings(
    chunks.map((c) => c.text),
    (done, total) => onProgress?.(formatEmbeddingProgress(done, total)),
  );
  const embedded: EmbeddedChunk[] = chunks.map((c, i) => ({ ...c, embedding: embeddings[i] }));

  const records: EmbeddingChunkRecord[] = embedded.map((c) => ({
    id: crypto.randomUUID(),
    docId: c.docId,
    index: c.index,
    text: c.text,
    embedding: c.embedding,
    sourceHash,
    model: activeModel,
    createdAt: new Date().toISOString(),
  }));

  await deleteChunksForDoc(docId);
  await storeChunks(records);

  return embedded;
}
