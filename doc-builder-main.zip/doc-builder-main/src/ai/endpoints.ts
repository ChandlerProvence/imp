// ---------------------------------------------------------------------------
// AI Endpoint Configuration
// ---------------------------------------------------------------------------
// Central source of truth for CUI (IL5) and Proprietary (IL2) endpoint definitions.
// Modeled after opp-tracker/src/config/aiEndpoints.ts.

export type EndpointId = "cui" | "non-cui";

export interface EndpointConfig {
  id: EndpointId;
  label: string;
  /** Short label for badges/indicators (e.g. "CUI", "Proprietary"). */
  shortLabel: string;
  description: string;
  baseUrl: string;
  /** Path prefix used by Vite dev proxy to route to this endpoint. */
  devProxyPath: string;
  /**
   * Default model per capability class. Roles are vendor-neutral so any model
   * the proxy offers can back them (e.g. Haiku / GPT mini → light,
   * Sonnet / GPT-5 → standard, Opus / GPT-5 Pro → advanced).
   */
  models: {
    /** Lightweight model for classification tasks (e.g. CUI detection). */
    light: string;
    /** Extraction, image description, and the Fast/Balanced chat tiers. */
    standard: string;
    /** The Thorough chat tier. */
    advanced: string;
  };
  embeddingModel: string;
}

export const ENDPOINTS: Record<EndpointId, EndpointConfig> = {
  "non-cui": {
    id: "non-cui",
    label: "Proprietary (IL2)",
    shortLabel: "Proprietary",
    description: "LiteLLM — Commercial IL2",
    baseUrl: "https://lmg.leadai.leidos.com",
    devProxyPath: "/api/llm",
    models: {
      light: "claude-haiku-5-5-aws-comm-il2",
      standard: "claude-sonnet-5-5-aws-comm-il2",
      advanced: "claude-opus-5-5-aws-comm-il2",
    },
    embeddingModel: "text-embedding-3-small-azure-comm-il2",
  },
  cui: {
    id: "cui",
    label: "CUI (IL5)",
    shortLabel: "CUI",
    description: "LiteLLM — GovCloud IL5",
    baseUrl: "https://lmg-cui.leadai.leidos.com",
    devProxyPath: "/api/llm-cui",
    models: {
      light: "claude-haiku-5-5-aws-gov-il5",
      standard: "claude-sonnet-5-5-aws-gov-il5",
      advanced: "claude-opus-5-5-aws-gov-il5",
    },
    embeddingModel: "text-embedding-3-small-azure-gov-il5",
  },
};

// ---------------------------------------------------------------------------
// localStorage keys
// ---------------------------------------------------------------------------

/** Key for the active endpoint selection. */
export const ACTIVE_ENDPOINT_KEY = "doc-builder:active-endpoint";

/** Legacy API key (pre-endpoint-switching). Used for migration only. */
export const LEGACY_API_KEY_STORAGE = "doc-builder:litellm-api-key";

/** Returns the localStorage key for storing an API key for the given endpoint. */
export function apiKeyStorageKey(ep: EndpointId): string {
  return ep === "cui" ? "doc-builder:api-key-cui" : "doc-builder:api-key-noncui";
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Returns the currently selected endpoint ID from localStorage (defaults to "non-cui"). */
export function getActiveEndpointId(): EndpointId {
  const stored = localStorage.getItem(ACTIVE_ENDPOINT_KEY);
  if (stored === "cui" || stored === "non-cui") return stored;
  return "non-cui";
}

/** Returns the full EndpointConfig for the currently active endpoint. */
export function getActiveEndpointConfig(): EndpointConfig {
  return ENDPOINTS[getActiveEndpointId()];
}

/** Resolves the base URL accounting for dev vs production mode. */
export function getResolvedBaseUrl(ep?: EndpointId): string {
  const config = ENDPOINTS[ep ?? getActiveEndpointId()];
  return import.meta.env.DEV ? config.devProxyPath : config.baseUrl;
}
