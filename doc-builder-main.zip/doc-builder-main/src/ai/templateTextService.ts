/**
 * Template Text Service — fetch, extract, cache, and query the unfilled
 * document template so the AI assistant can see surrounding prose context.
 *
 * The template text is extracted once per schema (via mammoth for .docx,
 * or split from output_template for markdown) and cached for the session.
 * Line numbers are 1-indexed and stable while the template is unchanged; the
 * cache entry is dropped when an uploaded template is replaced.
 */

import mammoth from "mammoth";
import type { DocumentSchema } from "../schemas/types";
import { loadTemplateBuffer, onTemplateChanged } from "../generation/templateSource";
import { decodeBasicEntities } from "./promptUtils";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface TemplateTextCache {
  schemaId: string;
  /** Template lines (0-indexed internally; exposed as 1-indexed). */
  lines: string[];
  /** Heading entries with 1-indexed line numbers. */
  headingIndex: HeadingEntry[];
  /** Template tag → 1-indexed line number of first occurrence. */
  tagIndex: Map<string, number>;
  totalLines: number;
}

export interface HeadingEntry {
  /** 1-indexed line number. */
  line: number;
  /** Heading level (1–6). */
  level: number;
  /** Heading text (without level marker). */
  text: string;
}

export interface TemplateContextResult {
  /** Formatted numbered lines (e.g. "L15: The contractor shall..."). */
  lines: string;
  /** Compact heading outline with line numbers. */
  outline: string;
  /** What was matched (tag name, search term, clamping note, etc.). */
  matchInfo?: string;
}

// ---------------------------------------------------------------------------
// Module-level cache: schema ID → Promise<TemplateTextCache>
// ---------------------------------------------------------------------------

const cacheMap = new Map<string, Promise<TemplateTextCache>>();

// Uploaded templates can be replaced or deleted mid-session
onTemplateChanged((schemaId) => cacheMap.delete(schemaId));

/**
 * Get or build the cached template text for a schema.
 * First call triggers the async fetch + extraction; subsequent calls
 * return the same promise (deduplicating concurrent requests).
 */
export function getOrBuildCache(schema: DocumentSchema): Promise<TemplateTextCache> {
  const existing = cacheMap.get(schema.id);
  if (existing) return existing;

  const promise = buildCache(schema).catch((err) => {
    // Clear on failure so the next call retries
    cacheMap.delete(schema.id);
    throw err;
  });
  cacheMap.set(schema.id, promise);
  return promise;
}

async function buildCache(schema: DocumentSchema): Promise<TemplateTextCache> {
  let rawText: string;

  if (schema.docx_template) {
    rawText = await fetchAndExtractDocx(schema);
  } else if (schema.output_template) {
    rawText = schema.output_template;
  } else {
    throw new Error("Schema has no docx_template or output_template.");
  }

  const lines = rawText.split("\n");
  const isDocx = !!schema.docx_template;
  const headingIndex = buildHeadingIndex(lines, isDocx);
  const tagIndex = buildTagIndex(lines);

  return {
    schemaId: schema.id,
    lines,
    headingIndex,
    tagIndex,
    totalLines: lines.length,
  };
}

// ---------------------------------------------------------------------------
// .docx fetch + extraction
// ---------------------------------------------------------------------------

async function fetchAndExtractDocx(schema: DocumentSchema): Promise<string> {
  const arrayBuffer = await loadTemplateBuffer(schema);
  const result = await mammoth.convertToHtml({ arrayBuffer });
  return htmlToTemplateText(result.value);
}

/**
 * Convert mammoth's HTML to plain text with heading-level markers preserved.
 * Similar to htmlToText in extraction/parseFile.ts, but retains `[H1]`–`[H6]`
 * prefixes so the outline builder and AI can distinguish headings.
 */
function htmlToTemplateText(html: string): string {
  let text = html;
  // Replace <br> with newline
  text = text.replace(/<br\s*\/?>/gi, "\n");
  // Replace headings with level-tagged lines
  text = text.replace(
    /<h([1-6])[^>]*>(.*?)<\/h[1-6]>/gi,
    (_match, level, content) => `\n[H${level}] ${content.trim()}\n`,
  );
  // Replace paragraphs with double newlines
  text = text.replace(/<\/p>/gi, "\n\n");
  text = text.replace(/<p[^>]*>/gi, "");
  // Replace list items with bullet points
  text = text.replace(/<li[^>]*>/gi, "• ");
  text = text.replace(/<\/li>/gi, "\n");
  // Strip image tags (not relevant for template structure)
  text = text.replace(/<img[^>]*\/?>/gi, "");
  // Strip all remaining tags
  text = text.replace(/<[^>]+>/g, "");
  // Decode common HTML entities
  text = decodeBasicEntities(text);
  // Collapse excessive blank lines
  text = text.replace(/\n{3,}/g, "\n\n");
  return text.trim();
}

// ---------------------------------------------------------------------------
// Index builders
// ---------------------------------------------------------------------------

const HEADING_DOCX_RE = /^\[H([1-6])]\s*(.+)$/;
const HEADING_MD_RE = /^(#{1,6})\s+(.+)$/;
const TAG_RE = /\{\{#?\/?\s*([^}:]+?)(?:\s*:[^}]*)?\s*\}\}/g;

function buildHeadingIndex(lines: string[], isDocx: boolean): HeadingEntry[] {
  const index: HeadingEntry[] = [];
  const re = isDocx ? HEADING_DOCX_RE : HEADING_MD_RE;

  for (let i = 0; i < lines.length; i++) {
    const match = lines[i].match(re);
    if (match) {
      const level = isDocx ? parseInt(match[1], 10) : match[1].length;
      index.push({ line: i + 1, level, text: match[2].trim() });
    }
  }
  return index;
}

function buildTagIndex(lines: string[]): Map<string, number> {
  const index = new Map<string, number>();
  for (let i = 0; i < lines.length; i++) {
    let match: RegExpExecArray | null;
    TAG_RE.lastIndex = 0;
    while ((match = TAG_RE.exec(lines[i])) !== null) {
      const tag = match[1].trim();
      // Only record first occurrence
      if (!index.has(tag)) {
        index.set(tag, i + 1);
      }
    }
  }
  return index;
}

// ---------------------------------------------------------------------------
// Query functions
// ---------------------------------------------------------------------------

/**
 * Invert template_key_map: field key → list of template tag names.
 */
function invertKeyMap(schema: DocumentSchema): Map<string, string[]> {
  const inv = new Map<string, string[]>();
  const tkm = schema.template_key_map;
  if (!tkm) return inv;

  for (const [tag, mapping] of Object.entries(tkm)) {
    const fieldKey = typeof mapping === "string" ? mapping : mapping.field;
    const list = inv.get(fieldKey) ?? [];
    list.push(tag);
    inv.set(fieldKey, list);
  }
  return inv;
}

/**
 * Format a window of lines with `L{num}: ` prefixes.
 */
function formatLines(lines: string[], startIdx: number, count: number): string {
  const from = Math.max(0, startIdx);
  const to = Math.min(lines.length, from + count);
  const padWidth = String(to).length;

  const result: string[] = [];
  for (let i = from; i < to; i++) {
    const num = String(i + 1).padStart(padWidth, " ");
    result.push(`L${num}: ${lines[i]}`);
  }
  return result.join("\n");
}

export function queryByFieldKey(
  cache: TemplateTextCache,
  schema: DocumentSchema,
  fieldKey: string,
  window: number,
): TemplateContextResult {
  // For markdown-only schemas (no template_key_map), the tag IS the field key
  if (!schema.template_key_map) {
    const lineNum = cache.tagIndex.get(fieldKey);
    if (lineNum) {
      const startIdx = Math.max(0, lineNum - 1 - window);
      const count = window * 2 + 1;
      return {
        lines: formatLines(cache.lines, startIdx, count),
        outline: buildOutline(cache),
        matchInfo: `Field "${fieldKey}" found at L${lineNum} (markdown template).`,
      };
    }
    return {
      lines: "",
      outline: buildOutline(cache),
      matchInfo:
        `Field "${fieldKey}" not found in template. ` +
        `Available tags: ${[...cache.tagIndex.keys()].slice(0, 15).join(", ")}${cache.tagIndex.size > 15 ? "..." : ""}.`,
    };
  }

  const inverted = invertKeyMap(schema);
  const tags = inverted.get(fieldKey);

  if (!tags || tags.length === 0) {
    // List some available field mappings for guidance
    const available = [...inverted.entries()]
      .slice(0, 10)
      .map(([k, t]) => `${k} → {{${t[0]}}}`)
      .join(", ");
    return {
      lines: "",
      outline: buildOutline(cache),
      matchInfo:
        `Field "${fieldKey}" has no mapping in template_key_map. ` +
        `Available mappings: ${available}${inverted.size > 10 ? "..." : ""}.`,
    };
  }

  // Find the first tag that appears in the template text
  let foundTag: string | undefined;
  let foundLine: number | undefined;
  for (const tag of tags) {
    const lineNum = cache.tagIndex.get(tag);
    if (lineNum !== undefined) {
      foundTag = tag;
      foundLine = lineNum;
      break;
    }
  }

  if (!foundTag || !foundLine) {
    return {
      lines: "",
      outline: buildOutline(cache),
      matchInfo:
        `Tag(s) {{${tags.join("}}, {{")}}} mapped to "${fieldKey}" not found in extracted template text. ` +
        `This can happen when Word XML splits a tag across formatting runs.`,
    };
  }

  const startIdx = Math.max(0, foundLine - 1 - window);
  const count = window * 2 + 1;
  let info = `Field "${fieldKey}" → {{${foundTag}}} at L${foundLine}.`;

  // Note additional tag locations
  const otherTags = tags.filter((t) => t !== foundTag);
  for (const t of otherTags) {
    const l = cache.tagIndex.get(t);
    if (l !== undefined) {
      info += ` Also appears at L${l} as {{${t}}}.`;
    }
  }

  return {
    lines: formatLines(cache.lines, startIdx, count),
    outline: buildOutline(cache),
    matchInfo: info,
  };
}

export function queryByLineRange(
  cache: TemplateTextCache,
  fromLine: number,
  count: number,
): TemplateContextResult {
  const clamped = Math.max(1, Math.min(fromLine, cache.totalLines));
  const clampNote = clamped !== fromLine ? ` (clamped from ${fromLine})` : "";
  const startIdx = clamped - 1;

  return {
    lines: formatLines(cache.lines, startIdx, count),
    outline: buildOutline(cache),
    matchInfo: `Lines ${clamped}–${Math.min(clamped + count - 1, cache.totalLines)}${clampNote} of ${cache.totalLines}.`,
  };
}

export function queryBySearch(
  cache: TemplateTextCache,
  searchText: string,
  window: number,
): TemplateContextResult {
  const lower = searchText.toLowerCase();

  for (let i = 0; i < cache.lines.length; i++) {
    if (cache.lines[i].toLowerCase().includes(lower)) {
      const lineNum = i + 1;
      const startIdx = Math.max(0, i - window);
      const count = window * 2 + 1;
      return {
        lines: formatLines(cache.lines, startIdx, count),
        outline: buildOutline(cache),
        matchInfo: `Found "${searchText}" at L${lineNum}.`,
      };
    }
  }

  return {
    lines: "",
    outline: buildOutline(cache),
    matchInfo:
      `No match for "${searchText}" in the template (${cache.totalLines} lines). ` +
      `Try different terms or use the outline line numbers with from_line.`,
  };
}

// ---------------------------------------------------------------------------
// Outline builder
// ---------------------------------------------------------------------------

/**
 * Build a compact heading outline with line numbers.
 * Annotates headings with nearby {{TAG}} placeholders when they fall
 * within 5 lines of a heading, so the AI can orient without extra calls.
 */
export function buildOutline(cache: TemplateTextCache): string {
  if (cache.headingIndex.length === 0) {
    return `Document outline (${cache.totalLines} lines): (no headings detected)`;
  }

  const padWidth = String(cache.totalLines).length;

  // Build a map of line number → nearby tags for annotation
  const tagsByLine = new Map<number, string[]>();
  for (const [tag, line] of cache.tagIndex) {
    const list = tagsByLine.get(line) ?? [];
    list.push(tag);
    tagsByLine.set(line, list);
  }

  const lines: string[] = [`Document outline (${cache.totalLines} lines):`];

  for (const h of cache.headingIndex) {
    const indent = "  ".repeat(Math.max(0, h.level - 1));
    const num = String(h.line).padStart(padWidth, " ");
    let entry = `  L${num}: ${indent}${h.text}`;

    // Annotate with nearby tags (within 5 lines after the heading)
    const nearbyTags: string[] = [];
    for (let offset = 0; offset <= 5; offset++) {
      const tags = tagsByLine.get(h.line + offset);
      if (tags) {
        for (const t of tags) {
          nearbyTags.push(`{{${t}}} at L${h.line + offset}`);
        }
      }
    }
    if (nearbyTags.length > 0) {
      entry += `  ← ${nearbyTags.join(", ")}`;
    }

    lines.push(entry);
  }

  return lines.join("\n");
}
