/**
 * Starting points for the drafting style note, for customers with no style
 * reference. Generic on purpose: nothing here is specific to one schema.
 */
export interface DraftingStylePreset {
  id: "narrative" | "bulleted" | "mixed";
  label: string;
  text: string;
}

export const DRAFTING_STYLE_PRESETS: DraftingStylePreset[] = [
  {
    id: "narrative",
    label: "Narrative",
    text: "Write in complete paragraphs. Use bullet lists only for enumerations of four or more discrete items (for example a list of annexes or deliverables). Open each section with a one-sentence statement of purpose. Third person, present tense. Spell out each acronym on first use within a section.",
  },
  {
    id: "bulleted",
    label: "Bulleted",
    text: "Lead each section with one or two sentences of context, then present the substance as concise bullet points. One idea per bullet; bullets are fragments or single sentences, not paragraphs. Use bold lead-ins for bullet groups instead of sub-headings where sub-headings are not permitted. Spell out each acronym on first use within a section.",
  },
  {
    id: "mixed",
    label: "Mixed",
    text: "Use paragraphs for strategy, rationale, and context (introductions, overviews, approach descriptions). Use bullet points for enumerable content (requirements, risks, schedules, responsibilities, deliverables). Third person, present tense. Spell out each acronym on first use within a section.",
  },
];
