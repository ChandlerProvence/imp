import { describe, it, expect, vi, beforeEach } from "vitest";
import { computeSourceHash, embedAndStoreDocument } from "./embeddings";
import { db } from "../db/dexie";
import { ACTIVE_ENDPOINT_KEY, apiKeyStorageKey } from "./endpoints";

describe("embedAndStoreDocument cache invalidation", () => {
  let fetchMock: ReturnType<typeof vi.fn>;

  beforeEach(async () => {
    localStorage.clear();
    await db.embeddingChunks.clear();
    localStorage.setItem(apiKeyStorageKey("non-cui"), "test-key");
    localStorage.setItem(apiKeyStorageKey("cui"), "test-cui-key");
    localStorage.setItem(ACTIVE_ENDPOINT_KEY, "non-cui");

    fetchMock = vi.fn(async (_url: string, init: any) => {
      const body = JSON.parse(init.body);
      return {
        ok: true,
        json: async () => ({ data: body.input.map((_: string, i: number) => ({ embedding: [i, i + 1], index: i })) }),
      };
    });
    vi.stubGlobal("fetch", fetchMock);
  });

  it("re-embeds when the active endpoint's embedding model differs from the cached chunk's model", async () => {
    const docId = "doc-model-switch";
    const text = "a".repeat(50);

    await embedAndStoreDocument({ docId, docTitle: "t", text });
    expect(fetchMock).toHaveBeenCalledTimes(1);

    // Same endpoint, same text — cache hit, no re-embed call.
    await embedAndStoreDocument({ docId, docTitle: "t", text });
    expect(fetchMock).toHaveBeenCalledTimes(1);

    // Switch to the CUI endpoint (different embedding model) — same text, same docId.
    localStorage.setItem(ACTIVE_ENDPOINT_KEY, "cui");
    await embedAndStoreDocument({ docId, docTitle: "t", text });
    expect(fetchMock).toHaveBeenCalledTimes(2);

    const stored = await db.embeddingChunks.where("docId").equals(docId).first();
    expect(stored?.model).toBe("text-embedding-3-small-azure-gov-il5");
  });

  it("re-embeds when the text changes only in the middle", async () => {
    const docId = "doc-middle-edit";
    const edge = "e".repeat(100);
    await embedAndStoreDocument({ docId, docTitle: "t", text: `${edge}original middle${edge}` });
    expect(fetchMock).toHaveBeenCalledTimes(1);

    await embedAndStoreDocument({ docId, docTitle: "t", text: `${edge}replaced middle${edge}` });
    expect(fetchMock).toHaveBeenCalledTimes(2);
  });
});

describe("computeSourceHash", () => {
  it("distinguishes texts with the same length, first 100 and last 100 characters", async () => {
    const edge = "x".repeat(100);
    const a = `${edge}middle one${edge}`;
    const b = `${edge}middle two${edge}`;
    expect(a.length).toBe(b.length);

    const [hashA, hashB] = await Promise.all([computeSourceHash(a), computeSourceHash(b)]);
    expect(hashA).not.toBe(hashB);
    expect(hashA).toMatch(/^[0-9a-f]{64}$/);
  });

  it("is stable for the same text", async () => {
    expect(await computeSourceHash("same")).toBe(await computeSourceHash("same"));
  });
});
