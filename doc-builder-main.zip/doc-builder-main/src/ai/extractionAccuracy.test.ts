/**
 * Suite 1: Extraction Accuracy Tests
 *
 * Validates the AI extraction pipeline's type coercion and response parsing
 * without making any LLM calls (deterministic, CI-safe).
 *
 * Two layers:
 * 1. coerceValue() — unit tests for per-field-type coercion
 * 2. parseBulkEditResponse() — integration tests feeding canned LLM JSON
 */
import { describe, it, expect } from "vitest";
import { coerceValue, parseBulkEditResponse } from "./bulkEdit";
import type { BulkEditRequest } from "./bulkEdit";
import type { DocumentSchema, FieldDef, TableColumnDef } from "../schemas/types";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Create a minimal FieldDef for testing coerceValue. */
function field(
  type: FieldDef["type"],
  opts?: Partial<FieldDef>,
): FieldDef {
  return {
    id: "test_field",
    label: "Test Field",
    type,
    required: false,
    ...opts,
  };
}

/** Build a minimal BulkEditRequest for parseBulkEditResponse tests. */
function makeRequest(
  fields: FieldDef[],
  currentAnswers: Record<string, string | number | boolean> = {},
  sectionId = "sec",
): BulkEditRequest {
  const schema: DocumentSchema = {
    id: "test-schema",
    title: "Test Schema",
    version: 1,
    sections: [
      {
        id: sectionId,
        title: "Test Section",
        fields,
      },
    ],
  };

  return {
    mode: "prompt",
    prompt: "test",
    selectedSectionIds: [sectionId],
    schema,
    currentAnswers,
  };
}

// ===========================================================================
// coerceValue — unit tests
// ===========================================================================

describe("coerceValue", () => {
  // ── String / Freetext ────────────────────────────────────────────────────

  describe("string fields", () => {
    it("passes through string values", () => {
      expect(coerceValue("hello", field("string"))).toEqual({
        value: "hello",
      });
    });

    it("converts numbers to strings", () => {
      expect(coerceValue(42, field("string"))).toEqual({ value: "42" });
    });

    it("returns null for null/undefined", () => {
      expect(coerceValue(null, field("string"))).toBeNull();
      expect(coerceValue(undefined, field("string"))).toBeNull();
    });
  });

  describe("freetext fields", () => {
    it("passes through markdown text", () => {
      const markdown = "## Heading\n\nParagraph with **bold** text.";
      expect(coerceValue(markdown, field("freetext"))).toEqual({
        value: markdown,
      });
    });
  });

  // ── Number ───────────────────────────────────────────────────────────────

  describe("number fields", () => {
    it("parses numeric strings", () => {
      expect(coerceValue("125000.50", field("number"))).toEqual({
        value: 125000.5,
      });
    });

    it("passes through actual numbers", () => {
      expect(coerceValue(42, field("number"))).toEqual({ value: 42 });
    });

    it("returns null for non-numeric strings", () => {
      expect(coerceValue("abc", field("number"))).toBeNull();
    });

    it("treats an empty string as no value, not 0", () => {
      // A blank AI answer must not overwrite a price/amount with $0.
      expect(coerceValue("", field("number"))).toBeNull();
    });

    it("parses currency-formatted strings", () => {
      expect(coerceValue("$1,234.50", field("number"))).toEqual({ value: 1234.5 });
    });

    it("handles zero", () => {
      expect(coerceValue(0, field("number"))).toEqual({ value: 0 });
      expect(coerceValue("0", field("number"))).toEqual({ value: 0 });
    });

    it("returns null for null", () => {
      expect(coerceValue(null, field("number"))).toBeNull();
    });
  });

  // ── Boolean ──────────────────────────────────────────────────────────────

  describe("boolean fields", () => {
    it("passes through true/false", () => {
      expect(coerceValue(true, field("boolean"))).toEqual({ value: true });
      expect(coerceValue(false, field("boolean"))).toEqual({ value: false });
    });

    it('coerces "yes" to true', () => {
      expect(coerceValue("yes", field("boolean"))).toEqual({ value: true });
    });

    it('coerces "true" to true (case-insensitive)', () => {
      expect(coerceValue("True", field("boolean"))).toEqual({ value: true });
      expect(coerceValue("TRUE", field("boolean"))).toEqual({ value: true });
    });

    it('coerces "no" to false', () => {
      expect(coerceValue("no", field("boolean"))).toEqual({ value: false });
    });

    it('coerces "false" to false (case-insensitive)', () => {
      expect(coerceValue("False", field("boolean"))).toEqual({
        value: false,
      });
    });

    it("returns null for ambiguous strings", () => {
      expect(coerceValue("maybe", field("boolean"))).toBeNull();
      expect(coerceValue("1", field("boolean"))).toBeNull();
    });

    it("returns null for null", () => {
      expect(coerceValue(null, field("boolean"))).toBeNull();
    });
  });

  // ── Date ─────────────────────────────────────────────────────────────────

  describe("date fields", () => {
    it("accepts YYYY-MM-DD format unchanged", () => {
      expect(coerceValue("2026-03-15", field("date"))).toEqual({
        value: "2026-03-15",
      });
    });

    it("parses natural language dates to YYYY-MM-DD", () => {
      const result = coerceValue("March 15, 2026", field("date"));
      expect(result).not.toBeNull();
      expect(result!.value).toBe("2026-03-15");
    });

    it("parses ISO datetime strings", () => {
      const result = coerceValue("2026-06-15T00:00:00.000Z", field("date"));
      expect(result).not.toBeNull();
      expect(result!.value).toBe("2026-06-15");
    });

    it("returns null for invalid date strings", () => {
      expect(coerceValue("not a date", field("date"))).toBeNull();
    });

    it("returns null for null", () => {
      expect(coerceValue(null, field("date"))).toBeNull();
    });
  });

  // ── Enum ─────────────────────────────────────────────────────────────────

  describe("enum fields", () => {
    const enumField = field("enum", {
      options: ["California", "Delaware", "New York"],
    });

    it("accepts exact match", () => {
      expect(coerceValue("California", enumField)).toEqual({
        value: "California",
      });
    });

    it("handles case-insensitive match", () => {
      expect(coerceValue("california", enumField)).toEqual({
        value: "California",
      });
      expect(coerceValue("DELAWARE", enumField)).toEqual({
        value: "Delaware",
      });
    });

    it("returns error for invalid option", () => {
      const result = coerceValue("Montana", enumField);
      expect(result).not.toBeNull();
      expect(result!.value).toBe("Montana");
      expect(result!.error).toContain("not a valid option");
    });

    it("returns null for null", () => {
      expect(coerceValue(null, enumField)).toBeNull();
    });
  });

  // ── Table ────────────────────────────────────────────────────────────────

  describe("table fields", () => {
    const tableField = field("table", {
      columns: [
        { id: "name", label: "Name", type: "string", required: true },
        { id: "qty", label: "Qty", type: "number", required: true },
      ] as TableColumnDef[],
    });

    it("accepts array of row objects", () => {
      const result = coerceValue(
        [{ name: "Widget", qty: 5 }, { name: "Gadget", qty: 10 }],
        tableField,
      );
      expect(result).not.toBeNull();
      // Result value is a serialized JSON string (from serializeTableData)
      expect(typeof result!.value).toBe("string");
      const parsed = JSON.parse(result!.value as string);
      expect(parsed.rows).toHaveLength(2);
    });

    it("returns null for non-array input", () => {
      expect(coerceValue("not an array", tableField)).toBeNull();
      expect(coerceValue({ name: "Widget" }, tableField)).toBeNull();
    });

    it("returns null for empty array", () => {
      expect(coerceValue([], tableField)).toBeNull();
    });

    it("filters out non-object rows", () => {
      const result = coerceValue(
        [{ name: "Widget", qty: 5 }, "bad row", null],
        tableField,
      );
      expect(result).not.toBeNull();
      const parsed = JSON.parse(result!.value as string);
      expect(parsed.rows).toHaveLength(1);
    });
  });
});

// ===========================================================================
// parseBulkEditResponse — integration tests
// ===========================================================================

describe("parseBulkEditResponse", () => {
  const stringField: FieldDef = {
    id: "country",
    label: "Country",
    type: "string",
    required: true,
  };
  const numberField: FieldDef = {
    id: "amount",
    label: "Amount",
    type: "number",
    required: false,
  };
  const dateField: FieldDef = {
    id: "start_date",
    label: "Start Date",
    type: "date",
    required: true,
  };
  const boolField: FieldDef = {
    id: "active",
    label: "Active",
    type: "boolean",
    required: false,
  };
  const enumField: FieldDef = {
    id: "status",
    label: "Status",
    type: "enum",
    required: false,
    options: ["Draft", "Final", "Cancelled"],
  };

  const allFields = [stringField, numberField, dateField, boolField, enumField];

  // ── Multi-field extraction ───────────────────────────────────────────────

  it("parses a multi-field response correctly", () => {
    const request = makeRequest(allFields);
    const raw = JSON.stringify({
      "sec.country": { value: "Japan", confidence: 0.95 },
      "sec.amount": { value: "125000", confidence: 0.85 },
      "sec.start_date": { value: "2026-03-15", confidence: 0.90 },
      "sec.active": { value: true, confidence: 0.88 },
      "sec.status": { value: "Final", confidence: 0.92 },
    });

    const { changes } = parseBulkEditResponse(raw, request);
    expect(changes).toHaveLength(5);

    const country = changes.find((c) => c.fieldKey === "sec.country");
    expect(country?.proposedValue).toBe("Japan");
    expect(country?.confidence).toBe(0.95);
    expect(country?.fieldType).toBe("string");

    const amount = changes.find((c) => c.fieldKey === "sec.amount");
    expect(amount?.proposedValue).toBe(125000);

    const date = changes.find((c) => c.fieldKey === "sec.start_date");
    expect(date?.proposedValue).toBe("2026-03-15");

    const active = changes.find((c) => c.fieldKey === "sec.active");
    expect(active?.proposedValue).toBe(true);

    const status = changes.find((c) => c.fieldKey === "sec.status");
    expect(status?.proposedValue).toBe("Final");
  });

  // ── Confidence score handling ────────────────────────────────────────────

  it("clamps confidence to [0, 1]", () => {
    const request = makeRequest([stringField]);
    const raw = JSON.stringify({
      "sec.country": { value: "Japan", confidence: 1.5 },
    });

    const { changes } = parseBulkEditResponse(raw, request);
    expect(changes[0].confidence).toBe(1.0);
  });

  it("clamps negative confidence to 0", () => {
    const request = makeRequest([stringField]);
    const raw = JSON.stringify({
      "sec.country": { value: "Japan", confidence: -0.3 },
    });

    const { changes } = parseBulkEditResponse(raw, request);
    expect(changes[0].confidence).toBe(0);
  });

  it("defaults confidence to 0.7 when not provided", () => {
    const request = makeRequest([stringField]);
    const raw = JSON.stringify({
      "sec.country": { value: "Japan" },
    });

    const { changes } = parseBulkEditResponse(raw, request);
    expect(changes[0].confidence).toBe(0.7);
  });

  // ── Legacy flat value format ─────────────────────────────────────────────

  it("handles legacy flat values (no {value, confidence} wrapper)", () => {
    const request = makeRequest([stringField]);
    const raw = JSON.stringify({
      "sec.country": "Japan",
    });

    const { changes } = parseBulkEditResponse(raw, request);
    expect(changes).toHaveLength(1);
    expect(changes[0].proposedValue).toBe("Japan");
    expect(changes[0].confidence).toBe(0.7); // default
  });

  // ── same_as / computed field skipping ────────────────────────────────────

  it("skips same_as fields", () => {
    const sameAsField: FieldDef = {
      id: "mirror",
      label: "Mirror",
      type: "string",
      required: false,
      same_as: "sec.country",
    };
    const request = makeRequest([stringField, sameAsField]);
    const raw = JSON.stringify({
      "sec.country": { value: "Japan", confidence: 0.9 },
      "sec.mirror": { value: "Japan", confidence: 0.9 },
    });

    const { changes, skipped } = parseBulkEditResponse(raw, request);
    expect(changes).toHaveLength(1);
    expect(changes[0].fieldKey).toBe("sec.country");
    expect(skipped).toHaveLength(1);
    expect(skipped[0].fieldKey).toBe("sec.mirror");
  });

  it("skips computed fields", () => {
    const computedField: FieldDef = {
      id: "total",
      label: "Total",
      type: "number",
      required: false,
      formula: "amount * 2", format: "currency",
    };
    const request = makeRequest([numberField, computedField]);
    const raw = JSON.stringify({
      "sec.amount": { value: 100, confidence: 0.9 },
      "sec.total": { value: 200, confidence: 0.9 },
    });

    const { changes, skipped } = parseBulkEditResponse(raw, request);
    expect(changes).toHaveLength(1);
    expect(changes[0].fieldKey).toBe("sec.amount");
    expect(skipped).toHaveLength(1);
    expect(skipped[0].fieldKey).toBe("sec.total");
  });

  // ── Identical values skipped ─────────────────────────────────────────────

  it("skips values identical to current answers", () => {
    const request = makeRequest([stringField], { "sec.country": "Japan" });
    const raw = JSON.stringify({
      "sec.country": { value: "Japan", confidence: 0.9 },
    });

    const { changes, skipped } = parseBulkEditResponse(raw, request);
    expect(changes).toHaveLength(0);
    expect(skipped).toHaveLength(1);
    expect(skipped[0].reason).toBe("identical to current value");
  });

  it("includes values that differ from current answers", () => {
    const request = makeRequest([stringField], { "sec.country": "Germany" });
    const raw = JSON.stringify({
      "sec.country": { value: "Japan", confidence: 0.9 },
    });

    const { changes } = parseBulkEditResponse(raw, request);
    expect(changes).toHaveLength(1);
    expect(changes[0].proposedValue).toBe("Japan");
    expect(changes[0].currentValue).toBe("Germany");
  });

  // ── Code fence stripping ─────────────────────────────────────────────────

  it("strips markdown code fences from response", () => {
    const request = makeRequest([stringField]);
    const raw =
      '```json\n{"sec.country": {"value": "Japan", "confidence": 0.9}}\n```';

    const { changes } = parseBulkEditResponse(raw, request);
    expect(changes).toHaveLength(1);
    expect(changes[0].proposedValue).toBe("Japan");
  });

  it("strips code fences without language tag", () => {
    const request = makeRequest([stringField]);
    const raw =
      '```\n{"sec.country": {"value": "Japan", "confidence": 0.9}}\n```';

    const { changes } = parseBulkEditResponse(raw, request);
    expect(changes).toHaveLength(1);
  });

  // ── Error handling ───────────────────────────────────────────────────────

  it("throws a user-friendly error for invalid JSON", () => {
    const request = makeRequest([stringField]);
    const raw = '{"sec.country": {"value": "Japan", "confidence": }';

    expect(() => parseBulkEditResponse(raw, request)).toThrow(
      /not valid JSON/i,
    );
  });

  it("throws for array response (expected object)", () => {
    const request = makeRequest([stringField]);
    const raw = '[{"sec.country": "Japan"}]';

    expect(() => parseBulkEditResponse(raw, request)).toThrow(/object/i);
  });

  // ── Skip reasons ─────────────────────────────────────────────────────────

  it("reports unknown field keys in skipped", () => {
    const request = makeRequest([stringField]);
    const raw = JSON.stringify({
      "sec.country": { value: "Japan", confidence: 0.9 },
      "sec.nonexistent_field": { value: "ignored", confidence: 0.5 },
    });

    const { changes, skipped } = parseBulkEditResponse(raw, request);
    expect(changes).toHaveLength(1);
    expect(changes[0].fieldKey).toBe("sec.country");
    expect(skipped).toHaveLength(1);
    expect(skipped[0]).toEqual({
      fieldKey: "sec.nonexistent_field",
      reason: "not in selected sections",
    });
  });

  it("reports coercion failures in skipped", () => {
    const request = makeRequest([numberField]);
    const raw = JSON.stringify({
      "sec.amount": { value: "not-a-number", confidence: 0.8 },
    });

    const { changes, skipped } = parseBulkEditResponse(raw, request);
    expect(changes).toHaveLength(0);
    expect(skipped).toHaveLength(1);
    expect(skipped[0]).toEqual({
      fieldKey: "sec.amount",
      reason: "could not convert to number",
    });
  });

  it("reports identical values in skipped", () => {
    const request = makeRequest([stringField], { "sec.country": "Japan" });
    const raw = JSON.stringify({
      "sec.country": { value: "Japan", confidence: 0.9 },
    });

    const { changes, skipped } = parseBulkEditResponse(raw, request);
    expect(changes).toHaveLength(0);
    expect(skipped).toHaveLength(1);
    expect(skipped[0]).toEqual({
      fieldKey: "sec.country",
      reason: "identical to current value",
    });
  });

  it("reports same_as fields in skipped", () => {
    const sameAsField: FieldDef = {
      id: "mirror",
      label: "Mirror",
      type: "string",
      required: false,
      same_as: "sec.country",
    };
    const request = makeRequest([stringField, sameAsField]);
    const raw = JSON.stringify({
      "sec.country": { value: "Japan", confidence: 0.9 },
      "sec.mirror": { value: "Japan", confidence: 0.9 },
    });

    const { changes, skipped } = parseBulkEditResponse(raw, request);
    expect(changes).toHaveLength(1);
    expect(skipped).toHaveLength(1);
    expect(skipped[0]).toEqual({
      fieldKey: "sec.mirror",
      reason: "linked/computed field (auto-filled)",
    });
  });

  it("returns empty skipped array on happy path", () => {
    const request = makeRequest([stringField]);
    const raw = JSON.stringify({
      "sec.country": { value: "Japan", confidence: 0.9 },
    });

    const { changes, skipped } = parseBulkEditResponse(raw, request);
    expect(changes).toHaveLength(1);
    expect(skipped).toHaveLength(0);
  });

  // ── Enum validation error ────────────────────────────────────────────────

  it("sets validationError for invalid enum values", () => {
    const request = makeRequest([enumField]);
    const raw = JSON.stringify({
      "sec.status": { value: "Pending", confidence: 0.8 },
    });

    const { changes } = parseBulkEditResponse(raw, request);
    expect(changes).toHaveLength(1);
    expect(changes[0].validationError).toContain("not a valid option");
    expect(changes[0].accepted).toBe(false); // Default rejected due to error
  });

  // ── rawResponse preserved ────────────────────────────────────────────────

  it("preserves the original raw response string", () => {
    const request = makeRequest([stringField]);
    const raw = '{"sec.country": {"value": "Japan", "confidence": 0.9}}';

    const { rawResponse } = parseBulkEditResponse(raw, request);
    expect(rawResponse).toBe(raw);
  });
});

// ===========================================================================
// LLM-gated integration tests (optional, skipped in CI)
// ===========================================================================

const RUN_LLM_TESTS = process.env.RUN_LLM_TESTS === "true";

describe.skipIf(!RUN_LLM_TESTS)("LLM Extraction Integration", () => {
  it.todo(
    "extracts fields from a natural language prompt with reasonable confidence",
  );

  it.todo(
    "directly-stated facts get higher confidence than inferred values",
  );

  it.todo(
    "extraction from formal document text produces expected field values",
  );
});
