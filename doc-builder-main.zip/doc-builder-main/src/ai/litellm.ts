import Anthropic from "@anthropic-ai/sdk";
import type { MessageParam, ContentBlockParam, ToolResultBlockParam, TextBlockParam } from "@anthropic-ai/sdk/resources/messages";
import type { LiteLLMMessage, ToolCall, StopReason, StreamCallbacks, StreamOptions, ToolDefinition, TokenUsage } from "./types";
import {
  apiKeyStorageKey,
  getActiveEndpointConfig,
  getActiveEndpointId,
  getResolvedBaseUrl,
  type EndpointId,
} from "./endpoints";
import { markModelUnavailable, resolveModel, setDiscoveredModels, type ModelInfo } from "./models";
import { isFeatureEnabled, disableFeatureForSession } from "./featureFlags";
import { assertAllowedFetchUrl } from "../utils/urlAllowlist";
import { appError, appErrorException, classifyHttpStatus, isAbortError, toAppErrorException, type AppError } from "../errors";

// ---------------------------------------------------------------------------
// Streaming timeout defaults
// ---------------------------------------------------------------------------

/**
 * Default inter-chunk timeout (ms). If no SSE event arrives within this window
 * after the first event has been received, the stream is aborted.
 *
 * Set to 24 hours — effectively unlimited.  Users can cancel manually via
 * the Stop button; the timeout only exists as a last-resort backstop for
 * truly abandoned connections.
 */
const STREAM_CHUNK_TIMEOUT_MS = 86_400_000; // 24 h

/**
 * Multiplier for the initial timeout (time-to-first-event).  With a 24-hour
 * base this is academic, but kept at 1× so the initial phase doesn't double
 * an already-huge value.
 */
const STREAM_INITIAL_TIMEOUT_MULTIPLIER = 1;

// ---------------------------------------------------------------------------
// Retry defaults for non-streaming completions
// ---------------------------------------------------------------------------

/** Max retries for non-streaming completions on transient errors. */
const COMPLETION_MAX_RETRIES = 2;

/** Base delay before retry (ms). Doubled on each attempt (exponential backoff). */
const COMPLETION_RETRY_BASE_DELAY_MS = 1_500;

// ---------------------------------------------------------------------------
// SDK base URL helper
// ---------------------------------------------------------------------------

/**
 * The Anthropic SDK requires an absolute URL for `baseURL`.
 * In dev mode `getResolvedBaseUrl()` returns a relative proxy path like `/api/llm`.
 * Prepend window.location.origin to make it absolute.
 */
function getSdkBaseUrl(): string {
  const raw = getResolvedBaseUrl();
  if (raw.startsWith("http")) return raw;
  return `${window.location.origin}${raw}`;
}

// ---------------------------------------------------------------------------
// Dynamic config accessors — read from localStorage so they always reflect
// the currently selected endpoint without requiring React context.
// ---------------------------------------------------------------------------

/** Returns the stored API key for the active endpoint, or null if not configured. */
export function getApiKey(): string | null {
  return localStorage.getItem(apiKeyStorageKey(getActiveEndpointId()));
}

/** Persists an API key for the active endpoint to localStorage. */
export function setApiKey(key: string): void {
  localStorage.setItem(apiKeyStorageKey(getActiveEndpointId()), key);
}

/** Returns the resolved standard model ID for the active endpoint. */
function getModel(): string {
  return resolveModel(getActiveEndpointId(), "standard");
}

/** Returns the resolved advanced model ID for the active endpoint. */
function getModelAdvanced(): string {
  return resolveModel(getActiveEndpointId(), "advanced");
}

/**
 * Normalize an AI error and, if the model is gone, mark it so the next
 * request resolves to a substitute.
 */
function toModelAwareError(err: unknown, model: string) {
  const mapped = toAppErrorException(err, { domain: "ai", context: { model } });
  if (mapped.appError.kind === "ai.model-unavailable") {
    markModelUnavailable(getActiveEndpointId(), model);
  }
  return mapped;
}

// Legacy exports — still used by some consumers for display purposes.
/** @deprecated Use `useAiConfig().endpointConfig.baseUrl` in components. */
export function getLitellmEndpoint(): string {
  return getActiveEndpointConfig().baseUrl;
}
/** @deprecated Use `useAiConfig().modelStandard` in components. */
export function getLitellmModelStandard(): string {
  return getModel();
}
/** @deprecated Use `useAiConfig().modelAdvanced` in components. */
export function getLitellmModelAdvanced(): string {
  return getModelAdvanced();
}

export type { TokenUsage } from "./types";

export interface FetchCompletionResult {
  content: string;
  usage: TokenUsage | null;
  model: string;
  /** Why the model stopped; `max_tokens` means `content` was cut off. */
  stopReason?: StopReason | null;
}

export interface FetchCompletionOptions {
  /** Model to use. Defaults to the standard model. */
  model?: string;
  /** Whether to request JSON mode. */
  jsonMode?: boolean;
  /** Max tokens for the response (default 16384 for non-streaming). */
  maxTokens?: number;
  /** AbortSignal for cancellation. */
  signal?: AbortSignal;
  /** Effort level: "low" for extraction (speed), "high" for drafting (quality). */
  effort?: "low" | "medium" | "high";
}

// ---------------------------------------------------------------------------
// Message Translation: App format (LiteLLMMessage) → Anthropic SDK format
// ---------------------------------------------------------------------------

interface TranslatedMessages {
  system: string | TextBlockParam[] | undefined;
  messages: MessageParam[];
}

/**
 * Translate app-internal messages (OpenAI-ish format) to Anthropic SDK format.
 *
 * Rules:
 * 1. System messages → extracted to top-level `system` param
 * 2. User messages → {role:"user", content: text}
 * 3. Assistant messages with tool_calls → content blocks (text + tool_use)
 * 4. Tool-role messages → grouped into user message with tool_result blocks
 * 5. Consecutive same-role messages are merged (Anthropic requires strict alternation)
 *
 * When `enableCaching` is true, the system prompt is returned as a TextBlockParam[]
 * with `cache_control: { type: "ephemeral" }` on the last block. This enables
 * Anthropic's prompt caching for multi-turn conversations.
 */
function translateMessages(
  appMessages: LiteLLMMessage[],
  options?: { enableCaching?: boolean },
): TranslatedMessages {
  const enableCaching = options?.enableCaching ?? isFeatureEnabled("promptCaching");
  let systemText: string | undefined;
  const raw: MessageParam[] = [];

  for (let i = 0; i < appMessages.length; i++) {
    const msg = appMessages[i];

    if (msg.role === "system") {
      // Combine all system messages into one string
      systemText = systemText ? `${systemText}\n\n${msg.content ?? ""}` : (msg.content ?? "");
      continue;
    }

    if (msg.role === "user") {
      raw.push({ role: "user", content: msg.content ?? "" });
      continue;
    }

    if (msg.role === "assistant") {
      if (!msg.tool_calls || msg.tool_calls.length === 0) {
        // Plain text response
        raw.push({ role: "assistant", content: msg.content ?? "" });
      } else {
        // Build content blocks: optional text + tool_use blocks
        const blocks: ContentBlockParam[] = [];
        if (msg.content) {
          blocks.push({ type: "text", text: msg.content });
        }
        for (const tc of msg.tool_calls) {
          let input: unknown = {};
          try {
            input = JSON.parse(tc.function.arguments);
          } catch {
            input = { _raw: tc.function.arguments };
          }
          blocks.push({
            type: "tool_use",
            id: tc.id,
            name: tc.function.name,
            input: input as Record<string, unknown>,
          });
        }
        raw.push({ role: "assistant", content: blocks });
      }
      continue;
    }

    if (msg.role === "tool") {
      // Collect consecutive tool messages into a single user message with tool_result blocks
      const toolResults: ToolResultBlockParam[] = [];
      let j = i;
      while (j < appMessages.length && appMessages[j].role === "tool") {
        const toolMsg = appMessages[j];
        toolResults.push({
          type: "tool_result",
          tool_use_id: toolMsg.tool_call_id ?? "",
          content: toolMsg.content ?? "",
        });
        j++;
      }
      raw.push({ role: "user", content: toolResults });
      // Skip the messages we just consumed (minus 1 because the for loop will i++)
      i = j - 1;
      continue;
    }
  }

  // Merge consecutive same-role messages (Anthropic requires strict alternation)
  const merged: MessageParam[] = [];
  for (const msg of raw) {
    const prev = merged[merged.length - 1];
    if (prev && prev.role === msg.role) {
      // Merge content: both could be string or array
      const prevContent = Array.isArray(prev.content)
        ? prev.content
        : [{ type: "text" as const, text: prev.content as string }];
      const currContent = Array.isArray(msg.content)
        ? msg.content
        : [{ type: "text" as const, text: msg.content as string }];
      (prev as { role: string; content: unknown }).content = [...prevContent, ...currContent];
    } else {
      merged.push(msg);
    }
  }

  // Apply prompt caching: return system as TextBlockParam[] with cache_control
  let system: string | TextBlockParam[] | undefined;
  if (systemText && enableCaching) {
    system = [
      {
        type: "text" as const,
        text: systemText,
        cache_control: { type: "ephemeral" as const },
      },
    ];
  } else {
    system = systemText;
  }

  return { system, messages: merged };
}

/**
 * Translate Anthropic ToolDefinition[] to the format the SDK expects.
 * Our ToolDefinition is already in Anthropic's native shape.
 */
function translateTools(tools?: ToolDefinition[]): Anthropic.Messages.Tool[] | undefined {
  if (!tools || tools.length === 0) return undefined;
  return tools.map((t) => ({
    name: t.name,
    description: t.description,
    input_schema: t.input_schema as Anthropic.Messages.Tool.InputSchema,
  }));
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/** GET a LiteLLM path with the given key; non-2xx responses become an AppError. */
async function proxyGet(
  ep: EndpointId,
  apiKey: string,
  path: string,
  signal?: AbortSignal,
): Promise<{ ok: true; json: unknown } | { ok: false; status?: number; error: AppError }> {
  try {
    const url = `${getResolvedBaseUrl(ep)}${path}`;
    assertAllowedFetchUrl(url);
    // nosemgrep: nodejs_scan.javascript-ssrf-rule-node_ssrf — URL is from hardcoded ENDPOINTS config, validated by allowlist above
    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${apiKey}` },
      ...(signal ? { signal } : {}),
    });
    if (res.ok) return { ok: true, json: await res.json().catch(() => null) };
    const body = await res.text().catch(() => "");
    // A 404 on a listing endpoint means a wrong base URL, not a retired model
    const kind = res.status === 404 ? "ai.server" : classifyHttpStatus(res.status, body);
    return {
      ok: false,
      status: res.status,
      error: appError(kind, { detail: `HTTP ${res.status} ${body.slice(0, 300)}`.trim() }),
    };
  } catch (e: unknown) {
    if (isAbortError(e)) throw e;
    return { ok: false, error: toAppErrorException(e, { domain: "ai" }).appError };
  }
}

function parseModelIds(json: unknown): string[] | null {
  const data = (json as { data?: unknown } | null)?.data;
  if (!Array.isArray(data)) return null;
  return data
    .map((m) => (m && typeof m === "object" && "id" in m ? String((m as { id: unknown }).id) : ""))
    .filter(Boolean);
}

/** List the model IDs the proxy offers this key (GET /v1/models). */
export async function listModels(
  ep: EndpointId,
  apiKey: string,
  signal?: AbortSignal,
): Promise<{ ok: true; ids: string[] } | { ok: false; error: AppError }> {
  const res = await proxyGet(ep, apiKey, "/v1/models", signal);
  if (!res.ok) return res;
  const ids = parseModelIds(res.json);
  if (!ids) return { ok: false, error: appError("ai.bad-response", { context: { what: "model list" } }) };
  return { ok: true, ids };
}

function perMTok(v: unknown): number | undefined {
  return typeof v === "number" && Number.isFinite(v) ? v * 1_000_000 : undefined;
}

/**
 * Cost/context metadata from LiteLLM GET /model/info. Best-effort: returns
 * null when the proxy doesn't allow it for this key or omits the fields.
 */
export async function fetchModelInfo(
  ep: EndpointId,
  apiKey: string,
  signal?: AbortSignal,
): Promise<Record<string, ModelInfo> | null> {
  const res = await proxyGet(ep, apiKey, "/model/info", signal);
  if (!res.ok) return null;
  const data = (res.json as { data?: unknown } | null)?.data;
  if (!Array.isArray(data)) return null;
  const out: Record<string, ModelInfo> = {};
  for (const entry of data) {
    if (!entry || typeof entry !== "object") continue;
    const name = (entry as { model_name?: unknown }).model_name;
    const info = (entry as { model_info?: Record<string, unknown> }).model_info;
    if (typeof name !== "string" || !info) continue;
    const item: ModelInfo = {
      inputCostPerMTok: perMTok(info.input_cost_per_token),
      outputCostPerMTok: perMTok(info.output_cost_per_token),
      maxInputTokens: typeof info.max_input_tokens === "number" ? info.max_input_tokens : undefined,
    };
    if (item.inputCostPerMTok !== undefined || item.outputCostPerMTok !== undefined || item.maxInputTokens !== undefined) {
      out[name] = item;
    }
  }
  return Object.keys(out).length > 0 ? out : null;
}

/**
 * Refresh the cached model list (and metadata) for an endpoint. Failures
 * leave the previous cache in place so resolution keeps working.
 */
export async function discoverModels(
  ep: EndpointId,
  apiKey: string,
  signal?: AbortSignal,
): Promise<{ ok: true; ids: string[] } | { ok: false; error: AppError }> {
  const [list, info] = await Promise.all([
    listModels(ep, apiKey, signal),
    fetchModelInfo(ep, apiKey, signal).catch((e: unknown) => {
      if (isAbortError(e)) throw e;
      return null;
    }),
  ]);
  if (list.ok) setDiscoveredModels(ep, list.ids, info ?? undefined);
  return list;
}

/**
 * Quick connectivity check — hits GET /v1/models with the given key.
 * No tokens consumed; validates the key and network path, and refreshes the
 * discovered model list as a side effect.
 */
export async function testApiKey(
  ep: EndpointId,
  apiKey: string,
): Promise<{ ok: boolean; error?: AppError }> {
  const res = await discoverModels(ep, apiKey).catch((e: unknown) => ({
    ok: false as const,
    error: toAppErrorException(e, { domain: "ai" }).appError,
  }));
  return res.ok ? { ok: true } : { ok: false, error: res.error };
}

/**
 * Non-streaming chat completion via Anthropic SDK.
 * Used for bulk operations where we need the complete JSON before rendering a diff.
 * Retries up to COMPLETION_MAX_RETRIES times on transient server/network errors.
 */
export async function fetchChatCompletion(
  messages: LiteLLMMessage[],
  options: FetchCompletionOptions = {},
): Promise<FetchCompletionResult> {
  const apiKey = getApiKey();
  if (!apiKey) {
    throw appErrorException("ai.no-key");
  }

  const { model = getModel(), maxTokens = 16384, signal, effort } = options;

  const client = new Anthropic({
    baseURL: getSdkBaseUrl(),
    apiKey,
    dangerouslyAllowBrowser: true,
  });

  const { system, messages: sdkMessages } = translateMessages(messages);

  // Build effort/output_config if the feature is enabled
  const useEffort = effort && isFeatureEnabled("effort");

  let lastError: Error | null = null;

  for (let attempt = 0; attempt <= COMPLETION_MAX_RETRIES; attempt++) {
    // Exponential backoff between retries
    if (attempt > 0) {
      const delay = COMPLETION_RETRY_BASE_DELAY_MS * Math.pow(2, attempt - 1);
      await new Promise((r) => setTimeout(r, delay));
    }

    // Respect caller's abort signal between attempts
    if (signal?.aborted) {
      throw new DOMException("Aborted", "AbortError");
    }

    try {
      const response = await client.messages.create(
        {
          model,
          max_tokens: maxTokens,
          ...(system ? { system } : {}),
          messages: sdkMessages,
          ...(useEffort ? { output_config: { effort } } : {}),
        },
        { signal: signal ?? undefined },
      );

      const text = response.content
        .filter((b): b is Anthropic.TextBlock => b.type === "text")
        .map((b) => b.text)
        .join("");

      const usage: TokenUsage | null = response.usage
        ? {
            promptTokens: response.usage.input_tokens,
            completionTokens: response.usage.output_tokens,
            totalTokens: response.usage.input_tokens + response.usage.output_tokens,
            cacheReadTokens: (response.usage as unknown as Record<string, number>).cache_read_input_tokens ?? 0,
            cacheCreationTokens: (response.usage as unknown as Record<string, number>).cache_creation_input_tokens ?? 0,
          }
        : null;

      return { content: text, usage, model: response.model, stopReason: response.stop_reason };
    } catch (err: unknown) {
      if (isAbortError(err)) throw err;
      const mapped = toModelAwareError(err, model);
      if (mapped.appError.kind === "ai.model-unavailable") throw mapped;
      if (!mapped.appError.retryable || mapped.appError.kind === "ai.rate-limit") throw mapped;
      // Retryable: 5xx server errors, network/connection errors, timeouts
      lastError = mapped;
    }
  }

  // All retries exhausted
  throw lastError!;
}

/**
 * Streaming chat completion via Anthropic SDK.
 * Returns an AbortController so the caller can cancel the request.
 */
export function streamChatCompletion(
  messages: LiteLLMMessage[],
  callbacks: StreamCallbacks,
  options?: StreamOptions,
): AbortController {
  const controller = new AbortController();

  const apiKey = getApiKey();
  if (!apiKey) {
    queueMicrotask(() =>
      callbacks.onError(appErrorException("ai.no-key")),
    );
    return controller;
  }

  const client = new Anthropic({
    baseURL: getSdkBaseUrl(),
    apiKey,
    dangerouslyAllowBrowser: true,
  });

  // undefined falls back to the promptCaching flag inside translateMessages
  const { system, messages: sdkMessages } = translateMessages(messages, { enableCaching: options?.enableCaching });
  const tools = translateTools(options?.tools);

  // Resolve feature-gated options
  const useEffort = options?.effort && isFeatureEnabled("effort");
  const useThinking = options?.enableThinking && isFeatureEnabled("thinking");
  const thinkingBudget = options?.thinkingBudget ?? 10000;
  const toolChoice = options?.toolChoice && options.toolChoice !== "auto" && isFeatureEnabled("structuredOutputs")
    ? options.toolChoice
    : undefined;

  // When thinking is enabled, max_tokens must accommodate thinking + response
  const maxTokens = useThinking
    ? thinkingBudget + (options?.maxTokens ?? 4096)
    : (options?.maxTokens ?? 4096);

  (async () => {
    // Declare timeout handle outside try so catch can clear it
    let timeoutId: ReturnType<typeof setTimeout> | null = null;

    try {
      const stream = client.messages.stream(
        {
          model: options?.model ?? getModel(),
          max_tokens: maxTokens,
          ...(system ? { system } : {}),
          messages: sdkMessages,
          ...(tools ? { tools } : {}),
          // Effort parameter (mutually exclusive with thinking)
          ...(!useThinking && useEffort ? { output_config: { effort: options!.effort! } } : {}),
          // Extended thinking
          ...(useThinking ? { thinking: { type: "enabled" as const, budget_tokens: thinkingBudget } } : {}),
          // Tool choice forcing
          ...(toolChoice ? { tool_choice: toolChoice } : {}),
        },
        { signal: controller.signal },
      );

      // --- Two-phase streaming timeout ---
      // Phase 1 (initial): longer timeout while waiting for the model to start responding.
      // Phase 2 (inter-chunk): shorter timeout once data is flowing.
      const baseTimeout = options?.streamTimeout ?? STREAM_CHUNK_TIMEOUT_MS;
      let timeoutMs = baseTimeout * STREAM_INITIAL_TIMEOUT_MULTIPLIER;
      let receivedFirstEvent = false;

      function resetTimeout() {
        if (timeoutId !== null) clearTimeout(timeoutId);
        timeoutId = setTimeout(() => {
          controller.abort();
          const seconds = String(Math.round(timeoutMs / 1000));
          callbacks.onError(appErrorException("ai.timeout", {
            context: { seconds },
            detail: receivedFirstEvent
              ? `Stream stalled: no data for ${seconds}s after the first event`
              : `No response within ${seconds}s`,
          }));
        }, timeoutMs);
      }

      function onEvent() {
        if (!receivedFirstEvent) {
          receivedFirstEvent = true;
          timeoutMs = baseTimeout; // Switch to shorter inter-chunk timeout
        }
        resetTimeout();
      }

      // Start the initial timeout
      resetTimeout();

      let fullText = "";

      stream.on("text", (delta) => {
        onEvent();
        fullText += delta;
        callbacks.onToken(delta);
      });

      // Surface thinking events if the callback is provided.
      // The SDK emits "contentBlock" when a block completes and every raw SSE
      // event as "streamEvent". Thinking deltas only arrive as raw events.
      if (callbacks.onThinking || callbacks.onThinkingDone) {
        let inThinkingBlock = false;
        stream.on("contentBlock", (block) => {
          onEvent();
          if (block.type === "thinking") {
            inThinkingBlock = false;
            callbacks.onThinkingDone?.();
          }
        });
        stream.on("streamEvent", (event) => {
          onEvent();
          if (event.type === "content_block_start" && event.content_block.type === "thinking") {
            inThinkingBlock = true;
            callbacks.onThinking?.("");
          } else if (
            inThinkingBlock &&
            event.type === "content_block_delta" &&
            event.delta.type === "thinking_delta" &&
            event.delta.thinking
          ) {
            callbacks.onThinking?.(event.delta.thinking);
          }
        });
      } else {
        // Even without thinking callbacks, listen for raw events to keep the timeout alive
        // (e.g., content_block_start events that arrive before text)
        stream.on("streamEvent", () => { onEvent(); });
      }

      const finalMsg = await stream.finalMessage();

      // Stream completed successfully — clear the timeout
      if (timeoutId !== null) clearTimeout(timeoutId);

      // Report usage stats (including cache metrics)
      if (callbacks.onUsage && finalMsg.usage) {
        const usageData = finalMsg.usage as unknown as Record<string, number>;
        callbacks.onUsage({
          promptTokens: usageData.input_tokens ?? 0,
          completionTokens: usageData.output_tokens ?? 0,
          totalTokens: (usageData.input_tokens ?? 0) + (usageData.output_tokens ?? 0),
          cacheReadTokens: usageData.cache_read_input_tokens ?? 0,
          cacheCreationTokens: usageData.cache_creation_input_tokens ?? 0,
        });
      }

      // Check for tool_use blocks in the response
      const toolUseBlocks = finalMsg.content.filter(
        (b): b is Anthropic.ToolUseBlock => b.type === "tool_use",
      );

      if (toolUseBlocks.length > 0) {
        // Map Anthropic tool_use blocks back to app's ToolCall format
        const toolCalls: ToolCall[] = toolUseBlocks.map((block) => ({
          id: block.id,
          type: "function" as const,
          function: {
            name: block.name,
            arguments: JSON.stringify(block.input),
          },
        }));

        if (callbacks.onToolCalls) {
          callbacks.onToolCalls(toolCalls, { stopReason: finalMsg.stop_reason });
        } else if (toolCalls.length >= 1 && callbacks.onToolCall) {
          callbacks.onToolCall(toolCalls[0]);
        }
      } else {
        callbacks.onDone(fullText);
      }
    } catch (err: unknown) {
      // Clear the stream timeout on any exit path
      if (timeoutId !== null) clearTimeout(timeoutId);

      // Abort is not an error
      if (isAbortError(err)) return;

      // Auto-disable features that cause proxy 400 errors
      if (err instanceof Anthropic.BadRequestError) {
        const detail = typeof err.message === "string" ? err.message : "";
        if (useThinking && detail.includes("thinking")) {
          disableFeatureForSession("thinking", detail);
        } else if (useEffort && detail.includes("output_config")) {
          disableFeatureForSession("effort", detail);
        }
      }

      callbacks.onError(toModelAwareError(err, options?.model ?? getModel()));
    }
  })();

  return controller;
}

// ---------------------------------------------------------------------------
// Token Counting
// ---------------------------------------------------------------------------

export interface TokenCountResult {
  inputTokens: number;
  /** Whether the count came from the API or a client-side estimate. */
  source: "api" | "estimate";
}

/**
 * Count tokens for a set of messages. Attempts the SDK's countTokens endpoint;
 * falls back to a character-based estimate if the proxy doesn't support it.
 */
export async function countTokens(
  messages: LiteLLMMessage[],
  options?: { model?: string; tools?: ToolDefinition[] },
): Promise<TokenCountResult> {
  const apiKey = getApiKey();
  if (!apiKey || !isFeatureEnabled("tokenCounting")) {
    return { inputTokens: estimateTokensFromMessages(messages), source: "estimate" };
  }

  // Everything is inside the try: callers treat this as best-effort, so a
  // failure while building the request falls back to the estimate too.
  try {
    const client = new Anthropic({
      baseURL: getSdkBaseUrl(),
      apiKey,
      dangerouslyAllowBrowser: true,
    });

    const { system, messages: sdkMessages } = translateMessages(messages);
    const tools = translateTools(options?.tools);

    // Normalize system to the format countTokens expects (string or TextBlockParam[])
    const systemParam = system
      ? (Array.isArray(system) ? system : [{ type: "text" as const, text: system }])
      : undefined;

    const result = await client.messages.countTokens({
      model: options?.model ?? getModel(),
      messages: sdkMessages,
      ...(systemParam ? { system: systemParam } : {}),
      ...(tools ? { tools } : {}),
    });
    return { inputTokens: result.input_tokens, source: "api" };
  } catch {
    // Usually the proxy doesn't support /v1/messages/count_tokens — fall back
    return { inputTokens: estimateTokensFromMessages(messages), source: "estimate" };
  }
}

/**
 * Quick client-side token estimate (~3.3 chars per token for English).
 * Intentionally conservative (overestimates slightly).
 */
function estimateTokensFromMessages(messages: LiteLLMMessage[]): number {
  let chars = 0;
  for (const msg of messages) {
    chars += msg.content?.length ?? 0;
  }
  // Add ~10% overhead for message structure/formatting
  return Math.ceil((chars * 1.1) / 3.3);
}
