/**
 * Schema validation rules applied to AI-proposed values and described in the
 * AI prompt. Rule semantics are tested in src/engine/validation/.
 */
import { describe, it, expect } from "vitest";
import { buildBulkEditChatSystemPrompt, parseBulkEditResponse, type BulkEditRequest } from "./bulkEdit";
import type { DocumentSchema } from "../schemas/types";

const schema: DocumentSchema = {
  id: "t",
  title: "T",
  version: 1,
  output_template: "x",
  sections: [
    {
      id: "fund",
      title: "Funding",
      fields: [
        { id: "from", label: "Previous Funding", type: "number", required: true, validate: [{ rule: "range", min: 0 }] },
        { id: "ceiling", label: "Ceiling", type: "number", required: false },
        {
          id: "funded",
          label: "Funded",
          type: "number",
          required: false,
          validate: [{ rule: "compare", op: "lte", other: "fund.ceiling" }],
        },
        {
          id: "lines",
          label: "Lines",
          type: "table",
          required: false,
          columns: [{ id: "rate", label: "Rate", type: "number", validate: [{ rule: "range", min: 0 }] }],
        },
      ],
    },
  ],
};

function request(currentAnswers: Record<string, string | number | boolean> = {}): BulkEditRequest {
  return { mode: "prompt", prompt: "x", selectedSectionIds: ["fund"], schema, currentAnswers };
}

describe("parseBulkEditResponse — validation rules", () => {
  it("flags rule-breaking values and leaves them unaccepted", () => {
    const { changes } = parseBulkEditResponse(JSON.stringify({ "fund.from": -100 }), request());
    expect(changes[0]).toMatchObject({ proposedValue: -100, accepted: false, validationError: "Must be at least 0" });
  });

  it("accepts values that satisfy the rules", () => {
    const { changes } = parseBulkEditResponse(JSON.stringify({ "fund.from": 100 }), request());
    expect(changes[0]).toMatchObject({ accepted: true, validationError: undefined });
  });

  it("checks cross-field rules against current answers", () => {
    const raw = JSON.stringify({ "fund.funded": 600 });
    expect(parseBulkEditResponse(raw, request({ "fund.ceiling": 500 })).changes[0].accepted).toBe(false);
    expect(parseBulkEditResponse(raw, request({ "fund.ceiling": 700 })).changes[0].accepted).toBe(true);
  });

  it("flags table cells that break column rules", () => {
    const { changes } = parseBulkEditResponse(JSON.stringify({ "fund.lines": [{ rate: -1 }] }), request());
    expect(changes[0].validationError).toBe("Row 1, Rate: Must be at least 0");
  });

  it("keeps currency-formatted numbers instead of dropping them", () => {
    const raw = JSON.stringify({ "fund.from": "$12,300.00", "fund.lines": [{ rate: "$50,000.00" }, { rate: "1,234.50" }] });
    const { changes } = parseBulkEditResponse(raw, request());
    expect(changes.find((c) => c.fieldKey === "fund.from")?.proposedValue).toBe(12300);
    const lines = changes.find((c) => c.fieldKey === "fund.lines")!;
    expect(JSON.parse(lines.proposedValue as string).rows).toEqual([{ rate: 50000 }, { rate: 1234.5 }]);
  });
});

describe("buildBulkEditChatSystemPrompt — rule descriptions", () => {
  it("describes field and column constraints in plain text", () => {
    const prompt = buildBulkEditChatSystemPrompt(schema, ["fund"], {});
    expect(prompt).toContain("[must be ≥ 0]");
    expect(prompt).toContain("[must be less than or equal to Ceiling]");
    expect(prompt).toContain("rate (number, must be ≥ 0)");
  });
});

describe("buildBulkEditChatSystemPrompt — proposing changes", () => {
  it("asks the model to omit table rows no source states", () => {
    const prompt = buildBulkEditChatSystemPrompt(schema, ["fund"], {});
    expect(prompt).toContain("for table rows, omit when no source states a value");
    expect(prompt).not.toContain("For freetext and table fields, always propose a draft");
  });

  it("tells the model to keep drafting until fields_to_draft is empty", () => {
    const prompt = buildBulkEditChatSystemPrompt(schema, ["fund"], {});
    expect(prompt).toContain("fields_to_draft");
    expect(prompt).toContain("End-of-turn check");
    expect(prompt).not.toContain("single batch");
    expect(prompt).not.toContain("Omit fields you cannot determine");
  });
});
