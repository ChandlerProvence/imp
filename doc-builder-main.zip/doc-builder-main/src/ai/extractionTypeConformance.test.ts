/**
 * Suite 1b: Extraction Type Conformance Tests
 *
 * Validates that extracted values conform to schema-defined types using
 * property-based checks derived from schemas — no golden files needed.
 *
 * The key insight: generateSampleAnswers() should ALWAYS produce
 * type-conformant answers. If it doesn't, either the generator or the
 * schema has a bug.
 */
import { describe, it, expect } from "vitest";
import { schemas } from "../schemas/loader";
import { checkAllFieldConformance, checkTableConformance } from "../test/schema-invariant-utils";
import { generateSampleAnswers } from "../test/fixture-utils";
import type { DocumentSchema, FieldDef } from "../schemas/types";

// ---------------------------------------------------------------------------
// Schema collection — all schemas with a docx_template
// ---------------------------------------------------------------------------

const docxSchemas: DocumentSchema[] = [];
for (const [, schema] of schemas) {
  if (schema.docx_template) docxSchemas.push(schema);
}

// ---------------------------------------------------------------------------
// Suite 1b: Extraction type conformance (deterministic, CI-safe)
// ---------------------------------------------------------------------------

describe("Suite 1b: Extraction type conformance", () => {
  describe.each(docxSchemas.map((s) => [s.id, s] as const))(
    "schema: %s",
    (_id, schema) => {
      const answers = generateSampleAnswers(schema);

      // ── Test 1: all sample answers conform to schema type constraints ──

      it("generated sample answers conform to all schema type constraints", () => {
        const results = checkAllFieldConformance(schema, answers);
        const failures = results.filter((r) => !r.pass);
        const failureMessage = failures
          .map((f) => `  ${f.fieldKey}: ${f.message}`)
          .join("\n");
        expect(
          failures,
          `Type conformance failures:\n${failureMessage}`,
        ).toEqual([]);
      });

      // ── Test 2: table fields respect min_rows ─────────────────────────

      const tableFieldsWithMinRows: { key: string; field: FieldDef }[] = [];
      for (const section of schema.sections) {
        for (const field of section.fields) {
          if (field.type === "table" && field.min_rows !== undefined) {
            tableFieldsWithMinRows.push({
              key: `${section.id}.${field.id}`,
              field,
            });
          }
        }
      }

      if (tableFieldsWithMinRows.length > 0) {
        it("table fields respect min_rows when min_rows is defined", () => {
          for (const { key, field } of tableFieldsWithMinRows) {
            const raw = answers[key];
            if (raw === undefined || raw === "") continue;
            const tableData = JSON.parse(String(raw));
            expect(
              tableData.rows.length,
              `${key}: expected >= ${field.min_rows} rows, got ${tableData.rows.length}`,
            ).toBeGreaterThanOrEqual(field.min_rows!);
          }
        });
      }

      // ── Test 3: formula columns are not populated in sample answers ────

      const tableFieldsWithFormulas: { key: string; field: FieldDef }[] = [];
      for (const section of schema.sections) {
        for (const field of section.fields) {
          if (
            field.type === "table" &&
            field.columns?.some((col) => col.formula)
          ) {
            tableFieldsWithFormulas.push({
              key: `${section.id}.${field.id}`,
              field,
            });
          }
        }
      }

      if (tableFieldsWithFormulas.length > 0) {
        it("table formula columns are not populated in sample answers", () => {
          for (const { key, field } of tableFieldsWithFormulas) {
            const raw = answers[key];
            if (raw === undefined || raw === "") continue;
            const results = checkTableConformance(key, raw, field);
            const formulaFailures = results.filter(
              (r) => !r.pass && r.message.includes("formula column"),
            );
            const failureMessage = formulaFailures
              .map((f) => `  ${f.fieldKey}: ${f.message}`)
              .join("\n");
            expect(
              formulaFailures,
              `Formula column conformance failures:\n${failureMessage}`,
            ).toEqual([]);
          }
        });
      }

      // ── Test 4: all enum fields use values from the options array ──────

      it("all enum fields use values from the options array", () => {
        for (const section of schema.sections) {
          for (const field of section.fields) {
            if (field.type !== "enum") continue;
            if (field.same_as || field.formula !== undefined) continue;

            const key = `${section.id}.${field.id}`;
            const value = answers[key];
            if (value === undefined || value === null || value === "") continue;

            const options = field.options ?? [];
            expect(
              options.includes(String(value)),
              `${key}: enum value "${value}" not in options [${options.join(", ")}]`,
            ).toBe(true);
          }
        }
      });

      // ── Test 5: all date fields are valid YYYY-MM-DD ──────────────────

      it("all date fields are valid YYYY-MM-DD", () => {
        for (const section of schema.sections) {
          for (const field of section.fields) {
            if (field.type !== "date") continue;
            if (field.same_as || field.formula !== undefined) continue;

            const key = `${section.id}.${field.id}`;
            const value = answers[key];
            if (value === undefined || value === null || value === "") continue;

            const strValue = String(value);
            expect(
              /^\d{4}-\d{2}-\d{2}$/.test(strValue),
              `${key}: date "${strValue}" is not in YYYY-MM-DD format`,
            ).toBe(true);
            expect(
              !isNaN(new Date(strValue + "T00:00:00Z").getTime()),
              `${key}: date "${strValue}" is not a valid calendar date`,
            ).toBe(true);
          }
        }
      });
    },
  );
});

// ---------------------------------------------------------------------------
// LLM-gated stubs
// ---------------------------------------------------------------------------

const RUN_LLM_TESTS = process.env.RUN_LLM_TESTS === "true";

describe.skipIf(!RUN_LLM_TESTS)("Suite 1c: Synthetic extraction accuracy", () => {
  it.todo("LLM extracts all field values from synthetic prose document");
  it.todo("extracted values match synthetic input within tolerance");
});

describe.skipIf(!RUN_LLM_TESTS)("Suite 1d: AI-hint effectiveness", () => {
  it.todo("fields with ai_hints have higher extraction confidence than those without");
  it.todo("ai_hint text correlates with extraction accuracy for ambiguous fields");
});
