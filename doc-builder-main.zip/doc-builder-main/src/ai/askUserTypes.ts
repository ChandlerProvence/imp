// ---------------------------------------------------------------------------
// AI "ask_user" types (multiple-choice questions posed to the user)
// ---------------------------------------------------------------------------

export interface AskUserOption {
  label: string;
  description?: string;
  recommended?: boolean;
}

export interface AskUserQuestion {
  header: string;
  question: string;
  fieldKey: string | null;
  multiSelect: boolean;
  options: AskUserOption[];
}

export interface PendingQuestion {
  toolCallId: string;
  questions: AskUserQuestion[];
}

export interface QuestionAnswer {
  header: string;
  question: string;
  fieldKey: string | null;
  selected: string[];
  otherText?: string;
  skipped?: boolean;
}

const MAX_QUESTIONS = 4;
const MIN_OPTIONS = 2;
const MAX_OPTIONS = 6;

interface RawAskUserOption {
  label?: unknown;
  description?: unknown;
  recommended?: unknown;
}

interface RawAskUserQuestion {
  header?: unknown;
  question?: unknown;
  field_key?: unknown;
  multi_select?: unknown;
  options?: unknown;
}

function parseOption(raw: unknown): AskUserOption | null {
  if (typeof raw !== "object" || raw === null) return null;
  const o = raw as RawAskUserOption;
  if (typeof o.label !== "string" || o.label.trim() === "") return null;
  const option: AskUserOption = { label: o.label };
  if (typeof o.description === "string" && o.description.trim() !== "") {
    option.description = o.description;
  }
  if (o.recommended === true) option.recommended = true;
  return option;
}

function parseQuestion(raw: unknown): AskUserQuestion | null {
  if (typeof raw !== "object" || raw === null) return null;
  const q = raw as RawAskUserQuestion;
  if (typeof q.header !== "string" || q.header.trim() === "") return null;
  if (typeof q.question !== "string" || q.question.trim() === "") return null;
  if (!Array.isArray(q.options)) return null;

  const options = q.options
    .map(parseOption)
    .filter((o): o is AskUserOption => o !== null)
    .slice(0, MAX_OPTIONS);
  if (options.length < MIN_OPTIONS) return null;

  return {
    header: q.header,
    question: q.question,
    fieldKey: typeof q.field_key === "string" && q.field_key.trim() !== "" ? q.field_key : null,
    multiSelect: q.multi_select === true,
    options,
  };
}

/** Parse the raw `ask_user` tool-call arguments JSON into validated questions. Returns null if nothing usable survives. */
export function parseAskUserArgs(argsJson: string): AskUserQuestion[] | null {
  let args: unknown;
  try {
    args = JSON.parse(argsJson);
  } catch {
    return null;
  }
  if (typeof args !== "object" || args === null) return null;
  const rawQuestions = (args as { questions?: unknown }).questions;
  if (!Array.isArray(rawQuestions)) return null;

  const questions = rawQuestions
    .map(parseQuestion)
    .filter((q): q is AskUserQuestion => q !== null)
    .slice(0, MAX_QUESTIONS);

  return questions.length > 0 ? questions : null;
}

function formatOneAnswer(answer: QuestionAnswer): string {
  if (answer.skipped) return `${answer.header} → (skipped)`;
  const parts: string[] = [...answer.selected];
  if (answer.otherText && answer.otherText.trim() !== "") {
    parts.push(`Other: "${answer.otherText.trim()}"`);
  }
  if (parts.length === 0) return `${answer.header} → (no answer)`;
  return `${answer.header} → ${parts.join(", ")}`;
}

/** Build the tool_result content for an answered ask_user call: JSON payload + a one-line summary for the model. */
export function formatAnswersToolResult(answers: QuestionAnswer[]): string {
  const summary = answers.length > 0
    ? `User answered: ${answers.map(formatOneAnswer).join("; ")}`
    : "User did not answer.";
  return JSON.stringify({ answers, summary });
}

/** Parse a persisted ask_user tool_result's content back into its answers (for rendering an answered summary). */
export function parseAnsweredAskUser(toolResultContent: string): QuestionAnswer[] | null {
  try {
    const parsed = JSON.parse(toolResultContent) as { answers?: unknown };
    if (!Array.isArray(parsed.answers)) return null;
    return parsed.answers as QuestionAnswer[];
  } catch {
    return null;
  }
}

/** Minimal shape needed to scan a chat message history for a pending ask_user call. */
export interface AskUserScannableMessage {
  role: "user" | "assistant" | "tool";
  toolCalls?: Array<{ id: string; function: { name: string; arguments: string } }>;
  toolCallId?: string;
}

/**
 * Find the most recent assistant `ask_user` tool call in `messages` that has no
 * matching `tool` message yet — i.e. a question still awaiting the user's answer.
 */
export function findPendingAskUser(messages: AskUserScannableMessage[]): PendingQuestion | null {
  const toolResultIds = new Set(
    messages.filter((m) => m.role === "tool" && m.toolCallId).map((m) => m.toolCallId!),
  );
  for (let i = messages.length - 1; i >= 0; i--) {
    const msg = messages[i];
    if (msg.role !== "assistant" || !msg.toolCalls) continue;
    const call = msg.toolCalls.find(
      (tc) => tc.function.name === "ask_user" && !toolResultIds.has(tc.id),
    );
    if (call) {
      const questions = parseAskUserArgs(call.function.arguments);
      if (questions) return { toolCallId: call.id, questions };
    }
  }
  return null;
}
