import { describe, it, expect } from "vitest";
import {
  buildBulkEditChatSystemPrompt,
  buildBulkEditChatUserMessage,
  escapeXmlAttr,
  formatSourceDocumentGuidance,
  type BulkEditRequest,
} from "./bulkEdit";
import type { DocumentSchema } from "../schemas/types";

const schema = { id: "s", title: "S", version: 1, sections: [] } as unknown as DocumentSchema;

function request(overrides: Partial<BulkEditRequest> = {}): BulkEditRequest {
  return {
    mode: "document",
    prompt: "Fill it in.",
    documentText: '<document role="pws" title="PWS" filename="a.pdf">\nbody\n</document>',
    selectedSectionIds: [],
    schema,
    currentAnswers: {},
    ...overrides,
  };
}

describe("source document roles in prompts", () => {
  it("escapes attribute values", () => {
    expect(escapeXmlAttr('a "b" & <c>')).toBe("a &quot;b&quot; &amp; &lt;c&gt;");
  });

  it("formats one line per role, with files and hint when present", () => {
    const text = formatSourceDocumentGuidance([
      { role: "pws", title: "PWS (Performance Work Statement)", aiHint: "Scope only.", filenames: ["a.pdf"] },
      { role: "pr", title: "PR", filenames: ["b.pdf", "c.pdf"] },
    ]);
    expect(text).toContain("## Source document guidance");
    expect(text).toContain("- pws — PWS (Performance Work Statement) (a.pdf): Scope only.");
    expect(text).toContain("- pr — PR (b.pdf, c.pdf)");
    expect(text).not.toContain("PR (b.pdf, c.pdf):");
  });

  it("returns an empty string without roles", () => {
    expect(formatSourceDocumentGuidance(undefined)).toBe("");
    expect(formatSourceDocumentGuidance([])).toBe("");
  });

  it("puts the guidance block before the documents in the user message", () => {
    const msg = buildBulkEditChatUserMessage(
      request({ sourceDocumentRoles: [{ role: "pws", title: "PWS", aiHint: "Scope only.", filenames: ["a.pdf"] }] }),
    );
    const guidanceAt = msg.indexOf("## Source document guidance");
    expect(guidanceAt).toBeGreaterThanOrEqual(0);
    expect(guidanceAt).toBeLessThan(msg.indexOf("<document"));
  });

  it("omits the guidance block when no roles are assigned", () => {
    expect(buildBulkEditChatUserMessage(request())).not.toContain("Source document guidance");
  });

  it("system prompt explains the role attribute", () => {
    const prompt = buildBulkEditChatSystemPrompt(schema, [], {});
    expect(prompt).toContain("`role` attribute");
    expect(prompt).toContain("prefer the one whose assigned role matches the field's subject");
  });

  it("system prompt asks the model to flag documents that don't match their role", () => {
    const prompt = buildBulkEditChatSystemPrompt(schema, [], {});
    const conflictSection = prompt.slice(prompt.indexOf("## Conflict Detection"));
    expect(conflictSection).toContain("does not match its assigned `role`");
    expect(conflictSection).toContain("recommend moving it to the correct slot");
  });
});

describe("source document roles in the review prompt", () => {
  it("explains the role attribute and conflicts with authoritative documents", async () => {
    const { buildReviewSystemPrompt } = await import("./documentReviewPrompt");
    const prompt = buildReviewSystemPrompt(schema);
    expect(prompt).toContain("`role` attribute");
    expect(prompt).toContain("Source document guidance");
    expect(prompt).toContain("whose role is authoritative for it");
  });

  it("asks the reviewer to flag documents that don't match their role", async () => {
    const { buildReviewSystemPrompt } = await import("./documentReviewPrompt");
    const prompt = buildReviewSystemPrompt(schema);
    expect(prompt).toContain("does not match its assigned role");
    expect(prompt).toContain("recommend moving it to the correct slot");
  });
});
