import type { DocumentSchema, FieldDef, FieldType, SectionDef, TableColumnDef } from "../schemas/types";
import type { FieldMeta } from "../db/types";
import { serializeTableData, parseTableData } from "../engine/tableData";
import { getBlockGate } from "../engine/contentBlocks";
import { describeRules, validateProposedValue } from "../engine/validation";
import { toNumber } from "../engine/validation/coerce";
import { todayLine, formatExistingAnswers, GROUNDING_RULES, buildPersonaLine, ANSWERS_SECTION_HEADING, ANSWERS_SECTION_PREAMBLE, FIELD_TYPE_RULES, FREETEXT_DRAFTING_RULE } from "./promptUtils";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface BulkEditRequest {
  mode: "prompt" | "document";
  /** User instruction (mode=prompt). */
  prompt?: string;
  /** Extracted document text (mode=document). */
  documentText?: string;
  /** Section IDs the user selected via checkboxes. */
  selectedSectionIds: string[];
  /** Full schema for the document type. */
  schema: DocumentSchema;
  /** Current session answers (all fields, for context). */
  currentAnswers: Record<string, string | number | boolean>;
  /** Small docs (<10k): full text included directly in prompt. */
  referenceDocTexts?: { title: string; text: string }[];
  /** Large docs (≥10k): pre-retrieved relevant chunks only. */
  retrievedChunks?: { title: string; text: string }[];
  /**
   * Roles the user assigned to attached documents via picker slots. Rendered
   * as a "Source document guidance" block ahead of the documents.
   */
  sourceDocumentRoles?: SourceDocumentRole[];
}

/** A picker slot (schema `recommended_uploads` entry) with its attached documents. */
export interface SourceDocumentRole {
  /** Slot id, matches the `role` attribute on the `<document>` tag. */
  role: string;
  /** Human-readable slot title (e.g. "PWS (Performance Work Statement)"). */
  title: string;
  /** Schema-authored guidance on how to treat this document. */
  aiHint?: string;
  /** Filenames of the documents attached to this slot. */
  filenames: string[];
}

/** Escape a value for use inside a double-quoted XML-style attribute. */
export function escapeXmlAttr(value: string): string {
  return value.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

/**
 * Format the "Source document guidance" block that maps each `role` attribute
 * to its slot title and AI hint. Returns an empty string when there are no roles.
 */
export function formatSourceDocumentGuidance(roles: SourceDocumentRole[] | undefined): string {
  if (!roles || roles.length === 0) return "";
  const lines = [
    "## Source document guidance",
    "Documents tagged with a `role` attribute were assigned that role by the user:",
  ];
  for (const r of roles) {
    const files = r.filenames.length > 0 ? ` (${r.filenames.join(", ")})` : "";
    const hint = r.aiHint?.trim() ? `: ${r.aiHint.trim()}` : "";
    lines.push(`- ${r.role} — ${r.title}${files}${hint}`);
  }
  lines.push("Documents without a `role` attribute are general reference material.");
  return lines.join("\n");
}

/**
 * Format the "Drafting Style" system-prompt block from `session.draftingStyle`.
 * Returns an empty string when no note is set.
 */
export function formatDraftingStyle(draftingStyle: string | undefined): string {
  const note = draftingStyle?.trim();
  if (!note) return "";
  return [
    "## Drafting Style",
    "The customer for this document has the following style preferences. Apply them to every freetext field you draft or revise. They govern form, not facts; the grounding rules above still control what you may assert.",
    note,
  ].join("\n");
}

export interface SkippedChange {
  fieldKey: string;
  reason: string;
}

export interface ProposedChange {
  fieldKey: string;
  sectionId: string;
  sectionTitle: string;
  fieldLabel: string;
  fieldType: FieldType;
  currentValue: string | number | boolean | undefined;
  proposedValue: string | number | boolean;
  /** AI confidence score: 0.0–1.0. */
  confidence: number;
  accepted: boolean;
  validationError?: string;
  /** Column definitions for table-type fields (for rendering). */
  columns?: TableColumnDef[];
}


// ---------------------------------------------------------------------------
// Prompt Construction
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Response Parsing
// ---------------------------------------------------------------------------

function cleanJsonResponse(raw: string): string {
  let cleaned = raw.trim();
  // Strip markdown code fences if present
  if (cleaned.startsWith("```")) {
    cleaned = cleaned.replace(/^```(?:json)?\s*\n?/, "").replace(/\n?```\s*$/, "");
  }
  return cleaned;
}

/** @internal Exported for testing. */
export function coerceValue(
  value: unknown,
  field: FieldDef,
): { value: string | number | boolean; error?: string } | null {
  if (value === null || value === undefined) return null;

  switch (field.type) {
    case "string":
    case "freetext":
      return { value: String(value) };

    case "number": {
      const num = toNumber(value);
      if (num === null) return null;
      return { value: num };
    }

    case "boolean": {
      if (typeof value === "boolean") return { value };
      if (typeof value === "string") {
        const lower = value.toLowerCase();
        if (lower === "true" || lower === "yes") return { value: true };
        if (lower === "false" || lower === "no") return { value: false };
      }
      return null;
    }

    case "date": {
      const str = String(value);
      // Check YYYY-MM-DD format
      if (/^\d{4}-\d{2}-\d{2}$/.test(str)) return { value: str };
      // Try parsing and converting
      const date = new Date(str);
      if (!isNaN(date.getTime())) {
        return { value: date.toISOString().slice(0, 10) };
      }
      return null;
    }

    case "enum": {
      const str = String(value);
      if (field.options?.includes(str)) return { value: str };
      // Case-insensitive match attempt
      const match = field.options?.find(
        (o) => o.toLowerCase() === str.toLowerCase(),
      );
      if (match) return { value: match };
      // Return with warning
      return { value: str, error: `"${str}" is not a valid option` };
    }

    case "table": {
      // Expect an array of row objects
      if (!Array.isArray(value)) return null;
      const columns = field.columns ?? [];
      const validatedRows = value
        .filter((row): row is Record<string, unknown> => typeof row === "object" && row !== null)
        .map((row) => coerceTableRow(row, columns));
      if (validatedRows.length === 0) return null;
      return { value: serializeTableData({ rows: validatedRows }) };
    }

    case "multiselect": {
      // Expect an array of strings; validate each against options
      const arr = Array.isArray(value) ? value : typeof value === "string" ? (() => { try { return JSON.parse(value); } catch { return [value]; } })() : [String(value)];
      if (!Array.isArray(arr)) return null;
      const options = field.options ?? [];
      const validated = arr
        .map((v: unknown) => String(v))
        .map((v: string) => options.find((o) => o.toLowerCase() === v.toLowerCase()) ?? v)
        .filter((v: string) => options.includes(v));
      if (validated.length === 0) return null;
      return { value: JSON.stringify(validated) };
    }

    default:
      return { value: String(value) };
  }
}

/** Coerce and validate a single table row's cells against column definitions. */
function coerceTableRow(
  row: Record<string, unknown>,
  columns: TableColumnDef[],
): Record<string, string | number | boolean> {
  const result: Record<string, string | number | boolean> = {};
  for (const col of columns) {
    const raw = row[col.id];
    if (raw === undefined || raw === null || raw === "") {
      result[col.id] = col.type === "boolean" ? false : "";
      continue;
    }
    switch (col.type) {
      case "string":
        result[col.id] = String(raw);
        break;
      case "number": {
        result[col.id] = toNumber(raw) ?? "";
        break;
      }
      case "boolean": {
        if (typeof raw === "boolean") {
          result[col.id] = raw;
        } else if (typeof raw === "string") {
          const lower = raw.toLowerCase();
          result[col.id] = lower === "true" || lower === "yes";
        } else {
          result[col.id] = false;
        }
        break;
      }
      case "date": {
        const str = String(raw);
        if (/^\d{4}-\d{2}-\d{2}$/.test(str)) {
          result[col.id] = str;
        } else {
          const date = new Date(str);
          result[col.id] = !isNaN(date.getTime())
            ? date.toISOString().slice(0, 10)
            : "";
        }
        break;
      }
      case "enum": {
        const str = String(raw);
        const match = col.options?.find(
          (o) => o.toLowerCase() === str.toLowerCase(),
        );
        result[col.id] = match ?? str;
        break;
      }
      default:
        result[col.id] = String(raw);
    }
  }
  return result;
}

export function parseBulkEditResponse(
  raw: string,
  request: BulkEditRequest,
): { changes: ProposedChange[]; skipped: SkippedChange[]; rawResponse: string } {
  const cleaned = cleanJsonResponse(raw);

  let parsed: Record<string, unknown>;
  try {
    parsed = JSON.parse(cleaned);
  } catch {
    throw new Error(
      "The AI response was not valid JSON. Please try again.\n\nRaw response:\n" +
        raw.slice(0, 500),
    );
  }

  if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
    throw new Error("Expected a JSON object in response.");
  }

  // Build a field lookup from selected sections
  const fieldMap = new Map<string, { field: FieldDef; section: SectionDef }>();
  const selectedSections = request.schema.sections.filter((s) =>
    request.selectedSectionIds.includes(s.id),
  );
  for (const section of selectedSections) {
    for (const field of section.fields) {
      fieldMap.set(`${section.id}.${field.id}`, { field, section });
    }
  }

  const changes: ProposedChange[] = [];
  const skipped: SkippedChange[] = [];

  for (const [key, rawValue] of Object.entries(parsed)) {
    const entry = fieldMap.get(key);
    if (!entry) {
      skipped.push({ fieldKey: key, reason: "not in selected sections" });
      continue;
    }

    const { field, section } = entry;

    // Skip linked/computed fields — the engine auto-fills them
    if (field.same_as || field.formula !== undefined) {
      skipped.push({ fieldKey: key, reason: "linked/computed field (auto-filled)" });
      continue;
    }

    // Skip image fields — these require manual upload, not AI extraction
    if (field.type === "image") {
      skipped.push({ fieldKey: key, reason: "image field (requires manual upload)" });
      continue;
    }

    // Support both { value, confidence } shape and legacy flat values
    let actualValue: unknown;
    let confidence = 0.7; // default if not provided
    if (
      rawValue !== null &&
      typeof rawValue === "object" &&
      !Array.isArray(rawValue) &&
      "value" in (rawValue as Record<string, unknown>)
    ) {
      const obj = rawValue as Record<string, unknown>;
      actualValue = obj.value;
      if (typeof obj.confidence === "number") {
        confidence = Math.max(0, Math.min(1, obj.confidence));
      }
    } else {
      actualValue = rawValue;
    }

    const coerced = coerceValue(actualValue, field);
    if (!coerced) {
      skipped.push({ fieldKey: key, reason: `could not convert to ${field.type}` });
      continue;
    }
    // Schema validation rules: flag (not drop) values that break them.
    if (!coerced.error) {
      const problems = validateProposedValue(request.schema, key, coerced.value, request.currentAnswers)
        .filter((i) => i.severity === "warning");
      if (problems.length > 0) coerced.error = problems.map((i) => i.message).join("; ");
    }

    const currentValue = request.currentAnswers[key];
    // Skip if value is identical to current
    if (currentValue !== undefined && currentValue === coerced.value) {
      skipped.push({ fieldKey: key, reason: "identical to current value" });
      continue;
    }

    changes.push({
      fieldKey: key,
      sectionId: section.id,
      sectionTitle: section.title,
      fieldLabel: field.label,
      fieldType: field.type,
      currentValue,
      proposedValue: coerced.value,
      confidence,
      accepted: !coerced.error, // Default to rejected if there's a validation error
      validationError: coerced.error,
      columns: field.type === "table" ? field.columns : undefined,
    });
  }

  return { changes, skipped, rawResponse: raw };
}

// ---------------------------------------------------------------------------
// Heading collision detection
// ---------------------------------------------------------------------------

/**
 * Find outline numbers already claimed by sibling fields in the same section.
 * For a field with outline "4.3", returns child outlines like ["4.3.1", "4.3.2"]
 * that are occupied by dedicated template fields — the AI should not generate
 * sub-headings that collide with these.
 */
function getReservedChildOutlines(
  field: FieldDef,
  sectionFields: FieldDef[],
): string[] {
  const outline = field.outline_number;
  if (!outline) return [];
  const prefix = outline + ".";
  return sectionFields
    .filter((f) => f.id !== field.id && f.outline_number?.startsWith(prefix))
    .map((f) => f.outline_number!);
}

// ---------------------------------------------------------------------------
// Visibility gate description
// ---------------------------------------------------------------------------

/** Human-readable "requires X contains Y" phrase for a block reference, if it's a multiselect gate. */
function describeGate(schema: DocumentSchema, blockRef: string | undefined): string | undefined {
  if (!blockRef) return undefined;
  const gate = getBlockGate(schema, blockRef);
  return gate ? `${gate.field} contains "${gate.value}"` : undefined;
}

/**
 * Human-readable description of a content block's condition for column annotations.
 * Handles all condition types, not just multiselect `contains`.
 */
function describeBlockCondition(schema: DocumentSchema, blockRef: string | undefined): string | undefined {
  if (!blockRef) return undefined;
  const block = schema.content_blocks?.[blockRef];
  if (!block) return undefined;
  if (typeof block === "boolean") return block ? "always" : "never";
  if (typeof block === "string") return undefined;
  const w = block.when;
  if (w.contains !== undefined) return `${w.field} contains "${w.contains}"`;
  if (w.is_truthy !== undefined) return w.is_truthy ? `${w.field} is true` : `${w.field} is false`;
  if (w.equals !== undefined) return `${w.field} = "${w.equals}"`;
  if (w.gte !== undefined) return `${w.field} >= ${w.gte}`;
  if (w.lt !== undefined) return `${w.field} < ${w.lt}`;
  return undefined;
}

/**
 * Build a prompt section describing which multiselect gate values control
 * which sections and fields. Returns an empty array when no gate
 * relationships exist, adding zero lines to the prompt.
 */
function buildGateDescription(schema: DocumentSchema): string[] {
  // Collect: gateFieldKey → Map<gateValue → { sections, fields }>
  const gates = new Map<string, Map<string, { sections: string[]; fields: string[] }>>();

  const addGate = (
    blockRef: string | undefined,
    target: { type: "section"; title: string } | { type: "field"; key: string },
  ) => {
    const gate = blockRef ? getBlockGate(schema, blockRef) : undefined;
    if (!gate) return;
    if (!gates.has(gate.field)) gates.set(gate.field, new Map());
    const valueMap = gates.get(gate.field)!;
    if (!valueMap.has(gate.value)) valueMap.set(gate.value, { sections: [], fields: [] });
    const entry = valueMap.get(gate.value)!;
    if (target.type === "section") {
      entry.sections.push(target.title);
    } else {
      entry.fields.push(target.key);
    }
  };

  for (const section of schema.sections) {
    addGate(section.visible_when, { type: "section", title: section.title });
    for (const field of section.fields) {
      addGate(field.visible_when, { type: "field", key: `${section.id}.${field.id}` });
    }
  }

  if (gates.size === 0) return [];

  const lines: string[] = ["## Visibility Gates", ""];
  lines.push(
    "Some sections and fields only appear in the generated document when a " +
    "multiselect gate field includes specific values. **You must select the " +
    "appropriate gate values AND fill the gated fields for them to appear.**",
  );
  lines.push("");

  for (const [gateKey, valueMap] of gates) {
    lines.push(`Gate field: \`${gateKey}\``);
    for (const [value, targets] of valueMap) {
      const parts: string[] = [];
      if (targets.sections.length > 0) {
        parts.push(`sections: ${targets.sections.join(", ")}`);
      }
      if (targets.fields.length > 0) {
        parts.push(`fields: ${targets.fields.join(", ")}`);
      }
      lines.push(`- "${value}" → enables ${parts.join("; ")}`);
    }
    lines.push("");
  }

  lines.push(
    "When source documents contain information relevant to a gated section, " +
    "include the corresponding value in the gate field AND fill the gated section's fields.",
  );
  lines.push("");

  return lines;
}

// ---------------------------------------------------------------------------
// Conversational System Prompt (for chat-based bulk edit)
// ---------------------------------------------------------------------------

export function buildBulkEditChatSystemPrompt(
  schema: DocumentSchema,
  selectedSectionIds: string[],
  currentAnswers: Record<string, string | number | boolean>,
  focusField?: { sectionId: string; fieldKey: string },
  fieldMeta?: Record<string, FieldMeta>,
  draftingStyle?: string,
): string {
  const selectedSections = schema.sections.filter((s) =>
    selectedSectionIds.includes(s.id),
  );

  const lines: string[] = [
    buildPersonaLine(schema, "editor filling fields in") + " Be concise.",
    todayLine(),
    "",
    "## Fields",
    "",
  ];

  for (const section of selectedSections) {
    lines.push(`### ${section.title} (${section.id})`);
    const sectionGate = describeGate(schema, section.visible_when);
    if (sectionGate) {
      lines.push(`  (gated: visible when ${sectionGate})`);
    }
    for (const field of section.fields) {
      if (field.same_as || field.formula !== undefined) continue; // Skip linked/computed fields — engine auto-fills them
      if (field.type === "image") continue; // Skip image fields — require manual upload
      const fieldKey = `${section.id}.${field.id}`;
      if (field.type === "table") {
        let desc = `- ${fieldKey}: table — "${field.label}"`;
        if (field.ai_hint) desc += ` (${field.ai_hint})`;
        lines.push(desc);
        // Full column schema
        for (const col of field.columns ?? []) {
          let colDesc = `    - ${col.id} (${col.type}`;
          if (col.required) colDesc += ", required";
          if (col.type === "enum" && col.options) {
            colDesc += `, options: [${col.options.join(", ")}]`;
          }
          const colRules = describeRules(col.validate, schema, field.columns);
          if (colRules) colDesc += `, must be ${colRules}`;
          colDesc += `): "${col.label}"`;
          if (col.visible_when) {
            const desc = describeBlockCondition(schema, col.visible_when);
            colDesc += desc ? ` [only when ${desc}]` : ` [gated: ${col.visible_when}]`;
          }
          lines.push(colDesc);
        }
        if (field.rows) {
          lines.push(`    Fixed rows: ${field.rows.map((r) => `${r.id}="${r.label}"`).join(", ")}`);
        }
        // Existing table data
        const existingData = parseTableData(currentAnswers[fieldKey]);
        if (existingData.rows.length > 0) {
          lines.push(`    Current data (${existingData.rows.length} row(s)): ${JSON.stringify(existingData.rows)}`);
        }
        lines.push(`    Value format: array of row objects, e.g. [{"${(field.columns ?? [])[0]?.id ?? "col"}": "...", ...}]`);
      } else {
        let desc = `- ${fieldKey}: ${field.type}`;
        if (field.type === "date") desc += " (YYYY-MM-DD)";
        if ((field.type === "enum" || field.type === "multiselect") && field.options) {
          desc += ` [${field.options.join("|")}]`;
        }
        desc += ` — "${field.label}"`;
        if (field.ai_hint) desc += ` (${field.ai_hint})`;
        const rules = describeRules(field.validate, schema);
        if (rules) desc += ` [must be ${rules}]`;
        if (field.template_heading) desc += ` [heading: "${field.template_heading}"]`;
        if (field.heading_level) desc += ` [level: ${field.heading_level}]`;
        const reserved = getReservedChildOutlines(field, section.fields);
        if (reserved.length > 0) {
          desc += ` [no-subheadings: child sections ${reserved.join(", ")} already exist in the template]`;
        }
        const fieldGate = describeGate(schema, field.visible_when);
        if (fieldGate) desc += ` [requires ${fieldGate}]`;
        lines.push(desc);
      }
    }
    lines.push("");
  }

  // Gate relationship context — tell the AI which multiselect values
  // control which sections/fields so it fills all relevant areas.
  const gateLines = buildGateDescription(schema);
  if (gateLines.length > 0) {
    lines.push(...gateLines);
  }

  // Include existing answers as context, tagging AI-proposed values
  const contextLines = formatExistingAnswers(schema, currentAnswers, { fieldMeta });
  if (contextLines.length > 0) {
    const hasAiValues = contextLines.some((l) => l.includes("(AI-proposed)"));
    lines.push(ANSWERS_SECTION_HEADING);
    if (hasAiValues) {
      lines.push(ANSWERS_SECTION_PREAMBLE);
    }
    lines.push("", ...contextLines);
  }

  // Focus field section: lock proposals to a single field
  if (focusField) {
    const focusSection = selectedSections.find((s) => s.id === focusField.sectionId);
    const field = focusSection?.fields.find(
      (f) => `${focusSection!.id}.${f.id}` === focusField.fieldKey,
    );
    if (field && focusSection) {
      lines.push(`## Focus Field`);
      lines.push(`You can ONLY propose changes to: ${focusField.fieldKey}`);
      lines.push(`Section: ${focusSection.title}`);
      lines.push(`Field: ${field.label}`);
      if (field.ai_hint) lines.push(`Guidance: ${field.ai_hint}`);
      if (field.template_heading) {
        lines.push(`Template heading (already in document): "${field.template_heading}"`);
      }
      if (field.heading_level) {
        lines.push(`Heading level: ${field.heading_level} — use # for immediate sub-headings, ## for sub-sub-headings (the system auto-offsets these to the correct document level)`);
      }
      const focusReserved = getReservedChildOutlines(field, focusSection.fields);
      if (focusReserved.length > 0) {
        lines.push(`Sub-heading restriction: Do NOT use markdown headings (# or ##) in this field. Sections ${focusReserved.join(", ")} already have dedicated template headings. Use **bold text** or bullet lists to organize content instead.`);
      }
      lines.push("");
    }
  }

  lines.push(`## Rules
- Source material is in the user message (in <document> tags or as instruction). Do not ask for additional documents. Documents may carry a \`role\` attribute (e.g. role="pws") assigned by the user; when present, a "Source document guidance" section in the user message explains each role. Follow that guidance when deciding which document is authoritative for a field.
- The uploaded documents are NOT expected to be the same type as the target document. They are reference materials (contracts, proposals, emails, prior agreements, etc.) from which you should INFER relevant values for the target fields. When documents conflict, prefer the one whose assigned role matches the field's subject.
- Analyze the provided documents to extract factual information (names, dates, amounts, terms, parties, etc.) that is relevant to filling the target fields.
- The current field values shown in the Working Draft section are often your own earlier proposals, NOT source material. Never cite them as factual evidence (e.g. "the modification document shows...") and never let a value you proposed earlier become the justification for a later answer. When the user asks whether something is true, re-check the uploaded documents and the template; if they don't say, answer that the sources don't say.
- Produce values ONLY for fields listed above. ${FIELD_TYPE_RULES}
${GROUNDING_RULES.map((r) => `- ${r}`).join("\n")}
- ${FREETEXT_DRAFTING_RULE}
- For freetext fields: do not repeat a heading that the document template already contains above the field (shown as [heading: "..."] in the field listing).
- If a freetext field shows [level: N], always use # for immediate sub-headings and ## for deeper ones — the system automatically offsets them to sit below the parent heading at the correct depth. Include section numbers in heading text (e.g., "# 3.2.1 Provisioning Strategy").
- If a freetext field has a numbered outline (e.g., 3.1), number any sub-headings as extensions (3.1.1, 3.1.2, ...).
- If a freetext field has an unnumbered heading, use the next heading level down for sub-headings.
- If a freetext field shows [no-subheadings: ...], do NOT create any markdown headings (# / ## / ###) — the listed sections already have their own dedicated template headings. Use **bold text**, bullet lists, or plain paragraph breaks to organize content in these introductory/overview fields.`);

  const styleBlock = formatDraftingStyle(draftingStyle);
  if (styleBlock) lines.push("", styleBlock);

  // Add scope awareness when not in full-document scope
  if (selectedSections.length < schema.sections.length && !focusField) {
    lines.push(`
## Scope
You can ONLY propose changes to fields in the sections listed under ## Fields above.
The ## Working Draft section shows other answers for reference only — those fields are not editable in the current scope.
The user's scope may have changed during this conversation. Earlier messages may reference fields from a different section — use that context, but propose changes ONLY to the fields listed under ## Fields above.
If the user's request requires changes to fields outside your current scope:
1. Call \`propose_changes\` for any in-scope fields that need updating.
2. After the tool call, explicitly list which out-of-scope fields also need attention and suggest the user switch to "Entire Document" scope.`);
  }

  lines.push(`
## Template Context
- Use \`get_template_context\` to see the surrounding document text where a field will appear in the output.
- Query by field_key to see the prose around a placeholder, from_line to read from a position, or search to find specific text.
- For document sets, pass \`schema_id\` to specify which document's template to query (the field_key mode auto-detects the schema).
- Responses include a document outline with line numbers for follow-up queries.
- Especially useful when drafting freetext fields — helps match tone, avoid duplicating headings, and understand what content the template expects.
- The template shows the UNFILLED document structure (with {{TAG}} placeholders), not the rendered version.`);

  lines.push(`
## Proposing Changes
IMPORTANT: The \`propose_changes\` tool call is the ONLY way changes reach the user. Describing changes in text alone is NOT sufficient — the user cannot act on text descriptions.

- Whenever you identify specific field values that should be set or updated — whether from extraction, consistency checking, analysis, correction, or any other task — you MUST call \`propose_changes\`.
- You may explain your reasoning briefly BEFORE calling the tool, but always follow through with the tool call.
- Group related fields into each \`propose_changes\` call (roughly 3-6 long narrative fields, more if short) and keep calling it until every in-scope field is covered. Several calls per turn is the expected workflow for long documents.
- For string/number/date/enum/multiselect fields and for table rows, omit when no source states a value and say so. For freetext fields, always propose a draft (see the freetext drafting rule); lower the confidence instead of omitting.
- In follow-up turns, include ONLY changed or new fields.
- **End-of-turn check:** before you write a final reply, re-read the latest tool result. If \`fields_to_draft\` is non-empty, you are not done: call \`propose_changes\` again for those fields. Never summarize remaining fields as a substitute for drafting them. Fields under \`fields_awaiting_source_facts\` may stay empty only when no source states them; list those with the reason.
- Confidence: 0.9-1.0 = directly stated, 0.6-0.8 = inferred, <0.6 = uncertain.
- Only skip the tool call when you genuinely have NO field value changes to suggest (e.g., answering a question, or needing more information before determining values).

## Conflict Detection
- When you detect conflicting or contradictory information between source documents, call \`report_observations\` with type "conflict" to flag the discrepancies. Do this BEFORE or ALONGSIDE \`propose_changes\`.
- Still choose the best value for propose_changes when conflicts exist, but document your rationale in the observation's recommendation field.
- Severity guide: HIGH = contradicts a key fact that changes meaning (dates, amounts, parties); MEDIUM = ambiguous or inconsistent phrasing; LOW = minor discrepancy unlikely to matter.
- If the user explicitly asks you to check for conflicts, perform a thorough cross-document analysis and always call report_observations (with an empty array if none found).
- If a document's content clearly does not match its assigned \`role\` (e.g. a document tagged role="pws" reads like a vendor quote), call \`report_observations\` with type "conflict" naming the document and the role it was given, and recommend moving it to the correct slot. Do not treat it as authoritative for that role's fields; use it only as general reference material.`);

  lines.push(`
## Asking the User
- You can use \`ask_user\` whenever the user's preference or decision would meaningfully shape your response and you can't reasonably infer it.
- Keep questions concise. Batch related questions (up to 4) into one call. When you have a recommendation, put it first and mark it recommended.
- Don't call \`propose_changes\` for something that depends on a pending question in the same turn.`);

  return lines.join("\n");
}

/**
 * Build the initial user message for the chat-based bulk edit flow.
 */
export function buildBulkEditChatUserMessage(request: BulkEditRequest): string {
  const parts: string[] = [];

  // Role guidance goes first so it survives truncation of the document text.
  const guidance = formatSourceDocumentGuidance(request.sourceDocumentRoles);
  if (guidance) {
    parts.push(guidance, "");
  }

  // Include small reference documents as full context
  if (request.referenceDocTexts && request.referenceDocTexts.length > 0) {
    for (const refDoc of request.referenceDocTexts) {
      parts.push(`<document title="${escapeXmlAttr(refDoc.title)}">`);
      parts.push(refDoc.text.slice(0, 50_000));
      parts.push("</document>");
      parts.push("");
    }
  }

  // Include retrieved chunks from large reference documents
  if (request.retrievedChunks && request.retrievedChunks.length > 0) {
    parts.push("The following are relevant excerpts retrieved from large reference documents:");
    parts.push("");
    for (const chunk of request.retrievedChunks) {
      parts.push(`<reference-excerpt source="${escapeXmlAttr(chunk.title)}">`);
      parts.push(chunk.text);
      parts.push("</reference-excerpt>");
      parts.push("");
    }
  }

  if (request.mode === "document" && request.documentText != null && request.documentText.length > 0) {
    parts.push(
      "The user has uploaded reference document(s). The full text content is provided below.",
      "Analyze these documents and infer values for the target fields based on factual information found within them. The documents may be of a different type than the target — extract relevant details (parties, dates, terms, amounts, etc.) that apply to the fields you need to fill.",
      "",
      request.documentText.slice(0, 100_000),
    );
    if (request.prompt && request.prompt.trim().length > 0) {
      parts.push("", "## Additional Instruction", "", request.prompt);
    }
  } else if (request.mode === "document") {
    throw new Error(
      "No text could be extracted from the uploaded document. " +
      "The file may be a scanned image without a text layer. " +
      "Try uploading a .docx or text-based PDF instead.",
    );
  } else {
    parts.push(
      "## User Instruction",
      "",
      request.prompt ?? "Fill in all fields based on available context.",
    );
  }

  return parts.join("\n");
}

// ---------------------------------------------------------------------------
// Change Accumulation (multi-turn)
// ---------------------------------------------------------------------------

/**
 * Merge incoming proposed changes into the existing accumulated set.
 * - Matching fieldKey: replaces the old entry (resets accepted to default)
 * - New fieldKey: appended
 * - Existing entries not in incoming: preserved unchanged
 */
export function accumulateChanges(
  existing: ProposedChange[],
  incoming: ProposedChange[],
): ProposedChange[] {
  const result = [...existing];
  for (const change of incoming) {
    const idx = result.findIndex((c) => c.fieldKey === change.fieldKey);
    if (idx >= 0) {
      result[idx] = change;
    } else {
      result.push(change);
    }
  }
  return result;
}

