import { describe, it, expect, afterEach, vi } from "vitest";
import { buildReviewSystemPrompt, buildDocumentOutline, stripHtmlTags } from "./documentReviewPrompt";
import { GROUNDING_RULES } from "./promptUtils";
import { createMockSchema } from "../test/mocks";

const schema = createMockSchema({ id: "sow", title: "Statement of Work" });

describe("buildReviewSystemPrompt", () => {
  afterEach(() => {
    vi.useRealTimers();
  });

  it("opens with the reviewer persona and today's date", () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-04-01T10:00:00Z"));
    const lines = buildReviewSystemPrompt(schema).split("\n");
    expect(lines[0]).toBe('You are a professional document reviewer analyzing a "Statement of Work".');
    expect(lines[1]).toBe("Today's date is 2026-04-01.");
  });

  it("includes the task, categories, tools and grounding rules", () => {
    const prompt = buildReviewSystemPrompt(schema);
    for (const heading of ["## Your Task", "## Observation Categories", "## Tools", "## Rules"]) {
      expect(prompt).toContain(heading);
    }
    for (const cat of ["conflict", "gap", "assumption", "quality", "placeholder"]) {
      expect(prompt).toContain(`- **${cat}**:`);
    }
    for (const r of GROUNDING_RULES) expect(prompt).toContain(`- ${r}`);
    expect(prompt).toContain("`report_observations`");
  });

  it("omits the document-set block with no source schemas or a single one", () => {
    for (const sources of [undefined, [], [schema]]) {
      const prompt = buildReviewSystemPrompt(schema, sources);
      expect(prompt).not.toContain("## Document Set");
      expect(prompt).not.toContain("pass `schema_id`");
    }
  });

  it("lists each set member with its template type", () => {
    const word = createMockSchema({ id: "a", title: "Doc A", docx_template: "a.docx" });
    const md = createMockSchema({ id: "b", title: "Doc B", output_template: "# B" });
    const none = createMockSchema({ id: "c", title: "Doc C" });
    const prompt = buildReviewSystemPrompt(schema, [word, md, none]);
    expect(prompt).toContain("pass `schema_id` to specify which document's template");
    expect(prompt).toContain("## Document Set");
    expect(prompt).toContain('- `a` — "Doc A" (Word)');
    expect(prompt).toContain('- `b` — "Doc B" (Markdown)');
    expect(prompt).toContain('- `c` — "Doc C" (no template)');
  });

  it("appends a trimmed drafting style block last", () => {
    const prompt = buildReviewSystemPrompt(schema, undefined, "  Use bullets.  ");
    expect(prompt.endsWith("\nUse bullets.")).toBe(true);
    expect(prompt).toContain("## Drafting Style");
  });

  it("places the drafting style after the document set", () => {
    const a = createMockSchema({ id: "a", title: "A" });
    const b = createMockSchema({ id: "b", title: "B" });
    const prompt = buildReviewSystemPrompt(schema, [a, b], "Terse.");
    expect(prompt.indexOf("## Drafting Style")).toBeGreaterThan(prompt.indexOf("## Document Set"));
  });

  it("omits the style block for blank notes", () => {
    expect(buildReviewSystemPrompt(schema, undefined, "   ")).not.toContain("## Drafting Style");
  });
});

describe("buildDocumentOutline", () => {
  it("indents markdown headings by level", () => {
    const md = "# Title\ntext\n## Sub  \n###### Deep\n#NoSpace\n####### seven";
    expect(buildDocumentOutline(md, "markdown")).toBe(
      "- Title\n  - Sub\n          - Deep",
    );
  });

  it("reports when no headings exist", () => {
    expect(buildDocumentOutline("just text", "markdown")).toBe("(No headings found in document)");
    expect(buildDocumentOutline("just text\nmore", "text")).toBe("(No headings found in document)");
    expect(buildDocumentOutline("", "text")).toBe("(No headings found in document)");
  });

  it("detects numbered headings with depth from dot count", () => {
    const text = "1 Introduction\nbody\n4.3 Maintenance Planning\n  4.3.1 Detail\n2.Nope";
    expect(buildDocumentOutline(text, "text")).toBe(
      "- 1 Introduction\n  - 4.3 Maintenance Planning\n    - 4.3.1 Detail",
    );
  });

  it("does not treat '1. Title' (trailing dot) as a numbered heading", () => {
    expect(buildDocumentOutline("1. Introduction", "text")).toBe("(No headings found in document)");
  });

  it("detects ALL-CAPS lines but not short, lowercase, digit-only or table rows", () => {
    const text = "SCOPE OF WORK\nAB\nNormal line\n| COL | COL |\n123-456\nPHASE 2: GO";
    expect(buildDocumentOutline(text, "text")).toBe("- SCOPE OF WORK\n- PHASE 2: GO");
  });
});

describe("stripHtmlTags", () => {
  it("converts block boundaries to newlines and removes tags", () => {
    const html = "<h1>Title</h1><p>One<br>Two<br/>Three</p><ul><li>a</li><li>b</li></ul>";
    expect(stripHtmlTags(html)).toBe("Title\n\nOne\nTwo\nThree\n\na\nb");
  });

  it("strips nested and attributed tags", () => {
    expect(stripHtmlTags('<p class="x"><strong><em>Bold</em></strong> text</p>')).toBe("Bold text");
  });

  it("emits a newline per table row", () => {
    expect(stripHtmlTags("<table><tr><td>a</td><td>b</td></tr><tr><td>c</td></tr></table>")).toBe("ab\nc");
  });

  it("decodes common entities", () => {
    expect(stripHtmlTags("<p>A &amp; B &lt;c&gt; &quot;d&quot; &#39;e&#39;&nbsp;f</p>")).toBe(
      "A & B <c> \"d\" 'e' f",
    );
  });

  it("decodes an escaped entity only once", () => {
    expect(stripHtmlTags("&amp;lt;")).toBe("&lt;");
  });

  it("collapses 3+ newlines and trims", () => {
    expect(stripHtmlTags("<p>a</p><p></p><p>b</p>\n\n")).toBe("a\n\nb");
  });
});
