/**
 * Feature flags for SDK-unlocked AI capabilities, plus the AskSage gate.
 *
 * All features default to enabled except `askSage`. If the LiteLLM proxy rejects a feature
 * (400 error), it is auto-disabled for the current session and a console
 * warning is logged. Persisted flags can be changed with setFeatureFlags().
 */

export interface AiFeatureFlags {
  promptCaching: boolean;
  effort: boolean;
  structuredOutputs: boolean;
  thinking: boolean;
  tokenCounting: boolean;
  /**
   * SharePoint / OneDrive search through AskSage. Off until the AskSage team
   * approves it — see the STATUS block at the top of src/ai/asksage.ts before
   * changing this default or deleting the AskSage code.
   */
  askSage: boolean;
}

const STORAGE_KEY = "doc-builder:ai-feature-flags";

const DEFAULTS: AiFeatureFlags = {
  promptCaching: true,
  effort: true,
  structuredOutputs: true,
  thinking: true,
  tokenCounting: true,
  askSage: false,
};

/** Session-local overrides (auto-disabled features that failed at runtime). */
const sessionOverrides: Partial<AiFeatureFlags> = {};

/** One-time warning tracker to avoid spamming the console. */
const warned = new Set<string>();

/** Flags saved in localStorage, without session overrides. A corrupt value falls back to the defaults. */
function getPersistedFlags(): AiFeatureFlags {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (!stored) return { ...DEFAULTS };
  try {
    return { ...DEFAULTS, ...JSON.parse(stored) };
  } catch {
    return { ...DEFAULTS };
  }
}

/**
 * Get the current feature flags (persisted + session overrides merged).
 */
export function getFeatureFlags(): AiFeatureFlags {
  return { ...getPersistedFlags(), ...sessionOverrides };
}

/**
 * Persist updated feature flags to localStorage. Session-only auto-disables
 * are not persisted.
 */
export function setFeatureFlags(flags: Partial<AiFeatureFlags>): void {
  const merged = { ...getPersistedFlags(), ...flags };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
}

/**
 * Auto-disable a feature for the current session (proxy rejected it).
 * Logs a console warning once per feature.
 */
export function disableFeatureForSession(
  feature: keyof AiFeatureFlags,
  reason?: string,
): void {
  sessionOverrides[feature] = false;
  if (!warned.has(feature)) {
    warned.add(feature);
    console.warn(
      `[AI] Feature "${feature}" disabled for this session${reason ? `: ${reason}` : " (proxy returned 400)"}. ` +
        `It will be retried after the page is reloaded.`,
    );
  }
}

/**
 * Check if a specific feature is currently enabled.
 */
export function isFeatureEnabled(feature: keyof AiFeatureFlags): boolean {
  return getFeatureFlags()[feature];
}
