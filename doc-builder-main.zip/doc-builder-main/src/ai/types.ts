/** Message format for the OpenAI-compatible chat completions API. */
export interface LiteLLMMessage {
  role: "system" | "user" | "assistant" | "tool";
  content: string | null;
  /** Tool calls made by the assistant (present when role=assistant). */
  tool_calls?: ToolCall[];
  /** For tool role: the ID of the tool call this result corresponds to. */
  tool_call_id?: string;
}

/** A tool call from the assistant. */
export interface ToolCall {
  id: string;
  type: "function";
  function: {
    name: string;
    arguments: string;
  };
}

/** Tool definition (Anthropic format). */
export interface ToolDefinition {
  name: string;
  description: string;
  input_schema: {
    type: "object";
    properties: Record<string, unknown>;
    required?: string[];
    [key: string]: unknown;
  };
}

/** Why the model stopped generating (mirrors Anthropic `stop_reason`). */
export type StopReason =
  | "end_turn"
  | "max_tokens"
  | "stop_sequence"
  | "tool_use"
  | "pause_turn"
  | "refusal"
  | (string & {});

/** Metadata about how a streamed response terminated. */
export interface StreamMeta {
  /** The response's `stop_reason`, if the SDK reported one. */
  stopReason?: StopReason | null;
}

/** Callbacks for streaming token delivery. */
export interface StreamCallbacks {
  onToken: (token: string) => void;
  onDone: (fullText: string) => void;
  onError: (error: Error) => void;
  /** Called when the model issues tool call(s) (finish_reason === "tool_calls"). */
  onToolCall?: (call: ToolCall) => void;
  /** Called when the model issues multiple tool calls in one response. */
  onToolCalls?: (calls: ToolCall[], meta?: StreamMeta) => void;
  /** Called when thinking content is streamed (for UI indicators). */
  onThinking?: (delta: string) => void;
  /** Called when a thinking block completes. */
  onThinkingDone?: () => void;
  /** Called with usage stats after each response completes. */
  onUsage?: (usage: TokenUsage) => void;
}

// ---------------------------------------------------------------------------
// Response timing
// ---------------------------------------------------------------------------

/** Timing breakdown attached to each assistant message in a response sequence. */
export interface ResponseTimings {
  /** Wall-clock total (ms) from user send to final onDone. Only present on the final message. */
  totalMs?: number;
  /** Steps that completed before this message was produced. */
  steps: ResponseStep[];
  /** Token usage for the response sequence (promptTokens = context size of the last call). */
  usage?: {
    promptTokens: number;
    completionTokens: number;
    cacheReadTokens?: number;
  };
  /**
   * Usage of the single LLM call that produced this message. Present on every
   * assistant message, including intermediate tool-call messages, so a
   * troubleshoot export shows per-call context size across a tool cycle.
   */
  callUsage?: {
    /** Uncached input tokens. With prompt caching on, this excludes the cached prefix. */
    promptTokens: number;
    completionTokens: number;
    cacheReadTokens?: number;
    cacheCreationTokens?: number;
  };
}

export interface ResponseStep {
  kind: "thinking" | "generating" | "searching" | "tool_processing";
  /** Duration in milliseconds. */
  durationMs: number;
  /** Optional label (e.g., search query text). */
  label?: string;
}

/** Token usage statistics from an API response. */
export interface TokenUsage {
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
  /** Tokens read from prompt cache (0 if caching inactive). */
  cacheReadTokens?: number;
  /** Tokens written to prompt cache on this request. */
  cacheCreationTokens?: number;
}

/** Options for streaming chat completion. */
export interface StreamOptions {
  /** Model override (defaults to Sonnet). */
  model?: string;
  /** Max tokens for the response (default 4096). */
  maxTokens?: number;
  /** Tool definitions to make available to the model. */
  tools?: ToolDefinition[];
  /** Effort level: "low" for extraction (speed), "high" for drafting (quality). */
  effort?: "low" | "medium" | "high";
  /** Enable prompt caching via cache_control on system prompt. Defaults to true. */
  enableCaching?: boolean;
  /** Force a specific tool call (for extraction mode). */
  toolChoice?: "auto" | { type: "tool"; name: string };
  /** Enable extended thinking for quality-sensitive drafting. */
  enableThinking?: boolean;
  /** Budget tokens for thinking (default 10000). Only used when enableThinking is true. */
  thinkingBudget?: number;
  /**
   * Timeout (ms) for receiving data during streaming.
   * Two phases: initial wait (time-to-first-event) uses 2× this value to accommodate
   * model queuing/thinking. After the first event, resets to 1× on each chunk.
   * Default: 90_000 (90s inter-chunk, 180s initial).
   */
  streamTimeout?: number;
}
