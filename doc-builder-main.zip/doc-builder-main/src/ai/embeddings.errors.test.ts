import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { createEmbeddings } from "./embeddings";
import { ACTIVE_ENDPOINT_KEY, apiKeyStorageKey } from "./endpoints";
import { isAppErrorException } from "../errors";

function response(status: number, body = "") {
  return { ok: status < 400, status, text: async () => body, json: async () => ({ data: [{ embedding: [1], index: 0 }] }) };
}

async function kindOf(p: Promise<unknown>): Promise<string> {
  try {
    await p;
  } catch (err) {
    if (isAppErrorException(err)) return err.appError.kind;
    throw err;
  }
  throw new Error("expected rejection");
}

describe("createEmbeddings error handling", () => {
  let fetchMock: ReturnType<typeof vi.fn>;

  beforeEach(() => {
    vi.useFakeTimers();
    localStorage.clear();
    localStorage.setItem(apiKeyStorageKey("non-cui"), "test-key");
    localStorage.setItem(ACTIVE_ENDPOINT_KEY, "non-cui");
    fetchMock = vi.fn();
    vi.stubGlobal("fetch", fetchMock);
  });

  afterEach(() => {
    vi.useRealTimers();
    vi.unstubAllGlobals();
  });

  it("throws ai.no-key without a key", async () => {
    localStorage.clear();
    expect(await kindOf(createEmbeddings(["a"]))).toBe("ai.no-key");
  });

  it.each([
    [401, "", "ai.auth"],
    [400, '{"error":{"message":"input too large"}}', "ai.bad-request"],
    [404, "", "ai.model-unavailable"],
  ])("does not retry HTTP %i (→ %s)", async (status, body, kind) => {
    fetchMock.mockResolvedValue(response(status, body));
    expect(await kindOf(createEmbeddings(["a"]))).toBe(kind);
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it("retries 5xx and reports ai.server after exhausting retries", async () => {
    fetchMock.mockResolvedValue(response(503, "upstream down"));
    const result = kindOf(createEmbeddings(["a"]));
    await vi.runAllTimersAsync();
    expect(await result).toBe("ai.server");
    expect(fetchMock).toHaveBeenCalledTimes(3);
  });

  it("recovers when a retry succeeds", async () => {
    fetchMock.mockResolvedValueOnce(response(502)).mockResolvedValueOnce(response(200));
    const result = createEmbeddings(["a"]);
    await vi.runAllTimersAsync();
    await expect(result).resolves.toEqual([[1]]);
  });

  it("retries network failures as ai.network", async () => {
    fetchMock.mockRejectedValue(new TypeError("Failed to fetch"));
    const result = kindOf(createEmbeddings(["a"]));
    await vi.runAllTimersAsync();
    expect(await result).toBe("ai.network");
    expect(fetchMock).toHaveBeenCalledTimes(3);
  });
});
