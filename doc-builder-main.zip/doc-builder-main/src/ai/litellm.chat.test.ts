/**
 * Characterization tests for the Anthropic-SDK calls in litellm.ts:
 * fetchChatCompletion, streamChatCompletion, countTokens, and the config getters.
 */
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";

vi.mock("@anthropic-ai/sdk", async (importOriginal) => {
  const { mockAnthropicModule } = await import("../test/mockAnthropic");
  return mockAnthropicModule(await importOriginal());
});

import Anthropic from "@anthropic-ai/sdk";
import type { MessageStreamEvent } from "@anthropic-ai/sdk/resources/messages";
import {
  anthropicMocks,
  fakeStream,
  message,
  resetAnthropicMocks,
  textBlock,
  textDeltaEvents,
  toolUseBlock,
} from "../test/mockAnthropic";
import {
  countTokens,
  fetchChatCompletion,
  getApiKey,
  getLitellmEndpoint,
  getLitellmModelAdvanced,
  getLitellmModelStandard,
  setApiKey,
  streamChatCompletion,
} from "./litellm";
import { ACTIVE_ENDPOINT_KEY, ENDPOINTS, getResolvedBaseUrl } from "./endpoints";
import { _resetModelsForTests, resolveModel, setDiscoveredModels, setModelOverride } from "./models";
import { getFeatureFlags, setFeatureFlags } from "./featureFlags";
import { isAppErrorException, type AppErrorException } from "../errors";
import type { LiteLLMMessage, StreamCallbacks, ToolDefinition } from "./types";

const STANDARD = ENDPOINTS["non-cui"].models.standard;
const ADVANCED = ENDPOINTS["non-cui"].models.advanced;

const MSGS: LiteLLMMessage[] = [
  { role: "system", content: "You are helpful." },
  { role: "user", content: "Hello" },
];

const TOOL: ToolDefinition = {
  name: "set_answers",
  description: "Set answers",
  input_schema: { type: "object", properties: { a: { type: "string" } }, required: ["a"] },
};

function authError() {
  return new Anthropic.AuthenticationError(401, { error: { message: "bad key" } }, "bad key", new Headers());
}
function badRequest(msg: string) {
  return new Anthropic.BadRequestError(400, { error: { message: msg } }, msg, new Headers());
}
function serverError() {
  return new Anthropic.InternalServerError(500, { error: { message: "boom" } }, "boom", new Headers());
}

async function rejection(p: Promise<unknown>): Promise<unknown> {
  try {
    await p;
  } catch (e) {
    return e;
  }
  throw new Error("expected rejection");
}

/** Callbacks whose calls are recorded in `log` for ordering assertions. */
function recorder(extra: Partial<StreamCallbacks> = {}) {
  const log: string[] = [];
  let resolve!: () => void;
  const done = new Promise<void>((r) => (resolve = r));
  const cb: StreamCallbacks = {
    onToken: vi.fn((t: string) => void log.push(`token:${t}`)),
    onDone: vi.fn((full: string) => {
      log.push(`done:${full}`);
      resolve();
    }),
    onError: vi.fn((e: Error) => {
      log.push(`error:${(e as AppErrorException).appError?.kind ?? e.message}`);
      resolve();
    }),
    onUsage: vi.fn(() => void log.push("usage")),
    ...extra,
  };
  return { log, done, cb };
}

const flush = () => new Promise((r) => setTimeout(r, 20));

beforeEach(() => {
  resetAnthropicMocks();
  _resetModelsForTests();
  setApiKey("sk-test");
  vi.spyOn(console, "warn").mockImplementation(() => {});
});

afterEach(() => {
  vi.useRealTimers();
  vi.restoreAllMocks();
});

// ---------------------------------------------------------------------------
// Getters / setters
// ---------------------------------------------------------------------------

describe("config getters", () => {
  it("stores the API key per active endpoint", () => {
    expect(getApiKey()).toBe("sk-test");
    localStorage.setItem(ACTIVE_ENDPOINT_KEY, "cui");
    expect(getApiKey()).toBeNull();
    setApiKey("sk-cui");
    expect(getApiKey()).toBe("sk-cui");
    localStorage.setItem(ACTIVE_ENDPOINT_KEY, "non-cui");
    expect(getApiKey()).toBe("sk-test");
  });

  it("returns the active endpoint's base URL and resolved models", () => {
    expect(getLitellmEndpoint()).toBe(ENDPOINTS["non-cui"].baseUrl);
    expect(getLitellmModelStandard()).toBe(STANDARD);
    expect(getLitellmModelAdvanced()).toBe(ADVANCED);
    localStorage.setItem(ACTIVE_ENDPOINT_KEY, "cui");
    expect(getLitellmEndpoint()).toBe(ENDPOINTS.cui.baseUrl);
    expect(getLitellmModelStandard()).toBe(ENDPOINTS.cui.models.standard);
  });

  it("reflects a user override and a discovered-model substitution", () => {
    setModelOverride("non-cui", "standard", "my-model");
    expect(getLitellmModelStandard()).toBe("my-model");
    setDiscoveredModels("non-cui", ["claude-opus-9-9-aws-comm-il2"]);
    expect(getLitellmModelAdvanced()).toBe("claude-opus-9-9-aws-comm-il2");
  });
});

// ---------------------------------------------------------------------------
// fetchChatCompletion
// ---------------------------------------------------------------------------

describe("fetchChatCompletion", () => {
  it("throws ai.no-key without calling the SDK when no key is set", async () => {
    localStorage.clear();
    const err = await rejection(fetchChatCompletion(MSGS));
    expect(isAppErrorException(err) && err.appError.kind).toBe("ai.no-key");
    expect(anthropicMocks.create).not.toHaveBeenCalled();
    expect(anthropicMocks.constructed).toHaveLength(0);
  });

  it("constructs the client with the proxy URL and key, and sends the default request", async () => {
    anthropicMocks.create.mockResolvedValue(message({ content: [textBlock("Hi")] }));
    await fetchChatCompletion(MSGS);

    expect(anthropicMocks.constructed).toEqual([
      { baseURL: `${window.location.origin}${getResolvedBaseUrl()}`, apiKey: "sk-test", dangerouslyAllowBrowser: true },
    ]);
    const [params, opts] = anthropicMocks.create.mock.calls[0];
    expect(params).toEqual({
      model: STANDARD,
      max_tokens: 16384,
      system: [{ type: "text", text: "You are helpful.", cache_control: { type: "ephemeral" } }],
      messages: [{ role: "user", content: "Hello" }],
    });
    expect(opts).toEqual({ signal: undefined });
  });

  it("honours model, maxTokens, effort and signal options", async () => {
    anthropicMocks.create.mockResolvedValue(message({ content: [textBlock("x")] }));
    const ctrl = new AbortController();
    await fetchChatCompletion(MSGS, { model: "m-1", maxTokens: 100, effort: "low", signal: ctrl.signal });
    const [params, opts] = anthropicMocks.create.mock.calls[0];
    expect(params).toMatchObject({ model: "m-1", max_tokens: 100, output_config: { effort: "low" } });
    expect(opts?.signal).toBe(ctrl.signal);
  });

  it("does not send tools or tool_choice (jsonMode is accepted but ignored)", async () => {
    anthropicMocks.create.mockResolvedValue(message({ content: [textBlock("{}")] }));
    await fetchChatCompletion(MSGS, { jsonMode: true });
    const [params] = anthropicMocks.create.mock.calls[0];
    expect(params).not.toHaveProperty("tools");
    expect(params).not.toHaveProperty("tool_choice");
    expect(params).not.toHaveProperty("response_format");
  });

  it("omits system when there is no system message", async () => {
    anthropicMocks.create.mockResolvedValue(message({ content: [textBlock("x")] }));
    await fetchChatCompletion([{ role: "user", content: "Q" }]);
    expect(anthropicMocks.create.mock.calls[0][0]).not.toHaveProperty("system");
  });

  it("sends system as a plain string when promptCaching is off", async () => {
    setFeatureFlags({ promptCaching: false });
    anthropicMocks.create.mockResolvedValue(message({ content: [textBlock("x")] }));
    await fetchChatCompletion(MSGS);
    expect(anthropicMocks.create.mock.calls[0][0].system).toBe("You are helpful.");
  });

  it("drops output_config when the effort flag is off", async () => {
    setFeatureFlags({ effort: false });
    anthropicMocks.create.mockResolvedValue(message({ content: [textBlock("x")] }));
    await fetchChatCompletion(MSGS, { effort: "high" });
    expect(anthropicMocks.create.mock.calls[0][0]).not.toHaveProperty("output_config");
  });

  it("translates tool calls/results, merges same-role turns and joins multiple system messages", async () => {
    anthropicMocks.create.mockResolvedValue(message({ content: [textBlock("x")] }));
    setFeatureFlags({ promptCaching: false });
    await fetchChatCompletion([
      { role: "system", content: "A" },
      { role: "system", content: "B" },
      { role: "user", content: "u1" },
      {
        role: "assistant",
        content: "calling",
        tool_calls: [
          { id: "t1", type: "function", function: { name: "f", arguments: '{"x":1}' } },
          { id: "t2", type: "function", function: { name: "g", arguments: "not json" } },
        ],
      },
      { role: "tool", tool_call_id: "t1", content: "r1" },
      { role: "tool", tool_call_id: "t2", content: "r2" },
      { role: "user", content: "u2" },
    ]);
    const params = anthropicMocks.create.mock.calls[0][0];
    expect(params.system).toBe("A\n\nB");
    expect(params.messages).toEqual([
      { role: "user", content: "u1" },
      {
        role: "assistant",
        content: [
          { type: "text", text: "calling" },
          { type: "tool_use", id: "t1", name: "f", input: { x: 1 } },
          { type: "tool_use", id: "t2", name: "g", input: { _raw: "not json" } },
        ],
      },
      {
        role: "user",
        content: [
          { type: "tool_result", tool_use_id: "t1", content: "r1" },
          { type: "tool_result", tool_use_id: "t2", content: "r2" },
          { type: "text", text: "u2" },
        ],
      },
    ]);
  });

  it("maps the response: joined text blocks, usage with cache metrics, response model and stop reason", async () => {
    anthropicMocks.create.mockResolvedValue(
      message({
        model: "served-model",
        content: [textBlock("Hello "), toolUseBlock("ignored", {}), textBlock("world")],
        usage: { input_tokens: 100, output_tokens: 20, cache_read_input_tokens: 80, cache_creation_input_tokens: 5 },
      }),
    );
    expect(await fetchChatCompletion(MSGS)).toEqual({
      content: "Hello world",
      model: "served-model",
      usage: { promptTokens: 100, completionTokens: 20, totalTokens: 120, cacheReadTokens: 80, cacheCreationTokens: 5 },
      stopReason: "end_turn",
    });
  });

  it("reports stopReason max_tokens when the response was cut off", async () => {
    anthropicMocks.create.mockResolvedValue({ ...message({ content: [textBlock("partial")] }), stop_reason: "max_tokens" });
    expect((await fetchChatCompletion(MSGS)).stopReason).toBe("max_tokens");
  });

  it("defaults null cache metrics to 0 and handles a missing usage object", async () => {
    anthropicMocks.create.mockResolvedValueOnce(message({ content: [textBlock("a")] }));
    expect((await fetchChatCompletion(MSGS)).usage).toEqual({
      promptTokens: 10,
      completionTokens: 5,
      totalTokens: 15,
      cacheReadTokens: 0,
      cacheCreationTokens: 0,
    });
    anthropicMocks.create.mockResolvedValueOnce({ ...message({ content: [textBlock("a")] }), usage: undefined });
    expect((await fetchChatCompletion(MSGS)).usage).toBeNull();
  });

  it("throws ai.auth on 401 without retrying", async () => {
    anthropicMocks.create.mockRejectedValue(authError());
    const err = await rejection(fetchChatCompletion(MSGS));
    expect(isAppErrorException(err) && err.appError.kind).toBe("ai.auth");
    expect(anthropicMocks.create).toHaveBeenCalledTimes(1);
  });

  it("throws ai.bad-request on 400 without retrying or disabling features", async () => {
    anthropicMocks.create.mockRejectedValue(badRequest("output_config: unsupported"));
    const err = await rejection(fetchChatCompletion(MSGS, { effort: "low" }));
    expect(isAppErrorException(err) && err.appError.kind).toBe("ai.bad-request");
    expect(anthropicMocks.create).toHaveBeenCalledTimes(1);
    // Unlike streamChatCompletion, the non-streaming path never auto-disables
    expect(getFeatureFlags().effort).toBe(true);
  });

  it("throws ai.rate-limit on 429 without retrying", async () => {
    anthropicMocks.create.mockRejectedValue(new Anthropic.RateLimitError(429, undefined, "slow", new Headers()));
    const err = await rejection(fetchChatCompletion(MSGS));
    expect(isAppErrorException(err) && err.appError.kind).toBe("ai.rate-limit");
    expect(anthropicMocks.create).toHaveBeenCalledTimes(1);
  });

  it("marks the model unavailable on a model-not-found error so the next call substitutes", async () => {
    setDiscoveredModels("non-cui", [STANDARD, "claude-sonnet-9-9-aws-comm-il2"]);
    anthropicMocks.create.mockRejectedValue(new Anthropic.NotFoundError(404, undefined, "Not Found", new Headers()));
    const err = await rejection(fetchChatCompletion(MSGS));
    expect(isAppErrorException(err) && err.appError.kind).toBe("ai.model-unavailable");
    expect(anthropicMocks.create).toHaveBeenCalledTimes(1);
    expect(resolveModel("non-cui", "standard")).toBe("claude-sonnet-9-9-aws-comm-il2");
  });

  it("retries 5xx twice with backoff, then throws ai.server", async () => {
    vi.useFakeTimers();
    anthropicMocks.create.mockRejectedValue(serverError());
    const p = fetchChatCompletion(MSGS);
    const settled = rejection(p);
    await vi.advanceTimersByTimeAsync(1_499);
    expect(anthropicMocks.create).toHaveBeenCalledTimes(1);
    await vi.advanceTimersByTimeAsync(1);
    expect(anthropicMocks.create).toHaveBeenCalledTimes(2);
    await vi.advanceTimersByTimeAsync(3_000);
    expect(anthropicMocks.create).toHaveBeenCalledTimes(3);
    const err = await settled;
    expect(isAppErrorException(err) && err.appError.kind).toBe("ai.server");
  });

  it("succeeds on a retry after a transient network error", async () => {
    vi.useFakeTimers();
    anthropicMocks.create
      .mockRejectedValueOnce(new Anthropic.APIConnectionError({ cause: new TypeError("Failed to fetch") }))
      .mockResolvedValueOnce(message({ content: [textBlock("ok")] }));
    const p = fetchChatCompletion(MSGS);
    await vi.advanceTimersByTimeAsync(1_500);
    expect((await p).content).toBe("ok");
    expect(anthropicMocks.create).toHaveBeenCalledTimes(2);
  });

  it("rethrows an SDK abort error as-is", async () => {
    const abortErr = new Anthropic.APIUserAbortError();
    anthropicMocks.create.mockRejectedValue(abortErr);
    expect(await rejection(fetchChatCompletion(MSGS))).toBe(abortErr);
    expect(anthropicMocks.create).toHaveBeenCalledTimes(1);
  });

  it("throws a DOMException AbortError before calling the SDK when the signal is already aborted", async () => {
    const ctrl = new AbortController();
    ctrl.abort();
    const err = await rejection(fetchChatCompletion(MSGS, { signal: ctrl.signal }));
    expect(err).toBeInstanceOf(DOMException);
    expect((err as DOMException).name).toBe("AbortError");
    expect(anthropicMocks.create).not.toHaveBeenCalled();
  });

  it("stops retrying when the signal aborts during backoff", async () => {
    vi.useFakeTimers();
    const ctrl = new AbortController();
    anthropicMocks.create.mockRejectedValue(serverError());
    const settled = rejection(fetchChatCompletion(MSGS, { signal: ctrl.signal }));
    await vi.advanceTimersByTimeAsync(0);
    ctrl.abort();
    await vi.advanceTimersByTimeAsync(1_500);
    expect((await settled as DOMException).name).toBe("AbortError");
    expect(anthropicMocks.create).toHaveBeenCalledTimes(1);
  });
});

// ---------------------------------------------------------------------------
// streamChatCompletion
// ---------------------------------------------------------------------------

describe("streamChatCompletion", () => {
  it("reports ai.no-key asynchronously and returns a controller", async () => {
    localStorage.clear();
    const r = recorder();
    const ctrl = streamChatCompletion(MSGS, r.cb);
    expect(ctrl).toBeInstanceOf(AbortController);
    expect(r.cb.onError).not.toHaveBeenCalled();
    await r.done;
    expect(r.log).toEqual(["error:ai.no-key"]);
    expect(anthropicMocks.stream).not.toHaveBeenCalled();
  });

  it("sends the default request with the controller's signal", async () => {
    anthropicMocks.stream.mockImplementation(() => fakeStream([], message({ content: [] })));
    const r = recorder();
    const ctrl = streamChatCompletion(MSGS, r.cb);
    await r.done;
    expect(anthropicMocks.constructed[0]).toMatchObject({ apiKey: "sk-test", dangerouslyAllowBrowser: true });
    const [params, opts] = anthropicMocks.stream.mock.calls[0];
    expect(params).toEqual({
      model: STANDARD,
      max_tokens: 4096,
      system: [{ type: "text", text: "You are helpful.", cache_control: { type: "ephemeral" } }],
      messages: [{ role: "user", content: "Hello" }],
    });
    expect(opts?.signal).toBe(ctrl.signal);
  });

  it("passes tools as raw JSON schema and a forced tool_choice", async () => {
    anthropicMocks.stream.mockImplementation(() => fakeStream([], message()));
    const r = recorder();
    streamChatCompletion(MSGS, r.cb, {
      model: ADVANCED,
      maxTokens: 999,
      tools: [TOOL],
      toolChoice: { type: "tool", name: "set_answers" },
      effort: "high",
    });
    await r.done;
    const [params] = anthropicMocks.stream.mock.calls[0];
    expect(params).toMatchObject({
      model: ADVANCED,
      max_tokens: 999,
      tools: [{ name: TOOL.name, description: TOOL.description, input_schema: TOOL.input_schema }],
      tool_choice: { type: "tool", name: "set_answers" },
      output_config: { effort: "high" },
    });
  });

  it("omits tool_choice for 'auto' and when structuredOutputs is off; omits tools when empty", async () => {
    anthropicMocks.stream.mockImplementation(() => fakeStream([], message()));
    let r = recorder();
    streamChatCompletion(MSGS, r.cb, { tools: [], toolChoice: "auto" });
    await r.done;
    expect(anthropicMocks.stream.mock.calls[0][0]).not.toHaveProperty("tools");
    expect(anthropicMocks.stream.mock.calls[0][0]).not.toHaveProperty("tool_choice");

    setFeatureFlags({ structuredOutputs: false });
    r = recorder();
    streamChatCompletion(MSGS, r.cb, { tools: [TOOL], toolChoice: { type: "tool", name: "set_answers" } });
    await r.done;
    expect(anthropicMocks.stream.mock.calls[1][0]).toHaveProperty("tools");
    expect(anthropicMocks.stream.mock.calls[1][0]).not.toHaveProperty("tool_choice");
  });

  it("thinking replaces effort and adds the budget to max_tokens", async () => {
    anthropicMocks.stream.mockImplementation(() => fakeStream([], message()));
    const r = recorder();
    streamChatCompletion(MSGS, r.cb, { enableThinking: true, thinkingBudget: 2000, maxTokens: 1000, effort: "high" });
    await r.done;
    const [params] = anthropicMocks.stream.mock.calls[0];
    expect(params).toMatchObject({ max_tokens: 3000, thinking: { type: "enabled", budget_tokens: 2000 } });
    expect(params).not.toHaveProperty("output_config");
  });

  it("drops thinking and effort when their flags are off", async () => {
    setFeatureFlags({ thinking: false, effort: false });
    anthropicMocks.stream.mockImplementation(() => fakeStream([], message()));
    const r = recorder();
    streamChatCompletion(MSGS, r.cb, { enableThinking: true, effort: "high", maxTokens: 1000 });
    await r.done;
    const [params] = anthropicMocks.stream.mock.calls[0];
    expect(params.max_tokens).toBe(1000);
    expect(params).not.toHaveProperty("thinking");
    expect(params).not.toHaveProperty("output_config");
  });

  it("sends system as a string when enableCaching is false", async () => {
    anthropicMocks.stream.mockImplementation(() => fakeStream([], message()));
    const r = recorder();
    streamChatCompletion(MSGS, r.cb, { enableCaching: false });
    await r.done;
    expect(anthropicMocks.stream.mock.calls[0][0].system).toBe("You are helpful.");
  });

  it("honours the promptCaching flag when enableCaching is not given", async () => {
    setFeatureFlags({ promptCaching: false });
    anthropicMocks.stream.mockImplementation(() => fakeStream([], message()));
    const r = recorder();
    streamChatCompletion(MSGS, r.cb);
    await r.done;
    expect(anthropicMocks.stream.mock.calls[0][0].system).toBe("You are helpful.");
  });

  it("an explicit enableCaching: true still wins over the flag being off", async () => {
    setFeatureFlags({ promptCaching: false });
    anthropicMocks.stream.mockImplementation(() => fakeStream([], message()));
    const r = recorder();
    streamChatCompletion(MSGS, r.cb, { enableCaching: true });
    await r.done;
    expect(anthropicMocks.stream.mock.calls[0][0].system).toEqual([
      expect.objectContaining({ type: "text", text: "You are helpful.", cache_control: { type: "ephemeral" } }),
    ]);
  });

  it("streams text deltas, then reports usage, then onDone with the full text", async () => {
    anthropicMocks.stream.mockImplementation(() =>
      fakeStream(
        textDeltaEvents("Hel", "lo"),
        message({
          content: [textBlock("Hello")],
          usage: { input_tokens: 50, output_tokens: 7, cache_read_input_tokens: 40, cache_creation_input_tokens: 2 },
        }),
      ),
    );
    const r = recorder();
    streamChatCompletion(MSGS, r.cb);
    await r.done;
    expect(r.log).toEqual(["token:Hel", "token:lo", "usage", "done:Hello"]);
    expect(r.cb.onUsage).toHaveBeenCalledWith({
      promptTokens: 50,
      completionTokens: 7,
      totalTokens: 57,
      cacheReadTokens: 40,
      cacheCreationTokens: 2,
    });
  });

  it("maps tool_use blocks to onToolCalls with the stop reason (no onDone)", async () => {
    anthropicMocks.stream.mockImplementation(() =>
      fakeStream(
        textDeltaEvents("Let me "),
        message({
          content: [textBlock("Let me "), toolUseBlock("set_answers", { a: "1" }, "tu1"), toolUseBlock("other", {}, "tu2")],
          stop_reason: "tool_use",
        }),
      ),
    );
    const onToolCalls = vi.fn();
    const r = recorder({ onToolCalls });
    streamChatCompletion(MSGS, r.cb);
    await vi.waitFor(() => expect(onToolCalls).toHaveBeenCalled());
    expect(r.log).toEqual(["token:Let me ", "usage"]);
    expect(onToolCalls).toHaveBeenCalledWith(
      [
        { id: "tu1", type: "function", function: { name: "set_answers", arguments: '{"a":"1"}' } },
        { id: "tu2", type: "function", function: { name: "other", arguments: "{}" } },
      ],
      { stopReason: "tool_use" },
    );
    expect(r.cb.onDone).not.toHaveBeenCalled();
  });

  it("falls back to onToolCall with the first call when onToolCalls is absent", async () => {
    anthropicMocks.stream.mockImplementation(() =>
      fakeStream([], message({ content: [toolUseBlock("a", { x: 1 }, "1"), toolUseBlock("b", {}, "2")] })),
    );
    const onToolCall = vi.fn();
    const r = recorder({ onToolCall });
    streamChatCompletion(MSGS, r.cb);
    await vi.waitFor(() => expect(onToolCall).toHaveBeenCalledTimes(1));
    expect(onToolCall).toHaveBeenCalledWith({ id: "1", type: "function", function: { name: "a", arguments: '{"x":1}' } });
  });

  it("reports a thinking block's completion via onThinkingDone", async () => {
    const events = [
      { type: "content_block_start", index: 0, content_block: { type: "thinking", thinking: "", signature: "" } },
      { type: "content_block_delta", index: 0, delta: { type: "thinking_delta", thinking: "hmm" } },
      { type: "content_block_stop", index: 0 },
      ...textDeltaEvents("ok").map((e) => ({ ...e, index: 1 })),
    ] as MessageStreamEvent[];
    anthropicMocks.stream.mockImplementation(() =>
      fakeStream(events, message({ content: [{ type: "thinking", thinking: "hmm", signature: "s" } as never, textBlock("ok")] })),
    );
    const onThinkingDone = vi.fn();
    const r = recorder({ onThinking: vi.fn(), onThinkingDone });
    streamChatCompletion(MSGS, r.cb, { enableThinking: true });
    await r.done;
    expect(onThinkingDone).toHaveBeenCalledTimes(1);
    expect(r.log.at(-1)).toBe("done:ok");
  });

  it("streams thinking deltas to onThinking", async () => {
    const events = [
      { type: "content_block_start", index: 0, content_block: { type: "thinking", thinking: "", signature: "" } },
      { type: "content_block_delta", index: 0, delta: { type: "thinking_delta", thinking: "hmm" } },
      { type: "content_block_stop", index: 0 },
    ] as MessageStreamEvent[];
    anthropicMocks.stream.mockImplementation(() =>
      fakeStream(events, message({ content: [{ type: "thinking", thinking: "hmm", signature: "s" } as never] })),
    );
    const onThinking = vi.fn();
    const r = recorder({ onThinking });
    streamChatCompletion(MSGS, r.cb, { enableThinking: true });
    await r.done;
    expect(onThinking).toHaveBeenCalledWith("hmm");
  });

  it("raw events with no text keep the stream timeout alive", async () => {
    const events = [
      { type: "message_start", message: message() },
      { type: "content_block_start", index: 0, content_block: { type: "text", text: "", citations: null } },
    ] as unknown as MessageStreamEvent[];
    anthropicMocks.stream.mockImplementation(() => {
      const s = fakeStream([], message(), { hang: true });
      const realOn = s.on.bind(s);
      // Re-emit raw events every 20ms, under the 50ms timeout, then let it lapse
      let ticks = 0;
      s.on = (event, listener) => {
        realOn(event, listener);
        if (event === "streamEvent") {
          const id = setInterval(() => {
            if (ticks++ >= 4) return clearInterval(id);
            listener(events[ticks % 2], message());
          }, 20);
        }
        return s;
      };
      return s;
    });
    const r = recorder();
    const started = Date.now();
    streamChatCompletion(MSGS, r.cb, { streamTimeout: 50 });
    await r.done;
    expect(r.log).toEqual(["error:ai.timeout"]);
    // Without the resets it would time out at ~50ms; with them, not before ~100ms
    expect(Date.now() - started).toBeGreaterThanOrEqual(90);
    const err = (r.cb.onError as ReturnType<typeof vi.fn>).mock.calls[0][0] as AppErrorException;
    expect(err.appError.detail).toMatch(/after the first event/);
  });

  it("abort stops the stream silently: no further tokens, no onDone, no onError", async () => {
    anthropicMocks.stream.mockImplementation(() => fakeStream(textDeltaEvents("a"), message(), { hang: true }));
    const r = recorder();
    const ctrl = streamChatCompletion(MSGS, r.cb);
    await flush();
    expect(r.log).toEqual(["token:a"]);
    ctrl.abort();
    await flush();
    expect(r.log).toEqual(["token:a"]);
    expect(r.cb.onError).not.toHaveBeenCalled();
    expect(r.cb.onDone).not.toHaveBeenCalled();
  });

  it("reports ai.timeout when no data arrives within streamTimeout, and aborts", async () => {
    anthropicMocks.stream.mockImplementation(() => fakeStream([], message(), { hang: true }));
    const r = recorder();
    const ctrl = streamChatCompletion(MSGS, r.cb, { streamTimeout: 30 });
    await r.done;
    expect(r.log).toEqual(["error:ai.timeout"]);
    expect(ctrl.signal.aborted).toBe(true);
    const err = (r.cb.onError as ReturnType<typeof vi.fn>).mock.calls[0][0] as AppErrorException;
    expect(err.appError.detail).toMatch(/No response within/);
  });

  it("reports an auth error through onError as ai.auth", async () => {
    anthropicMocks.stream.mockImplementation(() => fakeStream([], message(), { error: authError() }));
    const r = recorder();
    streamChatCompletion(MSGS, r.cb);
    await r.done;
    expect(r.log).toEqual(["error:ai.auth"]);
    expect(isAppErrorException((r.cb.onError as ReturnType<typeof vi.fn>).mock.calls[0][0])).toBe(true);
  });

  // Session auto-disables are module state, so each case loads fresh modules.
  describe("auto-disable on proxy 400 (fresh modules)", () => {
    async function fresh() {
      vi.resetModules();
      const sdk = (await import("@anthropic-ai/sdk")).default;
      const lite = await import("./litellm");
      const flags = await import("./featureFlags");
      const bad = (msg: string) => new sdk.BadRequestError(400, { error: { message: msg } }, msg, new Headers());
      return { lite, flags, bad };
    }

    it("disables thinking for the session on a 400 mentioning thinking (no retry)", async () => {
      const { lite, flags, bad } = await fresh();
      anthropicMocks.stream.mockImplementation(() => fakeStream([], message(), { error: bad("thinking is not supported") }));
      const r = recorder();
      lite.streamChatCompletion(MSGS, r.cb, { enableThinking: true });
      await r.done;
      expect(r.log).toEqual(["error:ai.bad-request"]);
      expect(anthropicMocks.stream).toHaveBeenCalledTimes(1);
      expect(flags.getFeatureFlags()).toMatchObject({ thinking: false, effort: true });
      // The next request omits thinking
      anthropicMocks.stream.mockImplementation(() => fakeStream([], message()));
      const r2 = recorder();
      lite.streamChatCompletion(MSGS, r2.cb, { enableThinking: true });
      await r2.done;
      expect(anthropicMocks.stream.mock.calls[1][0]).not.toHaveProperty("thinking");
    });

    it("disables effort on a 400 mentioning output_config", async () => {
      const { lite, flags, bad } = await fresh();
      anthropicMocks.stream.mockImplementation(() => fakeStream([], message(), { error: bad("Extra inputs: output_config") }));
      const r = recorder();
      lite.streamChatCompletion(MSGS, r.cb, { effort: "low" });
      await r.done;
      expect(r.log).toEqual(["error:ai.bad-request"]);
      expect(flags.getFeatureFlags()).toMatchObject({ thinking: true, effort: false });
    });

    it("does not disable a feature that was not in the request", async () => {
      const { lite, flags, bad } = await fresh();
      anthropicMocks.stream.mockImplementation(() => fakeStream([], message(), { error: bad("thinking output_config") }));
      const r = recorder();
      lite.streamChatCompletion(MSGS, r.cb);
      await r.done;
      expect(flags.getFeatureFlags()).toMatchObject({ thinking: true, effort: true });
    });
  });
});

// ---------------------------------------------------------------------------
// countTokens
// ---------------------------------------------------------------------------

describe("countTokens", () => {
  const EST = Math.ceil(((16 + 5) * 1.1) / 3.3); // "You are helpful." + "Hello"

  it("returns the API count and sends system as text blocks plus tools", async () => {
    anthropicMocks.countTokens.mockResolvedValue({ input_tokens: 1234 });
    setFeatureFlags({ promptCaching: false });
    expect(await countTokens(MSGS, { model: "m-x", tools: [TOOL] })).toEqual({ inputTokens: 1234, source: "api" });
    expect(anthropicMocks.countTokens.mock.calls[0][0]).toEqual({
      model: "m-x",
      messages: [{ role: "user", content: "Hello" }],
      system: [{ type: "text", text: "You are helpful." }],
      tools: [{ name: TOOL.name, description: TOOL.description, input_schema: TOOL.input_schema }],
    });
  });

  it("defaults to the standard model and keeps cache_control when caching is on", async () => {
    anthropicMocks.countTokens.mockResolvedValue({ input_tokens: 1 });
    await countTokens(MSGS);
    const params = anthropicMocks.countTokens.mock.calls[0][0];
    expect(params.model).toBe(STANDARD);
    expect(params.system).toEqual([{ type: "text", text: "You are helpful.", cache_control: { type: "ephemeral" } }]);
    expect(params).not.toHaveProperty("tools");
  });

  it("estimates without calling the SDK when tokenCounting is off", async () => {
    setFeatureFlags({ tokenCounting: false });
    expect(await countTokens(MSGS)).toEqual({ inputTokens: EST, source: "estimate" });
    expect(anthropicMocks.countTokens).not.toHaveBeenCalled();
    expect(anthropicMocks.constructed).toHaveLength(0);
  });

  it("estimates without calling the SDK when there is no API key", async () => {
    localStorage.clear();
    expect(await countTokens(MSGS)).toEqual({ inputTokens: EST, source: "estimate" });
    expect(anthropicMocks.countTokens).not.toHaveBeenCalled();
  });

  it("falls back to the estimate when the proxy rejects count_tokens", async () => {
    anthropicMocks.countTokens.mockRejectedValue(new Anthropic.NotFoundError(404, undefined, "nope", new Headers()));
    expect(await countTokens(MSGS)).toEqual({ inputTokens: EST, source: "estimate" });
  });

  it("falls back to the estimate when building the request throws", async () => {
    const malformed = [
      { role: "assistant", content: "hi", tool_calls: [{ id: "t1", type: "function" }] },
    ] as unknown as Parameters<typeof countTokens>[0];
    await expect(countTokens(malformed)).resolves.toMatchObject({ source: "estimate" });
    expect(anthropicMocks.countTokens).not.toHaveBeenCalled();
  });
});
