import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";

vi.mock("@anthropic-ai/sdk", async (importOriginal) => {
  const { mockAnthropicModule } = await import("../test/mockAnthropic");
  return mockAnthropicModule(await importOriginal());
});

import Anthropic from "@anthropic-ai/sdk";
import { anthropicMocks, message, resetAnthropicMocks, textBlock, toolUseBlock } from "../test/mockAnthropic";
import { aiCuiClassification, checkForCui, regexCuiPreScreen } from "./cuiDetection";
import { ACTIVE_ENDPOINT_KEY, ENDPOINTS, apiKeyStorageKey, getResolvedBaseUrl } from "./endpoints";
import { _resetModelsForTests, resolveModel, setDiscoveredModels } from "./models";

const CLEAN = "This is a routine statement of work describing deliverables and schedule. ".repeat(3);

function classifyResponse(input: Record<string, unknown>) {
  return message({ content: [toolUseBlock("classify_cui", input)] });
}

beforeEach(() => {
  resetAnthropicMocks();
  _resetModelsForTests();
  vi.spyOn(console, "warn").mockImplementation(() => {});
});

afterEach(() => {
  vi.restoreAllMocks();
});

// ---------------------------------------------------------------------------
// regexCuiPreScreen
// ---------------------------------------------------------------------------

describe("regexCuiPreScreen", () => {
  it.each([
    ["CONTROLLED UNCLASSIFIED INFORMATION", "Controlled Unclassified Information"],
    ["controlled   unclassified\ninformation", "Controlled Unclassified Information"],
    ["CUI//SP-PRVCY", "CUI Specified category marking"],
    ["cui//prvcy", "CUI category code"],
    ["Marked FOUO in header", "For Official Use Only (FOUO)"],
    ["UNCLASSIFIED//FOR OFFICIAL USE ONLY", "FOUO legacy marking"],
    ["DISTRIBUTION STATEMENT D: DoD and contractors only", "Restricted distribution statement"],
    ["This data is export controlled.", "Export controlled"],
    ["Subject to ITAR restrictions", "ITAR reference"],
    ["SECRET//noforn", "NOFORN marking"],
    ["Controlled Technical Information", "Controlled Technical Information"],
    ["Marked CUI.", "CUI marking"],
  ])("flags %j as %s", (text, label) => {
    const res = regexCuiPreScreen(text);
    expect(res).toMatchObject({ isCui: true, confidence: "high", method: "regex" });
    expect(res!.markers).toContain(label);
    expect(res!.reason).toContain(label);
  });

  it("collects every matching marker in pattern order", () => {
    const res = regexCuiPreScreen("CUI//SP-CTI ... NOFORN ... ITAR");
    expect(res!.markers).toEqual([
      "CUI Specified category marking",
      "CUI category code",
      "ITAR reference",
      "NOFORN marking",
      "CUI marking",
    ]);
    expect(res!.reason).toBe(`Standard CUI marking(s) detected: ${res!.markers.join(", ")}`);
  });

  it.each([
    ["clean text", CLEAN],
    ["Distribution Statement A (public release)", "DISTRIBUTION STATEMENT A: Approved for public release"],
    ["lowercase fouo/itar (case-sensitive patterns)", "fouo and itar in lowercase"],
    ["CUI inside a word", "CIRCUITS and ACUITY"],
    ["empty", ""],
  ])("returns null for %s", (_label, text) => {
    expect(regexCuiPreScreen(text)).toBeNull();
  });
});

// ---------------------------------------------------------------------------
// aiCuiClassification
// ---------------------------------------------------------------------------

describe("aiCuiClassification", () => {
  it("returns null without calling the SDK when neither endpoint has a key", async () => {
    expect(await aiCuiClassification(CLEAN, "a.docx")).toBeNull();
    expect(anthropicMocks.create).not.toHaveBeenCalled();
  });

  it("prefers the CUI endpoint and light model, forcing the classify_cui tool", async () => {
    localStorage.setItem(apiKeyStorageKey("cui"), "k-cui");
    localStorage.setItem(apiKeyStorageKey("non-cui"), "k-il2");
    anthropicMocks.create.mockResolvedValue(
      classifyResponse({ is_cui: false, confidence: "medium", reason: "routine", markers: [] }),
    );
    const ctrl = new AbortController();
    const res = await aiCuiClassification(CLEAN, "sow.docx", ctrl.signal);

    expect(res).toEqual({ isCui: false, confidence: "medium", reason: "routine", method: "ai", markers: [] });
    expect(anthropicMocks.constructed[0]).toEqual({
      baseURL: `${window.location.origin}${getResolvedBaseUrl("cui")}`,
      apiKey: "k-cui",
      dangerouslyAllowBrowser: true,
    });
    const [params, opts] = anthropicMocks.create.mock.calls[0];
    expect(params.model).toBe(ENDPOINTS.cui.models.light);
    expect(params.max_tokens).toBe(1024);
    expect(params.system).toEqual(expect.stringContaining("classify_cui"));
    expect(params.tool_choice).toEqual({ type: "tool", name: "classify_cui" });
    const tools = params.tools as { name: string; input_schema: { required: string[] } }[];
    expect(tools.map((t) => t.name)).toEqual(["classify_cui"]);
    expect(tools[0].input_schema.required).toEqual(["is_cui", "confidence", "reason", "markers"]);
    expect(params.messages).toEqual([
      { role: "user", content: `Classify the following document from "sow.docx":\n\n${CLEAN}` },
    ]);
    expect(opts?.signal).toBe(ctrl.signal);
  });

  it("falls back to the IL2 endpoint when only that key is set", async () => {
    localStorage.setItem(apiKeyStorageKey("non-cui"), "k-il2");
    anthropicMocks.create.mockResolvedValue(
      classifyResponse({ is_cui: true, confidence: "low", reason: "personnel data", markers: ["PII"] }),
    );
    const res = await aiCuiClassification(CLEAN, "a.docx");
    expect(res).toEqual({ isCui: true, confidence: "low", reason: "personnel data", method: "ai", markers: ["PII"] });
    expect(anthropicMocks.constructed[0].apiKey).toBe("k-il2");
    expect(anthropicMocks.create.mock.calls[0][0].model).toBe(ENDPOINTS["non-cui"].models.light);
  });

  it("defaults missing markers to []", async () => {
    localStorage.setItem(apiKeyStorageKey("cui"), "k");
    anthropicMocks.create.mockResolvedValue(classifyResponse({ is_cui: false, confidence: "high", reason: "ok" }));
    expect(await aiCuiClassification(CLEAN, "a.docx")).toMatchObject({ markers: [] });
  });

  it("truncates text over 12,000 characters with a note", async () => {
    localStorage.setItem(apiKeyStorageKey("cui"), "k");
    anthropicMocks.create.mockResolvedValue(classifyResponse({ is_cui: false, confidence: "high", reason: "", markers: [] }));
    await aiCuiClassification("x".repeat(12_000) + "TAIL", "big.pdf");
    const content = (anthropicMocks.create.mock.calls[0][0].messages as { content: string }[])[0].content;
    expect(content).not.toContain("TAIL");
    expect(content).toContain("x".repeat(12_000));
    expect(content).toMatch(/\[Document truncated — only first 12,000 characters shown for classification\.\]$/);
  });

  it("returns a CuiScanError when the model returns no tool_use block", async () => {
    localStorage.setItem(apiKeyStorageKey("cui"), "k");
    anthropicMocks.create.mockResolvedValue(message({ content: [textBlock("I think it's fine")] }));
    const res = await aiCuiClassification(CLEAN, "a.docx");
    expect(res).toEqual({
      error: true,
      message: expect.stringMatching(/^AI CUI scan failed: .*\nModel did not return a classify_cui tool_use block$/s),
    });
  });

  it("returns a CuiScanError with the catalog message on 401", async () => {
    localStorage.setItem(apiKeyStorageKey("cui"), "k");
    anthropicMocks.create.mockRejectedValue(
      new Anthropic.AuthenticationError(401, { error: { message: "bad key" } }, "bad key", new Headers()),
    );
    const res = await aiCuiClassification(CLEAN, "a.docx");
    expect(res).toEqual({
      error: true,
      message: expect.stringContaining("AI CUI scan failed: Your API key was rejected"),
    });
  });

  it("returns a CuiScanError (not a throw) when aborted", async () => {
    localStorage.setItem(apiKeyStorageKey("cui"), "k");
    anthropicMocks.create.mockRejectedValue(new Anthropic.APIUserAbortError());
    const res = await aiCuiClassification(CLEAN, "a.docx", AbortSignal.abort());
    expect(res).toMatchObject({ error: true, message: expect.stringContaining("AI CUI scan failed:") });
  });

  it("marks the light model unavailable on a model-not-found error", async () => {
    localStorage.setItem(apiKeyStorageKey("cui"), "k");
    setDiscoveredModels("cui", [ENDPOINTS.cui.models.light, "claude-haiku-9-9-aws-gov-il5"]);
    anthropicMocks.create.mockRejectedValue(new Anthropic.NotFoundError(404, undefined, "Not Found", new Headers()));
    const res = await aiCuiClassification(CLEAN, "a.docx");
    expect(res).toMatchObject({ error: true });
    expect(resolveModel("cui", "light")).toBe("claude-haiku-9-9-aws-gov-il5");
  });
});

// ---------------------------------------------------------------------------
// checkForCui
// ---------------------------------------------------------------------------

describe("checkForCui", () => {
  beforeEach(() => {
    localStorage.setItem(apiKeyStorageKey("cui"), "k");
  });

  it("returns null when the active endpoint is already CUI", async () => {
    localStorage.setItem(ACTIVE_ENDPOINT_KEY, "cui");
    expect(await checkForCui("CONTROLLED UNCLASSIFIED INFORMATION " + CLEAN, "a.docx")).toBeNull();
    expect(anthropicMocks.create).not.toHaveBeenCalled();
  });

  it("returns null for text under 100 characters, even with markings", async () => {
    expect(await checkForCui("CUI//SP-PRVCY".padEnd(99, "."), "a.docx")).toBeNull();
    expect(anthropicMocks.create).not.toHaveBeenCalled();
  });

  it("short-circuits on a regex hit without calling the AI", async () => {
    const res = await checkForCui("NOFORN " + CLEAN, "a.docx");
    expect(res).toMatchObject({ isCui: true, method: "regex", markers: ["NOFORN marking"] });
    expect(anthropicMocks.create).not.toHaveBeenCalled();
  });

  it("falls through to the AI when regex finds nothing, passing the signal", async () => {
    anthropicMocks.create.mockResolvedValue(
      classifyResponse({ is_cui: true, confidence: "medium", reason: "tech data", markers: ["CTI-like"] }),
    );
    const ctrl = new AbortController();
    const res = await checkForCui(CLEAN, "a.docx", ctrl.signal);
    expect(res).toEqual({ isCui: true, confidence: "medium", reason: "tech data", method: "ai", markers: ["CTI-like"] });
    expect(anthropicMocks.create.mock.calls[0][1]?.signal).toBe(ctrl.signal);
  });

  it("returns the CuiScanError shape when the AI fails", async () => {
    anthropicMocks.create.mockRejectedValue(new Anthropic.InternalServerError(500, undefined, "boom", new Headers()));
    const res = await checkForCui(CLEAN, "a.docx");
    expect(res).toEqual({ error: true, message: expect.stringMatching(/^AI CUI scan failed: /) });
  });

  it("returns null when no key is configured anywhere", async () => {
    localStorage.removeItem(apiKeyStorageKey("cui"));
    expect(await checkForCui(CLEAN, "a.docx")).toBeNull();
  });
});
