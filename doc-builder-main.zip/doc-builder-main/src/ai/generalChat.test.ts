import { describe, it, expect } from "vitest";
import {
  GENERAL_CHAT_SCHEMA,
  GENERAL_TOOLS,
  DEFAULT_GENERAL_DOC_PROMPT,
  buildGeneralChatSystemPrompt,
  buildGeneralChatUserMessage,
} from "./generalChat";

describe("generalChat", () => {
  it("offers no drafting tools", () => {
    const names = GENERAL_TOOLS.map((t) => t.name);
    expect(names).toEqual(["search_references", "ask_user"]);
  });

  it("has a system prompt that does not talk about fields or proposing changes", () => {
    const prompt = buildGeneralChatSystemPrompt();
    expect(prompt).not.toMatch(/propose_changes/);
    expect(prompt).not.toMatch(/fill in (the|all) fields/i);
    expect(prompt).toMatch(/search_references/);
    expect(prompt).toMatch(/ask_user/);
  });

  it("stands in for a schema with a category and no sections", () => {
    expect(GENERAL_CHAT_SCHEMA.sections).toEqual([]);
    expect(GENERAL_CHAT_SCHEMA.category).toBe("general");
    expect(GENERAL_CHAT_SCHEMA.id.startsWith("custom-")).toBe(false);
  });

  it("sends plain text unchanged when nothing is attached", () => {
    expect(buildGeneralChatUserMessage("  What is FMS?  ")).toBe("What is FMS?");
  });

  it("puts attached document text before the request", () => {
    const docs = '<document filename="a.docx">\nHello\n</document>';
    const msg = buildGeneralChatUserMessage("Summarize in one line", docs);
    expect(msg.indexOf(docs)).toBeGreaterThan(-1);
    expect(msg.indexOf(docs)).toBeLessThan(msg.indexOf("Summarize in one line"));
  });

  it("uses the default request when documents are attached without text", () => {
    const msg = buildGeneralChatUserMessage("", "<document></document>");
    expect(msg).toContain(DEFAULT_GENERAL_DOC_PROMPT);
  });
});
