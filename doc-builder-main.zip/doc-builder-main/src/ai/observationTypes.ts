// ---------------------------------------------------------------------------
// AI Observation types (conflict detection, gap analysis, assumption surfacing)
// ---------------------------------------------------------------------------

export type ObservationType = "conflict" | "gap" | "assumption" | "quality" | "placeholder";

export interface ObservationSource {
  document: string;
  value: string;
  excerpt?: string;
}

export interface DetectedObservation {
  type: ObservationType;
  topic: string;
  fieldKey: string | null;
  severity: "high" | "medium" | "low";
  description: string;
  sources: ObservationSource[];
  recommendation?: string;
}
