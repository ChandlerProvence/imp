import { describe, it, expect } from "vitest";
import { buildUnifiedSystemPrompt, getScopedSectionIds, involvesComplexFields, sectionIdFromPath, type AiScope } from "./unifiedPrompt";
import { buildBulkEditChatSystemPrompt } from "./bulkEdit";
import { buildReviewSystemPrompt } from "./documentReviewPrompt";
import { FREETEXT_DRAFTING_RULE, GROUNDING_RULES } from "./promptUtils";
import type { DocumentSchema } from "../schemas/types";
import { createMockFieldMeta } from "../test/mocks";

// ---------------------------------------------------------------------------
// Test schema
// ---------------------------------------------------------------------------

const testSchema: DocumentSchema = {
  id: "test-doc",
  title: "Test Document",
  sections: [
    {
      id: "simple",
      title: "Simple Section",
      fields: [
        { id: "name", label: "Name", type: "string" },
        { id: "age", label: "Age", type: "number" },
        { id: "active", label: "Active", type: "boolean" },
        { id: "joined", label: "Joined", type: "date" },
        { id: "role", label: "Role", type: "enum", options: ["admin", "user"] },
      ],
    },
    {
      id: "complex",
      title: "Complex Section",
      fields: [
        { id: "title", label: "Title", type: "string" },
        { id: "description", label: "Description", type: "freetext" },
        { id: "items", label: "Items", type: "table", columns: [{ id: "col1", label: "Col", type: "string" }] },
      ],
    },
    {
      id: "mixed",
      title: "Mixed Section",
      fields: [
        { id: "heading", label: "Heading", type: "string" },
        { id: "body", label: "Body", type: "freetext" },
      ],
    },
  ],
  output_template: "",
} as unknown as DocumentSchema;

// ---------------------------------------------------------------------------
// involvesComplexFields — field scope
// ---------------------------------------------------------------------------

describe("involvesComplexFields", () => {
  describe("field scope", () => {
    it("returns true for a freetext field", () => {
      expect(
        involvesComplexFields(testSchema, {
          type: "field",
          sectionId: "complex",
          fieldKey: "complex.description",
        }),
      ).toBe(true);
    });

    it("returns true for a table field", () => {
      expect(
        involvesComplexFields(testSchema, {
          type: "field",
          sectionId: "complex",
          fieldKey: "complex.items",
        }),
      ).toBe(true);
    });

    it("returns false for a string field", () => {
      expect(
        involvesComplexFields(testSchema, {
          type: "field",
          sectionId: "simple",
          fieldKey: "simple.name",
        }),
      ).toBe(false);
    });

    it("returns false for a number field", () => {
      expect(
        involvesComplexFields(testSchema, {
          type: "field",
          sectionId: "simple",
          fieldKey: "simple.age",
        }),
      ).toBe(false);
    });

    it("returns false for an enum field", () => {
      expect(
        involvesComplexFields(testSchema, {
          type: "field",
          sectionId: "simple",
          fieldKey: "simple.role",
        }),
      ).toBe(false);
    });

    it("returns false when field is not found", () => {
      expect(
        involvesComplexFields(testSchema, {
          type: "field",
          sectionId: "simple",
          fieldKey: "simple.nonexistent",
        }),
      ).toBe(false);
    });

    it("returns false when section is not found", () => {
      expect(
        involvesComplexFields(testSchema, {
          type: "field",
          sectionId: "missing",
          fieldKey: "missing.foo",
        }),
      ).toBe(false);
    });
  });

  // ---------------------------------------------------------------------------
  // section scope
  // ---------------------------------------------------------------------------

  describe("section scope", () => {
    it("returns true when section has a freetext field", () => {
      expect(
        involvesComplexFields(testSchema, { type: "section", sectionId: "complex" }),
      ).toBe(true);
    });

    it("returns true when section has a table field", () => {
      expect(
        involvesComplexFields(testSchema, { type: "section", sectionId: "complex" }),
      ).toBe(true);
    });

    it("returns false when section has only simple fields", () => {
      expect(
        involvesComplexFields(testSchema, { type: "section", sectionId: "simple" }),
      ).toBe(false);
    });

    it("returns false when section is not found", () => {
      expect(
        involvesComplexFields(testSchema, { type: "section", sectionId: "missing" }),
      ).toBe(false);
    });
  });

  // ---------------------------------------------------------------------------
  // document scope
  // ---------------------------------------------------------------------------

  describe("document scope", () => {
    it("returns true when any section has complex fields", () => {
      expect(
        involvesComplexFields(testSchema, { type: "document" }),
      ).toBe(true);
    });

    it("returns false when no section has complex fields", () => {
      const simpleOnlySchema: DocumentSchema = {
        ...testSchema,
        sections: [testSchema.sections[0]], // Only the "simple" section
      } as unknown as DocumentSchema;

      expect(
        involvesComplexFields(simpleOnlySchema, { type: "document" }),
      ).toBe(false);
    });
  });
});

// ---------------------------------------------------------------------------
// buildBulkEditChatSystemPrompt — ask_user guidance
// ---------------------------------------------------------------------------

describe("buildBulkEditChatSystemPrompt — Asking the User guidance", () => {
  it("includes neutral ask_user guidance without steering toward conflicts", () => {
    const prompt = buildBulkEditChatSystemPrompt(testSchema, ["simple"], {});
    expect(prompt).toContain("## Asking the User");
    expect(prompt).toContain("ask_user");
    // The guidance section itself must stay general-purpose — not conflict-specific.
    const askUserSection = prompt.slice(prompt.indexOf("## Asking the User"));
    expect(askUserSection).not.toMatch(/conflict/i);
  });

  it("leaves the existing Conflict Detection guidance unchanged", () => {
    const prompt = buildBulkEditChatSystemPrompt(testSchema, ["simple"], {});
    expect(prompt).toContain("## Conflict Detection");
    expect(prompt).toContain(
      'When you detect conflicting or contradictory information between source documents, call `report_observations` with type "conflict" to flag the discrepancies.',
    );
  });
});

// ---------------------------------------------------------------------------
// buildBulkEditChatSystemPrompt — freetext drafting carve-out
// ---------------------------------------------------------------------------

describe("buildBulkEditChatSystemPrompt — freetext drafting rule", () => {
  it("includes the freetext narrative carve-out alongside the grounding rules", () => {
    const prompt = buildBulkEditChatSystemPrompt(testSchema, ["complex"], {});
    expect(prompt).toContain(FREETEXT_DRAFTING_RULE);
    expect(prompt.indexOf(FREETEXT_DRAFTING_RULE)).toBeGreaterThan(
      prompt.indexOf(GROUNDING_RULES[GROUNDING_RULES.length - 1]),
    );
  });

  it("keeps strict identifier grounding", () => {
    const prompt = buildBulkEditChatSystemPrompt(testSchema, ["complex"], {});
    expect(prompt).toContain("Never construct identifiers by pattern");
  });

  it("does not promise harness auto-continuation", () => {
    const prompt = buildBulkEditChatSystemPrompt(testSchema, ["complex"], {});
    expect(prompt).not.toMatch(/automatically prompted to continue/i);
  });
});

// ---------------------------------------------------------------------------
// buildUnifiedSystemPrompt — drafting style
// ---------------------------------------------------------------------------

describe("buildUnifiedSystemPrompt — drafting style", () => {
  const note = "Use bullet points for requirements.";
  const scopes: AiScope[] = [
    { type: "document" },
    { type: "section", sectionId: "complex" },
    { type: "field", sectionId: "complex", fieldKey: "complex.description" },
  ];

  it.each(scopes)("emits the block after the rules for $type scope", (scope) => {
    const prompt = buildUnifiedSystemPrompt(testSchema, scope, {}, undefined, note);
    expect(prompt).toContain("## Drafting Style\n");
    expect(prompt).toContain("They govern form, not facts");
    expect(prompt).toContain(note);
    expect(prompt.indexOf("## Drafting Style")).toBeGreaterThan(prompt.indexOf("## Rules"));
  });

  it.each([undefined, "", "   "])("omits the block when the note is %j", (value) => {
    for (const scope of scopes) {
      expect(buildUnifiedSystemPrompt(testSchema, scope, {}, undefined, value)).not.toContain("## Drafting Style");
    }
  });
});

describe("sectionIdFromPath", () => {
  it("returns a real section id", () => {
    expect(sectionIdFromPath("/interview/test-doc/complex", testSchema)).toBe("complex");
  });

  it("ignores prep pages and unknown ids", () => {
    expect(sectionIdFromPath("/interview/test-doc/prep/style", testSchema)).toBeNull();
    expect(sectionIdFromPath("/interview/test-doc/prep", testSchema)).toBeNull();
    expect(sectionIdFromPath("/interview/test-doc/nope", testSchema)).toBeNull();
    expect(sectionIdFromPath("/review", testSchema)).toBeNull();
    expect(sectionIdFromPath("/interview/test-doc/complex", null)).toBeNull();
  });
});

describe("buildReviewSystemPrompt — drafting style", () => {
  it("tells the reviewer the requested style is not a quality issue", () => {
    const prompt = buildReviewSystemPrompt(testSchema, undefined, "Bulleted sections.");
    expect(prompt).toContain("## Drafting Style");
    expect(prompt).toContain("Bulleted sections.");
  });

  it("omits the block without a note", () => {
    expect(buildReviewSystemPrompt(testSchema)).not.toContain("## Drafting Style");
  });
});

// ---------------------------------------------------------------------------
// buildUnifiedSystemPrompt — scope dispatch
// ---------------------------------------------------------------------------

describe("buildUnifiedSystemPrompt — scope dispatch", () => {
  const allIds = testSchema.sections.map((s) => s.id);

  it("document scope lists every section and matches the bulk edit prompt", () => {
    const prompt = buildUnifiedSystemPrompt(testSchema, { type: "document" }, {});
    expect(prompt).toContain("### Simple Section (simple)");
    expect(prompt).toContain("### Complex Section (complex)");
    expect(prompt).toContain("### Mixed Section (mixed)");
    expect(prompt).not.toContain("## Focus Field");
    expect(prompt).toBe(buildBulkEditChatSystemPrompt(testSchema, allIds, {}));
  });

  it("section scope lists only that section", () => {
    const prompt = buildUnifiedSystemPrompt(testSchema, { type: "section", sectionId: "simple" }, {});
    expect(prompt).toContain("### Simple Section (simple)");
    expect(prompt).not.toContain("### Complex Section (complex)");
    expect(prompt).not.toContain("## Focus Field");
  });

  it("field scope adds a focus-field block for the target field", () => {
    const prompt = buildUnifiedSystemPrompt(
      testSchema,
      { type: "field", sectionId: "complex", fieldKey: "complex.description" },
      {},
    );
    expect(prompt).toContain("## Focus Field");
    expect(prompt).toContain("You can ONLY propose changes to: complex.description");
    expect(prompt).toContain("Field: Description");
    expect(prompt).not.toContain("### Simple Section (simple)");
  });

  it("field scope falls back to document scope when the section is unknown", () => {
    const prompt = buildUnifiedSystemPrompt(
      testSchema,
      { type: "field", sectionId: "missing", fieldKey: "missing.x" },
      {},
    );
    expect(prompt).toBe(buildBulkEditChatSystemPrompt(testSchema, allIds, {}));
  });

  it("field scope falls back to section scope when the field is unknown", () => {
    const prompt = buildUnifiedSystemPrompt(
      testSchema,
      { type: "field", sectionId: "simple", fieldKey: "simple.nope" },
      {},
    );
    expect(prompt).toBe(buildBulkEditChatSystemPrompt(testSchema, ["simple"], {}));
    expect(prompt).not.toContain("## Focus Field");
  });

  it("includes current answers in the working draft", () => {
    const prompt = buildUnifiedSystemPrompt(testSchema, { type: "section", sectionId: "simple" }, { "simple.name": "Ada" });
    expect(prompt).toContain("## Working Draft");
    expect(prompt).toContain("- Name: Ada");
    expect(prompt).not.toContain("(AI-proposed)");
  });

  it.each<AiScope>([
    { type: "document" },
    { type: "section", sectionId: "simple" },
    { type: "field", sectionId: "simple", fieldKey: "simple.name" },
  ])("passes fieldMeta through for $type scope", (scope) => {
    const prompt = buildUnifiedSystemPrompt(
      testSchema,
      scope,
      { "simple.name": "Ada" },
      { "simple.name": createMockFieldMeta({ source: "chat-draft" }) },
    );
    expect(prompt).toContain("- Name: Ada (AI-proposed)");
    expect(prompt).toContain("This is your OUTPUT, not a source");
  });

  it("does not tag manual values from fieldMeta", () => {
    const prompt = buildUnifiedSystemPrompt(
      testSchema,
      { type: "document" },
      { "simple.name": "Ada" },
      { "simple.name": createMockFieldMeta({ source: "manual" }) },
    );
    expect(prompt).toContain("- Name: Ada\n");
    expect(prompt).not.toContain("This is your OUTPUT, not a source");
  });

  it("passes the drafting style through the fallback paths", () => {
    const prompt = buildUnifiedSystemPrompt(
      testSchema,
      { type: "field", sectionId: "missing", fieldKey: "missing.x" },
      {},
      undefined,
      "Short sentences.",
    );
    expect(prompt).toContain("Short sentences.");
    const sectionFallback = buildUnifiedSystemPrompt(
      testSchema,
      { type: "field", sectionId: "simple", fieldKey: "simple.nope" },
      {},
      undefined,
      "Short sentences.",
    );
    expect(sectionFallback).toContain("Short sentences.");
  });
});

describe("getScopedSectionIds", () => {
  it("returns every section for document scope", () => {
    expect(getScopedSectionIds(testSchema, { type: "document" })).toEqual(["simple", "complex", "mixed"]);
  });

  it("returns the one section for section and field scope", () => {
    expect(getScopedSectionIds(testSchema, { type: "section", sectionId: "mixed" })).toEqual(["mixed"]);
    expect(
      getScopedSectionIds(testSchema, { type: "field", sectionId: "complex", fieldKey: "complex.title" }),
    ).toEqual(["complex"]);
  });

  it("does not validate the section id", () => {
    expect(getScopedSectionIds(testSchema, { type: "section", sectionId: "ghost" })).toEqual(["ghost"]);
  });
});

describe("sectionIdFromPath — edge cases", () => {
  it("rejects trailing slashes, extra segments and non-interview prefixes", () => {
    expect(sectionIdFromPath("/interview/test-doc/complex/", testSchema)).toBeNull();
    expect(sectionIdFromPath("/interview/test-doc/complex/extra", testSchema)).toBeNull();
    expect(sectionIdFromPath("/x/interview/test-doc/complex", testSchema)).toBeNull();
    expect(sectionIdFromPath("/interview/test-doc", testSchema)).toBeNull();
  });

  it("does not check the schema id segment", () => {
    expect(sectionIdFromPath("/interview/other-doc/simple", testSchema)).toBe("simple");
  });
});
