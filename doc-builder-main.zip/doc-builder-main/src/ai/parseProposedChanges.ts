/**
 * @deprecated Legacy utilities for backward-compatible rendering of conversations
 * started before the tool-call migration. New conversations use the
 * `propose_changes` tool call instead of embedding XML in the response text.
 */

const PROPOSED_CHANGES_RE = /<proposed-changes>([\s\S]*?)<\/proposed-changes>/;

/**
 * Extract the JSON string from the first <proposed-changes> block in an
 * assistant response. Returns null if no such block is present.
 *
 * @deprecated New conversations use the `propose_changes` tool call. Kept for
 * restoring old persisted conversations from IndexedDB.
 */
export function extractProposedChangesJson(content: string): string | null {
  const match = content.match(PROPOSED_CHANGES_RE);
  if (!match) return null;
  const json = match[1].trim();
  return json.length > 0 ? json : null;
}

/**
 * Strip all <proposed-changes> blocks from content, returning only the
 * conversational text (for display in the chat bubble).
 *
 * @deprecated New conversations use the `propose_changes` tool call. Kept for
 * rendering old persisted conversations that may contain XML blocks.
 */
export function stripProposedChanges(content: string): string {
  return content.replace(/<proposed-changes>[\s\S]*?<\/proposed-changes>/g, "").trim();
}
