import type { DocumentSchema, FieldType } from "../schemas/types";
import type { FieldMeta } from "../db/types";
import { buildBulkEditChatSystemPrompt } from "./bulkEdit";

// ---------------------------------------------------------------------------
// Complex field detection
// ---------------------------------------------------------------------------

/** Field types that benefit from a higher-quality model + extended thinking. */
const COMPLEX_FIELD_TYPES: Set<FieldType> = new Set(["freetext", "table"]);

/**
 * Determines whether the given AI scope targets any complex (freetext/table) fields.
 * Used to decide model tier, effort level, and thinking enablement.
 */
export function involvesComplexFields(schema: DocumentSchema, scope: AiScope): boolean {
  switch (scope.type) {
    case "field": {
      const section = schema.sections.find((s) => s.id === scope.sectionId);
      const field = section?.fields.find(
        (f) => `${section!.id}.${f.id}` === scope.fieldKey,
      );
      return field ? COMPLEX_FIELD_TYPES.has(field.type) : false;
    }
    case "section": {
      const section = schema.sections.find((s) => s.id === scope.sectionId);
      return section?.fields.some((f) => COMPLEX_FIELD_TYPES.has(f.type)) ?? false;
    }
    case "document": {
      return schema.sections.some((s) =>
        s.fields.some((f) => COMPLEX_FIELD_TYPES.has(f.type)),
      );
    }
  }
}

// ---------------------------------------------------------------------------
// Scope types
// ---------------------------------------------------------------------------

export type AiScope =
  | { type: "document" }
  | { type: "section"; sectionId: string }
  | { type: "field"; sectionId: string; fieldKey: string };

// ---------------------------------------------------------------------------
// Unified prompt dispatcher
// ---------------------------------------------------------------------------

/**
 * Build the system prompt appropriate for the given AI scope.
 * - "document" → bulk edit prompt across all sections
 * - "section"  → bulk edit prompt scoped to one section
 * - "field"    → per-field drafting prompt for a single field
 */
export function buildUnifiedSystemPrompt(
  schema: DocumentSchema,
  scope: AiScope,
  answers: Record<string, string | number | boolean>,
  fieldMeta?: Record<string, FieldMeta>,
  draftingStyle?: string,
): string {
  switch (scope.type) {
    case "document":
      return buildBulkEditChatSystemPrompt(
        schema,
        schema.sections.map((s) => s.id),
        answers,
        undefined,
        fieldMeta,
        draftingStyle,
      );
    case "section":
      return buildBulkEditChatSystemPrompt(schema, [scope.sectionId], answers, undefined, fieldMeta, draftingStyle);
    case "field": {
      const section = schema.sections.find((s) => s.id === scope.sectionId);
      if (!section) {
        // Fallback to document scope if section not found
        return buildBulkEditChatSystemPrompt(
          schema,
          schema.sections.map((s) => s.id),
          answers,
          undefined,
          fieldMeta,
          draftingStyle,
        );
      }
      const field = section.fields.find(
        (f) => `${section.id}.${f.id}` === scope.fieldKey,
      );
      if (!field) {
        // Fallback to section scope if field not found
        return buildBulkEditChatSystemPrompt(schema, [scope.sectionId], answers, undefined, fieldMeta, draftingStyle);
      }
      return buildBulkEditChatSystemPrompt(schema, [scope.sectionId], answers, {
        sectionId: scope.sectionId,
        fieldKey: scope.fieldKey,
      }, fieldMeta, draftingStyle);
    }
  }
}

/**
 * The schema section an interview URL points at, or null. Prep pages
 * (`/interview/<id>/prep/...`) and unknown ids are not sections, so the AI
 * scope is left alone there.
 */
export function sectionIdFromPath(pathname: string, schema: DocumentSchema | null): string | null {
  const match = pathname.match(/^\/interview\/[^/]+\/([^/]+)$/);
  const id = match?.[1] ?? null;
  return id && schema?.sections.some((s) => s.id === id) ? id : null;
}

/**
 * Returns the selected section IDs for the given scope.
 * Used to scope the BulkEditRequest when parsing proposed changes.
 */
export function getScopedSectionIds(schema: DocumentSchema, scope: AiScope): string[] {
  switch (scope.type) {
    case "document":
      return schema.sections.map((s) => s.id);
    case "section":
      return [scope.sectionId];
    case "field":
      return [scope.sectionId];
  }
}
