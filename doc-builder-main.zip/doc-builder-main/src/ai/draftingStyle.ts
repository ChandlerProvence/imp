/**
 * Style-reference analysis: derive a short drafting-style note from a
 * customer's prior document. One call per reference set, never per draft —
 * the reference text itself never enters the drafting prompt.
 */

import { appErrorException } from "../errors";
import { fetchChatCompletion } from "./litellm";
import { escapeXmlAttr } from "./bulkEdit";
import type { LiteLLMMessage } from "./types";

/**
 * The note steers new prose, so it describes only conventions worth copying.
 * Template-owned structure (headings, captions, tables) is excluded because
 * freetext fields never produce it, and the old document's defects are
 * excluded because a model told about them may reproduce them. A bare
 * "don't quote names" didn't hold: the model treated "PdM Abrams" as an
 * example of framing, so examples must use bracketed placeholders.
 */
export const STYLE_ANALYSIS_INSTRUCTION =
  "Describe how this document is written so another writer could match it in new prose. Cover: paragraphs vs. bullet points and when each is used, naming any sections whose format differs from the rest; how bullet items are phrased; typical sentence and paragraph length; voice and tense; how acronyms are introduced; how hedged or definite the language is; recurring phrasing. Describe the conventions the document follows, not where it departs from them: ignore typos, formatting defects, inconsistencies, and text repeated between sections, and never tell the writer to reproduce them. Leave out structure a template supplies: front matter, signature blocks, heading numbering, section-number cross-references, figure and table captions and references to them, tables, and annexes. When a convention depends on facts (citing regulations, claims of success or superlatives, progress statements, review schedules, as-of dates), describe it as applying only where the sources support it. Do NOT summarize the content. When you give an example phrase, replace every program, system, organization, person, regulation, number, and date in it with a bracketed placeholder such as [program], [office], [regulation], or [date], for example \"the [office] manages [program] sustainment\"; never write the document's actual names or values. Output 6 to 12 short lines, no preamble.";

/** Total characters of reference text sent, split evenly across documents. */
export const STYLE_REFERENCE_MAX_CHARS = 30_000;

export interface StyleReferenceDoc {
  fileName: string;
  text: string;
}

const IMAGE_FILE = /\.(png|jpe?g|gif|webp|bmp|tiff?)$/i;

/** Bracketed blocks the upload pipeline inserts in place of images: vision
 *  transcriptions (`[Image: …]`), CUI quarantine placeholders, raw
 *  `[IMAGE_n]` placeholders, and the "images not processed" note. */
const MACHINE_BLOCK_START = /\[(?:Image[: ]|IMAGE_\d|Note: \d+ additional image)/g;

/**
 * Remove the upload pipeline's image blocks. They are machine output, not the
 * author's writing, and would otherwise be read as the document's style.
 * Brackets are depth-matched because transcriptions contain their own
 * (`[illegible]`, markdown links).
 */
export function stripMachineBlocks(text: string): string {
  let out = "";
  let pos = 0;
  for (const match of text.matchAll(MACHINE_BLOCK_START)) {
    const start = match.index;
    if (start < pos) continue;
    let depth = 0;
    let end = text.length;
    for (let i = start; i < text.length; i++) {
      if (text[i] === "[") depth++;
      else if (text[i] === "]" && --depth === 0) {
        end = i + 1;
        break;
      }
    }
    out += text.slice(pos, start);
    pos = end;
  }
  if (pos === 0) return text;
  return (out + text.slice(pos)).replace(/\n{3,}/g, "\n\n").trim();
}

/** Style-reference text the analysis can use: image files dropped, image blocks stripped. */
export function styleTextOf(docs: StyleReferenceDoc[]): StyleReferenceDoc[] {
  return docs
    .filter((d) => !IMAGE_FILE.test(d.fileName))
    .map((d) => ({ fileName: d.fileName, text: stripMachineBlocks(d.text) }))
    .filter((d) => d.text.length > 0);
}

export function buildStyleAnalysisMessages(docs: StyleReferenceDoc[]): LiteLLMMessage[] {
  const usable = styleTextOf(docs);
  const perDoc = Math.floor(STYLE_REFERENCE_MAX_CHARS / Math.max(usable.length, 1));
  const body = usable
    .map((d) => `<document filename="${escapeXmlAttr(d.fileName)}">\n${d.text.slice(0, perDoc)}\n</document>`)
    .join("\n\n");
  return [
    { role: "system", content: STYLE_ANALYSIS_INSTRUCTION },
    { role: "user", content: body },
  ];
}

/**
 * Upper bound on the whole analysis, retries included. The chat waits while it
 * runs, so a stalled proxy must not hold it for the SDK's own 10-minute timeout.
 */
export const STYLE_ANALYSIS_TIMEOUT_MS = 90_000;

/** Room for 12 long lines; a note that still hits it is rejected as cut off. */
export const STYLE_ANALYSIS_MAX_TOKENS = 2048;

/** Run the style analysis (models.standard) and return the trimmed note. */
export async function deriveDraftingStyle(docs: StyleReferenceDoc[], signal?: AbortSignal): Promise<string> {
  // Nothing but images: there is no authored prose to describe.
  if (styleTextOf(docs).length === 0) {
    throw appErrorException("file.no-text", { context: { fileName: docs.map((d) => d.fileName).join(", ") } });
  }
  const timeout = new AbortController();
  const timer = setTimeout(() => timeout.abort(), STYLE_ANALYSIS_TIMEOUT_MS);
  const onCallerAbort = () => timeout.abort();
  signal?.addEventListener("abort", onCallerAbort);
  let content: string;
  let stopReason: string | null | undefined;
  try {
    ({ content, stopReason } = await fetchChatCompletion(buildStyleAnalysisMessages(docs), {
      maxTokens: STYLE_ANALYSIS_MAX_TOKENS,
      signal: timeout.signal,
    }));
  } catch (err) {
    // Our timer fired, not the caller: report a timeout instead of a silent abort.
    if (timeout.signal.aborted && !signal?.aborted) {
      throw appErrorException("ai.timeout", { context: { seconds: String(STYLE_ANALYSIS_TIMEOUT_MS / 1000) } });
    }
    throw err;
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener("abort", onCallerAbort);
  }
  // A cut-off note would be saved and injected into every draft looking complete.
  if (stopReason === "max_tokens") {
    throw appErrorException("ai.bad-response", { context: { what: "style analysis was cut off" } });
  }
  const note = content.trim();
  if (!note) throw appErrorException("ai.bad-response", { context: { what: "style analysis" } });
  return note;
}
