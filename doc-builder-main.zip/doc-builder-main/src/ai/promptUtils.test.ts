import { describe, it, expect, afterEach, vi } from "vitest";
import {
  buildPersonaLine,
  todayLine,
  formatExistingAnswers,
  formatColumnDefs,
  ANSWERS_SECTION_HEADING,
  ANSWERS_SECTION_PREAMBLE,
  FIELD_TYPE_RULES,
  GROUNDING_RULES,
  FREETEXT_DRAFTING_RULE,
} from "./promptUtils";
import { createMockSchema, createMockSection, createMockField, createMockFieldMeta } from "../test/mocks";
import type { TableColumnDef } from "../schemas/types";

const schema = createMockSchema({
  title: "Statement of Work",
  sections: [
    createMockSection({
      id: "basics",
      title: "Basics",
      fields: [
        createMockField({ id: "name", label: "Name", type: "string" }),
        createMockField({ id: "count", label: "Count", type: "number" }),
        createMockField({ id: "flag", label: "Flag", type: "boolean" }),
        createMockField({ id: "kind", label: "Kind", type: "enum", options: ["A", "B"] }),
        createMockField({ id: "tags", label: "Tags", type: "multiselect", options: ["x", "y"] }),
      ],
    }),
    createMockSection({
      id: "body",
      title: "Body",
      fields: [
        createMockField({ id: "summary", label: "Summary", type: "freetext" }),
        createMockField({
          id: "items",
          label: "Items",
          type: "table",
          columns: [{ id: "c", label: "C", type: "string" }],
        }),
        createMockField({ id: "logo", label: "Logo", type: "image" }),
      ],
    }),
  ],
});

describe("buildPersonaLine", () => {
  it("embeds the role and quoted schema title", () => {
    expect(buildPersonaLine(schema, "reviewer analyzing")).toBe(
      'You are a professional document reviewer analyzing a "Statement of Work".',
    );
  });
});

describe("todayLine", () => {
  afterEach(() => {
    vi.useRealTimers();
  });

  it("formats the current UTC date as YYYY-MM-DD", () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-03-05T12:00:00Z"));
    expect(todayLine()).toBe("Today's date is 2026-03-05.");
  });

  it("uses the UTC date, not local time", () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-12-31T23:59:59Z"));
    expect(todayLine()).toBe("Today's date is 2026-12-31.");
  });
});

describe("formatExistingAnswers", () => {
  it("returns no lines for empty answers", () => {
    expect(formatExistingAnswers(schema, {})).toEqual([]);
  });

  it("skips empty-string values and sections with no answers", () => {
    expect(formatExistingAnswers(schema, { "basics.name": "" })).toEqual([]);
    const lines = formatExistingAnswers(schema, { "body.summary": "Text" });
    expect(lines).not.toContain("### Basics");
    expect(lines).toEqual(["### Body", "- Summary: Text", ""]);
  });

  it("formats string, number, boolean, enum and multiselect values", () => {
    const lines = formatExistingAnswers(schema, {
      "basics.name": "Acme",
      "basics.count": 0,
      "basics.flag": false,
      "basics.kind": "B",
      "basics.tags": '["x","y"]',
    });
    expect(lines).toEqual([
      "### Basics",
      "- Name: Acme",
      "- Count: 0",
      "- Flag: No",
      "- Kind: B",
      '- Tags: ["x","y"]',
      "",
    ]);
  });

  it("renders true booleans as Yes", () => {
    expect(formatExistingAnswers(schema, { "basics.flag": true })).toContain("- Flag: Yes");
  });

  it("keeps multi-paragraph freetext verbatim", () => {
    const lines = formatExistingAnswers(schema, { "body.summary": "Para 1\n\nPara 2" });
    expect(lines).toContain("- Summary: Para 1\n\nPara 2");
  });

  it("renders image fields as a placeholder", () => {
    expect(formatExistingAnswers(schema, { "body.logo": "data:image/png;base64,AAA" })).toContain(
      "- Logo: [Image uploaded]",
    );
  });

  it("emits raw table JSON by default", () => {
    const raw = JSON.stringify({ rows: [{ c: "1" }, { c: "2" }] });
    expect(formatExistingAnswers(schema, { "body.items": raw })).toContain(`- Items: ${raw}`);
  });

  it("summarizes tables when summarizeTables is set", () => {
    const raw = JSON.stringify({ rows: [{ c: "1" }, { c: "2" }] });
    expect(formatExistingAnswers(schema, { "body.items": raw }, { summarizeTables: true })).toEqual([
      "### Body",
      "- Items: [Table with 2 row(s)]",
      "",
    ]);
  });

  it("omits empty or unparseable tables when summarizing", () => {
    expect(
      formatExistingAnswers(schema, { "body.items": JSON.stringify({ rows: [] }) }, { summarizeTables: true }),
    ).toEqual([]);
    expect(formatExistingAnswers(schema, { "body.items": "not json" }, { summarizeTables: true })).toEqual([]);
  });

  it("tags AI-sourced values but not manual ones or values without meta", () => {
    const lines = formatExistingAnswers(
      schema,
      {
        "basics.name": "Acme",
        "basics.count": 3,
        "basics.kind": "A",
        "body.logo": "img",
        "body.items": JSON.stringify({ rows: [{ c: "1" }] }),
      },
      {
        summarizeTables: true,
        fieldMeta: {
          "basics.name": createMockFieldMeta({ source: "bulk-edit" }),
          "basics.count": createMockFieldMeta({ source: "manual" }),
          "body.logo": createMockFieldMeta({ source: "chat-draft" }),
          "body.items": createMockFieldMeta({ source: "chat-draft" }),
        },
      },
    );
    expect(lines).toContain("- Name: Acme (AI-proposed)");
    expect(lines).toContain("- Count: 3");
    expect(lines).toContain("- Kind: A");
    expect(lines).toContain("- Logo: [Image uploaded] (AI-proposed)");
    expect(lines).toContain("- Items: [Table with 1 row(s)] (AI-proposed)");
  });

  it("ignores answers for keys not in the schema", () => {
    expect(formatExistingAnswers(schema, { "other.x": "y" })).toEqual([]);
  });
});

describe("formatColumnDefs", () => {
  const columns: TableColumnDef[] = [
    { id: "name", label: "Name", type: "string", required: true },
    { id: "amount", label: "Amount", type: "number" },
    { id: "status", label: "Status", type: "enum", options: ["active", "closed"] },
    { id: "bare", label: "Bare", type: "enum" },
  ];

  it("describes type, required flag and enum options", () => {
    expect(formatColumnDefs(columns)).toBe(
      "name: string (required), amount: number, status: enum [active|closed], bare: enum",
    );
  });

  it("honors a custom separator", () => {
    expect(formatColumnDefs(columns.slice(0, 2), "; ")).toBe("name: string (required); amount: number");
  });

  it("returns an empty string for no columns", () => {
    expect(formatColumnDefs([])).toBe("");
  });
});

describe("rule constants", () => {
  it("are non-empty strings", () => {
    for (const s of [ANSWERS_SECTION_HEADING, ANSWERS_SECTION_PREAMBLE, FIELD_TYPE_RULES, FREETEXT_DRAFTING_RULE]) {
      expect(typeof s).toBe("string");
      expect(s.length).toBeGreaterThan(0);
    }
    expect(ANSWERS_SECTION_HEADING.startsWith("## ")).toBe(true);
  });

  it("GROUNDING_RULES is a non-empty list of non-empty strings", () => {
    expect(GROUNDING_RULES.length).toBeGreaterThan(0);
    for (const r of GROUNDING_RULES) expect(r.length).toBeGreaterThan(0);
  });

  it("FIELD_TYPE_RULES mentions every answer type", () => {
    for (const t of ["string", "number", "boolean", "date", "enum", "multiselect", "freetext", "table"]) {
      expect(FIELD_TYPE_RULES).toContain(`${t} =`);
    }
  });
});
