import { describe, it, expect, vi, beforeEach } from "vitest";

const mocks = vi.hoisted(() => ({
  convertToHtml: vi.fn(),
  loadTemplateBuffer: vi.fn(),
  listeners: [] as ((schemaId: string) => void)[],
}));

vi.mock("mammoth", () => ({ default: { convertToHtml: mocks.convertToHtml } }));
vi.mock("../generation/templateSource", () => ({
  loadTemplateBuffer: mocks.loadTemplateBuffer,
  onTemplateChanged: (listener: (schemaId: string) => void) => {
    mocks.listeners.push(listener);
    return () => {};
  },
}));

import {
  getOrBuildCache,
  queryByFieldKey,
  queryByLineRange,
  queryBySearch,
  buildOutline,
  type TemplateTextCache,
} from "./templateTextService";
import { createMockSchema } from "../test/mocks";

function makeCache(lines: string[], headings: TemplateTextCache["headingIndex"], tags: [string, number][]): TemplateTextCache {
  return { schemaId: "s", lines, headingIndex: headings, tagIndex: new Map(tags), totalLines: lines.length };
}

const lines = [
  "[H1] Introduction", // 1
  "Intro text {{NAME}}", // 2
  "", // 3
  "[H2] Scope", // 4
  "Scope body", // 5
  "The {{AMOUNT}} applies", // 6
  "", // 7
  "Again {{NAME_ALT}}", // 8
  "[H1] Closing", // 9
  "Closing text", // 10
  "Scope again", // 11
];
const cache = makeCache(
  lines,
  [
    { line: 1, level: 1, text: "Introduction" },
    { line: 4, level: 2, text: "Scope" },
    { line: 9, level: 1, text: "Closing" },
  ],
  [
    ["NAME", 2],
    ["AMOUNT", 6],
    ["NAME_ALT", 8],
  ],
);

describe("buildOutline", () => {
  it("reports when there are no headings", () => {
    expect(buildOutline(makeCache(["a", "b"], [], []))).toBe("Document outline (2 lines): (no headings detected)");
  });

  it("indents by level, pads line numbers, and annotates tags within 5 lines", () => {
    expect(buildOutline(cache)).toBe(
      [
        "Document outline (11 lines):",
        "  L 1: Introduction  ← {{NAME}} at L2, {{AMOUNT}} at L6",
        "  L 4:   Scope  ← {{AMOUNT}} at L6, {{NAME_ALT}} at L8",
        "  L 9: Closing",
      ].join("\n"),
    );
  });

  it("does not annotate tags more than 5 lines after a heading", () => {
    const c = makeCache(["h", "", "", "", "", "", "{{FAR}}"], [{ line: 1, level: 1, text: "H" }], [["FAR", 7]]);
    expect(buildOutline(c)).toBe("Document outline (7 lines):\n  L1: H");
  });
});

describe("queryByLineRange", () => {
  it("returns the requested window with line prefixes", () => {
    const r = queryByLineRange(cache, 4, 3);
    expect(r.lines).toBe("L4: [H2] Scope\nL5: Scope body\nL6: The {{AMOUNT}} applies");
    expect(r.matchInfo).toBe("Lines 4–6 of 11.");
    expect(r.outline).toBe(buildOutline(cache));
  });

  it("pads numbers to the width of the last shown line", () => {
    expect(queryByLineRange(cache, 9, 2).lines).toBe("L 9: [H1] Closing\nL10: Closing text");
  });

  it("clips the window at the end of the template", () => {
    const r = queryByLineRange(cache, 10, 5);
    expect(r.lines).toBe("L10: Closing text\nL11: Scope again");
    expect(r.matchInfo).toBe("Lines 10–11 of 11.");
  });

  it("clamps out-of-range starts", () => {
    expect(queryByLineRange(cache, 0, 1).matchInfo).toBe("Lines 1–1 (clamped from 0) of 11.");
    const high = queryByLineRange(cache, 99, 2);
    expect(high.matchInfo).toBe("Lines 11–11 (clamped from 99) of 11.");
    expect(high.lines).toBe("L11: Scope again");
  });
});

describe("queryBySearch", () => {
  it("finds the first case-insensitive match and centers the window", () => {
    const r = queryBySearch(cache, "SCOPE", 1);
    expect(r.matchInfo).toBe('Found "SCOPE" at L4.');
    expect(r.lines).toBe("L3: \nL4: [H2] Scope\nL5: Scope body");
  });

  it("shifts a clipped window forward instead of shrinking it", () => {
    expect(queryBySearch(cache, "introduction", 2).lines).toBe(
      "L1: [H1] Introduction\nL2: Intro text {{NAME}}\nL3: \nL4: [H2] Scope\nL5: Scope body",
    );
  });

  it("reports no match with the line count", () => {
    const r = queryBySearch(cache, "zzz", 2);
    expect(r.lines).toBe("");
    expect(r.matchInfo).toContain('No match for "zzz" in the template (11 lines).');
    expect(r.outline).toBe(buildOutline(cache));
  });
});

describe("queryByFieldKey", () => {
  describe("without template_key_map (markdown)", () => {
    const schema = createMockSchema();

    it("treats the field key as the tag", () => {
      const c = makeCache(["a", "{{s.f}}", "b"], [], [["s.f", 2]]);
      const r = queryByFieldKey(c, schema, "s.f", 1);
      expect(r.lines).toBe("L1: a\nL2: {{s.f}}\nL3: b");
      expect(r.matchInfo).toBe('Field "s.f" found at L2 (markdown template).');
    });

    it("lists available tags when not found", () => {
      const r = queryByFieldKey(cache, schema, "nope", 1);
      expect(r.lines).toBe("");
      expect(r.matchInfo).toBe('Field "nope" not found in template. Available tags: NAME, AMOUNT, NAME_ALT.');
    });

    it("truncates the tag list after 15 with an ellipsis", () => {
      const tags: [string, number][] = Array.from({ length: 16 }, (_, i) => [`T${i}`, 1]);
      const r = queryByFieldKey(makeCache(["x"], [], tags), schema, "nope", 1);
      expect(r.matchInfo).toContain("T14...");
      expect(r.matchInfo).not.toContain("T15");
    });
  });

  describe("with template_key_map", () => {
    const schema = createMockSchema({
      template_key_map: {
        NAME: "intro.name",
        NAME_ALT: { field: "intro.name" },
        AMOUNT: "money.amount",
        MISSING_TAG: "ghost.field",
      },
    } as never);

    it("finds the first mapped tag and notes other locations", () => {
      const r = queryByFieldKey(cache, schema, "intro.name", 1);
      expect(r.matchInfo).toBe('Field "intro.name" → {{NAME}} at L2. Also appears at L8 as {{NAME_ALT}}.');
      expect(r.lines).toBe("L1: [H1] Introduction\nL2: Intro text {{NAME}}\nL3: ");
    });

    it("uses the window around a single mapped tag", () => {
      const r = queryByFieldKey(cache, schema, "money.amount", 0);
      expect(r.lines).toBe("L6: The {{AMOUNT}} applies");
      expect(r.matchInfo).toBe('Field "money.amount" → {{AMOUNT}} at L6.');
    });

    it("reports unmapped fields with available mappings", () => {
      const r = queryByFieldKey(cache, schema, "nope.field", 1);
      expect(r.lines).toBe("");
      expect(r.matchInfo).toBe(
        'Field "nope.field" has no mapping in template_key_map. ' +
          "Available mappings: intro.name → {{NAME}}, money.amount → {{AMOUNT}}, ghost.field → {{MISSING_TAG}}.",
      );
    });

    it("adds an ellipsis when more than 10 fields are mapped", () => {
      const tkm = Object.fromEntries(Array.from({ length: 11 }, (_, i) => [`T${i}`, `s.f${i}`]));
      const r = queryByFieldKey(cache, createMockSchema({ template_key_map: tkm } as never), "nope", 1);
      expect(r.matchInfo).toMatch(/s\.f9 → \{\{T9\}\}\.\.\.\.$/);
      expect(r.matchInfo).not.toContain("s.f10");
    });

    it("explains when mapped tags are absent from the extracted text", () => {
      const r = queryByFieldKey(cache, schema, "ghost.field", 1);
      expect(r.lines).toBe("");
      expect(r.matchInfo).toContain("Tag(s) {{MISSING_TAG}} mapped to \"ghost.field\" not found");
      expect(r.matchInfo).toContain("splits a tag across formatting runs");
    });
  });
});

describe("getOrBuildCache", () => {
  beforeEach(() => {
    mocks.convertToHtml.mockReset();
    mocks.loadTemplateBuffer.mockReset();
  });

  it("registers an invalidation listener at import", () => {
    expect(mocks.listeners).toHaveLength(1);
  });

  it("builds from a markdown output_template with markdown headings and tags", async () => {
    const schema = createMockSchema({
      id: "md-1",
      output_template: "# Title\nHello {{a.b}} and {{#LOOP}}{{/LOOP}}\n## Sub {{c.d: hint here}}\n[H1] not a md heading",
    });
    const c = await getOrBuildCache(schema);
    expect(c.schemaId).toBe("md-1");
    expect(c.totalLines).toBe(4);
    expect(c.headingIndex).toEqual([
      { line: 1, level: 1, text: "Title" },
      { line: 3, level: 2, text: "Sub {{c.d: hint here}}" },
    ]);
    expect([...c.tagIndex]).toEqual([
      ["a.b", 2],
      ["LOOP", 2],
      ["c.d", 3],
    ]);
    expect(mocks.loadTemplateBuffer).not.toHaveBeenCalled();
  });

  it("extracts .docx via mammoth, keeping heading markers, bullets and entities", async () => {
    const buf = new ArrayBuffer(1);
    mocks.loadTemplateBuffer.mockResolvedValue(buf);
    mocks.convertToHtml.mockResolvedValue({
      value:
        '<h1 id="x"> Intro </h1><p>Name: {{NAME}}<br/>Line &amp; more</p>' +
        '<ul><li>one</li><li>two {{NAME}}</li></ul><p><img src="a.png"/>&lt;tag&gt;</p><h2>Sub</h2>',
    });
    const schema = createMockSchema({ id: "docx-1", docx_template: "t.docx" });
    const c = await getOrBuildCache(schema);
    expect(mocks.loadTemplateBuffer).toHaveBeenCalledWith(schema);
    expect(mocks.convertToHtml).toHaveBeenCalledWith({ arrayBuffer: buf });
    expect(c.lines).toEqual([
      "[H1] Intro",
      "Name: {{NAME}}",
      "Line & more",
      "",
      "• one",
      "• two {{NAME}}",
      "<tag>",
      "",
      "[H2] Sub",
    ]);
    expect(c.headingIndex).toEqual([
      { line: 1, level: 1, text: "Intro" },
      { line: 9, level: 2, text: "Sub" },
    ]);
    expect(c.tagIndex.get("NAME")).toBe(2);
  });

  it("decodes an escaped entity only once", async () => {
    mocks.loadTemplateBuffer.mockResolvedValue(new ArrayBuffer(1));
    mocks.convertToHtml.mockResolvedValue({ value: "<p>Use &amp;lt;b&amp;gt; for bold</p>" });
    const c = await getOrBuildCache(createMockSchema({ id: "docx-entity", docx_template: "t.docx" }));
    expect(c.lines[0]).toBe("Use &lt;b&gt; for bold");
  });

  it("returns the same promise on repeat calls without re-parsing", async () => {
    mocks.loadTemplateBuffer.mockResolvedValue(new ArrayBuffer(1));
    mocks.convertToHtml.mockResolvedValue({ value: "<p>x</p>" });
    const schema = createMockSchema({ id: "docx-cache", docx_template: "t.docx" });
    const p1 = getOrBuildCache(schema);
    const p2 = getOrBuildCache(schema);
    expect(p2).toBe(p1);
    await p1;
    await getOrBuildCache(schema);
    expect(mocks.convertToHtml).toHaveBeenCalledTimes(1);
  });

  it("rebuilds after onTemplateChanged fires for that schema only", async () => {
    mocks.loadTemplateBuffer.mockResolvedValue(new ArrayBuffer(1));
    mocks.convertToHtml.mockResolvedValue({ value: "<p>v1</p>" });
    const a = createMockSchema({ id: "docx-inv-a", docx_template: "a.docx" });
    const b = createMockSchema({ id: "docx-inv-b", docx_template: "b.docx" });
    expect((await getOrBuildCache(a)).lines).toEqual(["v1"]);
    await getOrBuildCache(b);
    expect(mocks.convertToHtml).toHaveBeenCalledTimes(2);

    mocks.convertToHtml.mockResolvedValue({ value: "<p>v2</p>" });
    mocks.listeners.forEach((l) => l("docx-inv-a"));
    expect((await getOrBuildCache(a)).lines).toEqual(["v2"]);
    expect((await getOrBuildCache(b)).lines).toEqual(["v1"]);
    expect(mocks.convertToHtml).toHaveBeenCalledTimes(3);
  });

  it("rejects schemas without a template and retries on the next call", async () => {
    const schema = createMockSchema({ id: "none-1" });
    await expect(getOrBuildCache(schema)).rejects.toThrow("Schema has no docx_template or output_template.");
    const p2 = getOrBuildCache(schema);
    await expect(p2).rejects.toThrow();
  });

  it("clears a failed load so the next call succeeds", async () => {
    mocks.loadTemplateBuffer.mockRejectedValueOnce(new Error("fetch failed"));
    mocks.loadTemplateBuffer.mockResolvedValue(new ArrayBuffer(1));
    mocks.convertToHtml.mockResolvedValue({ value: "<p>ok</p>" });
    const schema = createMockSchema({ id: "docx-retry", docx_template: "t.docx" });
    await expect(getOrBuildCache(schema)).rejects.toThrow("fetch failed");
    expect((await getOrBuildCache(schema)).lines).toEqual(["ok"]);
    expect(mocks.loadTemplateBuffer).toHaveBeenCalledTimes(2);
  });
});
