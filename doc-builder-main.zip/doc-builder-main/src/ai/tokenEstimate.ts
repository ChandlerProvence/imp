/**
 * Client-side token estimation utilities.
 *
 * Claude tokenizes at roughly 3.3 characters per token for English text.
 * These estimates are intentionally conservative (overestimate slightly)
 * so the radial progress indicator errs on the side of caution.
 */

import { findModelInfo } from "./models";

/** Estimate token count from a text string. */
export function estimateTokens(text: string): number {
  return Math.ceil(text.length / 3.3);
}

/** Estimate tokens for a conversation (messages + optional system prompt). */
export function estimateConversationTokens(
  messages: Array<{ content: string | null }>,
  systemPrompt?: string,
): number {
  let chars = systemPrompt?.length ?? 0;
  for (const msg of messages) {
    chars += msg.content?.length ?? 0;
  }
  // Add ~10% overhead for message framing/formatting
  return Math.ceil((chars * 1.1) / 3.3);
}

/** Fallback context window (tokens) when the proxy doesn't report one. */
export const DEFAULT_CONTEXT_WINDOW = 200_000;

/**
 * Get the context window size for a model ID — from LiteLLM `/model/info`
 * when discovery cached it, otherwise the default.
 */
export function getContextWindow(model: string): number {
  return findModelInfo(model)?.maxInputTokens ?? DEFAULT_CONTEXT_WINDOW;
}
