/**
 * Metrics for one AI Assistant conversation, computed from its stored
 * messages (a chat troubleshoot export). Pure; used by
 * tools/chat-run-metrics.ts for the LCSP drafting-quality baseline.
 */
import type { ToolCall, ResponseTimings } from "./types";
import type { DocumentSchema } from "../schemas/types";

export interface RunMessage {
  role: "user" | "assistant" | "tool";
  content: string;
  toolCalls?: ToolCall[];
  toolCallId?: string;
  timings?: ResponseTimings;
}

export interface RunMetrics {
  /** LLM calls that reported their own usage (timings.callUsage). */
  calls: number;
  /** Full input context per call: uncached + cache read + cache write. */
  contextTokensPerCall: { min: number; median: number; max: number } | null;
  totalContextTokens: number;
  /** Share of input tokens served from the prompt cache (0 when caching is off). */
  cacheReadShare: number;
  totalCompletionTokens: number;
  /** Tool calls by name, e.g. { propose_changes: 9, search_references: 4 }. */
  toolCalls: Record<string, number>;
  /** search_references results that returned no excerpts. */
  zeroHitSearches: number;
  /** Distinct field keys proposed across every propose_changes call. */
  proposedKeys: number;
  /** Present when a schema is supplied. */
  coverage?: {
    draftable: number;
    draftableProposed: number;
    factFields: number;
    factProposed: number;
    draftableMissing: string[];
  };
}

const DRAFTABLE = new Set(["freetext"]);
const ZERO_HIT = /^No (relevant excerpts|large reference documents)/;

function median(sorted: number[]): number {
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid] : Math.round((sorted[mid - 1] + sorted[mid]) / 2);
}

export function computeRunMetrics(messages: RunMessage[], schema?: DocumentSchema): RunMetrics {
  const prompt: number[] = [];
  let totalCacheRead = 0;
  let totalCompletion = 0;
  const toolCalls: Record<string, number> = {};
  const searchIds = new Set<string>();
  const proposed = new Set<string>();

  for (const m of messages) {
    if (m.role !== "assistant") continue;
    const u = m.timings?.callUsage;
    if (u) {
      const cacheRead = u.cacheReadTokens ?? 0;
      prompt.push(u.promptTokens + cacheRead + (u.cacheCreationTokens ?? 0));
      totalCacheRead += cacheRead;
      totalCompletion += u.completionTokens;
    }
    for (const c of m.toolCalls ?? []) {
      const name = c.function.name;
      toolCalls[name] = (toolCalls[name] ?? 0) + 1;
      if (name === "search_references") searchIds.add(c.id);
      if (name === "propose_changes") {
        try {
          const args = JSON.parse(c.function.arguments) as { changes?: Record<string, unknown> };
          for (const key of Object.keys(args.changes ?? {})) proposed.add(key);
        } catch {
          // Malformed arguments were rejected by the app too; nothing proposed.
        }
      }
    }
  }

  const zeroHitSearches = messages.filter(
    (m) => m.role === "tool" && m.toolCallId && searchIds.has(m.toolCallId) && ZERO_HIT.test(m.content),
  ).length;

  const sorted = [...prompt].sort((a, b) => a - b);
  const totalContext = prompt.reduce((a, b) => a + b, 0);
  const metrics: RunMetrics = {
    calls: prompt.length,
    contextTokensPerCall: sorted.length
      ? { min: sorted[0], median: median(sorted), max: sorted[sorted.length - 1] }
      : null,
    totalContextTokens: totalContext,
    cacheReadShare: totalContext > 0 ? Math.round((totalCacheRead / totalContext) * 100) / 100 : 0,
    totalCompletionTokens: totalCompletion,
    toolCalls,
    zeroHitSearches,
    proposedKeys: proposed.size,
  };

  if (schema) {
    let draftable = 0, draftableProposed = 0, factFields = 0, factProposed = 0;
    const draftableMissing: string[] = [];
    for (const section of schema.sections) {
      for (const field of section.fields) {
        if (field.same_as || field.formula !== undefined || field.type === "image") continue;
        const key = `${section.id}.${field.id}`;
        if (DRAFTABLE.has(field.type)) {
          draftable++;
          if (proposed.has(key)) draftableProposed++;
          else draftableMissing.push(key);
        } else {
          factFields++;
          if (proposed.has(key)) factProposed++;
        }
      }
    }
    metrics.coverage = { draftable, draftableProposed, factFields, factProposed, draftableMissing };
  }

  return metrics;
}

export function formatRunMetrics(m: RunMetrics): string {
  const lines: string[] = [];
  lines.push(`LLM calls with usage:     ${m.calls}`);
  if (m.contextTokensPerCall) {
    const p = m.contextTokensPerCall;
    lines.push(`Context tokens per call:  min ${p.min}  median ${p.median}  max ${p.max}`);
  } else {
    lines.push("Context tokens per call:  not recorded (export predates per-call usage)");
  }
  lines.push(`Total input tokens:       ${m.totalContextTokens}`);
  lines.push(`Served from cache:        ${Math.round(m.cacheReadShare * 100)}%`);
  lines.push(`Total completion tokens:  ${m.totalCompletionTokens}`);
  const tools = Object.entries(m.toolCalls).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k} ${v}`).join(", ");
  lines.push(`Tool calls:               ${tools || "none"}`);
  lines.push(`Zero-hit searches:        ${m.zeroHitSearches}`);
  lines.push(`Distinct fields proposed: ${m.proposedKeys}`);
  if (m.coverage) {
    const c = m.coverage;
    lines.push(`Freetext proposed:        ${c.draftableProposed} of ${c.draftable}`);
    lines.push(`Fact fields proposed:     ${c.factProposed} of ${c.factFields}`);
    if (c.draftableMissing.length) lines.push(`Missing drafts:           ${c.draftableMissing.join(", ")}`);
  }
  return lines.join("\n");
}
