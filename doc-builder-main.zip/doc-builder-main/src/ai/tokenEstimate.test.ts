import { beforeEach, describe, expect, it } from "vitest";
import { DEFAULT_CONTEXT_WINDOW, estimateConversationTokens, estimateTokens, getContextWindow } from "./tokenEstimate";
import { _resetModelsForTests, setDiscoveredModels } from "./models";

describe("estimateTokens", () => {
  it("is ceil(length / 3.3)", () => {
    expect(estimateTokens("")).toBe(0);
    expect(estimateTokens("a")).toBe(1);
    expect(estimateTokens("abc")).toBe(1);
    expect(estimateTokens("abcd")).toBe(2);
    expect(estimateTokens("x".repeat(33))).toBe(10);
    expect(estimateTokens("x".repeat(34))).toBe(11);
  });
});

describe("estimateConversationTokens", () => {
  it("returns 0 for an empty conversation", () => {
    expect(estimateConversationTokens([])).toBe(0);
  });

  it("sums message and system prompt chars with 10% overhead", () => {
    // ceil((10 + 20 + 3) * 1.1 / 3.3)
    expect(estimateConversationTokens([{ content: "x".repeat(10) }, { content: "y".repeat(20) }], "abc")).toBe(
      Math.ceil((33 * 1.1) / 3.3),
    );
    expect(estimateConversationTokens([{ content: "x".repeat(300) }])).toBe(100);
  });

  it("treats null content as empty", () => {
    expect(estimateConversationTokens([{ content: null }, { content: "x".repeat(300) }])).toBe(100);
  });

  it("counts a system prompt alone", () => {
    expect(estimateConversationTokens([], "x".repeat(300))).toBe(100);
  });
});

describe("getContextWindow", () => {
  beforeEach(() => {
    _resetModelsForTests();
  });

  it("DEFAULT_CONTEXT_WINDOW is 200k", () => {
    expect(DEFAULT_CONTEXT_WINDOW).toBe(200_000);
  });

  it("returns the default for an unknown model", () => {
    expect(getContextWindow("no-such-model")).toBe(DEFAULT_CONTEXT_WINDOW);
  });

  it("returns maxInputTokens from discovered model info on any endpoint", () => {
    setDiscoveredModels("cui", ["big-model"], { "big-model": { maxInputTokens: 1_000_000 } });
    setDiscoveredModels("non-cui", ["small-model"], { "small-model": { maxInputTokens: 32_000 } });
    expect(getContextWindow("big-model")).toBe(1_000_000);
    expect(getContextWindow("small-model")).toBe(32_000);
  });

  it("falls back to the default when info lacks maxInputTokens", () => {
    setDiscoveredModels("cui", ["m"], { m: {} });
    expect(getContextWindow("m")).toBe(DEFAULT_CONTEXT_WINDOW);
  });
});
