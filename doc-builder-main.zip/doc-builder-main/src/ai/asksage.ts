// ---------------------------------------------------------------------------
// AskSage API Client — SharePoint / M365 integration via MCP tools
// ---------------------------------------------------------------------------
// Calls the AskSage REST API to authenticate, verify connectivity, and
// execute Microsoft 365 MCP tools (search_files, list_items, ms_get_file_content).
//
// API docs:  https://docs.asksage.ai/docs/v2/api-documentation/api-documentation
// Instance:  api.asksage.leidos.com
// Reference: /home/chuw/code/m365-asksage-claude-skill/scripts/_mcp.py
// Lessons:   docs/asksage-m365-integration.md
//
// ---------------------------------------------------------------------------
// STATUS: DISABLED PENDING ASKSAGE TEAM APPROVAL. DO NOT DELETE.
// ---------------------------------------------------------------------------
// SharePoint / OneDrive search through AskSage is a capability we intend to
// ship. This file, AskSageContext.tsx and SharePointSearch.tsx are complete and
// kept on purpose, even though nothing reaches them while the feature is off.
// They are hidden by the `askSage` feature flag (src/ai/featureFlags.ts,
// default false), which hides the Settings section and shows a "Coming soon"
// placeholder in the document picker's SharePoint column (the column itself
// stays so the picker layout doesn't change).
//
// Why it is off: the deployed site (GitLab Pages) calls api.asksage.leidos.com
// cross-origin, and the AskSage API does not send CORS headers for our origin,
// so the browser blocks every request (see isCorsBlockedError below). It only
// works under `npm run dev`, where the Vite proxy (/api/asksage) makes the
// calls same-origin.
//
// What we need from the AskSage team: allow our production origin in the CORS
// policy of api.asksage.leidos.com.
//   - Origin:          https://ams-oot.pages.lsde.leidos.com
//   - Methods:         POST, plus the OPTIONS preflight
//   - Request headers: Content-Type, Accept, x-access-tokens
//   - Endpoints:       POST /user/get-token-with-api-key
//                      POST /server/get-models
//                      POST /server/query (M365 MCP tools)
//   - Credentials:     not needed (no cookies; auth is the x-access-tokens
//                      header), so Access-Control-Allow-Credentials is not
//                      required
// If the app moves to another host (e.g. a high-side deployment), that origin
// needs the same allowance.
//
// Gate for re-enabling: AskSage confirms the CORS change, AND on the
// production URL (not the dev server), with `{"askSage":true}` set in
// localStorage "doc-builder:ai-feature-flags", Settings → AskSage → Test
// shows "✓ Connected" and a SharePoint search in the document picker returns
// results that can be attached. Then:
//   1. set `askSage: true` in DEFAULTS in src/ai/featureFlags.ts;
//   2. remove this STATUS block and the "currently disabled" notes in
//      docs/help/asksage-setup.md, docs/help/settings.md,
//      docs/help/api-key-setup.md, README.md and
//      docs/asksage-m365-integration.md;
//   3. update docs/public/development-plan.md and docs/RUNBOOK.md.

import { assertAllowedFetchUrl } from "../utils/urlAllowlist";

// ---------------------------------------------------------------------------
// Error types
// ---------------------------------------------------------------------------

/** Thrown when AskSage rejects a token (expired or invalid). */
export class TokenInvalidError extends Error {
  constructor(detail: string) {
    super(`AskSage token rejected: ${detail}`);
    this.name = "TokenInvalidError";
  }
}

// ---------------------------------------------------------------------------
// CORS detection
// ---------------------------------------------------------------------------

/**
 * Detect CORS-blocked fetch errors in production.
 *
 * Browsers throw an opaque TypeError when a cross-origin fetch is blocked by
 * CORS policy.  The exact message varies:
 *   - Firefox:  "NetworkError when attempting to fetch resource"
 *   - Chrome:   "Failed to fetch"
 *   - Safari:   "Load failed"
 *
 * In dev mode the Vite proxy makes AskSage calls same-origin, so a TypeError
 * there is a genuine network problem (server down / DNS failure), not CORS.
 */
function isCorsBlockedError(err: unknown): boolean {
  if (!(err instanceof TypeError) || import.meta.env.DEV) return false;
  if (!/fetch|network|load failed/i.test(err.message)) return false;
  const base = getAsksageBaseUrl();
  try {
    return new URL(base).origin !== window.location.origin;
  } catch {
    return base.startsWith("http");
  }
}

function corsErrorMessage(raw: string): string {
  return (
    "The browser blocked this request due to cross-origin (CORS) restrictions. " +
    "The deployed site cannot connect directly to api.asksage.leidos.com. " +
    "AskSage features require running the app locally via the dev server " +
    "(npm run dev), where a built-in proxy handles this automatically.\n\n" +
    `Original error: ${raw}`
  );
}

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const ASKSAGE_BASE_URL = "https://api.asksage.leidos.com";
const ASKSAGE_DEV_PROXY = "/api/asksage";

/** localStorage keys for AskSage credentials. */
export const ASKSAGE_EMAIL_KEY = "doc-builder:asksage-email";
export const ASKSAGE_API_KEY_KEY = "doc-builder:asksage-api-key";

/** Access tokens are cached for this many milliseconds before refreshing. */
const TOKEN_TTL_MS = 30 * 60 * 1000; // 30 minutes

/**
 * Model for MCP tool execution. Must be a Claude model — GPT models silently
 * ignore MCP tools. Try Google-hosted first, Bedrock as fallback.
 */
const MCP_MODELS = [
  "google-claude-46-sonnet",
  "aws-bedrock-claude-45-sonnet-gov",
] as const;

// ---------------------------------------------------------------------------
// MCP Tool Definitions
// ---------------------------------------------------------------------------
// These schemas must include function_type, server_id, server_name, and
// require_approval for the AskSage server to execute them. Copied from the
// reference skill at m365-asksage-claude-skill/scripts/_mcp.py.

interface McpToolDef {
  name: string;
  description: string;
  server_id: number;
  server_name: string;
  function_type: "mcp";
  require_approval: false;
  parameters: {
    type: "object";
    properties: Record<string, { type: string; description: string }>;
    required?: string[];
  };
}

const SEARCH_FILES_TOOL: McpToolDef = {
  name: "search_files",
  description: "Search for files and folders across OneDrive and SharePoint.",
  server_id: 1,
  server_name: "Microsoft 365",
  function_type: "mcp",
  require_approval: false,
  parameters: {
    type: "object",
    properties: {
      query: { type: "string", description: "Search query string" },
      max_results: { type: "integer", description: "Maximum number of results" },
    },
    required: ["query"],
  },
};

const LIST_ITEMS_TOOL: McpToolDef = {
  name: "list_items",
  description: "List files and folders in OneDrive/SharePoint.",
  server_id: 1,
  server_name: "Microsoft 365",
  function_type: "mcp",
  require_approval: false,
  parameters: {
    type: "object",
    properties: {
      path: { type: "string", description: "Path to list (e.g. /Documents)" },
      drive_id: { type: "string", description: "Drive ID to list from" },
    },
  },
};

const GET_FILE_CONTENT_TOOL: McpToolDef = {
  name: "ms_get_file_content",
  description: "Retrieve and process file contents from Microsoft 365.",
  server_id: 1,
  server_name: "Microsoft 365",
  function_type: "mcp",
  require_approval: false,
  parameters: {
    type: "object",
    properties: {
      item_id: { type: "string", description: "The full item ID (from list_items or search_files)" },
    },
    required: ["item_id"],
  },
};

const GET_ITEM_METADATA_TOOL: McpToolDef = {
  name: "get_item_metadata",
  description: "Get detailed metadata for a file or folder.",
  server_id: 1,
  server_name: "Microsoft 365",
  function_type: "mcp",
  require_approval: false,
  parameters: {
    type: "object",
    properties: {
      item_id: { type: "string", description: "The full item ID (from list_items or search_files)" },
    },
    required: ["item_id"],
  },
};

/** All file-related MCP tools (exported for natural-language query use). */
export const M365_FILE_TOOLS: McpToolDef[] = [
  SEARCH_FILES_TOOL,
  LIST_ITEMS_TOOL,
  GET_FILE_CONTENT_TOOL,
  GET_ITEM_METADATA_TOOL,
];

// ---------------------------------------------------------------------------
// Public types
// ---------------------------------------------------------------------------

/** A file/folder item returned from search_files or list_items. */
export interface SharePointItem {
  id: string;
  name: string;
  type: "file" | "folder";
  size: number;
  webUrl: string;
  createdDateTime: string;
  lastModifiedDateTime: string;
  mimeType?: string;
  path?: string | null;
  parentId?: string | null;
  childCount?: number;
  downloadUrl?: string | null;
  _searchRank?: number;
  _searchSummary?: string;
}

/** Result from an MCP tool call. */
export interface McpToolResult<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
}

// ---------------------------------------------------------------------------
// Token cache (module-level)
// ---------------------------------------------------------------------------

let cachedToken: { value: string; email: string; expiresAt: number } | null = null;

// ---------------------------------------------------------------------------
// URL helpers
// ---------------------------------------------------------------------------

/** Returns the base URL for AskSage API calls (dev proxy or production). */
export function getAsksageBaseUrl(): string {
  return import.meta.env.DEV ? ASKSAGE_DEV_PROXY : ASKSAGE_BASE_URL;
}

// ---------------------------------------------------------------------------
// Credential storage
// ---------------------------------------------------------------------------

export function getAsksageCredentials(): { email: string | null; apiKey: string | null } {
  return {
    email: localStorage.getItem(ASKSAGE_EMAIL_KEY),
    apiKey: localStorage.getItem(ASKSAGE_API_KEY_KEY),
  };
}

export function saveAsksageCredentials(email: string, apiKey: string): void {
  const trimmedEmail = email.trim();
  const trimmedKey = apiKey.trim();
  if (trimmedEmail) {
    localStorage.setItem(ASKSAGE_EMAIL_KEY, trimmedEmail);
  } else {
    localStorage.removeItem(ASKSAGE_EMAIL_KEY);
  }
  if (trimmedKey) {
    localStorage.setItem(ASKSAGE_API_KEY_KEY, trimmedKey);
  } else {
    localStorage.removeItem(ASKSAGE_API_KEY_KEY);
  }
  cachedToken = null;
}

export function clearAsksageCredentials(): void {
  localStorage.removeItem(ASKSAGE_EMAIL_KEY);
  localStorage.removeItem(ASKSAGE_API_KEY_KEY);
  cachedToken = null;
}

// ---------------------------------------------------------------------------
// Authentication
// ---------------------------------------------------------------------------

/**
 * Authenticates with AskSage and returns an access token.
 * Caches the token for TOKEN_TTL_MS and reuses it across calls.
 */
export async function getAccessToken(email: string, apiKey: string): Promise<string> {
  const trimmedEmail = email.trim();
  const trimmedKey = apiKey.trim();
  if (!trimmedEmail || !trimmedKey) {
    throw new Error("AskSage email and API key are both required.");
  }

  if (cachedToken && cachedToken.email === trimmedEmail && Date.now() < cachedToken.expiresAt) {
    return cachedToken.value;
  }

  const base = getAsksageBaseUrl();
  const url = `${base}/user/get-token-with-api-key`;
  assertAllowedFetchUrl(url);

  let res: Response;
  try {
    res = await fetch(url, {
      method: "POST",
      headers: {
        "Accept": "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email: trimmedEmail, api_key: trimmedKey }),
    });
  } catch (err) {
    if (isCorsBlockedError(err)) {
      throw new Error(corsErrorMessage((err as Error).message));
    }
    throw err;
  }

  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new Error(`AskSage auth failed (${res.status}): ${body || res.statusText}`);
  }

  const data = await res.json();

  // AskSage returns { response: "<jwt>", status: 200 } on success.
  // On failure it returns { response: "error message", status: 400 } (still HTTP 200).
  const statusCode = Number(data?.status);
  if (statusCode >= 400) {
    const raw = String(data?.response ?? "").trim();
    const hint = /missing.*field|required.*field/i.test(raw)
      ? " Make sure both your email and API key are filled in."
      : /key|api.key/i.test(raw)
        ? " Check that your API key is correct — you may need to regenerate it at asksage.leidos.com."
        : /email/i.test(raw)
          ? " Check that your email matches the one tied to your AskSage account."
          : "";
    throw new Error(`AskSage authentication failed: ${raw || `error ${statusCode}`}.${hint}`);
  }

  // Extract the token — primary path is data.response as a JWT string.
  const raw = data?.response;
  const token =
    (typeof raw === "string" ? raw : null) ??
    raw?.access_token ??
    data?.access_token ??
    data?.token;

  // Validate: a JWT has three base64 segments separated by dots.
  const isJwt = typeof token === "string" && /^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(token);
  if (!isJwt) {
    console.error("[AskSage] Auth response body (no valid token):", JSON.stringify(data, null, 2));
    throw new Error(
      `AskSage auth did not return a valid token. Response: ${String(token ?? raw ?? "").slice(0, 200)}`,
    );
  }

  cachedToken = { value: token, email: trimmedEmail, expiresAt: Date.now() + TOKEN_TTL_MS };
  return token;
}

/** Evict the cached token so the next `getAccessToken` call re-authenticates. */
export function invalidateToken(): void {
  cachedToken = null;
}

// ---------------------------------------------------------------------------
// Connection test
// ---------------------------------------------------------------------------

/**
 * Tests AskSage connectivity by authenticating and hitting /server/get-models.
 */
export async function testAsksageConnection(
  email: string,
  apiKey: string,
): Promise<{ ok: boolean; error?: string }> {
  try {
    const token = await getAccessToken(email, apiKey);

    const base = getAsksageBaseUrl();
    const url = `${base}/server/get-models`;
    assertAllowedFetchUrl(url);

    let res: Response;
    try {
      res = await fetch(url, {
        method: "POST",
        headers: {
          "x-access-tokens": token,
          "Content-Type": "application/json",
        },
      });
    } catch (fetchErr) {
      if (isCorsBlockedError(fetchErr)) {
        return { ok: false, error: corsErrorMessage((fetchErr as Error).message) };
      }
      throw fetchErr;
    }

    if (!res.ok) {
      return { ok: false, error: `Server returned ${res.status}` };
    }

    return { ok: true };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : "Connection failed" };
  }
}

// ---------------------------------------------------------------------------
// Diagnostic helpers
// ---------------------------------------------------------------------------

function devLog(label: string, ...args: unknown[]): void {
  if (import.meta.env.DEV) {
    console.groupCollapsed(`[AskSage] ${label}`);
    args.forEach((a) => console.log(a));
    console.groupEnd();
  }
}

function buildDiagnosticError(
  operation: string,
  status: number,
  contentType: string | null,
  body: string,
): Error {
  const parts = [
    `AskSage ${operation} failed`,
    `HTTP ${status}`,
    `Content-Type: ${contentType ?? "(none)"}`,
  ];
  if (body) {
    parts.push(`Body: ${body.slice(0, 500)}`);
  } else {
    parts.push("Body: (empty)");
  }
  return new Error(parts.join(" | "));
}

// ---------------------------------------------------------------------------
// MCP tool execution
// ---------------------------------------------------------------------------

/**
 * Extracts parsed MCP tool response data from the API response message.
 * The server wraps tool results in `<mcp-content>...</mcp-content>` tags.
 */
function extractMcpContent(message: string): unknown[] | null {
  const startTag = "<mcp-content>";
  const endTag = "</mcp-content>";
  const startIdx = message.indexOf(startTag);
  const endIdx = message.indexOf(endTag);
  if (startIdx === -1 || endIdx === -1) return null;
  const json = message.slice(startIdx + startTag.length, endIdx).trim();
  try {
    return JSON.parse(json);
  } catch {
    return null;
  }
}

/**
 * Invoke a single MCP tool with explicit parameters via `/server/query`.
 *
 * Uses a deterministic prompt format — the model is instructed to call the
 * named tool with the exact parameters provided, minimising LLM interpretation.
 */
async function mcpCall(
  token: string,
  toolName: string,
  params: Record<string, unknown>,
  toolDef: McpToolDef,
): Promise<McpToolResult> {
  const base = getAsksageBaseUrl();
  const url = `${base}/server/query`;
  assertAllowedFetchUrl(url);

  const paramStr = JSON.stringify(params);
  const payload = {
    message: [
      { user: "gpt", message: "I can help you with Microsoft 365 operations." },
      { user: "me", message: `Call the ${toolName} tool with exactly these parameters: ${paramStr}` },
    ],
    model: MCP_MODELS[0], // google-claude-46-sonnet (primary)
    streaming: false,
    tool_choice: "auto",
    tools: [toolDef],
    enabled_mcp_tools: [toolName],
    tools_to_execute: [toolName],
    dataset: "none",
  };

  devLog(`mcpCall(${toolName})`, { url, params, model: payload.model });

  let res: Response;
  try {
    res = await fetch(url, {
      method: "POST",
      headers: {
        "x-access-tokens": token,
        "Accept": "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });
  } catch (err) {
    if (isCorsBlockedError(err)) {
      throw new Error(corsErrorMessage((err as Error).message));
    }
    throw err;
  }

  const text = await res.text();

  devLog(`mcpCall(${toolName}) response`, {
    status: res.status,
    contentType: res.headers.get("content-type"),
    bodyPreview: text.slice(0, 500),
  });

  if (!res.ok) {
    throw buildDiagnosticError(
      `MCP ${toolName}`,
      res.status,
      res.headers.get("content-type"),
      text,
    );
  }

  let data: Record<string, unknown>;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error(`AskSage MCP ${toolName}: response is not JSON — ${text.slice(0, 200)}`);
  }

  // Detect token rejection — AskSage returns { response: "Token is invalid ...", status: 400 }
  const respMsg = typeof data.response === "string" ? data.response : "";
  if (
    respMsg.toLowerCase().includes("token") &&
    (respMsg.toLowerCase().includes("invalid") || respMsg.toLowerCase().includes("expired")) ||
    Number(data.status) === 401
  ) {
    invalidateToken();
    throw new TokenInvalidError(respMsg || `status ${data.status}`);
  }

  // Check for model errors (e.g. 502 from Bedrock)
  const apiError = data.error as Record<string, unknown> | null | undefined;
  if (apiError?.code === "model_error") {
    const httpStatus = apiError.http_status ?? "unknown";
    throw new Error(
      `AskSage model error (${httpStatus}) for ${toolName}. ` +
      `Model "${payload.model}" may be unavailable — try again shortly.`,
    );
  }

  // Extract <mcp-content> from the message
  const message = String(data.message ?? "");
  if (message.includes("Internal error")) {
    throw new Error(`AskSage MCP ${toolName}: ${message}`);
  }

  const mcpData = extractMcpContent(message);
  if (!mcpData) {
    // No MCP content — the model may have responded in text instead of calling the tool.
    // Build a diagnostic string from whatever the API did return.
    const diag: string[] = [`No MCP response for ${toolName}.`];
    if (message) {
      diag.push(`Message: ${message.slice(0, 300)}`);
    }
    // Surface other top-level keys that might explain the failure
    const extras = Object.entries(data)
      .filter(([k]) => k !== "message")
      .map(([k, v]) => `${k}: ${typeof v === "string" ? v.slice(0, 120) : JSON.stringify(v)}`)
      .join(" | ");
    if (extras) diag.push(extras);
    if (diag.length === 1) diag.push("The server returned an empty response.");

    return { success: false, error: diag.join("\n") };
  }

  // Find the tool result in the MCP data array
  for (const item of mcpData as Record<string, unknown>[]) {
    if (item.tool === toolName) {
      const toolResp = item.response;
      if (Array.isArray(toolResp) && toolResp.length > 0) {
        const first = toolResp[0] as Record<string, unknown>;
        if (first.status === "success") {
          return { success: true, data: first.data ?? first };
        } else {
          return { success: false, error: String(first.message ?? JSON.stringify(first)) };
        }
      }
      return { success: true, data: toolResp };
    }
  }

  return { success: false, error: `Tool "${toolName}" not found in MCP response` };
}

// ---------------------------------------------------------------------------
// SharePoint convenience wrappers
// ---------------------------------------------------------------------------

/**
 * Searches SharePoint/OneDrive via the MCP search_files tool.
 * Returns a structured list of matching files.
 */
export async function searchSharePoint(
  token: string,
  query: string,
  maxResults = 10,
): Promise<McpToolResult<{ items: SharePointItem[] }>> {
  const params: Record<string, unknown> = { query };
  if (maxResults !== 10) params.max_results = maxResults;

  const result = await mcpCall(token, "search_files", params, SEARCH_FILES_TOOL);
  return result as McpToolResult<{ items: SharePointItem[] }>;
}

/**
 * Lists files/folders at a OneDrive/SharePoint path.
 */
export async function listSharePointItems(
  token: string,
  path?: string,
): Promise<McpToolResult<{ items: SharePointItem[] }>> {
  const params: Record<string, unknown> = {};
  if (path) params.path = path;

  const result = await mcpCall(token, "list_items", params, LIST_ITEMS_TOOL);
  return result as McpToolResult<{ items: SharePointItem[] }>;
}

/**
 * Fetches the text content of a SharePoint/OneDrive file by item ID.
 * The item_id comes from search_files or list_items results.
 *
 * If ms_get_file_content fails (e.g. cross-site RESOURCE_ERROR), falls back
 * to get_item_metadata to retrieve a downloadUrl, which the caller can use.
 */
export async function fetchFileContent(
  token: string,
  itemId: string,
): Promise<McpToolResult<{ content?: string; downloadUrl?: string; mimeType?: string; name?: string }>> {
  const result = await mcpCall(token, "ms_get_file_content", { item_id: itemId }, GET_FILE_CONTENT_TOOL);

  if (result.success) {
    return result as McpToolResult<{ content: string; mimeType?: string; name?: string }>;
  }

  // Fallback: try get_item_metadata for a downloadUrl (cross-site items need this)
  devLog("fetchFileContent fallback", { itemId, originalError: result.error });
  const metaResult = await mcpCall(token, "get_item_metadata", { item_id: itemId }, GET_ITEM_METADATA_TOOL);
  if (metaResult.success && metaResult.data) {
    const meta = metaResult.data as Record<string, unknown>;
    if (meta.downloadUrl) {
      return {
        success: true,
        data: {
          downloadUrl: String(meta.downloadUrl),
          name: meta.name ? String(meta.name) : undefined,
          mimeType: meta.mimeType ? String(meta.mimeType) : undefined,
        },
      };
    }
  }

  // Both failed — return the original error
  return result as McpToolResult<{ content?: string; downloadUrl?: string; mimeType?: string; name?: string }>;
}
