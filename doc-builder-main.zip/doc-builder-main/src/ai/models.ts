// ---------------------------------------------------------------------------
// Model resolution
// ---------------------------------------------------------------------------
// Single place that decides which model ID each AI feature uses. Configured
// defaults live in `ENDPOINTS` (endpoints.ts); this module layers on top:
//
//   1. user override (Settings → AI Models)
//   2. configured default, if the proxy still lists it
//   3. newest same-family substitute from the discovered list (family is
//      inferred from the configured ID, e.g. "sonnet", so roles stay vendor-neutral)
//   4. configured default (fails with the friendly "model unavailable" error)
//
// Everything is synchronous and localStorage-backed so non-React code
// (litellm.ts, effortTiers.ts, embeddings.ts) can call it directly.

import { ENDPOINTS, type EndpointId } from "./endpoints";

/**
 * Capability classes, not vendor families: light ≈ Haiku / GPT mini,
 * standard ≈ Sonnet / GPT-5, advanced ≈ Opus / GPT-5 Pro.
 */
export type ModelRole = "light" | "standard" | "advanced" | "embedding";

/** Cost and capability metadata from LiteLLM `/model/info`. */
export interface ModelInfo {
  /** USD per 1M input tokens. */
  inputCostPerMTok?: number;
  /** USD per 1M output tokens. */
  outputCostPerMTok?: number;
  maxInputTokens?: number;
}

export type ModelSource = "override" | "default" | "substituted" | "missing";

export interface RoleResolution {
  role: ModelRole;
  /** Model ID that will be sent. */
  id: string;
  source: ModelSource;
  /** Configured default from `ENDPOINTS`. */
  configured: string;
}

interface DiscoveredEntry {
  ids: string[];
  info?: Record<string, ModelInfo>;
  fetchedAt: number;
}

type Overrides = Partial<Record<EndpointId, Partial<Record<ModelRole, string>>>>;
type Discovered = Partial<Record<EndpointId, DiscoveredEntry>>;

// ---------------------------------------------------------------------------
// localStorage keys
// ---------------------------------------------------------------------------

export const MODEL_OVERRIDES_KEY = "doc-builder:model-overrides";
export const DISCOVERED_MODELS_KEY = "doc-builder:discovered-models";

/** Role names stored before roles became vendor-neutral. */
const LEGACY_ROLES: Record<string, ModelRole> = { sonnet: "standard", opus: "advanced", luna: "light" };

// ---------------------------------------------------------------------------
// Storage helpers
// ---------------------------------------------------------------------------

function readJson<T extends object>(key: string): T {
  try {
    const raw = localStorage.getItem(key);
    const parsed: unknown = raw ? JSON.parse(raw) : {};
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? (parsed as T) : ({} as T);
  } catch {
    return {} as T;
  }
}

function writeJson(key: string, value: object): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Storage full or blocked — resolution still works from defaults
  }
}

// ---------------------------------------------------------------------------
// Change notification (so React can re-render when non-React code changes state)
// ---------------------------------------------------------------------------

const listeners = new Set<() => void>();

/** Subscribe to override / discovery / availability changes. Returns an unsubscribe fn. */
export function subscribeModels(fn: () => void): () => void {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}

function notify(): void {
  for (const fn of listeners) fn();
}

// ---------------------------------------------------------------------------
// Defaults, overrides, discovery
// ---------------------------------------------------------------------------

/** Roles that apply to an endpoint, in Settings display order. */
export function rolesFor(_ep: EndpointId): ModelRole[] {
  return ["standard", "advanced", "light", "embedding"];
}

/** Configured default from `ENDPOINTS`. */
export function defaultModel(ep: EndpointId, role: ModelRole): string {
  const config = ENDPOINTS[ep];
  if (role === "embedding") return config.embeddingModel;
  return config.models[role];
}

/** Stored overrides, migrating legacy family-named roles (sonnet/opus/luna) in place. */
function readOverrides(): Overrides {
  const all = readJson<Overrides>(MODEL_OVERRIDES_KEY);
  let migrated = false;
  for (const entry of Object.values(all)) {
    if (!entry || typeof entry !== "object") continue;
    const raw = entry as Record<string, string | undefined>;
    for (const [legacy, role] of Object.entries(LEGACY_ROLES)) {
      if (!(legacy in raw)) continue;
      if (raw[role] === undefined) raw[role] = raw[legacy];
      delete raw[legacy];
      migrated = true;
    }
  }
  if (migrated) writeJson(MODEL_OVERRIDES_KEY, all);
  return all;
}

export function getModelOverrides(ep: EndpointId): Partial<Record<ModelRole, string>> {
  return readOverrides()[ep] ?? {};
}

/** Set (or clear with null/empty) the user's override for one role. */
export function setModelOverride(ep: EndpointId, role: ModelRole, id: string | null): void {
  const all = readOverrides();
  const forEp = { ...(all[ep] ?? {}) };
  const trimmed = id?.trim();
  if (trimmed) forEp[role] = trimmed;
  else delete forEp[role];
  all[ep] = forEp;
  writeJson(MODEL_OVERRIDES_KEY, all);
  notify();
}

/** Model IDs the proxy reported for this endpoint, or null if never discovered. */
export function getDiscoveredModels(ep: EndpointId): string[] | null {
  return readJson<Discovered>(DISCOVERED_MODELS_KEY)[ep]?.ids ?? null;
}

export function getDiscoveredAt(ep: EndpointId): number | null {
  return readJson<Discovered>(DISCOVERED_MODELS_KEY)[ep]?.fetchedAt ?? null;
}

/**
 * Store the discovered model list. Passing `info` replaces the cached
 * metadata; omitting it keeps whatever was cached before.
 */
export function setDiscoveredModels(ep: EndpointId, ids: string[], info?: Record<string, ModelInfo>): void {
  const all = readJson<Discovered>(DISCOVERED_MODELS_KEY);
  const nextInfo = info ?? all[ep]?.info;
  all[ep] = { ids, fetchedAt: Date.now(), ...(nextInfo ? { info: nextInfo } : {}) };
  writeJson(DISCOVERED_MODELS_KEY, all);
  // A fresh list supersedes session-level "unavailable" marks
  unavailableThisSession.delete(ep);
  notify();
}

/** Cached cost/context metadata for a model, if `/model/info` provided it. */
export function getModelInfo(ep: EndpointId, id: string): ModelInfo | undefined {
  return readJson<Discovered>(DISCOVERED_MODELS_KEY)[ep]?.info?.[id];
}

/** Cached metadata for a model ID on any endpoint (for callers that only have the ID). */
export function findModelInfo(id: string): ModelInfo | undefined {
  const all = readJson<Discovered>(DISCOVERED_MODELS_KEY);
  for (const entry of Object.values(all)) {
    const info = entry?.info?.[id];
    if (info) return info;
  }
  return undefined;
}

const unavailableThisSession = new Map<EndpointId, Set<string>>();

/**
 * Record that a request with this model failed as "model unavailable", so the
 * next resolution substitutes even before the next discovery runs.
 */
export function markModelUnavailable(ep: EndpointId, id: string): void {
  const set = unavailableThisSession.get(ep) ?? new Set<string>();
  if (set.has(id)) return;
  set.add(id);
  unavailableThisSession.set(ep, set);
  notify();
}

function isUnavailable(ep: EndpointId, id: string): boolean {
  if (unavailableThisSession.get(ep)?.has(id)) return true;
  const ids = getDiscoveredModels(ep);
  return ids !== null && !ids.includes(id);
}

// ---------------------------------------------------------------------------
// Ranking
// ---------------------------------------------------------------------------

/** Family tokens recognized in model IDs, e.g. "claude-sonnet-5-5-…" → "sonnet". */
const KNOWN_FAMILIES = ["haiku", "sonnet", "opus", "fable", "luna", "mini", "nano"];

const isNumericSegment = (seg: string) => /^[\d.]+$/.test(seg);

/**
 * Test for IDs in the same family as the configured one. The family comes
 * from the configured ID (a known token, else its first non-numeric segment),
 * so a retired Sonnet is replaced by a newer Sonnet, never by an Opus.
 * The token must appear as whole `-`-delimited segment(s) of the ID.
 */
function familyMatcher(role: ModelRole, configured: string): (id: string) => boolean {
  if (role === "embedding") return (id) => id.toLowerCase().includes("embed");
  const segments = configured.toLowerCase().split("-");
  const token =
    segments.find((seg) => KNOWN_FAMILIES.includes(seg)) ??
    segments.find((seg) => !isNumericSegment(seg)) ??
    configured.toLowerCase();
  return (id) => `-${id.toLowerCase()}-`.includes(`-${token}-`);
}

// ---------------------------------------------------------------------------
// Model type
// ---------------------------------------------------------------------------
// `/v1/models` carries no type information (and `/model/info`, which has
// `mode`, is blocked for user keys), so the type is inferred from the name.

export type ModelKind = "chat" | "embedding" | "other";

/** The model type each role needs. */
export const ROLE_KIND: Record<ModelRole, ModelKind> = {
  light: "chat",
  standard: "chat",
  advanced: "chat",
  embedding: "embedding",
};

const EMBEDDING_RE = /embed/i;
const NON_CHAT_RE = /image|realtime|tts|whisper|transcribe|audio|dall-?e|moderation/i;

/** Name-based guess at a model's type. */
export function classifyModel(id: string): ModelKind {
  if (EMBEDDING_RE.test(id)) return "embedding";
  if (NON_CHAT_RE.test(id)) return "other";
  return "chat";
}

/** IDs of the type a role needs (chat roles get chat models, etc.). */
export function modelsForRole(role: ModelRole, ids: readonly string[]): string[] {
  return ids.filter((id) => classifyModel(id) === ROLE_KIND[role]);
}

/** The model's apparent type when it doesn't fit the role, else null. */
export function kindMismatch(role: ModelRole, id: string): ModelKind | null {
  const kind = classifyModel(id);
  return kind === ROLE_KIND[role] ? null : kind;
}

/** First numeric version in an ID, e.g. "claude-4-6-sonnet…" → [4, 6]. */
function parseVersion(id: string): [number, number] {
  const m = id.match(/(\d+)(?:[-.](\d+))?/);
  return m ? [Number(m[1]), Number(m[2] ?? 0)] : [0, 0];
}

function compareVersion(a: string, b: string): number {
  const [aMaj, aMin] = parseVersion(a);
  const [bMaj, bMin] = parseVersion(b);
  return aMaj - bMaj || aMin - bMin;
}

/** Number of trailing "-" segments two IDs share (deployment suffix, e.g. "aws-comm-il2"). */
function sharedSuffix(a: string, b: string): number {
  const as = a.split("-");
  const bs = b.split("-");
  let n = 0;
  while (n < as.length && n < bs.length && as[as.length - 1 - n] === bs[bs.length - 1 - n]) n++;
  return n;
}

/**
 * Trailing segments before the version or family token, e.g. 3 ("aws-comm-il2")
 * for both "claude-4-6-sonnet-aws-comm-il2" and "claude-sonnet-5-5-aws-comm-il2".
 */
function deploymentLength(role: ModelRole, configured: string): number {
  const inFamily = familyMatcher(role, configured);
  const segments = configured.split("-");
  let n = 0;
  for (let i = segments.length - 1; i >= 0; i--) {
    if (isNumericSegment(segments[i]) || inFamily(segments[i])) break;
    n++;
  }
  return n;
}

/** How much of the configured ID's deployment suffix a candidate shares. */
function deploymentScore(role: ModelRole, id: string, configured: string): number {
  return Math.min(sharedSuffix(id, configured), deploymentLength(role, configured));
}

/**
 * Same-family candidates ranked best first: same deployment suffix as the
 * configured ID first, then highest version.
 */
export function rankCandidates(role: ModelRole, configured: string, ids: readonly string[]): string[] {
  const inFamily = familyMatcher(role, configured);
  return ids
    .filter((id) => inFamily(id) && classifyModel(id) === ROLE_KIND[role])
    .sort(
      (a, b) =>
        deploymentScore(role, b, configured) - deploymentScore(role, a, configured) || compareVersion(b, a),
    );
}

/** Best available replacement for a missing model, or undefined. */
export function pickSubstitute(
  role: ModelRole,
  configured: string,
  ids: readonly string[],
  exclude: ReadonlySet<string> = new Set(),
): string | undefined {
  return rankCandidates(role, configured, ids).find((id) => id !== configured && !exclude.has(id));
}

// ---------------------------------------------------------------------------
// Resolution
// ---------------------------------------------------------------------------

/**
 * Full resolution for one role, including where the ID came from.
 * `ignoreOverride` gives what "Default" would resolve to (for Settings).
 */
export function resolveRole(
  ep: EndpointId,
  role: ModelRole,
  opts: { ignoreOverride?: boolean } = {},
): RoleResolution {
  const configured = defaultModel(ep, role);
  const override = opts.ignoreOverride ? undefined : getModelOverrides(ep)[role];
  if (override) return { role, id: override, source: "override", configured };

  if (!isUnavailable(ep, configured)) return { role, id: configured, source: "default", configured };

  const substitute = pickSubstitute(
    role,
    configured,
    getDiscoveredModels(ep) ?? [],
    unavailableThisSession.get(ep),
  );
  if (substitute) return { role, id: substitute, source: "substituted", configured };
  return { role, id: configured, source: "missing", configured };
}

/** The model ID to send for a role on an endpoint. */
export function resolveModel(ep: EndpointId, role: ModelRole): string {
  return resolveRole(ep, role).id;
}

/** Resolution for every role on an endpoint — for Settings, notices, diagnostics. */
export function getModelResolution(ep: EndpointId): RoleResolution[] {
  return rolesFor(ep).map((role) => resolveRole(ep, role));
}

/** Pure: the best-ranked same-deployment model newer than `current`, or undefined. */
function newerThan(role: ModelRole, configured: string, current: string, ids: readonly string[]): string | undefined {
  const best = rankCandidates(role, configured, ids)[0];
  if (!best || best === current) return undefined;
  // Only suggest a model on the same deployment as the configured one
  if (deploymentScore(role, best, configured) < deploymentScore(role, current, configured)) return undefined;
  return compareVersion(best, current) > 0 ? best : undefined;
}

/**
 * A newer same-family model the user could opt into, or undefined. Never
 * applied automatically — the configured model stays pinned while available.
 */
export function newerModelFor(ep: EndpointId, role: ModelRole): string | undefined {
  const configured = defaultModel(ep, role);
  const ids = getDiscoveredModels(ep);
  if (!ids) return undefined;
  return newerThan(role, configured, resolveModel(ep, role), ids);
}

/** Test-only: clear in-memory state. */
export function _resetModelsForTests(): void {
  unavailableThisSession.clear();
  listeners.clear();
}
