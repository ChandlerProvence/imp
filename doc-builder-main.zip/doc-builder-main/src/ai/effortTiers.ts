import { getActiveEndpointId } from "./endpoints";
import { resolveModel } from "./models";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/** AI effort tiers — determines model, effort parameter, and thinking config. */
export type EffortTier = "low" | "medium" | "high";

export interface ResolvedEffortConfig {
  tier: EffortTier;
  model: string;
  effort: "low" | "medium" | undefined;
  enableThinking: boolean;
  thinkingBudget: number;
  /** Per-tier streaming inter-chunk timeout (ms). Undefined → use global default. */
  streamTimeout?: number;
}

// ---------------------------------------------------------------------------
// Display labels
// ---------------------------------------------------------------------------

export const TIER_ICONS: Record<EffortTier, string> = {
  low: "⚡",
  medium: "⚖️",
  high: "🔬",
};

export const TIER_LABELS: Record<EffortTier, string> = {
  low: "Fast",
  medium: "Balanced",
  high: "Thorough",
};

export const TIER_TOOLTIPS: Record<EffortTier, string> = {
  low: "Standard model · low effort",
  medium: "Standard model · medium effort",
  high: "Advanced model · thinking",
};

// ---------------------------------------------------------------------------
// Resolution
// ---------------------------------------------------------------------------

/** Map a tier to concrete model/effort/thinking parameters. */
export function resolveEffortConfig(tier: EffortTier): ResolvedEffortConfig {
  const ep = getActiveEndpointId();
  switch (tier) {
    case "low":
      return {
        tier: "low",
        model: resolveModel(ep, "standard"),
        effort: "low",
        enableThinking: false,
        thinkingBudget: 0,
      };
    case "medium":
      return {
        tier: "medium",
        model: resolveModel(ep, "standard"),
        effort: "medium",
        enableThinking: false,
        thinkingBudget: 0,
      };
    case "high":
      return {
        tier: "high",
        model: resolveModel(ep, "advanced"),
        effort: undefined, // thinking replaces effort
        enableThinking: true,
        thinkingBudget: 10000,
        // Stream timeout matches the global 24-hour default — no per-tier
        // override needed, but kept explicit for clarity.
        streamTimeout: 86_400_000, // 24 h
      };
  }
}
