import { describe, it, expect } from "vitest";
import {
  parseAskUserArgs,
  formatAnswersToolResult,
  parseAnsweredAskUser,
  findPendingAskUser,
  type AskUserScannableMessage,
  type QuestionAnswer,
} from "./askUserTypes";

// ---------------------------------------------------------------------------
// parseAskUserArgs
// ---------------------------------------------------------------------------

describe("parseAskUserArgs", () => {
  it("parses a well-formed single question", () => {
    const args = JSON.stringify({
      questions: [
        {
          header: "Tone",
          question: "What tone should the background use?",
          options: [{ label: "Formal", recommended: true }, { label: "Plain-language" }],
        },
      ],
    });
    const questions = parseAskUserArgs(args);
    expect(questions).toHaveLength(1);
    expect(questions![0]).toEqual({
      header: "Tone",
      question: "What tone should the background use?",
      fieldKey: null,
      multiSelect: false,
      options: [
        { label: "Formal", recommended: true },
        { label: "Plain-language" },
      ],
    });
  });

  it("maps field_key and multi_select to camelCase", () => {
    const args = JSON.stringify({
      questions: [
        {
          header: "Scope",
          question: "Which sections apply?",
          field_key: "scope.sections",
          multi_select: true,
          options: [{ label: "A" }, { label: "B" }],
        },
      ],
    });
    const questions = parseAskUserArgs(args);
    expect(questions![0].fieldKey).toBe("scope.sections");
    expect(questions![0].multiSelect).toBe(true);
  });

  it("returns null for invalid JSON", () => {
    expect(parseAskUserArgs("not json")).toBeNull();
  });

  it("returns null when questions is missing or not an array", () => {
    expect(parseAskUserArgs(JSON.stringify({}))).toBeNull();
    expect(parseAskUserArgs(JSON.stringify({ questions: "nope" }))).toBeNull();
  });

  it("drops a question with fewer than 2 options", () => {
    const args = JSON.stringify({
      questions: [
        { header: "Bad", question: "Only one option?", options: [{ label: "Only" }] },
      ],
    });
    expect(parseAskUserArgs(args)).toBeNull();
  });

  it("drops a question missing header or question text", () => {
    const args = JSON.stringify({
      questions: [
        { question: "No header", options: [{ label: "A" }, { label: "B" }] },
        { header: "No question text", options: [{ label: "A" }, { label: "B" }] },
      ],
    });
    expect(parseAskUserArgs(args)).toBeNull();
  });

  it("clamps to a maximum of 4 questions", () => {
    const questions = Array.from({ length: 6 }, (_, i) => ({
      header: `Q${i}`,
      question: `Question ${i}?`,
      options: [{ label: "A" }, { label: "B" }],
    }));
    const parsed = parseAskUserArgs(JSON.stringify({ questions }));
    expect(parsed).toHaveLength(4);
  });

  it("clamps to a maximum of 6 options per question", () => {
    const options = Array.from({ length: 10 }, (_, i) => ({ label: `Opt${i}` }));
    const parsed = parseAskUserArgs(
      JSON.stringify({ questions: [{ header: "Many", question: "Pick one?", options }] }),
    );
    expect(parsed![0].options).toHaveLength(6);
  });

  it("drops malformed options but keeps the question if enough valid options remain", () => {
    const args = JSON.stringify({
      questions: [
        {
          header: "Mixed",
          question: "Pick?",
          options: [{ label: "Good" }, { notLabel: "bad" }, { label: "Also good" }],
        },
      ],
    });
    const parsed = parseAskUserArgs(args);
    expect(parsed![0].options).toEqual([{ label: "Good" }, { label: "Also good" }]);
  });

  it("filters out entirely-malformed questions while keeping valid ones", () => {
    const args = JSON.stringify({
      questions: [
        { header: "Valid", question: "Pick?", options: [{ label: "A" }, { label: "B" }] },
        { header: "Invalid", question: "Pick?", options: [{ label: "OnlyOne" }] },
      ],
    });
    const parsed = parseAskUserArgs(args);
    expect(parsed).toHaveLength(1);
    expect(parsed![0].header).toBe("Valid");
  });
});

// ---------------------------------------------------------------------------
// formatAnswersToolResult / parseAnsweredAskUser
// ---------------------------------------------------------------------------

describe("formatAnswersToolResult", () => {
  it("formats a single-select answer", () => {
    const answers: QuestionAnswer[] = [
      { header: "Tone", question: "Tone?", fieldKey: null, selected: ["Formal"] },
    ];
    const result = formatAnswersToolResult(answers);
    const parsed = JSON.parse(result);
    expect(parsed.summary).toBe('User answered: Tone → Formal');
    expect(parsed.answers).toEqual(answers);
  });

  it("formats a multi-select answer with multiple choices", () => {
    const answers: QuestionAnswer[] = [
      { header: "Scope", question: "Which?", fieldKey: null, selected: ["A", "B"] },
    ];
    const result = formatAnswersToolResult(answers);
    expect(JSON.parse(result).summary).toBe("User answered: Scope → A, B");
  });

  it("formats an Other-only answer", () => {
    const answers: QuestionAnswer[] = [
      { header: "Length", question: "How long?", fieldKey: null, selected: [], otherText: "one paragraph max" },
    ];
    const result = formatAnswersToolResult(answers);
    expect(JSON.parse(result).summary).toBe('User answered: Length → Other: "one paragraph max"');
  });

  it("combines selected options with Other text", () => {
    const answers: QuestionAnswer[] = [
      { header: "Scope", question: "Which?", fieldKey: null, selected: ["A"], otherText: "and also C" },
    ];
    const result = formatAnswersToolResult(answers);
    expect(JSON.parse(result).summary).toBe('User answered: Scope → A, Other: "and also C"');
  });

  it("formats a skipped answer", () => {
    const answers: QuestionAnswer[] = [
      { header: "Tone", question: "Tone?", fieldKey: null, selected: [], skipped: true },
    ];
    const result = formatAnswersToolResult(answers);
    expect(JSON.parse(result).summary).toBe("User answered: Tone → (skipped)");
  });

  it("formats multiple questions joined with semicolons", () => {
    const answers: QuestionAnswer[] = [
      { header: "Tone", question: "Tone?", fieldKey: null, selected: ["Formal"] },
      { header: "Length", question: "Length?", fieldKey: null, selected: [], skipped: true },
    ];
    const result = formatAnswersToolResult(answers);
    expect(JSON.parse(result).summary).toBe(
      "User answered: Tone → Formal; Length → (skipped)",
    );
  });

  it("round-trips through parseAnsweredAskUser", () => {
    const answers: QuestionAnswer[] = [
      { header: "Tone", question: "Tone?", fieldKey: "background.tone", selected: ["Formal"] },
    ];
    const content = formatAnswersToolResult(answers);
    expect(parseAnsweredAskUser(content)).toEqual(answers);
  });

  it("parseAnsweredAskUser returns null for non-answer content", () => {
    expect(parseAnsweredAskUser(JSON.stringify({ status: "ok" }))).toBeNull();
    expect(parseAnsweredAskUser("not json")).toBeNull();
  });
});

// ---------------------------------------------------------------------------
// findPendingAskUser
// ---------------------------------------------------------------------------

describe("findPendingAskUser", () => {
  function askUserMessage(toolCallId: string, questions: unknown[]): AskUserScannableMessage {
    return {
      role: "assistant",
      toolCalls: [
        {
          id: toolCallId,
          function: { name: "ask_user", arguments: JSON.stringify({ questions }) },
        },
      ],
    };
  }

  const sampleQuestions = [
    { header: "Tone", question: "Tone?", options: [{ label: "Formal" }, { label: "Casual" }] },
  ];

  it("returns null when there are no ask_user calls", () => {
    const messages: AskUserScannableMessage[] = [{ role: "user" }, { role: "assistant" }];
    expect(findPendingAskUser(messages)).toBeNull();
  });

  it("finds an unanswered ask_user call", () => {
    const messages: AskUserScannableMessage[] = [
      { role: "user" },
      askUserMessage("tc1", sampleQuestions),
    ];
    const pending = findPendingAskUser(messages);
    expect(pending).not.toBeNull();
    expect(pending!.toolCallId).toBe("tc1");
    expect(pending!.questions).toHaveLength(1);
  });

  it("returns null when the ask_user call already has a matching tool result", () => {
    const messages: AskUserScannableMessage[] = [
      askUserMessage("tc1", sampleQuestions),
      { role: "tool", toolCallId: "tc1" },
    ];
    expect(findPendingAskUser(messages)).toBeNull();
  });

  it("finds the most recent unanswered call when there are multiple ask_user calls", () => {
    const messages: AskUserScannableMessage[] = [
      askUserMessage("tc1", sampleQuestions),
      { role: "tool", toolCallId: "tc1" },
      askUserMessage("tc2", sampleQuestions),
    ];
    const pending = findPendingAskUser(messages);
    expect(pending!.toolCallId).toBe("tc2");
  });

  it("skips an ask_user call with unparseable arguments", () => {
    const messages: AskUserScannableMessage[] = [
      {
        role: "assistant",
        toolCalls: [{ id: "tc1", function: { name: "ask_user", arguments: "not json" } }],
      },
    ];
    expect(findPendingAskUser(messages)).toBeNull();
  });
});
