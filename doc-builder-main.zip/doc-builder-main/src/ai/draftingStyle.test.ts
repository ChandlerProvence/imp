import { beforeEach, describe, expect, it, vi } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

vi.mock("./litellm", () => ({ fetchChatCompletion: vi.fn() }));

import { fetchChatCompletion } from "./litellm";
import {
  STYLE_ANALYSIS_INSTRUCTION,
  STYLE_ANALYSIS_MAX_TOKENS,
  STYLE_ANALYSIS_TIMEOUT_MS,
  STYLE_REFERENCE_MAX_CHARS,
  buildStyleAnalysisMessages,
  deriveDraftingStyle,
  stripMachineBlocks,
  styleTextOf,
} from "./draftingStyle";
import { AppErrorException } from "../errors";

const fixture = readFileSync(resolve(__dirname, "../test/fixtures/style-reference/lcsp-prior.txt"), "utf8");

describe("buildStyleAnalysisMessages", () => {
  it("sends the fixed instruction as the system message", () => {
    const [system] = buildStyleAnalysisMessages([{ fileName: "a.docx", text: "x" }]);
    expect(system).toEqual({ role: "system", content: STYLE_ANALYSIS_INSTRUCTION });
    expect(STYLE_ANALYSIS_INSTRUCTION).toContain("Do NOT summarize the content");
  });

  it("keeps defects and template-owned structure out of the note", () => {
    expect(STYLE_ANALYSIS_INSTRUCTION).toContain("ignore typos, formatting defects, inconsistencies");
    expect(STYLE_ANALYSIS_INSTRUCTION).toContain("never tell the writer to reproduce them");
    expect(STYLE_ANALYSIS_INSTRUCTION).toContain("Leave out structure a template supplies");
    expect(STYLE_ANALYSIS_INSTRUCTION).toContain("naming any sections whose format differs");
    expect(STYLE_ANALYSIS_INSTRUCTION).toContain("signature blocks");
    expect(STYLE_ANALYSIS_INSTRUCTION).toContain("only where the sources support it");
    expect(STYLE_ANALYSIS_INSTRUCTION).toContain("section-number cross-references");
    expect(STYLE_ANALYSIS_INSTRUCTION).toContain("as-of dates");
    expect(STYLE_ANALYSIS_INSTRUCTION).toContain("not where it departs from them");
  });

  it("asks for placeholders instead of the document's names and values in examples", () => {
    expect(STYLE_ANALYSIS_INSTRUCTION).toContain("bracketed placeholder");
    expect(STYLE_ANALYSIS_INSTRUCTION).toContain("never write the document's actual names or values");
    expect(STYLE_ANALYSIS_INSTRUCTION).not.toContain("use of tables");
  });

  it("does not truncate a document under the budget", () => {
    const [, user] = buildStyleAnalysisMessages([{ fileName: "prior.docx", text: fixture }]);
    expect(user.content).toBe(`<document filename="prior.docx">\n${fixture}\n</document>`);
  });

  it("truncates to the budget, split evenly across documents", () => {
    const long = "a".repeat(STYLE_REFERENCE_MAX_CHARS * 2);
    const [, one] = buildStyleAnalysisMessages([{ fileName: "a", text: long }]);
    expect(one.content).toContain("a".repeat(STYLE_REFERENCE_MAX_CHARS) + "\n</document>");
    expect(one.content).not.toContain("a".repeat(STYLE_REFERENCE_MAX_CHARS + 1));

    const half = STYLE_REFERENCE_MAX_CHARS / 2;
    const [, two] = buildStyleAnalysisMessages([
      { fileName: "a", text: long },
      { fileName: "b", text: "b".repeat(STYLE_REFERENCE_MAX_CHARS) },
    ]);
    expect(two.content).toContain("a".repeat(half) + "\n</document>");
    expect(two.content).not.toContain("a".repeat(half + 1));
    expect(two.content).toContain('<document filename="b">\n' + "b".repeat(half) + "\n</document>");
  });

  it("matches the snapshot for the fixture (catches instruction drift)", () => {
    expect(buildStyleAnalysisMessages([{ fileName: "lcsp-prior.txt", text: fixture }])).toMatchSnapshot();
  });
});

describe("stripMachineBlocks", () => {
  it("removes vision transcriptions, including nested brackets", () => {
    const text = "Intro paragraph.\n\n[Image: | Col | Val |\n|---|---|\n| a | [illegible] |\n- see [link](x)]\n\nNext paragraph.";
    expect(stripMachineBlocks(text)).toBe("Intro paragraph.\n\nNext paragraph.");
  });

  it("removes quarantine and raw image placeholders and the skipped-images note", () => {
    const text =
      "A.\n[Image quarantined — pending CUI confirmation (IMAGE_0)]\nB.\n[IMAGE_1]\nC.\n\n[Note: 3 additional images were not processed]";
    expect(stripMachineBlocks(text)).toBe("A.\n\nB.\n\nC.");
  });

  it("leaves author brackets alone", () => {
    const text = "Availability is [X] percent per [SERVICE] guidance.";
    expect(stripMachineBlocks(text)).toBe(text);
  });
});

describe("styleTextOf", () => {
  it("drops standalone image uploads and image-only documents", () => {
    expect(
      styleTextOf([
        { fileName: "scan.png", text: "# Transcribed heading\n- bullet" },
        { fileName: "figs.docx", text: "[Image: chart]" },
        { fileName: "prior.docx", text: "Prose." },
      ]),
    ).toEqual([{ fileName: "prior.docx", text: "Prose." }]);
  });

  it("keeps image transcriptions out of the analysis request", () => {
    const [, user] = buildStyleAnalysisMessages([
      { fileName: "prior.docx", text: "Prose.\n[Image: ## Heading\n- vision bullet]" },
    ]);
    expect(user.content).not.toContain("vision bullet");
  });
});

describe("deriveDraftingStyle", () => {
  beforeEach(() => {
    vi.mocked(fetchChatCompletion).mockReset();
  });

  it("returns the trimmed note from one standard-model call", async () => {
    vi.mocked(fetchChatCompletion).mockResolvedValue({ content: "\n- Bullets for lists.\n", usage: null, model: "m" });
    await expect(deriveDraftingStyle([{ fileName: "a", text: "x" }])).resolves.toBe("- Bullets for lists.");
    expect(fetchChatCompletion).toHaveBeenCalledTimes(1);
    const [messages, options] = vi.mocked(fetchChatCompletion).mock.calls[0];
    expect(messages[0].content).toBe(STYLE_ANALYSIS_INSTRUCTION);
    expect(options).toEqual({ maxTokens: STYLE_ANALYSIS_MAX_TOKENS, signal: expect.any(AbortSignal) });
  });

  it("rejects a note cut off at the token limit instead of saving it", async () => {
    vi.mocked(fetchChatCompletion).mockResolvedValue({
      content: "- Voice: third person only. The register is formal,",
      usage: null,
      model: "m",
      stopReason: "max_tokens",
    });
    await expect(deriveDraftingStyle([{ fileName: "a", text: "x" }])).rejects.toMatchObject({
      appError: { kind: "ai.bad-response" },
    });
  });

  /** A fetch that never answers on its own and rejects as aborted when its signal fires. */
  const hangUntilAborted = () =>
    vi.mocked(fetchChatCompletion).mockImplementation(
      (_m, opts) =>
        new Promise((_resolve, reject) => {
          opts!.signal!.addEventListener("abort", () => reject(new DOMException("Aborted", "AbortError")));
        }),
    );

  it("gives up with ai.timeout when the service stalls", async () => {
    vi.useFakeTimers();
    try {
      hangUntilAborted();
      const pending = deriveDraftingStyle([{ fileName: "a", text: "x" }]).catch((e) => e);
      await vi.advanceTimersByTimeAsync(STYLE_ANALYSIS_TIMEOUT_MS);
      const err = await pending;
      expect((err as AppErrorException).appError.kind).toBe("ai.timeout");
    } finally {
      vi.useRealTimers();
    }
  });

  it("passes the caller's abort through as an abort, not a timeout", async () => {
    hangUntilAborted();
    const controller = new AbortController();
    const pending = deriveDraftingStyle([{ fileName: "a", text: "x" }], controller.signal).catch((e) => e);
    controller.abort();
    const err = await pending;
    expect(err).toBeInstanceOf(DOMException);
    expect((err as DOMException).name).toBe("AbortError");
  });

  it("refuses image-only references without calling the model", async () => {
    const err = await deriveDraftingStyle([{ fileName: "scan.png", text: "transcribed" }]).catch((e) => e);
    expect((err as AppErrorException).appError.kind).toBe("file.no-text");
    expect(fetchChatCompletion).not.toHaveBeenCalled();
  });

  it("throws ai.bad-response on an empty reply", async () => {
    vi.mocked(fetchChatCompletion).mockResolvedValue({ content: "  ", usage: null, model: "m" });
    const err = await deriveDraftingStyle([{ fileName: "a", text: "x" }]).catch((e) => e);
    expect(err).toBeInstanceOf(AppErrorException);
    expect((err as AppErrorException).appError.kind).toBe("ai.bad-response");
  });
});
