import { describe, it, expect } from "vitest";
import {
  extractProposedChangesJson,
  stripProposedChanges,
} from "./parseProposedChanges";

// ---------------------------------------------------------------------------
// extractProposedChangesJson
// ---------------------------------------------------------------------------

describe("extractProposedChangesJson", () => {
  it("returns null when no block is present", () => {
    expect(extractProposedChangesJson("Just a normal message")).toBeNull();
  });

  it("returns null for empty block", () => {
    expect(
      extractProposedChangesJson("<proposed-changes></proposed-changes>"),
    ).toBeNull();
  });

  it("returns null for whitespace-only block", () => {
    expect(
      extractProposedChangesJson("<proposed-changes>   \n  </proposed-changes>"),
    ).toBeNull();
  });

  it("extracts JSON content from block", () => {
    const json = '{"field": "value"}';
    const content = `Some text\n<proposed-changes>\n${json}\n</proposed-changes>\nMore text`;
    expect(extractProposedChangesJson(content)).toBe(json);
  });

  it("trims whitespace from extracted content", () => {
    const content = `<proposed-changes>  {"a":1}  </proposed-changes>`;
    expect(extractProposedChangesJson(content)).toBe('{"a":1}');
  });

  it("extracts only the first block when multiple exist", () => {
    const content =
      '<proposed-changes>first</proposed-changes> text <proposed-changes>second</proposed-changes>';
    expect(extractProposedChangesJson(content)).toBe("first");
  });
});

// ---------------------------------------------------------------------------
// stripProposedChanges
// ---------------------------------------------------------------------------

describe("stripProposedChanges", () => {
  it("returns text unchanged when no block present", () => {
    expect(stripProposedChanges("Hello world")).toBe("Hello world");
  });

  it("removes a single block and trims", () => {
    const content =
      "Before <proposed-changes>content</proposed-changes> After";
    expect(stripProposedChanges(content)).toBe("Before  After");
  });

  it("removes multiple blocks", () => {
    const content =
      "A <proposed-changes>x</proposed-changes> B <proposed-changes>y</proposed-changes> C";
    expect(stripProposedChanges(content)).toBe("A  B  C");
  });

  it("handles multiline blocks", () => {
    const content = `Text before
<proposed-changes>
{"changes": []}
</proposed-changes>
Text after`;
    expect(stripProposedChanges(content)).toBe("Text before\n\nText after");
  });
});
