import type { DocumentSchema } from "../schemas/types";
import { buildPersonaLine, todayLine, GROUNDING_RULES, decodeBasicEntities } from "./promptUtils";

// ---------------------------------------------------------------------------
// Document Review Utilities
// ---------------------------------------------------------------------------

/**
 * Build a system prompt tuned for document review rather than field editing.
 *
 * The drafting prompt is heavily biased toward propose_changes; this prompt
 * frames the AI as a reviewer that discusses the document holistically and
 * uses report_observations as the primary output. propose_changes is still
 * available for follow-up fixes if the user asks.
 */
export function buildReviewSystemPrompt(
  schema: DocumentSchema,
  sourceSchemas?: DocumentSchema[],
  draftingStyle?: string,
): string {
  const lines: string[] = [
    buildPersonaLine(schema, "reviewer analyzing"),
    todayLine(),
    "",
    "## Your Task",
    "Review the generated document attached by the user for quality issues.",
    "Report ALL observations via `report_observations`. After reporting, provide a brief overall assessment — do NOT re-list individual findings (the user sees them in a structured Observations panel).",
    "",
    "## Observation Categories",
    "- **conflict**: Values that contradict each other (dates out of order, amounts that don't sum, contradictory statements)",
    "- **gap**: Missing information, empty sections, or content that a reader would expect but isn't present",
    "- **assumption**: Inferred content that may be wrong or needs user confirmation",
    "- **quality**: Unprofessional tone, incomplete sentences, non-sequiturs, or content that doesn't match the document's purpose",
    "- **placeholder**: Template artifacts like \"[Not provided]\", \"{{...}}\", obviously auto-generated filler, or incomplete sections",
    "",
    "## Tools",
    "- **`report_observations`**: Report ALL issues found (or an empty observations array if clean). Set the `type`, `severity`, and quote the relevant excerpt(s) in `sources`.",
    "- **`propose_changes`**: Only use if the user explicitly asks you to fix an issue. Do NOT propose field changes unprompted during review.",
    "- **`get_field_info`**: Look up field definitions, AI hints, and current answers for specific sections.",
    "- **`search_references`**: Search the document content and any attached reference documents by query.",
    "- **`get_template_context`**: View the original template structure around a field to check if generated content matches the expected format." +
      (sourceSchemas && sourceSchemas.length > 1
        ? " For document sets, pass `schema_id` to specify which document's template to query."
        : ""),
    "",
    "## Rules",
    ...GROUNDING_RULES.map((r) => `- ${r}`),
    "- Call `report_observations` with all findings in one batch. Do not narrate each issue before the tool call — the user sees structured observations in a dedicated panel.",
    "- Only flag genuine, actionable issues — not stylistic preferences or minor formatting choices.",
    "- Focus on cross-cutting problems that emerge from the combination of fields — individual field validation was already done earlier.",
    "- For each issue, provide a clear, actionable `recommendation`.",
    "- In the `sources` array, quote the relevant excerpt(s) from the generated document showing the problem.",
    "- Reference documents may carry a `role` attribute (e.g. role=\"pr\") assigned by the user. When present, a \"Source document guidance\" section in the user message explains what each role is authoritative for.",
    "- Report a **conflict** when a value in the generated document disagrees with the reference document whose role is authoritative for it (e.g. a funding amount that differs from the PR). Do not flag disagreement with a document that its guidance says not to use for that value.",
    "- If a reference document's content clearly does not match its assigned role (e.g. a document tagged role=\"pr\" reads like a vendor quote), report a **conflict** naming the document and the role it was given, and recommend moving it to the correct slot. Do not use it as authoritative for that role's values when checking the generated document.",
    "- In `sources`, name a reference document by its role title when it has one (e.g. \"PR (Purchase Request)\"), otherwise by filename.",
  ];

  // For set reviews, list the available schemas so the AI can use schema_id
  if (sourceSchemas && sourceSchemas.length > 1) {
    lines.push(
      "",
      "## Document Set",
      "This session contains multiple documents. Each is attached separately.",
      "Available schema_id values for `get_template_context`:",
    );
    for (const s of sourceSchemas) {
      const templateType = s.docx_template ? "Word" : s.output_template ? "Markdown" : "no template";
      lines.push(`- \`${s.id}\` — "${s.title}" (${templateType})`);
    }
  }

  const style = draftingStyle?.trim();
  if (style) {
    lines.push(
      "",
      "## Drafting Style",
      "The customer asked for the following style. Content written this way (for example, bullet-heavy sections) is not a **quality** issue; flag only departures from it.",
      style,
    );
  }

  return lines.join("\n");
}

// ---------------------------------------------------------------------------
// Document Outline Builder
// ---------------------------------------------------------------------------

/**
 * Extract a compact heading outline from document content.
 * Used in RAG mode so the AI can see the document structure without the full text.
 */
export function buildDocumentOutline(
  content: string,
  format: "markdown" | "text",
): string {
  const headings: { level: number; text: string }[] = [];

  if (format === "markdown") {
    // Match markdown headings: # Heading, ## Heading, etc.
    const headingRegex = /^(#{1,6})\s+(.+)$/gm;
    let match;
    while ((match = headingRegex.exec(content)) !== null) {
      headings.push({ level: match[1].length, text: match[2].trim() });
    }
  } else {
    // Match numbered headings in plain text (e.g., "1. Introduction", "4.3 Maintenance Planning")
    // and ALL-CAPS lines that look like section titles
    const lines = content.split("\n");
    for (const line of lines) {
      const trimmed = line.trim();
      // Numbered section headings
      const numbered = trimmed.match(/^(\d+(?:\.\d+)*)\s+(.+)/);
      if (numbered) {
        const depth = numbered[1].split(".").length;
        headings.push({ level: depth, text: trimmed });
        continue;
      }
      // ALL-CAPS lines (at least 3 chars, not a table row)
      if (
        trimmed.length >= 3 &&
        trimmed === trimmed.toUpperCase() &&
        /[A-Z]/.test(trimmed) &&
        !trimmed.includes("|")
      ) {
        headings.push({ level: 1, text: trimmed });
      }
    }
  }

  if (headings.length === 0) {
    return "(No headings found in document)";
  }

  return headings
    .map((h) => {
      const indent = "  ".repeat(Math.max(0, h.level - 1));
      return `${indent}- ${h.text}`;
    })
    .join("\n");
}

/**
 * Strip HTML tags to produce plain text for AI review.
 * Preserves whitespace structure (paragraphs become double newlines).
 */
export function stripHtmlTags(html: string): string {
  const withoutTags = html
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/p>/gi, "\n\n")
    .replace(/<\/h[1-6]>/gi, "\n\n")
    .replace(/<\/li>/gi, "\n")
    .replace(/<\/tr>/gi, "\n")
    .replace(/<[^>]*>/g, "");
  return decodeBasicEntities(withoutTags)
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}
