import type { DocumentSchema, TableColumnDef } from "../schemas/types";
import type { FieldMeta } from "../db/types";
import { parseTableData } from "../engine/tableData";

/**
 * Build a standardized persona opening line for system prompts.
 * @param schema - The document schema (provides the title)
 * @param role - Mode-specific role phrase, e.g. "drafting assistant helping write sections of"
 */
export function buildPersonaLine(schema: DocumentSchema, role: string): string {
  return `You are a professional document ${role} a "${schema.title}".`;
}

/**
 * Standard heading for the existing-answers context section in system prompts.
 */
export const ANSWERS_SECTION_HEADING = "## Working Draft (current field values of the document being built)";

/**
 * Framing that follows ANSWERS_SECTION_HEADING. Prevents the AI from treating
 * its own prior proposals (now stored as answers) as evidence — a common
 * failure in multi-turn chats where the draft echoes back into the prompt.
 */
export const ANSWERS_SECTION_PREAMBLE =
  "These are the values currently entered in the document you are producing. " +
  "Many were proposed by you in earlier turns. This is your OUTPUT, not a source — " +
  "never cite these values as evidence, and never attribute them to an uploaded document. " +
  "Use them only to avoid redundant proposals and to keep new values consistent.";

/**
 * Compact field-type constraint descriptions for system prompts.
 * Provides explicit type rules to reduce coercion errors.
 */
export const FIELD_TYPE_RULES =
  "Type rules: string = plain text; number = numeric value; boolean = true/false; " +
  "date = YYYY-MM-DD; enum = exactly one of the listed options; " +
  "multiselect = array of selected options (e.g. [\"A\",\"B\"]); " +
  "freetext = multi-paragraph text; table = array of row objects respecting column types.";

/**
 * Core grounding rules that MUST appear in every system prompt.
 * These prevent the AI from generating fake, placeholder, or hallucinated values
 * regardless of what the user asks for.
 */
export const GROUNDING_RULES = [
  "Do NOT invent fake, placeholder, or example values. All values must be grounded in the uploaded source documents, user-provided information, or reasonable professional defaults.",
  "If you cannot determine a real value, ask the user rather than making one up.",
  "Never construct identifiers by pattern — emails, phone numbers, contract/PO numbers, serial numbers, addresses. If no source states one verbatim, leave the field empty and say so.",
];

/**
 * Drafting-only carve-out from GROUNDING_RULES for narrative fields.
 * The grounding rules are written for fact extraction; applied to prose they
 * tell the model to stop whenever no source covers a section directly, which
 * stalls long narrative documents (e.g. LCSP) mid-draft. Facts and identifiers
 * inside the prose stay strictly grounded.
 */
export const FREETEXT_DRAFTING_RULE =
  "For freetext (narrative) fields, the grounding rules above govern specific facts — names, dates, amounts, " +
  "identifiers, commitments — not the prose itself. Draft complete, professional narrative using the uploaded " +
  "documents, the template context (`get_template_context`), the field's guidance, and standard practice for this " +
  "document type. Do not leave a freetext field empty or stop drafting because no source addresses it directly. " +
  "Where a draft relies mainly on standard practice rather than the sources, give it confidence below 0.6. " +
  "Mention any specific facts you couldn't confirm briefly in your reply, not as placeholders in the text.";

/**
 * Returns "Today's date is YYYY-MM-DD." for use in system prompts.
 */
export function todayLine(): string {
  return `Today's date is ${new Date().toISOString().split("T")[0]}.`;
}

const BASIC_ENTITIES: Record<string, string> = {
  amp: "&",
  lt: "<",
  gt: ">",
  quot: '"',
  "#39": "'",
  nbsp: " ",
};

/**
 * Decode the few HTML entities mammoth emits, in one pass so `&amp;lt;`
 * becomes the literal text `&lt;`, not `<`. No DOM needed (also runs under tsx).
 */
export function decodeBasicEntities(text: string): string {
  return text.replace(/&(amp|lt|gt|quot|#39|nbsp);/g, (_m, e: string) => BASIC_ENTITIES[e]);
}

export interface FormatAnswersOptions {
  /**
   * When true, table values render as "[Table with N row(s)]" instead of the
   * raw stored string. Useful for the drafting chat prompt where compactness
   * matters more than full data.
   */
  summarizeTables?: boolean;
  /**
   * Per-field AI metadata. When provided, AI-sourced values (source !== "manual"
   * and meta entry exists) are tagged "(AI-proposed)" so the model can
   * distinguish its own prior proposals from user-entered data.
   */
  fieldMeta?: Record<string, FieldMeta>;
}

/**
 * Format all non-empty answers from a schema into context lines grouped by
 * section. Returns lines ready to push into a prompt array.
 *
 * Example output:
 *   ### Section Title
 *   - Field Label: value
 */
export function formatExistingAnswers(
  schema: DocumentSchema,
  answers: Record<string, string | number | boolean>,
  opts?: FormatAnswersOptions,
): string[] {
  const lines: string[] = [];
  for (const section of schema.sections) {
    const sectionAnswers: string[] = [];
    for (const field of section.fields) {
      const key = `${section.id}.${field.id}`;
      const value = answers[key];
      if (value !== undefined && value !== "") {
        // Tag AI-proposed values so the model can distinguish them from user entries
        const meta = opts?.fieldMeta?.[key];
        const aiTag = meta && meta.source !== "manual" ? " (AI-proposed)" : "";

        if (field.type === "image") {
          sectionAnswers.push(`- ${field.label}: [Image uploaded]${aiTag}`);
        } else if (opts?.summarizeTables && field.type === "table") {
          const tableData = parseTableData(value);
          if (tableData.rows.length > 0) {
            sectionAnswers.push(`- ${field.label}: [Table with ${tableData.rows.length} row(s)]${aiTag}`);
          }
        } else {
          const formatted =
            typeof value === "boolean" ? (value ? "Yes" : "No") : String(value);
          sectionAnswers.push(`- ${field.label}: ${formatted}${aiTag}`);
        }
      }
    }
    if (sectionAnswers.length > 0) {
      lines.push(`### ${section.title}`);
      lines.push(...sectionAnswers);
      lines.push("");
    }
  }
  return lines;
}

/**
 * Format a list of table column definitions into a compact description string.
 *
 * Example: "name: string (required), amount: number, status: enum [active|closed]"
 */
export function formatColumnDefs(
  columns: TableColumnDef[],
  separator: string = ", ",
): string {
  return columns
    .map((c) => {
      let desc = `${c.id}: ${c.type}`;
      if (c.required) desc += " (required)";
      if (c.type === "enum" && c.options) {
        desc += ` [${c.options.join("|")}]`;
      }
      return desc;
    })
    .join(separator);
}
