import { toAppError } from "../errors";
import Anthropic from "@anthropic-ai/sdk";
import {
  apiKeyStorageKey,
  getActiveEndpointId,
  getResolvedBaseUrl,
  type EndpointId,
} from "./endpoints";
import { markModelUnavailable, resolveModel } from "./models";

// ---------------------------------------------------------------------------
// CUI (Controlled Unclassified Information) Detection
// ---------------------------------------------------------------------------
// Hybrid approach: fast regex pre-screen for standard CUI markings, then
// AI classification (via the CUI/IL5 endpoint) for ambiguous cases.
// ---------------------------------------------------------------------------

/** Result of CUI detection for a single document. */
export interface CuiDetectionResult {
  /** Whether CUI indicators were found. */
  isCui: boolean;
  /** Confidence: "high" for regex matches, "medium"/"low" for AI-only. */
  confidence: "high" | "medium" | "low";
  /** Human-readable explanation of what was detected. */
  reason: string;
  /** Which detection method triggered: "regex", "ai", or "both". */
  method: "regex" | "ai" | "both";
  /** Specific markers/patterns found (for display in the warning dialog). */
  markers: string[];
}

/** Returned when the AI CUI scan fails (non-blocking — upload still proceeds). */
export interface CuiScanError {
  error: true;
  message: string;
}

// ---------------------------------------------------------------------------
// Regex pre-screen
// ---------------------------------------------------------------------------

/** Standard CUI banner/marking patterns. Checked against the document header. */
const CUI_REGEX_PATTERNS: { pattern: RegExp; label: string }[] = [
  { pattern: /CONTROLLED\s+UNCLASSIFIED\s+INFORMATION/i, label: "Controlled Unclassified Information" },
  { pattern: /CUI\/\/SP-[A-Z]/i, label: "CUI Specified category marking" },
  { pattern: /CUI\/\/[A-Z]{2,}/i, label: "CUI category code" },
  { pattern: /\bFOUO\b/, label: "For Official Use Only (FOUO)" },
  { pattern: /UNCLASSIFIED\/\/FOR\s+OFFICIAL\s+USE\s+ONLY/i, label: "FOUO legacy marking" },
  { pattern: /DISTRIBUTION\s+STATEMENT\s+[B-F]/i, label: "Restricted distribution statement" },
  { pattern: /EXPORT\s+CONTROLLED/i, label: "Export controlled" },
  { pattern: /\bITAR\b/, label: "ITAR reference" },
  { pattern: /\bNOFORN\b/i, label: "NOFORN marking" },
  { pattern: /CONTROLLED\s+TECHNICAL\s+INFORMATION/i, label: "Controlled Technical Information" },
  // Bare "CUI" last — it's the broadest match and can false-positive on acronyms
  { pattern: /\bCUI\b/, label: "CUI marking" },
];

/**
 * Fast regex pre-screen for common CUI markings.
 * Scans the full document text — benchmarks at ~1.5ms for a 1MB document,
 * so there's no need to truncate.
 * Returns a high-confidence result if any pattern matches, otherwise null.
 */
export function regexCuiPreScreen(text: string): CuiDetectionResult | null {
  const matched: string[] = [];

  for (const { pattern, label } of CUI_REGEX_PATTERNS) {
    if (pattern.test(text)) {
      matched.push(label);
    }
  }

  if (matched.length === 0) return null;

  return {
    isCui: true,
    confidence: "high",
    reason: `Standard CUI marking(s) detected: ${matched.join(", ")}`,
    method: "regex",
    markers: matched,
  };
}

// ---------------------------------------------------------------------------
// AI classification (always via the CUI / IL5 endpoint)
// ---------------------------------------------------------------------------

/**
 * Maximum characters sent to the AI for classification (~3k tokens).
 * CUI markings are almost always in the first few pages (headers, banners,
 * distribution statements), so truncating is both safe and necessary to
 * avoid blowing the context window on large documents.
 */
const AI_MAX_CHARS = 12_000;

const CUI_CLASSIFICATION_SYSTEM_PROMPT = `You are a document classification assistant. Your job is to determine whether a document contains or is likely to contain Controlled Unclassified Information (CUI).

CUI indicators include (but are not limited to):
- CUI markings, banners, or category codes
- For Official Use Only (FOUO) markings
- Distribution limitation statements (B through F)
- Export control notices (ITAR, EAR)
- Controlled Technical Information (CTI)
- Sensitive but unclassified technical data, personnel records, legal privilege, law enforcement sensitive information
- Information that appears to require safeguarding per 32 CFR Part 2002

If you are uncertain, err on the side of caution and flag it as potential CUI.

Use the classify_cui tool to report your result.`;

/** Tool definition that forces the model to return structured CUI classification. */
const CUI_CLASSIFY_TOOL: Anthropic.Messages.Tool = {
  name: "classify_cui",
  description: "Report CUI classification result for the document.",
  input_schema: {
    type: "object" as const,
    properties: {
      is_cui: { type: "boolean", description: "Whether the document contains CUI." },
      confidence: { type: "string", enum: ["high", "medium", "low"], description: "Classification confidence level." },
      reason: { type: "string", description: "Brief explanation of the classification." },
      markers: { type: "array", items: { type: "string" }, description: "Specific CUI indicators found." },
    },
    required: ["is_cui", "confidence", "reason", "markers"],
  },
};

/**
 * AI-based CUI classification. Prefers the CUI (IL5) endpoint since the
 * document text may be CUI. Falls back to the IL2 endpoint when no CUI key
 * is configured — better to catch CUI via IL2 than to skip the scan entirely.
 *
 * Uses the light model for speed and cost efficiency.
 *
 * Returns a CuiDetectionResult on success, CuiScanError on failure, or null
 * when no API key is available for either endpoint.
 */
export async function aiCuiClassification(
  text: string,
  fileName: string,
  signal?: AbortSignal,
): Promise<CuiDetectionResult | CuiScanError | null> {
  // Prefer IL5; fall back to IL2 if no CUI key is configured
  const cuiApiKey = localStorage.getItem(apiKeyStorageKey("cui"));
  const nonCuiApiKey = localStorage.getItem(apiKeyStorageKey("non-cui"));
  const ep: EndpointId = cuiApiKey ? "cui" : "non-cui";
  const apiKey = cuiApiKey ?? nonCuiApiKey;

  if (!apiKey) {
    console.warn("[CUI Detection] No API key configured for either endpoint — skipping AI classification.");
    return null;
  }

  const model = resolveModel(ep, "light");

  const baseURL = (() => {
    const raw = getResolvedBaseUrl(ep);
    if (raw.startsWith("http")) return raw;
    return `${window.location.origin}${raw}`;
  })();

  // Truncate to avoid blowing context window on large documents
  let classifyText = text;
  if (text.length > AI_MAX_CHARS) {
    classifyText = text.slice(0, AI_MAX_CHARS) +
      `\n\n[Document truncated — only first ${AI_MAX_CHARS.toLocaleString()} characters shown for classification.]`;
  }

  try {
    const client = new Anthropic({
      baseURL,
      apiKey,
      dangerouslyAllowBrowser: true,
    });

    const response = await client.messages.create(
      {
        model,
        max_tokens: 1024,
        system: CUI_CLASSIFICATION_SYSTEM_PROMPT,
        messages: [
          {
            role: "user",
            content: `Classify the following document from "${fileName}":\n\n${classifyText}`,
          },
        ],
        tools: [CUI_CLASSIFY_TOOL],
        tool_choice: { type: "tool" as const, name: "classify_cui" },
      },
      { signal: signal ?? undefined },
    );

    // With forced tool_choice the model must return a tool_use block
    const toolBlock = response.content.find(
      (b): b is Anthropic.ToolUseBlock => b.type === "tool_use" && b.name === "classify_cui",
    );
    if (!toolBlock) {
      throw new Error("Model did not return a classify_cui tool_use block");
    }

    const parsed = toolBlock.input as {
      is_cui: boolean;
      confidence: "high" | "medium" | "low";
      reason: string;
      markers: string[];
    };

    return {
      isCui: parsed.is_cui,
      confidence: parsed.confidence,
      reason: parsed.reason,
      method: "ai",
      markers: parsed.markers ?? [],
    };
  } catch (err) {
    // Persisted as a string on the document record, so flatten the AppError
    const appErr = toAppError(err, { domain: "ai", context: { model } });
    if (appErr.kind === "ai.model-unavailable") markModelUnavailable(ep, model);
    console.warn("[CUI Detection] AI classification failed — proceeding without blocking.", err);
    return {
      error: true,
      message: `AI CUI scan failed: ${appErr.message}${appErr.detail && appErr.detail !== appErr.message ? `\n${appErr.detail}` : ""}`,
    };
  }
}

// ---------------------------------------------------------------------------
// Combined check
// ---------------------------------------------------------------------------

/** Minimum text length for classification to be meaningful. */
const MIN_TEXT_LENGTH = 100;

/**
 * Combined CUI check: regex first, then AI if regex is inconclusive.
 *
 * - Skips entirely if the active endpoint is already CUI (returns null).
 * - AI step prefers IL5; falls back to IL2 when no CUI key is configured.
 * - Returns CuiScanError on AI failure (fails open — caller should warn but not block).
 */
export async function checkForCui(
  text: string,
  fileName: string,
  signal?: AbortSignal,
): Promise<CuiDetectionResult | CuiScanError | null> {
  // Already on CUI endpoint — no need to warn
  if (getActiveEndpointId() === "cui") return null;

  // Not enough content to judge
  if (text.length < MIN_TEXT_LENGTH) return null;

  // Fast regex pre-screen
  const regexResult = regexCuiPreScreen(text);
  if (regexResult) return regexResult;

  // AI classification (via CUI endpoint)
  return aiCuiClassification(text, fileName, signal);
}
