import { describe, it, expect } from "vitest";
import { computeRunMetrics, formatRunMetrics, type RunMessage } from "./chatRunMetrics";
import type { DocumentSchema } from "../schemas/types";

const schema = {
  id: "t",
  title: "T",
  sections: [
    {
      id: "main",
      title: "Main",
      fields: [
        { id: "name", label: "Name", type: "string" },
        { id: "story", label: "Story", type: "freetext" },
        { id: "rows", label: "Rows", type: "table" },
        { id: "pic", label: "Pic", type: "image" },
      ],
    },
  ],
} as unknown as DocumentSchema;

const usage = (promptTokens: number, completionTokens = 10) => ({
  steps: [],
  callUsage: { promptTokens, completionTokens },
});

const tc = (id: string, name: string, args: unknown) => ({
  id,
  type: "function" as const,
  function: { name, arguments: JSON.stringify(args) },
});

const messages: RunMessage[] = [
  { role: "user", content: "Fill in all fields" },
  {
    role: "assistant",
    content: "",
    timings: usage(1000),
    toolCalls: [tc("s1", "search_references", { query: "a" }), tc("s2", "search_references", { query: "b" })],
  },
  { role: "tool", toolCallId: "s1", content: "[1] (PWS): text" },
  { role: "tool", toolCallId: "s2", content: "No relevant excerpts found for this query." },
  {
    role: "assistant",
    content: "",
    timings: usage(3000),
    toolCalls: [tc("p1", "propose_changes", { changes: { "main.story": { value: "x", confidence: 0.5 } } })],
  },
  { role: "tool", toolCallId: "p1", content: "{}" },
  {
    role: "assistant",
    content: "",
    timings: usage(2000),
    toolCalls: [tc("p2", "propose_changes", { changes: { "main.story": { value: "y", confidence: 0.6 }, "main.name": { value: "n", confidence: 0.9 } } })],
  },
  { role: "tool", toolCallId: "p2", content: "{}" },
  { role: "assistant", content: "Done.", timings: { steps: [] } },
];

describe("computeRunMetrics", () => {
  it("summarizes per-call tokens, tool calls, and zero-hit searches", () => {
    const m = computeRunMetrics(messages);
    expect(m.calls).toBe(3);
    expect(m.contextTokensPerCall).toEqual({ min: 1000, median: 2000, max: 3000 });
    expect(m.totalContextTokens).toBe(6000);
    expect(m.cacheReadShare).toBe(0);
    expect(m.totalCompletionTokens).toBe(30);
    expect(m.toolCalls).toEqual({ search_references: 2, propose_changes: 2 });
    expect(m.zeroHitSearches).toBe(1);
    expect(m.proposedKeys).toBe(2);
    expect(m.coverage).toBeUndefined();
  });

  it("counts freetext as draftable and tables as fact fields, skipping images", () => {
    const m = computeRunMetrics(messages, schema);
    expect(m.coverage).toEqual({
      draftable: 1,
      draftableProposed: 1,
      factFields: 2,
      factProposed: 1,
      draftableMissing: [],
    });
  });

  it("counts cached input toward context size", () => {
    const m = computeRunMetrics([
      { role: "assistant", content: "a", timings: { steps: [], callUsage: { promptTokens: 200, completionTokens: 5, cacheReadTokens: 700, cacheCreationTokens: 100 } } },
    ]);
    expect(m.contextTokensPerCall).toEqual({ min: 1000, median: 1000, max: 1000 });
    expect(m.cacheReadShare).toBe(0.7);
  });

  it("reports when an export has no per-call usage", () => {
    const m = computeRunMetrics([{ role: "assistant", content: "hi" }]);
    expect(m.contextTokensPerCall).toBeNull();
    expect(formatRunMetrics(m)).toContain("not recorded");
  });
});
