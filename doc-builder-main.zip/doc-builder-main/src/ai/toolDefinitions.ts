import type { ToolDefinition } from "./types";

// ---------------------------------------------------------------------------
// Shared AI tool definitions (Anthropic format)
// ---------------------------------------------------------------------------

/** Tool for proposing field value changes to the document. */
export const PROPOSE_CHANGES_TOOL: ToolDefinition = {
  name: "propose_changes",
  description:
    "Propose field value changes for the document. For long documents, call it several times with a few related fields each until every field in scope is covered.",
  input_schema: {
    type: "object",
    properties: {
      changes: {
        type: "object",
        description:
          "Map of 'section_id.field_id' keys to proposed values. Each entry has a value (type depends on field) and confidence (0.0-1.0).",
        additionalProperties: {
          type: "object",
          properties: {
            value: {
              description:
                "The proposed value for the field (string, number, boolean, date string YYYY-MM-DD, or array of row objects for tables)",
            },
            confidence: {
              type: "number",
              description: "Confidence score between 0.0 and 1.0",
              minimum: 0,
              maximum: 1,
            },
          },
          required: ["value", "confidence"],
        },
      },
    },
    required: ["changes"],
  },
};

/** Tool for searching reference documents via semantic retrieval. */
export const SEARCH_TOOL: ToolDefinition = {
  name: "search_references",
  description:
    "Search the selected reference documents for information relevant to a query. Use this when you need to look up specific details from the reference materials. Results are labeled with the document's role title when the user assigned one.",
  input_schema: {
    type: "object",
    properties: {
      query: {
        type: "string",
        description: "What to search for in the reference documents",
      },
    },
    required: ["query"],
  },
};

/** Tool for reporting observations (conflicts, gaps, assumptions) about source documents. */
export const REPORT_OBSERVATIONS_TOOL: ToolDefinition = {
  name: "report_observations",
  description:
    "Report observations about the source documents: conflicts between documents, gaps in available information, or assumptions made during extraction. Call this when you notice issues the user should be aware of.",
  input_schema: {
    type: "object",
    properties: {
      observations: {
        type: "array",
        description: "Array of observations. Empty array if none found.",
        items: {
          type: "object",
          properties: {
            type: {
              type: "string",
              enum: ["conflict", "gap", "assumption", "quality", "placeholder"],
              description:
                "conflict = documents disagree or values contradict; gap = information missing from all sources; assumption = value inferred without direct evidence; quality = professionalism, coherence, or completeness issue; placeholder = unfilled template artifact or incomplete content",
            },
            topic: {
              type: "string",
              description:
                "What the observation is about (e.g., 'Effective Date', 'Contract Amount')",
            },
            field_key: {
              type: "string",
              description:
                "section_id.field_id if applicable, or null if general",
            },
            severity: {
              type: "string",
              enum: ["high", "medium", "low"],
            },
            description: {
              type: "string",
              description: "Brief explanation",
            },
            sources: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  document: {
                    type: "string",
                    description: "Document filename, or its role title (e.g. \"PWS\") when the document was given a role",
                  },
                  value: {
                    type: "string",
                    description: "What this document states",
                  },
                  excerpt: {
                    type: "string",
                    description: "Relevant quote from the document",
                  },
                },
                required: ["document", "value"],
              },
            },
            recommendation: {
              type: "string",
              description:
                "Which value you chose (if proposing changes) and why, or what action the user should take",
            },
          },
          required: ["type", "topic", "severity", "description", "sources"],
        },
      },
    },
    required: ["observations"],
  },
};

/** Tool for viewing surrounding document template text where a field will appear. */
export const GET_TEMPLATE_CONTEXT_TOOL: ToolDefinition = {
  name: "get_template_context",
  description:
    "View the surrounding document template text where a field's output will appear. " +
    "Queries the UNFILLED template (.docx or markdown), not the rendered document. " +
    "Use this to understand the prose context around a field before drafting its content. " +
    "Returns numbered lines (stable for the session) and a document outline for navigation.",
  input_schema: {
    type: "object",
    properties: {
      schema_id: {
        type: "string",
        description:
          "For document sets: the ID of the specific document schema whose template to query " +
          "(e.g., 'fms-tte-proposal'). Optional for single-document sessions.",
      },
      field_key: {
        type: "string",
        description:
          "The field key (e.g., 'scope.description') to center on. " +
          "Returns lines surrounding the field's {{TAG}} placeholder in the template.",
      },
      from_line: {
        type: "integer",
        description:
          "Start line number (1-indexed) for a positional query. " +
          "Use this to read the beginning of the document or jump to a specific region from the outline.",
        minimum: 1,
      },
      search: {
        type: "string",
        description:
          "Text to search for in the template. Returns surrounding lines around the first match.",
      },
      lines: {
        type: "integer",
        description:
          "Number of context lines. For field_key/search: lines before AND after the match (default 20, max 60). " +
          "For from_line: total lines to return (default 40, max 120).",
        minimum: 1,
        maximum: 120,
      },
    },
    required: [],
  },
};

/** Tool for looking up field definitions, AI hints, answers, and document outline on demand. */
export const GET_FIELD_INFO_TOOL: ToolDefinition = {
  name: "get_field_info",
  description:
    "Look up field definitions, AI hints, current answers, and document structure for specific sections " +
    "of the document BEING BUILT (not an uploaded source). Current answers are the working draft — often your own " +
    "earlier proposals — and are never evidence. Use this when you need to understand what a field or section is " +
    "supposed to contain, verify entered values against rendered output, or check the document structure. " +
    "To find facts, use search_references or the <document> text instead.",
  input_schema: {
    type: "object",
    properties: {
      section_ids: {
        type: "array",
        items: { type: "string" },
        description:
          "Section IDs to look up (e.g., [\"cover\", \"sustainment\"]). Omit to get all sections.",
      },
      include_answers: {
        type: "boolean",
        description:
          "When true, includes current entered values alongside field definitions. Useful for comparing raw data against rendered output.",
      },
      include_outline: {
        type: "boolean",
        description:
          "When true, includes the document's heading structure. Useful for verifying structural completeness.",
      },
    },
    required: [],
  },
};

/** Tool for asking the user one or more multiple-choice questions. */
export const ASK_USER_TOOL: ToolDefinition = {
  name: "ask_user",
  description:
    "Ask the user one or more multiple-choice questions to learn their preferences or get a decision " +
    "before continuing. The user can always choose 'Other' and type a free answer — do not include an " +
    "'Other' option yourself. Wait for the answer before acting on what the question affects.",
  input_schema: {
    type: "object",
    properties: {
      questions: {
        type: "array",
        description: "1-4 questions to ask in a single batch.",
        items: {
          type: "object",
          properties: {
            header: {
              type: "string",
              description: "Very short label (max ~12 chars) shown as a tab/chip, e.g. 'Tone'.",
            },
            question: {
              type: "string",
              description: "The full question text.",
            },
            field_key: {
              type: "string",
              description: "section_id.field_id if this question is about a specific field, or omit if general.",
            },
            multi_select: {
              type: "boolean",
              description: "True if the user may choose more than one option. Defaults to single-select.",
            },
            options: {
              type: "array",
              description: "2-6 options for the user to choose from.",
              items: {
                type: "object",
                properties: {
                  label: {
                    type: "string",
                    description: "The option text shown to the user.",
                  },
                  description: {
                    type: "string",
                    description: "Optional secondary text explaining the option or its tradeoff.",
                  },
                  recommended: {
                    type: "boolean",
                    description: "True to mark this as your recommended choice. Put it first.",
                  },
                },
                required: ["label"],
              },
            },
          },
          required: ["header", "question", "options"],
        },
      },
    },
    required: ["questions"],
  },
};

/** Standard set of AI tools for document drafting and review. */
export const AI_TOOLS: ToolDefinition[] = [PROPOSE_CHANGES_TOOL, SEARCH_TOOL, REPORT_OBSERVATIONS_TOOL, GET_FIELD_INFO_TOOL, GET_TEMPLATE_CONTEXT_TOOL, ASK_USER_TOOL];
