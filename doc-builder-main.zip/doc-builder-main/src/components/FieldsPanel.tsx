import { useMemo } from "react";
import type { DocumentSchema, SectionDef } from "../schemas/types";
import type { FieldMeta } from "../db/types";
import type { AiScope } from "../ai/unifiedPrompt";
import type { FieldDestinationMap } from "../engine/fieldDestinations";
import type { ValidationIssues } from "../engine/validation";
import { getVisibleFields } from "../engine/visibility";
import { resolveEffectiveAnswers } from "../engine/effectiveAnswers";
import { getScopeColors } from "../utils/scopeColors";
import MagicWandIcon from "./icons/MagicWandIcon";
import FieldRenderer from "./FieldRenderer";
import ComputedFieldDisplay from "./ComputedFieldDisplay";

interface Props {
  section: SectionDef;
  answers: Record<string, string | number | boolean>;
  fieldMeta: Record<string, FieldMeta>;
  onAnswer: (key: string, value: string | number | boolean) => void;
  /** Callback to open the AI chat panel for a freetext field. */
  onOpenChat?: (fieldKey: string) => void;
  /** The fieldKey currently being drafted by AI (highlighted). */
  activeDraftField?: string | null;
  /** Full schema (used to resolve linked field labels). */
  schema?: DocumentSchema;
  /** Optional field-to-document-location map (shown when toggle is active). */
  destinationMap?: FieldDestinationMap;
  /** Whether to display AI hints below fields. */
  showHints?: boolean;
  /** Callback to open the AI panel scoped to this section. */
  onDraftSection?: () => void;
  /** Current AI scope (used to highlight the active button). */
  activeScope?: AiScope;
  /** Session ID — passed through to image fields for blob storage. */
  sessionId?: string;
  /** Validation rule problems keyed by answer key. */
  validationIssues?: ValidationIssues;
  /**
   * Disable every input (e.g. another tab holds the session lock). Edits
   * would be discarded, so the controls must not look like they took.
   */
  readOnly?: boolean;
}

/** Resolve the human-readable label of a field key from the schema. */
function resolveFieldLabel(fieldKey: string, schema?: DocumentSchema): string | undefined {
  if (!schema) return undefined;
  const [sectionId, fieldId] = fieldKey.split(".");
  const section = schema.sections.find((s) => s.id === sectionId);
  const field = section?.fields.find((f) => f.id === fieldId);
  return field?.label;
}

export default function FieldsPanel({ section, answers, fieldMeta, onAnswer, onOpenChat, activeDraftField, schema, destinationMap, showHints, onDraftSection, activeScope, sessionId, validationIssues, readOnly }: Props) {
  const effectiveSchema = schema ?? ({ sections: [section] } as DocumentSchema);
  const { blocks, computed } = useMemo(
    () => resolveEffectiveAnswers(effectiveSchema, answers),
    [effectiveSchema, answers],
  );
  const visibleFields = useMemo(
    () => getVisibleFields(section, effectiveSchema, answers, blocks),
    [section, effectiveSchema, answers, blocks],
  );

  return (
    <div className="flex-1 overflow-y-auto overflow-x-hidden p-6">
      <div className="flex items-center gap-2 mb-6">
        <h2 className="text-lg font-semibold text-gray-900">
          {section.title}
        </h2>
        {onDraftSection && (
          <button
            type="button"
            onClick={onDraftSection}
            className={`inline-flex items-center justify-center w-6 h-6 rounded-md border transition-colors ${
              activeScope?.type === "section" && activeScope.sectionId === section.id
                ? `${getScopeColors("section").iconBgActive} ${getScopeColors("section").iconTextActive} ${getScopeColors("section").iconBorderActive}`
                : `${getScopeColors("section").iconBg} ${getScopeColors("section").iconText} ${getScopeColors("section").iconBgHover} ${getScopeColors("section").iconBorder}`
            }`}
            title="Focus AI on this section"
          >
            <MagicWandIcon className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
      <fieldset disabled={readOnly} className="m-0 min-w-0 border-0 p-0">
        <div className="space-y-5">
          {visibleFields.map((field) => {
            const key = `${section.id}.${field.id}`;

            // Formula fields render as read-only summaries
            if (field.formula !== undefined) {
              return (
                <div key={key} className="max-w-xl">
                  <ComputedFieldDisplay
                    field={field}
                    value={computed[key] ?? null}
                    destinations={destinationMap?.get(key)}
                  />
                </div>
              );
            }

            const linkedFromLabel = field.same_as
              ? resolveFieldLabel(field.same_as, schema)
              : undefined;

            // Table fields use full available width; other fields stay constrained
            const isTable = field.type === "table";

            return (
              <div key={key} className={isTable ? "min-w-0" : "max-w-xl"}>
                <FieldRenderer
                  field={field}
                  fieldKey={key}
                  value={answers[key]}
                  meta={fieldMeta[key]}
                  onChange={onAnswer}
                  onOpenChat={onOpenChat}
                  isDraftTarget={key === activeDraftField}
                  linkedFromLabel={linkedFromLabel}
                  destinations={destinationMap?.get(key)}
                  isScopeTarget={activeScope?.type === "field" && activeScope.fieldKey === key}
                  showHints={showHints}
                  blocks={blocks}
                  constants={effectiveSchema.constants}
                  sessionId={sessionId}
                  issues={validationIssues?.[key]}
                />
              </div>
            );
          })}
        </div>
      </fieldset>
    </div>
  );
}
