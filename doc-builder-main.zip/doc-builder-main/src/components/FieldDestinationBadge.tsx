import type { FieldDestination } from "../engine/fieldDestinations";

interface Props {
  destinations: FieldDestination[];
}

/**
 * Inline indicator showing where a field's value appears in the output document(s).
 * Shows document title and tag name, separated by semicolons for multiple destinations.
 */
export default function FieldDestinationBadge({ destinations }: Props) {
  if (destinations.length === 0) return null;

  const label = destinations
    .map((d) => (d.documentTitle ? `${d.documentTitle}: ${d.heading}` : d.heading))
    .join("; ");

  return (
    <span className="text-xs text-blue-500 font-normal">
      → {label}
    </span>
  );
}
