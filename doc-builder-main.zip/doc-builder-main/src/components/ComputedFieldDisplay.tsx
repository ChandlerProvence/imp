import type { FieldDef } from "../schemas/types";
import type { FieldDestination } from "../engine/fieldDestinations";
import { formatCalculatedForUi } from "../engine/formula/format";
import FieldDestinationBadge from "./FieldDestinationBadge";

interface Props {
  field: FieldDef;
  /** The field's evaluated value (from `resolveEffectiveAnswers().computed`). */
  value: number | null;
  destinations?: FieldDestination[];
}

/**
 * Read-only display for a formula field. Updates live because the parent
 * re-evaluates every formula when answers change.
 */
export default function ComputedFieldDisplay({ field, value, destinations }: Props) {
  return (
    <div className="flex items-center gap-3 rounded-md bg-gray-50 border border-gray-200 px-4 py-3">
      <span className="text-sm font-medium text-gray-700">{field.label}</span>
      <span className="text-sm font-semibold text-gray-900">{formatCalculatedForUi(value, field)}</span>
      {destinations && destinations.length > 0 && (
        <FieldDestinationBadge destinations={destinations} />
      )}
    </div>
  );
}
