import { useAiConfig } from "../context/AiConfigContext";

/** Custom event fired when the badge is clicked to request opening settings. */
export const OPEN_SETTINGS_EVENT = "doc-builder:open-settings";

/**
 * Colored pill badge indicating the active AI endpoint (CUI vs Proprietary).
 * Clicking the badge dispatches a custom event to open the settings dialog.
 * Intended for prominent display on AI panels.
 */
export default function EndpointBadge() {
  const { endpointConfig } = useAiConfig();
  const isCui = endpointConfig.id === "cui";

  function handleClick() {
    window.dispatchEvent(new CustomEvent(OPEN_SETTINGS_EVENT));
  }

  return (
    <button
      type="button"
      onClick={handleClick}
      className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-semibold ring-1 ring-inset cursor-pointer hover:opacity-80 transition-opacity ${
        isCui
          ? "bg-amber-100 text-amber-800 ring-amber-300"
          : "bg-blue-100 text-blue-800 ring-blue-300"
      }`}
      title={`${endpointConfig.description} — click to change`}
    >
      {endpointConfig.shortLabel}
    </button>
  );
}
