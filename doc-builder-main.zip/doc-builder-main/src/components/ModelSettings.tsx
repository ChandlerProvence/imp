import { useState } from "react";
import { useAiConfig } from "../context/AiConfigContext";
import { ENDPOINTS, type EndpointId } from "../ai/endpoints";
import { discoverModels } from "../ai/litellm";
import {
  getModelInfo,
  kindMismatch,
  modelsForRole,
  newerModelFor,
  ROLE_KIND,
  rankCandidates,
  resolveRole,
  rolesFor,
  type ModelInfo,
  type ModelKind,
  type ModelRole,
} from "../ai/models";
import AppErrorBox from "./AppErrorBox";
import { toAppError, type AppError } from "../errors";

const ROLE_LABELS: Record<ModelRole, string> = {
  standard: "Standard",
  advanced: "Advanced",
  light: "Light",
  embedding: "Embeddings",
};

/** Performance side of the cost/performance trade-off, per role. */
const ROLE_DESCRIPTIONS: Record<ModelRole, string> = {
  standard: "Balanced cost and capability — used for extraction and the Fast/Balanced chat tiers.",
  advanced: "Slower and more expensive — used for the Thorough chat tier.",
  light: "Fastest and cheapest — classifies uploads as CUI. Change only if instructed.",
  embedding: "Indexes large documents for search. Changing it re-indexes them on next use.",
};

const OTHER = "__other__";

const KIND_LABELS: Record<ModelKind, string> = {
  chat: "a chat model",
  embedding: "an embedding model",
  other: "an image/audio model",
};

function formatUsd(n: number): string {
  return `$${n < 1 ? n.toFixed(2) : Number(n.toFixed(2)).toString()}`;
}

/** "$3 / $15 per 1M tokens", or null when the proxy didn't report costs. */
export function formatCost(info: ModelInfo | undefined): string | null {
  if (!info || (info.inputCostPerMTok === undefined && info.outputCostPerMTok === undefined)) return null;
  const inp = info.inputCostPerMTok !== undefined ? formatUsd(info.inputCostPerMTok) : "?";
  const out = info.outputCostPerMTok !== undefined ? formatUsd(info.outputCostPerMTok) : "?";
  return `${inp} in / ${out} out per 1M tokens`;
}

/** Cost relative to another model (sum of input + output rates), or null. */
export function relativeCost(a: ModelInfo | undefined, b: ModelInfo | undefined): number | null {
  const sum = (i: ModelInfo | undefined) =>
    i && i.inputCostPerMTok !== undefined && i.outputCostPerMTok !== undefined
      ? i.inputCostPerMTok + i.outputCostPerMTok
      : undefined;
  const sa = sum(a);
  const sb = sum(b);
  return sa !== undefined && sb ? sa / sb : null;
}

function formatRatio(r: number): string {
  return r >= 1 ? `≈${Number(r.toFixed(1))}× the cost of the default` : `≈${Number((1 / r).toFixed(1))}× cheaper than the default`;
}

interface Props {
  ep: EndpointId;
  /**
   * API key as currently typed in Settings (may be unsaved), so Refresh uses
   * the same key as the Test button.
   */
  apiKey: string;
  /** Draft overrides for this endpoint ("" / missing = default). */
  overrides: Partial<Record<ModelRole, string>>;
  onChange: (role: ModelRole, id: string | null) => void;
}

/** Settings → AI Models: per-role model choice with cost information. */
export default function ModelSettings({ ep, apiKey, overrides, onChange }: Props) {
  // The context value changes whenever discovery or availability changes,
  // so the resolutions read below stay current
  const { availableModels } = useAiConfig();
  const [refreshing, setRefreshing] = useState(false);
  const [refreshError, setRefreshError] = useState<AppError | null>(null);
  const [otherMode, setOtherMode] = useState<Partial<Record<ModelRole, boolean>>>({});

  const ids = availableModels(ep);
  const key = apiKey.trim();

  async function handleRefresh() {
    setRefreshing(true);
    setRefreshError(null);
    const res = await discoverModels(ep, key).catch((e: unknown) => ({
      ok: false as const,
      error: toAppError(e, { domain: "ai" }),
    }));
    setRefreshing(false);
    if (!res.ok) setRefreshError(res.error);
  }

  return (
    <div className="mt-4 border-t border-gray-200 pt-3" data-testid="model-settings">
      <div className="flex items-center justify-between">
        <p className="text-xs font-medium text-gray-700">Models for {ENDPOINTS[ep].label}</p>
        <button
          type="button"
          onClick={handleRefresh}
          disabled={refreshing || !key}
          title={key ? undefined : "Enter an API key above to load the model list"}
          className="rounded border border-gray-300 bg-white px-2 py-0.5 text-xs text-gray-700 hover:bg-gray-100 disabled:opacity-50"
        >
          {refreshing ? "Refreshing…" : "Refresh model list"}
        </button>
      </div>
      <p className="text-[11px] text-gray-500 mb-2">
        These apply only to {ENDPOINTS[ep].label}. The other endpoint has its own models.
      </p>
      {!key ? (
        <p className="text-xs text-gray-500 mb-2">
          Enter an API key above to load the model list. You can still type a model ID with "Other…".
        </p>
      ) : (
        ids === null && (
          <p className="text-xs text-gray-500 mb-2">
            Model list not loaded yet — click Refresh. You can still type a model ID with "Other…".
          </p>
        )
      )}
      {refreshError && <AppErrorBox error={refreshError} className="mb-2" />}

      <div className="space-y-3">
        {rolesFor(ep).map((role) => {
          const def = resolveRole(ep, role, { ignoreOverride: true });
          const draft = overrides[role] ?? "";
          const ranked = ids ? rankCandidates(role, def.configured, ids) : [];
          const others = ids ? modelsForRole(role, ids).filter((id) => !ranked.includes(id)) : [];
          const mismatch = draft ? kindMismatch(role, draft) : null;
          const listed = draft === "" || ranked.includes(draft) || others.includes(draft);
          const showOther = otherMode[role] || !listed;
          const selectedId = draft || def.id;
          const selectedInfo = getModelInfo(ep, selectedId);
          const defaultInfo = getModelInfo(ep, def.id);
          const ratio = draft && draft !== def.id ? relativeCost(selectedInfo, defaultInfo) : null;
          const newer = newerModelFor(ep, role);
          const selectId = `model-${ep}-${role}`;

          const optionLabel = (id: string) => {
            const cost = formatCost(getModelInfo(ep, id));
            return cost ? `${id} — ${cost}` : id;
          };

          return (
            <div key={role}>
              <label htmlFor={selectId} className="block text-xs font-medium text-gray-700">
                {ROLE_LABELS[role]}
              </label>
              <p className="text-[11px] text-gray-500 mb-1">{ROLE_DESCRIPTIONS[role]}</p>
              <select
                id={selectId}
                value={showOther ? OTHER : draft}
                onChange={(e) => {
                  const v = e.target.value;
                  if (v === OTHER) {
                    setOtherMode((m) => ({ ...m, [role]: true }));
                    return;
                  }
                  setOtherMode((m) => ({ ...m, [role]: false }));
                  onChange(role, v || null);
                }}
                className="block w-full rounded-md border border-gray-300 bg-white px-2 py-1 text-xs font-mono"
              >
                <option value="">Default ({optionLabel(def.id)})</option>
                {ranked.map((id) => (
                  <option key={id} value={id}>{optionLabel(id)}</option>
                ))}
                {others.length > 0 && (
                  <optgroup label={`Other ${ROLE_KIND[role]} models on this proxy`}>
                    {others.map((id) => (
                      <option key={id} value={id}>{optionLabel(id)}</option>
                    ))}
                  </optgroup>
                )}
                <option value={OTHER}>Other…</option>
              </select>
              {showOther && (
                <input
                  type="text"
                  aria-label={`${ROLE_LABELS[role]} model ID`}
                  value={draft}
                  onChange={(e) => onChange(role, e.target.value || null)}
                  placeholder={`Model ID (blank = ${def.id})`}
                  className="mt-1 block w-full rounded-md border border-gray-300 px-2 py-1 text-xs font-mono"
                />
              )}

              <p className="mt-1 text-[11px] text-gray-500">
                {formatCost(selectedInfo) ?? "Cost unavailable"}
                {selectedInfo?.maxInputTokens ? ` · ${Math.round(selectedInfo.maxInputTokens / 1000)}k context` : ""}
                {ratio !== null && Math.abs(ratio - 1) > 0.05 ? ` · ${formatRatio(ratio)}` : ""}
              </p>

              {mismatch && (
                <p className="mt-0.5 text-[11px] text-amber-700">
                  <span className="font-mono">{draft}</span> looks like {KIND_LABELS[mismatch]} — this role needs{" "}
                  {KIND_LABELS[ROLE_KIND[role]]}.
                </p>
              )}
              {def.source === "substituted" && (
                <p className="mt-0.5 text-[11px] text-amber-700">
                  {def.configured} is no longer on the proxy — Default is using {def.id} instead.
                </p>
              )}
              {def.source === "missing" && (
                <p className="mt-0.5 text-[11px] text-red-700">
                  {def.configured} was not found on the proxy and no replacement is available. Choose a model above.
                </p>
              )}
              {newer && draft !== newer && (
                <p className="mt-0.5 text-[11px] text-blue-700">
                  Newer model available: <span className="font-mono">{newer}</span>
                  {formatCost(getModelInfo(ep, newer)) ? ` (${formatCost(getModelInfo(ep, newer))})` : ""}{" "}
                  <button
                    type="button"
                    onClick={() => {
                      setOtherMode((m) => ({ ...m, [role]: false }));
                      onChange(role, newer);
                    }}
                    className="underline hover:text-blue-900"
                  >
                    Use this
                  </button>
                </p>
              )}
            </div>
          );
        })}
      </div>
      <p className="mt-3 text-[11px] text-gray-400">
        Overrides apply after Save. Costs come from the LiteLLM proxy and may not reflect negotiated rates.
      </p>
    </div>
  );
}
