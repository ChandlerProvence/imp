import { describe, it, expect } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import MailingListNotice, { MAILING_LIST_DISMISSED_KEY } from "./MailingListNotice";
import { CONTACT_EMAIL } from "../config/contact";
import { MAILING_LIST_SUBJECT } from "../config/mailingList";

describe("MailingListNotice", () => {
  it("shows on first visit", () => {
    render(<MailingListNotice />);
    expect(screen.getByRole("region", { name: "Mailing list" })).toHaveTextContent(/mailing list/);
  });

  it("Dismiss hides it for good", () => {
    render(<MailingListNotice />);
    fireEvent.click(screen.getByRole("button", { name: "Dismiss" }));
    expect(screen.queryByRole("region", { name: "Mailing list" })).not.toBeInTheDocument();
    expect(localStorage.getItem(MAILING_LIST_DISMISSED_KEY)).toBe("dismissed");
  });

  it("Email me to join opens a prefilled email and hides it for good", () => {
    render(<MailingListNotice />);
    const link = screen.getByRole("link", { name: "Email me to join" });
    expect(link).toHaveAttribute(
      "href",
      expect.stringContaining(`mailto:${CONTACT_EMAIL}?subject=${encodeURIComponent(MAILING_LIST_SUBJECT)}`),
    );
    fireEvent.click(link);
    expect(screen.queryByRole("region", { name: "Mailing list" })).not.toBeInTheDocument();
    expect(localStorage.getItem(MAILING_LIST_DISMISSED_KEY)).toBe("emailed");
  });

  it("stays hidden once dismissed", () => {
    localStorage.setItem(MAILING_LIST_DISMISSED_KEY, "dismissed");
    render(<MailingListNotice />);
    expect(screen.queryByRole("region", { name: "Mailing list" })).not.toBeInTheDocument();
  });
});
