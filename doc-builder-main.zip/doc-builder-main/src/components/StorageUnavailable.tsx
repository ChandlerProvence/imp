import AppErrorBox from "./AppErrorBox";
import CopyDiagnosticsButton from "./CopyDiagnosticsButton";
import { clearDataAndReload } from "../db/resetDatabase";
import type { AppError } from "../errors";

/**
 * Full-page recovery screen shown when IndexedDB can't be opened at startup
 * (private browsing, corrupt or half-migrated database, blocked upgrade).
 */
export default function StorageUnavailable({ error }: { error: AppError }) {
  return (
    <div className="flex items-center justify-center h-screen bg-gray-50 p-8">
      <div className="max-w-md w-full space-y-4">
        <h1 className="text-xl font-semibold text-gray-900 text-center">
          Doc Builder can't load your saved work
        </h1>
        <AppErrorBox error={error} />
        <p className="text-xs text-gray-500">
          Word documents you've already downloaded are not affected.
        </p>
        <div className="flex flex-wrap gap-3 justify-center pt-2">
          <button
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-blue-600 text-white rounded-sm hover:bg-blue-700 text-sm font-medium"
          >
            Reload
          </button>
          <CopyDiagnosticsButton />
          <button
            onClick={() => {
              if (window.confirm("This permanently deletes all saved sessions and uploaded documents in this browser. Continue?")) {
                void clearDataAndReload();
              }
            }}
            className="px-4 py-2 bg-red-50 text-red-700 border border-red-200 rounded-sm hover:bg-red-100 text-sm font-medium"
          >
            Clear data &amp; reload
          </button>
        </div>
      </div>
    </div>
  );
}
