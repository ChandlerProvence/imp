import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, fireEvent, waitFor, within } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { AiConfigProvider } from "../context/AiConfigContext";
import { AskSageProvider } from "../context/AskSageContext";
import { UserPreferencesProvider } from "../context/UserPreferencesContext";
import SettingsDialog from "./SettingsDialog";
import ModelSubstitutionNotice from "./ModelSubstitutionNotice";
import { formatCost, relativeCost } from "./ModelSettings";
import { ENDPOINTS, apiKeyStorageKey } from "../ai/endpoints";
import {
  _resetModelsForTests,
  getModelOverrides,
  setDiscoveredModels,
  setModelOverride,
} from "../ai/models";

const STANDARD = ENDPOINTS["non-cui"].models.standard;
const NEWER = "claude-sonnet-5-9-aws-comm-il2";

function renderSettings() {
  return render(
    <MemoryRouter>
      <UserPreferencesProvider>
        <AiConfigProvider>
          <AskSageProvider>
            <SettingsDialog open onClose={() => {}} />
          </AskSageProvider>
        </AiConfigProvider>
      </UserPreferencesProvider>
    </MemoryRouter>,
  );
}

beforeEach(() => {
  _resetModelsForTests();
  // No key → no startup discovery; tests seed the cache directly
  vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new TypeError("Failed to fetch")));
});

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("Settings footer", () => {
  it("shows the build label and a Copy diagnostics button", () => {
    renderSettings();
    expect(screen.getByText("Build dev")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /copy diagnostics/i })).toBeInTheDocument();
  });
});

describe("formatCost / relativeCost", () => {
  it("formats per-1M costs and reports missing data as null", () => {
    expect(formatCost({ inputCostPerMTok: 3, outputCostPerMTok: 15 })).toBe("$3 in / $15 out per 1M tokens");
    expect(formatCost({ inputCostPerMTok: 0.02 })).toBe("$0.02 in / ? out per 1M tokens");
    expect(formatCost(undefined)).toBeNull();
  });

  it("compares combined input + output rates", () => {
    expect(relativeCost({ inputCostPerMTok: 15, outputCostPerMTok: 75 }, { inputCostPerMTok: 3, outputCostPerMTok: 15 })).toBe(5);
    expect(relativeCost({ inputCostPerMTok: 15 }, { inputCostPerMTok: 3, outputCostPerMTok: 15 })).toBeNull();
  });
});

describe("Settings → AI Models", () => {
  it("lists discovered models with costs and saves an override", () => {
    setDiscoveredModels("non-cui", [STANDARD, NEWER], {
      [STANDARD]: { inputCostPerMTok: 3, outputCostPerMTok: 15 },
      [NEWER]: { inputCostPerMTok: 6, outputCostPerMTok: 30, maxInputTokens: 500_000 },
    });
    renderSettings();

    const select = screen.getByLabelText("Standard") as HTMLSelectElement;
    expect(within(select).getByRole("option", { name: `${NEWER} — $6 in / $30 out per 1M tokens` })).toBeInTheDocument();

    fireEvent.change(select, { target: { value: NEWER } });
    expect(screen.getByText(/500k context · ≈2× the cost of the default/)).toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: /save/i }));
    expect(getModelOverrides("non-cui").standard).toBe(NEWER);
  });

  it("offers a newer model as an opt-in hint", () => {
    setDiscoveredModels("non-cui", [STANDARD, NEWER]);
    renderSettings();
    expect(screen.getByText(/Newer model available/)).toHaveTextContent(NEWER);
    expect(screen.getAllByText("Cost unavailable").length).toBeGreaterThan(0);

    fireEvent.click(screen.getByRole("button", { name: "Use this" }));
    fireEvent.click(screen.getByRole("button", { name: /save/i }));
    expect(getModelOverrides("non-cui").standard).toBe(NEWER);
  });

  it("selecting Default clears an existing override on save", () => {
    setDiscoveredModels("non-cui", [STANDARD, NEWER]);
    setModelOverride("non-cui", "standard", NEWER);
    renderSettings();
    fireEvent.change(screen.getByLabelText("Standard"), { target: { value: "" } });
    fireEvent.click(screen.getByRole("button", { name: /save/i }));
    expect(getModelOverrides("non-cui").standard).toBeUndefined();
  });

  it("allows a free-text model ID when it isn't listed", () => {
    renderSettings();
    fireEvent.change(screen.getByLabelText("Advanced"), { target: { value: "__other__" } });
    fireEvent.change(screen.getByLabelText("Advanced model ID"), { target: { value: "custom-opus" } });
    fireEvent.click(screen.getByRole("button", { name: /save/i }));
    expect(getModelOverrides("non-cui").advanced).toBe("custom-opus");
  });

  it("explains when Default has been substituted", () => {
    setDiscoveredModels("non-cui", [NEWER]);
    renderSettings();
    expect(screen.getByText((text) => text.includes(`${STANDARD} is no longer on the proxy`))).toBeInTheDocument();
  });
});

describe("model type filter", () => {
  const IDS = [
    STANDARD,
    "claude-4-6-opus-aws-comm-il2",
    "gpt-5-4-azure-comm-il2",
    "text-embedding-3-small-azure-comm-il2",
    "titan-embed-text-v2-aws-comm-il2",
    "gpt-image-2-azure-comm-il2",
  ];
  const optionsOf = (label: string) =>
    within(screen.getByLabelText(label))
      .getAllByRole("option")
      .map((o) => (o as HTMLOptionElement).value);

  it("chat roles offer only chat models", () => {
    setDiscoveredModels("non-cui", IDS);
    renderSettings();
    const standard = optionsOf("Standard");
    expect(standard).toContain("gpt-5-4-azure-comm-il2");
    expect(standard).not.toContain("text-embedding-3-small-azure-comm-il2");
    expect(standard).not.toContain("titan-embed-text-v2-aws-comm-il2");
    expect(standard).not.toContain("gpt-image-2-azure-comm-il2");
  });

  it("the embedding role offers only embedding models", () => {
    setDiscoveredModels("non-cui", IDS);
    renderSettings();
    const embedding = optionsOf("Embeddings");
    expect(embedding).toContain("titan-embed-text-v2-aws-comm-il2");
    expect(embedding).not.toContain(STANDARD);
    expect(embedding).not.toContain("gpt-5-4-azure-comm-il2");
  });

  it("warns about a wrong-type free-text ID but still saves it", () => {
    setDiscoveredModels("non-cui", IDS);
    renderSettings();
    fireEvent.change(screen.getByLabelText("Advanced"), { target: { value: "__other__" } });
    fireEvent.change(screen.getByLabelText("Advanced model ID"), {
      target: { value: "text-embedding-3-large-azure-comm-il2" },
    });
    expect(screen.getByText(/looks like an embedding model — this role needs a chat model/)).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: /save/i }));
    expect(getModelOverrides("non-cui").advanced).toBe("text-embedding-3-large-azure-comm-il2");
  });
});

describe("Refresh model list", () => {
  /** Proxy that accepts only `goodKey`; records which key each call used. */
  function stubProxy(goodKey: string) {
    const used: string[] = [];
    const fn = vi.fn(async (url: string, init?: RequestInit) => {
      const auth = new Headers(init?.headers).get("Authorization") ?? "";
      used.push(auth.replace("Bearer ", ""));
      if (auth !== `Bearer ${goodKey}`) return new Response('{"error":"bad key"}', { status: 401 });
      const body = url.endsWith("/v1/models") ? { data: [{ id: NEWER }] } : {};
      return new Response(JSON.stringify(body), { status: 200 });
    });
    vi.stubGlobal("fetch", fn);
    return used;
  }

  it("uses the key typed in Settings, even before Save", async () => {
    localStorage.setItem(apiKeyStorageKey("non-cui"), "old-key");
    const used = stubProxy("new-key");
    renderSettings();

    fireEvent.change(screen.getByLabelText("Proprietary (IL2) API Key"), { target: { value: "new-key" } });
    fireEvent.click(screen.getAllByRole("button", { name: "Test" })[0]);
    expect(await screen.findByText("✓ Connected")).toBeInTheDocument();

    used.length = 0;
    fireEvent.click(screen.getByRole("button", { name: "Refresh model list" }));
    await waitFor(() => expect(used.length).toBeGreaterThan(0));
    expect(used.every((k) => k === "new-key")).toBe(true);
    await waitFor(() => expect(screen.getByRole("button", { name: "Refresh model list" })).toBeEnabled());
    expect(screen.queryByText(/AI key rejected/)).not.toBeInTheDocument();
    expect(within(screen.getByLabelText("Standard")).getByRole("option", { name: NEWER })).toBeInTheDocument();
  });

  it("shows a rejected typed key as an error", async () => {
    stubProxy("other-key");
    renderSettings();
    fireEvent.change(screen.getByLabelText("Proprietary (IL2) API Key"), { target: { value: "wrong-key" } });
    fireEvent.click(screen.getByRole("button", { name: "Refresh model list" }));
    expect(await screen.findByText(/AI key rejected/)).toBeInTheDocument();
  });

  it("is disabled with an explanation when no key is entered", () => {
    renderSettings();
    expect(screen.getByRole("button", { name: "Refresh model list" })).toBeDisabled();
    expect(screen.getByText(/Enter an API key above to load the model list/)).toBeInTheDocument();
  });
});

describe("startup discovery", () => {
  it("queries /v1/models for endpoints with a key", async () => {
    localStorage.setItem(apiKeyStorageKey("non-cui"), "k");
    const fetchMock = vi.fn(async (url: string) =>
      new Response(JSON.stringify(url.endsWith("/v1/models") ? { data: [{ id: NEWER }] } : {}), {
        status: url.endsWith("/v1/models") ? 200 : 403,
      }),
    );
    vi.stubGlobal("fetch", fetchMock);
    render(
      <AiConfigProvider>
        <ModelSubstitutionNotice />
      </AiConfigProvider>,
    );
    // Configured standard model is gone → notice appears once discovery lands
    expect(await screen.findByText(/AI model changed/)).toBeInTheDocument();
    expect(fetchMock.mock.calls.some(([u]) => String(u).endsWith("/v1/models"))).toBe(true);
  });
});

describe("ModelSubstitutionNotice", () => {
  it("shows substitutions and stays hidden after dismissal", async () => {
    setDiscoveredModels("non-cui", [NEWER]);
    const { unmount } = render(
      <AiConfigProvider>
        <ModelSubstitutionNotice />
      </AiConfigProvider>,
    );
    expect(screen.getByRole("status")).toHaveTextContent(`${STANDARD} is no longer available; using ${NEWER} instead.`);
    fireEvent.click(screen.getByRole("button", { name: "Dismiss" }));
    await waitFor(() => expect(screen.queryByRole("status")).not.toBeInTheDocument());
    unmount();

    render(
      <AiConfigProvider>
        <ModelSubstitutionNotice />
      </AiConfigProvider>,
    );
    expect(screen.queryByRole("status")).not.toBeInTheDocument();
  });

  it("is hidden when nothing is substituted", () => {
    render(
      <AiConfigProvider>
        <ModelSubstitutionNotice />
      </AiConfigProvider>,
    );
    expect(screen.queryByRole("status")).not.toBeInTheDocument();
  });
});
