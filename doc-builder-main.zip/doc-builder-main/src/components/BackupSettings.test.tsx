import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { renderWithProviders } from "../test/renderWithProviders";
import BackupSettings from "./BackupSettings";
import { appError } from "../errors";
import type { ParsedBackup } from "../db/backup";

const backupApi = vi.hoisted(() => ({
  downloadBackup: vi.fn(),
  restoreBackup: vi.fn(),
  getCurrentSummary: vi.fn(),
  validateBackup: vi.fn(),
}));
vi.mock("../db/backup", async (importOriginal) => ({
  ...(await importOriginal<typeof import("../db/backup")>()),
  ...backupApi,
}));

const summary = { sessions: 2, documents: 3, cuiDocuments: 0, templates: 1 };
const parsed: ParsedBackup = { exportedAt: "2026-10-01T12:00:00Z", tables: {}, settings: {}, summary, warnings: [] };

const reload = vi.fn();
const originalLocation = window.location;

beforeEach(() => {
  vi.clearAllMocks();
  backupApi.downloadBackup.mockResolvedValue(true);
  backupApi.restoreBackup.mockResolvedValue(undefined);
  backupApi.getCurrentSummary.mockResolvedValue(summary);
  backupApi.validateBackup.mockResolvedValue({ ok: true, backup: parsed });
  Object.defineProperty(window, "location", { configurable: true, value: { ...originalLocation, reload } });
});

afterEach(() => {
  Object.defineProperty(window, "location", { configurable: true, value: originalLocation });
});

function render() {
  const cancelPendingSave = vi.fn();
  renderWithProviders(<BackupSettings />, { sessionContext: { cancelPendingSave } });
  return { cancelPendingSave };
}

async function chooseFile() {
  const file = new File(["{}"], "doc-builder-backup.json", { type: "application/json" });
  await userEvent.upload(screen.getByTestId("backup-file-input"), file);
}

describe("BackupSettings — last backup", () => {
  const daysAgo = (n: number) => new Date(Date.now() - n * 24 * 60 * 60 * 1000 - 60_000).toISOString();

  it.each([
    ["never backed up", null, "Last backup: Never", true],
    ["backed up today", 0, "Last backup: Today", false],
    ["backed up 14 days ago", 14, "Last backup: 14 days ago", false],
    ["backed up 15 days ago", 15, "Last backup: 15 days ago", true],
  ])("%s", (_label, days, text, red) => {
    localStorage.removeItem("doc-builder:last-backup-at");
    if (days !== null) localStorage.setItem("doc-builder:last-backup-at", daysAgo(days));
    render();
    const line = screen.getByTestId("last-backup");
    expect(line).toHaveTextContent(text);
    expect(line.className.includes("text-red-600")).toBe(red);
  });
});

describe("BackupSettings — backup", () => {
  it("shows what will be saved, then saves", async () => {
    render();
    await userEvent.click(screen.getByRole("button", { name: "Back up all data…" }));
    expect(await screen.findByText(/2 sessions, 3 uploaded documents, 1 custom template/)).toBeInTheDocument();
    expect(screen.queryByRole("alert")).not.toBeInTheDocument();

    await userEvent.click(screen.getByRole("button", { name: "Save backup" }));
    expect(backupApi.downloadBackup).toHaveBeenCalledTimes(1);
    expect(await screen.findByText("Backup saved.")).toBeInTheDocument();
  });

  it("warns when CUI documents will be in the file", async () => {
    backupApi.getCurrentSummary.mockResolvedValue({ ...summary, cuiDocuments: 2 });
    render();
    await userEvent.click(screen.getByRole("button", { name: "Back up all data…" }));
    expect(await screen.findByRole("alert")).toHaveTextContent(/2 documents are marked or flagged as CUI/);
  });
});

describe("BackupSettings — restore", () => {
  it("backs up current data first, then restores and reloads", async () => {
    const { cancelPendingSave } = render();
    await chooseFile();
    expect(await screen.findByText("This replaces all data in this browser.")).toBeInTheDocument();
    expect(screen.getByRole("checkbox", { name: "Back up current data first" })).toBeChecked();

    await userEvent.click(screen.getByRole("button", { name: "Replace all data" }));
    await waitFor(() => expect(reload).toHaveBeenCalled());
    expect(backupApi.downloadBackup).toHaveBeenCalledTimes(1);
    expect(backupApi.downloadBackup.mock.invocationCallOrder[0]).toBeLessThan(
      backupApi.restoreBackup.mock.invocationCallOrder[0],
    );
    expect(backupApi.restoreBackup).toHaveBeenCalledWith(parsed);
    expect(cancelPendingSave).toHaveBeenCalled();
  });

  it("changes nothing when the pre-restore backup is cancelled", async () => {
    backupApi.downloadBackup.mockResolvedValue(false);
    render();
    await chooseFile();
    await userEvent.click(await screen.findByRole("button", { name: "Replace all data" }));
    expect(await screen.findByText(/Restore cancelled/)).toBeInTheDocument();
    expect(backupApi.restoreBackup).not.toHaveBeenCalled();
    expect(reload).not.toHaveBeenCalled();
  });

  it("can restore without backing up first", async () => {
    render();
    await chooseFile();
    await userEvent.click(await screen.findByRole("checkbox", { name: "Back up current data first" }));
    await userEvent.click(screen.getByRole("button", { name: "Replace all data" }));
    await waitFor(() => expect(reload).toHaveBeenCalled());
    expect(backupApi.downloadBackup).not.toHaveBeenCalled();
  });

  it("shows the error for an unusable file without offering to restore", async () => {
    backupApi.validateBackup.mockResolvedValue({ ok: false, error: appError("db.backup-invalid") });
    render();
    await chooseFile();
    expect(await screen.findByText(/Not a usable backup/)).toBeInTheDocument();
    expect(screen.getByText(/Nothing in this browser was changed/)).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Replace all data" })).not.toBeInTheDocument();
  });

  it("lists templates that will be skipped", async () => {
    backupApi.validateBackup.mockResolvedValue({
      ok: true,
      backup: { ...parsed, warnings: ['The custom template "Vendor Letter" is damaged and won\'t be restored.'] },
    });
    render();
    await chooseFile();
    expect(await screen.findByText(/Vendor Letter.*won't be restored/)).toBeInTheDocument();
  });
});
