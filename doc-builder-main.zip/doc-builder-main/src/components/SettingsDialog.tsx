import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAiConfig } from "../context/AiConfigContext";
import { useAskSage } from "../context/AskSageContext";
import { useUserPreferences } from "../context/UserPreferencesContext";
import type { UserProfile } from "../context/UserPreferencesContext";
import type { EndpointId } from "../ai/endpoints";
import { testApiKey } from "../ai/litellm";
import { testAsksageConnection } from "../ai/asksage";
import { isFeatureEnabled } from "../ai/featureFlags";
import { ROLES } from "../roles";
import ErrorBox from "./ErrorBox";
import EndpointSettings from "./EndpointSettings";
import BackupSettings from "./BackupSettings";
import CopyDiagnosticsButton from "./CopyDiagnosticsButton";
import { formatBuildLabel } from "../buildInfo";
import { getModelOverrides, rolesFor, setModelOverride, type ModelRole } from "../ai/models";
import { appError, type AppError } from "../errors";

interface Props {
  open: boolean;
  onClose: () => void;
  /** When set ("asksage" or "backup"), scroll that section into view on open. */
  initialSection?: string;
}

export default function SettingsDialog({ open, onClose, initialSection }: Props) {
  const { role, setRole, profile, setProfile } = useUserPreferences();
  const {
    activeEndpoint,
    setActiveEndpoint,
    setApiKey: saveApiKey,
    getApiKeyFor,
  } = useAiConfig();
  const askSage = useAskSage();
  // AskSage is disabled pending AskSage team approval; see the STATUS block in src/ai/asksage.ts.
  const askSageEnabled = isFeatureEnabled("askSage");
  const navigate = useNavigate();

  const [selectedEndpoint, setSelectedEndpoint] = useState<EndpointId>(activeEndpoint);
  const [cuiKey, setCuiKey] = useState("");
  const [nonCuiKey, setNonCuiKey] = useState("");
  const [selectedRole, setSelectedRole] = useState<string>(role ?? "");
  const [profileName, setProfileName] = useState(profile?.name ?? "");
  const [profileTitle, setProfileTitle] = useState(profile?.title ?? "");
  const [profilePhone, setProfilePhone] = useState(profile?.phone ?? "");
  const [profileEmail, setProfileEmail] = useState(profile?.email ?? "");
  const dialogRef = useRef<HTMLDivElement>(null);
  const asksageSectionRef = useRef<HTMLDivElement>(null);
  const [highlightAsksage, setHighlightAsksage] = useState(false);
  const backupSectionRef = useRef<HTMLDivElement>(null);
  const [highlightBackup, setHighlightBackup] = useState(false);

  // AskSage state
  const [sageEmail, setSageEmail] = useState("");
  const [sageApiKey, setSageApiKey] = useState("");
  const [sageTestStatus, setSageTestStatus] = useState<"idle" | "testing" | "ok" | "error">("idle");
  const [sageTestError, setSageTestError] = useState("");

  // Model override drafts (written on Save)
  const [modelDrafts, setModelDrafts] = useState<Record<EndpointId, Partial<Record<ModelRole, string>>>>({
    "non-cui": {},
    cui: {},
  });

  // API key test state
  const [testStatus, setTestStatus] = useState<Record<EndpointId, "idle" | "testing" | "ok" | "error">>({
    "non-cui": "idle",
    cui: "idle",
  });
  const [testError, setTestError] = useState<Record<EndpointId, AppError | null>>({
    "non-cui": null,
    cui: null,
  });

  async function handleTestKey(ep: EndpointId) {
    const key = ep === "cui" ? cuiKey : nonCuiKey;
    if (!key) {
      setTestStatus((s) => ({ ...s, [ep]: "error" }));
      setTestError((e) => ({ ...e, [ep]: appError("ai.no-key") }));
      return;
    }
    setTestStatus((s) => ({ ...s, [ep]: "testing" }));
    const result = await testApiKey(ep, key);
    setTestStatus((s) => ({ ...s, [ep]: result.ok ? "ok" : "error" }));
    setTestError((e) => ({ ...e, [ep]: result.error ?? null }));
  }

  async function handleTestSage() {
    if (!sageEmail.trim() || !sageApiKey.trim()) {
      setSageTestStatus("error");
      setSageTestError("Email and API key are required");
      return;
    }
    setSageTestStatus("testing");
    const result = await testAsksageConnection(sageEmail, sageApiKey);
    setSageTestStatus(result.ok ? "ok" : "error");
    setSageTestError(result.error ?? "");
  }

  // Load current values when dialog opens
  useEffect(() => {
    if (open) {
      setSelectedEndpoint(activeEndpoint);
      setCuiKey(getApiKeyFor("cui") ?? "");
      setNonCuiKey(getApiKeyFor("non-cui") ?? "");
      setSelectedRole(role && role !== "__all__" ? role : "");
      setProfileName(profile?.name ?? "");
      setProfileTitle(profile?.title ?? "");
      setProfilePhone(profile?.phone ?? "");
      setProfileEmail(profile?.email ?? "");
      setTestStatus({ "non-cui": "idle", cui: "idle" });
      setTestError({ "non-cui": null, cui: null });
      setModelDrafts({ "non-cui": getModelOverrides("non-cui"), cui: getModelOverrides("cui") });
      setSageEmail(askSage.email ?? "");
      setSageApiKey(askSage.apiKey ?? "");
      setSageTestStatus("idle");
      setSageTestError("");
    }
  }, [open, activeEndpoint, role, profile, getApiKeyFor, askSage.email, askSage.apiKey]);

  // Focus trap + Escape handling
  useEffect(() => {
    if (!open) return;

    const dialog = dialogRef.current;
    if (!dialog) return;

    // Focus the first focusable element on open
    const focusable = dialog.querySelectorAll<HTMLElement>(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])',
    );
    if (focusable.length > 0) focusable[0].focus();

    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape") {
        e.stopPropagation();
        onClose();
        return;
      }
      if (e.key === "Tab" && dialog) {
        const focusableEls = dialog.querySelectorAll<HTMLElement>(
          'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])',
        );
        if (focusableEls.length === 0) return;
        const first = focusableEls[0];
        const last = focusableEls[focusableEls.length - 1];
        if (e.shiftKey) {
          if (document.activeElement === first) {
            e.preventDefault();
            last.focus();
          }
        } else {
          if (document.activeElement === last) {
            e.preventDefault();
            first.focus();
          }
        }
      }
    }

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [open, onClose]);

  // Scroll to a specific section when requested ("asksage" or "backup")
  useEffect(() => {
    if (!open || !initialSection) return;
    const target =
      initialSection === "asksage"
        ? { ref: asksageSectionRef, highlight: setHighlightAsksage }
        : initialSection === "backup"
          ? { ref: backupSectionRef, highlight: setHighlightBackup }
          : null;
    let timer: ReturnType<typeof setTimeout>;
    if (target?.ref.current) {
      requestAnimationFrame(() => {
        target.ref.current?.scrollIntoView({ behavior: "smooth", block: "center" });
        target.highlight(true);
        timer = setTimeout(() => target.highlight(false), 2000);
      });
    }
    return () => clearTimeout(timer);
  }, [open, initialSection]);

  if (!open) return null;

  function handleSave() {
    // Save endpoint selection
    setActiveEndpoint(selectedEndpoint);
    // Save both keys (so switching later doesn't lose the other key)
    saveApiKey("cui", cuiKey);
    saveApiKey("non-cui", nonCuiKey);
    // Save model overrides for both endpoints (missing role = default)
    for (const ep of ["non-cui", "cui"] as EndpointId[]) {
      for (const r of rolesFor(ep)) setModelOverride(ep, r, modelDrafts[ep][r] ?? null);
    }
    // Save AskSage credentials (skipped while the section is hidden, so stored ones are kept)
    if (askSageEnabled) askSage.setCredentials(sageEmail, sageApiKey);
    // Save role
    setRole(selectedRole || "__all__");
    // Save user profile (persist even if partially filled)
    const hasAnyProfile = profileName || profileTitle || profilePhone || profileEmail;
    if (hasAnyProfile) {
      setProfile({
        name: profileName,
        title: profileTitle,
        phone: profilePhone,
        email: profileEmail,
      } satisfies UserProfile);
    } else {
      setProfile(null);
    }
    onClose();
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />

      {/* Dialog */}
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="settings-dialog-title"
        className="relative w-[90vw] max-w-4xl rounded-lg bg-white p-6 shadow-xl max-h-[90vh] overflow-y-auto"
      >
        <h2 id="settings-dialog-title" className="text-lg font-semibold text-gray-900">Settings</h2>

        {/* Group selector */}
        <div className="mt-4">
          <label
            htmlFor="role-select"
            className="block text-sm font-medium text-gray-700 mb-1"
          >
            Group
          </label>
          <select
            id="role-select"
            value={selectedRole}
            onChange={(e) => setSelectedRole(e.target.value)}
            className="block w-full rounded-md border border-gray-300 px-3 py-2 text-sm shadow-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
          >
            <option value="">All Documents (no filter)</option>
            {ROLES.map((r) => (
              <option key={r.id} value={r.id}>
                {r.label}
              </option>
            ))}
          </select>
          <p className="mt-1.5 text-xs text-gray-400">
            Your group determines which document types are visible.
          </p>
        </div>

        {/* Your Information (Preparer profile) */}
        <div className="mt-5">
          <span className="block text-sm font-medium text-gray-700 mb-2">
            Your Information
          </span>
          <div className="space-y-2">
            <input
              type="text"
              value={profileName}
              onChange={(e) => setProfileName(e.target.value)}
              placeholder="Name"
              aria-label="Name"
              className="block w-full rounded-md border border-gray-300 px-3 py-2 text-sm shadow-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
            />
            <input
              type="text"
              value={profileTitle}
              onChange={(e) => setProfileTitle(e.target.value)}
              placeholder="Title (e.g., Subcontracts Administrator)"
              aria-label="Title"
              className="block w-full rounded-md border border-gray-300 px-3 py-2 text-sm shadow-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
            />
            <div className="flex gap-2">
              <input
                type="tel"
                value={profilePhone}
                onChange={(e) => setProfilePhone(e.target.value)}
                placeholder="Phone"
                aria-label="Phone"
                className="block flex-1 rounded-md border border-gray-300 px-3 py-2 text-sm shadow-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              />
              <input
                type="email"
                value={profileEmail}
                onChange={(e) => setProfileEmail(e.target.value)}
                placeholder="Email"
                aria-label="Email"
                className="block flex-1 rounded-md border border-gray-300 px-3 py-2 text-sm shadow-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>
          <p className="mt-1.5 text-xs text-gray-400">
            Auto-fills preparer fields when you start a new document.
          </p>
        </div>

        {/* Whole-database backup and restore (acts immediately, not on Save) */}
        <div
          ref={backupSectionRef}
          id="settings-backup"
          className={`mt-5 rounded-md p-3 -mx-3 transition-all duration-500 ${
            highlightBackup ? "ring-2 ring-blue-400 bg-blue-50/40" : ""
          }`}
        >
          <BackupSettings />
        </div>

        {/* Endpoints: one tab each for key, URL, models, and "in use" */}
        <EndpointSettings
          inUse={selectedEndpoint}
          onUseEndpoint={setSelectedEndpoint}
          keys={{ "non-cui": nonCuiKey, cui: cuiKey }}
          onKeyChange={(ep, value) => {
            if (ep === "cui") setCuiKey(value);
            else setNonCuiKey(value);
            setTestStatus((st) => ({ ...st, [ep]: "idle" }));
          }}
          testStatus={testStatus}
          testError={testError}
          onTest={handleTestKey}
          modelDrafts={modelDrafts}
          onModelChange={(ep, role, id) =>
            setModelDrafts((d) => {
              const forEp = { ...d[ep] };
              if (id) forEp[role] = id;
              else delete forEp[role];
              return { ...d, [ep]: forEp };
            })
          }
        />

        {/* AskSage (SharePoint) credentials — hidden while the askSage flag is off */}
        {askSageEnabled && (
        <div
          ref={asksageSectionRef}
          id="settings-asksage"
          className={`mt-5 rounded-md p-3 -mx-3 transition-all duration-500 ${
            highlightAsksage ? "ring-2 ring-blue-400 bg-blue-50/40" : ""
          }`}
        >
          <span className="block text-sm font-medium text-gray-700 mb-2">
            AskSage (SharePoint)
          </span>
          <div className="space-y-2">
            <input
              type="email"
              value={sageEmail}
              onChange={(e) => {
                setSageEmail(e.target.value);
                setSageTestStatus("idle");
              }}
              placeholder="Leidos email"
              aria-label="AskSage email"
              className="block w-full rounded-md border border-gray-300 px-3 py-2 text-sm shadow-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
            />
            <div className="flex gap-2">
              <input
                type="password"
                value={sageApiKey}
                onChange={(e) => {
                  setSageApiKey(e.target.value);
                  setSageTestStatus("idle");
                }}
                placeholder="AskSage API key"
                aria-label="AskSage API key"
                className="block flex-1 rounded-md border border-gray-300 px-3 py-2 text-sm shadow-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              />
              <button
                type="button"
                onClick={handleTestSage}
                disabled={sageTestStatus === "testing"}
                className="rounded-md border border-gray-300 bg-white px-3 py-2 text-xs font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50"
              >
                {sageTestStatus === "testing" ? "Testing…" : "Test"}
              </button>
            </div>
          </div>
          {sageTestStatus === "ok" && (
            <p className="mt-1 text-xs text-green-600">✓ Connected</p>
          )}
          {sageTestStatus === "error" && (
            <ErrorBox
              title={sageTestError.includes("cross-origin (CORS)") ? "Blocked in production" : "Connection failed"}
              detail={sageTestError}
              className="mt-2"
            />
          )}
          <p className="mt-1.5 text-xs text-gray-400">
            Enables searching and attaching SharePoint files. Credentials are stored locally.
            {" "}
            <button
              type="button"
              onClick={() => { onClose(); navigate("/docs/help/asksage-setup"); }}
              className="text-blue-500 hover:text-blue-700 underline"
            >
              Setup guide
            </button>
          </p>
        </div>
        )}

        <div className="mt-6 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <CopyDiagnosticsButton />
            <span className="text-xs text-gray-400">{formatBuildLabel()}</span>
          </div>
          <div className="flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
            >
              Save
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
