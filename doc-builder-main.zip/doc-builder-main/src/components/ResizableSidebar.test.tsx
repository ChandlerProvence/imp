import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import ResizableSidebar from "./ResizableSidebar";

describe("ResizableSidebar", () => {
  it("renders children", () => {
    render(
      <ResizableSidebar>
        <span>Sidebar Content</span>
      </ResizableSidebar>,
    );
    expect(screen.getByText("Sidebar Content")).toBeInTheDocument();
  });

  it("uses default width when no localStorage value", () => {
    const { container } = render(
      <ResizableSidebar defaultWidth={250}>
        <span>Content</span>
      </ResizableSidebar>,
    );
    const sidebar = container.querySelector("[data-sidebar-resize]") as HTMLElement;
    expect(sidebar.style.width).toBe("250px");
  });

  it("reads initial width from localStorage", () => {
    localStorage.setItem("doc-builder:sidebar-width", "300");
    const { container } = render(
      <ResizableSidebar defaultWidth={220} minWidth={140} maxWidth={400}>
        <span>Content</span>
      </ResizableSidebar>,
    );
    const sidebar = container.querySelector("[data-sidebar-resize]") as HTMLElement;
    expect(sidebar.style.width).toBe("300px");
  });

  it("ignores localStorage value outside min/max bounds", () => {
    localStorage.setItem("doc-builder:sidebar-width", "50"); // below minWidth
    const { container } = render(
      <ResizableSidebar defaultWidth={220} minWidth={140} maxWidth={400}>
        <span>Content</span>
      </ResizableSidebar>,
    );
    const sidebar = container.querySelector("[data-sidebar-resize]") as HTMLElement;
    expect(sidebar.style.width).toBe("220px"); // falls back to default
  });

  it("renders resize handle", () => {
    const { container } = render(
      <ResizableSidebar>
        <span>Content</span>
      </ResizableSidebar>,
    );
    const handle = container.querySelector(".cursor-col-resize");
    expect(handle).toBeInTheDocument();
  });
});
