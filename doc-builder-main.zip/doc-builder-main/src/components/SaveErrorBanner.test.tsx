import { describe, it, expect, vi, beforeEach } from "vitest";
import { act, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";

vi.mock("../db/sessionExport", () => ({ downloadSessionExport: vi.fn().mockResolvedValue(true) }));

import SaveErrorBanner from "./SaveErrorBanner";
import { renderWithProviders } from "../test/renderWithProviders";
import { createMockSession } from "../test/mocks";
import { resetWriteStatus, trackWrite } from "../db/writeStatus";
import { downloadSessionExport } from "../db/sessionExport";

const quota = () => new DOMException("The quota has been exceeded.", "QuotaExceededError");

beforeEach(() => {
  resetWriteStatus();
  vi.mocked(downloadSessionExport).mockClear();
});

describe("SaveErrorBanner", () => {
  it("renders nothing while writes succeed", async () => {
    renderWithProviders(<SaveErrorBanner />);
    await act(() => trackWrite(Promise.resolve()));
    expect(screen.queryByRole("alert")).toBeNull();
  });

  it("appears when a tracked write fails and clears on the next success", async () => {
    vi.spyOn(console, "error").mockImplementation(() => {});
    renderWithProviders(<SaveErrorBanner />);

    await act(() => trackWrite(Promise.reject(quota())));
    expect(screen.getByRole("alert")).toHaveTextContent("Your changes aren't being saved");
    expect(screen.getByRole("alert")).toHaveTextContent("Browser storage is full");

    await act(() => trackWrite(Promise.resolve()));
    await waitFor(() => expect(screen.queryByRole("alert")).toBeNull());
  });

  it("exports the live in-memory answers, not the stale stored copy", async () => {
    vi.spyOn(console, "error").mockImplementation(() => {});
    const session = createMockSession({ id: "s1" });
    const answers = { "a.b": "unsaved edit" };
    renderWithProviders(<SaveErrorBanner />, { sessionContext: { session, answers, fieldMeta: {} } });

    await act(() => trackWrite(Promise.reject(quota())));
    await userEvent.click(screen.getByRole("button", { name: "Export session" }));
    expect(downloadSessionExport).toHaveBeenCalledWith("s1", { answers, fieldMeta: {} });
  });

  it("trackWrite never rejects, so fire-and-forget callers are safe", async () => {
    vi.spyOn(console, "error").mockImplementation(() => {});
    await expect(trackWrite(Promise.reject(new Error("x")))).resolves.toBeUndefined();
  });
});
