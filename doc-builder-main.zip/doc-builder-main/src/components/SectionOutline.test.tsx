import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import SectionOutline from "./SectionOutline";
import type { DocumentSchema, SectionDef } from "../schemas/types";
import type { SectionStatus } from "../engine/types";

const sections: SectionDef[] = [
  { id: "s1", title: "Parties", fields: [{ id: "f1", label: "F1", type: "string", required: false }] },
  { id: "s2", title: "Terms", fields: [{ id: "f2", label: "F2", type: "string", required: false }] },
];
const schema = { id: "t", title: "T", version: 1, sections } as DocumentSchema;

const statuses: Record<string, SectionStatus> = { s1: "complete", s2: "in-progress" };

function renderWithRouter(ui: React.ReactElement) {
  return render(<MemoryRouter>{ui}</MemoryRouter>);
}

describe("SectionOutline", () => {
  it("renders section titles", () => {
    renderWithRouter(
      <SectionOutline
        schema={schema}
        answers={{}}
        statuses={statuses}
        currentSectionId="s1"
        onSelect={vi.fn()}
      />,
    );
    expect(screen.getByText("Parties")).toBeInTheDocument();
    expect(screen.getByText("Terms")).toBeInTheDocument();
  });

  it("renders Build step label", () => {
    renderWithRouter(
      <SectionOutline
        schema={schema}
        answers={{}}
        statuses={statuses}
        currentSectionId="s1"
        onSelect={vi.fn()}
      />,
    );
    expect(screen.getByText("Build")).toBeInTheDocument();
  });

  it("renders Review and Export links", () => {
    renderWithRouter(
      <SectionOutline
        schema={schema}
        answers={{}}
        statuses={statuses}
        currentSectionId="s1"
        onSelect={vi.fn()}
      />,
    );
    expect(screen.getByText("Review")).toBeInTheDocument();
    expect(screen.getByText("Export")).toBeInTheDocument();
  });

  it("calls onSelect when a section is clicked", () => {
    const onSelect = vi.fn();
    renderWithRouter(
      <SectionOutline
        schema={schema}
        answers={{}}
        statuses={statuses}
        currentSectionId="s1"
        onSelect={onSelect}
      />,
    );
    fireEvent.click(screen.getByText("Terms"));
    expect(onSelect).toHaveBeenCalledWith("s2");
  });


  it("highlights active section", () => {
    renderWithRouter(
      <SectionOutline
        schema={schema}
        answers={{}}
        statuses={statuses}
        currentSectionId="s1"
        onSelect={vi.fn()}
        activeStep="interview"
      />,
    );
    // The active section button should have the active class
    const partiesBtn = screen.getByText("Parties").closest("button");
    expect(partiesBtn?.className).toContain("bg-blue-50");
  });
});

describe("SectionOutline — validation badges", () => {
  it("shows a problem badge only on sections with issues", () => {
    renderWithRouter(
      <SectionOutline
        schema={schema}
        answers={{}}
        statuses={statuses}
        issueCounts={{ s2: 2 }}
        currentSectionId="s1"
        onSelect={vi.fn()}
      />,
    );
    const badges = screen.getAllByTitle("2 problem(s) to check");
    expect(badges).toHaveLength(1);
    expect(screen.getByText("Terms").closest("button")).toContainElement(badges[0]);
  });
});

describe("SectionOutline — Prep group", () => {
  // Drafting style is the only prep page, and it applies only to schemas with freetext.
  const narrative = {
    ...schema,
    sections: [...sections, { id: "s3", title: "Approach", fields: [{ id: "f3", label: "F3", type: "freetext", required: false }] }],
  } as DocumentSchema;

  it("is absent when no prep page applies (no freetext fields)", () => {
    renderWithRouter(
      <SectionOutline schema={schema} answers={{}} statuses={statuses} currentSectionId="s1" onSelect={vi.fn()} />,
    );
    expect(screen.queryByText("Prep")).not.toBeInTheDocument();
    expect(screen.queryByRole("link", { name: "Drafting style" })).not.toBeInTheDocument();
  });

  it("lists Prep above Build with a link to each prep page", () => {
    renderWithRouter(
      <SectionOutline schema={narrative} answers={{}} statuses={statuses} currentSectionId="s1" onSelect={vi.fn()} />,
    );
    const prep = screen.getByText("Prep");
    const build = screen.getByText("Build");
    expect(prep.compareDocumentPosition(build) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();
    expect(screen.getByRole("link", { name: "Drafting style" })).toHaveAttribute("href", "/interview/t/prep/style");
  });

  it("highlights the active prep page", () => {
    renderWithRouter(
      <SectionOutline
        schema={narrative}
        answers={{}}
        statuses={statuses}
        currentSectionId=""
        onSelect={vi.fn()}
        activeStep="prep"
        currentPrepId="style"
      />,
    );
    expect(screen.getByRole("link", { name: "Drafting style" })).toHaveClass("bg-blue-50");
  });
});
