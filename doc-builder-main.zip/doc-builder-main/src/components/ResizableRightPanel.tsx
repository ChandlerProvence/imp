import { useCallback, useEffect, useRef, useState } from "react";

interface Props {
  children: React.ReactNode;
  /** localStorage key for persisting width. */
  storageKey?: string;
  /** Minimum width in pixels. */
  minWidth?: number;
  /** Maximum fraction of the viewport width. */
  maxWidthFraction?: number;
  /** Pixels reserved for content to the left of this panel (sidebar + main content min). */
  reservedLeft?: number;
}

const DEFAULT_STORAGE_KEY = "doc-builder:chat-panel-width";

/**
 * A right-side panel with a draggable left-edge divider.
 * Defaults to 50% of the window width on first open; persists user preference.
 */
export default function ResizableRightPanel({
  children,
  storageKey = DEFAULT_STORAGE_KEY,
  minWidth = 360,
  maxWidthFraction = 0.50,
  reservedLeft = 320,
}: Props) {
  const [width, setWidth] = useState(() => {
    const stored = localStorage.getItem(storageKey);
    if (stored) {
      const parsed = parseInt(stored, 10);
      if (!isNaN(parsed) && parsed >= minWidth) return parsed;
    }
    // Default to half the viewport
    return Math.round(window.innerWidth / 2);
  });

  const dragging = useRef(false);
  const startX = useRef(0);
  const startWidth = useRef(0);

  const clamp = useCallback(
    (w: number) => {
      const maxByFraction = Math.round(window.innerWidth * maxWidthFraction);
      const maxBySpace = window.innerWidth - reservedLeft;
      return Math.max(minWidth, Math.min(w, maxByFraction, maxBySpace));
    },
    [minWidth, maxWidthFraction, reservedLeft],
  );

  // Re-clamp when the window is resized so the panel never extends off-screen
  useEffect(() => {
    function handleResize() {
      setWidth((prev) => clamp(prev));
    }
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [clamp]);

  const handleMouseDown = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      dragging.current = true;
      startX.current = e.clientX;
      startWidth.current = width;
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
    },
    [width],
  );

  useEffect(() => {
    function handleMouseMove(e: MouseEvent) {
      if (!dragging.current) return;
      // Dragging left (negative delta) increases width for a right panel
      const delta = startX.current - e.clientX;
      const newWidth = clamp(startWidth.current + delta);
      setWidth(newWidth);
    }

    function handleMouseUp() {
      if (!dragging.current) return;
      dragging.current = false;
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
      const el = document.querySelector<HTMLElement>(`[data-chat-panel-resize]`);
      if (el) localStorage.setItem(storageKey, el.style.width.replace("px", ""));
    }

    document.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("mouseup", handleMouseUp);
    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
    };
  }, [clamp, storageKey]);

  return (
    <div
      data-chat-panel-resize
      className="relative flex h-full shrink-0 border-l border-gray-200"
      style={{ width, maxWidth: `calc(100vw - ${reservedLeft}px)` }}
    >
      {/* Resize handle — left edge */}
      <div
        onMouseDown={handleMouseDown}
        className="absolute top-0 left-0 w-1 h-full cursor-col-resize hover:bg-blue-400 active:bg-blue-500 transition-colors z-10"
      />

      {/* Panel content */}
      <div className="flex-1 min-w-0 overflow-hidden">{children}</div>
    </div>
  );
}
