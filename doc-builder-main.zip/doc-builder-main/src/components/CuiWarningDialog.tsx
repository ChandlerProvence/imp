import { useEffect, useRef } from "react";
import type { UploadedDocument } from "../db/types";
import ErrorBox from "./ErrorBox";

interface CuiWarningDialogProps {
  open: boolean;
  /** Draft documents flagged as potential CUI (or whose scan failed). */
  flaggedDocs: UploadedDocument[];
  /** Whether a CUI API key is configured — "Switch to CUI Mode" requires one. */
  cuiKeyConfigured: boolean;
  /** Called to close the dialog without attaching; draft selection is untouched. */
  onCancel: () => void;
  /** Called when the user affirms the flagged documents are not CUI, and attaches. */
  onAffirmNotCui: () => void;
  /** Called when the user switches to CUI mode, and attaches. */
  onSwitchToCui: () => void;
  /** Called from the no-key hint to open Settings. */
  onOpenSettings?: () => void;
}

export default function CuiWarningDialog({
  open,
  flaggedDocs,
  cuiKeyConfigured,
  onCancel,
  onAffirmNotCui,
  onSwitchToCui,
  onOpenSettings,
}: CuiWarningDialogProps) {
  const dialogRef = useRef<HTMLDivElement>(null);
  // Initial focus goes to the safe choice, so Enter never sends flagged content to IL2
  const safeButtonRef = useRef<HTMLButtonElement>(null);

  // Focus trap + Escape handling (same pattern as ConfirmDialog)
  useEffect(() => {
    if (!open) return;

    const dialog = dialogRef.current;
    if (!dialog) return;

    safeButtonRef.current?.focus();

    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape") {
        e.stopPropagation();
        onCancel();
        return;
      }
      if (e.key === "Tab" && dialog) {
        const focusableEls = dialog.querySelectorAll<HTMLElement>(
          'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])',
        );
        if (focusableEls.length === 0) return;
        const first = focusableEls[0];
        const last = focusableEls[focusableEls.length - 1];
        if (e.shiftKey) {
          if (document.activeElement === first) {
            e.preventDefault();
            last.focus();
          }
        } else {
          if (document.activeElement === last) {
            e.preventDefault();
            first.focus();
          }
        }
      }
    }

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [open, onCancel, cuiKeyConfigured]);

  if (!open || flaggedDocs.length === 0) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/50" onClick={onCancel} />

      {/* Dialog */}
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="cui-warning-title"
        className="relative w-full max-w-lg rounded-lg bg-white p-6 shadow-xl"
      >
        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-amber-100">
            <svg className="h-5 w-5 text-amber-600" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z" />
            </svg>
          </div>
          <h2 id="cui-warning-title" className="text-lg font-semibold text-gray-900">
            Potential CUI content detected
          </h2>
        </div>

        {/* Message */}
        <p className="mt-3 text-sm text-gray-600">
          CUI markings or content were detected in the documents below. They have not
          been sent to the Proprietary (IL2) endpoint. If you&apos;re unsure, switch to CUI mode.
        </p>

        {/* Flagged documents */}
        <div className="mt-4 max-h-56 overflow-y-auto space-y-2">
          {flaggedDocs.map((doc) => (
            <div key={doc.id} className="rounded-md border border-amber-200 bg-amber-50 p-3">
              {doc.cuiStatus === "scan-error" ? (
                <>
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-gray-900 truncate">{doc.fileName}</span>
                    <span className="flex-shrink-0 rounded-full bg-gray-200 px-2 py-0.5 text-xs font-medium text-gray-700">
                      scan incomplete
                    </span>
                  </div>
                  <ErrorBox
                    className="mt-2"
                    title="CUI scan failed — document was saved anyway"
                    message={doc.cuiScanError ?? "Unknown error."}
                    detail={doc.cuiScanError ?? "Unknown error."}
                    helpText={null}
                  />
                </>
              ) : (
                <div className="text-sm">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-gray-900 truncate">{doc.fileName}</span>
                    {doc.cuiDetection && (
                      <span
                        className={`flex-shrink-0 rounded-full px-2 py-0.5 text-xs font-medium ${
                          doc.cuiDetection.confidence === "high"
                            ? "bg-amber-200 text-amber-800"
                            : doc.cuiDetection.confidence === "medium"
                              ? "bg-yellow-200 text-yellow-800"
                              : "bg-gray-200 text-gray-700"
                        }`}
                      >
                        {doc.cuiDetection.confidence}
                      </span>
                    )}
                  </div>
                  {doc.cuiDetection && doc.cuiDetection.markers.length > 0 && (
                    <p className="mt-0.5 text-xs text-gray-500">
                      Detected: {doc.cuiDetection.markers.join(", ")}
                    </p>
                  )}
                  {doc.quarantinedImages && doc.quarantinedImages.length > 0 && (
                    <p className="mt-0.5 text-xs text-amber-600">
                      {doc.quarantinedImages.length} image{doc.quarantinedImages.length !== 1 ? "s" : ""} quarantined — they&apos;ll be converted after you choose.
                    </p>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>

        {!cuiKeyConfigured && (
          <p className="mt-4 text-sm text-gray-600">
            Add a CUI API key in Settings to attach these in CUI mode.
            {onOpenSettings && (
              <>
                {" "}
                <button
                  type="button"
                  onClick={onOpenSettings}
                  className="font-medium text-amber-800 underline hover:text-amber-950"
                >
                  Open Settings →
                </button>
              </>
            )}
          </p>
        )}

        {/* Actions — the safe choice is the filled button; affirming "not CUI" is de-emphasized */}
        <div className="mt-6 flex flex-wrap justify-end gap-3">
          <button
            type="button"
            onClick={onAffirmNotCui}
            className="rounded-md border border-amber-300 bg-white px-4 py-2 text-sm font-medium text-amber-800 hover:bg-amber-50"
          >
            These Are Not CUI — Attach
          </button>
          <button
            ref={cuiKeyConfigured ? undefined : safeButtonRef}
            type="button"
            onClick={onCancel}
            className={
              cuiKeyConfigured
                ? "rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
                : "rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
            }
          >
            Cancel
          </button>
          <button
            ref={cuiKeyConfigured ? safeButtonRef : undefined}
            type="button"
            onClick={onSwitchToCui}
            disabled={!cuiKeyConfigured}
            title={cuiKeyConfigured ? undefined : "Requires a CUI API key"}
            className="rounded-md bg-amber-600 px-4 py-2 text-sm font-medium text-white hover:bg-amber-700 disabled:cursor-not-allowed disabled:opacity-50"
          >
            Switch to CUI Mode &amp; Attach
          </button>
        </div>
      </div>
    </div>
  );
}
