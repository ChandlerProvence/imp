import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import ChatInput from "./ChatInput";

describe("ChatInput", () => {
  const defaultProps = {
    onSend: vi.fn(),
    onStop: vi.fn(),
    isStreaming: false,
  };

  it("renders textarea and Send button", () => {
    render(<ChatInput {...defaultProps} />);
    expect(screen.getByPlaceholderText(/Ask the AI/)).toBeInTheDocument();
    expect(screen.getByText("Send")).toBeInTheDocument();
  });

  it("Send button is disabled when textarea is empty", () => {
    render(<ChatInput {...defaultProps} />);
    expect(screen.getByText("Send")).toBeDisabled();
  });

  it("Send button is enabled when textarea has content", () => {
    render(<ChatInput {...defaultProps} />);
    fireEvent.change(screen.getByPlaceholderText(/Ask the AI/), {
      target: { value: "hello" },
    });
    expect(screen.getByText("Send")).not.toBeDisabled();
  });

  it("calls onSend with trimmed text on Send click", () => {
    const onSend = vi.fn();
    render(<ChatInput {...defaultProps} onSend={onSend} />);
    fireEvent.change(screen.getByPlaceholderText(/Ask the AI/), {
      target: { value: "  hello  " },
    });
    fireEvent.click(screen.getByText("Send"));
    expect(onSend).toHaveBeenCalledWith("hello");
  });

  it("clears textarea after send", () => {
    render(<ChatInput {...defaultProps} />);
    const textarea = screen.getByPlaceholderText(/Ask the AI/) as HTMLTextAreaElement;
    fireEvent.change(textarea, { target: { value: "msg" } });
    fireEvent.click(screen.getByText("Send"));
    expect(textarea.value).toBe("");
  });

  it("sends on Ctrl+Enter", () => {
    const onSend = vi.fn();
    render(<ChatInput {...defaultProps} onSend={onSend} />);
    const textarea = screen.getByPlaceholderText(/Ask the AI/);
    fireEvent.change(textarea, { target: { value: "msg" } });
    fireEvent.keyDown(textarea, { key: "Enter", ctrlKey: true });
    expect(onSend).toHaveBeenCalledWith("msg");
  });

  it("shows Stop button when streaming", () => {
    render(<ChatInput {...defaultProps} isStreaming={true} />);
    expect(screen.getByText("Stop")).toBeInTheDocument();
    expect(screen.queryByText("Send")).not.toBeInTheDocument();
  });

  it("calls onStop when Stop button clicked", () => {
    const onStop = vi.fn();
    render(<ChatInput {...defaultProps} onStop={onStop} isStreaming={true} />);
    fireEvent.click(screen.getByText("Stop"));
    expect(onStop).toHaveBeenCalledOnce();
  });

  it("textarea is disabled when streaming", () => {
    render(<ChatInput {...defaultProps} isStreaming={true} />);
    expect(screen.getByPlaceholderText(/Ask the AI/)).toBeDisabled();
  });

  it("textarea is disabled when disabled prop is true", () => {
    render(<ChatInput {...defaultProps} disabled />);
    expect(screen.getByPlaceholderText(/Ask the AI/)).toBeDisabled();
  });

  it("Send button is disabled when disabled prop is true even with docs attached", () => {
    render(
      <ChatInput
        {...defaultProps}
        disabled
        attachedDocs={[{ id: "1", name: "test.pdf" }]}
      />,
    );
    expect(screen.getByText("Send")).toBeDisabled();
  });

  it("Send button is enabled when docs attached and not disabled", () => {
    render(
      <ChatInput
        {...defaultProps}
        attachedDocs={[{ id: "1", name: "test.pdf" }]}
      />,
    );
    expect(screen.getByText("Send")).not.toBeDisabled();
  });

  it("shows processing spinner on doc chip when processing is true", () => {
    const { container } = render(
      <ChatInput
        {...defaultProps}
        attachedDocs={[{ id: "1", name: "test.pdf", processing: true }]}
      />,
    );
    // The processing spinner uses animate-spin class
    const spinner = container.querySelector(".animate-spin");
    expect(spinner).toBeInTheDocument();
  });

  it("shows document icon (not spinner) when processing is false", () => {
    const { container } = render(
      <ChatInput
        {...defaultProps}
        attachedDocs={[{ id: "1", name: "test.pdf", processing: false }]}
      />,
    );
    const spinner = container.querySelector(".animate-spin");
    expect(spinner).not.toBeInTheDocument();
    // SVG document icon should be present
    const svg = container.querySelector("svg");
    expect(svg).toBeInTheDocument();
  });

  it("shows a red error chip with the full message as a tooltip when a doc has an error", () => {
    render(
      <ChatInput
        {...defaultProps}
        attachedDocs={[{ id: "1", name: "test.pdf", error: "Embeddings endpoint returned 500" }]}
      />,
    );
    const chip = screen.getByTitle(/Embeddings endpoint returned 500/);
    expect(chip).toHaveAttribute("title", "test.pdf\nEmbeddings endpoint returned 500");
    expect(chip).toHaveClass("bg-red-50");
    expect(chip).toHaveClass("text-red-700");
  });

  it("shows the slot role in the tooltip instead of an inline pill", () => {
    render(
      <ChatInput
        {...defaultProps}
        attachedDocs={[{ id: "1", name: "statement-of-work.docx", role: "PWS" }]}
      />,
    );
    expect(screen.getByTitle("PWS: statement-of-work.docx")).toBeInTheDocument();
    expect(screen.queryByText("PWS")).not.toBeInTheDocument();
  });
});
