import { useCallback, useEffect, useRef, useState } from "react";
import ProgressRing from "../icons/ProgressRing";

interface AttachedDoc {
  id: string;
  name: string;
  /** True while the document is still being fetched, parsed, or embedded. */
  processing?: boolean;
  /** Completion fraction (0–1) while embedding; undefined/null = indeterminate. */
  progress?: number | null;
  /** Human-readable processing status (e.g. "Embedding 50/120 chunks…"). */
  statusText?: string;
  /** Set when the document has an attachment error (embedding failure, CUI-in-IL2 conflict). */
  error?: string;
  /** Short role label when the document fills a picker slot (e.g. "PWS"). */
  role?: string;
}

interface Props {
  onSend: (text: string) => void;
  onStop: () => void;
  isStreaming: boolean;
  disabled?: boolean;
  /** Called when the + (attach) button is clicked. */
  onAttach?: () => void;
  /** Docs currently attached — shown as chips above the input. */
  attachedDocs?: AttachedDoc[];
  /** Remove an attached doc chip. */
  onRemoveDoc?: (id: string) => void;

  /** Optional slot rendered left of the Send button (e.g. scope selector). */
  scopeSlot?: React.ReactNode;
  /** Optional slot rendered left of Send/Stop (e.g. token radial indicator). */
  tokenSlot?: React.ReactNode;
  /** Optional slot for model/effort indicator (rendered between tokenSlot and Send). */
  modelSlot?: React.ReactNode;
  /** Tailwind classes for textarea border (scope-colored). Falls back to neutral gray. */
  inputColorClasses?: string;
  /** Tailwind classes for the Send button background (scope-colored). Falls back to blue. */
  sendColorClasses?: string;
  /** Pre-fill the textarea with this text. Consumed once on change (via onPrefillConsumed). */
  prefillText?: string | null;
  /** Called after prefillText is consumed (set into textarea). */
  onPrefillConsumed?: () => void;
  /** Override the default placeholder text. */
  placeholder?: string;
}

export default function ChatInput({ onSend, onStop, isStreaming, disabled, onAttach, attachedDocs, onRemoveDoc, scopeSlot, tokenSlot, modelSlot, inputColorClasses, sendColorClasses, prefillText, onPrefillConsumed, placeholder }: Props) {
  const [text, setText] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Consume prefill text: set textarea value and auto-resize
  useEffect(() => {
    if (prefillText != null && prefillText.length > 0) {
      setText(prefillText);
      onPrefillConsumed?.();
      // Auto-resize textarea to fit prefilled content
      if (textareaRef.current) {
        const el = textareaRef.current;
        el.style.height = "auto";
        el.style.height = `${Math.min(el.scrollHeight, 96)}px`;
      }
    }
  }, [prefillText]); // eslint-disable-line react-hooks/exhaustive-deps

  const hasContent = text.trim().length > 0;
  const hasDocs = attachedDocs && attachedDocs.length > 0;

  const handleSend = useCallback(() => {
    if (isStreaming) return;
    // Allow send if there's text OR attached docs
    if (!hasContent && !hasDocs) return;
    onSend(text.trim());
    setText("");
    // Reset textarea height
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
    }
  }, [text, isStreaming, hasContent, hasDocs, onSend]);

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        handleSend();
      }
    },
    [handleSend],
  );

  // Auto-resize textarea up to 4 lines (~96px)
  const handleInput = useCallback((e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
    const el = e.target;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 96)}px`;
  }, []);

  return (
    <div className="border-t border-gray-200 p-3">
      {/* Attached doc chips */}
      {attachedDocs && attachedDocs.length > 0 && (
        <div className="flex flex-wrap gap-1 mb-2">
          {attachedDocs.map((doc) => (
            <span
              key={doc.id}
              title={[
                doc.role ? `${doc.role}: ${doc.name}` : doc.name,
                doc.error ?? (doc.processing ? doc.statusText : undefined),
              ].filter(Boolean).join("\n")}
              className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] ${
                doc.error
                  ? "bg-red-50 border-red-300 text-red-700"
                  : "bg-gray-100 border-gray-200 text-gray-700"
              }`}
            >
              {doc.error ? (
                <span className="shrink-0">✗</span>
              ) : doc.processing ? (
                <ProgressRing progress={doc.progress ?? null} className="w-3 h-3 text-blue-500" />
              ) : (
                <svg className="w-3 h-3 text-gray-400" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                </svg>
              )}
              <span className="max-w-[120px] truncate">{doc.name}</span>
              {onRemoveDoc && (
                <button
                  type="button"
                  onClick={() => onRemoveDoc(doc.id)}
                  className={`-mr-0.5 ${doc.error ? "text-red-400 hover:text-red-600" : "text-gray-400 hover:text-gray-600"}`}
                  title="Remove"
                >
                  <svg className="w-3 h-3" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M6.28 5.22a.75.75 0 0 0-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 1 0 1.06 1.06L10 11.06l3.72 3.72a.75.75 0 1 0 1.06-1.06L11.06 10l3.72-3.72a.75.75 0 0 0-1.06-1.06L10 8.94 6.28 5.22Z" />
                  </svg>
                </button>
              )}
            </span>
          ))}
        </div>
      )}

      {/* Textarea — full width */}
      <textarea
        ref={textareaRef}
        value={text}
        onChange={handleInput}
        onKeyDown={handleKeyDown}
        disabled={disabled || isStreaming}
        placeholder={placeholder ?? "Ask the AI to help draft…"}
        rows={1}
        className={`w-full resize-none rounded-md border px-3 py-2 text-sm transition-colors disabled:bg-gray-50 disabled:text-gray-400 ${inputColorClasses ?? "border-gray-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"}`}
      />

      {/* Toolbar row: + button + hint on left, Send/Stop on right */}
      <div className="flex items-center justify-between mt-1.5 min-w-0">
        <div className="flex items-center gap-2 shrink min-w-0 overflow-hidden">
          {onAttach && (
            <button
              type="button"
              onClick={onAttach}
              className="flex items-center justify-center w-6 h-6 shrink-0 rounded-full border border-gray-500 text-gray-700 hover:text-gray-900 hover:border-gray-600 hover:bg-gray-50 transition-colors"
              title="Add documents"
            >
              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
              </svg>
            </button>
          )}
          <span className="text-[11px] text-gray-400 truncate">Shift+Enter for new line</span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {tokenSlot}
          {modelSlot}
          {scopeSlot}
          {isStreaming ? (
            <button
              type="button"
              onClick={onStop}
              className="shrink-0 rounded-md bg-red-100 px-3 py-1.5 text-xs font-medium text-red-700 hover:bg-red-200 border border-red-200"
            >
              Stop
            </button>
          ) : (
            <button
              type="button"
              onClick={handleSend}
              disabled={disabled || (!hasContent && !hasDocs)}
              className={`shrink-0 rounded-md px-3 py-1.5 text-xs font-medium text-white transition-colors disabled:opacity-40 disabled:cursor-not-allowed ${sendColorClasses ?? "bg-blue-600 hover:bg-blue-700"}`}
            >
              Send
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
