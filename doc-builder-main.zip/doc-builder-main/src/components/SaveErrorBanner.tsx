import { useState } from "react";
import { useWriteError } from "../db/writeStatus";
import { downloadSessionExport } from "../db/sessionExport";
import { useSessionContext } from "../context/SessionContext";
import { appErrorCopyText } from "./AppErrorBox";

/**
 * App-wide banner shown while background saves to browser storage are
 * failing. Stays until a later write succeeds. Full-width so it reads as an
 * app-level problem, distinct from per-field validation warnings.
 */
export default function SaveErrorBanner() {
  const error = useWriteError();
  const { session, answers, fieldMeta } = useSessionContext();
  const [exportFailed, setExportFailed] = useState(false);

  if (!error) return null;

  async function handleExport() {
    if (!session) return;
    try {
      // Export live in-memory values — the stored copy is missing unsaved edits
      await downloadSessionExport(session.id, { answers, fieldMeta });
      setExportFailed(false);
    } catch (err) {
      console.error("[storage] Export from save banner failed:", err);
      setExportFailed(true);
    }
  }

  return (
    <div
      role="alert"
      className="flex flex-wrap items-center gap-x-3 gap-y-1 bg-red-50 border-b border-red-200 px-4 py-2 text-sm text-red-800"
    >
      <span className="font-medium">⚠ Your changes aren't being saved.</span>
      <span>{error.message}</span>
      {error.help && <span className="text-red-700">{error.help}</span>}
      <span className="flex gap-2 ml-auto">
        {session && (
          <button
            type="button"
            onClick={handleExport}
            className="rounded border border-red-300 bg-white px-2 py-0.5 text-xs font-medium text-red-700 hover:bg-red-100"
          >
            Export session
          </button>
        )}
        <button
          type="button"
          onClick={() => navigator.clipboard.writeText(appErrorCopyText(error))}
          className="rounded border border-red-300 bg-white px-2 py-0.5 text-xs font-medium text-red-700 hover:bg-red-100"
          title="Copy error details to clipboard"
        >
          Copy details
        </button>
      </span>
      {exportFailed && (
        <span className="w-full text-xs text-red-700">
          Export failed too — copy your answers out of the fields manually before closing this tab.
        </span>
      )}
    </div>
  );
}
