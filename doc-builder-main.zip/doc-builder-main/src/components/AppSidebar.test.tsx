import { describe, it, expect } from "vitest";
import { screen } from "@testing-library/react";
import AppSidebar from "./AppSidebar";
import { renderWithProviders } from "../test/renderWithProviders";
import { createMockSchema, createMockSection } from "../test/mocks";

describe("AppSidebar", () => {
  it("renders section outline when session and schema exist", () => {
    const schema = createMockSchema({
      sections: [
        createMockSection({ id: "s1", title: "First Section" }),
        createMockSection({ id: "s2", title: "Second Section" }),
      ],
    });
    renderWithProviders(<AppSidebar />, {
      sessionContext: { schema, sectionStatuses: { s1: "empty", s2: "empty" } },
      routerEntries: ["/interview/s1"],
    });
    expect(screen.getByText("First Section")).toBeInTheDocument();
    expect(screen.getByText("Second Section")).toBeInTheDocument();
  });

  it("shows placeholder when no session", () => {
    renderWithProviders(<AppSidebar />, {
      sessionContext: { session: null, schema: null },
    });
    // Should not show section content
    expect(screen.queryByText("Build")).not.toBeInTheDocument();
  });

  it("shows the docs file list instead of Steps on /docs routes", () => {
    const schema = createMockSchema({
      sections: [createMockSection({ id: "s1", title: "First Section" })],
    });
    renderWithProviders(<AppSidebar />, {
      sessionContext: { schema, sectionStatuses: { s1: "empty" } },
      routerEntries: ["/docs/help/attachments"],
    });
    expect(screen.getByRole("navigation", { name: "Documentation" })).toBeInTheDocument();
    expect(screen.queryByText("First Section")).not.toBeInTheDocument();
    expect(screen.getByText("Attachments").closest("button")).toHaveAttribute("aria-current", "page");
  });

  it("shows the docs file list without a session", () => {
    renderWithProviders(<AppSidebar />, {
      sessionContext: { session: null, schema: null },
      routerEntries: ["/docs"],
    });
    expect(screen.queryByText("No document open")).not.toBeInTheDocument();
    expect(screen.getByText("Development Plan").closest("button")).toHaveAttribute("aria-current", "page");
  });
});
