import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import FieldsPanel from "./FieldsPanel";
import type { DocumentSchema, SectionDef } from "../schemas/types";

// Mock FieldRenderer to isolate FieldsPanel logic
vi.mock("./FieldRenderer", () => ({
  default: ({ field, fieldKey, linkedFromLabel }: any) => (
    <div data-testid={`field-${fieldKey}`}>
      {field.label}
      {linkedFromLabel && <span>linked:{linkedFromLabel}</span>}
    </div>
  ),
}));

describe("FieldsPanel", () => {
  const section: SectionDef = {
    id: "info",
    title: "Basic Information",
    fields: [
      { id: "name", label: "Name", type: "string", required: true },
      { id: "desc", label: "Description", type: "freetext", required: false },
    ],
  };

  it("renders section title", () => {
    render(
      <FieldsPanel
        section={section}
        answers={{}}
        fieldMeta={{}}
        onAnswer={vi.fn()}
      />,
    );
    expect(screen.getByText("Basic Information")).toBeInTheDocument();
  });

  it("renders a FieldRenderer for each field", () => {
    render(
      <FieldsPanel
        section={section}
        answers={{}}
        fieldMeta={{}}
        onAnswer={vi.fn()}
      />,
    );
    expect(screen.getByTestId("field-info.name")).toBeInTheDocument();
    expect(screen.getByTestId("field-info.desc")).toBeInTheDocument();
  });

  it("resolves linked field labels from schema", () => {
    const linkedSection: SectionDef = {
      id: "s2",
      title: "Section 2",
      fields: [
        { id: "name", label: "Linked Name", type: "string", required: false, same_as: "info.name" },
      ],
    };
    const schema: DocumentSchema = {
      id: "test",
      title: "Test",
      version: 1,
      sections: [section, linkedSection],
    };

    render(
      <FieldsPanel
        section={linkedSection}
        answers={{}}
        fieldMeta={{}}
        onAnswer={vi.fn()}
        schema={schema}
      />,
    );
    expect(screen.getByText("linked:Name")).toBeInTheDocument();
  });

  it("only passes onOpenChat for freetext fields", () => {
    const onOpenChat = vi.fn();
    // We mock FieldRenderer, so we can't assert onOpenChat prop easily.
    // Instead verify it renders without error.
    render(
      <FieldsPanel
        section={section}
        answers={{}}
        fieldMeta={{}}
        onAnswer={vi.fn()}
        onOpenChat={onOpenChat}
      />,
    );
    expect(screen.getByTestId("field-info.name")).toBeInTheDocument();
    expect(screen.getByTestId("field-info.desc")).toBeInTheDocument();
  });
});
