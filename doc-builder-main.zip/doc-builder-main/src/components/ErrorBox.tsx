import { type ReactNode, useState } from "react";

const DEFAULT_HELP_TEXT =
  "If this error persists, use the button above to copy an error report and send it to Winston T. Chu (winston.chu@leidos.com).";

interface ErrorBoxProps {
  /** Bold title line, e.g. "Connection failed". Rendered with a "✗" prefix. */
  title: string;
  /** Optional plain-language explanation shown under the title. */
  message?: string;
  /** Technical error detail shown in a monospace block. Copyable via button. */
  detail: string;
  /** Text copied to the clipboard. Defaults to `detail`. Pass a richer
   *  string (e.g. a diagnostics report) to give admins more context. */
  copyText?: string;
  /** Instructional text below the detail. Defaults to the admin-contact
   *  message. Pass `null` to suppress it entirely. */
  helpText?: ReactNode | null;
  /** Additional Tailwind classes on the outer container (e.g. "mt-2"). */
  className?: string;
}

export default function ErrorBox({
  title,
  message,
  detail,
  copyText,
  helpText = DEFAULT_HELP_TEXT,
  className,
}: ErrorBoxProps) {
  const [copied, setCopied] = useState(false);

  function handleCopy() {
    navigator.clipboard.writeText(copyText ?? detail).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    });
  }

  return (
    <div
      className={`rounded-md border border-red-300 bg-red-50 p-2.5${className ? ` ${className}` : ""}`}
    >
      <p className="text-xs font-medium text-red-800">✗ {title}</p>
      {message && <p className="mt-0.5 text-xs text-red-800">{message}</p>}

      {(detail || copyText) && (
        <button
          type="button"
          onClick={handleCopy}
          className="mt-1 inline-flex items-center gap-1 rounded border border-red-300 bg-white px-2 py-0.5 text-xs font-medium text-red-700 hover:bg-red-100 transition-colors"
        >
          {copied ? (
            <>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" className="w-3 h-3 text-green-600">
                <path fillRule="evenodd" d="M12.416 3.376a.75.75 0 0 1 .208 1.04l-5 7.5a.75.75 0 0 1-1.154.114l-3-3a.75.75 0 0 1 1.06-1.06l2.353 2.353 4.493-6.74a.75.75 0 0 1 1.04-.207Z" clipRule="evenodd" />
              </svg>
              Copied!
            </>
          ) : (
            <>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" className="w-3 h-3">
                <path d="M5.5 3.5A1.5 1.5 0 0 1 7 2h2.879a1.5 1.5 0 0 1 1.06.44l2.122 2.12a1.5 1.5 0 0 1 .439 1.061V9.5A1.5 1.5 0 0 1 12 11V3.5H5.5Z" />
                <path d="M3.5 5.5A1.5 1.5 0 0 1 5 4h3.379a1.5 1.5 0 0 1 1.06.44l2.122 2.12a1.5 1.5 0 0 1 .439 1.061V11.5A1.5 1.5 0 0 1 10.5 13H5a1.5 1.5 0 0 1-1.5-1.5v-6Z" />
              </svg>
              Copy Error Report
            </>
          )}
        </button>
      )}

      {helpText != null && (
        <p className="mt-1.5 text-xs text-red-700">{helpText}</p>
      )}
    </div>
  );
}
