interface Props {
  className?: string;
}

/** Inline SVG magic wand icon. Uses currentColor so it inherits text-* classes. */
export default function MagicWandIcon({ className = "w-4 h-4" }: Props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="currentColor"
      className={className}
    >
      {/* Wand shaft */}
      <path d="M3.5 20.5a1 1 0 0 1 0-1.414l11-11a1 1 0 1 1 1.414 1.414l-11 11a1 1 0 0 1-1.414 0Z" />
      {/* Sparkles */}
      <path d="M18 2v2m0 2V4m-2 0h2m2 0h-2M14 6v1.5m0 1.5V7.5M12.5 7.5H14m1.5 0H14M20 10v1.5m0 1.5v-1.5M18.5 11.5H20m1.5 0H20" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" fill="none" />
    </svg>
  );
}
