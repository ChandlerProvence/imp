interface Props {
  /** Completion fraction in [0, 1]. `null` renders an indeterminate spinner. */
  progress: number | null;
  className?: string;
  title?: string;
}

const RADIUS = 10;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;

/**
 * Small circular progress indicator. Uses currentColor so it inherits text-*
 * classes. Determinate when `progress` is a number (arc sweeps clockwise from
 * 12 o'clock and closes into a full ring at 1); falls back to a spinning arc
 * when `progress` is null.
 */
export default function ProgressRing({ progress, className = "w-3 h-3", title }: Props) {
  if (progress === null) {
    return (
      <span
        role="progressbar"
        title={title}
        className={`inline-block border-[1.5px] border-current border-t-transparent rounded-full animate-spin shrink-0 ${className}`}
      />
    );
  }

  const clamped = Math.min(1, Math.max(0, progress));
  return (
    <svg
      role="progressbar"
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={Math.round(clamped * 100)}
      viewBox="0 0 24 24"
      fill="none"
      className={`shrink-0 ${className}`}
    >
      {title && <title>{title}</title>}
      {/* Track */}
      <circle cx="12" cy="12" r={RADIUS} stroke="currentColor" strokeWidth="3" opacity="0.25" />
      {/* Filled arc */}
      <circle
        cx="12"
        cy="12"
        r={RADIUS}
        stroke="currentColor"
        strokeWidth="3"
        strokeLinecap="round"
        strokeDasharray={CIRCUMFERENCE}
        strokeDashoffset={CIRCUMFERENCE * (1 - clamped)}
        transform="rotate(-90 12 12)"
        className="transition-[stroke-dashoffset] duration-300 ease-out"
      />
    </svg>
  );
}
