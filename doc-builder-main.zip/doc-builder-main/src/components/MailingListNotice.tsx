import { useState } from "react";
import { CONTACT_EMAIL, CONTACT_NAME } from "../config/contact";
import { MAILING_LIST_MAILTO } from "../config/mailingList";

/** Set once the user emails or dismisses; value records which ("emailed" | "dismissed"). */
export const MAILING_LIST_DISMISSED_KEY = "doc-builder:mailing-list-dismissed";

/**
 * App-wide first-visit notice asking users to join the update mailing list.
 * Hidden for good after either action; Help → Get Update Notifications… and
 * the Contact page remain as permanent entry points.
 */
export default function MailingListNotice() {
  const [hidden, setHidden] = useState(() => localStorage.getItem(MAILING_LIST_DISMISSED_KEY) !== null);
  if (hidden) return null;

  function hide(reason: "emailed" | "dismissed") {
    localStorage.setItem(MAILING_LIST_DISMISSED_KEY, reason);
    setHidden(true);
  }

  return (
    // A labeled region, not role="status": it's static on load, so it shouldn't be
    // announced as a live update or collide with real status messages.
    <section
      aria-label="Mailing list"
      className="flex flex-wrap items-center gap-x-3 gap-y-1 bg-blue-50 border-b border-blue-200 px-4 py-2 text-sm text-blue-900"
    >
      <span className="font-medium">Stay up to date.</span>
      <span>
        Email {CONTACT_NAME} (
        <a className="underline" href={MAILING_LIST_MAILTO}>
          {CONTACT_EMAIL}
        </a>
        ) to join the mailing list for Doc Builder update notifications.
      </span>
      <span className="ml-auto flex gap-2">
        <a
          href={MAILING_LIST_MAILTO}
          onClick={() => hide("emailed")}
          className="rounded border border-blue-600 bg-blue-600 px-2 py-0.5 text-xs font-medium text-white hover:bg-blue-700"
        >
          Email me to join
        </a>
        <button
          type="button"
          onClick={() => hide("dismissed")}
          className="rounded border border-blue-300 bg-white px-2 py-0.5 text-xs font-medium text-blue-800 hover:bg-blue-100"
        >
          Dismiss
        </button>
      </span>
    </section>
  );
}
