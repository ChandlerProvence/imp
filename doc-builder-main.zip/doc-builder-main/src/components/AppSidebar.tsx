import { useCallback, useEffect, useMemo } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useSessionContext } from "../context/SessionContext";
import { useSidebarOpen } from "../hooks/useSidebarOpen";
import SectionOutline from "./SectionOutline";
import { prepIdFromPath, prepPagesFor, prepPath } from "../pages/prep/prepPages";
import ResizableSidebar from "./ResizableSidebar";
import DocsNav from "./DocsNav";
import { DEFAULT_DOC_ID, findDoc } from "../docs/docsRegistry";
import type { SectionStatus } from "../engine/types";
import { countWarnings } from "../engine/validation";

const STATUS_ICON: Record<SectionStatus, string> = {
  empty: "○",
  "in-progress": "◐",
  complete: "✓",
};

const STATUS_COLOR: Record<SectionStatus, string> = {
  empty: "text-gray-400",
  "in-progress": "text-amber-500",
  complete: "text-green-600",
};

/** Derive an overall status for the Build step from its sub-section statuses. */
function deriveBuildStatus(
  statuses: Record<string, SectionStatus>,
  sectionIds: string[],
): SectionStatus {
  const sectionStatuses = sectionIds.map((id) => statuses[id] ?? "empty");
  if (sectionStatuses.every((s) => s === "complete")) return "complete";
  if (sectionStatuses.every((s) => s === "empty")) return "empty";
  return "in-progress";
}

/** Narrow collapsed strip with only an expand chevron. */
function CollapsedStrip({ onExpand }: { onExpand: () => void }) {
  return (
    <div className="print:hidden h-full">
      <button
        type="button"
        onClick={onExpand}
        className="flex flex-col items-center border-r border-gray-200 bg-white w-10 shrink-0 h-full cursor-pointer hover:bg-gray-50 transition-colors"
        title="Expand sidebar (Ctrl+B)"
      >
        {/* Expand chevron */}
        <div className="mt-3 p-1.5 text-gray-400">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-3.5 h-3.5">
            <path fillRule="evenodd" d="M8.22 5.22a.75.75 0 0 1 1.06 0l4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.75.75 0 0 1-1.06-1.06L11.94 10 8.22 6.28a.75.75 0 0 1 0-1.06Z" clipRule="evenodd" />
          </svg>
        </div>
      </button>
    </div>
  );
}

/**
 * App-level sidebar — always visible (like the menu bar).
 * Shows the docs file list on `/docs/*` routes, otherwise the section
 * outline whenever an active session exists.
 * Can be collapsed to a narrow icon strip showing only status symbols.
 */
export default function AppSidebar() {
  const location = useLocation();
  const navigate = useNavigate();
  const { session, schema, sectionStatuses, answers, validationIssues } = useSessionContext();
  const issueCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const section of schema?.sections ?? []) {
      const n = countWarnings(validationIssues, section.id);
      if (n > 0) counts[section.id] = n;
    }
    return counts;
  }, [schema, validationIssues]);
  const [sidebarOpen, setSidebarOpen] = useSidebarOpen();

  // Derive the active section ID from the URL
  const activeSectionId = useMemo(() => {
    const match = location.pathname.match(/^\/interview\/[^/]+\/(.+)$/);
    return match?.[1] ?? "";
  }, [location.pathname]);

  // Doc id from a /docs/* route ("" for bare /docs), or null when not on the docs page
  const docsPath = useMemo(() => {
    const match = location.pathname.match(/^\/docs(?:\/(.*))?$/);
    return match ? match[1] ?? "" : null;
  }, [location.pathname]);

  const activePrepId = useMemo(() => prepIdFromPath(location.pathname), [location.pathname]);

  // Derive active step from route
  const activeStep: "prep" | "interview" | "review" | "generate" = useMemo(
    () => {
      if (location.pathname.startsWith("/preview")) return "generate";
      if (location.pathname.startsWith("/review")) return "review";
      if (activePrepId) return "prep";
      return "interview";
    },
    [location.pathname, activePrepId],
  );

  function handleSelect(sectionId: string) {
    if (!schema) return;
    navigate(`/interview/${schema.id}/${sectionId}`);
  }

  const handleCollapse = useCallback(() => setSidebarOpen(false), [setSidebarOpen]);
  const handleExpand = useCallback(() => setSidebarOpen(true), [setSidebarOpen]);

  // Ctrl+B / Cmd+B keyboard shortcut to toggle sidebar
  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key === "b") {
        e.preventDefault();
        setSidebarOpen((prev) => !prev);
      }
    }
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [setSidebarOpen]);

  // Documentation routes — the sidebar becomes the docs file list
  if (docsPath !== null) {
    if (!sidebarOpen) return <CollapsedStrip onExpand={handleExpand} />;
    return (
      <div className="print:hidden h-full">
        <ResizableSidebar>
          <DocsNav activeId={findDoc(docsPath)?.id ?? DEFAULT_DOC_ID} onCollapse={handleCollapse} />
        </ResizableSidebar>
      </div>
    );
  }

  // No session yet — show empty sidebar placeholder
  if (!session || !schema) {
    if (!sidebarOpen) return <CollapsedStrip onExpand={handleExpand} />;

    return (
      <div className="print:hidden h-full">
        <ResizableSidebar>
          <nav className="min-h-0 flex-1 border-r border-gray-200 bg-white px-2 py-3 text-xs">
            <div className="flex items-center justify-between px-2 mb-2">
              <h2 className="text-[10px] font-semibold uppercase tracking-wider text-gray-400">
                Steps
              </h2>
              <button
                type="button"
                onClick={handleCollapse}
                className="text-gray-400 hover:text-gray-600 p-0.5 rounded hover:bg-gray-200 transition-colors"
                title="Collapse sidebar (Ctrl+B)"
              >
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-3 h-3">
                  <path fillRule="evenodd" d="M11.78 5.22a.75.75 0 0 1 0 1.06L8.06 10l3.72 3.72a.75.75 0 1 1-1.06 1.06l-4.25-4.25a.75.75 0 0 1 0-1.06l4.25-4.25a.75.75 0 0 1 1.06 0Z" clipRule="evenodd" />
                </svg>
              </button>
            </div>
            <p className="px-2 text-gray-400 text-[10px]">No document open</p>
          </nav>
        </ResizableSidebar>
      </div>
    );
  }

  // Collapsed icon strip — status symbols only
  if (!sidebarOpen) {
    const buildStatus = deriveBuildStatus(
      sectionStatuses,
      schema.sections.map((s) => s.id),
    );
    const prepPages = prepPagesFor(schema);

    return (
      <div className="print:hidden h-full">
        <nav
          className="flex flex-col items-center border-r border-gray-200 bg-white w-10 shrink-0 h-full py-3 overflow-y-auto"
          aria-label="Steps (collapsed)"
        >
          {/* Expand chevron */}
          <button
            type="button"
            onClick={handleExpand}
            className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded transition-colors mb-2"
            title="Expand sidebar (Ctrl+B)"
          >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-3.5 h-3.5">
              <path fillRule="evenodd" d="M8.22 5.22a.75.75 0 0 1 1.06 0l4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.75.75 0 0 1-1.06-1.06L11.94 10 8.22 6.28a.75.75 0 0 1 0-1.06Z" clipRule="evenodd" />
            </svg>
          </button>

          {/* Prep (only when a prep page applies to this schema) */}
          {prepPages.length > 0 && (
            <button
              type="button"
              onClick={() => { handleExpand(); navigate(prepPath(schema.id, prepPages[0].id)); }}
              className={`w-7 h-7 flex items-center justify-center rounded text-xs transition-colors hover:bg-gray-100 ${
                activeStep === "prep" ? "bg-blue-50 text-blue-700" : "text-gray-400"
              }`}
              title="Prep"
              aria-label="Prep"
            >
              ○
            </button>
          )}

          {/* Build (aggregate) */}
          <button
            type="button"
            onClick={() => { handleExpand(); handleSelect(schema.sections[0].id); }}
            className={`w-7 h-7 flex items-center justify-center rounded text-xs transition-colors hover:bg-gray-100 ${STATUS_COLOR[buildStatus]}`}
            title="Build"
          >
            {STATUS_ICON[buildStatus]}
          </button>

          {/* Section sub-items */}
          <div className="ml-0 border-l border-gray-200 pl-0 space-y-px mt-px">
            {schema.sections.map((section) => {
              const status = sectionStatuses[section.id] ?? "empty";
              const active = activeStep === "interview" && section.id === activeSectionId;
              return (
                <button
                  key={section.id}
                  type="button"
                  onClick={() => { handleExpand(); handleSelect(section.id); }}
                  className={`relative w-7 h-7 flex items-center justify-center rounded text-[10px] transition-colors ${
                    active
                      ? "bg-blue-50 ring-1 ring-blue-300"
                      : "hover:bg-gray-100"
                  } ${STATUS_COLOR[status]}`}
                  title={issueCounts[section.id] ? `${section.title} — ${issueCounts[section.id]} problem(s)` : section.title}
                >
                  {STATUS_ICON[status]}
                  {issueCounts[section.id] && (
                    <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 rounded-full bg-red-500" aria-hidden="true" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Separator */}
          <div className="w-5 border-t border-gray-200 my-1.5" />

          {/* Review */}
          <button
            type="button"
            onClick={() => { handleExpand(); navigate("/review"); }}
            className={`w-7 h-7 flex items-center justify-center rounded text-xs transition-colors ${
              activeStep === "review" ? "bg-blue-50 ring-1 ring-blue-300" : "hover:bg-gray-100"
            } ${session.reviewApproved ? "text-green-600" : "text-gray-400"}`}
            title="Review"
          >
            {session.reviewApproved ? "✓" : "○"}
          </button>

          {/* Export */}
          <button
            type="button"
            onClick={() => { handleExpand(); navigate("/preview"); }}
            className={`w-7 h-7 flex items-center justify-center rounded text-xs transition-colors ${
              activeStep === "generate" ? "bg-blue-50 ring-1 ring-blue-300" : "hover:bg-gray-100"
            } ${session.generated ? "text-green-600" : "text-gray-400"}`}
            title="Export"
          >
            {session.generated ? "✓" : "○"}
          </button>
        </nav>
      </div>
    );
  }

  // Expanded sidebar
  return (
    <div className="print:hidden h-full">
      <ResizableSidebar>
        <SectionOutline
          schema={schema}
          statuses={sectionStatuses}
          issueCounts={issueCounts}
          currentSectionId={activeSectionId}
          onSelect={handleSelect}
          answers={answers}
          activeStep={activeStep}
          currentPrepId={activePrepId}
          reviewApproved={session.reviewApproved ?? false}
          generated={session.generated ?? false}
          onCollapse={handleCollapse}
        />
      </ResizableSidebar>
    </div>
  );
}
