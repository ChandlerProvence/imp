import { useMemo } from "react";
import { Link } from "react-router-dom";
import type { DocumentSchema, SectionDef } from "../schemas/types";
import type { SectionStatus } from "../engine/types";
import { isSectionFullyLinked } from "../engine/fieldLinks";
import { getVisibleSections } from "../engine/visibility";
import { prepPagesFor, prepPath } from "../pages/prep/prepPages";

interface Props {
  schema: DocumentSchema;
  statuses: Record<string, SectionStatus>;
  /** Warning-level validation problem counts by section id (absent = none). */
  issueCounts?: Record<string, number>;
  currentSectionId: string;
  onSelect: (sectionId: string) => void;
  /** Current answer map — used to evaluate `visible_when` on sections. */
  answers: Record<string, string | number | boolean>;
  /** Which workflow step is active. */
  activeStep?: "prep" | "interview" | "review" | "generate";
  /** Active prep page id when `activeStep` is "prep". */
  currentPrepId?: string | null;
  /** Whether the review has been approved. */
  reviewApproved?: boolean;
  /** Whether the document has been generated. */
  generated?: boolean;
  /** Callback to collapse the sidebar. When provided, a collapse chevron is shown in the header. */
  onCollapse?: () => void;
}

const STATUS_ICON: Record<SectionStatus, string> = {
  empty: "○",
  "in-progress": "◐",
  complete: "✓",
};

const STATUS_COLOR: Record<SectionStatus, string> = {
  empty: "text-gray-400",
  "in-progress": "text-amber-500",
  complete: "text-green-600",
};

/** Derive an overall status for the "Refine" step from its sub-section statuses. */
function deriveBuildStatus(
  statuses: Record<string, SectionStatus>,
  sections: SectionDef[],
): SectionStatus {
  const sectionStatuses = sections.map((s) => statuses[s.id] ?? "empty");
  if (sectionStatuses.every((s) => s === "complete")) return "complete";
  if (sectionStatuses.every((s) => s === "empty")) return "empty";
  return "in-progress";
}

export default function SectionOutline({
  schema,
  statuses,
  issueCounts = {},
  currentSectionId,
  onSelect,
  answers,
  activeStep = "interview",
  currentPrepId = null,
  reviewApproved = false,
  generated = false,
  onCollapse,
}: Props) {
  const visibleSections = useMemo(
    () => getVisibleSections(schema, answers),
    [schema, answers],
  );

  const buildStatus = deriveBuildStatus(statuses, visibleSections);
  const prepPages = useMemo(() => prepPagesFor(schema), [schema]);

  return (
    <nav className="h-full min-h-0 flex-1 border-r border-gray-200 bg-white px-2 py-3 overflow-y-auto text-xs">
      <div className="flex items-center justify-between px-2 mb-2">
        <h2 className="text-[10px] font-semibold uppercase tracking-wider text-gray-400">
          Steps
        </h2>
        {onCollapse && (
          <button
            type="button"
            onClick={onCollapse}
            className="text-gray-400 hover:text-gray-600 p-0.5 rounded hover:bg-gray-200 transition-colors"
            title="Collapse sidebar (Ctrl+B)"
          >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-3 h-3">
              <path fillRule="evenodd" d="M11.78 5.22a.75.75 0 0 1 0 1.06L8.06 10l3.72 3.72a.75.75 0 1 1-1.06 1.06l-4.25-4.25a.75.75 0 0 1 0-1.06l4.25-4.25a.75.75 0 0 1 1.06 0Z" clipRule="evenodd" />
            </svg>
          </button>
        )}
      </div>
      <ol className="space-y-px">
        {/* 0. Prep (parent) — pages that come before the schema's sections, when any apply */}
        {prepPages.length > 0 && (
        <li>
          <Link
            to={prepPath(schema.id, prepPages[0].id)}
            className={`flex items-center gap-1.5 rounded px-2 py-1 text-xs font-medium transition-colors ${
              activeStep === "prep" ? "text-gray-900 hover:bg-gray-100" : "text-gray-600 hover:bg-gray-100"
            }`}
          >
            <span className="text-xs text-gray-400">○</span>
            <span>Prep</span>
          </Link>
          <ol className="ml-3 border-l border-gray-200 pl-1.5 space-y-px mt-px">
            {prepPages.map((page) => (
              <li key={page.id}>
                <Link
                  to={prepPath(schema.id, page.id)}
                  className={`flex items-center gap-1.5 rounded px-2 py-1 text-xs transition-colors ${
                    activeStep === "prep" && page.id === currentPrepId
                      ? "bg-blue-50 text-blue-900 font-medium"
                      : "text-gray-600 hover:bg-gray-100"
                  }`}
                >
                  <span className="truncate">{page.title}</span>
                </Link>
              </li>
            ))}
          </ol>
        </li>
        )}

        {/* 1. Build (parent) — contains section sub-items */}
        <li>
          <button
            type="button"
            onClick={() => onSelect(visibleSections[0]?.id ?? schema.sections[0].id)}
            className={`w-full flex items-center gap-1.5 rounded px-2 py-1 text-left text-xs font-medium transition-colors ${
              activeStep === "interview"
                ? "text-gray-900 hover:bg-gray-100"
                : "text-gray-600 hover:bg-gray-100"
            }`}
          >
            <span className={`text-xs ${STATUS_COLOR[buildStatus]}`}>
              {STATUS_ICON[buildStatus]}
            </span>
            <span>Build</span>
          </button>

          {/* Sub-items: individual sections (only visible ones) */}
          <ol className="ml-3 border-l border-gray-200 pl-1.5 space-y-px mt-px">
            {visibleSections.map((section) => {
              const status = statuses[section.id] ?? "empty";
              const active =
                activeStep === "interview" && section.id === currentSectionId;
              const fullyLinked = isSectionFullyLinked(section);
              return (
                <li key={section.id}>
                  <button
                    type="button"
                    onClick={() => onSelect(section.id)}
                    className={`w-full flex items-center gap-1.5 rounded px-2 py-1 text-left text-xs transition-colors ${
                      active
                        ? "bg-blue-50 text-blue-900 font-medium"
                        : "text-gray-600 hover:bg-gray-100"
                    }`}
                  >
                    <span className={`text-[10px] ${STATUS_COLOR[status]}`}>
                      {STATUS_ICON[status]}
                    </span>
                    <span className="truncate">{section.title}</span>
                    {issueCounts[section.id] ? (
                      <span
                        className="ml-auto shrink-0 rounded-full bg-red-100 px-1.5 text-[10px] font-semibold text-red-700"
                        title={`${issueCounts[section.id]} problem(s) to check`}
                      >
                        !
                      </span>
                    ) : null}
                    {fullyLinked && (
                      <span className="ml-auto text-[10px] text-gray-400" title="All fields linked from other sections">🔗</span>
                    )}
                  </button>
                </li>
              );
            })}
          </ol>
        </li>

        {/* 2. Review */}
        <li>
          <Link
            to="/review"
            className={`flex items-center gap-1.5 rounded px-2 py-1 text-xs transition-colors ${
              activeStep === "review"
                ? "bg-blue-50 text-blue-900 font-medium"
                : "text-gray-600 hover:bg-gray-100"
            }`}
          >
            <span className={`text-xs ${reviewApproved ? "text-green-600" : "text-gray-400"}`}>
              {reviewApproved ? "✓" : "○"}
            </span>
            <span>Review</span>
          </Link>
        </li>

        {/* 3. Export */}
        <li>
          <Link
            to="/preview"
            className={`flex items-center gap-1.5 rounded px-2 py-1 text-xs transition-colors ${
              activeStep === "generate"
                ? "bg-blue-50 text-blue-900 font-medium"
                : "text-gray-600 hover:bg-gray-100"
            }`}
          >
            <span className={`text-xs ${generated ? "text-green-600" : "text-gray-400"}`}>
              {generated ? "✓" : "○"}
            </span>
            <span>Export</span>
          </Link>
        </li>
      </ol>
    </nav>
  );
}
