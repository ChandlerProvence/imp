import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, fireEvent, within } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { AiConfigProvider } from "../context/AiConfigContext";
import { AskSageProvider } from "../context/AskSageContext";
import { UserPreferencesProvider } from "../context/UserPreferencesContext";
import SettingsDialog from "./SettingsDialog";
import { ACTIVE_ENDPOINT_KEY, ENDPOINTS, LEGACY_API_KEY_STORAGE, apiKeyStorageKey } from "../ai/endpoints";
import { _resetModelsForTests, getModelOverrides, setDiscoveredModels } from "../ai/models";

const CUI_STANDARD = ENDPOINTS.cui.models.standard;
const CUI_NEWER = "claude-sonnet-5-9-aws-gov-il5";

function renderSettings() {
  return render(
    <MemoryRouter>
      <UserPreferencesProvider>
        <AiConfigProvider>
          <AskSageProvider>
            <SettingsDialog open onClose={() => {}} />
          </AskSageProvider>
        </AiConfigProvider>
      </UserPreferencesProvider>
    </MemoryRouter>,
  );
}

const tab = (name: RegExp) => screen.getByRole("tab", { name });
const save = () => fireEvent.click(screen.getByRole("button", { name: /save/i }));

beforeEach(() => {
  _resetModelsForTests();
  // Keep startup discovery offline; tests seed the cache directly
  vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new TypeError("Failed to fetch")));
});

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("Settings → AI Endpoints tabs", () => {
  it("opens on the endpoint in use, marked In use", () => {
    localStorage.setItem(ACTIVE_ENDPOINT_KEY, "cui");
    renderSettings();
    expect(tab(/CUI \(IL5\)/)).toHaveAttribute("aria-selected", "true");
    expect(within(tab(/CUI \(IL5\)/)).getByText("In use")).toBeInTheDocument();
    expect(within(tab(/Proprietary/)).queryByText("In use")).not.toBeInTheDocument();
    expect(screen.getByTestId("endpoint-in-use")).toHaveTextContent("AI requests use: CUI (IL5)");
  });

  it("viewing and editing another endpoint's models does not switch the endpoint in use", () => {
    setDiscoveredModels("cui", [CUI_STANDARD, CUI_NEWER]);
    renderSettings();
    fireEvent.click(tab(/CUI \(IL5\)/));
    expect(screen.getByText("Models for CUI (IL5)")).toBeInTheDocument();
    fireEvent.change(screen.getByLabelText("Standard"), { target: { value: CUI_NEWER } });
    save();
    expect(localStorage.getItem(ACTIVE_ENDPOINT_KEY)).toBe("non-cui");
    expect(getModelOverrides("cui").standard).toBe(CUI_NEWER);
    expect(getModelOverrides("non-cui").standard).toBeUndefined();
  });

  it("'Use this endpoint' switches the endpoint in use on Save", () => {
    renderSettings();
    fireEvent.click(tab(/CUI \(IL5\)/));
    fireEvent.click(screen.getByRole("button", { name: "Use this endpoint for AI requests" }));
    expect(screen.getByText("✓ AI requests use this endpoint")).toBeInTheDocument();
    expect(within(tab(/CUI \(IL5\)/)).getByText("In use")).toBeInTheDocument();
    save();
    expect(localStorage.getItem(ACTIVE_ENDPOINT_KEY)).toBe("cui");
  });

  it("keys belong to their own tab and survive switching tabs", () => {
    localStorage.setItem(apiKeyStorageKey("non-cui"), "il2-key");
    renderSettings();
    fireEvent.click(tab(/CUI \(IL5\)/));
    fireEvent.change(screen.getByLabelText("CUI (IL5) API Key"), { target: { value: "il5-key" } });
    fireEvent.click(tab(/Proprietary/));
    expect(screen.getByLabelText("Proprietary (IL2) API Key")).toHaveValue("il2-key");
    fireEvent.click(tab(/CUI \(IL5\)/));
    expect(screen.getByLabelText("CUI (IL5) API Key")).toHaveValue("il5-key");
    save();
    expect(localStorage.getItem(apiKeyStorageKey("cui"))).toBe("il5-key");
    expect(localStorage.getItem(apiKeyStorageKey("non-cui"))).toBe("il2-key");
  });

  it("flags tabs without a key and warns when the endpoint in use has none", () => {
    localStorage.setItem(apiKeyStorageKey("cui"), "il5-key");
    renderSettings();
    expect(within(tab(/Proprietary/)).getByText("No key")).toBeInTheDocument();
    expect(within(tab(/CUI \(IL5\)/)).queryByText("No key")).not.toBeInTheDocument();
    expect(screen.getByRole("note")).toHaveTextContent("Proprietary (IL2) is in use but has no API key");

    fireEvent.change(screen.getByLabelText("Proprietary (IL2) API Key"), { target: { value: "il2-key" } });
    expect(screen.queryByRole("note")).not.toBeInTheDocument();
  });

  it("shows a migrated legacy key on the very first load", () => {
    localStorage.setItem(LEGACY_API_KEY_STORAGE, "legacy-key");
    renderSettings();
    expect(screen.getByLabelText("Proprietary (IL2) API Key")).toHaveValue("legacy-key");
    expect(within(tab(/Proprietary/)).queryByText("No key")).not.toBeInTheDocument();
    expect(screen.queryByRole("note")).not.toBeInTheDocument();
  });

  it("marks tabs with custom models", () => {
    setDiscoveredModels("cui", [CUI_STANDARD, CUI_NEWER]);
    renderSettings();
    expect(within(tab(/CUI \(IL5\)/)).queryByLabelText("custom models")).not.toBeInTheDocument();
    fireEvent.click(tab(/CUI \(IL5\)/));
    fireEvent.change(screen.getByLabelText("Standard"), { target: { value: CUI_NEWER } });
    expect(within(tab(/CUI \(IL5\)/)).getByLabelText("custom models")).toBeInTheDocument();
  });

  it("arrow keys move between tabs", () => {
    renderSettings();
    fireEvent.keyDown(tab(/Proprietary/), { key: "ArrowRight" });
    expect(tab(/CUI \(IL5\)/)).toHaveAttribute("aria-selected", "true");
    expect(tab(/CUI \(IL5\)/)).toHaveFocus();
    fireEvent.keyDown(tab(/CUI \(IL5\)/), { key: "ArrowLeft" });
    expect(tab(/Proprietary/)).toHaveAttribute("aria-selected", "true");
  });
});
