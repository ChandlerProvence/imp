import type { ManifestDiff } from "../../schemas/fieldManifest";

/** Fields added, removed, or retyped by replacing a custom template. */
export default function DiffSummary({ diff }: { diff: ManifestDiff }) {
  if (diff.added.length + diff.removed.length + diff.retyped.length === 0) {
    return <p className="mt-1 text-xs text-gray-500">The fields are unchanged.</p>;
  }
  return (
    <ul className="mt-1 space-y-0.5 text-xs">
      {diff.added.length > 0 && <li className="text-green-700">Added: {diff.added.join(", ")}</li>}
      {diff.removed.length > 0 && (
        <li className="text-red-700">Removed (saved answers for these are ignored): {diff.removed.join(", ")}</li>
      )}
      {diff.retyped.length > 0 && <li className="text-amber-700">Changed type: {diff.retyped.join(", ")}</li>}
    </ul>
  );
}
