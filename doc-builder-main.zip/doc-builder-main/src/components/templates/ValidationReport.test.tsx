import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import ValidationReport, { formatReportForAssistant } from "./ValidationReport";
import { ISSUE_CATALOG } from "../../schemas/issueCatalog";
import type { Issue } from "../../schemas/templateScan";

const issues: Issue[] = [
  { severity: "error", code: "tag-unmapped", message: "Template tag {{MYSTERY}} is not in template_key_map." },
  { severity: "warning", code: "hints-stripped", message: "Removed 1 inline hint(s)." },
];

describe("ValidationReport", () => {
  it("shows the catalog fix under each error", () => {
    render(<ValidationReport issues={issues} />);
    expect(screen.getByText(`Fix: ${ISSUE_CATALOG["tag-unmapped"].fix}`)).toBeInTheDocument();
  });

  it("copies errors with their fixes for an AI assistant", async () => {
    const writeText = vi.fn().mockResolvedValue(undefined);
    Object.assign(navigator, { clipboard: { writeText } });
    render(<ValidationReport issues={issues} />);
    fireEvent.click(screen.getByRole("button", { name: "Copy for your AI assistant" }));
    await waitFor(() => expect(writeText).toHaveBeenCalledWith(formatReportForAssistant(issues)));
    const text = writeText.mock.calls[0][0] as string;
    expect(text).toContain("tag-unmapped: Template tag {{MYSTERY}}");
    expect(text).toContain(`Fix: ${ISSUE_CATALOG["tag-unmapped"].fix}`);
    expect(text).not.toContain("hints-stripped"); // warnings aren't sent
    expect(await screen.findByRole("button", { name: "Copied" })).toBeInTheDocument();
  });

  it("falls back to selectable text when the clipboard is blocked", async () => {
    Object.assign(navigator, { clipboard: { writeText: vi.fn().mockRejectedValue(new Error("denied")) } });
    render(<ValidationReport issues={issues} />);
    fireEvent.click(screen.getByRole("button", { name: "Copy for your AI assistant" }));
    expect(await screen.findByLabelText("Report to copy")).toHaveValue(formatReportForAssistant(issues));
  });
});
