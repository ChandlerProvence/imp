import { useState } from "react";
import { Link } from "react-router-dom";

const dismissKey = (schemaId: string) => `doc-builder:custom-banner-dismissed:${schemaId}`;

/**
 * Reminder shown while filling in a custom template: only this browser has
 * it, so nudge toward submitting it for team use. Dismissal lasts for the tab.
 */
export default function CustomTemplateBanner({ schemaId }: { schemaId: string }) {
  const [dismissed, setDismissed] = useState(() => sessionStorage.getItem(dismissKey(schemaId)) === "1");
  if (dismissed) return null;

  return (
    <div className="flex items-center gap-3 border-b border-amber-200 bg-amber-50 px-4 py-2 text-sm text-amber-900" role="note">
      <span className="flex-1">
        You're using a <strong>custom template</strong> that only exists in this browser.{" "}
        <Link to="/templates" className="underline hover:text-amber-700">
          Submit it for team use
        </Link>{" "}
        so everyone's documents match.
      </span>
      <button
        type="button"
        aria-label="Dismiss"
        onClick={() => {
          sessionStorage.setItem(dismissKey(schemaId), "1");
          setDismissed(true);
        }}
        className="text-amber-700 hover:text-amber-900"
      >
        ✕
      </button>
    </div>
  );
}
