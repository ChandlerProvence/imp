import { useState } from "react";
import type { Issue } from "../../schemas/templateScan";
import { fixFor } from "../../schemas/issueCatalog";

/** Text a user pastes back into the chatbot that edited their template. */
export function formatReportForAssistant(issues: Issue[]): string {
  return [
    "My template upload to Doc Builder failed with the problems below. Fix the schema and/or Word template " +
      "following the Doc Builder template authoring guide, then return the complete schema JSON and the exact Word changes.",
    "",
    ...issues
      .filter((i) => i.severity === "error")
      .map((i) => `- ${i.code}: ${i.message}\n  Fix: ${fixFor(i.code)}`),
  ].join("\n");
}

/** Upload validation results, errors first, each with how to fix it. */
export default function ValidationReport({ issues }: { issues: Issue[] }) {
  const [copied, setCopied] = useState(false);
  const [showText, setShowText] = useState(false);
  const errors = issues.filter((i) => i.severity === "error");
  const warnings = issues.filter((i) => i.severity === "warning");
  if (issues.length === 0) return null;

  async function copy() {
    try {
      await navigator.clipboard.writeText(formatReportForAssistant(issues));
      setCopied(true);
    } catch {
      setShowText(true); // Clipboard blocked — show text to copy by hand
    }
  }

  return (
    <div className="space-y-3 text-sm" data-testid="validation-report">
      {errors.length > 0 && (
        <div className="rounded-md border border-red-200 bg-red-50 p-3">
          <div className="flex items-start justify-between gap-3">
            <p className="font-medium text-red-800">
              {errors.length} problem{errors.length === 1 ? "" : "s"} must be fixed before this template can be added
            </p>
            <button
              type="button"
              onClick={() => void copy()}
              className="shrink-0 rounded-md border border-red-300 bg-white px-2 py-1 text-xs font-medium text-red-700 hover:bg-red-100"
            >
              {copied ? "Copied" : "Copy for your AI assistant"}
            </button>
          </div>
          <ul className="mt-2 list-disc space-y-1.5 pl-5 text-red-700">
            {errors.map((i, n) => (
              <li key={n}>
                {i.message} <span className="text-xs text-red-400">({i.code})</span>
                <span className="block text-xs text-red-600">Fix: {fixFor(i.code)}</span>
              </li>
            ))}
          </ul>
          {showText && (
            <textarea
              readOnly
              aria-label="Report to copy"
              value={formatReportForAssistant(issues)}
              onFocus={(e) => e.currentTarget.select()}
              className="mt-2 h-32 w-full rounded border border-red-200 p-2 font-mono text-xs"
            />
          )}
        </div>
      )}
      {warnings.length > 0 && (
        <div className="rounded-md border border-amber-200 bg-amber-50 p-3">
          <p className="font-medium text-amber-800">
            {warnings.length} warning{warnings.length === 1 ? "" : "s"}
          </p>
          <ul className="mt-2 list-disc space-y-1 pl-5 text-amber-700">
            {warnings.map((i, n) => (
              <li key={n}>{i.message}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
