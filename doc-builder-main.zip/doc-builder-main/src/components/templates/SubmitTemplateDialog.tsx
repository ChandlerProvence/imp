import { useEffect, useState } from "react";
import type { UserTemplate } from "../../db/types";
import { isBuiltInSchema, schemaList } from "../../schemas/loader";
import { CONTACT_EMAIL, CONTACT_NAME } from "../../config/contact";
import { bundleFilename, downloadUserTemplate } from "../../schemas/userTemplateBundle";
import {
  buildSubmissionMailto,
  buildSubmissionMessage,
  formatSubmissionMessage,
  formatSubmissionNotes,
  type SubmissionForm,
} from "../../schemas/templateSubmission";
import { markSubmitted } from "../../schemas/userSchemas";

interface Props {
  template: UserTemplate | null;
  onClose: () => void;
}

/**
 * Send a custom template to the developers so it can become a built-in that
 * everyone uses: downloads the bundle, then either opens a prefilled email or
 * copies the message so the user can paste it and attach the bundle by hand.
 */
export default function SubmitTemplateDialog({ template, onClose }: Props) {
  const [form, setForm] = useState<SubmissionForm>({ purpose: "", users: "", urgency: "normal" });
  const [sentVia, setSentVia] = useState<"email" | "copy" | null>(null);
  const [copied, setCopied] = useState<boolean | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (template) {
      setForm({ purpose: "", users: "", urgency: "normal", basedOn: template.basedOn });
      setSentVia(null);
      setCopied(null);
      setError(null);
    }
  }, [template]);

  if (!template) return null;

  const builtIns = schemaList.filter((s) => isBuiltInSchema(s.id));
  const message = buildSubmissionMessage(template, form);
  const messageText = formatSubmissionMessage(message);
  const filename = bundleFilename(template.originalId);

  async function copyMessage() {
    try {
      await navigator.clipboard.writeText(messageText);
      setCopied(true);
    } catch {
      setCopied(false); // Clipboard blocked — the text box below stays selectable
    }
  }

  async function submit(via: "email" | "copy") {
    if (!template) return;
    setError(null);
    const submission = {
      notes: formatSubmissionNotes(form),
      ...(form.basedOn ? { basedOn: form.basedOn } : {}),
      submittedAt: new Date().toISOString(),
    };
    try {
      const saved = await downloadUserTemplate(template, submission);
      if (!saved) return; // Cancelled the save dialog
      await markSubmitted(template.id, submission);
      if (via === "email") {
        window.location.href = buildSubmissionMailto(message);
      } else {
        await copyMessage();
      }
      setSentVia(via);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Couldn't prepare the submission.");
    }
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="submit-template-title"
        className="relative w-full max-w-lg rounded-lg bg-white p-6 shadow-xl"
      >
        <h2 id="submit-template-title" className="text-lg font-semibold text-gray-900">
          Submit “{template.schema.title}” for team use
        </h2>

        {sentVia ? (
          <div className="mt-3 space-y-3 text-sm text-gray-700">
            {sentVia === "email" ? (
              <p>
                Your email app should now be open with a message to {CONTACT_NAME}. <strong>Attach the file you just
                saved</strong> (<code>{filename}</code>) and send it.
              </p>
            ) : null}
            <div className={sentVia === "email" ? "rounded-md border border-gray-200 bg-gray-50 p-3" : ""}>
              {sentVia === "email" && (
                <p className="mb-2 font-medium text-gray-700">Email app didn't open? Send it yourself:</p>
              )}
              <ol className="list-decimal space-y-1 pl-5">
                <li>
                  {sentVia === "copy" && copied ? "The message is copied. " : "Copy the message below. "}
                  Start a new email to{" "}
                  <a className="text-blue-600 underline" href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</a> and paste it.
                </li>
                <li>
                  <strong>Attach the file you just saved</strong>, <code>{filename}</code> (usually in your Downloads
                  folder).
                </li>
                <li>Send it.</li>
              </ol>
              <div className="mt-3">
                <div className="mb-1 flex items-center justify-between">
                  <span className="text-xs font-medium text-gray-500">Message</span>
                  <button
                    type="button"
                    onClick={() => void copyMessage()}
                    className="rounded-md border border-gray-300 bg-white px-2 py-1 text-xs font-medium text-gray-700 hover:bg-gray-50"
                  >
                    {copied ? "Copied" : "Copy message"}
                  </button>
                </div>
                <textarea
                  readOnly
                  value={messageText}
                  rows={8}
                  aria-label="Submission message"
                  onFocus={(e) => e.currentTarget.select()}
                  className="w-full rounded-md border border-gray-300 bg-white px-3 py-2 font-mono text-xs text-gray-700"
                />
                {copied === false && (
                  <p className="mt-1 text-xs text-amber-700">
                    Your browser blocked copying. Click in the box, press Ctrl+A, then Ctrl+C.
                  </p>
                )}
              </div>
            </div>
            <p className="text-gray-500">
              Once it's added to Doc Builder, you'll be offered to switch your documents to the official version.
            </p>
            <div className="flex justify-end">
              <button
                type="button"
                onClick={onClose}
                className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
              >
                Done
              </button>
            </div>
          </div>
        ) : (
          <>
            <p className="mt-1 text-sm text-gray-600">
              Custom templates only exist in your browser. Submitting one lets the developers add it to Doc Builder so
              everyone produces documents the same way.
            </p>
            <div className="mt-4 space-y-3 text-sm">
              <label className="block">
                <span className="font-medium text-gray-700">What is it for?</span>
                <textarea
                  value={form.purpose}
                  onChange={(e) => setForm({ ...form, purpose: e.target.value })}
                  rows={3}
                  className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2"
                  placeholder="e.g. Repair quotes for the Shipping Hub team, replaces the emailed Word form"
                />
              </label>
              <label className="block">
                <span className="font-medium text-gray-700">Based on a built-in template?</span>
                <select
                  value={form.basedOn ?? ""}
                  onChange={(e) => setForm({ ...form, basedOn: e.target.value || undefined })}
                  className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2"
                >
                  <option value="">No — it's new</option>
                  {builtIns.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.title}
                    </option>
                  ))}
                </select>
              </label>
              <label className="block">
                <span className="font-medium text-gray-700">Who uses it?</span>
                <input
                  value={form.users}
                  onChange={(e) => setForm({ ...form, users: e.target.value })}
                  className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2"
                  placeholder="Team or role"
                />
              </label>
              <label className="block">
                <span className="font-medium text-gray-700">How soon is it needed?</span>
                <select
                  value={form.urgency}
                  onChange={(e) => setForm({ ...form, urgency: e.target.value as SubmissionForm["urgency"] })}
                  className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2"
                >
                  <option value="low">No rush</option>
                  <option value="normal">Normal</option>
                  <option value="high">Blocking our work</option>
                </select>
              </label>
            </div>
            {error && <p className="mt-3 text-sm text-red-600">{error}</p>}
            <div className="mt-6 flex justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={!form.purpose.trim()}
                onClick={() => void submit("copy")}
                className="rounded-md border border-blue-300 bg-white px-4 py-2 text-sm font-medium text-blue-700 hover:bg-blue-50 disabled:cursor-not-allowed disabled:opacity-50"
              >
                Save bundle &amp; copy message
              </button>
              <button
                type="button"
                disabled={!form.purpose.trim()}
                onClick={() => void submit("email")}
                className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-50"
              >
                Save bundle &amp; open email
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
