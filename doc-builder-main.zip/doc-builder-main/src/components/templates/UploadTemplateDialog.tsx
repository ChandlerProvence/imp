import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useFileDrop } from "../ai-panel/useFileDrop";
import ValidationReport from "./ValidationReport";
import DiffSummary from "./DiffSummary";
import type { Issue } from "../../schemas/templateScan";
import type { PreparedTemplate } from "../../schemas/userTemplateValidation";
import { validateUserTemplateFiles } from "../../schemas/userTemplateValidation";
import { parseBundleText, MAX_BUNDLE_BYTES } from "../../schemas/userTemplateBundle";
import { installTemplate, countSessionsForSchema } from "../../schemas/userSchemas";
import { getUserTemplate } from "../../db/userTemplates";
import { buildFieldManifest, diffFieldManifests, type ManifestDiff } from "../../schemas/fieldManifest";
import type { UserTemplate } from "../../db/types";
import { createDraftFromDocx } from "../../schemas/templateDrafts";
import { toAppError, type AppError } from "../../errors";
import AppErrorBox from "../AppErrorBox";

interface Props {
  open: boolean;
  onClose: () => void;
  onInstalled: (record: UserTemplate, replaced: boolean) => void;
}

interface Checked {
  issues: Issue[];
  prepared?: PreparedTemplate;
  basedOn?: string;
  /** From a bundle someone else made, not the user's own files. */
  fromBundle: boolean;
  existing?: UserTemplate;
  sessionsUsing: number;
  diff?: ManifestDiff;
}

type Slot = "docx" | "schema" | "bundle";
type Slots = Partial<Record<Slot, File>>;

/** Building a draft schema from a .docx added on its own. */
type Build = { step: "idle" } | { step: "building" } | { step: "rejected"; issues: Issue[] } | { step: "error"; error: AppError };

/**
 * Add or replace a custom template from a .schema.json + .docx pair or a
 * template bundle. Validates before anything is stored. A .docx on its own
 * can instead become a draft whose schema is built from its tags.
 */
export default function UploadTemplateDialog({ open, onClose, onInstalled }: Props) {
  const [slots, setSlots] = useState<Slots>({});
  const [busy, setBusy] = useState(false);
  const [checked, setChecked] = useState<Checked | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [build, setBuild] = useState<Build>({ step: "idle" });
  const navigate = useNavigate();
  // Ignores results from an earlier check when files change mid-validation
  const checkRun = useRef(0);

  useEffect(() => {
    if (!open) {
      setSlots({});
      setChecked(null);
      setMessage(null);
      setBusy(false);
      setBuild({ step: "idle" });
      checkRun.current++;
    }
  }, [open]);

  useEffect(() => {
    if (!open) return;
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
    }
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  /**
   * Files go to the slot matching what they are, whichever zone they were
   * dropped on, so dropping the pair together (or a bundle on the schema
   * zone) still works. A bundle and a file pair are alternatives.
   */
  async function addFiles(incoming: File[]) {
    const next: Slots = { ...slots };
    let rejected: string | null = null;
    for (const file of incoming) {
      const slot = await slotFor(file);
      if (!slot) {
        rejected = file.name;
        continue;
      }
      if (slot === "bundle") {
        delete next.docx;
        delete next.schema;
      } else {
        delete next.bundle;
      }
      next[slot] = file;
    }
    setSlots(next);
    await check(next, rejected ? `"${rejected}" isn't a Word template (.docx) or a .json file.` : null);
  }

  async function removeFile(slot: Slot) {
    const next = { ...slots };
    delete next[slot];
    setSlots(next);
    await check(next, null);
  }

  async function check(current: Slots, notice: string | null) {
    const run = ++checkRun.current;
    setChecked(null);
    setMessage(notice);
    setBuild({ step: "idle" });
    const { docx, schema, bundle } = current;
    if (!bundle && !(docx && schema)) {
      setBusy(false);
      return;
    }

    setBusy(true);
    try {
      let result: { issues: Issue[]; prepared?: PreparedTemplate };
      let basedOn: string | undefined;
      let fromBundle = false;
      if (bundle) {
        fromBundle = true;
        const parsed = await parseBundleText(await bundle.text());
        result = parsed.validation;
        basedOn = parsed.embedded?.basedOn;
      } else {
        result = await validateUserTemplateFiles(schema!, docx!);
      }

      let existing: UserTemplate | undefined;
      let sessionsUsing = 0;
      let diff: ManifestDiff | undefined;
      if (result.prepared) {
        existing = await getUserTemplate(result.prepared.id);
        if (existing) {
          sessionsUsing = await countSessionsForSchema(existing.id);
          diff = diffFieldManifests(buildFieldManifest(existing.schema), buildFieldManifest(result.prepared.schema));
        }
      }
      if (run !== checkRun.current) return;
      setChecked({ issues: result.issues, prepared: result.prepared, basedOn, fromBundle, existing, sessionsUsing, diff });
    } catch (e) {
      if (run !== checkRun.current) return;
      setMessage(`Couldn't read the files: ${e instanceof Error ? e.message : e}`);
    } finally {
      if (run === checkRun.current) setBusy(false);
    }
  }

  async function buildFromTags() {
    if (!slots.docx) return;
    setBuild({ step: "building" });
    try {
      const result = await createDraftFromDocx(slots.docx);
      if (!result.ok) {
        setBuild({ step: "rejected", issues: result.issues });
        return;
      }
      onClose();
      navigate(`/templates/edit/${result.draft.id}`);
    } catch (e) {
      setBuild({ step: "error", error: toAppError(e, { domain: "db" }) });
    }
  }

  async function install() {
    if (!checked?.prepared) return;
    setBusy(true);
    try {
      const record = await installTemplate(checked.prepared, { basedOn: checked.basedOn });
      onInstalled(record, !!checked.existing);
    } catch (e) {
      setMessage(`Couldn't save the template: ${e instanceof Error ? e.message : e}`);
      setBusy(false);
    }
  }

  if (!open) return null;

  const prepared = checked?.prepared;
  const fieldCount = prepared?.schema.sections.reduce((n, s) => n + s.fields.length, 0) ?? 0;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="upload-template-title"
        className="relative flex max-h-[90vh] w-full max-w-xl flex-col rounded-lg bg-white shadow-xl"
      >
        <div className="border-b border-gray-200 px-6 py-4">
          <h2 id="upload-template-title" className="text-lg font-semibold text-gray-900">
            Add a custom template
          </h2>
          <p className="mt-1 text-sm text-gray-600">
            Add a Word file with {"{{TAGS}}"} and Doc Builder builds its schema for you. You can also add a Word
            template with its schema, or a template bundle someone shared with you.{" "}
            <a
              className="text-blue-600 underline"
              href={`${import.meta.env.BASE_URL}docs/help/template-editor`}
              target="_blank"
              rel="noreferrer"
            >
              How it works
            </a>
          </p>
        </div>

        <div className="flex-1 space-y-4 overflow-y-auto px-6 py-4">
          <div>
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-gray-500">Your files</h3>
            <div className="grid grid-cols-2 gap-3">
              <FileZone
                label="Word template"
                hint=".docx"
                accept=".docx"
                testId="template-docx-input"
                file={slots.docx}
                onFiles={(f) => void addFiles(f)}
                onRemove={() => void removeFile("docx")}
              />
              <FileZone
                label="Schema"
                hint=".schema.json"
                accept=".json"
                testId="template-schema-input"
                file={slots.schema}
                onFiles={(f) => void addFiles(f)}
                onRemove={() => void removeFile("schema")}
              />
            </div>
            {slots.docx && !slots.schema && (
              <div className="mt-3 space-y-2 rounded-md border border-blue-200 bg-blue-50 p-3 text-sm text-blue-900" role="status">
                <p>
                  No schema yet? Doc Builder can build one from the {"{{TAGS}}"} in your Word file. You'll check the
                  labels and types before it's added.
                </p>
                <button
                  type="button"
                  disabled={build.step === "building"}
                  onClick={() => void buildFromTags()}
                  className="rounded-md bg-blue-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {build.step === "building" ? "Building…" : "Build the schema from the tags"}
                </button>
                <p className="text-xs text-blue-800">Already have a schema? Add its .schema.json to check it as is.</p>
              </div>
            )}
            {slots.schema && !slots.docx && (
              <p className="mt-2 text-sm text-gray-700" role="status">
                Schema added. Now add its Word template (.docx) to check the template.
              </p>
            )}
            {build.step === "rejected" && (
              <div className="mt-3">
                <ValidationReport issues={build.issues} />
              </div>
            )}
            {build.step === "error" && <AppErrorBox error={build.error} className="mt-3" />}
          </div>

          <div className="flex items-center gap-3 text-xs uppercase tracking-wide text-gray-400">
            <span className="h-px flex-1 bg-gray-200" />
            or
            <span className="h-px flex-1 bg-gray-200" />
          </div>

          <FileZone
            label="Template bundle"
            hint=".template-bundle.json — a template someone shared with you"
            accept=".json"
            testId="template-bundle-input"
            file={slots.bundle}
            onFiles={(f) => void addFiles(f)}
            onRemove={() => void removeFile("bundle")}
          />

          {busy && <p className="text-sm text-gray-500">Checking the template…</p>}
          {message && <p className="text-sm text-gray-700">{message}</p>}

          {checked && <ValidationReport issues={checked.issues} />}

          {prepared && (
            <div className="rounded-md border border-gray-200 bg-gray-50 p-3 text-sm text-gray-700">
              <p className="font-medium text-gray-900">{prepared.schema.title}</p>
              <p className="text-xs text-gray-500">
                {prepared.schema.sections.length} sections · {fieldCount} fields · id {prepared.originalId}
              </p>
              {checked?.existing && (
                <div className="mt-2 border-t border-gray-200 pt-2">
                  <p>
                    This replaces your current version (revision {checked.existing.revision}).{" "}
                    {checked.sessionsUsing > 0
                      ? `${checked.sessionsUsing} saved document${checked.sessionsUsing === 1 ? "" : "s"} use it and will switch to the new version.`
                      : "No saved documents use it."}
                  </p>
                  {checked.diff && <DiffSummary diff={checked.diff} />}
                </div>
              )}
            </div>
          )}

          {checked?.fromBundle && prepared && (
            <p className="rounded-md border border-blue-200 bg-blue-50 p-3 text-sm text-blue-800">
              This template came from a file, not from Doc Builder. Its field hints are sent to the AI assistant —
              review the template before relying on it.
            </p>
          )}
        </div>

        <div className="flex justify-end gap-3 border-t border-gray-200 px-6 py-4">
          <button
            type="button"
            onClick={onClose}
            className="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={!prepared || busy}
            onClick={() => void install()}
            className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {checked?.existing ? "Replace template" : "Add template"}
          </button>
        </div>
      </div>
    </div>
  );
}

interface FileZoneProps {
  label: string;
  hint: string;
  accept: string;
  testId: string;
  file?: File;
  onFiles: (files: File[]) => void;
  onRemove: () => void;
}

/** One drop zone with a checkmark once its file is added. */
function FileZone({ label, hint, accept, testId, file, onFiles, onRemove }: FileZoneProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const { dragOver, dropHandlers } = useFileDrop(onFiles);
  const browse = () => inputRef.current?.click();

  return (
    <div
      {...dropHandlers}
      onClick={browse}
      className={`flex cursor-pointer items-start gap-2 rounded-md border-2 px-3 py-3 text-sm transition-colors ${
        dragOver
          ? "border-dashed border-blue-400 bg-blue-50"
          : file
            ? "border-solid border-green-300 bg-green-50"
            : "border-dashed border-gray-300 hover:border-gray-400"
      }`}
    >
      <span
        aria-label={file ? `${label} added` : `${label} not added`}
        role="img"
        className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-xs font-bold ${
          file ? "bg-green-600 text-white" : "border-2 border-gray-300"
        }`}
      >
        {file ? "✓" : ""}
      </span>
      <div className="min-w-0 flex-1">
        <p className="font-medium text-gray-900">{label}</p>
        {file ? (
          <p className="truncate text-xs text-gray-600" title={file.name}>
            {file.name}
          </p>
        ) : (
          <p className="text-xs text-gray-500">{hint}</p>
        )}
        <div className="mt-1 flex gap-3 text-xs">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              browse();
            }}
            className="font-medium text-blue-600 hover:text-blue-800"
          >
            {file ? "Replace…" : "Drop here or browse…"}
          </button>
          {file && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onRemove();
              }}
              className="text-gray-500 hover:text-red-600"
              aria-label={`Remove ${label.toLowerCase()}`}
            >
              Remove
            </button>
          )}
        </div>
      </div>
      <input
        ref={inputRef}
        type="file"
        accept={accept}
        multiple
        className="hidden"
        data-testid={testId}
        onClick={(e) => e.stopPropagation()}
        onChange={(e) => {
          const selected = Array.from(e.target.files ?? []);
          e.target.value = "";
          if (selected.length > 0) onFiles(selected);
        }}
      />
    </div>
  );
}

async function slotFor(file: File): Promise<Slot | null> {
  const name = file.name.toLowerCase();
  if (name.endsWith(".docx")) return "docx";
  if (!name.endsWith(".json")) return null;
  const head = file.size <= MAX_BUNDLE_BYTES ? await file.slice(0, 2000).text() : "";
  return looksLikeBundle(head) ? "bundle" : "schema";
}

function looksLikeBundle(text: string): boolean {
  return /"_type"\s*:\s*"doc-builder-template-bundle"/.test(text.slice(0, 2000));
}
