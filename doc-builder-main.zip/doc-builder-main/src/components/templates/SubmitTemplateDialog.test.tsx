import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import SubmitTemplateDialog from "./SubmitTemplateDialog";
import type { UserTemplate } from "../../db/types";
import { CONTACT_EMAIL } from "../../config/contact";

const downloadUserTemplate = vi.fn();
const markSubmitted = vi.fn();

vi.mock("../../schemas/userTemplateBundle", async (importOriginal) => ({
  ...(await importOriginal<typeof import("../../schemas/userTemplateBundle")>()),
  downloadUserTemplate: (...args: unknown[]) => downloadUserTemplate(...args),
}));
vi.mock("../../schemas/userSchemas", async (importOriginal) => ({
  ...(await importOriginal<typeof import("../../schemas/userSchemas")>()),
  markSubmitted: (...args: unknown[]) => markSubmitted(...args),
}));

const template: UserTemplate = {
  id: "custom-vendor-letter",
  originalId: "vendor-letter",
  schema: { id: "custom-vendor-letter", title: "Vendor Letter", version: 1, sections: [] } as unknown as UserTemplate["schema"],
  docx: new ArrayBuffer(0),
  docxSha256: "abc",
  revision: 2,
  createdAt: "2026-10-01T00:00:00Z",
  updatedAt: "2026-10-01T00:00:00Z",
};

const writeText = vi.fn();

beforeEach(() => {
  downloadUserTemplate.mockReset().mockResolvedValue(true);
  markSubmitted.mockReset().mockResolvedValue(undefined);
  writeText.mockReset().mockResolvedValue(undefined);
  Object.defineProperty(navigator, "clipboard", { value: { writeText }, configurable: true });
});

function fillPurpose() {
  fireEvent.change(screen.getByPlaceholderText(/Repair quotes/), { target: { value: "Vendor outreach" } });
}

describe("SubmitTemplateDialog", () => {
  it("saves the bundle and copies the message with attach instructions", async () => {
    render(<SubmitTemplateDialog template={template} onClose={() => {}} />);
    fillPurpose();
    fireEvent.click(screen.getByRole("button", { name: "Save bundle & copy message" }));

    await waitFor(() => expect(writeText).toHaveBeenCalledTimes(1));
    const copied = writeText.mock.calls[0][0] as string;
    expect(copied).toContain(`To: ${CONTACT_EMAIL}`);
    expect(copied).toContain("Subject: [Doc Builder] Template submission: Vendor Letter");
    expect(copied).toContain("Purpose: Vendor outreach");

    expect(downloadUserTemplate).toHaveBeenCalledTimes(1);
    expect(markSubmitted).toHaveBeenCalledWith("custom-vendor-letter", expect.objectContaining({ submittedAt: expect.any(String) }));
    expect(screen.getByText(/The message is copied/)).toBeInTheDocument();
    expect(screen.getByText("vendor-letter.template-bundle.json")).toBeInTheDocument();
    expect(screen.getByLabelText("Submission message")).toHaveValue(copied);
    expect(screen.getByRole("button", { name: "Copied" })).toBeInTheDocument();
  });

  it("falls back to the selectable text box when the clipboard is blocked", async () => {
    writeText.mockRejectedValue(new DOMException("denied", "NotAllowedError"));
    render(<SubmitTemplateDialog template={template} onClose={() => {}} />);
    fillPurpose();
    fireEvent.click(screen.getByRole("button", { name: "Save bundle & copy message" }));

    expect(await screen.findByText(/browser blocked copying/)).toBeInTheDocument();
    expect((screen.getByLabelText("Submission message") as HTMLTextAreaElement).value).toContain("Vendor Letter");
    expect(screen.getByRole("button", { name: "Copy message" })).toBeInTheDocument();
  });

  it("does nothing when the save dialog is cancelled", async () => {
    downloadUserTemplate.mockResolvedValue(false);
    render(<SubmitTemplateDialog template={template} onClose={() => {}} />);
    fillPurpose();
    fireEvent.click(screen.getByRole("button", { name: "Save bundle & copy message" }));

    await waitFor(() => expect(downloadUserTemplate).toHaveBeenCalled());
    expect(markSubmitted).not.toHaveBeenCalled();
    expect(writeText).not.toHaveBeenCalled();
    expect(screen.getByRole("button", { name: "Save bundle & copy message" })).toBeInTheDocument();
  });

  it("offers the copy fallback after opening email", async () => {
    render(<SubmitTemplateDialog template={template} onClose={() => {}} />);
    fillPurpose();
    fireEvent.click(screen.getByRole("button", { name: "Save bundle & open email" }));

    expect(await screen.findByText(/Email app didn't open/)).toBeInTheDocument();
    expect(writeText).not.toHaveBeenCalled();
    fireEvent.click(screen.getByRole("button", { name: "Copy message" }));
    await waitFor(() => expect(writeText).toHaveBeenCalledTimes(1));
  });
});
