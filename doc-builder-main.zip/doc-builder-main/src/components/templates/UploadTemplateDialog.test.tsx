import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { MemoryRouter, Route, Routes, useParams } from "react-router-dom";
import UploadTemplateDialog from "./UploadTemplateDialog";
import { db } from "../../db/dexie";
import { getSchema } from "../../schemas/loader";
import { reloadUserSchemas } from "../../schemas/userSchemas";
import { getTemplateDraft } from "../../db/templateDrafts";
import { buildDocx, para } from "../../test/docxFixtures";

const schema = {
  id: "vendor-letter",
  title: "Vendor Letter",
  version: 1,
  docx_template: "x.docx",
  sections: [{ id: "main", title: "Main", fields: [{ id: "vendor", label: "Vendor", type: "string", required: true }] }],
  template_key_map: { VENDOR: "main.vendor" },
};

const schemaFile = (s: unknown = schema) => new File([JSON.stringify(s)], "vendor-letter.schema.json", { type: "application/json" });
const docxFile = (text = "Dear {{VENDOR}}") =>
  new File([buildDocx(para(text)) as BlobPart], "vendor-letter.docx");

type Zone = "docx" | "schema" | "bundle";

function upload(files: File[], zone: Zone = "schema") {
  fireEvent.change(screen.getByTestId(`template-${zone}-input`), { target: { files } });
}

function EditorStub() {
  return <p>Editing {useParams().id}</p>;
}

/** The dialog navigates to the editor after building a draft. */
function renderDialog(ui: React.ReactElement) {
  return render(
    <MemoryRouter initialEntries={["/templates"]}>
      <Routes>
        <Route path="/templates" element={ui} />
        <Route path="/templates/edit/:id" element={<EditorStub />} />
      </Routes>
    </MemoryRouter>,
  );
}

beforeEach(async () => {
  await db.userTemplates.clear();
  await db.templateDrafts.clear();
  await reloadUserSchemas();
});

describe("UploadTemplateDialog", () => {
  it("validates a pair and installs it", async () => {
    const onInstalled = vi.fn();
    renderDialog(<UploadTemplateDialog open onClose={() => {}} onInstalled={onInstalled} />);

    upload([schemaFile()], "schema");
    expect(await screen.findByText(/Now add its Word template/i)).toBeInTheDocument();

    upload([docxFile()], "docx");
    expect(await screen.findByText("Vendor Letter")).toBeInTheDocument();
    const add = screen.getByRole("button", { name: "Add template" });
    await waitFor(() => expect(add).toBeEnabled());

    fireEvent.click(add);
    await waitFor(() => expect(onInstalled).toHaveBeenCalledTimes(1));
    expect(onInstalled.mock.calls[0][1]).toBe(false);
    expect(getSchema("custom-vendor-letter")).toBeDefined();
  });

  it("checks off the Word template alone and asks for the schema", async () => {
    renderDialog(<UploadTemplateDialog open onClose={() => {}} onInstalled={() => {}} />);
    expect(screen.getByLabelText("Word template not added")).toBeInTheDocument();
    expect(screen.getByLabelText("Schema not added")).toBeInTheDocument();

    upload([docxFile()], "docx");
    expect(await screen.findByLabelText("Word template added")).toBeInTheDocument();
    expect(screen.getByLabelText("Schema not added")).toBeInTheDocument();
    expect(screen.getByText("vendor-letter.docx")).toBeInTheDocument();
    expect(screen.getByRole("status")).toHaveTextContent("Add its .schema.json to check it as is");
    expect(screen.getByRole("button", { name: "Add template" })).toBeDisabled();
  });

  it("builds a draft schema from a Word file's tags and opens the editor", async () => {
    const onClose = vi.fn();
    renderDialog(<UploadTemplateDialog open onClose={onClose} onInstalled={() => {}} />);
    upload([docxFile()], "docx");
    fireEvent.click(await screen.findByRole("button", { name: "Build the schema from the tags" }));

    const editing = await screen.findByText(/^Editing draft-/);
    const draft = await getTemplateDraft(editing.textContent!.replace("Editing ", ""));
    expect(draft?.schema.template_key_map).toEqual({ VENDOR: "header.vendor" });
    expect(onClose).toHaveBeenCalled();
  });

  it("says so when the Word file has no tags", async () => {
    renderDialog(<UploadTemplateDialog open onClose={() => {}} onInstalled={() => {}} />);
    upload([docxFile("Dear vendor,")], "docx");
    fireEvent.click(await screen.findByRole("button", { name: "Build the schema from the tags" }));
    expect(await screen.findByTestId("validation-report")).toHaveTextContent("has no {{TAGS}}");
    expect(await db.templateDrafts.count()).toBe(0);
  });

  it("checks off the schema alone and asks for the Word template", async () => {
    renderDialog(<UploadTemplateDialog open onClose={() => {}} onInstalled={() => {}} />);
    upload([schemaFile()], "schema");
    expect(await screen.findByLabelText("Schema added")).toBeInTheDocument();
    expect(screen.getByLabelText("Word template not added")).toBeInTheDocument();
    expect(screen.getByRole("status")).toHaveTextContent("Now add its Word template (.docx)");
  });

  it("sorts files into the right zone whichever zone they're dropped on", async () => {
    renderDialog(<UploadTemplateDialog open onClose={() => {}} onInstalled={() => {}} />);
    upload([docxFile(), schemaFile()], "bundle");
    expect(await screen.findByLabelText("Word template added")).toBeInTheDocument();
    expect(screen.getByLabelText("Schema added")).toBeInTheDocument();
    expect(screen.getByLabelText("Template bundle not added")).toBeInTheDocument();
    await waitFor(() => expect(screen.getByRole("button", { name: "Add template" })).toBeEnabled());
  });

  it("removing a file unchecks it and disables Add", async () => {
    renderDialog(<UploadTemplateDialog open onClose={() => {}} onInstalled={() => {}} />);
    upload([schemaFile(), docxFile()]);
    await waitFor(() => expect(screen.getByRole("button", { name: "Add template" })).toBeEnabled());

    fireEvent.click(screen.getByRole("button", { name: "Remove word template" }));
    expect(await screen.findByLabelText("Word template not added")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Add template" })).toBeDisabled();
    expect(screen.getByRole("status")).toHaveTextContent("Now add its Word template");
  });

  it("a bundle replaces the file pair", async () => {
    const bundle = {
      _type: "doc-builder-template-bundle",
      version: 1,
      exportedAt: "2026-10-09T00:00:00Z",
      template: {
        originalId: "vendor-letter",
        schema,
        docxBase64: btoa(String.fromCharCode(...buildDocx(para("Dear {{VENDOR}}")))),
        docxSha256: "",
        revision: 1,
      },
    };
    renderDialog(<UploadTemplateDialog open onClose={() => {}} onInstalled={() => {}} />);
    upload([docxFile()], "docx");
    expect(await screen.findByLabelText("Word template added")).toBeInTheDocument();

    upload([new File([JSON.stringify(bundle)], "vendor-letter.template-bundle.json")], "bundle");
    expect(await screen.findByLabelText("Template bundle added")).toBeInTheDocument();
    expect(screen.getByLabelText("Word template not added")).toBeInTheDocument();
    await waitFor(() => expect(screen.getByRole("button", { name: "Add template" })).toBeEnabled());
    expect(screen.getByText(/came from a file/)).toBeInTheDocument();
  });

  it("rejects files that aren't .docx or .json", async () => {
    renderDialog(<UploadTemplateDialog open onClose={() => {}} onInstalled={() => {}} />);
    upload([new File(["x"], "notes.pdf")], "docx");
    expect(await screen.findByText(/"notes.pdf" isn't a Word template/)).toBeInTheDocument();
    expect(screen.getByLabelText("Word template not added")).toBeInTheDocument();
  });

  it("shows integrity errors and keeps Add disabled", async () => {
    renderDialog(<UploadTemplateDialog open onClose={() => {}} onInstalled={() => {}} />);
    upload([schemaFile(), docxFile("Dear {{VENDOR}} {{MYSTERY}}")]);
    expect(await screen.findByTestId("validation-report")).toHaveTextContent("{{MYSTERY}}");
    expect(screen.getByRole("button", { name: "Add template" })).toBeDisabled();
  });

  it("offers Replace with a field diff when the template exists", async () => {
    const first = vi.fn();
    const { unmount } = renderDialog(<UploadTemplateDialog open onClose={() => {}} onInstalled={first} />);
    upload([schemaFile(), docxFile()]);
    const add = await screen.findByRole("button", { name: "Add template" });
    await waitFor(() => expect(add).toBeEnabled());
    fireEvent.click(add);
    await waitFor(() => expect(first).toHaveBeenCalled());
    unmount();

    const updated = structuredClone(schema);
    updated.sections[0].fields.push({ id: "po", label: "PO", type: "string", required: false });
    renderDialog(<UploadTemplateDialog open onClose={() => {}} onInstalled={() => {}} />);
    upload([schemaFile(updated), docxFile()]);
    expect(await screen.findByRole("button", { name: "Replace template" })).toBeInTheDocument();
    expect(screen.getByText(/Added: main\.po/)).toBeInTheDocument();
  });
});
