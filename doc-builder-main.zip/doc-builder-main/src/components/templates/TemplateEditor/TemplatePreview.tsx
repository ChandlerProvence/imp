import { useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import rehypeRaw from "rehype-raw";
import type { DocumentSchema, FieldDef } from "../../../schemas/types";
import { findField } from "../../../schemas/templateScan";
import { placeholderAnswers } from "../../../schemas/sampleAnswers";
import { renderDocxFromArrayBuffer } from "../../../generation/generateDocx";
import { docxToHtmlPreview } from "../../../generation/docxPreview";
import { toAppError, type AppError } from "../../../errors";
import AppErrorBox from "../../AppErrorBox";

/** A request to show a field's marker; `seq` changes on every click so repeat clicks re-run. */
export interface PreviewFocus {
  path: string;
  seq: number;
}

interface Props {
  schema: DocumentSchema;
  docx: ArrayBuffer;
  /** The preview's tab is showing. Renders are skipped while it's hidden. */
  active: boolean;
  focus: PreviewFocus | null;
}

type Render = { status: "pending" } | { status: "ready"; html: string } | { status: "error"; error: AppError };

/** Re-render delay after the last schema change. */
export const PREVIEW_DEBOUNCE_MS = 600;
/** How long a located marker stays highlighted. */
const FLASH_MS = 2000;

/**
 * Text the preview shows for a field, matching `placeholderValue()`: the
 * bracketed label, the first choice for enum and multiselect fields, the
 * first text column's label for tables. Booleans have no visible marker.
 */
export function previewMarker(field: FieldDef): string | null {
  if (field.formula !== undefined || field.same_as) return null;
  switch (field.type) {
    case "boolean":
    case "image":
      return null;
    case "enum":
    case "multiselect":
      return field.options?.[0] ?? `[${field.label}]`;
    case "table": {
      const column = field.columns?.find((c) => !c.formula && c.type !== "boolean");
      return column ? `[${column.label}]` : null;
    }
    default:
      return `[${field.label}]`;
  }
}

/** Every text node under `root` that contains `marker`, in document order. */
function findMarkers(root: HTMLElement, marker: string): Text[] {
  const hits: Text[] = [];
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  for (let node = walker.nextNode(); node; node = walker.nextNode()) {
    if (node.textContent?.includes(marker)) hits.push(node as Text);
  }
  return hits;
}

/**
 * The Word file filled with placeholder answers, so the user can see where
 * each field lands before installing. Re-renders as the schema changes.
 */
export default function TemplatePreview({ schema, docx, active, focus }: Props) {
  const [render, setRender] = useState<Render>({ status: "pending" });
  const [updating, setUpdating] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const body = useRef<HTMLDivElement>(null);
  /**
   * Which occurrence the last click showed, so repeat clicks step through
   * them. A re-render for the same click (same `seq`) stays on it.
   */
  const occurrence = useRef<{ path: string; index: number; seq: number } | null>(null);

  useEffect(() => {
    if (!active) return;
    let cancelled = false;
    setUpdating(true);
    const timer = setTimeout(() => {
      (async () => {
        const blob = renderDocxFromArrayBuffer(docx, schema, placeholderAnswers(schema));
        const html = await docxToHtmlPreview(blob);
        if (!cancelled) setRender({ status: "ready", html });
      })()
        .catch((err) => {
          if (!cancelled) setRender({ status: "error", error: toAppError(err, { domain: "generation", context: { schema: schema.title } }) });
        })
        .finally(() => {
          if (!cancelled) setUpdating(false);
        });
    }, PREVIEW_DEBOUNCE_MS);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [schema, docx, active]);

  const html = render.status === "ready" ? render.html : null;
  useEffect(() => {
    const root = body.current;
    if (!focus || !root || !html) return;
    const field = findField(schema, focus.path);
    const marker = field ? previewMarker(field) : null;
    if (!field || !marker) {
      setNotice(field?.type === "boolean" ? `“${field.label}” is a yes/no field; it has no text in the preview.` : null);
      return;
    }
    const hits = findMarkers(root, marker);
    if (hits.length === 0) {
      setNotice(`“${marker}” isn't in the preview. Headers and footers aren't shown here.`);
      return;
    }
    const prev = occurrence.current;
    const index =
      prev?.path !== focus.path ? 0 : prev.seq === focus.seq ? Math.min(prev.index, hits.length - 1) : (prev.index + 1) % hits.length;
    occurrence.current = { path: focus.path, index, seq: focus.seq };
    setNotice(hits.length > 1 ? `Showing ${index + 1} of ${hits.length}. Click the field again for the next one.` : null);

    const target = hits[index].parentElement;
    if (!target) return;
    // Scroll only the preview box; scrollIntoView would also move the page
    const offset = target.getBoundingClientRect().top - root.getBoundingClientRect().top;
    root.scrollTo?.({ top: root.scrollTop + offset - root.clientHeight / 3, behavior: "smooth" });
    target.classList.add("bg-yellow-200");
    target.dataset.previewMarker = "active";
    const timer = setTimeout(() => {
      target.classList.remove("bg-yellow-200");
      delete target.dataset.previewMarker;
    }, FLASH_MS);
    return () => {
      clearTimeout(timer);
      target.classList.remove("bg-yellow-200");
      delete target.dataset.previewMarker;
    };
    // Runs per click (focus.seq) or once the preview it needs has rendered
  }, [focus, html]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <section aria-label="Preview" className="flex h-full min-h-0 flex-col rounded-lg border border-gray-200 bg-white">
      <p className="px-3 pt-2 text-xs text-gray-500">
        Each field shows as its [label]. Click a field to find it here.
        {updating && render.status !== "pending" && " Updating…"}
      </p>
      {notice && (
        <p className="px-3 pt-1 text-xs text-amber-800" role="status">
          {notice}
        </p>
      )}
      {render.status === "error" ? (
        <div className="p-3">
          <AppErrorBox error={render.error} />
        </div>
      ) : (
        // Fills the column on wide screens; capped when stacked below the fields
        <div ref={body} data-testid="template-preview" className="relative max-h-[70vh] min-h-0 flex-1 overflow-y-auto p-3 @4xl:max-h-none">
          {html !== null ? (
            <div className="prose prose-sm prose-gray max-w-none">
              <ReactMarkdown rehypePlugins={[rehypeRaw]}>{html}</ReactMarkdown>
            </div>
          ) : (
            <p className="text-sm text-gray-500">Building the preview…</p>
          )}
        </div>
      )}
    </section>
  );
}
