import type { FieldDef } from "../../../schemas/types";
import OptionsEditor from "./OptionsEditor";
import LockedBadge from "./LockedBadge";
import { COLUMN_TYPES, type EditAction } from "./useTemplateEditor";
import { columnKey, lockTooltip, type SchemaLocks } from "./locks";
import { TYPE_LABELS } from "./typeLabels";

interface Props {
  path: string;
  field: FieldDef;
  locks: SchemaLocks;
  /** Template tag for each column id, from template_column_map. */
  columnTags: Record<string, string>;
  dispatch: (action: EditAction) => void;
}

/** Label, type, required, and choices for each column of a table field. */
export default function ColumnEditor({ path, field, locks, columnTags, dispatch }: Props) {
  return (
    <div className="space-y-2">
      <p className="text-xs font-medium text-gray-600">Columns</p>
      {(field.columns ?? []).map((col) => {
        const locked = locks.columns.get(columnKey(path, col.id)) ?? [];
        const name = col.label || col.id;
        return (
          <div key={col.id} className="space-y-2 rounded-md border border-gray-200 bg-gray-50 p-2" data-testid="column-editor">
            <div className="flex flex-wrap items-end gap-2">
              <label className="min-w-[10rem] flex-1 text-xs text-gray-600">
                Column label
                <input
                  value={col.label}
                  onChange={(e) => dispatch({ type: "updateColumn", path, columnId: col.id, patch: { label: e.target.value } })}
                  className="mt-0.5 block w-full rounded-md border border-gray-300 px-2 py-1 text-sm text-gray-900"
                />
              </label>
              <label className="text-xs text-gray-600" title={lockTooltip(locked, locks.causes)}>
                Type
                <select
                  value={col.type}
                  disabled={locked.length > 0}
                  onChange={(e) =>
                    dispatch({ type: "setColumnType", path, columnId: col.id, columnType: e.target.value as (typeof COLUMN_TYPES)[number] })
                  }
                  aria-label={`${name} column type`}
                  className="mt-0.5 block rounded-md border border-gray-300 px-2 py-1 text-sm text-gray-900 disabled:bg-gray-100"
                >
                  {COLUMN_TYPES.map((t) => (
                    <option key={t} value={t}>
                      {TYPE_LABELS[t]}
                    </option>
                  ))}
                </select>
              </label>
              <label className="flex items-center gap-1 pb-1 text-xs text-gray-700">
                <input
                  type="checkbox"
                  checked={!!col.required}
                  onChange={(e) =>
                    dispatch({ type: "updateColumn", path, columnId: col.id, patch: { required: e.target.checked || undefined } })
                  }
                />
                Required
              </label>
            </div>
            <p className="text-xs text-gray-500">
              id {col.id}
              {columnTags[col.id] ? ` · fills {{${columnTags[col.id]}}}` : ""}
            </p>
            {col.type === "enum" && (
              <div title={lockTooltip(locked, locks.causes)}>
                <OptionsEditor
                  label={name}
                  options={col.options ?? []}
                  disabled={locked.length > 0}
                  onChange={(options) => dispatch({ type: "updateColumn", path, columnId: col.id, patch: { options } })}
                />
              </div>
            )}
            <LockedBadge reasons={locked} what="type" />
          </div>
        );
      })}
    </div>
  );
}
