import { describe, it, expect, beforeEach, vi } from "vitest";
import { screen, fireEvent, waitFor, within } from "@testing-library/react";
import { Route, Routes } from "react-router-dom";
import TemplateEditorPage from "../../../pages/TemplateEditorPage";
import { renderWithProviders } from "../../../test/renderWithProviders";
import { db } from "../../../db/dexie";
import { getUserTemplate } from "../../../db/userTemplates";
import { getTemplateDraft } from "../../../db/templateDrafts";
import { installTemplate, reloadUserSchemas } from "../../../schemas/userSchemas";
import { validateUserTemplatePair } from "../../../schemas/userTemplateValidation";
import { createDraftFromDocx } from "../../../schemas/templateDrafts";
import { buildDocx, headingPara, para, table } from "../../../test/docxFixtures";

// mammoth's Node build doesn't accept { arrayBuffer } (the browser build does)
vi.mock("mammoth", async () => {
  const { default: PizZip } = await import("pizzip");
  return {
    default: {
      convertToHtml: async ({ arrayBuffer }: { arrayBuffer: ArrayBuffer }) => {
        const xml = new PizZip(arrayBuffer).file("word/document.xml")!.asText();
        const paragraphs = [...xml.matchAll(/<w:p[ >][\s\S]*?<\/w:p>/g)].map(
          (p) => `<p>${[...p[0].matchAll(/<w:t[^>]*>([^<]*)<\/w:t>/g)].map((m) => m[1]).join("")}</p>`,
        );
        return { value: paragraphs.join("") };
      },
    },
  };
});

const docx = () =>
  buildDocx(
    para("Dear {{VENDOR}}, on {{LETTER_DATE}}") +
      headingPara(1, "Items") +
      table([["Name"], ["{{#ITEMS}}{{NAME}}{{/ITEMS}}"]]),
  );

async function installSample(extra: Record<string, unknown> = {}) {
  const schema = {
    id: "vendor-letter",
    title: "Vendor Letter",
    version: 1,
    docx_template: "x.docx",
    sections: [
      {
        id: "main",
        title: "Main",
        fields: [
          { id: "vendor", label: "VENDOR", type: "string", required: false },
          { id: "letter_date", label: "Letter date", type: "date", required: false },
        ],
      },
      {
        id: "items",
        title: "Items",
        fields: [{ id: "items", label: "Items", type: "table", required: false, columns: [{ id: "name", label: "Name", type: "string" }] }],
      },
    ],
    template_key_map: { VENDOR: "main.vendor", LETTER_DATE: "main.letter_date", ITEMS: "items.items" },
    template_column_map: { ITEMS: { NAME: "name" } },
    ...extra,
  };
  const { prepared, issues } = await validateUserTemplatePair({ schemaText: JSON.stringify(schema), docx: docx() });
  if (!prepared) throw new Error(JSON.stringify(issues));
  return installTemplate(prepared);
}

function renderEditor(id: string) {
  return renderWithProviders(
    <Routes>
      <Route path="/templates/edit/:id" element={<TemplateEditorPage />} />
      <Route path="/templates" element={<p>Templates list</p>} />
    </Routes>,
    { routerEntries: [`/templates/edit/${id}`] },
  );
}

const card = (name: string) => screen.getByRole("article", { name });

// Each test validates and installs a real .docx and some render a preview.
// Alone that takes up to ~1.5 s, but under a full parallel suite the save →
// navigate steps can pass Testing Library's 1 s default and the test Vitest's
// 5 s, so give this file room instead of raising the limits for every test.
const SAVE_WAIT = { timeout: 5_000 };

beforeEach(async () => {
  await db.userTemplates.clear();
  await db.templateDrafts.clear();
  await reloadUserSchemas();
});

describe("TemplateEditor", { timeout: 20_000 }, () => {
  it("edits an installed template and saves it as a new revision", async () => {
    await installSample();
    renderEditor("custom-vendor-letter");

    const vendor = await screen.findByRole("article", { name: "VENDOR" });
    fireEvent.change(within(vendor).getByLabelText("Label"), { target: { value: "Vendor name" } });
    fireEvent.change(within(card("Vendor name")).getByLabelText("Vendor name type"), { target: { value: "enum" } });
    expect(within(card("Vendor name")).getByText("Add at least one choice.")).toBeInTheDocument();
    fireEvent.click(within(card("Vendor name")).getByText("Add a choice"));
    fireEvent.change(within(card("Vendor name")).getByLabelText("Vendor name choice 1"), { target: { value: "Acme" } });
    expect(screen.getByText(/Unsaved changes/)).toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: "Save" }));
    const confirm = await screen.findByTestId("editor-confirm", {}, SAVE_WAIT);
    expect(within(confirm).getByText(/This replaces revision 1/)).toBeInTheDocument();
    expect(within(confirm).getByText(/Changed type: main.vendor \(was string, now enum\)/)).toBeInTheDocument();

    fireEvent.click(within(confirm).getByRole("button", { name: "Save changes" }));
    expect(await screen.findByText("Templates list", {}, SAVE_WAIT)).toBeInTheDocument();
    const saved = await getUserTemplate("custom-vendor-letter");
    expect(saved?.revision).toBe(2);
    expect(saved?.schema.sections[0].fields[0]).toMatchObject({ label: "Vendor name", type: "enum", options: ["Acme"] });
  });

  it("shows validation problems instead of saving", async () => {
    await installSample();
    renderEditor("custom-vendor-letter");
    const title = (await screen.findAllByLabelText("Section title"))[0];
    fireEvent.change(title, { target: { value: "" } });
    fireEvent.click(screen.getByRole("button", { name: "Save" }));
    const report = await screen.findByTestId("editor-validation");
    expect(within(report).getByText(/missing `title`/)).toBeInTheDocument();
    expect((await getUserTemplate("custom-vendor-letter"))?.revision).toBe(1);
  });

  it("checks without saving, and edits clear the result", async () => {
    await installSample();
    renderEditor("custom-vendor-letter");
    const vendor = await screen.findByRole("article", { name: "VENDOR" });

    fireEvent.change(within(vendor).getByLabelText("Label"), { target: { value: "Vendor name" } });
    fireEvent.click(screen.getByRole("button", { name: "Check" }));
    expect(await screen.findByTestId("editor-checked")).toHaveTextContent("No problems found. Save to keep your changes.");
    expect((await getUserTemplate("custom-vendor-letter"))?.revision).toBe(1);

    fireEvent.change(within(card("Vendor name")).getByLabelText("Label"), { target: { value: "Vendor" } });
    expect(screen.queryByTestId("editor-checked")).not.toBeInTheDocument();

    // Check reports the same problems Save would
    fireEvent.change(screen.getAllByLabelText("Section title")[0], { target: { value: "" } });
    fireEvent.click(screen.getByRole("button", { name: "Check" }));
    expect(await screen.findByTestId("editor-validation")).toHaveTextContent(/missing `title`/);
  });

  it("moves a field to another section and keeps its tag mapped", async () => {
    await installSample();
    renderEditor("custom-vendor-letter");
    await screen.findByRole("article", { name: "VENDOR" });
    fireEvent.change(within(card("VENDOR")).getByLabelText("Move VENDOR to section"), { target: { value: "items" } });
    const items = screen.getByRole("region", { name: "Section Items" });
    expect(within(items).getByRole("article", { name: "VENDOR" })).toBeInTheDocument();
    expect(within(card("VENDOR")).getByText(/fills \{\{VENDOR\}\}/)).toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: "Save" }));
    fireEvent.click(await screen.findByRole("button", { name: "Save changes" }, SAVE_WAIT));
    await screen.findByText("Templates list", {}, SAVE_WAIT);
    expect((await getUserTemplate("custom-vendor-letter"))?.schema.template_key_map?.VENDOR).toBe("items.vendor");
  });

  it("locks fields used by advanced features", async () => {
    await installSample({ content_blocks: { HAS_VENDOR: { when: { field: "main.vendor", is_truthy: true } } } });
    renderEditor("custom-vendor-letter");
    const vendor = await screen.findByRole("article", { name: "VENDOR" });
    expect(within(vendor).getByLabelText("VENDOR type")).toBeDisabled();
    expect(within(vendor).getByLabelText("Move VENDOR to section")).toBeDisabled();
    expect(within(vendor).getByText(/Locked: section, type, and choices/)).toBeInTheDocument();
    expect(within(vendor).getByText(/decides the content block HAS_VENDOR/)).toBeInTheDocument();
    expect(within(vendor).getByLabelText("Label")).toBeEnabled();
    const moveTip = within(vendor).getByLabelText("Move VENDOR to section").parentElement!.title;
    expect(moveTip).toBe("Locked because it decides which parts of the document appear.");
    expect(within(vendor).getByLabelText("VENDOR type").closest("label")!.title).toBe(moveTip);
    expect(within(card("Letter date")).getByLabelText("Letter date type").closest("label")!.title).toBe("");
    expect(screen.getByText("Content blocks: HAS_VENDOR")).toBeInTheDocument();
    // Kept as is and every Locked badge point at the list of what the editor can't change
    const helpLinks = screen.getAllByRole("link", { name: "What the editor can't change", hidden: true });
    expect(helpLinks.length).toBeGreaterThanOrEqual(2);
    for (const link of helpLinks) expect(link).toHaveAttribute("href", "/docs/help/template-editor");

    // A section holding a pinned field can't merge, and the tooltip says which field
    const mergeMain = screen.getByLabelText("Merge section Main into");
    expect(mergeMain).toBeDisabled();
    expect(mergeMain.parentElement!.title).toBe("Locked because VENDOR can't leave this section.");
    expect(screen.getByLabelText("Merge section Items into")).toBeEnabled();
  });

  it("lists every template tag with the field that fills it", async () => {
    await installSample();
    renderEditor("custom-vendor-letter");
    fireEvent.click(await screen.findByRole("tab", { name: "Tags" }));
    const panel = screen.getByRole("complementary", { name: "Template tags" });
    const rows = within(panel).getAllByTestId("tag-row");
    expect(rows.map((r) => r.querySelector("code")?.textContent)).toEqual(["{{VENDOR}}", "{{LETTER_DATE}}", "{{ITEMS}}"]);
    expect(within(rows[2]).getByText("Items · in a table")).toBeInTheDocument();
    expect(within(rows[2]).getByRole("listitem").textContent).toBe("{{NAME}} → Name");
  });

  it("previews the edited schema and finds a clicked field in it", async () => {
    await installSample();
    renderEditor("custom-vendor-letter");
    const vendor = await screen.findByRole("article", { name: "VENDOR" });
    const preview = () => screen.getByTestId("template-preview");
    await waitFor(() => expect(preview().textContent).toContain("Dear [VENDOR], on [Letter date]"), SAVE_WAIT);
    expect(preview().textContent).toContain("[Name]");

    fireEvent.change(within(vendor).getByLabelText("Label"), { target: { value: "Vendor name" } });
    await waitFor(() => expect(preview().textContent).toContain("Dear [Vendor name]"), SAVE_WAIT);

    fireEvent.click(card("Letter date"));
    await waitFor(() => expect(preview().querySelector("[data-preview-marker]")?.textContent).toContain("[Letter date]"));

    fireEvent.click(screen.getByRole("tab", { name: "Tags" }));
    expect(screen.getByRole("tab", { name: "Tags" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByTestId("template-preview")).not.toBeVisible();
  });

  it("jumps from a tag to its field and its place in the preview", async () => {
    await installSample();
    renderEditor("custom-vendor-letter");
    const preview = () => screen.getByTestId("template-preview");
    await waitFor(() => expect(preview().textContent).toContain("[Letter date]"), SAVE_WAIT);

    fireEvent.click(screen.getByRole("tab", { name: "Tags" }));
    const panel = screen.getByRole("complementary", { name: "Template tags" });
    fireEvent.click(within(within(panel).getAllByTestId("tag-row")[1]).getByRole("button"));

    expect(screen.getByRole("tab", { name: "Preview" })).toHaveAttribute("aria-selected", "true");
    expect(card("Letter date").className).toContain("ring-2");
    await waitFor(() => expect(preview().querySelector("[data-preview-marker]")?.textContent).toContain("[Letter date]"));
  });

  it("autosaves a draft and installs it", async () => {
    const created = await createDraftFromDocx(new File([docx() as BlobPart], "Vendor Letter.docx"));
    if (!created.ok) throw new Error("draft failed");
    renderEditor(created.draft.id);

    const vendor = await screen.findByRole("article", { name: "Vendor" });
    fireEvent.change(within(vendor).getByLabelText("Label"), { target: { value: "Vendor name" } });
    await waitFor(async () => {
      expect((await getTemplateDraft(created.draft.id))?.schema.sections[0].fields[0].label).toBe("Vendor name");
    }, SAVE_WAIT);

    fireEvent.click(screen.getByRole("button", { name: "Save" }));
    expect(await screen.findByText("Templates list", {}, SAVE_WAIT)).toBeInTheDocument();
    expect((await getUserTemplate("custom-vendor-letter"))?.schema.sections[0].fields[0].label).toBe("Vendor name");
    expect(await getTemplateDraft(created.draft.id)).toBeUndefined();
  });

  it("warns before a draft replaces a template with the same id", async () => {
    await installSample();
    const created = await createDraftFromDocx(new File([docx() as BlobPart], "Vendor Letter.docx"));
    if (!created.ok) throw new Error("draft failed");
    renderEditor(created.draft.id);
    await screen.findByRole("article", { name: "Vendor" });
    fireEvent.click(screen.getByRole("button", { name: "Save" }));
    const confirm = await screen.findByTestId("editor-confirm", {}, SAVE_WAIT);
    expect(within(confirm).getByText(/already have a custom template with the id "vendor-letter"/)).toBeInTheDocument();

    fireEvent.change(screen.getByLabelText("Template id"), { target: { value: "Vendor Letter 2" } });
    expect(screen.queryByTestId("editor-confirm")).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Save" }));
    await screen.findByText("Templates list", {}, SAVE_WAIT);
    expect(await getUserTemplate("custom-vendor-letter-2")).toBeDefined();
    expect((await getUserTemplate("custom-vendor-letter"))?.revision).toBe(1);
  });

  it("says so when the template doesn't exist", async () => {
    renderEditor("draft-missing");
    expect(await screen.findByText(/isn't in this browser any more/)).toBeInTheDocument();
  });
});
