import { useMemo } from "react";
import type { DocumentSchema } from "../../../schemas/types";
import type { TemplateScan } from "../../../schemas/templateScan";
import { findField, resolveFieldPath } from "../../../schemas/templateScan";
import { tagContext, type TemplateStructure } from "../../../schemas/templateStructure";

interface Props {
  schema: DocumentSchema;
  scan: TemplateScan;
  structure: TemplateStructure;
  onSelectField: (path: string) => void;
}

interface TagRow {
  tag: string;
  /** Field path for field and loop tags. */
  path?: string;
  /** What fills the tag, in words. */
  target: string;
  /** Text of the paragraph it first appears in. */
  paragraph?: string;
  where?: string;
  columns: { tag: string; label: string }[];
}

const truncate = (s: string, n = 90) => (s.length > n ? `${s.slice(0, n - 1)}…` : s);

/** Read-only map of every tag in the Word file: what fills it, and where it sits. */
export default function TemplateTagsPanel({ schema, scan, structure, onSelectField }: Props) {
  const rows = useMemo(() => buildRows(schema, scan, structure), [schema, scan, structure]);
  return (
    <aside aria-label="Template tags" className="space-y-2">
      <h2 className="text-xs font-semibold uppercase tracking-wide text-gray-500">Template tags</h2>
      <p className="text-xs text-gray-500">Every tag in the Word file and the field that fills it.</p>
      <ul className="space-y-2">
        {rows.map((row) => (
          <li key={row.tag} className="rounded-md border border-gray-200 bg-white p-2 text-xs" data-testid="tag-row">
            <div className="flex flex-wrap items-baseline justify-between gap-1">
              <code className="font-mono text-gray-900">{`{{${row.tag}}}`}</code>
              {row.path ? (
                <button type="button" onClick={() => onSelectField(row.path!)} className="text-blue-600 hover:text-blue-800">
                  {row.target}
                </button>
              ) : (
                <span className={row.target === "Not filled" ? "text-red-700" : "text-gray-600"}>{row.target}</span>
              )}
            </div>
            {row.where && <p className="mt-0.5 text-gray-500">{row.where}</p>}
            {row.paragraph && <p className="mt-0.5 italic text-gray-600">“{row.paragraph}”</p>}
            {row.columns.length > 0 && (
              <ul className="mt-1 space-y-0.5 border-l-2 border-gray-200 pl-2">
                {row.columns.map((c) => (
                  <li key={c.tag}>
                    <code className="font-mono">{`{{${c.tag}}}`}</code> → {c.label}
                  </li>
                ))}
              </ul>
            )}
          </li>
        ))}
      </ul>
    </aside>
  );
}

function buildRows(schema: DocumentSchema, scan: TemplateScan, structure: TemplateStructure): TagRow[] {
  const tkm = schema.template_key_map ?? {};
  const blocks = new Set(Object.keys(schema.content_blocks ?? {}));
  const columnTags = new Set<string>();
  for (const [loop, cols] of scan.columnTags) if (loop in tkm) for (const c of cols) columnTags.add(c);

  // Document order, each tag once; column tags are listed under their loop
  const order: string[] = [];
  const seen = new Set<string>();
  for (const p of structure.paragraphs) {
    for (const t of p.tags) {
      if (t.prefix === "/" || seen.has(t.name)) continue;
      seen.add(t.name);
      if (!columnTags.has(t.name) || scan.topLevel.has(t.name)) order.push(t.name);
    }
  }

  return order.map((tag) => {
    const row: TagRow = { tag, target: "Not filled", columns: [] };
    const ctx = tagContext(structure, tag);
    if (ctx) {
      row.paragraph = truncate(ctx.paragraph.text);
      const place = ctx.paragraph.part === "header" ? "Page header" : ctx.paragraph.part === "footer" ? "Page footer" : undefined;
      const headings = ctx.headingPath.map((h) => h.text).join(" › ");
      row.where = [place, headings, ctx.paragraph.inTable ? "in a table" : undefined].filter(Boolean).join(" · ") || undefined;
    }
    const mapping = tkm[tag];
    if (mapping) {
      const path = resolveFieldPath(mapping);
      const field = findField(schema, path);
      row.path = field ? path : undefined;
      row.target = field ? field.label || field.id : `Missing field ${path}`;
      const colMap = schema.template_column_map?.[tag];
      for (const colTag of scan.columnTags.get(tag) ?? []) {
        const colId = colMap?.[colTag] ?? colTag;
        const col = field?.columns?.find((c) => c.id === colId);
        row.columns.push({ tag: colTag, label: col ? col.label || col.id : "Not filled" });
      }
    } else if (blocks.has(tag)) {
      row.target = "Content block (fixed)";
    }
    return row;
  });
}
