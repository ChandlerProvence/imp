import type { FieldType } from "../../../schemas/types";

/** Plain-language names for field and column types. */
export const TYPE_LABELS: Record<FieldType, string> = {
  string: "Short text",
  freetext: "Long text (paragraphs)",
  number: "Number",
  date: "Date",
  boolean: "Yes / no",
  enum: "One choice from a list",
  multiselect: "Several choices from a list",
  table: "Table",
  image: "Image",
};
