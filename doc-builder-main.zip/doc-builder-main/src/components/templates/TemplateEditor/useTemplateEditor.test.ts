import { describe, it, expect } from "vitest";
import { editReducer, retargetFieldPath, canMergeSection } from "./useTemplateEditor";
import { computeLocks, lockedSchemaSettings, lockTooltip } from "./locks";
import type { DocumentSchema } from "../../../schemas/types";

function base(): DocumentSchema {
  return {
    id: "memo",
    title: "Memo",
    version: 1,
    docx_template: "memo.docx",
    output_filename: "Memo - {{header.vendor}} - {{ header.memo_date }}",
    sections: [
      {
        id: "header",
        title: "Details",
        fields: [
          { id: "vendor", label: "Vendor", type: "string", required: false },
          { id: "memo_date", label: "Memo date", type: "date", required: false, display_format: "long" },
        ],
      },
      {
        id: "body",
        title: "Body",
        fields: [
          { id: "vendor", label: "Vendor again", type: "string", required: false },
          {
            id: "items",
            label: "Items",
            type: "table",
            required: false,
            columns: [
              { id: "name", label: "Name", type: "string" },
              { id: "qty", label: "Qty", type: "number", format: "integer" },
            ],
          },
        ],
      },
    ],
    template_key_map: {
      VENDOR: "header.vendor",
      MEMO_DATE: { field: "header.memo_date", date_format: "short" },
      VENDOR_2: "body.vendor",
      ITEMS: "body.items",
    },
    // Unknown keys must survive edits
    ...({ x_custom: { keep: true } } as object),
  } as DocumentSchema;
}

const field = (s: DocumentSchema, path: string) => {
  const [sid, fid] = path.split(".");
  return s.sections.find((x) => x.id === sid)?.fields.find((f) => f.id === fid);
};

describe("retargetFieldPath", () => {
  it("rewrites template_key_map (both forms), output_filename, and same_as", () => {
    const s = base();
    s.sections[1].fields.push({ id: "copy", label: "Copy", type: "date", required: false, same_as: "header.memo_date" });
    retargetFieldPath(s, "header.memo_date", "body.memo_date");
    expect(s.template_key_map!.MEMO_DATE).toEqual({ field: "body.memo_date", date_format: "short" });
    expect(s.output_filename).toBe("Memo - {{header.vendor}} - {{body.memo_date}}");
    expect(field(s, "body.copy")!.same_as).toBe("body.memo_date");
    expect(s.template_key_map!.VENDOR).toBe("header.vendor");
  });
});

describe("editReducer", () => {
  it("moves a field to another section, deduplicating its id and retargeting references", () => {
    const next = editReducer(base(), { type: "moveFieldToSection", path: "header.vendor", sectionId: "body" });
    expect(next.sections[0].fields.map((f) => f.id)).toEqual(["memo_date"]);
    expect(next.sections[1].fields.map((f) => f.id)).toEqual(["vendor", "items", "vendor_2"]);
    expect(next.template_key_map!.VENDOR).toBe("body.vendor_2");
    expect(next.template_key_map!.VENDOR_2).toBe("body.vendor");
    expect(next.output_filename).toContain("{{body.vendor_2}}");
    expect((next as unknown as { x_custom: unknown }).x_custom).toEqual({ keep: true });
  });

  it("does not mutate the previous state", () => {
    const s = base();
    const before = structuredClone(s);
    editReducer(s, { type: "moveFieldToSection", path: "header.vendor", sectionId: "body" });
    editReducer(s, { type: "setFieldType", path: "header.vendor", fieldType: "enum" });
    expect(s).toEqual(before);
  });

  it("reorders fields and sections within bounds", () => {
    let s = editReducer(base(), { type: "moveField", path: "header.memo_date", delta: -1 });
    expect(s.sections[0].fields.map((f) => f.id)).toEqual(["memo_date", "vendor"]);
    expect(editReducer(s, { type: "moveField", path: "header.memo_date", delta: -1 })).toBe(s);
    s = editReducer(s, { type: "moveSection", sectionId: "body", delta: -1 });
    expect(s.sections.map((x) => x.id)).toEqual(["body", "header"]);
  });

  it("changes type and clears type-specific extras", () => {
    let s = editReducer(base(), { type: "setFieldType", path: "header.vendor", fieldType: "enum" });
    expect(field(s, "header.vendor")).toMatchObject({ type: "enum", options: [] });
    s = editReducer(s, { type: "updateField", path: "header.vendor", patch: { options: ["A", "B"] } });
    s = editReducer(s, { type: "setFieldType", path: "header.vendor", fieldType: "number" });
    expect(field(s, "header.vendor")!.options).toBeUndefined();
    s = editReducer(s, { type: "updateField", path: "header.vendor", patch: { format: "currency" } });
    s = editReducer(s, { type: "setFieldType", path: "header.vendor", fieldType: "string" });
    expect(field(s, "header.vendor")!.format).toBeUndefined();
  });

  it("never retypes a table field", () => {
    const s = base();
    expect(editReducer(s, { type: "setFieldType", path: "body.items", fieldType: "string" })).toBe(s);
  });

  it("edits labels, required, and hints; an empty hint removes the key", () => {
    let s = editReducer(base(), { type: "updateField", path: "header.vendor", patch: { label: "Vendor name", required: true, ai_hint: "Legal name" } });
    expect(field(s, "header.vendor")).toMatchObject({ label: "Vendor name", required: true, ai_hint: "Legal name" });
    s = editReducer(s, { type: "updateField", path: "header.vendor", patch: { ai_hint: "" } });
    expect("ai_hint" in field(s, "header.vendor")!).toBe(false);
  });

  it("edits columns and clears extras on column type change", () => {
    let s = editReducer(base(), { type: "updateColumn", path: "body.items", columnId: "name", patch: { label: "Item name", required: true } });
    expect(field(s, "body.items")!.columns![0]).toMatchObject({ label: "Item name", required: true });
    s = editReducer(s, { type: "setColumnType", path: "body.items", columnId: "qty", columnType: "enum" });
    expect(field(s, "body.items")!.columns![1]).toEqual({ id: "qty", label: "Qty", type: "enum", options: [] });
  });

  it("adds, removes (only when empty), and merges sections", () => {
    let s = editReducer(base(), { type: "addSection", title: "Body" });
    expect(s.sections.map((x) => x.id)).toEqual(["header", "body", "body_2"]);
    expect(editReducer(s, { type: "removeSection", sectionId: "header" })).toBe(s);
    s = editReducer(s, { type: "removeSection", sectionId: "body_2" });
    expect(s.sections).toHaveLength(2);

    s = editReducer(s, { type: "mergeSection", sectionId: "header", intoId: "body" });
    expect(s.sections.map((x) => x.id)).toEqual(["body"]);
    expect(s.sections[0].fields.map((f) => f.id)).toEqual(["vendor", "items", "vendor_2", "memo_date"]);
    expect(s.template_key_map).toMatchObject({ VENDOR: "body.vendor_2", MEMO_DATE: { field: "body.memo_date" } });
  });

  it("keeps the last section", () => {
    const s = base();
    s.sections = [{ id: "only", title: "Only", fields: [] }];
    expect(editReducer(s, { type: "removeSection", sectionId: "only" })).toBe(s);
  });

  it("changes the schema id and docx_template together", () => {
    const s = editReducer(base(), { type: "setId", id: "new-memo" });
    expect(s).toMatchObject({ id: "new-memo", docx_template: "new-memo.docx" });
  });
});

describe("locks", () => {
  function advanced(): DocumentSchema {
    const s = base();
    s.sections[0].fields.push(
      { id: "copy", label: "Copy", type: "string", required: false, same_as: "header.vendor" },
      { id: "kind", label: "Kind", type: "enum", required: false, options: ["a", "b"] },
      { id: "fee", label: "Fee", type: "number", required: false },
      { id: "total", label: "Total", type: "number", required: false, formula: "fee * 2", format: "currency" },
      { id: "sum", label: "Sum", type: "number", required: false, formula: "SUM(items_local.qty)", format: "currency" },
      {
        id: "items_local",
        label: "Local items",
        type: "table",
        required: false,
        columns: [
          { id: "qty", label: "Qty", type: "number" },
          { id: "price", label: "Price", type: "number" },
          { id: "line", label: "Line", type: "number", formula: "qty * price" },
        ],
      },
    );
    s.content_blocks = { SHOW_B: { when: { field: "header.kind", equals: "b" } }, NOTE: "text" };
    s.sections[1].fields.push(
      { id: "fee_plus", label: "Fee plus", type: "number", required: false, formula: "header.fee + 1" },
      { id: "amount", label: "Amount", type: "number", required: false },
    );
    s.sections[0].fields.push({ id: "from_body", label: "From body", type: "number", required: false, formula: "body.amount * RATE" });
    s.constants = { RATE: 2 };
    return s;
  }

  it("locks fields that use or are used by advanced features", () => {
    const { fields } = computeLocks(advanced());
    const locked = (p: string) => fields.get(p)?.move.length ?? 0;
    expect(locked("header.copy")).toBeGreaterThan(0); // same_as
    expect(locked("header.vendor")).toBeGreaterThan(0); // copied by header.copy
    expect(locked("header.kind")).toBeGreaterThan(0); // content block gate
    expect(locked("header.fee")).toBeGreaterThan(0); // used by a sibling formula and a section.field path
    expect(locked("header.total")).toBeGreaterThan(0); // has a formula
    expect(locked("header.items_local")).toBeGreaterThan(0); // totalled by SUM()
    expect(locked("body.amount")).toBeGreaterThan(0); // used from another section
    expect(fields.get("header.fee")?.move).toEqual([
      "header.total's formula uses it.",
      "body.fee_plus's formula uses it.",
    ]);
    expect(locked("body.items")).toBe(0);
    // date_format mapping locks the type but not the place
    expect(fields.get("header.memo_date")).toEqual({ move: [], type: [expect.stringContaining("MEMO_DATE")] });
  });

  it("features that travel with the field lock its type but not its place", () => {
    const s = base();
    s.sections[0].fields.push(
      { id: "preparer", label: "Preparer", type: "string", required: false, auto_fill: "user_profile.name" },
      { id: "note", label: "Note", type: "string", required: false, visible_when: "NOTE" },
      {
        id: "fixed",
        label: "Fixed",
        type: "table",
        required: false,
        rows: [{ id: "r1", label: "Row 1" }],
        columns: [{ id: "qty", label: "Qty", type: "number" }],
      },
    );
    s.content_blocks = { NOTE: true };
    const { fields } = computeLocks(s);
    expect(fields.get("header.preparer")).toEqual({ move: [], type: ["It is filled in from the user's profile."] });
    expect(fields.get("header.note")).toEqual({ move: [], type: ["It is shown only when NOTE applies."] });
    expect(fields.get("header.fixed")).toEqual({ move: [], type: ["It has fixed rows."] });

    // The reducer lets them change section, keeps them from changing type
    const moved = editReducer(s, { type: "moveFieldToSection", path: "header.preparer", sectionId: "body" });
    expect(moved.sections[1].fields.some((f) => f.id === "preparer")).toBe(true);
    const retyped = editReducer(s, { type: "setFieldType", path: "header.preparer", fieldType: "number" });
    expect(retyped.sections[0].fields.find((f) => f.id === "preparer")?.type).toBe("string");
  });

  it("sums up each lock in one plain line per cause", () => {
    const { fields, columns, causes } = computeLocks(advanced());
    const tip = (path: string) => lockTooltip(fields.get(path)?.type ?? [], causes);
    expect(tip("header.fee")).toBe("Locked because other fields depend on it."); // two formulas use it: one line
    expect(tip("header.copy")).toBe("Locked because it depends on other fields.");
    expect(tip("header.kind")).toBe("Locked because it decides which parts of the document appear.");
    expect(tip("header.memo_date")).toBe("Locked because one of its settings needs this type.");
    expect(tip("header.total")).toBe("Locked because it depends on other fields.");
    expect(lockTooltip(columns.get("header.items_local:line") ?? [], causes)).toBe("Locked because it depends on other fields.");
    expect(tip("body.items")).toBeUndefined();
  });

  it("locks columns used by formulas and totals", () => {
    const { columns } = computeLocks(advanced());
    expect(columns.get("header.items_local:qty")).toEqual(["header.sum's formula totals it.", "The Line formula uses it."]);
    expect(columns.get("header.items_local:price")?.length).toBeGreaterThan(0);
    expect(columns.get("header.items_local:line")?.length).toBeGreaterThan(0);
    expect(columns.get("body.items:qty")).toBeUndefined();
  });

  it("the reducer refuses to move or retype locked fields, but edits their label", () => {
    const s = advanced();
    expect(editReducer(s, { type: "moveFieldToSection", path: "header.kind", sectionId: "body" })).toEqual(s);
    expect(editReducer(s, { type: "setFieldType", path: "header.kind", fieldType: "string" })).toBe(s);
    expect(editReducer(s, { type: "setFieldType", path: "header.memo_date", fieldType: "string" })).toBe(s);
    const relabeled = editReducer(s, { type: "updateField", path: "header.kind", patch: { label: "Type", options: ["z"] } });
    expect(field(relabeled, "header.kind")).toMatchObject({ label: "Type", options: ["a", "b"] });
    expect(editReducer(s, { type: "setColumnType", path: "header.items_local", columnId: "qty", columnType: "string" })).toBe(s);
  });

  it("does not merge a section holding locked fields", () => {
    const s = advanced();
    expect(canMergeSection(s, "header", "body")).toBe(false);
    expect(editReducer(s, { type: "mergeSection", sectionId: "header", intoId: "body" })).toBe(s);
  });

  it("lists schema-level settings carried through untouched", () => {
    expect(lockedSchemaSettings(advanced())).toEqual(["Content blocks: SHOW_B, NOTE", "Constants: RATE"]);
  });
});
