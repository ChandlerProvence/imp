import type { FieldDef, NumberFormat, SectionDef } from "../../../schemas/types";
import ColumnEditor from "./ColumnEditor";
import OptionsEditor from "./OptionsEditor";
import LockedBadge from "./LockedBadge";
import { canHaveScalarType, SCALAR_TYPES, type EditAction, type FieldPatch, type ScalarType } from "./useTemplateEditor";
import { lockTooltip, type SchemaLocks } from "./locks";
import { TYPE_LABELS } from "./typeLabels";

export interface FieldTags {
  /** Template tags that render this field. */
  tags: string[];
  /** Some of those tags sit in a header or footer, where long text can't render. */
  inHeaderFooter: boolean;
  /** Column id → template tag, for table fields. */
  columnTags: Record<string, string>;
}

interface Props {
  section: SectionDef;
  field: FieldDef;
  sections: SectionDef[];
  locks: SchemaLocks;
  tags: FieldTags;
  isFirst: boolean;
  isLast: boolean;
  highlighted: boolean;
  /** The user clicked somewhere in the card. */
  onSelect?: (path: string) => void;
  dispatch: (action: EditAction) => void;
}

const input = "mt-0.5 block w-full rounded-md border border-gray-300 px-2 py-1 text-sm text-gray-900 disabled:bg-gray-100";
const small = "rounded-md border border-gray-300 bg-white px-2 py-1 text-xs text-gray-700 hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-40";

/** Everything the editor can change about one field. */
export default function FieldCard({ section, field, sections, locks, tags, isFirst, isLast, highlighted, onSelect, dispatch }: Props) {
  const path = `${section.id}.${field.id}`;
  const lock = locks.fields.get(path);
  const moveLocked = (lock?.move.length ?? 0) > 0;
  const typeLocked = (lock?.type.length ?? 0) > 0;
  const name = field.label || field.id;
  const patch = (p: FieldPatch) => dispatch({ type: "updateField", path, patch: p });

  return (
    <article
      id={`field-${path}`}
      data-testid="field-card"
      aria-label={name}
      onClick={() => onSelect?.(path)}
      className={`space-y-3 rounded-lg border bg-white p-4 shadow-sm ${highlighted ? "border-blue-400 ring-2 ring-blue-200" : "border-gray-200"}`}
    >
      <div className="flex flex-wrap items-end gap-3">
        <label className="min-w-[12rem] flex-1 text-xs text-gray-600">
          Label
          <input value={field.label} onChange={(e) => patch({ label: e.target.value })} className={input} />
        </label>
        <label className="text-xs text-gray-600" title={canHaveScalarType(field) ? lockTooltip(lock?.type ?? [], locks.causes) : undefined}>
          Type
          {canHaveScalarType(field) ? (
            <select
              value={field.type}
              disabled={typeLocked}
              onChange={(e) => dispatch({ type: "setFieldType", path, fieldType: e.target.value as ScalarType })}
              aria-label={`${name} type`}
              className={input}
            >
              {SCALAR_TYPES.map((t) => (
                <option
                  key={t}
                  value={t}
                  disabled={t === "freetext" && tags.inHeaderFooter && field.type !== "freetext"}
                  title={t === "freetext" && tags.inHeaderFooter ? "This tag is in a header or footer, where long text can't render." : undefined}
                >
                  {TYPE_LABELS[t]}
                </option>
              ))}
            </select>
          ) : (
            <span className="mt-0.5 block rounded-md border border-gray-200 bg-gray-50 px-2 py-1 text-sm text-gray-700">
              {TYPE_LABELS[field.type]}
            </span>
          )}
        </label>
        <label className="flex items-center gap-1 pb-1 text-xs text-gray-700">
          <input type="checkbox" checked={field.required} onChange={(e) => patch({ required: e.target.checked })} />
          Required
        </label>
      </div>

      <p className="text-xs text-gray-500">
        id {field.id}
        {tags.tags.length > 0 ? ` · fills ${tags.tags.map((t) => `{{${t}}}`).join(", ")}` : " · not used in the Word file"}
        {field.type === "table" ? " · a table repeats its row for each entry" : ""}
      </p>
      {tags.inHeaderFooter && field.type !== "freetext" && (
        <p className="text-xs text-gray-500">This tag is in a header or footer, so it can't be long text.</p>
      )}

      {field.type === "date" && (
        <label className="block text-xs text-gray-600">
          Date format in the document
          <select
            value={field.display_format ?? "MM-DD-YYYY"}
            onChange={(e) => patch({ display_format: e.target.value as FieldDef["display_format"] })}
            className={input}
          >
            <option value="MM-DD-YYYY">06-28-2028</option>
            <option value="long">June 28, 2028</option>
            <option value="short">Jun 28, 2028</option>
          </select>
        </label>
      )}
      {field.type === "number" && (
        <label className="block text-xs text-gray-600">
          Number format in the document
          <select
            value={field.format ?? ""}
            onChange={(e) => patch({ format: (e.target.value || undefined) as NumberFormat | undefined })}
            className={input}
          >
            <option value="">As entered</option>
            <option value="currency">Currency (12,300.00)</option>
            <option value="integer">Whole number (60)</option>
          </select>
        </label>
      )}
      {(field.type === "enum" || field.type === "multiselect") && (
        <div title={lockTooltip(lock?.type ?? [], locks.causes)}>
          <OptionsEditor label={name} options={field.options ?? []} disabled={typeLocked} onChange={(options) => patch({ options })} />
        </div>
      )}
      {field.type === "table" && (
        <ColumnEditor path={path} field={field} locks={locks} columnTags={tags.columnTags} dispatch={dispatch} />
      )}

      <label className="block text-xs text-gray-600">
        Hint for the AI assistant <span className="text-gray-400">(optional)</span>
        <textarea
          value={field.ai_hint ?? ""}
          onChange={(e) => patch({ ai_hint: e.target.value })}
          rows={2}
          className={input}
          placeholder="What belongs here, where to find it, how to phrase it"
        />
      </label>

      <div className="flex flex-wrap items-center gap-2">
        <button type="button" className={small} disabled={isFirst} onClick={() => dispatch({ type: "moveField", path, delta: -1 })} aria-label={`Move ${name} up`}>
          Move up
        </button>
        <button type="button" className={small} disabled={isLast} onClick={() => dispatch({ type: "moveField", path, delta: 1 })} aria-label={`Move ${name} down`}>
          Move down
        </button>
        {sections.length > 1 && (
          <span title={lockTooltip(lock?.move ?? [], locks.causes)}>
            <select
              value=""
              disabled={moveLocked}
              onChange={(e) => e.target.value && dispatch({ type: "moveFieldToSection", path, sectionId: e.target.value })}
              aria-label={`Move ${name} to section`}
              className="rounded-md border border-gray-300 px-2 py-1 text-xs text-gray-700 disabled:bg-gray-100"
            >
              <option value="">Move to section…</option>
              {sections
                .filter((s) => s.id !== section.id)
                .map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.title || s.id}
                  </option>
                ))}
            </select>
          </span>
        )}
      </div>
      {lock && (
        <LockedBadge
          reasons={lock.type}
          what={moveLocked ? "section, type, and choices" : "type and choices"}
        />
      )}
    </article>
  );
}
