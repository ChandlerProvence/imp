import { Link } from "react-router-dom";
import { EDITOR_HELP } from "./editorHelp";

/** Shows that part of a field is fixed by an advanced schema feature, and why. */
export default function LockedBadge({ reasons, what }: { reasons: string[]; what: string }) {
  if (reasons.length === 0) return null;
  return (
    <details className="text-xs text-amber-800">
      <summary className="inline-flex cursor-pointer list-none items-center gap-1 rounded-full bg-amber-100 px-2 py-0.5 font-medium">
        Locked: {what}
      </summary>
      <ul className="mt-1 list-disc space-y-0.5 pl-5">
        {reasons.map((r) => (
          <li key={r}>{r}</li>
        ))}
      </ul>
      <p className="mt-1 text-amber-700">
        This can only be changed in the template files.{" "}
        <Link to={EDITOR_HELP} target="_blank" className="font-medium underline">
          What the editor can't change
        </Link>
      </p>
    </details>
  );
}
