import { describe, it, expect, vi } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import TemplatePreview, { previewMarker, type PreviewFocus } from "./TemplatePreview";
import type { DocumentSchema, FieldDef } from "../../../schemas/types";
import { buildDocx, para } from "../../../test/docxFixtures";

// mammoth's Node build doesn't accept { arrayBuffer } (the browser build does)
vi.mock("mammoth", async () => {
  const { default: PizZip } = await import("pizzip");
  return {
    default: {
      convertToHtml: async ({ arrayBuffer }: { arrayBuffer: ArrayBuffer }) => {
        const xml = new PizZip(arrayBuffer).file("word/document.xml")!.asText();
        const paragraphs = [...xml.matchAll(/<w:p[ >][\s\S]*?<\/w:p>/g)].map(
          (p) => `<p>${[...p[0].matchAll(/<w:t[^>]*>([^<]*)<\/w:t>/g)].map((m) => m[1]).join("")}</p>`,
        );
        return { value: paragraphs.join("") };
      },
    },
  };
});

const schema: DocumentSchema = {
  id: "letter",
  title: "Letter",
  version: 1,
  docx_template: "letter.docx",
  sections: [
    {
      id: "main",
      title: "Main",
      fields: [
        { id: "vendor", label: "Vendor name", type: "string", required: false },
        { id: "signed", label: "Signed", type: "boolean", required: false },
      ],
    },
  ],
  template_key_map: { VENDOR: "main.vendor", SIGNED: "main.signed" },
};

const docx = () => {
  const bytes = buildDocx(para("Dear {{VENDOR}},") + para("Regards, {{VENDOR}}"));
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
};

function show(props: { docx?: ArrayBuffer; focus?: PreviewFocus | null; schema?: DocumentSchema } = {}) {
  return render(
    <TemplatePreview schema={props.schema ?? schema} docx={props.docx ?? docx()} active focus={props.focus ?? null} />,
  );
}

const preview = () => screen.getByTestId("template-preview");

describe("previewMarker", () => {
  const f = (over: Partial<FieldDef>): FieldDef => ({ id: "x", label: "X", type: "string", required: false, ...over });
  it("matches the placeholder answer for each type", () => {
    expect(previewMarker(f({}))).toBe("[X]");
    expect(previewMarker(f({ type: "enum", options: ["Yes", "No"] }))).toBe("Yes");
    expect(previewMarker(f({ type: "boolean" }))).toBeNull();
    expect(previewMarker(f({ formula: "1 + 1", format: "currency" }))).toBeNull();
    expect(
      previewMarker(f({ type: "table", columns: [{ id: "ok", label: "OK", type: "boolean" }, { id: "n", label: "Name", type: "string" }] })),
    ).toBe("[Name]");
  });
});

describe("TemplatePreview", () => {
  it("renders the Word file with bracketed labels", async () => {
    show();
    await waitFor(() => expect(preview().textContent).toContain("Dear [Vendor name],"), { timeout: 3000 });
    expect(preview().textContent).not.toContain("{{");
  });

  it("highlights a field's marker and steps through repeats", async () => {
    const { rerender } = show();
    await waitFor(() => expect(preview().textContent).toContain("Regards"), { timeout: 3000 });
    const rerenderWith = (focus: PreviewFocus) =>
      rerender(<TemplatePreview schema={schema} docx={docx()} active focus={focus} />);

    rerenderWith({ path: "main.vendor", seq: 1 });
    await waitFor(() => expect(preview().querySelector("[data-preview-marker]")?.textContent).toContain("Dear"));
    expect(screen.getByText(/Showing 1 of 2/)).toBeInTheDocument();

    rerenderWith({ path: "main.vendor", seq: 2 });
    await waitFor(() => expect(preview().querySelector("[data-preview-marker]")?.textContent).toContain("Regards"));
    expect(screen.getByText(/Showing 2 of 2/)).toBeInTheDocument();

    // A re-render after an edit stays on the occurrence the last click showed
    const renamed = structuredClone(schema);
    renamed.sections[0].fields[0].label = "Supplier";
    rerender(<TemplatePreview schema={renamed} docx={docx()} active focus={{ path: "main.vendor", seq: 2 }} />);
    await waitFor(() => expect(preview().querySelector("[data-preview-marker]")?.textContent).toBe("Regards, [Supplier]"), {
      timeout: 3000,
    });
    expect(screen.getByText(/Showing 2 of 2/)).toBeInTheDocument();
  });

  it("doesn't render while its tab is hidden", async () => {
    render(<TemplatePreview schema={schema} docx={docx()} active={false} focus={null} />);
    await new Promise((r) => setTimeout(r, 800));
    expect(screen.getByText("Building the preview…")).toBeInTheDocument();
  });

  it("explains fields with no visible marker", async () => {
    show({ focus: { path: "main.signed", seq: 1 } });
    expect(await screen.findByText(/yes\/no field/, undefined, { timeout: 3000 })).toBeInTheDocument();
  });

  it("shows render errors", async () => {
    show({ docx: new TextEncoder().encode("not a zip").buffer as ArrayBuffer });
    expect(await screen.findByText(/Copy Error Report/, undefined, { timeout: 3000 })).toBeInTheDocument();
    expect(screen.queryByTestId("template-preview")).not.toBeInTheDocument();
  });
});
