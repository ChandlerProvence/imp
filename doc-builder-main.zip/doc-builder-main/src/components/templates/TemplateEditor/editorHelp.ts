/** The help page for the template editor; its top section lists what the editor can't change. */
export const EDITOR_HELP = "/docs/help/template-editor";
