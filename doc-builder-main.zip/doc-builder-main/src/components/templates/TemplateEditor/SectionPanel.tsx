import type { SectionDef } from "../../../schemas/types";
import FieldCard, { type FieldTags } from "./FieldCard";
import { canMergeSection, type EditAction } from "./useTemplateEditor";
import type { SchemaLocks } from "./locks";
import type { DocumentSchema } from "../../../schemas/types";

interface Props {
  schema: DocumentSchema;
  section: SectionDef;
  index: number;
  locks: SchemaLocks;
  tagsFor: (path: string) => FieldTags;
  highlightedPath: string | null;
  onSelectField?: (path: string) => void;
  dispatch: (action: EditAction) => void;
}

const small = "rounded-md border border-gray-300 bg-white px-2 py-1 text-xs text-gray-700 hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-40";

/** One section: its title and order, merge/remove, and its fields. */
export default function SectionPanel({ schema, section, index, locks, tagsFor, highlightedPath, onSelectField, dispatch }: Props) {
  const { sections } = schema;
  const name = section.title || section.id;
  const others = sections.filter((s) => s.id !== section.id);
  // Fields that can't change section keep the whole section from merging
  const pinned = section.fields
    .filter((f) => locks.fields.get(`${section.id}.${f.id}`)?.move.length)
    .map((f) => f.label || f.id);
  const visibilityDiffers = (s: SectionDef) => s.visible_when !== section.visible_when;
  const canMergeAny = pinned.length === 0 && others.some((s) => canMergeSection(schema, section.id, s.id, locks));

  return (
    <section id={`section-${section.id}`} aria-label={`Section ${name}`} className="space-y-3 scroll-mt-4" data-testid="section-panel">
      <div className="rounded-lg border border-gray-200 bg-gray-100 p-3">
        <div className="flex flex-wrap items-end gap-2">
          <label className="min-w-[12rem] flex-1 text-xs text-gray-600">
            Section title
            <input
              value={section.title}
              onChange={(e) => dispatch({ type: "renameSection", sectionId: section.id, title: e.target.value })}
              className="mt-0.5 block w-full rounded-md border border-gray-300 px-2 py-1 text-sm font-medium text-gray-900"
            />
          </label>
          <button type="button" className={small} disabled={index === 0} onClick={() => dispatch({ type: "moveSection", sectionId: section.id, delta: -1 })} aria-label={`Move section ${name} up`}>
            Move up
          </button>
          <button
            type="button"
            className={small}
            disabled={index === sections.length - 1}
            onClick={() => dispatch({ type: "moveSection", sectionId: section.id, delta: 1 })}
            aria-label={`Move section ${name} down`}
          >
            Move down
          </button>
          {section.fields.length > 0 && others.length > 0 && (
            <span
              title={
                pinned.length > 0
                  ? `Locked because ${pinned.join(", ")} can't leave this section.`
                  : canMergeAny
                    ? undefined
                    : "Locked because the other sections are shown under different conditions."
              }
            >
              <select
                value=""
                disabled={!canMergeAny}
                onChange={(e) => e.target.value && dispatch({ type: "mergeSection", sectionId: section.id, intoId: e.target.value })}
                aria-label={`Merge section ${name} into`}
                className="rounded-md border border-gray-300 px-2 py-1 text-xs text-gray-700 disabled:bg-gray-100"
              >
                <option value="">Merge into…</option>
                {others.map((s) => (
                  <option
                    key={s.id}
                    value={s.id}
                    disabled={visibilityDiffers(s)}
                    title={visibilityDiffers(s) ? "Locked because this section is shown under different conditions." : undefined}
                  >
                    {s.title || s.id}
                  </option>
                ))}
              </select>
            </span>
          )}
          {section.fields.length === 0 && sections.length > 1 && (
            <button
              type="button"
              className="rounded-md border border-red-300 bg-white px-2 py-1 text-xs text-red-600 hover:bg-red-50"
              onClick={() => dispatch({ type: "removeSection", sectionId: section.id })}
            >
              Remove section
            </button>
          )}
        </div>
        <p className="mt-1 text-xs text-gray-500">
          id {section.id}
          {section.visible_when ? ` · shown only when ${section.visible_when} applies` : ""}
        </p>
      </div>

      {section.fields.length === 0 && (
        <p className="rounded-lg border border-dashed border-gray-300 bg-white p-4 text-center text-sm text-gray-500">
          No fields yet. Use “Move to section…” on a field to put it here, or remove this section.
        </p>
      )}
      {section.fields.map((field, i) => (
        <FieldCard
          key={field.id}
          section={section}
          field={field}
          sections={sections}
          locks={locks}
          tags={tagsFor(`${section.id}.${field.id}`)}
          isFirst={i === 0}
          isLast={i === section.fields.length - 1}
          highlighted={highlightedPath === `${section.id}.${field.id}`}
          onSelect={onSelectField}
          dispatch={dispatch}
        />
      ))}
    </section>
  );
}
