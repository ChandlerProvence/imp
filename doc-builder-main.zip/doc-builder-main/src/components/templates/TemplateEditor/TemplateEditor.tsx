import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import type { DocumentSchema } from "../../../schemas/types";
import type { Issue, TemplateScan } from "../../../schemas/templateScan";
import { resolveFieldPath } from "../../../schemas/templateScan";
import type { TemplateStructure } from "../../../schemas/templateStructure";
import type { PreparedTemplate } from "../../../schemas/userTemplateValidation";
import type { TemplateDraft, UserTemplate } from "../../../db/types";
import type { ScaffoldNote } from "../../../schemas/scaffoldSchema";
import { installDraft, validateEditedSchema } from "../../../schemas/templateDrafts";
import { countSessionsForSchema, installTemplate } from "../../../schemas/userSchemas";
import { getUserTemplate } from "../../../db/userTemplates";
import { putTemplateDraft } from "../../../db/templateDrafts";
import { trackWrite } from "../../../db/writeStatus";
import { buildFieldManifest, diffFieldManifests, type ManifestDiff } from "../../../schemas/fieldManifest";
import { toAppError, type AppError } from "../../../errors";
import { saveFile } from "../../../utils/fileSave";
import AppErrorBox from "../../AppErrorBox";
import ConfirmDialog from "../../ConfirmDialog";
import ValidationReport from "../ValidationReport";
import DiffSummary from "../DiffSummary";
import SectionList from "./SectionList";
import SectionPanel from "./SectionPanel";
import TemplateTagsPanel from "./TemplateTagsPanel";
import TemplatePreview, { type PreviewFocus } from "./TemplatePreview";
import type { FieldTags } from "./FieldCard";
import { useTemplateEditor } from "./useTemplateEditor";
import { lockedSchemaSettings } from "./locks";
import { EDITOR_HELP } from "./editorHelp";

export type EditorTarget = { kind: "draft"; draft: TemplateDraft } | { kind: "installed"; record: UserTemplate };

interface Props {
  target: EditorTarget;
  docx: ArrayBuffer;
  scan: TemplateScan;
  structure: TemplateStructure;
}

type SaveState =
  | { step: "idle" }
  /** `purpose` is what the click asked for: just a check, or a check followed by saving. */
  | { step: "checking"; purpose: "report" | "save" }
  | { step: "invalid"; issues: Issue[] }
  /** Check passed (warnings, if any, are in `issues`); nothing saved. */
  | { step: "checked"; issues: Issue[] }
  | { step: "confirm"; prepared: PreparedTemplate; issues: Issue[]; existing: UserTemplate; sessions: number; diff: ManifestDiff }
  | { step: "saving" }
  | { step: "error"; error: AppError };

type SideTab = "preview" | "tags";
const SIDE_TABS: { id: SideTab; label: string }[] = [
  { id: "preview", label: "Preview" },
  { id: "tags", label: "Tags" },
];

/** Draft autosave delay after the last change. */
const AUTOSAVE_MS = 500;

const button = "rounded-md border border-gray-300 bg-white px-3 py-1.5 text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-50";

/**
 * Form-based schema editor for a custom template or a draft. Every save runs
 * the upload validator; drafts autosave as the user works.
 */
export default function TemplateEditor({ target, docx, scan, structure }: Props) {
  const navigate = useNavigate();
  const initial = target.kind === "draft" ? target.draft.schema : target.record.schema;
  const { schema, dispatch, locks } = useTemplateEditor(initial);
  const [save, setSave] = useState<SaveState>({ step: "idle" });
  const [notes, setNotes] = useState<ScaffoldNote[]>(target.kind === "draft" ? target.draft.notes : []);
  const [highlighted, setHighlighted] = useState<string | null>(null);
  const [leaving, setLeaving] = useState(false);
  const [sideTab, setSideTab] = useState<SideTab>("preview");
  const [previewFocus, setPreviewFocus] = useState<PreviewFocus | null>(null);
  const dirty = schema !== initial;

  // ── Draft autosave ───────────────────────────────────────────────────────
  const pending = useRef<{ schema: DocumentSchema; notes: ScaffoldNote[] } | null>(null);
  /** Set once the draft is installed, so a late autosave can't re-create it. */
  const closed = useRef(false);
  const flush = useCallback(() => {
    const next = pending.current;
    pending.current = null;
    if (!next || closed.current || target.kind !== "draft") return;
    void trackWrite(putTemplateDraft({ ...target.draft, ...next, updatedAt: new Date().toISOString() }));
  }, [target]);

  useEffect(() => {
    if (target.kind !== "draft" || (schema === initial && notes === target.draft.notes)) return;
    pending.current = { schema, notes };
    const timer = setTimeout(flush, AUTOSAVE_MS);
    return () => clearTimeout(timer);
  }, [schema, notes, initial, target, flush]);
  // Write the last change when leaving the page
  useEffect(() => () => flush(), [flush]);

  // ── Unsaved changes on an installed template ─────────────────────────────
  useEffect(() => {
    if (target.kind !== "installed" || !dirty) return;
    const onBeforeUnload = (e: BeforeUnloadEvent) => e.preventDefault();
    window.addEventListener("beforeunload", onBeforeUnload);
    return () => window.removeEventListener("beforeunload", onBeforeUnload);
  }, [target.kind, dirty]);

  // A check result or confirmation is for the schema as checked; editing again clears it
  const checkedSchema = useRef<DocumentSchema | null>(null);
  useEffect(() => {
    if ((save.step === "confirm" || save.step === "checked") && checkedSchema.current !== schema) setSave({ step: "idle" });
  }, [schema, save.step]);

  // ── Tags per field ───────────────────────────────────────────────────────
  const tagsByPath = useMemo(() => {
    const map = new Map<string, FieldTags>();
    for (const [tag, value] of Object.entries(schema.template_key_map ?? {})) {
      const path = resolveFieldPath(value);
      const entry = map.get(path) ?? { tags: [], inHeaderFooter: false, columnTags: {} };
      entry.tags.push(tag);
      if (scan.headerFooterTags.has(tag)) entry.inHeaderFooter = true;
      for (const [colTag, colId] of Object.entries(schema.template_column_map?.[tag] ?? {})) entry.columnTags[colId] = colTag;
      map.set(path, entry);
    }
    return map;
  }, [schema.template_key_map, schema.template_column_map, scan]);
  const tagsFor = useCallback(
    (path: string): FieldTags => tagsByPath.get(path) ?? { tags: [], inHeaderFooter: false, columnTags: {} },
    [tagsByPath],
  );

  const settings = useMemo(() => lockedSchemaSettings(schema), [schema]);
  const originalId = target.kind === "installed" ? target.record.originalId : schema.id;

  function scrollTo(elementId: string) {
    document.getElementById(elementId)?.scrollIntoView?.({ behavior: "smooth", block: "start" });
  }
  /** A click inside a field card: find that field in the preview. */
  function showInPreview(path: string) {
    setHighlighted(path);
    setSideTab("preview");
    setPreviewFocus((prev) => ({ path, seq: (prev?.seq ?? 0) + 1 }));
  }
  /** A click on a tag's field: bring up its card and its place in the preview. */
  function selectField(path: string) {
    showInPreview(path);
    scrollTo(`field-${path}`);
  }

  // ── Check and save ───────────────────────────────────────────────────────
  const validate = () => validateEditedSchema(schema, docx, { allowBuiltInId: target.kind === "installed" });

  /** Run the upload checks and report; nothing is saved. */
  async function check() {
    setSave({ step: "checking", purpose: "report" });
    try {
      const result = await validate();
      if (!result.ok || !result.prepared) {
        setSave({ step: "invalid", issues: result.issues });
        return;
      }
      checkedSchema.current = schema;
      setSave({ step: "checked", issues: result.issues });
    } catch (err) {
      setSave({ step: "error", error: toAppError(err, { domain: "db" }) });
    }
  }

  /** Run the same checks, then save if they pass (asking first when it replaces a template). */
  async function checkAndSave() {
    setSave({ step: "checking", purpose: "save" });
    try {
      const result = await validate();
      if (!result.ok || !result.prepared) {
        setSave({ step: "invalid", issues: result.issues });
        return;
      }
      const existing = await getUserTemplate(result.prepared.id);
      if (existing) {
        checkedSchema.current = schema;
        setSave({
          step: "confirm",
          prepared: result.prepared,
          issues: result.issues,
          existing,
          sessions: await countSessionsForSchema(existing.id),
          diff: diffFieldManifests(buildFieldManifest(existing.schema), buildFieldManifest(result.prepared.schema)),
        });
        return;
      }
      await install(result.prepared);
    } catch (err) {
      setSave({ step: "error", error: toAppError(err, { domain: "db" }) });
    }
  }

  async function install(prepared: PreparedTemplate) {
    setSave({ step: "saving" });
    try {
      let record: UserTemplate;
      if (target.kind === "draft") {
        closed.current = true;
        const result = await installDraft(target.draft, schema);
        if (!result.record) {
          closed.current = false;
          setSave({ step: "invalid", issues: result.validation.issues });
          return;
        }
        record = result.record;
      } else {
        record = await installTemplate(prepared, { basedOn: target.record.basedOn });
      }
      const notice =
        record.revision > 1
          ? `Saved "${record.schema.title}" (revision ${record.revision}).`
          : `Added "${record.schema.title}". It's listed under Custom Templates on the home page.`;
      navigate("/templates", { state: { notice } });
    } catch (err) {
      closed.current = false;
      setSave({ step: "error", error: toAppError(err, { domain: "db" }) });
    }
  }

  async function downloadSchema() {
    const out = structuredClone(schema) as DocumentSchema & Record<string, unknown>;
    out.id = originalId;
    out.docx_template = `${originalId}.docx`;
    delete out.category;
    await saveFile({
      blob: new Blob([JSON.stringify(out, null, 2) + "\n"], { type: "application/json;charset=utf-8" }),
      filename: `${originalId}.schema.json`,
      types: [{ description: "Schema", accept: { "application/json": [".json"] } }],
    });
  }

  function back() {
    if (target.kind === "installed" && dirty) setLeaving(true);
    else navigate("/templates");
  }

  const busy = save.step === "checking" || save.step === "saving";

  return (
    // Sized by the editor's own width: the AI panel and sidebar can leave it narrow on a wide screen
    <div className="@container h-full overflow-y-auto bg-gray-50">
      <header className="sticky top-0 z-10 border-b border-gray-200 bg-white px-4 py-3">
        <div className="mx-auto flex max-w-7xl flex-wrap items-end gap-3">
          <div className="min-w-[16rem] flex-1">
            <button type="button" onClick={back} className="text-xs text-blue-600 hover:text-blue-800">
              ← Custom templates
            </button>
            <label className="mt-1 block text-xs text-gray-600">
              Template name
              <input
                value={schema.title}
                onChange={(e) => dispatch({ type: "setTitle", title: e.target.value })}
                className="mt-0.5 block w-full rounded-md border border-gray-300 px-2 py-1 text-lg font-semibold text-gray-900"
              />
            </label>
          </div>
          {target.kind === "draft" ? (
            <label className="text-xs text-gray-600">
              Template id
              <input
                value={schema.id}
                onChange={(e) => dispatch({ type: "setId", id: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "-") })}
                className="mt-0.5 block w-56 rounded-md border border-gray-300 px-2 py-1 font-mono text-sm text-gray-900"
              />
            </label>
          ) : (
            <p className="pb-1 text-xs text-gray-500">
              id {originalId} · revision {target.record.revision}
            </p>
          )}
          <div className="flex gap-2">
            <button type="button" className={button} onClick={() => void downloadSchema()}>
              Download schema JSON
            </button>
            <button type="button" className={button} disabled={busy} onClick={() => void check()}>
              {save.step === "checking" && save.purpose === "report" ? "Checking…" : "Check"}
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={() => void checkAndSave()}
              className="rounded-md bg-blue-600 px-4 py-1.5 text-sm font-medium text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {(save.step === "checking" && save.purpose === "save") || save.step === "saving" ? "Saving…" : "Save"}
            </button>
          </div>
        </div>
        <p className="mx-auto mt-1 max-w-7xl text-xs text-gray-500">
          {target.kind === "draft"
            ? `Draft from ${target.draft.sourceName}. Changes are kept in this browser as you work; Save checks the template and adds it.`
            : dirty
              ? "Unsaved changes. Save to keep them."
              : "Change labels, types, and sections, then Save."}{" "}
          <Link to={EDITOR_HELP} target="_blank" className="text-blue-600 hover:text-blue-800">
            How the editor works
          </Link>
        </p>
      </header>

      <div className="mx-auto max-w-7xl space-y-4 px-4 py-4">
        {notes.length > 0 && (
          <div className="rounded-lg border border-blue-200 bg-blue-50 p-3 text-sm text-blue-900" role="status">
            <p className="font-medium">Built from the tags in your Word file. Check these:</p>
            <ul className="mt-1 list-disc space-y-0.5 pl-5">
              {notes.map((n, i) => (
                <li key={i}>{n.message}</li>
              ))}
            </ul>
            <button type="button" onClick={() => setNotes([])} className="mt-2 text-xs font-medium text-blue-700 hover:text-blue-900">
              Dismiss
            </button>
          </div>
        )}

        {save.step === "invalid" && (
          <div className="space-y-2" data-testid="editor-validation">
            <p className="text-sm font-medium text-red-800">The template can't be saved yet.</p>
            <ValidationReport issues={save.issues} />
          </div>
        )}
        {save.step === "checked" && (
          <div className="space-y-2 rounded-lg border border-green-200 bg-green-50 p-3 text-sm text-green-900" data-testid="editor-checked" role="status">
            <p className="font-medium">
              No problems found. {target.kind === "draft" ? "Save to add the template." : dirty ? "Save to keep your changes." : ""}
            </p>
            <ValidationReport issues={save.issues} />
          </div>
        )}
        {save.step === "error" && <AppErrorBox error={save.error} />}
        {save.step === "confirm" && (
          <div className="space-y-2 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900" data-testid="editor-confirm">
            <ValidationReport issues={save.issues} />
            <p>
              {target.kind === "installed"
                ? `This replaces revision ${save.existing.revision}. `
                : `You already have a custom template with the id "${save.existing.originalId}" ("${save.existing.schema.title}"). Saving replaces it. Change the template id to keep both. `}
              {save.sessions > 0
                ? `${save.sessions} saved document${save.sessions === 1 ? " uses" : "s use"} it and will switch to the new version.`
                : "No saved documents use it."}
            </p>
            <DiffSummary diff={save.diff} />
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => void install(save.prepared)}
                className="rounded-md bg-blue-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-blue-700"
              >
                {target.kind === "installed" ? "Save changes" : "Replace it"}
              </button>
              <button type="button" className={button} onClick={() => setSave({ step: "idle" })}>
                Keep editing
              </button>
            </div>
          </div>
        )}

        <div className="grid gap-6 @4xl:grid-cols-[12rem_minmax(0,1fr)_minmax(17rem,32rem)]">
          <div className="@4xl:sticky @4xl:top-36 @4xl:self-start">
            <SectionList sections={schema.sections} onSelect={(id) => scrollTo(`section-${id}`)} dispatch={dispatch} />
            {settings.length > 0 && (
              <div className="mt-4 space-y-1 text-xs text-gray-600">
                <h2 className="font-semibold uppercase tracking-wide text-gray-500">Kept as is</h2>
                <ul className="list-disc space-y-0.5 pl-4">
                  {settings.map((s) => (
                    <li key={s}>{s}</li>
                  ))}
                </ul>
                <p className="text-gray-500">
                  These can only be changed in the template files.{" "}
                  <Link to={EDITOR_HELP} target="_blank" className="text-blue-600 hover:text-blue-800">
                    What the editor can't change
                  </Link>
                </p>
              </div>
            )}
          </div>
          <div className="space-y-8">
            {schema.sections.map((section, i) => (
              <SectionPanel
                key={section.id}
                schema={schema}
                section={section}
                index={i}
                locks={locks}
                tagsFor={tagsFor}
                highlightedPath={highlighted}
                onSelectField={showInPreview}
                dispatch={dispatch}
              />
            ))}
          </div>
          <div className="flex flex-col gap-2 @4xl:sticky @4xl:top-36 @4xl:h-[calc(100vh-12rem)] @4xl:self-start">
            <div role="tablist" aria-label="Word file" className="flex gap-1 border-b border-gray-200">
              {SIDE_TABS.map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  role="tab"
                  id={`side-tab-${tab.id}`}
                  aria-selected={sideTab === tab.id}
                  aria-controls={`side-panel-${tab.id}`}
                  onClick={() => setSideTab(tab.id)}
                  className={`-mb-px border-b-2 px-3 py-1.5 text-sm font-medium ${
                    sideTab === tab.id ? "border-blue-600 text-blue-700" : "border-transparent text-gray-500 hover:text-gray-700"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
            {/* Both panels stay mounted so switching tabs keeps the last render */}
            <div role="tabpanel" id="side-panel-preview" aria-labelledby="side-tab-preview" hidden={sideTab !== "preview"} className="min-h-0 flex-1">
              <TemplatePreview schema={schema} docx={docx} active={sideTab === "preview"} focus={previewFocus} />
            </div>
            <div role="tabpanel" id="side-panel-tags" aria-labelledby="side-tab-tags" hidden={sideTab !== "tags"} className="min-h-0 flex-1 overflow-y-auto">
              <TemplateTagsPanel schema={schema} scan={scan} structure={structure} onSelectField={selectField} />
            </div>
          </div>
        </div>
      </div>

      <ConfirmDialog
        open={leaving}
        title="Discard your changes?"
        message="You haven't saved your changes to this template."
        confirmLabel="Discard changes"
        destructive
        onConfirm={() => navigate("/templates")}
        onCancel={() => setLeaving(false)}
      />
    </div>
  );
}
