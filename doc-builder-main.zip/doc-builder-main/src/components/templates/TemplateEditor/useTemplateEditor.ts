/**
 * State for the template editor: a reducer over the schema. Only the keys
 * the editor owns are touched; everything else (advanced features, unknown
 * keys) carries through unchanged. Ids of existing sections, fields, and
 * columns never change except to stay unique when a field moves into a
 * section that already has one by that name, and every path change goes
 * through `retargetFieldPath()`.
 */
import { useMemo, useReducer } from "react";
import type {
  DocumentSchema,
  FieldDef,
  FieldType,
  SectionDef,
  TableColumnDef,
  TableColumnType,
} from "../../../schemas/types";
import { toSnakeId, uniqueId } from "../../../schemas/naming";
import { computeLocks, columnKey, type SchemaLocks } from "./locks";

/** Types a field mapped to a plain `{{TAG}}` can take. */
export const SCALAR_TYPES = ["string", "number", "boolean", "date", "enum", "multiselect", "freetext"] as const;
export type ScalarType = (typeof SCALAR_TYPES)[number];
export const COLUMN_TYPES: TableColumnType[] = ["string", "number", "date", "enum", "boolean"];

export type FieldPatch = Partial<Pick<FieldDef, "label" | "required" | "ai_hint" | "options" | "display_format" | "format">>;
export type ColumnPatch = Partial<Pick<TableColumnDef, "label" | "required" | "options" | "format">>;

export type EditAction =
  | { type: "replace"; schema: DocumentSchema }
  | { type: "setTitle"; title: string }
  | { type: "setId"; id: string }
  | { type: "renameSection"; sectionId: string; title: string }
  | { type: "moveSection"; sectionId: string; delta: -1 | 1 }
  | { type: "addSection"; title: string }
  | { type: "removeSection"; sectionId: string }
  | { type: "mergeSection"; sectionId: string; intoId: string }
  | { type: "updateField"; path: string; patch: FieldPatch }
  | { type: "setFieldType"; path: string; fieldType: ScalarType }
  | { type: "moveField"; path: string; delta: -1 | 1 }
  | { type: "moveFieldToSection"; path: string; sectionId: string }
  | { type: "updateColumn"; path: string; columnId: string; patch: ColumnPatch }
  | { type: "setColumnType"; path: string; columnId: string; columnType: TableColumnType };

// ---------------------------------------------------------------------------
// Path helpers
// ---------------------------------------------------------------------------

export function splitPath(path: string): [string, string] {
  const dot = path.indexOf(".");
  return [path.slice(0, dot), path.slice(dot + 1)];
}

function locate(schema: DocumentSchema, path: string): { section: SectionDef; index: number; field: FieldDef } | undefined {
  const [sectionId, fieldId] = splitPath(path);
  const section = schema.sections.find((s) => s.id === sectionId);
  const index = section?.fields.findIndex((f) => f.id === fieldId) ?? -1;
  if (!section || index < 0) return undefined;
  return { section, index, field: section.fields[index] };
}

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/**
 * Point every reference to the field at `from` to `to`: template_key_map
 * (string and `{ field }` forms), output_filename placeholders, and same_as.
 * Mutates `schema`.
 */
export function retargetFieldPath(schema: DocumentSchema, from: string, to: string): void {
  if (from === to) return;
  const tkm = schema.template_key_map;
  if (tkm) {
    for (const [tag, value] of Object.entries(tkm)) {
      if (value === from) tkm[tag] = to;
      else if (typeof value === "object" && value?.field === from) tkm[tag] = { ...value, field: to };
    }
  }
  if (schema.output_filename) {
    schema.output_filename = schema.output_filename.replace(
      // nosemgrep: eslint.detect-non-literal-regexp — `from` is escaped by escapeRegExp, so the pattern is a fixed literal match
      new RegExp(`\\{\\{\\s*${escapeRegExp(from)}\\s*\\}\\}`, "g"),
      `{{${to}}}`,
    );
  }
  for (const section of schema.sections) {
    for (const field of section.fields) if (field.same_as === from) field.same_as = to;
  }
}

/** Set or delete keys: `undefined` and "" (for optional text) remove the key. */
function applyPatch<T extends object>(target: T, patch: Partial<T>, removeEmpty: (keyof T)[] = []): void {
  for (const [key, value] of Object.entries(patch) as [keyof T, T[keyof T] | undefined][]) {
    if (value === undefined || (removeEmpty.includes(key) && value === ("" as unknown))) delete target[key];
    else target[key] = value as T[keyof T];
  }
}

// ---------------------------------------------------------------------------
// Reducer
// ---------------------------------------------------------------------------

/** True when a field can be retyped to `type` (ignores locks). */
export function canHaveScalarType(field: FieldDef): boolean {
  return field.type !== "table" && field.type !== "image";
}

function moveField(schema: DocumentSchema, path: string, targetId: string, locks: SchemaLocks): void {
  const found = locate(schema, path);
  const target = schema.sections.find((s) => s.id === targetId);
  if (!found || !target || target === found.section || locks.fields.get(path)?.move.length) return;
  found.section.fields.splice(found.index, 1);
  const field = found.field;
  field.id = uniqueId(field.id, new Set(target.fields.map((f) => f.id)));
  target.fields.push(field);
  retargetFieldPath(schema, path, `${target.id}.${field.id}`);
}

export function editReducer(state: DocumentSchema, action: EditAction): DocumentSchema {
  if (action.type === "replace") return action.schema;
  const schema = structuredClone(state);
  const locks = computeLocks(state);

  switch (action.type) {
    case "setTitle":
      schema.title = action.title;
      break;
    case "setId":
      schema.id = action.id;
      schema.docx_template = `${action.id}.docx`;
      break;
    case "renameSection": {
      const section = schema.sections.find((s) => s.id === action.sectionId);
      if (section) section.title = action.title;
      break;
    }
    case "moveSection": {
      const i = schema.sections.findIndex((s) => s.id === action.sectionId);
      const j = i + action.delta;
      if (i < 0 || j < 0 || j >= schema.sections.length) return state;
      [schema.sections[i], schema.sections[j]] = [schema.sections[j], schema.sections[i]];
      break;
    }
    case "addSection": {
      const title = action.title.trim() || "New section";
      const id = uniqueId(toSnakeId(title, "section"), new Set(schema.sections.map((s) => s.id)));
      schema.sections.push({ id, title, fields: [] });
      break;
    }
    case "removeSection": {
      const i = schema.sections.findIndex((s) => s.id === action.sectionId);
      if (i < 0 || schema.sections[i].fields.length > 0 || schema.sections.length === 1) return state;
      schema.sections.splice(i, 1);
      break;
    }
    case "mergeSection": {
      if (!canMergeSection(state, action.sectionId, action.intoId, locks)) return state;
      const source = schema.sections.find((s) => s.id === action.sectionId)!;
      for (const field of [...source.fields]) moveField(schema, `${source.id}.${field.id}`, action.intoId, locks);
      schema.sections = schema.sections.filter((s) => s.id !== source.id);
      break;
    }
    case "updateField": {
      const found = locate(schema, action.path);
      if (!found) return state;
      const patch = { ...action.patch };
      if (locks.fields.get(action.path)?.type.length) delete patch.options;
      applyPatch(found.field, patch, ["ai_hint"]);
      break;
    }
    case "setFieldType": {
      const found = locate(schema, action.path);
      if (!found || !canHaveScalarType(found.field) || locks.fields.get(action.path)?.type.length) return state;
      const field = found.field;
      const next: FieldType = action.fieldType;
      if (field.type === next) return state;
      field.type = next;
      if (next === "enum" || next === "multiselect") field.options ??= [];
      else delete field.options;
      if (next !== "date") delete field.display_format;
      if (next !== "number") delete field.format;
      break;
    }
    case "moveField": {
      const found = locate(schema, action.path);
      if (!found) return state;
      const j = found.index + action.delta;
      if (j < 0 || j >= found.section.fields.length) return state;
      const fields = found.section.fields;
      [fields[found.index], fields[j]] = [fields[j], fields[found.index]];
      break;
    }
    case "moveFieldToSection":
      moveField(schema, action.path, action.sectionId, locks);
      break;
    case "updateColumn": {
      const col = locate(schema, action.path)?.field.columns?.find((c) => c.id === action.columnId);
      if (!col) return state;
      const patch = { ...action.patch };
      if (locks.columns.get(columnKey(action.path, action.columnId))?.length) delete patch.options;
      applyPatch(col, patch);
      break;
    }
    case "setColumnType": {
      const col = locate(schema, action.path)?.field.columns?.find((c) => c.id === action.columnId);
      if (!col || col.type === action.columnType || locks.columns.get(columnKey(action.path, action.columnId))?.length) {
        return state;
      }
      col.type = action.columnType;
      if (col.type === "enum") col.options ??= [];
      else delete col.options;
      if (col.type !== "number") delete col.format;
      break;
    }
  }
  return schema;
}

/** A section merges into another when none of its fields are locked in place. */
export function canMergeSection(schema: DocumentSchema, sectionId: string, intoId: string, locks = computeLocks(schema)): boolean {
  const source = schema.sections.find((s) => s.id === sectionId);
  const target = schema.sections.find((s) => s.id === intoId);
  if (!source || !target || source === target) return false;
  // Merging would change when the moved fields are shown
  if (source.visible_when !== target.visible_when) return false;
  return source.fields.every((f) => !locks.fields.get(`${source.id}.${f.id}`)?.move.length);
}

export interface TemplateEditorState {
  schema: DocumentSchema;
  dispatch: (action: EditAction) => void;
  locks: SchemaLocks;
}

export function useTemplateEditor(initial: DocumentSchema): TemplateEditorState {
  const [schema, dispatch] = useReducer(editReducer, initial);
  const locks = useMemo(() => computeLocks(schema), [schema]);
  return { schema, dispatch, locks };
}
