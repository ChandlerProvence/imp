interface Props {
  options: string[];
  onChange: (options: string[]) => void;
  disabled?: boolean;
  /** Accessible name prefix, e.g. the field label. */
  label: string;
}

/** Edit the choices of an enum or multiselect field (or an enum column). */
export default function OptionsEditor({ options, onChange, disabled, label }: Props) {
  const set = (i: number, value: string) => onChange(options.map((o, j) => (j === i ? value : o)));
  const remove = (i: number) => onChange(options.filter((_, j) => j !== i));
  const duplicates = options.filter((o, i) => o.trim() && options.indexOf(o) !== i);

  return (
    <fieldset className="space-y-1" disabled={disabled}>
      <legend className="text-xs font-medium text-gray-600">Choices</legend>
      {options.map((option, i) => (
        <div key={i} className="flex gap-2">
          <input
            value={option}
            onChange={(e) => set(i, e.target.value)}
            aria-label={`${label} choice ${i + 1}`}
            className="min-w-0 flex-1 rounded-md border border-gray-300 px-2 py-1 text-sm disabled:bg-gray-100"
          />
          <button
            type="button"
            onClick={() => remove(i)}
            aria-label={`Remove ${label} choice ${i + 1}`}
            className="rounded-md px-2 text-xs text-gray-500 hover:text-red-600 disabled:opacity-50"
          >
            Remove
          </button>
        </div>
      ))}
      <button
        type="button"
        onClick={() => onChange([...options, ""])}
        className="text-xs font-medium text-blue-600 hover:text-blue-800 disabled:opacity-50"
      >
        Add a choice
      </button>
      {options.length === 0 && <p className="text-xs text-amber-700">Add at least one choice.</p>}
      {duplicates.length > 0 && <p className="text-xs text-amber-700">Each choice should appear once.</p>}
    </fieldset>
  );
}
