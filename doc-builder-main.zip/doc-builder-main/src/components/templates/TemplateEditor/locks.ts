/**
 * Which fields and columns the template editor may restructure. A field that
 * uses an advanced schema feature, or that another part of the schema points
 * at, keeps its place and type: moving or retyping it would silently break
 * the feature. Its label, hint, and required flag stay editable.
 */
import type { DocumentSchema, FieldDef } from "../../../schemas/types";
import { isConditionalBlock } from "../../../schemas/types";
import { buildCalcGraph } from "../../../engine/formula/graph";
import { referencesOf } from "../../../engine/formula/parser";
import { resolveAggregate, resolveName } from "../../../engine/formula/scope";

export interface FieldLock {
  /** Reasons the field can't move to another place or section. */
  move: string[];
  /** Reasons its type (and options) can't change. Includes every move reason. */
  type: string[];
}

/**
 * What a lock reason comes down to, for the one-line tooltip:
 * - `dependents`: another field copies it, or a formula uses it
 * - `block`: a content block checks it to decide which text appears
 * - `depends`: it is calculated from or copies other fields (or columns)
 * - `setting`: a setting on it (profile fill, fixed rows, conditional display,
 *   validation, fixed date format) needs its current type
 */
export type LockCause = "dependents" | "block" | "depends" | "setting";

export interface SchemaLocks {
  /** By field path ("section.field"); only locked fields appear. */
  fields: Map<string, FieldLock>;
  /** By `${fieldPath}:${columnId}`; reasons the column's type can't change. */
  columns: Map<string, string[]>;
  /** The cause behind each reason text. */
  causes: Map<string, LockCause>;
}

export const columnKey = (fieldPath: string, columnId: string) => `${fieldPath}:${columnId}`;

/**
 * Features a field carries itself that hold a path or a sibling id, so the
 * field has to stay where it is. (`validate` stays here because a `compare`
 * rule names another field; a `range` rule alone wouldn't need it.)
 */
function ownMoveReasons(field: FieldDef): [string, LockCause][] {
  const reasons: [string, LockCause][] = [];
  if (field.formula !== undefined) reasons.push(["It is calculated from other fields.", "depends"]);
  if (field.same_as) reasons.push([`It copies ${field.same_as}.`, "depends"]);
  if (field.validate?.length) reasons.push(["It has validation rules.", "setting"]);
  return reasons;
}

/**
 * Features that move with the field but depend on its type: the profile
 * fills a string, fixed rows need a table, and a block condition
 * tests the field's current type.
 */
function ownTypeReasons(field: FieldDef): [string, LockCause][] {
  const reasons: [string, LockCause][] = [];
  if (field.auto_fill) reasons.push(["It is filled in from the user's profile.", "setting"]);
  if (field.rows?.length) reasons.push(["It has fixed rows.", "setting"]);
  if (field.visible_when) reasons.push([`It is shown only when ${field.visible_when} applies.`, "setting"]);
  return reasons;
}

export function computeLocks(schema: DocumentSchema): SchemaLocks {
  const move = new Map<string, Set<string>>();
  const typeOnly = new Map<string, Set<string>>();
  const columns = new Map<string, Set<string>>();
  const causes = new Map<string, LockCause>();
  const add = (map: Map<string, Set<string>>, key: string, reason: string, cause: LockCause) => {
    if (!map.has(key)) map.set(key, new Set());
    map.get(key)!.add(reason);
    causes.set(reason, cause);
  };

  const allPaths = new Set<string>();
  for (const section of schema.sections) for (const f of section.fields) allPaths.add(`${section.id}.${f.id}`);

  for (const section of schema.sections) {
    for (const field of section.fields) {
      const path = `${section.id}.${field.id}`;
      for (const [r, cause] of ownMoveReasons(field)) add(move, path, r, cause);
      for (const [r, cause] of ownTypeReasons(field)) add(typeOnly, path, r, cause);

      if (field.same_as && allPaths.has(field.same_as)) add(move, field.same_as, `${path} copies it.`, "dependents");

      // Columns of this table
      for (const col of field.columns ?? []) {
        const key = columnKey(path, col.id);
        if (col.formula) add(columns, key, "It is calculated from other columns.", "depends");
        if (col.validate?.length) add(columns, key, "It has validation rules.", "setting");
        if (col.visible_when) add(columns, key, `It is shown only when ${col.visible_when} applies.`, "setting");
      }
    }
  }

  // What each formula reads, resolved exactly as the evaluator resolves it
  const graph = buildCalcGraph(schema);
  for (const node of graph.nodes.values()) {
    if (!node.ast) continue;
    const refs = referencesOf(node.ast);
    const tablePath = `${node.place.section}.${node.place.field}`;
    const user = node.kind === "field" ? `${node.id}'s formula` : `The ${node.def.label} formula`;
    for (const name of refs.names) {
      const r = resolveName(graph.index, node.place, name);
      if (!r.ok) continue;
      if (r.target.kind === "field") add(move, r.target.key, `${user} uses it.`, "dependents");
      if (r.target.kind === "column") add(columns, columnKey(tablePath, r.target.id), `${user} uses it.`, "dependents");
    }
    for (const agg of refs.aggregates) {
      const r = resolveAggregate(graph.index, node.place, agg);
      if (!r.ok) continue;
      add(move, r.target.key, `${user} totals one of its columns.`, "dependents");
      if (r.target.column) add(columns, columnKey(r.target.key, r.target.column.id), `${user} totals it.`, "dependents");
    }
  }

  for (const [name, value] of Object.entries(schema.content_blocks ?? {})) {
    if (isConditionalBlock(value) && allPaths.has(value.when.field)) {
      add(move, value.when.field, `It decides the content block ${name}.`, "block");
    }
  }

  for (const [tag, value] of Object.entries(schema.template_key_map ?? {})) {
    if (typeof value === "object" && value?.date_format && allPaths.has(value.field)) {
      add(typeOnly, value.field, `The {{${tag}}} tag is set to a fixed date format.`, "setting");
    }
  }

  const fields = new Map<string, FieldLock>();
  for (const path of new Set([...move.keys(), ...typeOnly.keys()])) {
    const m = [...(move.get(path) ?? [])];
    fields.set(path, { move: m, type: [...m, ...(typeOnly.get(path) ?? [])] });
  }
  return {
    fields,
    columns: new Map([...columns].map(([k, v]) => [k, [...v]])),
    causes,
  };
}

const CAUSE_TEXT: Record<LockCause, string> = {
  dependents: "Locked because other fields depend on it.",
  block: "Locked because it decides which parts of the document appear.",
  depends: "Locked because it depends on other fields.",
  setting: "Locked because one of its settings needs this type.",
};

/**
 * Hover text for a locked control: one plain line per cause; the Locked
 * badge has the details. Goes on a wrapper, since some browsers show no
 * tooltip on a disabled control.
 */
export function lockTooltip(reasons: string[], causes: Map<string, LockCause>): string | undefined {
  const found = new Set(reasons.map((r) => causes.get(r) ?? "setting"));
  if (found.size === 0) return undefined;
  return (Object.keys(CAUSE_TEXT) as LockCause[])
    .filter((c) => found.has(c))
    .map((c) => CAUSE_TEXT[c])
    .join("\n");
}

/** Schema-level advanced settings the editor carries through untouched. */
export function lockedSchemaSettings(schema: DocumentSchema): string[] {
  const out: string[] = [];
  const blocks = Object.keys(schema.content_blocks ?? {});
  if (blocks.length) out.push(`Content blocks: ${blocks.join(", ")}`);
  const constants = Object.keys(schema.constants ?? {});
  if (constants.length) out.push(`Constants: ${constants.join(", ")}`);
  if (schema.toc) out.push("Table of contents");
  if (schema.heading_style_map && Object.keys(schema.heading_style_map).length) out.push("Heading styles");
  if (schema.recommended_uploads?.length) out.push(`Recommended uploads: ${schema.recommended_uploads.map((u) => u.title).join(", ")}`);
  if (schema.reference_docs?.length) out.push(`Reference documents: ${schema.reference_docs.map((d) => d.title).join(", ")}`);
  if (schema.download_hints?.length) out.push("Download hints");
  return out;
}
