import { useState } from "react";
import type { SectionDef } from "../../../schemas/types";
import type { EditAction } from "./useTemplateEditor";

interface Props {
  sections: SectionDef[];
  onSelect: (sectionId: string) => void;
  dispatch: (action: EditAction) => void;
}

/** Outline of the sections (jump to one) and a box to add a new one. */
export default function SectionList({ sections, onSelect, dispatch }: Props) {
  const [title, setTitle] = useState("");
  function add() {
    dispatch({ type: "addSection", title });
    setTitle("");
  }
  return (
    <nav aria-label="Sections" className="space-y-3">
      <h2 className="text-xs font-semibold uppercase tracking-wide text-gray-500">Sections</h2>
      <ol className="space-y-1">
        {sections.map((s) => (
          <li key={s.id}>
            <button
              type="button"
              onClick={() => onSelect(s.id)}
              className="flex w-full items-baseline justify-between gap-2 rounded-md px-2 py-1 text-left text-sm text-gray-800 hover:bg-gray-100"
            >
              <span className="truncate">{s.title || s.id}</span>
              <span className="shrink-0 text-xs text-gray-500">{s.fields.length}</span>
            </button>
          </li>
        ))}
      </ol>
      <form
        className="space-y-1"
        onSubmit={(e) => {
          e.preventDefault();
          add();
        }}
      >
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="New section title"
          aria-label="New section title"
          className="block w-full rounded-md border border-gray-300 px-2 py-1 text-sm"
        />
        <button type="submit" className="text-xs font-medium text-blue-600 hover:text-blue-800">
          Add section
        </button>
      </form>
    </nav>
  );
}
