import { reportWriteError } from "../db/writeStatus";
import { useCallback, useEffect, useRef, useState } from "react";
import type { FieldDef } from "../schemas/types";
import type { FieldMeta } from "../db/types";
import type { FieldDestination } from "../engine/fieldDestinations";
import { confidenceColor } from "../constants";
import FieldDestinationBadge from "./FieldDestinationBadge";
import {
  saveSessionImage,
  getSessionImage,
  deleteSessionImage,
} from "../db/sessionImages";

/** Sentinel value stored in session.answers to mark that an image is uploaded. */
export const IMAGE_SENTINEL_PREFIX = "[image:";

/** Check whether a value is an image sentinel. */
export function isImageSentinel(value: unknown): boolean {
  return typeof value === "string" && value.startsWith(IMAGE_SENTINEL_PREFIX);
}

/** Build the sentinel string for a field key. */
export function imageSentinel(fieldKey: string): string {
  return `${IMAGE_SENTINEL_PREFIX}${fieldKey}]`;
}

function ConfidenceBadge({ confidence }: { confidence: number }) {
  const pct = Math.round(confidence * 100);
  return (
    <span
      className={`ml-2 inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium ${confidenceColor(confidence)}`}
      title={`AI confidence: ${pct}%`}
    >
      AI {pct}%
    </span>
  );
}

interface Props {
  field: FieldDef;
  fieldKey: string;
  value: string | number | boolean | undefined;
  meta?: FieldMeta;
  sessionId: string;
  onChange: (key: string, value: string | number | boolean) => void;
  destinations?: FieldDestination[];
  showHints?: boolean;
}

export default function ImageField({
  field,
  fieldKey,
  value,
  meta,
  sessionId,
  onChange,
  destinations,
  showHints,
}: Props) {
  const showBadge = meta && meta.source !== "manual";
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [dragging, setDragging] = useState(false);

  // Load existing image on mount if sentinel is present
  useEffect(() => {
    if (!isImageSentinel(value)) {
      setPreviewUrl(null);
      setFileName(null);
      return;
    }

    let cancelled = false;
    getSessionImage(sessionId, fieldKey).then((img) => {
      if (cancelled || !img) return;
      const url = URL.createObjectURL(img.blob);
      setPreviewUrl(url);
      setFileName(img.fileName);
    });

    return () => {
      cancelled = true;
    };
  }, [sessionId, fieldKey, value]);

  // Revoke object URL on unmount to prevent memory leaks
  useEffect(() => {
    return () => {
      if (previewUrl) URL.revokeObjectURL(previewUrl);
    };
  }, [previewUrl]);

  const handleFile = useCallback(
    async (file: File) => {
      if (!file.type.startsWith("image/")) return;

      // Read intrinsic dimensions
      const bitmap = await createImageBitmap(file);
      const naturalWidth = bitmap.width;
      const naturalHeight = bitmap.height;
      bitmap.close();

      // Save to IndexedDB — on failure (e.g. storage full) leave the field
      // unfilled and raise the save banner rather than showing a phantom image
      try {
        await saveSessionImage({
          sessionId,
          fieldKey,
          fileName: file.name,
          mimeType: file.type,
          blob: file,
          naturalWidth,
          naturalHeight,
        });
      } catch (err) {
        console.error("[ImageField] Failed to save image:", err);
        reportWriteError(err);
        return;
      }

      // Update preview
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      setPreviewUrl(URL.createObjectURL(file));
      setFileName(file.name);

      // Store sentinel in answers so the engine knows the field is filled
      onChange(fieldKey, imageSentinel(fieldKey));
    },
    [sessionId, fieldKey, previewUrl, onChange],
  );

  const handleRemove = useCallback(async () => {
    await deleteSessionImage(sessionId, fieldKey);
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    setFileName(null);
    onChange(fieldKey, "");
  }, [sessionId, fieldKey, previewUrl, onChange]);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragging(false);
      const file = e.dataTransfer.files[0];
      if (file) handleFile(file);
    },
    [handleFile],
  );

  const hasImage = !!previewUrl;

  return (
    <div>
      {/* Label */}
      <div className="flex items-center gap-1.5 mb-1">
        <label className="text-sm font-medium text-gray-700">
          {field.label}
          {field.required && <span className="text-red-500 ml-0.5">*</span>}
        </label>
        {showBadge && <ConfidenceBadge confidence={meta!.confidence} />}
        {destinations && destinations.length > 0 && (
          <FieldDestinationBadge destinations={destinations} />
        )}
      </div>

      {/* Drop zone / preview */}
      {hasImage ? (
        <div className="relative rounded-lg border border-gray-300 bg-gray-50 p-3">
          <img
            src={previewUrl}
            alt={field.label}
            className="max-h-64 max-w-full rounded object-contain"
          />
          <div className="mt-2 flex items-center gap-3">
            <span className="text-xs text-gray-500 truncate">{fileName}</span>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="text-xs text-blue-600 hover:text-blue-800 underline"
            >
              Replace
            </button>
            <button
              type="button"
              onClick={handleRemove}
              className="text-xs text-red-600 hover:text-red-800 underline"
            >
              Remove
            </button>
          </div>
        </div>
      ) : (
        <div
          role="button"
          tabIndex={0}
          className={`flex flex-col items-center justify-center rounded-lg border-2 border-dashed px-6 py-8 cursor-pointer transition-colors ${
            dragging
              ? "border-blue-400 bg-blue-50"
              : "border-gray-300 bg-gray-50 hover:border-gray-400"
          }`}
          onClick={() => fileInputRef.current?.click()}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") fileInputRef.current?.click();
          }}
          onDragOver={(e) => {
            e.preventDefault();
            setDragging(true);
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={handleDrop}
        >
          <svg
            className="mx-auto h-10 w-10 text-gray-400"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={1.5}
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909M3.75 21h16.5A2.25 2.25 0 0022.5 18.75V5.25A2.25 2.25 0 0020.25 3H3.75A2.25 2.25 0 001.5 5.25v13.5A2.25 2.25 0 003.75 21z"
            />
          </svg>
          <p className="mt-2 text-sm text-gray-600">
            <span className="font-medium text-blue-600">Click to upload</span>{" "}
            or drag and drop
          </p>
          <p className="mt-1 text-xs text-gray-400">PNG, JPG, GIF, SVG</p>
        </div>
      )}

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) handleFile(file);
          // Reset so re-selecting the same file still triggers onChange
          e.target.value = "";
        }}
      />

      {field.ai_hint && showHints !== false && (
        <p className="mt-1 text-xs text-gray-400 italic">{field.ai_hint}</p>
      )}
    </div>
  );
}
