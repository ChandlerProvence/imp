import { useState, type InputHTMLAttributes } from "react";
import type { NumberFormat } from "../schemas/types";
import { toNumber } from "../engine/validation/coerce";
import { formatNumberForTemplate } from "../engine/formula/format";

type Props = Omit<InputHTMLAttributes<HTMLInputElement>, "type" | "value" | "onChange"> & {
  value: string | number | boolean | undefined;
  /** Called with the parsed number, "" when cleared, or the raw text when it isn't a number. */
  onChange: (value: string | number) => void;
  format?: NumberFormat;
};

/** What a typed text means as an answer value. */
function parseText(text: string): string | number {
  if (text.trim() === "") return "";
  return toNumber(text) ?? text;
}

/** Text shown while the box isn't being edited. Currency reads "1,234.50". */
function displayText(value: Props["value"], format: NumberFormat | undefined): string {
  if (value === undefined || value === null || value === "" || typeof value === "boolean") return "";
  if (typeof value === "number" && format === "currency") return String(formatNumberForTemplate(value, "currency"));
  return String(value);
}

function sameValue(a: string | number, b: Props["value"]): boolean {
  return typeof a === "number" && typeof b === "number" ? a === b : String(a) === String(b ?? "");
}

/**
 * Free-text number box. Native `<input type="number">` lets each browser
 * decide what a comma means before the app sees it (Chromium drops it,
 * Firefox may report ""), so what's on screen could differ from what's
 * totalled. Here the text is parsed by the same `toNumber` as every total:
 * clean numbers ("$1,234.50") are stored as numbers, and anything else is
 * stored as typed so validation flags it as "Must be a number".
 */
export default function NumberInput({ value, onChange, format, onFocus, onBlur, ...rest }: Props) {
  // Text being edited; null while the box isn't focused.
  const [draft, setDraft] = useState<string | null>(null);
  const [prevValue, setPrevValue] = useState(value);

  // An outside change (AI insert, session load) replaces the draft, unless it
  // is just the value the draft already means (our own onChange echoing back).
  if (value !== prevValue) {
    setPrevValue(value);
    if (draft !== null && !sameValue(parseText(draft), value)) setDraft(displayText(value, format));
  }

  return (
    <input
      {...rest}
      type="text"
      inputMode="decimal"
      value={draft ?? displayText(value, format)}
      onFocus={(e) => {
        setDraft(displayText(value, format));
        onFocus?.(e);
      }}
      onBlur={(e) => {
        setDraft(null);
        onBlur?.(e);
      }}
      onChange={(e) => {
        setDraft(e.target.value);
        onChange(parseText(e.target.value));
      }}
    />
  );
}
