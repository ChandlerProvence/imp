import type { DiagnosticsOptions } from "../errors/formatDiagnostics";
import { getActiveEndpointConfig } from "../ai/endpoints";
import { getFeatureFlags } from "../ai/featureFlags";
import { getModelResolution } from "../ai/models";

/** Gather the live app context (endpoint, flags, resolved models) for a diagnostics report. */
export function collectDiagnosticsOptions(schemaId?: string): DiagnosticsOptions {
  const ep = getActiveEndpointConfig();
  return {
    schemaId,
    endpoint: { id: ep.id, label: ep.label, baseUrl: ep.baseUrl },
    featureFlags: { ...getFeatureFlags() },
    models: getModelResolution(ep.id),
  };
}
