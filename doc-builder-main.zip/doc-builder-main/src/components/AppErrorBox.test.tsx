import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import AppErrorBox, { appErrorCopyText } from "./AppErrorBox";
import { appError } from "../errors";

describe("AppErrorBox", () => {
  const error = appError("ai.model-unavailable", { context: { model: "claude-x" }, detail: "HTTP 404 model not found" });

  it("renders title, message, and help from the AppError", () => {
    render(<AppErrorBox error={error} />);
    expect(screen.getByText(/AI model unavailable/)).toBeInTheDocument();
    expect(screen.getByText("The AI model claude-x is no longer available on the proxy.")).toBeInTheDocument();
    expect(screen.getByText(/Manual entry and Word generation still work/)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /copy error report/i })).toBeInTheDocument();
  });

  it("appends the subject to the title", () => {
    render(<AppErrorBox error={error} subject="contract.docx" />);
    expect(screen.getByText(/AI model unavailable — contract\.docx/)).toBeInTheDocument();
  });

  it("compact mode shows the message with help in the tooltip", () => {
    render(<AppErrorBox compact error={error} />);
    const text = screen.getByText(/no longer available/);
    expect(text).toHaveAttribute("title", expect.stringContaining("Settings → AI Models"));
  });

  it("copy text carries kind, detail, and the full diagnostics report", () => {
    const copied = appErrorCopyText(error);
    expect(copied).toContain("[ai.model-unavailable]");
    expect(copied).toContain("HTTP 404 model not found");
    expect(copied).toContain("doc-builder-diagnostics");
  });
});
