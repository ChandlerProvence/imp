import { useState } from "react";
import { useAiConfig } from "../context/AiConfigContext";

/** Remembers which substitution set was dismissed, so the notice shows once per change. */
export const SUBSTITUTION_SEEN_KEY = "doc-builder:model-substitution-seen";

/**
 * App-wide notice shown when a configured model is no longer on the proxy and
 * the app has automatically switched to a same-family replacement.
 */
export default function ModelSubstitutionNotice() {
  const { activeEndpoint, modelResolution } = useAiConfig();
  const [seen, setSeen] = useState(() => localStorage.getItem(SUBSTITUTION_SEEN_KEY));

  const substituted = modelResolution(activeEndpoint).filter((r) => r.source === "substituted");
  if (substituted.length === 0) return null;

  const signature = `${activeEndpoint}:${substituted.map((r) => `${r.role}=${r.id}`).join(",")}`;
  if (seen === signature) return null;

  function dismiss() {
    localStorage.setItem(SUBSTITUTION_SEEN_KEY, signature);
    setSeen(signature);
  }

  return (
    <div
      role="status"
      className="flex flex-wrap items-center gap-x-3 gap-y-1 bg-amber-50 border-b border-amber-200 px-4 py-2 text-sm text-amber-900"
    >
      <span className="font-medium">AI model changed.</span>
      {substituted.map((r) => (
        <span key={r.role}>
          <span className="font-mono">{r.configured}</span> is no longer available; using{" "}
          <span className="font-mono">{r.id}</span> instead.
        </span>
      ))}
      <span className="text-amber-800">You can choose a different model in Edit → Settings.</span>
      <button
        type="button"
        onClick={dismiss}
        className="ml-auto rounded border border-amber-300 bg-white px-2 py-0.5 text-xs font-medium text-amber-800 hover:bg-amber-100"
      >
        Dismiss
      </button>
    </div>
  );
}
