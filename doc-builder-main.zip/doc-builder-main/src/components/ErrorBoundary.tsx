import { Component, type ErrorInfo, type ReactNode } from "react";
import { toAppError } from "../errors";
import { clearDataAndReload } from "../db/resetDatabase";
import CopyDiagnosticsButton from "./CopyDiagnosticsButton";

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

/**
 * Root-level error boundary that catches unhandled React rendering errors
 * and shows a recovery UI instead of a white screen.
 */
export default class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false, error: null };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("[ErrorBoundary] Uncaught error:", error, info.componentStack);
    toAppError(error); // records it for diagnostics
  }

  handleReload = () => {
    window.location.reload();
  };

  handleClearAndReload = () => clearDataAndReload();

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex items-center justify-center h-screen bg-gray-50 p-8">
          <div className="max-w-md text-center space-y-4">
            <h1 className="text-xl font-semibold text-gray-900">
              Something went wrong
            </h1>
            <p className="text-gray-600 text-sm">
              An unexpected error occurred. You can try reloading the page.
              If the problem persists, clearing saved data may help.
            </p>
            {this.state.error && (
              <pre className="text-xs text-left bg-gray-100 p-3 rounded overflow-auto max-h-32 text-red-700">
                {this.state.error.message}
              </pre>
            )}
            <div className="flex flex-wrap gap-3 justify-center pt-2">
              <button
                onClick={this.handleReload}
                className="px-4 py-2 bg-blue-600 text-white rounded-sm hover:bg-blue-700 text-sm font-medium"
              >
                Reload
              </button>
              <CopyDiagnosticsButton />
              <button
                onClick={this.handleClearAndReload}
                className="px-4 py-2 bg-red-50 text-red-700 border border-red-200 rounded-sm hover:bg-red-100 text-sm font-medium"
              >
                Clear data &amp; reload
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
