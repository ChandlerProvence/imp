import type { ReferenceDoc } from "../../schemas/types";
import { parseEmbeddingProgress } from "../../ai/embeddings";
import type { EmbeddedChunk } from "../../ai/embeddings";
import ProgressRing from "../icons/ProgressRing";

interface Props {
  docs: ReferenceDoc[];
  selected: Set<string>;
  onToggle: (id: string) => void;
  fetchedTexts: Map<string, string>;
  fetchingIds: Set<string>;
  fetchErrors: Map<string, string>;
  /** Embedded chunks for large docs (keyed by docId). */
  embeddedDocs?: Map<string, EmbeddedChunk[]>;
  /** In-progress embedding status messages (keyed by docId). */
  embeddingProgress?: Map<string, string>;
}

export default function ReferenceDocsPanel({
  docs,
  selected,
  onToggle,
  fetchedTexts,
  fetchingIds,
  fetchErrors,
  embeddedDocs,
  embeddingProgress,
}: Props) {
  if (docs.length === 0) return null;

  return (
    <div className="border-t border-gray-200 px-4 py-3">
      <h3 className="text-xs font-semibold text-gray-600 uppercase tracking-wide mb-2">
        Reference Documents
      </h3>
      <div className="space-y-1.5">
        {docs.map((doc) => {
          const isSelected = selected.has(doc.id);
          const isFetching = fetchingIds.has(doc.id);
          const error = fetchErrors.get(doc.id);
          const hasSmallText = fetchedTexts.has(doc.id);
          const hasEmbedding = embeddedDocs?.has(doc.id) ?? false;
          const progressMsg = embeddingProgress?.get(doc.id);

          return (
            <label
              key={doc.id}
              className="flex items-start gap-2 cursor-pointer hover:bg-gray-50 p-1.5 rounded"
            >
              <input
                type="checkbox"
                checked={isSelected}
                onChange={() => onToggle(doc.id)}
                disabled={isFetching || !!progressMsg}
                className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500 mt-0.5 disabled:opacity-50"
              />
              <div className="flex-1 min-w-0">
                <div className="text-xs font-medium text-gray-800 leading-tight">
                  {doc.title}
                </div>
                {doc.description && (
                  <div className="text-xs text-gray-500 leading-tight mt-0.5">
                    {doc.description}
                  </div>
                )}
                {error && (
                  <div className="text-xs text-red-600 mt-0.5">
                    ✕ {error}
                  </div>
                )}
                {isFetching && (
                  <div className="text-xs text-blue-600 mt-0.5 flex items-center gap-1">
                    <span className="inline-block w-2 h-2 bg-blue-600 rounded-full animate-pulse" />
                    Fetching…
                  </div>
                )}
                {progressMsg && (
                  <div className="text-xs text-purple-600 mt-0.5 flex items-center gap-1">
                    <ProgressRing progress={parseEmbeddingProgress(progressMsg)} className="w-2.5 h-2.5" />
                    {progressMsg}
                  </div>
                )}
                {hasSmallText && !isFetching && !progressMsg && (
                  <div className="text-xs text-green-600 mt-0.5">
                    ✓ {fetchedTexts.get(doc.id)!.length.toLocaleString()} chars
                  </div>
                )}
                {hasEmbedding && !progressMsg && (
                  <div className="text-xs text-green-600 mt-0.5">
                    ✓ Indexed ({embeddedDocs!.get(doc.id)!.length} chunks)
                  </div>
                )}
              </div>
            </label>
          );
        })}
      </div>
    </div>
  );
}
