import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import BulkEditPreview from "./BulkEditPreview";
import type { ProposedChange } from "../../ai/bulkEdit";

// Mock FieldChangeCard to isolate
vi.mock("./FieldChangeCard", () => ({
  default: ({ change, onToggle }: any) => (
    <div data-testid={`change-${change.fieldKey}`} onClick={onToggle}>
      {change.fieldLabel}
    </div>
  ),
}));

function makeChange(overrides: Partial<ProposedChange> = {}): ProposedChange {
  return {
    fieldKey: "s1.f1",
    sectionId: "s1",
    sectionTitle: "Section One",
    fieldLabel: "Field One",
    fieldType: "string",
    currentValue: "old",
    proposedValue: "new",
    confidence: 0.9,
    accepted: true,
    ...overrides,
  };
}

describe("BulkEditPreview", () => {
  const defaultProps = {
    changes: [] as ProposedChange[],
    onToggleChange: vi.fn(),
    onAcceptAll: vi.fn(),
    onRejectAll: vi.fn(),
    onApply: vi.fn(),
    onCancel: vi.fn(),
  };

  it("shows empty state with Close button when no changes", () => {
    render(<BulkEditPreview {...defaultProps} />);
    expect(screen.getByText(/No changes proposed/)).toBeInTheDocument();
    expect(screen.getByText("Close")).toBeInTheDocument();
  });

  it("calls onCancel when Close clicked in empty state", () => {
    const onCancel = vi.fn();
    render(<BulkEditPreview {...defaultProps} onCancel={onCancel} />);
    fireEvent.click(screen.getByText("Close"));
    expect(onCancel).toHaveBeenCalledOnce();
  });

  it("renders changes grouped by section", () => {
    const changes = [
      makeChange({ fieldKey: "s1.f1", sectionTitle: "Section One", fieldLabel: "Field 1" }),
      makeChange({ fieldKey: "s1.f2", sectionTitle: "Section One", fieldLabel: "Field 2", sectionId: "s1" }),
      makeChange({ fieldKey: "s2.f3", sectionTitle: "Section Two", fieldLabel: "Field 3", sectionId: "s2" }),
    ];
    render(<BulkEditPreview {...defaultProps} changes={changes} />);
    expect(screen.getByText("Section One")).toBeInTheDocument();
    expect(screen.getByText("Section Two")).toBeInTheDocument();
  });

  it("shows accepted count in header", () => {
    const changes = [
      makeChange({ accepted: true }),
      makeChange({ fieldKey: "s1.f2", accepted: false }),
    ];
    render(<BulkEditPreview {...defaultProps} changes={changes} />);
    expect(screen.getByText("1/2 accepted")).toBeInTheDocument();
  });

  it("calls onAcceptAll when Select All clicked", () => {
    const onAcceptAll = vi.fn();
    const changes = [makeChange()];
    render(<BulkEditPreview {...defaultProps} changes={changes} onAcceptAll={onAcceptAll} />);
    fireEvent.click(screen.getByText("Select All"));
    expect(onAcceptAll).toHaveBeenCalledOnce();
  });

  it("calls onRejectAll when Deselect All clicked", () => {
    const onRejectAll = vi.fn();
    const changes = [makeChange()];
    render(<BulkEditPreview {...defaultProps} changes={changes} onRejectAll={onRejectAll} />);
    fireEvent.click(screen.getByText("Deselect All"));
    expect(onRejectAll).toHaveBeenCalledOnce();
  });

  it("Apply button shows count and calls onApply", () => {
    const onApply = vi.fn();
    const changes = [makeChange({ accepted: true }), makeChange({ fieldKey: "s1.f2", accepted: true })];
    render(<BulkEditPreview {...defaultProps} changes={changes} onApply={onApply} />);
    const btn = screen.getByText("Apply 2 Changes");
    fireEvent.click(btn);
    expect(onApply).toHaveBeenCalledOnce();
  });

  it("Apply button is disabled when no accepted changes", () => {
    const changes = [makeChange({ accepted: false })];
    render(<BulkEditPreview {...defaultProps} changes={changes} />);
    const btn = screen.getByText("Apply 0 Changes");
    expect(btn).toBeDisabled();
  });

  it("calls onToggleChange with index when a card is toggled", () => {
    const onToggleChange = vi.fn();
    const changes = [makeChange()];
    render(<BulkEditPreview {...defaultProps} changes={changes} onToggleChange={onToggleChange} />);
    fireEvent.click(screen.getByTestId("change-s1.f1"));
    expect(onToggleChange).toHaveBeenCalledWith(0);
  });
});
