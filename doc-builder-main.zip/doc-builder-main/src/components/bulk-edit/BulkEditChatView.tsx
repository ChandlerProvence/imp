import { useCallback, useEffect, useMemo, useRef } from "react";
import AppErrorBox from "../AppErrorBox";
import ReactMarkdown from "react-markdown";
import type { DocumentSchema } from "../../schemas/types";
import type { BulkEditRequest, ProposedChange } from "../../ai/bulkEdit";
import {
  buildBulkEditChatSystemPrompt,
  buildBulkEditChatUserMessage,
  parseBulkEditResponse,
} from "../../ai/bulkEdit";
import { AI_TOOLS } from "../../ai/toolDefinitions";
import { extractProposedChangesJson, stripProposedChanges } from "../../ai/parseProposedChanges";
import { clearConversation } from "../../db/chatHistory";
import { useAiChat } from "../../hooks/useAiChat";
import type { AiChatMessage } from "../../hooks/useAiChat";
import ChatInput from "../chat/ChatInput";
import EndpointBadge from "../EndpointBadge";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface Props {
  schema: DocumentSchema;
  answers: Record<string, string | number | boolean>;
  request: BulkEditRequest;
  /** Session ID for persisting conversation to IndexedDB. */
  sessionId: string;
  /** Field key for this conversation in IndexedDB (e.g., "__bulk_edit:<uuid>"). */
  fieldKey: string;
  onReconfigure: () => void;
  /** Callback to search large-doc embeddings. Returns relevant text chunks and retrieval metadata. */
  onSearchReferences: (query: string) => Promise<{ text: string; chunkCount: number; docCount: number }>;
  /** Notification about documents added mid-conversation. When a new id appears, a user message is injected. */
  documentNotification?: { id: string; content: string; displayLabel: string } | null;
  /** Called whenever accumulated proposed changes are updated (lifted state for external display). */
  onChangesUpdate?: (changes: ProposedChange[]) => void;
}

// ---------------------------------------------------------------------------
// Bubble subcomponent for bulk edit (handles <proposed-changes> stripping)
// ---------------------------------------------------------------------------

function BulkEditBubble({
  message,
  streaming,
  proposedCount,
}: {
  message: { role: "user" | "assistant"; content: string; displayLabel?: string };
  streaming?: boolean;
  proposedCount?: number;
}) {
  const displayContent = useMemo(() => {
    if (message.role === "user") return null;
    return stripProposedChanges(message.content);
  }, [message.role, message.content]);

  if (message.role === "user") {
    return (
      <div className="flex justify-end">
        <div className="max-w-[85%] rounded-lg bg-blue-600 px-3 py-2 text-sm text-white whitespace-pre-wrap">
          {message.displayLabel ?? message.content}
        </div>
      </div>
    );
  }

  return (
    <div className="flex justify-start">
      <div className="max-w-[85%] rounded-lg bg-gray-100 px-3 py-2 text-sm text-gray-900">
        {displayContent && (
          <div className="prose prose-sm prose-gray max-w-none [&>*:first-child]:mt-0 [&>*:last-child]:mb-0">
            <ReactMarkdown>{displayContent}</ReactMarkdown>
          </div>
        )}
        {proposedCount != null && proposedCount > 0 && (
          <div className="mt-2 rounded border border-blue-200 bg-blue-50 px-2.5 py-1.5 text-xs text-blue-700 font-medium">
            📋 {proposedCount} field change{proposedCount !== 1 && "s"} proposed
          </div>
        )}
        {streaming && (
          <span className="inline-flex items-center gap-0.5 ml-1 h-4">
            <span className="w-1 h-full bg-blue-500 rounded-sm animate-streaming-bar origin-bottom [animation-delay:0ms]" />
            <span className="w-1 h-full bg-blue-500 rounded-sm animate-streaming-bar origin-bottom [animation-delay:200ms]" />
            <span className="w-1 h-full bg-blue-500 rounded-sm animate-streaming-bar origin-bottom [animation-delay:400ms]" />
          </span>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Main component
// ---------------------------------------------------------------------------

export default function BulkEditChatView({
  schema,
  answers,
  request,
  sessionId,
  fieldKey,
  onReconfigure,
  onSearchReferences,
  documentNotification,
  onChangesUpdate,
}: Props) {
  const bottomRef = useRef<HTMLDivElement>(null);

  // Build initial message for auto-send on first mount
  const initialMessage = useMemo(() => {
    const userContent = buildBulkEditChatUserMessage(request);
    let displayLabel: string | undefined;
    if (request.referenceDocTexts && request.referenceDocTexts.length > 0) {
      const docNames = request.referenceDocTexts.map((d) => d.title).join(", ");
      displayLabel = request.prompt
        ? `${request.prompt}\n\n[Context: ${docNames}]`
        : `[Context: ${docNames}]`;
    } else {
      displayLabel = request.prompt ?? "Fill in all fields based on available context.";
    }
    return { content: userContent, displayLabel };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const buildSystemPrompt = useCallback(
    () => buildBulkEditChatSystemPrompt(schema, request.selectedSectionIds, answers),
    [schema, request.selectedSectionIds, answers],
  );

  const tools = AI_TOOLS;

  const {
    messages,
    isStreaming,
    streamingContent,
    isSearching,
    retrievalMeta,
    error,
    sendMessage,
    stopStreaming,
    injectDocumentNotification,
  } = useAiChat({
    sessionId,
    conversationKey: fieldKey,
    schema,
    buildSystemPrompt,
    tools,
    request,
    onSearchReferences,
    onChangesUpdate,
    conversationType: "bulk-edit",
    initialMessage,
  });

  // Inject document notifications when they arrive
  useEffect(() => {
    if (documentNotification && !isStreaming) {
      injectDocumentNotification(documentNotification);
    }
  }, [documentNotification, isStreaming, injectDocumentNotification]);

  // Auto-scroll to bottom
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, streamingContent]);

  // Count proposed changes per assistant message for inline badges
  const messageChangeCounts = useMemo(() => {
    const counts = new Map<string, number>();
    for (const msg of messages) {
      if (msg.role !== "assistant") continue;
      const proposeTc = msg.toolCalls?.find(
        (tc) => tc.function.name === "propose_changes",
      );
      if (proposeTc) {
        try {
          const args = JSON.parse(proposeTc.function.arguments) as { changes: Record<string, unknown> };
          const { changes } = parseBulkEditResponse(
            JSON.stringify(args.changes),
            request,
          );
          counts.set(msg.id, changes.length);
        } catch {
          // skip
        }
        continue;
      }
      const json = extractProposedChangesJson(msg.content);
      if (json) {
        try {
          const { changes } = parseBulkEditResponse(json, request);
          counts.set(msg.id, changes.length);
        } catch {
          // skip
        }
      }
    }
    return counts;
  }, [messages, request]);

  return (
    <div className="flex flex-col h-full">
      {/* Config summary bar */}
      <div className="flex items-center justify-between px-4 py-2 bg-gray-50 border-b border-gray-200">
        <span className="text-xs text-gray-600 flex items-center gap-2">
          <EndpointBadge />
          {request.selectedSectionIds.length} section{request.selectedSectionIds.length !== 1 && "s"}
          {request.referenceDocTexts && request.referenceDocTexts.length > 0 && (
            <> · {request.referenceDocTexts.length} ref doc{request.referenceDocTexts.length !== 1 && "s"}</>
          )}
        </span>
        <button
          type="button"
          onClick={() => {
            clearConversation(sessionId, fieldKey);
            onReconfigure();
          }}
          disabled={isStreaming}
          className="text-xs text-blue-600 hover:text-blue-800 font-medium disabled:opacity-40"
        >
          Reconfigure
        </button>
      </div>

      {/* Chat messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.length === 0 && !streamingContent && !isSearching && (
          <div className="flex items-center justify-center h-full">
            <p className="text-sm text-gray-400">Preparing conversation…</p>
          </div>
        )}
        {messages
          .filter((msg: AiChatMessage) => {
            if (msg.role === "tool") return false;
            if (msg.role === "assistant" && !msg.content && msg.toolCalls) return false;
            return true;
          })
          .map((msg: AiChatMessage) => (
            <BulkEditBubble
              key={msg.id}
              message={{ role: msg.role as "user" | "assistant", content: msg.content, displayLabel: msg.displayLabel }}
              proposedCount={messageChangeCounts.get(msg.id)}
            />
          ))}
        {isSearching && (
          <div className="flex justify-start">
            <div className="rounded-lg bg-blue-50 border border-blue-200 px-3 py-2 text-sm text-blue-700 flex items-center gap-2">
              <span className="inline-block w-3 h-3 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
              Searching references…
            </div>
          </div>
        )}
        {!isSearching && retrievalMeta && retrievalMeta.chunkCount > 0 && (
          <div className="flex justify-start">
            <p className="text-xs text-gray-400 italic px-3 py-1">
              Retrieved {retrievalMeta.chunkCount} relevant passage{retrievalMeta.chunkCount !== 1 ? "s" : ""} from{" "}
              {retrievalMeta.docCount} document{retrievalMeta.docCount !== 1 ? "s" : ""}
            </p>
          </div>
        )}
        {streamingContent !== null && streamingContent.length === 0 && (
          <div className="flex justify-start">
            <div className="rounded-lg bg-gray-100 px-3 py-2 text-sm text-gray-500 flex items-center gap-2">
              <span className="flex items-end gap-1 h-4">
                <span className="w-1 h-full bg-blue-500 rounded-sm origin-bottom [animation:var(--animate-streaming-bar)] [animation-delay:0ms]" />
                <span className="w-1 h-full bg-blue-500 rounded-sm origin-bottom [animation:var(--animate-streaming-bar)] [animation-delay:200ms]" />
                <span className="w-1 h-full bg-blue-500 rounded-sm origin-bottom [animation:var(--animate-streaming-bar)] [animation-delay:400ms]" />
              </span>
              Thinking…
            </div>
          </div>
        )}
        {streamingContent !== null && streamingContent.length > 0 && (
          <BulkEditBubble
            message={{ role: "assistant", content: streamingContent }}
            streaming
          />
        )}
        <div ref={bottomRef} />
      </div>

      {/* Error banner */}
      {error && <AppErrorBox error={error} className="mx-4 mb-2" />}

      {/* Chat input */}
      <ChatInput
        onSend={sendMessage}
        onStop={stopStreaming}
        isStreaming={isStreaming}
      />
    </div>
  );
}
