import type { ProposedChange } from "../../ai/bulkEdit";
import FieldChangeCard from "./FieldChangeCard";

interface Props {
  changes: ProposedChange[];
  onToggleChange: (index: number) => void;
  onAcceptAll: () => void;
  onRejectAll: () => void;
  onApply: () => void;
}

export default function ProposedChangesPanel({
  changes,
  onToggleChange,
  onAcceptAll,
  onRejectAll,
  onApply,
}: Props) {
  const acceptedCount = changes.filter((c) => c.accepted).length;

  if (changes.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center p-6">
        <p className="text-sm text-gray-400">No changes proposed yet.</p>
      </div>
    );
  }

  // Group changes by section
  const grouped = new Map<string, { title: string; items: { change: ProposedChange; index: number }[] }>();
  changes.forEach((change, index) => {
    if (!grouped.has(change.sectionId)) {
      grouped.set(change.sectionId, { title: change.sectionTitle, items: [] });
    }
    grouped.get(change.sectionId)!.items.push({ change, index });
  });

  return (
    <div className="flex flex-col h-full bg-gray-50">
      {/* Action bar (sticky top) */}
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-gray-200 bg-white shrink-0">
        <span className="text-sm font-medium text-gray-700">
          {changes.length} change{changes.length !== 1 && "s"}
          <span className="text-xs text-gray-500 ml-1.5">
            · {acceptedCount} accepted
          </span>
        </span>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onAcceptAll}
            className="text-xs text-green-600 hover:text-green-800 font-medium"
          >
            Select All
          </button>
          <button
            type="button"
            onClick={onRejectAll}
            className="text-xs text-red-600 hover:text-red-800 font-medium"
          >
            Deselect All
          </button>
          <button
            type="button"
            onClick={onApply}
            disabled={acceptedCount === 0}
            className="rounded-md bg-green-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-green-700 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            Apply {acceptedCount}
          </button>
        </div>
      </div>

      {/* Scrollable change list */}
      <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
        {[...grouped.entries()].map(([sectionId, { title, items }]) => (
          <div key={sectionId}>
            <h4 className="text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1.5">
              {title}
            </h4>
            <div className="space-y-1.5">
              {items.map(({ change, index }) => (
                <FieldChangeCard
                  key={change.fieldKey}
                  change={change}
                  onToggle={() => onToggleChange(index)}
                />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
