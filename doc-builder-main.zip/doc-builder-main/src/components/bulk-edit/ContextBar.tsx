import { useCallback, useRef, useState } from "react";
import type { SectionDef } from "../../schemas/types";
import type { SectionStatus } from "../../engine/types";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface Props {
  sections: SectionDef[];
  selectedSectionIds: string[];
  sectionStatuses: Record<string, SectionStatus>;
  documentCount: number;
  onSectionsChange: (ids: string[]) => void;
  onAddDocument: () => void;
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

/**
 * Collapsed context summary bar shown above the chat when a conversation is active.
 * Shows section count + doc count with inline edit popovers.
 */
export default function ContextBar({
  sections,
  selectedSectionIds,
  sectionStatuses,
  documentCount,
  onSectionsChange,
  onAddDocument,
}: Props) {
  const [showSectionPopover, setShowSectionPopover] = useState(false);
  const popoverRef = useRef<HTMLDivElement>(null);

  const selectedSet = new Set(selectedSectionIds);
  const allSelected = selectedSet.size === sections.length;

  const handleToggle = useCallback(
    (id: string) => {
      const next = new Set(selectedSectionIds);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      onSectionsChange([...next]);
    },
    [selectedSectionIds, onSectionsChange],
  );

  const handleSelectAll = useCallback(() => {
    onSectionsChange(sections.map((s) => s.id));
  }, [sections, onSectionsChange]);

  const handleDeselectAll = useCallback(() => {
    onSectionsChange([]);
  }, [onSectionsChange]);

  return (
    <div className="flex items-center gap-3 px-4 py-2 bg-gray-50 border-b border-gray-200 text-xs text-gray-600 shrink-0">
      {/* Section count + edit */}
      <div className="relative">
        <button
          type="button"
          onClick={() => setShowSectionPopover(!showSectionPopover)}
          className="inline-flex items-center gap-1 hover:text-gray-800 transition-colors"
        >
          <span className="font-medium">
            {selectedSectionIds.length} section{selectedSectionIds.length !== 1 && "s"}
          </span>
          <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
          </svg>
        </button>

        {showSectionPopover && (
          <>
            {/* Backdrop to close */}
            <div
              className="fixed inset-0 z-10"
              onClick={() => setShowSectionPopover(false)}
            />
            <div
              ref={popoverRef}
              className="absolute left-0 top-full mt-1 z-20 w-64 rounded-md border border-gray-200 bg-white shadow-lg"
            >
              <div className="flex items-center justify-between px-3 py-2 border-b border-gray-100">
                <span className="text-xs font-medium text-gray-700">Edit sections</span>
                <button
                  type="button"
                  onClick={allSelected ? handleDeselectAll : handleSelectAll}
                  className="text-xs text-blue-600 hover:text-blue-800 font-medium"
                >
                  {allSelected ? "Deselect All" : "Select All"}
                </button>
              </div>
              <div className="max-h-48 overflow-y-auto py-1">
                {sections.map((section) => {
                  const status = sectionStatuses[section.id] ?? "empty";
                  return (
                    <label
                      key={section.id}
                      className="flex items-center gap-2 px-3 py-1.5 cursor-pointer hover:bg-gray-50"
                    >
                      <input
                        type="checkbox"
                        checked={selectedSet.has(section.id)}
                        onChange={() => handleToggle(section.id)}
                        className="h-3.5 w-3.5 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                      />
                      <span className="flex-1 text-xs text-gray-800 truncate">
                        {section.title}
                      </span>
                      <span className="text-xs text-gray-400">
                        {status === "complete" ? "✓" : status === "in-progress" ? "◐" : "○"}
                      </span>
                    </label>
                  );
                })}
              </div>
            </div>
          </>
        )}
      </div>

      <span className="text-gray-300">·</span>

      {/* Document count + add */}
      <span>
        {documentCount} doc{documentCount !== 1 && "s"}
      </span>

      <button
        type="button"
        onClick={onAddDocument}
        className="inline-flex items-center gap-0.5 text-blue-600 hover:text-blue-800 font-medium transition-colors"
      >
        <span>+</span> Add doc
      </button>
    </div>
  );
}
