import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import ContextBar from "./ContextBar";
import type { SectionDef } from "../../schemas/types";

const sections: SectionDef[] = [
  { id: "s1", title: "Parties", fields: [{ id: "f1", label: "F1", type: "string", required: false }] },
  { id: "s2", title: "Terms", fields: [{ id: "f2", label: "F2", type: "string", required: false }] },
];

describe("ContextBar", () => {
  const defaultProps = {
    sections,
    selectedSectionIds: ["s1"],
    sectionStatuses: { s1: "complete" as const, s2: "empty" as const },
    documentCount: 2,
    onSectionsChange: vi.fn(),
    onAddDocument: vi.fn(),
  };

  it("shows section count", () => {
    render(<ContextBar {...defaultProps} />);
    expect(screen.getByText("1 section")).toBeInTheDocument();
  });

  it("shows pluralized section count", () => {
    render(<ContextBar {...defaultProps} selectedSectionIds={["s1", "s2"]} />);
    expect(screen.getByText("2 sections")).toBeInTheDocument();
  });

  it("shows document count", () => {
    render(<ContextBar {...defaultProps} />);
    expect(screen.getByText("2 docs")).toBeInTheDocument();
  });

  it("shows Add doc button", () => {
    render(<ContextBar {...defaultProps} />);
    expect(screen.getByText("Add doc")).toBeInTheDocument();
  });

  it("calls onAddDocument when Add doc clicked", () => {
    const onAddDocument = vi.fn();
    render(<ContextBar {...defaultProps} onAddDocument={onAddDocument} />);
    fireEvent.click(screen.getByText("Add doc"));
    expect(onAddDocument).toHaveBeenCalledOnce();
  });

  it("opens section edit popover on click", () => {
    render(<ContextBar {...defaultProps} />);
    fireEvent.click(screen.getByText("1 section"));
    expect(screen.getByText("Edit sections")).toBeInTheDocument();
    expect(screen.getByText("Parties")).toBeInTheDocument();
    expect(screen.getByText("Terms")).toBeInTheDocument();
  });
});
