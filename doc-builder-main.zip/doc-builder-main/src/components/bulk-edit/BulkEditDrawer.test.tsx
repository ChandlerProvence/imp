import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent, act } from "@testing-library/react";
import { createMockSchema } from "../../test/mocks";

const pending = new Map<string, (text: string) => void>();

vi.mock("../../extraction/parseFile", () => ({
  parseFile: vi.fn(
    (f: File) => new Promise<string>((resolve) => pending.set(f.name, resolve)),
  ),
}));

vi.mock("../../context/AiConfigContext", () => ({
  useAiConfig: () => ({ activeEndpoint: "non-cui", endpointConfig: { shortLabel: "Proprietary" } }),
}));

import BulkEditDrawer from "./BulkEditDrawer";

function addFile(name: string) {
  const input = document.querySelector<HTMLInputElement>('input[type="file"]')!;
  fireEvent.change(input, { target: { files: [new File(["x"], name)] } });
}

describe("BulkEditDrawer file parsing", () => {
  it("keeps the first file's result when a second file is added mid-parse", async () => {
    render(
      <BulkEditDrawer
        open
        onClose={() => {}}
        schema={createMockSchema()}
        answers={{}}
        sectionStatuses={{}}
        sessionId="s1"
        onApply={() => {}}
      />,
    );

    addFile("a.txt");
    addFile("b.txt");
    expect(screen.getAllByText("Parsing…")).toHaveLength(2);

    await act(async () => {
      pending.get("a.txt")!("alpha");
      pending.get("b.txt")!("bravo");
    });

    expect(screen.queryByText("Parsing…")).toBeNull();
    expect(screen.getAllByText(/✓ 5 chars/)).toHaveLength(2);
  });
});
