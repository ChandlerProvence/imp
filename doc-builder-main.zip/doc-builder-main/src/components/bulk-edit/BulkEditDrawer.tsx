import { useCallback, useEffect, useRef, useState } from "react";
import type { DocumentSchema } from "../../schemas/types";
import type { SectionStatus } from "../../engine/types";
import type { BulkEditRequest, ProposedChange } from "../../ai/bulkEdit";
import { parseFile } from "../../extraction/parseFile";
import { toAppError, type AppError } from "../../errors";
import AppErrorBox from "../AppErrorBox";
import { mapWithLimit } from "../../utils/concurrency";
import MagicWandIcon from "../icons/MagicWandIcon";
import SectionSelector from "./SectionSelector";
import BulkEditInput from "./BulkEditInput";
import BulkEditChatView from "./BulkEditChatView";
import ProposedChangesPanel from "./ProposedChangesPanel";
import EndpointBadge from "../EndpointBadge";

type Phase = "configure" | "chat";

/** No-op search for contexts without reference-doc embeddings (e.g. the simple drawer). */
const noopSearchReferences = async () =>
  ({ text: "No reference documents are available for search.", chunkCount: 0, docCount: 0 });

export interface BulkEditApplyMeta {
  confidence: number;
  source: "bulk-edit";
  aiSetAt: string;
}

interface Props {
  open: boolean;
  onClose: () => void;
  schema: DocumentSchema;
  answers: Record<string, string | number | boolean>;
  sectionStatuses: Record<string, SectionStatus>;
  sessionId: string;
  onApply: (
    updates: Record<string, string | number | boolean>,
    meta: Record<string, BulkEditApplyMeta>,
  ) => void;
}

export default function BulkEditDrawer({
  open,
  onClose,
  schema,
  answers,
  sectionStatuses,
  sessionId,
  onApply,
}: Props) {
  // Phase state
  const [phase, setPhase] = useState<Phase>("configure");

  // Configuration state
  const [selectedSections, setSelectedSections] = useState<Set<string>>(
    () => new Set(schema.sections.map((s) => s.id)),
  );
  const [prompt, setPrompt] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [parsedTexts, setParsedTexts] = useState<Map<File, string>>(new Map());
  const [parsingFiles, setParsingFiles] = useState<Set<File>>(new Set());
  const [error, setError] = useState<AppError | undefined>();

  // The frozen request sent to the chat view
  const [chatRequest, setChatRequest] = useState<BulkEditRequest | null>(null);

  // Key to force-remount BulkEditChatView on reconfigure
  const chatKeyRef = useRef(0);

  // Track which files have been queued for parsing to avoid re-processing
  const processedFilesRef = useRef<Set<File>>(new Set());
  // Current file list, read by in-flight parses to drop results for removed files
  const filesRef = useRef<File[]>([]);

  // Reset when drawer closes
  useEffect(() => {
    if (!open) {
      setPhase("configure");
      setPrompt("");
      setFiles([]);
      setParsedTexts(new Map());
      setParsingFiles(new Set());
      setError(undefined);
      setChatRequest(null);
      setSelectedSections(new Set(schema.sections.map((s) => s.id)));
      processedFilesRef.current = new Set();
    }
  }, [open, schema.sections]);


  // Parse files as they're added — limited to 2 concurrent to avoid memory spikes
  useEffect(() => {
    filesRef.current = files;
    // Parses outlive this effect run: adding another file re-runs it, and a
    // per-run cancel flag would drop the earlier file's result for good (it's
    // already in processedFilesRef). Drop results only for files since removed.
    const isCurrent = (f: File) => filesRef.current.includes(f);

    const newFiles = files.filter((f) => !processedFilesRef.current.has(f));

    if (newFiles.length > 0) {
      for (const f of newFiles) {
        processedFilesRef.current.add(f);
      }
      setParsingFiles((prev) => new Set([...prev, ...newFiles]));

      mapWithLimit(newFiles, 2, async (f) => {
        try {
          const text = await parseFile(f);
          if (!isCurrent(f)) return;
          setParsedTexts((prev) => new Map([...prev, [f, text]]));
          setParsingFiles((prev) => {
            const next = new Set(prev);
            next.delete(f);
            return next;
          });
        } catch (err) {
          if (!isCurrent(f)) return;
          setError(toAppError(err, { domain: "file", context: { fileName: f.name } }));
          setParsingFiles((prev) => {
            const next = new Set(prev);
            next.delete(f);
            return next;
          });
        }
      });
    }

    // Clean up removed files
    setParsedTexts((prev) => {
      const next = new Map(prev);
      for (const key of next.keys()) {
        if (!files.includes(key)) next.delete(key);
      }
      return next.size !== prev.size ? next : prev;
    });
    for (const f of processedFilesRef.current) {
      if (!files.includes(f)) processedFilesRef.current.delete(f);
    }
  }, [files]);

  // Section selection handlers
  const handleToggleSection = useCallback((id: string) => {
    setSelectedSections((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const handleSelectAll = useCallback(() => {
    setSelectedSections(new Set(schema.sections.map((s) => s.id)));
  }, [schema.sections]);

  const handleDeselectAll = useCallback(() => {
    setSelectedSections(new Set());
  }, []);

  // Submit — transition to chat phase
  const canSubmit =
    selectedSections.size > 0 &&
    prompt.trim().length > 0;

  const handleSubmit = useCallback(() => {
    // Uploaded files are context docs, not the primary source
    const referenceDocTexts =
      parsedTexts.size > 0
        ? Array.from(parsedTexts.entries())
            .filter(([, text]) => text.length > 0)
            .map(([f, text]) => ({ title: f.name, text }))
        : undefined;

    const request: BulkEditRequest = {
      mode: "prompt",
      prompt: prompt.trim(),
      referenceDocTexts,
      selectedSectionIds: [...selectedSections],
      schema,
      currentAnswers: answers,
    };
    setChatRequest(request);
    chatKeyRef.current += 1;
    setPhase("chat");
  }, [prompt, parsedTexts, selectedSections, schema, answers]);

  // Reconfigure — return to configure phase
  const handleReconfigure = useCallback(() => {
    setPhase("configure");
    setChatRequest(null);
  }, []);

  // Accumulated changes state (lifted from BulkEditChatView)
  const [accumulatedChanges, setAccumulatedChanges] = useState<ProposedChange[]>([]);

  const handleChangesUpdate = useCallback((changes: ProposedChange[]) => {
    setAccumulatedChanges(changes);
  }, []);

  const handleToggleChange = useCallback((index: number) => {
    setAccumulatedChanges((prev) =>
      prev.map((c, i) => (i === index ? { ...c, accepted: !c.accepted } : c)),
    );
  }, []);

  const handleAcceptAll = useCallback(() => {
    setAccumulatedChanges((prev) => prev.map((c) => ({ ...c, accepted: true })));
  }, []);

  const handleRejectAll = useCallback(() => {
    setAccumulatedChanges((prev) => prev.map((c) => ({ ...c, accepted: false })));
  }, []);

  const handleApplyChanges = useCallback(() => {
    const accepted = accumulatedChanges.filter((c) => c.accepted);
    if (accepted.length === 0) return;
    const updates: Record<string, string | number | boolean> = {};
    const meta: Record<string, BulkEditApplyMeta> = {};
    const now = new Date().toISOString();
    for (const change of accepted) {
      updates[change.fieldKey] = change.proposedValue;
      meta[change.fieldKey] = {
        confidence: change.confidence,
        source: "bulk-edit",
        aiSetAt: now,
      };
    }
    onApply(updates, meta);
    onClose();
  }, [accumulatedChanges, onApply, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Backdrop */}
      <div
        className="flex-1 bg-black/30"
        onClick={onClose}
      />

      {/* Drawer panel */}
      <div className="w-full max-w-lg bg-white shadow-xl flex flex-col overflow-hidden">
        {/* Header */}
        <header className="flex items-center justify-between border-b border-gray-200 px-5 py-3">
          <div className="flex items-center gap-2">
            <h2 className="text-base font-semibold text-gray-900 inline-flex items-center gap-1.5">
              <MagicWandIcon className="w-4 h-4 text-violet-600" /> Bulk AI Edit
            </h2>
            <EndpointBadge />
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 text-lg leading-none"
          >
            ✕
          </button>
        </header>

        {/* Content */}
        {phase === "configure" && (
          <>
            <div className="flex-1 overflow-y-auto px-5 py-4">
              <div className="space-y-5">
                <SectionSelector
                  sections={schema.sections}
                  selected={selectedSections}
                  sectionStatuses={sectionStatuses}
                  onToggle={handleToggleSection}
                  onSelectAll={handleSelectAll}
                  onDeselectAll={handleDeselectAll}
                />

                <BulkEditInput
                  prompt={prompt}
                  onPromptChange={setPrompt}
                  files={files}
                  onFilesChange={setFiles}
                  parsedLengths={new Map(Array.from(parsedTexts.entries()).map(([f, t]) => [f, t.length]))}
                  parsingFiles={parsingFiles}
                />

                {error && <AppErrorBox error={error} />}
              </div>
            </div>

            {/* Footer */}
            <footer className="flex items-center justify-between border-t border-gray-200 px-5 py-3">
              <button
                type="button"
                onClick={onClose}
                className="rounded-md border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSubmit}
                disabled={!canSubmit}
                className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed"
              >
                Run AI Edit
              </button>
            </footer>
          </>
        )}

        {phase === "chat" && chatRequest && (
          <>
            <BulkEditChatView
              key={chatKeyRef.current}
              schema={schema}
              answers={answers}
              request={chatRequest}
              sessionId={sessionId}
              fieldKey="__bulk_edit"
              onReconfigure={handleReconfigure}
              onSearchReferences={noopSearchReferences}
              onChangesUpdate={handleChangesUpdate}
            />
            <ProposedChangesPanel
              changes={accumulatedChanges}
              onToggleChange={handleToggleChange}
              onAcceptAll={handleAcceptAll}
              onRejectAll={handleRejectAll}
              onApply={handleApplyChanges}
            />
          </>
        )}
      </div>
    </div>
  );
}
