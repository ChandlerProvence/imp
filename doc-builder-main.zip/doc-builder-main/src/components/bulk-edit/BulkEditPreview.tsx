import type { ProposedChange } from "../../ai/bulkEdit";
import FieldChangeCard from "./FieldChangeCard";

interface Props {
  changes: ProposedChange[];
  onToggleChange: (index: number) => void;
  onAcceptAll: () => void;
  onRejectAll: () => void;
  onApply: () => void;
  onCancel: () => void;
}

export default function BulkEditPreview({
  changes,
  onToggleChange,
  onAcceptAll,
  onRejectAll,
  onApply,
  onCancel,
}: Props) {
  const acceptedCount = changes.filter((c) => c.accepted).length;

  // Group changes by section
  const grouped = new Map<string, { title: string; items: { change: ProposedChange; index: number }[] }>();
  changes.forEach((change, index) => {
    if (!grouped.has(change.sectionId)) {
      grouped.set(change.sectionId, { title: change.sectionTitle, items: [] });
    }
    grouped.get(change.sectionId)!.items.push({ change, index });
  });

  if (changes.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center gap-4 py-12">
        <p className="text-sm text-gray-500">
          No changes proposed. The AI did not suggest any field updates for the
          selected sections.
        </p>
        <button
          type="button"
          onClick={onCancel}
          className="rounded-md border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
        >
          Close
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-gray-200">
        <h3 className="text-sm font-semibold text-gray-900">
          AI Edit Preview
          <span className="ml-2 text-xs font-normal text-gray-500">
            {acceptedCount}/{changes.length} accepted
          </span>
        </h3>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={onAcceptAll}
            className="text-xs text-green-600 hover:text-green-800 font-medium"
          >
            Select All
          </button>
          <button
            type="button"
            onClick={onRejectAll}
            className="text-xs text-red-600 hover:text-red-800 font-medium"
          >
            Deselect All
          </button>
        </div>
      </div>

      {/* Change list */}
      <div className="flex-1 overflow-y-auto py-3 space-y-4">
        {[...grouped.entries()].map(([sectionId, { title, items }]) => (
          <div key={sectionId}>
            <h4 className="text-xs font-semibold text-gray-600 uppercase tracking-wide mb-2">
              {title}
            </h4>
            <div className="space-y-2">
              {items.map(({ change, index }) => (
                <FieldChangeCard
                  key={change.fieldKey}
                  change={change}
                  onToggle={() => onToggleChange(index)}
                />
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between pt-3 border-t border-gray-200">
        <button
          type="button"
          onClick={onCancel}
          className="rounded-md border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
        >
          Cancel
        </button>
        <button
          type="button"
          onClick={onApply}
          disabled={acceptedCount === 0}
          className="rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          Apply {acceptedCount} Change{acceptedCount !== 1 && "s"}
        </button>
      </div>
    </div>
  );
}
