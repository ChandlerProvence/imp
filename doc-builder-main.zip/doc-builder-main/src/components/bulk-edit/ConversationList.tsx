import { useEffect, useState } from "react";
import type { Conversation } from "../../db/types";
import { getConversationsForSession } from "../../db/chatHistory";

interface Props {
  sessionId: string;
  activeConvKey: string | null;
  /** Increment to force a refresh of the list (e.g., after delete). */
  refreshKey?: number;
  onSelect: (conv: Conversation) => void;
  onNewChat: () => void;
  onDelete: (conv: Conversation) => void;
}

function formatRelativeDate(date: Date): string {
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return "now";
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d ago`;
  return date.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

export default function ConversationList({
  sessionId,
  activeConvKey,
  refreshKey,
  onSelect,
  onNewChat,
  onDelete,
}: Props) {
  const [conversations, setConversations] = useState<Conversation[]>([]);

  // Load/refresh conversations whenever sessionId, activeConvKey, or refreshKey changes
  useEffect(() => {
    let cancelled = false;
    async function load() {
      const convs = await getConversationsForSession(sessionId);
      if (!cancelled) setConversations(convs);
    }
    load();
    return () => { cancelled = true; };
  }, [sessionId, activeConvKey, refreshKey]);

  return (
    <div className="flex flex-col h-full border-r border-gray-200 bg-white">
      {/* Header + New Chat button */}
      <div className="px-3 py-3 border-b border-gray-200 shrink-0">
        <button
          type="button"
          onClick={onNewChat}
          className="w-full flex items-center justify-center gap-1.5 rounded-md border border-gray-300 px-3 py-2 text-xs font-medium text-gray-700 hover:bg-gray-50 transition-colors"
        >
          <span className="text-sm">+</span>
          New Chat
        </button>
      </div>

      {/* Conversation list */}
      <div className="flex-1 overflow-y-auto">
        {conversations.length === 0 ? (
          <div className="px-3 py-6 text-center">
            <p className="text-xs text-gray-400">No conversations yet</p>
          </div>
        ) : (
          <ul className="py-1">
            {conversations.map((conv) => {
              const isActive = conv.fieldKey === activeConvKey;
              return (
                <li key={conv.id} className="group relative">
                  <button
                    type="button"
                    onClick={() => onSelect(conv)}
                    className={`w-full text-left px-3 py-2.5 text-xs transition-colors ${
                      isActive
                        ? "bg-blue-50 border-l-2 border-blue-600"
                        : "hover:bg-gray-50 border-l-2 border-transparent"
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span
                        className={`font-medium truncate ${
                          isActive ? "text-blue-900" : "text-gray-800"
                        }`}
                      >
                        {conv.label}
                      </span>
                      {/* Delete button — visible on hover */}
                      <span
                        role="button"
                        tabIndex={0}
                        onClick={(e) => {
                          e.stopPropagation();
                          onDelete(conv);
                        }}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            e.stopPropagation();
                            onDelete(conv);
                          }
                        }}
                        className="hidden group-hover:inline-flex shrink-0 text-gray-400 hover:text-red-600 text-sm"
                        title="Delete conversation"
                      >
                        ×
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mt-0.5 text-gray-400">
                      <span>{conv.messageCount} msg{conv.messageCount !== 1 && "s"}</span>
                      <span>·</span>
                      <span>{formatRelativeDate(conv.updatedAt)}</span>
                    </div>
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
