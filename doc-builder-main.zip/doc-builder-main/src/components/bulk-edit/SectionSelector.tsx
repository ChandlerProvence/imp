import type { SectionDef } from "../../schemas/types";
import type { SectionStatus } from "../../engine/types";

interface Props {
  sections: SectionDef[];
  selected: Set<string>;
  sectionStatuses: Record<string, SectionStatus>;
  onToggle: (sectionId: string) => void;
  onSelectAll: () => void;
  onDeselectAll: () => void;
}

const STATUS_BADGE: Record<SectionStatus, { label: string; color: string }> = {
  empty: { label: "○", color: "text-gray-400" },
  "in-progress": { label: "◐", color: "text-amber-500" },
  complete: { label: "✓", color: "text-green-600" },
};

export default function SectionSelector({
  sections,
  selected,
  sectionStatuses,
  onToggle,
  onSelectAll,
  onDeselectAll,
}: Props) {
  const allSelected = selected.size === sections.length;

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <label className="text-sm font-medium text-gray-700">
          Sections to edit
        </label>
        <button
          type="button"
          onClick={allSelected ? onDeselectAll : onSelectAll}
          className="text-xs text-blue-600 hover:text-blue-800 font-medium"
        >
          {allSelected ? "Deselect All" : "Select All"}
        </button>
      </div>

      <div className="border border-gray-200 rounded-md divide-y divide-gray-100 max-h-56 overflow-y-auto">
        {sections.map((section) => {
          const status = sectionStatuses[section.id] ?? "empty";
          const badge = STATUS_BADGE[status];

          return (
            <label
              key={section.id}
              className="flex items-center gap-3 px-3 py-2 cursor-pointer hover:bg-gray-50"
            >
              <input
                type="checkbox"
                checked={selected.has(section.id)}
                onChange={() => onToggle(section.id)}
                className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <span className="flex-1 text-sm text-gray-800">
                {section.title}
              </span>
              <span className="text-xs text-gray-400">
                {section.fields.length} field{section.fields.length !== 1 && "s"}
              </span>
              <span className={`text-xs ${badge.color}`} title={status}>
                {badge.label}
              </span>
            </label>
          );
        })}
      </div>

      {selected.size === 0 && (
        <p className="text-xs text-red-500">
          Select at least one section to continue.
        </p>
      )}
    </div>
  );
}
