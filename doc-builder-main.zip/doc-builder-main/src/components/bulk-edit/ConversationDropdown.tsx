import { useEffect, useState } from "react";
import type { Conversation } from "../../db/types";
import { getConversationsForSession } from "../../db/chatHistory";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface Props {
  sessionId: string;
  activeConvKey: string | null;
  /** Increment to force a refresh (e.g., after starting a new conversation). */
  refreshKey?: number;
  /** Only show conversations whose fieldKey starts with this prefix. */
  filterPrefix?: string;
  onSelect: (conv: Conversation) => void;
  onNewDraft: () => void;
  /** Delete a conversation. The list refreshes once the promise settles. */
  onDelete?: (conv: Conversation) => Promise<void>;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function formatRelativeDate(date: Date): string {
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return "now";
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d ago`;
  return date.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

/**
 * A dropdown menu in the header that shows conversation history.
 * Replaces the always-visible sidebar.
 */
export default function ConversationDropdown({
  sessionId,
  activeConvKey,
  refreshKey,
  filterPrefix,
  onSelect,
  onNewDraft,
  onDelete,
}: Props) {
  const [open, setOpen] = useState(false);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [reloadKey, setReloadKey] = useState(0);

  // Load conversations
  useEffect(() => {
    let cancelled = false;
    getConversationsForSession(sessionId).then((convs) => {
      if (!cancelled) {
        const filtered = filterPrefix
          ? convs.filter((c) => c.fieldKey.startsWith(filterPrefix))
          : convs;
        setConversations(filtered);
      }
    });
    return () => {
      cancelled = true;
    };
  }, [sessionId, activeConvKey, refreshKey, filterPrefix, reloadKey]);

  const handleDelete = async (conv: Conversation) => {
    if (!onDelete || deletingId) return;
    setDeletingId(conv.id);
    try {
      await onDelete(conv);
    } finally {
      setDeletingId(null);
      setReloadKey((k) => k + 1);
    }
  };

  const activeConv = conversations.find((c) => c.fieldKey === activeConvKey);
  const triggerLabel = activeConv?.label ?? "Chat Sessions";

  return (
    <div className="relative">
      {/* Trigger button */}
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="inline-flex items-center gap-1.5 rounded-md border border-gray-300 bg-white px-3 py-1.5 text-sm text-gray-700 hover:bg-gray-50 transition-colors"
      >
        <span className="font-medium">{triggerLabel}</span>
        <svg
          className={`w-3.5 h-3.5 text-gray-400 transition-transform ${open ? "rotate-180" : ""}`}
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          strokeWidth={2}
        >
          <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
        </svg>
        {conversations.length > 0 && (
          <span className="ml-1 inline-flex items-center justify-center min-w-[1.25rem] h-5 px-1 rounded-full text-xs font-medium bg-gray-100 text-gray-600">
            {conversations.length}
          </span>
        )}
      </button>

      {/* Dropdown */}
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-full mt-1 z-20 w-72 rounded-md border border-gray-200 bg-white shadow-lg">
            {/* New Chat Session */}
            <button
              type="button"
              onClick={() => {
                setOpen(false);
                onNewDraft();
              }}
              className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-blue-600 hover:bg-blue-50 font-medium border-b border-gray-100 transition-colors"
            >
              <span className="text-lg leading-none">+</span>
              New Chat Session
            </button>

            {/* Conversation list */}
            {conversations.length === 0 ? (
              <div className="px-4 py-4 text-center text-xs text-gray-400">
                No conversations yet
              </div>
            ) : (
              <div className="max-h-64 overflow-y-auto py-1">
                {conversations.map((conv) => {
                  const isActive = conv.fieldKey === activeConvKey;
                  const isDeleting = deletingId === conv.id;
                  return (
                    <div
                      key={conv.id}
                      className={`group flex items-stretch transition-colors ${
                        isActive
                          ? "bg-blue-50 border-l-2 border-blue-600"
                          : "hover:bg-gray-50 border-l-2 border-transparent"
                      } ${isDeleting ? "opacity-50" : ""}`}
                    >
                      <button
                        type="button"
                        disabled={isDeleting}
                        onClick={() => {
                          setOpen(false);
                          onSelect(conv);
                        }}
                        className="flex-1 min-w-0 text-left px-4 py-2.5"
                      >
                        <div className="flex items-center justify-between">
                          <span
                            className={`text-sm font-medium truncate ${
                              isActive ? "text-blue-900" : "text-gray-800"
                            }`}
                          >
                            {conv.label}
                          </span>
                          {isActive && (
                            <span className="text-xs text-blue-600 font-medium shrink-0">
                              Active
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 mt-0.5 text-xs text-gray-400">
                          <span>{conv.messageCount} msg{conv.messageCount !== 1 && "s"}</span>
                          <span>·</span>
                          <span>{formatRelativeDate(conv.updatedAt)}</span>
                        </div>
                      </button>
                      {onDelete && (
                        <button
                          type="button"
                          disabled={isDeleting}
                          onClick={(e) => {
                            e.stopPropagation();
                            void handleDelete(conv);
                          }}
                          className="shrink-0 px-2 text-gray-300 hover:text-red-600 hover:bg-red-50 opacity-0 group-hover:opacity-100 focus:opacity-100 transition-opacity"
                          aria-label={`Delete chat session ${conv.label}`}
                          title="Delete chat session"
                        >
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M6 7h12M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2m-7 0v12a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V7" />
                          </svg>
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
