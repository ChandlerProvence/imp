import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import SectionSelector from "./SectionSelector";
import type { SectionDef } from "../../schemas/types";

const sections: SectionDef[] = [
  { id: "s1", title: "Parties", fields: [{ id: "f1", label: "F1", type: "string", required: false }] },
  { id: "s2", title: "Terms", fields: [{ id: "f2", label: "F2", type: "string", required: false }, { id: "f3", label: "F3", type: "string", required: false }] },
];

const statuses = { s1: "complete" as const, s2: "in-progress" as const };

describe("SectionSelector", () => {
  it("renders all section titles", () => {
    render(
      <SectionSelector
        sections={sections}
        selected={new Set(["s1"])}
        sectionStatuses={statuses}
        onToggle={vi.fn()}
        onSelectAll={vi.fn()}
        onDeselectAll={vi.fn()}
      />,
    );
    expect(screen.getByText("Parties")).toBeInTheDocument();
    expect(screen.getByText("Terms")).toBeInTheDocument();
  });

  it("shows field counts", () => {
    render(
      <SectionSelector
        sections={sections}
        selected={new Set()}
        sectionStatuses={statuses}
        onToggle={vi.fn()}
        onSelectAll={vi.fn()}
        onDeselectAll={vi.fn()}
      />,
    );
    // "1 field" for Parties, "2 fields" for Terms
    const fieldCounts = screen.getAllByText(/\d+ fields?/);
    expect(fieldCounts).toHaveLength(2);
  });

  it("shows status badges", () => {
    render(
      <SectionSelector
        sections={sections}
        selected={new Set()}
        sectionStatuses={statuses}
        onToggle={vi.fn()}
        onSelectAll={vi.fn()}
        onDeselectAll={vi.fn()}
      />,
    );
    expect(screen.getAllByTitle("complete")).toHaveLength(1);
    expect(screen.getAllByTitle("in-progress")).toHaveLength(1);
  });

  it("calls onToggle when a checkbox is clicked", () => {
    const onToggle = vi.fn();
    render(
      <SectionSelector
        sections={sections}
        selected={new Set(["s1"])}
        sectionStatuses={statuses}
        onToggle={onToggle}
        onSelectAll={vi.fn()}
        onDeselectAll={vi.fn()}
      />,
    );
    const checkboxes = screen.getAllByRole("checkbox");
    fireEvent.click(checkboxes[1]); // Toggle "Terms"
    expect(onToggle).toHaveBeenCalledWith("s2");
  });

  it("shows Select All when not all selected", () => {
    render(
      <SectionSelector
        sections={sections}
        selected={new Set(["s1"])}
        sectionStatuses={statuses}
        onToggle={vi.fn()}
        onSelectAll={vi.fn()}
        onDeselectAll={vi.fn()}
      />,
    );
    expect(screen.getByRole("button", { name: "Select All" })).toBeInTheDocument();
  });

  it("shows Deselect All when all selected", () => {
    render(
      <SectionSelector
        sections={sections}
        selected={new Set(["s1", "s2"])}
        sectionStatuses={statuses}
        onToggle={vi.fn()}
        onSelectAll={vi.fn()}
        onDeselectAll={vi.fn()}
      />,
    );
    expect(screen.getByText("Deselect All")).toBeInTheDocument();
  });

  it("calls onSelectAll when Select All clicked", () => {
    const onSelectAll = vi.fn();
    render(
      <SectionSelector
        sections={sections}
        selected={new Set()}
        sectionStatuses={statuses}
        onToggle={vi.fn()}
        onSelectAll={onSelectAll}
        onDeselectAll={vi.fn()}
      />,
    );
    fireEvent.click(screen.getByRole("button", { name: "Select All" }));
    expect(onSelectAll).toHaveBeenCalledOnce();
  });

  it("shows validation message when none selected", () => {
    render(
      <SectionSelector
        sections={sections}
        selected={new Set()}
        sectionStatuses={statuses}
        onToggle={vi.fn()}
        onSelectAll={vi.fn()}
        onDeselectAll={vi.fn()}
      />,
    );
    expect(screen.getByText(/Select at least one section/)).toBeInTheDocument();
  });
});
