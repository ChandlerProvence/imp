import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import ConversationDropdown from "./ConversationDropdown";
import type { Conversation } from "../../db/types";

vi.mock("../../db/chatHistory", () => ({
  getConversationsForSession: vi.fn(),
}));

import { getConversationsForSession } from "../../db/chatHistory";

function conv(id: string, fieldKey: string, label: string): Conversation {
  return {
    id,
    sessionId: "s1",
    fieldKey,
    documentTypeId: "dt1",
    documentTypeTitle: "Test Doc",
    label,
    conversationType: "bulk-edit",
    messageCount: 2,
    createdAt: new Date("2026-01-01"),
    updatedAt: new Date("2026-01-02"),
  };
}

const convs = [conv("c1", "__unified_chat:a", "Chat A"), conv("c2", "__unified_chat:b", "Chat B")];

beforeEach(() => {
  vi.mocked(getConversationsForSession).mockReset();
});

describe("ConversationDropdown", () => {
  it("deletes a conversation and reloads the list", async () => {
    vi.mocked(getConversationsForSession)
      .mockResolvedValueOnce(convs)
      .mockResolvedValueOnce([convs[1]]);
    const onDelete = vi.fn(() => Promise.resolve());
    const onSelect = vi.fn();

    render(
      <ConversationDropdown
        sessionId="s1"
        activeConvKey="__unified_chat:a"
        filterPrefix="__unified_chat:"
        onSelect={onSelect}
        onNewDraft={vi.fn()}
        onDelete={onDelete}
      />,
    );

    fireEvent.click(screen.getByRole("button", { name: /Chat Sessions|Chat A/ }));
    await screen.findByText("Chat B");

    fireEvent.click(screen.getByRole("button", { name: "Delete chat session Chat A" }));

    expect(onDelete).toHaveBeenCalledWith(convs[0]);
    expect(onSelect).not.toHaveBeenCalled();
    await waitFor(() => expect(screen.queryByText("Chat A")).not.toBeInTheDocument());
    expect(screen.getByText("Chat B")).toBeInTheDocument();
    expect(getConversationsForSession).toHaveBeenCalledTimes(2);
  });

  it("shows no delete control without an onDelete handler", async () => {
    vi.mocked(getConversationsForSession).mockResolvedValue(convs);

    render(
      <ConversationDropdown
        sessionId="s1"
        activeConvKey={null}
        onSelect={vi.fn()}
        onNewDraft={vi.fn()}
      />,
    );

    fireEvent.click(screen.getByRole("button", { name: /Chat Sessions/ }));
    await screen.findByText("Chat A");
    expect(screen.queryByRole("button", { name: /Delete chat session/ })).not.toBeInTheDocument();
  });
});
