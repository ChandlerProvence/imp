import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import ReferenceDocsPanel from "./ReferenceDocsPanel";
import type { ReferenceDoc } from "../../schemas/types";

const docs: ReferenceDoc[] = [
  { id: "doc1", title: "Policy Guide", description: "Covers FMS policies" },
  { id: "doc2", title: "Template Reference" },
];

describe("ReferenceDocsPanel", () => {
  it("renders nothing when docs array is empty", () => {
    const { container } = render(
      <ReferenceDocsPanel
        docs={[]}
        selected={new Set()}
        onToggle={vi.fn()}
        fetchedTexts={new Map()}
        fetchingIds={new Set()}
        fetchErrors={new Map()}
      />,
    );
    expect(container.firstChild).toBeNull();
  });

  it("renders document titles", () => {
    render(
      <ReferenceDocsPanel
        docs={docs}
        selected={new Set()}
        onToggle={vi.fn()}
        fetchedTexts={new Map()}
        fetchingIds={new Set()}
        fetchErrors={new Map()}
      />,
    );
    expect(screen.getByText("Policy Guide")).toBeInTheDocument();
    expect(screen.getByText("Template Reference")).toBeInTheDocument();
  });

  it("renders description when available", () => {
    const { container } = render(
      <ReferenceDocsPanel
        docs={docs}
        selected={new Set()}
        onToggle={vi.fn()}
        fetchedTexts={new Map()}
        fetchingIds={new Set()}
        fetchErrors={new Map()}
      />,
    );
    expect(container.textContent).toContain("Covers FMS policies");
  });

  it("checks selected docs", () => {
    const { container } = render(
      <ReferenceDocsPanel
        docs={docs}
        selected={new Set(["doc1"])}
        onToggle={vi.fn()}
        fetchedTexts={new Map()}
        fetchingIds={new Set()}
        fetchErrors={new Map()}
      />,
    );
    const checkboxes = container.querySelectorAll('input[type="checkbox"]');
    expect((checkboxes[0] as HTMLInputElement).checked).toBe(true);
    expect((checkboxes[1] as HTMLInputElement).checked).toBe(false);
  });

  it("calls onToggle with doc id when checkbox clicked", () => {
    const onToggle = vi.fn();
    const { container } = render(
      <ReferenceDocsPanel
        docs={docs}
        selected={new Set()}
        onToggle={onToggle}
        fetchedTexts={new Map()}
        fetchingIds={new Set()}
        fetchErrors={new Map()}
      />,
    );
    const checkboxes = container.querySelectorAll('input[type="checkbox"]');
    fireEvent.click(checkboxes[0]);
    expect(onToggle).toHaveBeenCalledWith("doc1");
  });

  it("shows fetching indicator", () => {
    render(
      <ReferenceDocsPanel
        docs={docs}
        selected={new Set(["doc1"])}
        onToggle={vi.fn()}
        fetchedTexts={new Map()}
        fetchingIds={new Set(["doc1"])}
        fetchErrors={new Map()}
      />,
    );
    expect(screen.getByText("Fetching…")).toBeInTheDocument();
  });

  it("shows error message", () => {
    render(
      <ReferenceDocsPanel
        docs={docs}
        selected={new Set()}
        onToggle={vi.fn()}
        fetchedTexts={new Map()}
        fetchingIds={new Set()}
        fetchErrors={new Map([["doc1", "Network error"]])}
      />,
    );
    expect(screen.getByText("✕ Network error")).toBeInTheDocument();
  });

  it("shows char count for fetched text", () => {
    render(
      <ReferenceDocsPanel
        docs={docs}
        selected={new Set(["doc1"])}
        onToggle={vi.fn()}
        fetchedTexts={new Map([["doc1", "a".repeat(5000)]])}
        fetchingIds={new Set()}
        fetchErrors={new Map()}
      />,
    );
    expect(screen.getByText("✓ 5,000 chars")).toBeInTheDocument();
  });

  it("renders Reference Documents heading", () => {
    const { container } = render(
      <ReferenceDocsPanel
        docs={docs}
        selected={new Set()}
        onToggle={vi.fn()}
        fetchedTexts={new Map()}
        fetchingIds={new Set()}
        fetchErrors={new Map()}
      />,
    );
    const heading = container.querySelector("h3");
    expect(heading?.textContent).toBe("Reference Documents");
  });
});
