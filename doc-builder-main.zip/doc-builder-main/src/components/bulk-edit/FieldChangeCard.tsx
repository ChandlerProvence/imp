import type { ProposedChange } from "../../ai/bulkEdit";
import { parseTableData, type TableData } from "../../engine/tableData";
import type { TableColumnDef } from "../../schemas/types";
import { confidenceTextColor } from "../../constants";

interface Props {
  change: ProposedChange;
  onToggle: () => void;
  /** Whether this field has a related conflict observation. */
  hasConflict?: boolean;
  /** Called when the conflict badge is clicked. */
  onConflictClick?: () => void;
}

function formatValue(value: string | number | boolean | undefined): string {
  if (value === undefined || value === "") return "(empty)";
  if (typeof value === "boolean") return value ? "Yes" : "No";
  return String(value);
}

/** Render a compact table from parsed TableData and column definitions. */
function MiniTable({
  data,
  columns,
}: {
  data: TableData;
  columns: TableColumnDef[];
}) {
  if (data.rows.length === 0) {
    return <span className="text-xs text-gray-400 italic">(empty table)</span>;
  }

  const table = (
    <table className="w-full text-xs border border-gray-200 rounded">
      <thead>
        <tr className="bg-gray-50">
          {columns.map((col) => (
            <th
              key={col.id}
              className="px-2 py-1 text-left font-medium text-gray-600 border-b border-gray-200"
            >
              {col.label}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {data.rows.map((row, i) => (
          <tr key={i} className="border-b border-gray-100 last:border-0">
            {columns.map((col) => (
              <td key={col.id} className="px-2 py-1 text-gray-700">
                {formatCellValue(row[col.id], col)}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );

  // Wrap in expandable details if many rows
  if (data.rows.length > 5) {
    return (
      <details className="mt-1">
        <summary className="text-xs cursor-pointer text-gray-500">
          {data.rows.length} rows <span className="text-gray-400">(click to expand)</span>
        </summary>
        <div className="mt-1 max-h-48 overflow-y-auto">{table}</div>
      </details>
    );
  }

  return <div className="mt-1">{table}</div>;
}

function formatCellValue(
  value: string | number | boolean | undefined,
  col: TableColumnDef,
): string {
  if (value === undefined || value === null || value === "") return "—";
  if (col.type === "boolean") return value ? "Yes" : "No";
  return String(value);
}

export default function FieldChangeCard({ change, onToggle, hasConflict, onConflictClick }: Props) {
  const isTable = change.fieldType === "table" && change.columns;
  const currentDisplay = formatValue(change.currentValue);
  const proposedDisplay = formatValue(change.proposedValue);
  const isLong =
    !isTable &&
    change.fieldType === "freetext" &&
    typeof change.proposedValue === "string" &&
    change.proposedValue.length > 200;

  return (
    <div
      className={`rounded-md border px-3 py-2 ${
        change.accepted
          ? "border-green-200 bg-green-50/50"
          : "border-gray-200 bg-white"
      }`}
    >
      <div className="flex items-start gap-3">
        <input
          type="checkbox"
          checked={change.accepted}
          onChange={onToggle}
          className="mt-1 h-4 w-4 rounded border-gray-300 text-green-600 focus:ring-green-500"
        />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-gray-800">
              {change.fieldLabel}
            </span>
            <span className="text-xs text-gray-400">{change.fieldType}</span>
            <span className={`text-xs font-medium ${confidenceTextColor(change.confidence)}`}>
              {Math.round(change.confidence * 100)}%
            </span>
            {hasConflict && (
              <button
                type="button"
                onClick={(e) => { e.stopPropagation(); onConflictClick?.(); }}
                className="inline-flex items-center gap-0.5 rounded-full bg-amber-50 border border-amber-300 px-1.5 py-0.5 text-[10px] font-medium text-amber-700 hover:bg-amber-100 transition-colors"
                title="View conflict details"
              >
                ⚠ Conflict
              </button>
            )}
            {change.validationError && (
              <span className="text-xs text-amber-600 font-medium">
                ⚠ {change.validationError}
              </span>
            )}
          </div>

          {isTable ? (
            /* Table rendering */
            <>
              {/* Current table value */}
              <div className="mt-1">
                <span className="text-xs text-gray-500 font-medium">Current:</span>
                <MiniTable
                  data={parseTableData(change.currentValue)}
                  columns={change.columns!}
                />
              </div>
              {/* Proposed table value */}
              <div className="mt-2">
                <span className="text-xs text-green-700 font-medium">Proposed:</span>
                <MiniTable
                  data={parseTableData(change.proposedValue)}
                  columns={change.columns!}
                />
              </div>
            </>
          ) : (
            /* Scalar field rendering (existing logic) */
            <>
              {/* Current value */}
              <div className="mt-1">
                <span className="text-xs text-gray-500">Current: </span>
                <span
                  className={`text-xs ${
                    change.currentValue === undefined
                      ? "text-gray-400 italic"
                      : "text-gray-600"
                  }`}
                >
                  {isLong && change.currentValue
                    ? String(change.currentValue).slice(0, 100) + "…"
                    : currentDisplay}
                </span>
              </div>

              {/* Proposed value */}
              <div className="mt-1">
                <span className="text-xs text-green-700 font-medium">
                  Proposed:{" "}
                </span>
                {isLong ? (
                  <details className="inline">
                    <summary className="text-xs text-green-800 cursor-pointer">
                      {proposedDisplay.slice(0, 100)}…
                      <span className="text-gray-400 ml-1">(click to expand)</span>
                    </summary>
                    <pre className="mt-1 text-xs text-green-800 whitespace-pre-wrap bg-green-50 p-2 rounded max-h-48 overflow-y-auto">
                      {proposedDisplay}
                    </pre>
                  </details>
                ) : (
                  <span className="text-xs text-green-800">{proposedDisplay}</span>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
