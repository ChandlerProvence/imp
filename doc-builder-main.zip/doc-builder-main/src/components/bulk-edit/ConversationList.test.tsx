import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import { fireEvent } from "@testing-library/react";
import ConversationList from "./ConversationList";
import type { Conversation } from "../../db/types";

// Mock the db module
vi.mock("../../db/chatHistory", () => ({
  getConversationsForSession: vi.fn(),
}));

import { getConversationsForSession } from "../../db/chatHistory";

const mockConvs: Conversation[] = [
  {
    id: "c1",
    sessionId: "s1",
    fieldKey: "__bulk_edit",
    documentTypeId: "dt1",
    documentTypeTitle: "Test Doc",
    label: "Bulk Edit #1",
    conversationType: "bulk-edit",
    messageCount: 5,
    createdAt: new Date("2026-01-01"),
    updatedAt: new Date("2026-01-02"),
  },
  {
    id: "c2",
    sessionId: "s1",
    fieldKey: "s1.field1",
    documentTypeId: "dt1",
    documentTypeTitle: "Test Doc",
    label: "Field Chat",
    conversationType: "field-chat",
    messageCount: 2,
    createdAt: new Date("2026-01-01"),
    updatedAt: new Date("2026-01-01"),
  },
];

beforeEach(() => {
  vi.mocked(getConversationsForSession).mockResolvedValue(mockConvs);
});

describe("ConversationList", () => {
  const defaultProps = {
    sessionId: "s1",
    activeConvKey: null as string | null,
    onSelect: vi.fn(),
    onNewChat: vi.fn(),
    onDelete: vi.fn(),
  };

  it("shows New Chat button", () => {
    render(<ConversationList {...defaultProps} />);
    expect(screen.getByText("New Chat")).toBeInTheDocument();
  });

  it("calls onNewChat when New Chat clicked", () => {
    const onNewChat = vi.fn();
    render(<ConversationList {...defaultProps} onNewChat={onNewChat} />);
    fireEvent.click(screen.getByText("New Chat"));
    expect(onNewChat).toHaveBeenCalledOnce();
  });

  it("loads and displays conversations", async () => {
    render(<ConversationList {...defaultProps} />);
    await waitFor(() => {
      expect(screen.getByText("Bulk Edit #1")).toBeInTheDocument();
      expect(screen.getByText("Field Chat")).toBeInTheDocument();
    });
  });

  it("shows empty state when no conversations", async () => {
    vi.mocked(getConversationsForSession).mockResolvedValue([]);
    render(<ConversationList {...defaultProps} />);
    await waitFor(() => {
      expect(screen.getByText("No conversations yet")).toBeInTheDocument();
    });
  });

  it("shows message count", async () => {
    render(<ConversationList {...defaultProps} />);
    await waitFor(() => {
      expect(screen.getByText("5 msgs")).toBeInTheDocument();
      expect(screen.getByText("2 msgs")).toBeInTheDocument();
    });
  });

  it("highlights active conversation", async () => {
    render(<ConversationList {...defaultProps} activeConvKey="__bulk_edit" />);
    await waitFor(() => {
      const btn = screen.getByText("Bulk Edit #1").closest("button");
      expect(btn?.className).toContain("bg-blue-50");
    });
  });

  it("calls onSelect when conversation clicked", async () => {
    const onSelect = vi.fn();
    render(<ConversationList {...defaultProps} onSelect={onSelect} />);
    await waitFor(() => screen.getByText("Bulk Edit #1"));
    fireEvent.click(screen.getByText("Bulk Edit #1"));
    expect(onSelect).toHaveBeenCalledWith(mockConvs[0]);
  });
});
