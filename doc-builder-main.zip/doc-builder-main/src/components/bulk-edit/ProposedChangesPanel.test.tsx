import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import ProposedChangesPanel from "./ProposedChangesPanel";
import type { ProposedChange } from "../../ai/bulkEdit";

// Mock FieldChangeCard
vi.mock("./FieldChangeCard", () => ({
  default: ({ change, onToggle }: any) => (
    <div data-testid={`card-${change.fieldKey}`} onClick={onToggle}>
      {change.fieldLabel}
    </div>
  ),
}));

function makeChange(overrides: Partial<ProposedChange> = {}): ProposedChange {
  return {
    fieldKey: "s1.f1",
    sectionId: "s1",
    sectionTitle: "Section One",
    fieldLabel: "Field One",
    fieldType: "string",
    currentValue: "old",
    proposedValue: "new",
    confidence: 0.9,
    accepted: true,
    ...overrides,
  };
}

describe("ProposedChangesPanel", () => {
  const defaultProps = {
    changes: [] as ProposedChange[],
    onToggleChange: vi.fn(),
    onAcceptAll: vi.fn(),
    onRejectAll: vi.fn(),
    onApply: vi.fn(),
  };

  it("shows empty state when no changes", () => {
    render(<ProposedChangesPanel {...defaultProps} />);
    expect(screen.getByText("No changes proposed yet.")).toBeInTheDocument();
  });

  it("shows change count", () => {
    const changes = [makeChange(), makeChange({ fieldKey: "s1.f2", fieldLabel: "F2" })];
    render(<ProposedChangesPanel {...defaultProps} changes={changes} />);
    expect(screen.getByText(/2 changes/)).toBeInTheDocument();
  });

  it("shows accepted count", () => {
    const changes = [
      makeChange({ accepted: true }),
      makeChange({ fieldKey: "s1.f2", accepted: false }),
    ];
    render(<ProposedChangesPanel {...defaultProps} changes={changes} />);
    expect(screen.getByText(/1 accepted/)).toBeInTheDocument();
  });

  it("Apply button is disabled when none accepted", () => {
    const changes = [makeChange({ accepted: false })];
    render(<ProposedChangesPanel {...defaultProps} changes={changes} />);
    expect(screen.getByText("Apply 0")).toBeDisabled();
  });

  it("calls onApply on Apply click", () => {
    const onApply = vi.fn();
    const changes = [makeChange({ accepted: true })];
    render(<ProposedChangesPanel {...defaultProps} changes={changes} onApply={onApply} />);
    fireEvent.click(screen.getByText("Apply 1"));
    expect(onApply).toHaveBeenCalledOnce();
  });

  it("calls onAcceptAll on Select All click", () => {
    const onAcceptAll = vi.fn();
    const changes = [makeChange()];
    render(<ProposedChangesPanel {...defaultProps} changes={changes} onAcceptAll={onAcceptAll} />);
    fireEvent.click(screen.getByText("Select All"));
    expect(onAcceptAll).toHaveBeenCalledOnce();
  });

  it("groups changes by section", () => {
    const changes = [
      makeChange({ sectionId: "s1", sectionTitle: "Alpha" }),
      makeChange({ fieldKey: "s2.f1", sectionId: "s2", sectionTitle: "Beta" }),
    ];
    render(<ProposedChangesPanel {...defaultProps} changes={changes} />);
    expect(screen.getByText("Alpha")).toBeInTheDocument();
    expect(screen.getByText("Beta")).toBeInTheDocument();
  });
});
