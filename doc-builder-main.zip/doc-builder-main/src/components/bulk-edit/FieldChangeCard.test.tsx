import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import FieldChangeCard from "./FieldChangeCard";
import type { ProposedChange } from "../../ai/bulkEdit";

function makeChange(overrides: Partial<ProposedChange> = {}): ProposedChange {
  return {
    fieldKey: "s1.f1",
    sectionId: "s1",
    sectionTitle: "Section",
    fieldLabel: "My Field",
    fieldType: "string",
    currentValue: "old value",
    proposedValue: "new value",
    confidence: 0.85,
    accepted: true,
    ...overrides,
  };
}

describe("FieldChangeCard", () => {
  it("renders field label", () => {
    render(<FieldChangeCard change={makeChange()} onToggle={vi.fn()} />);
    expect(screen.getByText("My Field")).toBeInTheDocument();
  });

  it("renders field type badge", () => {
    const { container } = render(<FieldChangeCard change={makeChange()} onToggle={vi.fn()} />);
    const typeBadges = container.querySelectorAll(".text-xs.text-gray-400");
    const typeTexts = [...typeBadges].map((el) => el.textContent);
    expect(typeTexts).toContain("string");
  });

  it("renders confidence percentage", () => {
    render(<FieldChangeCard change={makeChange({ confidence: 0.72 })} onToggle={vi.fn()} />);
    expect(screen.getByText("72%")).toBeInTheDocument();
  });

  it("renders current and proposed values", () => {
    const { container } = render(<FieldChangeCard change={makeChange()} onToggle={vi.fn()} />);
    expect(container.textContent).toContain("old value");
    expect(container.textContent).toContain("new value");
  });

  it("shows (empty) for undefined current value", () => {
    const { container } = render(
      <FieldChangeCard change={makeChange({ currentValue: undefined })} onToggle={vi.fn()} />,
    );
    expect(container.textContent).toContain("(empty)");
  });

  it("calls onToggle when checkbox clicked", () => {
    const onToggle = vi.fn();
    const { container } = render(<FieldChangeCard change={makeChange()} onToggle={onToggle} />);
    const checkbox = container.querySelector('input[type="checkbox"]')!;
    fireEvent.click(checkbox);
    expect(onToggle).toHaveBeenCalledOnce();
  });

  it("checkbox is checked when accepted", () => {
    const { container } = render(
      <FieldChangeCard change={makeChange({ accepted: true })} onToggle={vi.fn()} />,
    );
    const checkbox = container.querySelector('input[type="checkbox"]') as HTMLInputElement;
    expect(checkbox.checked).toBe(true);
  });

  it("checkbox is unchecked when not accepted", () => {
    const { container } = render(
      <FieldChangeCard change={makeChange({ accepted: false })} onToggle={vi.fn()} />,
    );
    const checkbox = container.querySelector('input[type="checkbox"]') as HTMLInputElement;
    expect(checkbox.checked).toBe(false);
  });

  it("shows validation error when present", () => {
    render(
      <FieldChangeCard
        change={makeChange({ validationError: "Invalid format" })}
        onToggle={vi.fn()}
      />,
    );
    expect(screen.getByText("⚠ Invalid format")).toBeInTheDocument();
  });
});
