import { useCallback, useRef, useState } from "react";

interface Props {
  prompt: string;
  onPromptChange: (value: string) => void;
  files: File[];
  onFilesChange: (files: File[]) => void;
  /** Character counts keyed by file after parsing. */
  parsedLengths: Map<File, number>;
  /** Files currently being parsed. */
  parsingFiles: Set<File>;
}

export default function BulkEditInput({
  prompt,
  onPromptChange,
  files,
  onFilesChange,
  parsedLengths,
  parsingFiles,
}: Props) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragOver(false);
      const dropped = Array.from(e.dataTransfer.files);
      if (dropped.length > 0) onFilesChange([...files, ...dropped]);
    },
    [onFilesChange, files],
  );

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  }, []);

  const handleDragLeave = useCallback(() => setDragOver(false), []);

  const handleRemoveFile = useCallback(
    (fileToRemove: File) => {
      onFilesChange(files.filter((f) => f !== fileToRemove));
    },
    [onFilesChange, files],
  );

  return (
    <div className="space-y-3">
      {/* Prompt textarea */}
      <textarea
        value={prompt}
        onChange={(e) => onPromptChange(e.target.value)}
        placeholder="Describe what you want to fill in, e.g., 'Fill in all party info for Acme Inc contracting with Boeing, effective date January 1 2025, mutual NDA for 2 years.'"
        rows={5}
        className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm placeholder-gray-400 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 resize-y"
      />

      {/* File upload — always shown, optional context docs */}
      <div>
        <p className="text-xs text-gray-500 mb-1.5">
          Reference documents (optional) — added as context for the AI
        </p>
        <div
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onClick={() => fileInputRef.current?.click()}
          className={`flex flex-col items-center justify-center gap-2 rounded-md border-2 border-dashed px-4 py-6 cursor-pointer transition-colors ${
            dragOver
              ? "border-blue-400 bg-blue-50"
              : "border-gray-300 hover:border-gray-400"
          }`}
        >
          <span className="text-sm text-gray-500">
            Drop files here or click to browse
          </span>
          <span className="text-xs text-gray-400">
            Supports .pdf, .docx, .xlsx, .xls, .csv, .txt, and images (.png, .jpg, .gif, .webp)
          </span>
        </div>

        <input
          ref={fileInputRef}
          type="file"
          accept=".pdf,.docx,.xlsx,.xls,.csv,.txt,.md,.png,.jpg,.jpeg,.gif,.webp,.tiff"
          multiple
          className="hidden"
          onChange={(e) => {
            const selected = Array.from(e.target.files ?? []);
            if (selected.length > 0) onFilesChange([...files, ...selected]);
            e.target.value = "";
          }}
        />

        {/* File list */}
        {files.length > 0 && (
          <ul className="mt-2 space-y-1.5">
            {files.map((f, idx) => {
              const isParsing = parsingFiles.has(f);
              const parsedLen = parsedLengths.get(f);
              return (
                <li
                  key={`${f.name}-${f.size}-${idx}`}
                  className="flex items-center gap-2 text-xs rounded-md bg-gray-50 border border-gray-200 px-2 py-1.5"
                >
                  <div className="flex-1 min-w-0">
                    <span className="font-medium text-gray-800 truncate block">
                      {f.name}
                    </span>
                    <span className="text-gray-500">
                      {(f.size / 1024).toFixed(1)} KB
                    </span>
                    {isParsing && (
                      <span className="ml-2 text-blue-600">Parsing…</span>
                    )}
                    {parsedLen !== undefined && !isParsing && parsedLen > 0 && (
                      <span className="ml-2 text-green-600">
                        ✓ {parsedLen.toLocaleString()} chars
                      </span>
                    )}
                    {parsedLen !== undefined && !isParsing && parsedLen === 0 && (
                      <span className="ml-2 text-amber-600">
                        ⚠ No text extracted
                      </span>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleRemoveFile(f);
                    }}
                    className="shrink-0 text-gray-400 hover:text-red-600"
                    title="Remove"
                  >
                    ×
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
