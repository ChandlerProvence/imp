import type { FieldDef } from "../schemas/types";
import type { FieldMeta } from "../db/types";
import type { FieldDestination } from "../engine/fieldDestinations";
import type { BlockValues } from "../engine/contentBlocks";
import { inputAttrsFor, type ValidationIssue } from "../engine/validation";
import { confidenceColor } from "../constants";
import { getScopeColors } from "../utils/scopeColors";
import MagicWandIcon from "./icons/MagicWandIcon";
import TableFieldRenderer from "./TableFieldRenderer";
import ImageField from "./ImageField";
import FieldDestinationBadge from "./FieldDestinationBadge";
import NumberInput from "./NumberInput";
import { parseMultiselectValue, serializeMultiselectValue } from "../engine/multiselectData";

function ConfidenceBadge({ confidence }: { confidence: number }) {
  const pct = Math.round(confidence * 100);
  return (
    <span
      className={`ml-2 inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium ${confidenceColor(confidence)}`}
      title={`AI confidence: ${pct}%`}
    >
      AI {pct}%
    </span>
  );
}

interface Props {
  field: FieldDef;
  /** Namespaced key: "section_id.field_id" */
  fieldKey: string;
  value: string | number | boolean | undefined;
  /** AI metadata for this field (confidence, source). */
  meta?: FieldMeta;
  onChange: (key: string, value: string | number | boolean) => void;
  /** Callback to open AI chat for this freetext field. */
  onOpenChat?: (fieldKey: string) => void;
  /** When true, this field is the active AI drafting target and should be highlighted. */
  isDraftTarget?: boolean;
  /** If set, this field mirrors another and is read-only. Value is the source field label. */
  linkedFromLabel?: string;
  /** Where this field appears in the output document(s). Shown as a badge when provided. */
  destinations?: FieldDestination[];
  /** When true, this field's wand button is the active AI scope target (shown inverted). */
  isScopeTarget?: boolean;
  /** Whether AI hints should be displayed. Defaults to true for backward compat. */
  showHints?: boolean;
  /** Content block values for column-level visibility (passed to TableFieldRenderer). */
  blocks?: BlockValues;
  /** The schema's `constants`, for table column formulas (passed to TableFieldRenderer). */
  constants?: Record<string, number>;
  /** Session ID — required for image fields to store/retrieve blobs. */
  sessionId?: string;
  /** Validation rule problems for this field (warnings only — never blocks). */
  issues?: ValidationIssue[];
}

function IssueList({ issues }: { issues: ValidationIssue[] }) {
  return (
    <>
      {issues.map((issue, i) => (
        <p
          key={i}
          role={issue.severity === "warning" ? "alert" : undefined}
          className={`mt-1 text-xs ${issue.severity === "warning" ? "text-red-600" : "text-gray-500"}`}
        >
          {issue.message}
        </p>
      ))}
    </>
  );
}

export default function FieldRenderer({ field, fieldKey, value, meta, onChange, onOpenChat, isDraftTarget, linkedFromLabel, destinations, isScopeTarget, showHints, blocks, constants, sessionId, issues }: Props) {
  const showBadge = meta && meta.source !== "manual";
  const isLinked = !!linkedFromLabel;

  const labelEl = (
    <div className="flex items-center gap-1.5 mb-1">
      <label htmlFor={fieldKey} className="text-sm font-medium text-gray-700">
        {field.label}
        {field.required && <span className="text-red-500 ml-0.5">*</span>}
      </label>
      {showBadge && <ConfidenceBadge confidence={meta.confidence} />}
      {isLinked && (
        <span className="inline-flex items-center gap-0.5 text-xs text-gray-400 font-normal">
          🔗 Linked to {linkedFromLabel}
        </span>
      )}
      {destinations && destinations.length > 0 && (
        <FieldDestinationBadge destinations={destinations} />
      )}
      {onOpenChat && !isLinked && (
        <button
          type="button"
          onClick={() => onOpenChat(fieldKey)}
          className={`inline-flex items-center justify-center w-5 h-5 rounded-md border transition-colors ${
            isScopeTarget
              ? `${getScopeColors("field").iconBgActive} ${getScopeColors("field").iconTextActive} ${getScopeColors("field").iconBorderActive}`
              : `${getScopeColors("field").iconBg} ${getScopeColors("field").iconText} ${getScopeColors("field").iconBgHover} ${getScopeColors("field").iconBorder}`
          }`}
          title="Focus AI on this field"
        >
          <MagicWandIcon className="w-3 h-3" />
        </button>
      )}
    </div>
  );

  const baseInput =
    "block w-full rounded-md border border-gray-300 px-3 py-2 text-sm shadow-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500";
  const linkedInput =
    "block w-full rounded-md border border-gray-200 bg-gray-50 px-3 py-2 text-sm text-gray-500 cursor-not-allowed";
  const invalidInput =
    "block w-full rounded-md border border-red-400 px-3 py-2 text-sm shadow-sm focus:border-red-500 focus:ring-1 focus:ring-red-500";
  const invalid = !isLinked && !!issues?.some((i) => i.severity === "warning");
  const inputClass = isLinked ? linkedInput : invalid ? invalidInput : baseInput;
  const nativeAttrs = isLinked ? {} : inputAttrsFor(field.validate);
  const issuesEl = issues && issues.length > 0 && !isLinked ? <IssueList issues={issues} /> : null;

  switch (field.type) {
    case "string":
      return (
        <div>
          {labelEl}
          <input
            id={fieldKey}
            type="text"
            className={inputClass}
            aria-invalid={invalid || undefined}
            {...nativeAttrs}
            value={(value as string) ?? ""}
            readOnly={isLinked}
            tabIndex={isLinked ? -1 : undefined}
            onChange={(e) => onChange(fieldKey, e.target.value)}
          />
          {issuesEl}
          {field.ai_hint && showHints !== false && (
            <p className="mt-1 text-xs text-gray-400 italic">{field.ai_hint}</p>
          )}
        </div>
      );

    case "number":
      return (
        <div>
          {labelEl}
          <NumberInput
            id={fieldKey}
            className={inputClass}
            aria-invalid={invalid || undefined}
            value={value}
            format={field.format}
            readOnly={isLinked}
            tabIndex={isLinked ? -1 : undefined}
            onChange={(v) => onChange(fieldKey, v)}
          />
          {issuesEl}
          {field.ai_hint && showHints !== false && (
            <p className="mt-1 text-xs text-gray-400 italic">{field.ai_hint}</p>
          )}
        </div>
      );

    case "boolean":
      return (
        <div>
          <div className="flex items-center gap-2">
            <input
              id={fieldKey}
              type="checkbox"
              className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              checked={!!value}
              disabled={isLinked}
              onChange={(e) => onChange(fieldKey, e.target.checked)}
            />
            <label htmlFor={fieldKey} className={`text-sm ${isLinked ? "text-gray-400" : "text-gray-700"}`}>
              {field.label}
              {field.required && <span className="text-red-500 ml-0.5">*</span>}
              {isLinked && (
                <span className="ml-2 text-xs text-gray-400">🔗 Linked to {linkedFromLabel}</span>
              )}
              {destinations && destinations.length > 0 && (
                <span className="ml-2">
                  <FieldDestinationBadge destinations={destinations} />
                </span>
              )}
            </label>
          </div>
          {issuesEl}
          {field.ai_hint && showHints !== false && (
            <p className="mt-1 text-xs text-gray-400 italic">{field.ai_hint}</p>
          )}
        </div>
      );

    case "date":
      return (
        <div>
          {labelEl}
          <input
            id={fieldKey}
            type="date"
            className={inputClass}
            aria-invalid={invalid || undefined}
            {...nativeAttrs}
            value={(value as string) ?? ""}
            readOnly={isLinked}
            tabIndex={isLinked ? -1 : undefined}
            onChange={(e) => onChange(fieldKey, e.target.value)}
          />
          {issuesEl}
          {field.ai_hint && showHints !== false && (
            <p className="mt-1 text-xs text-gray-400 italic">{field.ai_hint}</p>
          )}
        </div>
      );

    case "enum":
      return (
        <div>
          {labelEl}
          <select
            id={fieldKey}
            className={inputClass}
            aria-invalid={invalid || undefined}
            value={(value as string) ?? ""}
            disabled={isLinked}
            onChange={(e) => onChange(fieldKey, e.target.value)}
          >
            <option value="">— Select —</option>
            {field.options?.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
          {issuesEl}
          {field.ai_hint && showHints !== false && (
            <p className="mt-1 text-xs text-gray-400 italic">{field.ai_hint}</p>
          )}
        </div>
      );

    case "freetext":
      return (
        <div>
          {labelEl}
          <textarea
            id={fieldKey}
            rows={6}
            className={isLinked
              ? `${linkedInput} resize-none`
              : `${invalid ? invalidInput : baseInput} resize-y${isDraftTarget ? " ring-2 ring-green-400 border-green-400" : ""}`}
            aria-invalid={invalid || undefined}
            {...nativeAttrs}
            value={(value as string) ?? ""}
            readOnly={isLinked}
            tabIndex={isLinked ? -1 : undefined}
            onChange={(e) => onChange(fieldKey, e.target.value)}
          />
          {issuesEl}
          {!isLinked && field.ai_hint && showHints !== false && (
            <p className="mt-1 text-xs text-gray-400 italic">{field.ai_hint}</p>
          )}
        </div>
      );

    case "table":
      return (
        <div>
          <TableFieldRenderer
            field={field}
            fieldKey={fieldKey}
            value={value}
            meta={meta}
            onChange={onChange}
            onOpenChat={onOpenChat}
            linkedFromLabel={linkedFromLabel}
            destinations={destinations}
            showHints={showHints}
            blocks={blocks}
            constants={constants}
          />
          {issuesEl}
        </div>
      );

    case "image":
      return sessionId ? (
        <ImageField
          field={field}
          fieldKey={fieldKey}
          value={value}
          meta={meta}
          sessionId={sessionId}
          onChange={onChange}
          destinations={destinations}
          showHints={showHints}
        />
      ) : null;

    case "multiselect": {
      const selected = parseMultiselectValue(value as string | number | boolean | undefined);
      return (
        <div>
          {labelEl}
          <fieldset className="space-y-2 mt-1">
            {field.options?.map((opt) => {
              const checked = selected.includes(opt);
              return (
                <label key={opt} className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    checked={checked}
                    disabled={isLinked}
                    onChange={() => {
                      const next = checked
                        ? selected.filter((v) => v !== opt)
                        : [...selected, opt];
                      onChange(fieldKey, serializeMultiselectValue(next));
                    }}
                  />
                  <span className={`text-sm ${isLinked ? "text-gray-400" : "text-gray-700"}`}>
                    {opt}
                  </span>
                </label>
              );
            })}
          </fieldset>
          {issuesEl}
          {field.ai_hint && showHints !== false && (
            <p className="mt-1 text-xs text-gray-400 italic">{field.ai_hint}</p>
          )}
        </div>
      );
    }

    default:
      return null;
  }
}
