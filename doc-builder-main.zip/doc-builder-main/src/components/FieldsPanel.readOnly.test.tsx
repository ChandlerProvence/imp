/**
 * While another tab holds the session lock, edits are discarded, so every
 * control in the panel must be disabled rather than appear to accept input.
 * Uses the real FieldRenderer (FieldsPanel.test.tsx mocks it).
 */
import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import FieldsPanel from "./FieldsPanel";
import type { SectionDef } from "../schemas/types";

const section: SectionDef = {
  id: "price",
  title: "Pricing",
  fields: [
    { id: "reason", label: "Reason", type: "string", required: false },
    { id: "from", label: "Previous price", type: "number", required: false, format: "currency" },
    { id: "tte", label: "Includes TT&E", type: "boolean", required: false },
    {
      id: "lines",
      label: "Lines",
      type: "table",
      required: false,
      columns: [{ id: "rate", label: "Rate", type: "number" }],
    },
  ],
};

const lines = JSON.stringify({ rows: [{ rate: 5 }] });

describe("FieldsPanel — read-only (session locked by another tab)", () => {
  it("disables every input and button", () => {
    render(<FieldsPanel section={section} answers={{ "price.lines": lines }} fieldMeta={{}} onAnswer={vi.fn()} readOnly />);
    expect(screen.getByLabelText("Reason")).toBeDisabled();
    expect(screen.getByLabelText(/Previous price/)).toBeDisabled();
    expect(screen.getByLabelText("Includes TT&E")).toBeDisabled();
    expect(screen.getByLabelText(/^Rate/)).toBeDisabled();
    expect(screen.getByRole("button", { name: /Add Row/ })).toBeDisabled();
  });

  it("leaves inputs enabled normally", () => {
    render(<FieldsPanel section={section} answers={{ "price.lines": lines }} fieldMeta={{}} onAnswer={vi.fn()} />);
    expect(screen.getByLabelText(/Previous price/)).toBeEnabled();
    expect(screen.getByLabelText(/^Rate/)).toBeEnabled();
  });
});
