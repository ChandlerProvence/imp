import { useState, useCallback, useEffect, useMemo } from "react";
import type { FieldDef } from "../schemas/types";
import type { FieldMeta } from "../db/types";
import type { FieldDestination } from "../engine/fieldDestinations";
import type { BlockValues } from "../engine/contentBlocks";
import { confidenceColor } from "../constants";
import {
  parseTableData,
  serializeTableData,
  createEmptyRow,
  initFixedRowTable,
  type TableData,
  type TableRow,
} from "../engine/tableData";
import { computeTableFormulas } from "../engine/formula/evaluate";
import { getVisibleColumns, evaluateVisibleWhen } from "../engine/visibility";
import FieldDestinationBadge from "./FieldDestinationBadge";
import MagicWandIcon from "./icons/MagicWandIcon";
import { getScopeColors } from "../utils/scopeColors";
import { CellInput } from "./table";

interface Props {
  field: FieldDef;
  /** Namespaced key: "section_id.field_id" */
  fieldKey: string;
  value: string | number | boolean | undefined;
  /** AI metadata for this field (confidence, source). */
  meta?: FieldMeta;
  onChange: (key: string, value: string | number | boolean) => void;
  /** Callback to open AI chat for this table field. */
  onOpenChat?: (fieldKey: string) => void;
  /** If set, this field mirrors another and is read-only. */
  linkedFromLabel?: string;
  /** Where this field appears in the output document(s). */
  destinations?: FieldDestination[];
  /** Whether AI hints should be displayed. Defaults to true for backward compat. */
  showHints?: boolean;
  /** Content block values for column-level visibility. */
  blocks?: BlockValues;
  /** The schema's `constants`, for column formulas that use them. */
  constants?: Record<string, number>;
}

export default function TableFieldRenderer({
  field,
  fieldKey,
  value,
  meta,
  onChange,
  onOpenChat,
  linkedFromLabel,
  destinations,
  showHints,
  blocks,
  constants,
}: Props) {
  const allColumns = field.columns ?? [];
  // Visible columns respect content-block gates; all columns used for storage.
  const columns = useMemo(
    () => (blocks ? getVisibleColumns(field, blocks) : allColumns),
    [field, allColumns, blocks],
  );
  const hiddenInputIds = useMemo(() => {
    if (!blocks) return new Set<string>();
    return new Set(
      allColumns
        .filter((c) => c.visible_when && !c.formula && !evaluateVisibleWhen(c.visible_when, blocks))
        .map((c) => c.id),
    );
  }, [allColumns, blocks]);
  const isFixedRow = !!field.rows;
  const isLinked = !!linkedFromLabel;
  const minRows = field.min_rows ?? 1;
  const maxRows = field.max_rows;
  const hasFormulas = allColumns.some((c) => c.formula);
  const formulaColIds = useMemo(
    () => new Set(allColumns.filter((c) => c.formula).map((c) => c.id)),
    [allColumns],
  );

  // Parse stored table data (or initialize fixed-row table)
  const [tableData, setTableData] = useState<TableData>(() => {
    const parsed = parseTableData(value);
    if (isFixedRow && parsed.rows.length === 0) {
      return initFixedRowTable(field);
    }
    return parsed;
  });

  /** Mask hidden inputs and recompute formulas on a row set. */
  const recomputeRows = useCallback(
    (rows: TableRow[]): TableRow[] => {
      if (!hasFormulas) return rows;
      // Blank hidden input columns before formula evaluation so
      // e.g. total_unit_cost = tte_rate + COALESCE(rr_rate, 0) drops hidden rr_rate.
      const masked = hiddenInputIds.size > 0
        ? rows.map((r) => {
            const m = { ...r };
            for (const id of hiddenInputIds) m[id] = "";
            return m;
          })
        : rows;
      return computeTableFormulas(allColumns, masked, constants);
    },
    [hasFormulas, hiddenInputIds, allColumns, constants],
  );

  // Sync from external value changes (e.g., AI draft inserted)
  useEffect(() => {
    const parsed = parseTableData(value);
    if (isFixedRow && parsed.rows.length === 0) {
      setTableData(initFixedRowTable(field));
    } else {
      setTableData({ rows: recomputeRows(parsed.rows) });
    }
  }, [value, field, isFixedRow, recomputeRows]);

  const persistTable = useCallback(
    (data: TableData) => {
      setTableData(data);
      onChange(fieldKey, serializeTableData(data));
    },
    [fieldKey, onChange],
  );

  const handleCellChange = useCallback(
    (rowIndex: number, columnId: string, cellValue: string | number | boolean) => {
      const newRows = [...tableData.rows];
      newRows[rowIndex] = { ...newRows[rowIndex], [columnId]: cellValue };
      persistTable({ rows: recomputeRows(newRows) });
    },
    [tableData, persistTable, recomputeRows],
  );

  const handleAddRow = useCallback(() => {
    if (maxRows && tableData.rows.length >= maxRows) return;
    const newRow = createEmptyRow(allColumns);
    persistTable({ rows: [...tableData.rows, newRow] });
  }, [tableData, allColumns, maxRows, persistTable]);

  const handleRemoveRow = useCallback(
    (index: number) => {
      if (tableData.rows.length <= minRows) return;
      const newRows = tableData.rows.filter((_, i) => i !== index);
      persistTable({ rows: newRows });
    },
    [tableData, minRows, persistTable],
  );

  // Get row label for fixed-row tables
  const getRowLabel = (row: TableRow, index: number): string | null => {
    if (!isFixedRow || !field.rows) return null;
    const rowId = row._rowId as string | undefined;
    if (rowId) {
      const def = field.rows.find((r) => r.id === rowId);
      return def?.label ?? null;
    }
    // Fallback: match by index
    return field.rows[index]?.label ?? null;
  };

  const showBadge = meta && meta.source !== "manual";

  return (
    <div className="space-y-2">
      {/* Header with label + AI badge */}
      <div className="flex items-center gap-1.5 mb-1">
        <label className="text-sm font-medium text-gray-700">
          {field.label}
          {field.required && <span className="text-red-500 ml-0.5">*</span>}
        </label>
        {showBadge && (
          <span
            className={`inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium ${confidenceColor(meta.confidence)}`}
            title={`AI confidence: ${Math.round(meta.confidence * 100)}%`}
          >
            AI {Math.round(meta.confidence * 100)}%
          </span>
        )}
        {isLinked && (
          <span className="inline-flex items-center gap-0.5 text-xs text-gray-400 font-normal">
            🔗 Linked to {linkedFromLabel}
          </span>
        )}
        {destinations && destinations.length > 0 && (
          <FieldDestinationBadge destinations={destinations} />
        )}
        {!isLinked && onOpenChat && (
          <button
            type="button"
            onClick={() => onOpenChat(fieldKey)}
            className={`inline-flex items-center justify-center w-5 h-5 rounded-md border transition-colors ${getScopeColors("field").iconBg} ${getScopeColors("field").iconText} ${getScopeColors("field").iconBgHover} ${getScopeColors("field").iconBorder}`}
            title="Focus AI on this field"
          >
            <MagicWandIcon className="w-3 h-3" />
          </button>
        )}
      </div>

      {/* Table */}
      <div className="overflow-x-auto rounded-lg border border-gray-200">
        <table className="min-w-full divide-y divide-gray-200 text-sm">
          <thead className="bg-gray-50">
            <tr>
              {isFixedRow && (
                <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">
                  {/* Row header column */}
                </th>
              )}
              {columns.map((col) => (
                <th
                  key={col.id}
                  className={`px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap ${
                    col.type === "string" ? "min-w-[10rem]" : col.type === "number" ? "min-w-[6rem]" : ""
                  }`}
                >
                  {col.label}
                </th>
              ))}
              {!isFixedRow && !isLinked && (
                <th className="px-2 py-2 w-8">{/* Delete column */}</th>
              )}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 bg-white">
            {tableData.rows.map((row, rowIndex) => (
              <tr key={rowIndex} className="hover:bg-gray-50/50">
                {isFixedRow && (
                  <td className="px-3 py-2 text-sm font-medium text-gray-700 whitespace-nowrap bg-gray-50/50">
                    {getRowLabel(row, rowIndex)}
                  </td>
                )}
                {columns.map((col) => (
                  <td key={col.id} className={`px-2 py-1.5 ${
                    col.type === "string" ? "min-w-[10rem]" : col.type === "number" ? "min-w-[6rem]" : ""
                  }`}>
                    <CellInput
                      column={col}
                      value={row[col.id] ?? (col.type === "boolean" ? false : "")}
                      readOnly={isLinked}
                      isFormula={formulaColIds.has(col.id)}
                      rowLabel={getRowLabel(row, rowIndex) ?? `Row ${rowIndex + 1}`}
                      onChange={(val) => handleCellChange(rowIndex, col.id, val)}
                    />
                  </td>
                ))}
                {!isFixedRow && !isLinked && (
                  <td className="px-2 py-1.5 text-center">
                    <button
                      type="button"
                      onClick={() => handleRemoveRow(rowIndex)}
                      disabled={tableData.rows.length <= minRows}
                      className="text-gray-400 hover:text-red-500 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                      title="Remove row"
                    >
                      <svg
                        className="h-4 w-4"
                        fill="none"
                        viewBox="0 0 24 24"
                        strokeWidth={1.5}
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M6 18L18 6M6 6l12 12"
                        />
                      </svg>
                    </button>
                  </td>
                )}
              </tr>
            ))}
            {tableData.rows.length === 0 && (
              <tr>
                <td
                  colSpan={columns.length + (isFixedRow ? 1 : 0) + (!isFixedRow && !isLinked ? 1 : 0)}
                  className="px-3 py-4 text-center text-sm text-gray-400 italic"
                >
                  No rows yet. Click "Add Row" to begin.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Add row button (dynamic mode only) */}
      {!isFixedRow && !isLinked && (
        <button
          type="button"
          onClick={handleAddRow}
          disabled={!!maxRows && tableData.rows.length >= maxRows}
          className="inline-flex items-center gap-1 rounded-md border border-gray-300 bg-white px-3 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          <svg
            className="h-3.5 w-3.5"
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth={1.5}
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
          </svg>
          Add Row
          {maxRows && (
            <span className="text-gray-400 ml-1">
              ({tableData.rows.length}/{maxRows})
            </span>
          )}
        </button>
      )}

      {/* AI hint */}
      {field.ai_hint && showHints !== false && (
        <p className="text-xs text-gray-400 italic">{field.ai_hint}</p>
      )}
    </div>
  );
}
