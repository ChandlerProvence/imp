import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import CopyDiagnosticsButton from "./CopyDiagnosticsButton";

// Mock the AI modules so the button can call them without full setup
vi.mock("../ai/endpoints", () => ({
  getActiveEndpointConfig: () => ({
    id: "non-cui",
    label: "Proprietary (IL2)",
    baseUrl: "https://proxy.example.com",
  }),
}));
vi.mock("../ai/models", () => ({
  getModelResolution: () => [
    { role: "standard", id: "claude-sub", source: "substituted", configured: "claude-old" },
  ],
}));
vi.mock("../ai/featureFlags", () => ({
  getFeatureFlags: () => ({ promptCaching: true, effort: true }),
}));

describe("CopyDiagnosticsButton", () => {
  beforeEach(() => {
    Object.assign(navigator, {
      clipboard: { writeText: vi.fn().mockResolvedValue(undefined) },
    });
  });

  it("renders a button with 'Copy diagnostics' text", () => {
    render(<CopyDiagnosticsButton />);
    expect(screen.getByRole("button", { name: /copy diagnostics/i })).toBeInTheDocument();
  });

  it("copies a diagnostics report to the clipboard on click", () => {
    render(<CopyDiagnosticsButton />);
    fireEvent.click(screen.getByRole("button", { name: /copy diagnostics/i }));
    expect(navigator.clipboard.writeText).toHaveBeenCalledTimes(1);
    const text = (navigator.clipboard.writeText as ReturnType<typeof vi.fn>).mock.calls[0][0];
    expect(text).toContain("doc-builder-diagnostics");
    expect(text).toContain("Proprietary (IL2)");
  });

  it("shows 'Copied!' after clicking", async () => {
    render(<CopyDiagnosticsButton />);
    fireEvent.click(screen.getByRole("button", { name: /copy diagnostics/i }));
    await waitFor(() => {
      expect(screen.getByText("Copied!")).toBeInTheDocument();
    });
  });

  it("passes schemaId through to the report", () => {
    render(<CopyDiagnosticsButton schemaId="nda" />);
    fireEvent.click(screen.getByRole("button", { name: /copy diagnostics/i }));
    const text = (navigator.clipboard.writeText as ReturnType<typeof vi.fn>).mock.calls[0][0];
    expect(text).toContain('"schemaId": "nda"');
  });

  it("includes resolved models with their source", () => {
    render(<CopyDiagnosticsButton />);
    fireEvent.click(screen.getByRole("button", { name: /copy diagnostics/i }));
    const text = (navigator.clipboard.writeText as ReturnType<typeof vi.fn>).mock.calls[0][0];
    expect(text).toContain('"source": "substituted"');
    expect(text).toContain('"configured": "claude-old"');
  });

  it("includes the build identity", () => {
    render(<CopyDiagnosticsButton />);
    fireEvent.click(screen.getByRole("button", { name: /copy diagnostics/i }));
    const text = (navigator.clipboard.writeText as ReturnType<typeof vi.fn>).mock.calls[0][0];
    expect(text).toContain('"build"');
    expect(text).toContain("Build: dev");
  });
});
