import { useRef, useState } from "react";
import { ENDPOINTS, type EndpointId } from "../ai/endpoints";
import type { ModelRole } from "../ai/models";
import type { AppError } from "../errors";
import AppErrorBox from "./AppErrorBox";
import ModelSettings from "./ModelSettings";

const ENDPOINT_ORDER: EndpointId[] = ["non-cui", "cui"];

type TestStatus = "idle" | "testing" | "ok" | "error";

/** Blue for Proprietary, amber for CUI — matches EndpointBadge elsewhere in the app. */
const TONE: Record<EndpointId, { tab: string; panel: string; badge: string; button: string }> = {
  "non-cui": {
    tab: "bg-blue-50 text-blue-900 border-blue-300",
    panel: "border-blue-300 bg-blue-50/30",
    badge: "bg-blue-600 text-white",
    button: "border-blue-300 text-blue-800 hover:bg-blue-100",
  },
  cui: {
    tab: "bg-amber-50 text-amber-900 border-amber-300",
    panel: "border-amber-300 bg-amber-50/30",
    badge: "bg-amber-600 text-white",
    button: "border-amber-300 text-amber-800 hover:bg-amber-100",
  },
};

interface Props {
  /** Endpoint chosen for AI requests (applied on Save). */
  inUse: EndpointId;
  onUseEndpoint: (ep: EndpointId) => void;
  /** API keys as typed (may be unsaved). */
  keys: Record<EndpointId, string>;
  onKeyChange: (ep: EndpointId, value: string) => void;
  testStatus: Record<EndpointId, TestStatus>;
  testError: Record<EndpointId, AppError | null>;
  onTest: (ep: EndpointId) => void;
  modelDrafts: Record<EndpointId, Partial<Record<ModelRole, string>>>;
  onModelChange: (ep: EndpointId, role: ModelRole, id: string | null) => void;
}

/**
 * Settings → AI endpoints. One tab per endpoint holding its key, URL, models,
 * and whether AI requests use it. Viewing a tab never changes the endpoint in
 * use — that's the explicit "Use this endpoint" choice inside the tab.
 */
export default function EndpointSettings({
  inUse,
  onUseEndpoint,
  keys,
  onKeyChange,
  testStatus,
  testError,
  onTest,
  modelDrafts,
  onModelChange,
}: Props) {
  // Remounted each time Settings opens, so it always starts on the endpoint in use
  const [viewing, setViewing] = useState<EndpointId>(inUse);
  const tabRefs = useRef<Partial<Record<EndpointId, HTMLButtonElement | null>>>({});

  const config = ENDPOINTS[viewing];
  const inUseLabel = ENDPOINTS[inUse].label;
  const inUseHasKey = !!keys[inUse].trim();
  const status = testStatus[viewing];
  const error = testError[viewing];
  const keyInputId = `${viewing}-key-input`;

  function handleTabKeyDown(e: React.KeyboardEvent) {
    if (e.key !== "ArrowLeft" && e.key !== "ArrowRight") return;
    e.preventDefault();
    const idx = ENDPOINT_ORDER.indexOf(viewing);
    const next = ENDPOINT_ORDER[(idx + (e.key === "ArrowRight" ? 1 : -1) + ENDPOINT_ORDER.length) % ENDPOINT_ORDER.length];
    setViewing(next);
    tabRefs.current[next]?.focus();
  }

  return (
    <div className="mt-5">
      <span className="block text-sm font-medium text-gray-700">AI Endpoints</span>
      <p className="mt-0.5 text-xs text-gray-600" data-testid="endpoint-in-use">
        AI requests use: <span className="font-semibold">{inUseLabel}</span>
      </p>
      {!inUseHasKey && (
        <p className="mt-1 text-xs text-amber-700" role="note">
          {inUseLabel} is in use but has no API key — AI features won't work until you add one in its tab.
        </p>
      )}

      <div role="tablist" aria-label="AI endpoints" className="mt-2 flex gap-1" onKeyDown={handleTabKeyDown}>
        {ENDPOINT_ORDER.map((ep) => {
          const selected = ep === viewing;
          const hasKey = !!keys[ep].trim();
          const customized = Object.keys(modelDrafts[ep]).length > 0;
          return (
            <button
              key={ep}
              ref={(el) => {
                tabRefs.current[ep] = el;
              }}
              id={`endpoint-tab-${ep}`}
              type="button"
              role="tab"
              aria-selected={selected}
              aria-controls={`endpoint-panel-${ep}`}
              tabIndex={selected ? 0 : -1}
              onClick={() => setViewing(ep)}
              className={`flex-1 inline-flex items-center justify-center gap-1.5 rounded-t-md border border-b-0 px-3 py-2 text-sm font-medium transition-colors ${
                selected ? TONE[ep].tab : "bg-white text-gray-600 border-gray-200 hover:bg-gray-50"
              }`}
            >
              {ENDPOINTS[ep].label}
              {ep === inUse && (
                <span className={`rounded px-1.5 py-0.5 text-[10px] font-semibold ${TONE[ep].badge}`}>In use</span>
              )}
              {!hasKey && <span className="text-[10px] font-normal text-gray-500">No key</span>}
              {customized && (
                <span className="h-1.5 w-1.5 rounded-full bg-gray-500" title="Custom models" aria-label="custom models" />
              )}
            </button>
          );
        })}
      </div>

      <div
        id={`endpoint-panel-${viewing}`}
        role="tabpanel"
        aria-labelledby={`endpoint-tab-${viewing}`}
        className={`rounded-b-md rounded-tr-md border p-3 ${TONE[viewing].panel}`}
      >
        <p className="text-xs text-gray-500">{config.description}</p>

        <div className="mt-2">
          {viewing === inUse ? (
            <p className="text-xs font-medium text-gray-700">✓ AI requests use this endpoint</p>
          ) : (
            <button
              type="button"
              onClick={() => onUseEndpoint(viewing)}
              className={`rounded border bg-white px-2 py-1 text-xs font-medium ${TONE[viewing].button}`}
            >
              Use this endpoint for AI requests
            </button>
          )}
        </div>

        <div className="mt-3">
          <label htmlFor={keyInputId} className="block text-sm font-medium text-gray-700 mb-1">
            {config.label} API Key
          </label>
          <div className="flex gap-2">
            <input
              id={keyInputId}
              type="password"
              value={keys[viewing]}
              onChange={(e) => onKeyChange(viewing, e.target.value)}
              placeholder={`Enter ${config.shortLabel} API key`}
              className="block flex-1 rounded-md border border-gray-300 bg-white px-3 py-2 text-sm shadow-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
            />
            <button
              type="button"
              onClick={() => onTest(viewing)}
              disabled={status === "testing"}
              className="rounded-md border border-gray-300 bg-white px-3 py-2 text-xs font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50"
            >
              {status === "testing" ? "Testing…" : "Test"}
            </button>
          </div>
          {status === "ok" && <p className="mt-1 text-xs text-green-600">✓ Connected</p>}
          {status === "error" && error && <AppErrorBox error={error} className="mt-2" />}
        </div>

        <p className="mt-2 text-xs text-gray-500">
          Endpoint: <span className="font-mono text-gray-700">{config.baseUrl}</span>
        </p>

        {/* key={viewing}: per-endpoint UI state (Other… inputs, refresh errors) doesn't carry across tabs */}
        <ModelSettings
          key={viewing}
          ep={viewing}
          apiKey={keys[viewing]}
          overrides={modelDrafts[viewing]}
          onChange={(role, id) => onModelChange(viewing, role, id)}
        />
      </div>
      <p className="mt-1.5 text-xs text-gray-400">
        Keys are stored in this browser and sent only to their own endpoint's LiteLLM proxy.
      </p>
    </div>
  );
}
