import { useCallback, useEffect, useMemo, useState } from "react";
import { useMatch } from "react-router-dom";
import { useAiPanelContext } from "../../context/AiPanelContext";
import { useSessionContext } from "../../context/SessionContext";
import { useSidebarOpen } from "../../hooks/useSidebarOpen";
import { getScopeColors } from "../../utils/scopeColors";
import MagicWandIcon from "../icons/MagicWandIcon";
import ResizableRightPanel from "../ResizableRightPanel";
import AiPanelChat from "./AiPanelChat";
import AiPanelTabBar from "./AiPanelTabBar";
import ProposedChangesTab from "./ProposedChangesTab";
import ObservationsTab from "./ObservationsTab";
import DocumentPickerDialog from "./DocumentPickerDialog";
import StyleReplaceDialog from "./StyleReplaceDialog";
import ConversationDropdown from "../bulk-edit/ConversationDropdown";
import ChatHeaderMenu from "./ChatHeaderMenu";
import EndpointBadge from "../EndpointBadge";
import { GENERAL_CHAT_ENABLED, GENERAL_CHAT_SESSION_ID } from "../../ai/generalChat";

export default function AiPanel() {
  const {
    panelOpen,
    setPanelOpen,
    togglePanel,
    proposedChanges,
    toggleChange,
    acceptAll,
    rejectAll,
    applyChanges,
    detectedObservations,
    clearObservations,
    docManager,
    hasActiveSession,
    scope,
    activeConvKey,
    chatInstanceKey,
    onNewChat,
    onSelectConversation,
    onDeleteConversation,
    activeTab,
    setActiveTab,
    hasUnseenChanges,
    hasUnseenObservations,
  } = useAiPanelContext();

  const { session, schema } = useSessionContext();
  const generalChat = !hasActiveSession && GENERAL_CHAT_ENABLED;
  const [sidebarOpen] = useSidebarOpen();
  const scopeColors = useMemo(() => getScopeColors(scope.type), [scope.type]);

  // When clicking a field link in an observation, switch to the Proposed Changes tab
  const handleObservationFieldClick = useCallback((_fieldKey: string) => {
    setActiveTab("changes");
  }, [setActiveTab]);

  // The template editor has no document for the assistant to work on and
  // needs the width, so the panel starts as its strip there. Opening it on
  // the editor lasts until the user leaves; the saved preference is untouched.
  const onTemplateEditor = useMatch("/templates/edit/:id") !== null;
  const [openedOnEditor, setOpenedOnEditor] = useState(false);
  useEffect(() => {
    if (!onTemplateEditor) setOpenedOnEditor(false);
  }, [onTemplateEditor]);
  const open = panelOpen && (!onTemplateEditor || openedOnEditor);

  // Collapsed strip
  if (!open) {
    return (
      <>
      <StyleReplaceDialog />
      <button
        type="button"
        onClick={() => {
          if (onTemplateEditor) setOpenedOnEditor(true);
          setPanelOpen(true);
        }}
        className={`flex flex-col items-center border-l-2 bg-gray-50 w-10 shrink-0 cursor-pointer hover:bg-gray-100 transition-colors ${scopeColors.stripBorder}`}
        title="Open AI Assistant"
      >
        <div className="mt-3 p-1.5">
          <MagicWandIcon className={`w-4 h-4 ${scopeColors.accentText}`} />
        </div>
        <span className="mt-2 text-[10px] text-gray-500 [writing-mode:vertical-rl] rotate-180">
          AI Assistant
        </span>
      </button>
      </>
    );
  }

  return (
    <ResizableRightPanel storageKey="doc-builder:ai-panel-width" reservedLeft={sidebarOpen ? 320 : 80}>
      <div className="flex flex-col h-full bg-white print:hidden">
        {/* Header */}
        <div className="relative flex items-center px-3 py-3 border-b border-gray-200 bg-gray-50 shrink-0">
          {/* Left-aligned title */}
          <span className="text-xl font-semibold text-gray-700 inline-flex items-center gap-1"><MagicWandIcon className={`w-3.5 h-3.5 ${scopeColors.accentText}`} /> AI Assistant</span>
          {/* Centered badge */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="pointer-events-auto"><EndpointBadge /></div>
          </div>
          {/* Right-aligned controls */}
          <div className="ml-auto flex items-center gap-1">
            {/* Conversation switcher */}
            {(session || generalChat) && (
              <ConversationDropdown
                sessionId={session?.id ?? GENERAL_CHAT_SESSION_ID}
                activeConvKey={activeConvKey}
                refreshKey={chatInstanceKey}
                filterPrefix="__unified_chat:"
                onSelect={onSelectConversation}
                onNewDraft={onNewChat}
                onDelete={onDeleteConversation}
              />
            )}
            {/* Chat actions menu */}
            {session && (
              <ChatHeaderMenu
                sessionId={session.id}
                activeConvKey={activeConvKey}
                schemaTitle={schema?.title ?? "Unknown"}
              />
            )}
            {/* Collapse button */}
            <button
              type="button"
              onClick={togglePanel}
              className="text-gray-400 hover:text-gray-600 p-1 rounded hover:bg-gray-200 transition-colors"
              title="Collapse AI Assistant"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 20 20"
                fill="currentColor"
                className="w-3.5 h-3.5"
              >
                <path
                  fillRule="evenodd"
                  d="M8.22 5.22a.75.75 0 0 1 1.06 0l4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.75.75 0 0 1-1.06-1.06L11.94 10 8.22 6.28a.75.75 0 0 1 0-1.06Z"
                  clipRule="evenodd"
                />
              </svg>
            </button>
          </div>
        </div>

        {/* Content */}
        {generalChat ? (
          // No document open: the same chat, without the drafting tabs.
          <div className="flex flex-col flex-1 min-h-0">
            <AiPanelChat key={chatInstanceKey} />
          </div>
        ) : !hasActiveSession ? (
          <div className="flex-1 flex items-center justify-center p-6">
            <div className="text-center">
              <div className={`mb-3 flex justify-center ${scopeColors.accentText}`}><MagicWandIcon className="w-8 h-8" /></div>
              <p className="text-sm text-gray-500 font-medium">AI Assistant</p>
              <p className="text-xs text-gray-400 mt-1 max-w-[180px]">
                Start a document to use AI-assisted drafting
              </p>
            </div>
          </div>
        ) : (
          <>
            <AiPanelTabBar
              activeTab={activeTab}
              onTabChange={setActiveTab}
              changesCount={proposedChanges.length}
              hasUnseenChanges={hasUnseenChanges}
              observationsCount={detectedObservations.length}
              hasUnseenObservations={hasUnseenObservations}
            />

            {/* Tab content — all rendered, toggled via CSS hidden to preserve state */}
            <div className={`flex flex-col flex-1 min-h-0 ${activeTab !== "chat" ? "hidden" : ""}`}>
              <AiPanelChat key={chatInstanceKey} />
            </div>
            <div className={`flex flex-col flex-1 min-h-0 ${activeTab !== "changes" ? "hidden" : ""}`}>
              <ProposedChangesTab
                changes={proposedChanges}
                onToggleChange={toggleChange}
                onAcceptAll={acceptAll}
                onRejectAll={rejectAll}
                onApply={applyChanges}
                observations={detectedObservations}
                onConflictClick={() => setActiveTab("observations")}
              />
            </div>
            <div className={`flex flex-col flex-1 min-h-0 ${activeTab !== "observations" ? "hidden" : ""}`}>
              <ObservationsTab
                observations={detectedObservations}
                onClear={clearObservations}
                onFieldClick={handleObservationFieldClick}
              />
            </div>
          </>
        )}
      </div>

      {/* Document picker dialog */}
      {docManager.showDocPicker && <DocumentPickerDialog docManager={docManager} />}
      <StyleReplaceDialog />
    </ResizableRightPanel>
  );
}
