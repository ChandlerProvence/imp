import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import AskUserQuestionCard from "./AskUserQuestionCard";
import type { AskUserQuestion } from "../../ai/askUserTypes";

const toneQuestion: AskUserQuestion = {
  header: "Tone",
  question: "What tone should the background use?",
  fieldKey: null,
  multiSelect: false,
  options: [
    { label: "Formal", recommended: true, description: "Matches prior SOWs" },
    { label: "Plain-language" },
  ],
};

const scopeQuestion: AskUserQuestion = {
  header: "Scope",
  question: "Which sections apply?",
  fieldKey: null,
  multiSelect: true,
  options: [{ label: "A" }, { label: "B" }, { label: "C" }],
};

describe("AskUserQuestionCard", () => {
  it("renders the question text and options", () => {
    render(<AskUserQuestionCard questions={[toneQuestion]} onSubmit={vi.fn()} />);
    expect(screen.getByText("What tone should the background use?")).toBeInTheDocument();
    expect(screen.getByText("Formal")).toBeInTheDocument();
    expect(screen.getByText("Plain-language")).toBeInTheDocument();
    expect(screen.getByText("★ Recommended")).toBeInTheDocument();
    expect(screen.getByText("Matches prior SOWs")).toBeInTheDocument();
  });

  it("does not show header chips/tabs for a single question", () => {
    render(<AskUserQuestionCard questions={[toneQuestion]} onSubmit={vi.fn()} />);
    expect(screen.queryByText("✓")).not.toBeInTheDocument();
  });

  it("single-select: Submit is disabled until an option is chosen", () => {
    render(<AskUserQuestionCard questions={[toneQuestion]} onSubmit={vi.fn()} />);
    const submit = screen.getByText("Submit");
    expect(submit).toBeDisabled();
    fireEvent.click(screen.getByText("Formal"));
    expect(submit).not.toBeDisabled();
  });

  it("single-select: choosing a new option replaces the previous one", () => {
    const onSubmit = vi.fn();
    render(<AskUserQuestionCard questions={[toneQuestion]} onSubmit={onSubmit} />);
    fireEvent.click(screen.getByText("Formal"));
    fireEvent.click(screen.getByText("Plain-language"));
    fireEvent.click(screen.getByText("Submit"));
    expect(onSubmit).toHaveBeenCalledWith([
      expect.objectContaining({ header: "Tone", selected: ["Plain-language"] }),
    ]);
  });

  it("multi-select: shows a 'select all that apply' hint and toggles checkboxes", () => {
    const onSubmit = vi.fn();
    render(<AskUserQuestionCard questions={[scopeQuestion]} onSubmit={onSubmit} />);
    expect(screen.getByText("Select all that apply")).toBeInTheDocument();

    fireEvent.click(screen.getByText("A"));
    fireEvent.click(screen.getByText("C"));
    fireEvent.click(screen.getByText("Submit"));
    expect(onSubmit).toHaveBeenCalledWith([
      expect.objectContaining({ header: "Scope", selected: ["A", "C"] }),
    ]);
  });

  it("multi-select: clicking a checked option unchecks it", () => {
    const onSubmit = vi.fn();
    render(<AskUserQuestionCard questions={[scopeQuestion]} onSubmit={onSubmit} />);
    fireEvent.click(screen.getByText("A"));
    fireEvent.click(screen.getByText("B"));
    fireEvent.click(screen.getByText("A")); // uncheck A
    fireEvent.click(screen.getByText("Submit"));
    expect(onSubmit).toHaveBeenCalledWith([
      expect.objectContaining({ selected: ["B"] }),
    ]);
  });

  it("Other text combines with selected checkboxes in multi-select", () => {
    const onSubmit = vi.fn();
    render(<AskUserQuestionCard questions={[scopeQuestion]} onSubmit={onSubmit} />);
    fireEvent.click(screen.getByText("A"));
    fireEvent.change(screen.getByPlaceholderText("Type a free answer…"), {
      target: { value: "and D" },
    });
    fireEvent.click(screen.getByText("Submit"));
    expect(onSubmit).toHaveBeenCalledWith([
      expect.objectContaining({ selected: ["A"], otherText: "and D" }),
    ]);
  });

  it("Other text alone is enough to enable Submit", () => {
    render(<AskUserQuestionCard questions={[toneQuestion]} onSubmit={vi.fn()} />);
    const submit = screen.getByText("Submit");
    expect(submit).toBeDisabled();
    fireEvent.change(screen.getByPlaceholderText("Type a free answer…"), {
      target: { value: "Something else" },
    });
    expect(submit).not.toBeDisabled();
  });

  it("Skip marks the question skipped and clears any selection", () => {
    const onSubmit = vi.fn();
    render(<AskUserQuestionCard questions={[toneQuestion]} onSubmit={onSubmit} />);
    fireEvent.click(screen.getByText("Formal"));
    fireEvent.click(screen.getByText("Skip"));
    fireEvent.click(screen.getByText("Submit"));
    expect(onSubmit).toHaveBeenCalledWith([
      expect.objectContaining({ selected: [], skipped: true }),
    ]);
  });

  it("renders header chips as tabs for multiple questions and tracks answered state", () => {
    render(<AskUserQuestionCard questions={[toneQuestion, scopeQuestion]} onSubmit={vi.fn()} />);
    expect(screen.getByText("Tone")).toBeInTheDocument();
    expect(screen.getByText("Scope")).toBeInTheDocument();
    // First question's question text is visible; second question is not shown yet.
    expect(screen.getByText("What tone should the background use?")).toBeInTheDocument();
    expect(screen.queryByText("Which sections apply?")).not.toBeInTheDocument();
  });

  it("Next advances to the next question only once the current one is answered", () => {
    render(<AskUserQuestionCard questions={[toneQuestion, scopeQuestion]} onSubmit={vi.fn()} />);
    const next = screen.getByText("Next →");
    expect(next).toBeDisabled();
    fireEvent.click(screen.getByText("Formal"));
    expect(next).not.toBeDisabled();
    fireEvent.click(next);
    expect(screen.getByText("Which sections apply?")).toBeInTheDocument();
  });

  it("Submit stays disabled until every question is answered or skipped", () => {
    const onSubmit = vi.fn();
    render(<AskUserQuestionCard questions={[toneQuestion, scopeQuestion]} onSubmit={onSubmit} />);
    fireEvent.click(screen.getByText("Formal"));
    fireEvent.click(screen.getByText("Next →"));
    // Second question unanswered — Submit should be disabled on the last tab.
    const submit = screen.getByText("Submit");
    expect(submit).toBeDisabled();
    fireEvent.click(screen.getByText("Skip"));
    // Skipping the last question marks it answered but does not auto-submit.
    expect(onSubmit).not.toHaveBeenCalled();
    expect(submit).not.toBeDisabled();
    fireEvent.click(submit);
    expect(onSubmit).toHaveBeenCalledWith([
      expect.objectContaining({ header: "Tone", selected: ["Formal"] }),
      expect.objectContaining({ header: "Scope", selected: [], skipped: true }),
    ]);
  });

  it("clicking a tab chip jumps directly to that question", () => {
    render(<AskUserQuestionCard questions={[toneQuestion, scopeQuestion]} onSubmit={vi.fn()} />);
    fireEvent.click(screen.getByText("Scope"));
    expect(screen.getByText("Which sections apply?")).toBeInTheDocument();
  });
});
