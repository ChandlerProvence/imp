import { useMemo, type ReactNode } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import type { AiChatMessage } from "../../hooks/useAiChat";
import type { ResponseStep } from "../../ai/types";
import type { PendingQuestion, QuestionAnswer } from "../../ai/askUserTypes";
import { parseAnsweredAskUser } from "../../ai/askUserTypes";
import { stripProposedChanges } from "../../ai/parseProposedChanges";
import { LiveActivitySteps, StaticStepsBeforeMessage, StaticTotalAfterMessage } from "./ActivitySteps";
import AskUserQuestionCard from "./AskUserQuestionCard";

interface Props {
  messages: AiChatMessage[];
  streamingContent: string | null;
  isSearching: boolean;
  isThinking?: boolean;
  retrievalMeta: { chunkCount: number; docCount: number } | null;
  proposedChangesCount: number;
  onViewChanges: () => void;
  observationsCount: number;
  onViewObservations: () => void;
  userBubbleBg?: string;
  /** Steps completed so far in the current response (live display). */
  completedSteps: ResponseStep[];
  /** The kind of step currently in-flight (null if idle). */
  activeStepKind: ResponseStep["kind"] | null;
  /** A pending ask_user question awaiting the user's answer, if any. */
  pendingQuestion?: PendingQuestion | null;
  /** Called with the user's answers when they submit the pending question. */
  onAnswerQuestion?: (answers: QuestionAnswer[]) => void;
  /** Shown when the conversation is empty. Defaults to the drafting prompt. */
  emptyState?: ReactNode;
}

/** Compact read-only summary of an answered ask_user question, rendered under the assistant bubble. */
function AnsweredQuestionSummary({ answers }: { answers: QuestionAnswer[] }) {
  return (
    <div className="flex justify-start">
      <div className="max-w-[85%] rounded-md bg-amber-50 border border-amber-200 px-3 py-1.5 text-xs text-amber-800 space-y-0.5">
        {answers.map((a, i) => {
          if (a.skipped) {
            return <p key={i}>{a.header} → <span className="italic text-amber-600">skipped</span></p>;
          }
          const parts = [...a.selected];
          if (a.otherText) parts.push(`Other: "${a.otherText}"`);
          return <p key={i}>{a.header} → {parts.join(", ") || "(no answer)"}</p>;
        })}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Message bubble
// ---------------------------------------------------------------------------

function MessageBubble({
  message,
  streaming,
  userBubbleBg = "bg-blue-600",
}: {
  message: { role: "user" | "assistant"; content: string; displayLabel?: string };
  streaming?: boolean;
  userBubbleBg?: string;
}) {
  const displayContent = useMemo(() => {
    if (message.role === "user") return null;
    return stripProposedChanges(message.content);
  }, [message.role, message.content]);

  if (message.role === "user") {
    return (
      <div className="flex justify-end">
        <div className={`max-w-[85%] rounded-lg ${userBubbleBg} px-3 py-2 text-sm text-white whitespace-pre-wrap`}>
          {message.displayLabel ?? message.content}
        </div>
      </div>
    );
  }

  return (
    <div className="flex justify-start">
      <div className="max-w-[85%] rounded-lg bg-gray-100 px-3 py-2 text-sm text-gray-900">
        {displayContent && (
          <div className="prose prose-sm prose-gray max-w-none [&>*:first-child]:mt-0 [&>*:last-child]:mb-0">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>{displayContent}</ReactMarkdown>
          </div>
        )}
        {streaming && (
          <span className="inline-flex items-center gap-0.5 ml-1 h-4">
            <span className="w-1 h-full bg-blue-500 rounded-sm animate-streaming-bar origin-bottom [animation-delay:0ms]" />
            <span className="w-1 h-full bg-blue-500 rounded-sm animate-streaming-bar origin-bottom [animation-delay:200ms]" />
            <span className="w-1 h-full bg-blue-500 rounded-sm animate-streaming-bar origin-bottom [animation-delay:400ms]" />
          </span>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Main list
// ---------------------------------------------------------------------------

export default function UnifiedMessageList({
  messages,
  streamingContent,
  isSearching,
  isThinking,
  retrievalMeta,
  proposedChangesCount,
  onViewChanges,
  observationsCount,
  onViewObservations,
  userBubbleBg,
  completedSteps,
  activeStepKind,
  pendingQuestion,
  onAnswerQuestion,
  emptyState,
}: Props) {
  // Filter out tool messages and assistant messages that have nothing to show
  const visibleMessages = useMemo(
    () =>
      messages.filter((msg) => {
        if (msg.role === "tool") return false;
        // Hide empty assistant+toolCalls messages unless they carry timing steps
        if (msg.role === "assistant" && !msg.content && msg.toolCalls && !msg.timings?.steps.length) return false;
        return true;
      }),
    [messages],
  );

  return (
    <>
      {visibleMessages.length === 0 && !streamingContent && !isSearching && !activeStepKind && (
        <div className="flex items-center justify-center min-h-32 py-4">
          {emptyState ?? <p className="text-sm text-gray-400">Send a message to start drafting…</p>}
        </div>
      )}

      {visibleMessages.map((msg) => {
        const askUserCall = msg.toolCalls?.find((tc) => tc.function.name === "ask_user");
        const answeredQuestion = askUserCall
          ? messages.find((m) => m.role === "tool" && m.toolCallId === askUserCall.id)
          : undefined;
        const answers = answeredQuestion ? parseAnsweredAskUser(answeredQuestion.content) : null;

        return (
          <div key={msg.id}>
            {msg.role === "assistant" && msg.timings && msg.timings.steps.length > 0 && (
              <StaticStepsBeforeMessage timings={msg.timings} />
            )}
            {/* Only render the bubble if there's content to show */}
            {msg.content && (
              <MessageBubble
                message={{
                  role: msg.role as "user" | "assistant",
                  content: msg.content,
                  displayLabel: msg.displayLabel,
                }}
                userBubbleBg={userBubbleBg}
              />
            )}
            {answers && <AnsweredQuestionSummary answers={answers} />}
            {msg.role === "assistant" && msg.timings && (
              <StaticTotalAfterMessage timings={msg.timings} />
            )}
          </div>
        );
      })}

      {pendingQuestion && onAnswerQuestion && (
        <AskUserQuestionCard
          questions={pendingQuestion.questions}
          onSubmit={onAnswerQuestion}
        />
      )}

      {/* Live activity steps — shown during streaming */}
      <LiveActivitySteps completedSteps={completedSteps} activeStepKind={activeStepKind} />

      {streamingContent !== null && streamingContent.length === 0 && (
        <div className="flex justify-start">
          <div className="rounded-lg bg-gray-100 px-3 py-2 text-sm text-gray-500 flex items-center gap-2">
            <span className="flex items-end gap-1 h-4">
              <span className="w-1 h-full bg-blue-500 rounded-sm origin-bottom [animation:var(--animate-streaming-bar)] [animation-delay:0ms]" />
              <span className="w-1 h-full bg-blue-500 rounded-sm origin-bottom [animation:var(--animate-streaming-bar)] [animation-delay:200ms]" />
              <span className="w-1 h-full bg-blue-500 rounded-sm origin-bottom [animation:var(--animate-streaming-bar)] [animation-delay:400ms]" />
            </span>
            {isThinking ? "Reasoning deeply…" : "Thinking…"}
          </div>
        </div>
      )}

      {!isSearching && retrievalMeta && retrievalMeta.chunkCount > 0 && (
        <div className="flex justify-start">
          <p className="text-xs text-gray-400 italic px-3 py-1">
            Retrieved {retrievalMeta.chunkCount} passage{retrievalMeta.chunkCount !== 1 ? "s" : ""} from{" "}
            {retrievalMeta.docCount} doc{retrievalMeta.docCount !== 1 ? "s" : ""}
          </p>
        </div>
      )}

      {streamingContent !== null && streamingContent.length > 0 && (
        <MessageBubble
          message={{ role: "assistant", content: streamingContent }}
          streaming
        />
      )}

      {observationsCount > 0 && streamingContent === null && (
        <div className="flex justify-start">
          <button
            onClick={onViewObservations}
            className="text-sm text-amber-600 hover:text-amber-800 flex items-center gap-1 px-3 py-1.5 rounded-md hover:bg-amber-50 transition-colors"
          >
            ⚠ View {observationsCount} alert{observationsCount !== 1 ? "s" : ""} →
          </button>
        </div>
      )}

      {proposedChangesCount > 0 && streamingContent === null && (
        <div className="flex justify-start">
          <button
            onClick={onViewChanges}
            className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1 px-3 py-1.5 rounded-md hover:bg-blue-50 transition-colors"
          >
            View {proposedChangesCount} proposed change{proposedChangesCount !== 1 ? "s" : ""} →
          </button>
        </div>
      )}
    </>
  );
}
