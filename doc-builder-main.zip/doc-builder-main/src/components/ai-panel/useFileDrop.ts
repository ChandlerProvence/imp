import { useRef, useState, type DragEvent } from "react";

/**
 * Drag-and-drop state for a file drop zone. The enter/leave counter keeps the
 * highlight stable while the pointer moves over child elements.
 */
export function useFileDrop(onFiles: (files: File[]) => void) {
  const [dragOver, setDragOver] = useState(false);
  const counter = useRef(0);

  const dropHandlers = {
    onDragOver: (e: DragEvent) => e.preventDefault(),
    onDragEnter: (e: DragEvent) => {
      e.preventDefault();
      counter.current++;
      setDragOver(true);
    },
    onDragLeave: () => {
      counter.current--;
      if (counter.current <= 0) {
        counter.current = 0;
        setDragOver(false);
      }
    },
    onDrop: (e: DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      counter.current = 0;
      setDragOver(false);
      const dropped = Array.from(e.dataTransfer.files);
      if (dropped.length > 0) onFiles(dropped);
    },
  };

  return { dragOver, dropHandlers };
}

/** File types the upload pipeline accepts (for `<input type="file" accept>`). */
export const ACCEPTED_FILE_TYPES =
  ".pdf,.docx,.xlsx,.xls,.csv,.txt,.md,.json,.png,.jpg,.jpeg,.gif,.webp,.tiff";
