import { useEffect, useMemo, useRef, useState } from "react";
import type { UseDocumentManagerReturn } from "../../hooks/useDocumentManager";
import { useAskSage } from "../../context/AskSageContext";
import { isFeatureEnabled } from "../../ai/featureFlags";
import { useAiConfig } from "../../context/AiConfigContext";
import { OPEN_SETTINGS_EVENT } from "../EndpointBadge";
import CuiWarningDialog from "../CuiWarningDialog";
import SharePointSearch from "./SharePointSearch";
import AppErrorBox from "../AppErrorBox";
import DocumentRowStatus, { DocumentRowErrors, RoleBadge, isDocProcessing } from "./DocumentRowStatus";
import DocumentSlotsPanel from "./DocumentSlotsPanel";
import { ACCEPTED_FILE_TYPES, useFileDrop } from "./useFileDrop";

/** Number of non-generated docs shown in "Recent" mode. */
const RECENT_DOC_LIMIT = 20;

interface Props {
  docManager: UseDocumentManagerReturn;
}

export default function DocumentPickerDialog({ docManager }: Props) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { dragOver, dropHandlers } = useFileDrop((files) => docManager.addFiles(files));
  const { isConfigured: askSageConfigured } = useAskSage();
  // AskSage is disabled pending AskSage team approval; see the STATUS block in src/ai/asksage.ts.
  const askSageEnabled = isFeatureEnabled("askSage");
  const { activeEndpoint, endpointConfig, getApiKeyFor } = useAiConfig();
  const hasSlots = docManager.slotDefs.length > 0;

  // Search + Recent/All filter state
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<"recent" | "all">("recent");
  const searchInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    searchInputRef.current?.focus();
  }, []);

  const filteredDocs = useMemo(() => {
    const docs = docManager.availableDocs;
    const generated = docs.filter((d) => d.source === "generated");
    const nonGenerated = docs.filter((d) => d.source !== "generated");

    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      const matched = nonGenerated.filter((d) =>
        d.title.toLowerCase().includes(q),
      );
      return [...generated, ...matched];
    }

    const visible =
      viewMode === "recent"
        ? nonGenerated.slice(0, RECENT_DOC_LIMIT)
        : nonGenerated;

    return [...generated, ...visible];
  }, [docManager.availableDocs, searchQuery, viewMode]);

  const totalNonGeneratedCount = docManager.availableDocs.filter(
    (d) => d.source !== "generated",
  ).length;
  const isRecentTruncated =
    viewMode === "recent" &&
    !searchQuery.trim() &&
    totalNonGeneratedCount > RECENT_DOC_LIMIT;

  // Always shown in IL2 with no CUI key — no dismiss, since the gap it describes
  // (no AI CUI scan, no image text extraction) persists until a key is configured.
  const showCuiKeyBanner = activeEndpoint !== "cui" && !getApiKeyFor("cui");

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-30 bg-black/20"
        onClick={() => docManager.closePickerDiscard()}
      />

      {/* Dialog */}
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Add Documents"
        onKeyDown={(e) => {
          if (e.key === "Escape") docManager.closePickerDiscard();
        }}
        className="fixed inset-0 z-40 m-[2.5vh_2.5vw] flex flex-col rounded-lg border border-gray-200 bg-white shadow-xl p-5"
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-gray-900">Documents</h3>
          <button
            type="button"
            onClick={() => docManager.closePickerDiscard()}
            className="text-gray-400 hover:text-gray-600 text-lg"
          >
            ×
          </button>
        </div>

        {/* Active endpoint banner */}
        <div className={`mb-3 flex items-center gap-2 rounded-md px-3 py-2 text-xs font-medium ${
          activeEndpoint === "cui"
            ? "bg-amber-50 text-amber-800 border border-amber-200"
            : "bg-blue-50 text-blue-800 border border-blue-200"
        }`}>
          <span className={`inline-block w-2 h-2 rounded-full flex-shrink-0 ${
            activeEndpoint === "cui" ? "bg-amber-500" : "bg-blue-500"
          }`} />
          Uploading in <strong className="ml-0.5">{endpointConfig.shortLabel}</strong> mode
        </div>

        {/* Body — up to three columns: [slots] | other docs + upload | [sharepoint] */}
        <div className="flex-1 min-h-0 flex gap-4">
          {/* Left column: document slots from the schema's recommended uploads */}
          {hasSlots && (
            <div className="w-[30%] flex-shrink-0 flex flex-col min-h-0 border-r border-gray-200 pr-4">
              <DocumentSlotsPanel docManager={docManager} />
            </div>
          )}

          {/* Center column: other documents + upload zone */}
          <div className="flex-1 min-w-0 flex flex-col">
            {hasSlots && (
              <h4 className="text-xs font-semibold text-gray-700 uppercase tracking-wide mb-2">
                Documents
              </h4>
            )}
            {/* Search + Recent/All controls */}
            <div className="mb-3 flex items-center gap-2">
              <div className="relative flex-1">
                <input
                  ref={searchInputRef}
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search documents…"
                  className="w-full rounded-md border border-gray-300 px-3 py-1.5 pl-8 text-xs shadow-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                />
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 16 16"
                  fill="currentColor"
                  className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400 pointer-events-none"
                >
                  <path
                    fillRule="evenodd"
                    d="M9.965 11.026a5 5 0 1 1 1.06-1.06l2.755 2.754a.75.75 0 1 1-1.06 1.06l-2.755-2.754ZM10.5 7a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Z"
                    clipRule="evenodd"
                  />
                </svg>
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery("")}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    aria-label="Clear search"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" className="w-3.5 h-3.5">
                      <path d="M5.28 4.22a.75.75 0 0 0-1.06 1.06L6.94 8l-2.72 2.72a.75.75 0 1 0 1.06 1.06L8 9.06l2.72 2.72a.75.75 0 1 0 1.06-1.06L9.06 8l2.72-2.72a.75.75 0 0 0-1.06-1.06L8 6.94 5.28 4.22Z" />
                    </svg>
                  </button>
                )}
              </div>
              {!searchQuery.trim() && (
                <div className="flex rounded-md border border-gray-300 text-xs flex-shrink-0">
                  <button
                    type="button"
                    onClick={() => setViewMode("recent")}
                    className={`px-2.5 py-1.5 font-medium transition-colors ${
                      viewMode === "recent"
                        ? "bg-blue-600 text-white"
                        : "bg-white text-gray-600 hover:bg-gray-50"
                    } rounded-l-md`}
                  >
                    Recent
                  </button>
                  <button
                    type="button"
                    onClick={() => setViewMode("all")}
                    className={`px-2.5 py-1.5 font-medium transition-colors ${
                      viewMode === "all"
                        ? "bg-blue-600 text-white"
                        : "bg-white text-gray-600 hover:bg-gray-50"
                    } rounded-r-md`}
                  >
                    All ({totalNonGeneratedCount})
                  </button>
                </div>
              )}
            </div>

            {/* Unified document list */}
            {filteredDocs.length > 0 ? (
              <div className="flex-1 min-h-0 mb-4 flex flex-col">
                <div className="space-y-1 flex-1 overflow-y-scroll">
                  {filteredDocs.map((doc) => {
                    const isSelected = docManager.draftDocIds.has(doc.id);
                    const isProcessing = isDocProcessing(doc, docManager);
                    const slotId = docManager.draftSlotAssignments.get(doc.id);
                    const slotTitle = slotId && docManager.slotDefs.find((s) => s.id === slotId)?.title;
                    const roleLabel = doc.savedDoc?.slotRole;

                    return (
                      <div key={doc.id} className="rounded hover:bg-gray-50">
                        <label className="flex items-center gap-2 p-1.5 cursor-pointer group">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => docManager.toggleDraftDoc(doc.id)}
                            disabled={isProcessing}
                            className="h-3.5 w-3.5 rounded border-gray-300 text-blue-600"
                          />
                          {/* Origin badge */}
                          <span className="text-xs flex-shrink-0 w-4 text-center" title={doc.source === "generated" ? "Generated document output" : doc.source === "reference" ? "Bundled document" : "Attached file"}>
                            {doc.source === "generated" ? "📝" : doc.source === "reference" ? "📄" : "📎"}
                          </span>
                          {/* Title, with its current role, or the role it was last used as */}
                          <span className="flex-1 min-w-[6rem] flex items-center gap-1.5">
                            <span className="text-xs text-gray-800 truncate">{doc.title}</span>
                            {slotTitle ? (
                              <RoleBadge title={slotTitle} />
                            ) : (
                              roleLabel && <RoleBadge title={roleLabel.title} muted />
                            )}
                          </span>
                          <DocumentRowStatus doc={doc} docManager={docManager} isSelected={isSelected} />
                          {/* Assign to (or move between) slots */}
                          {hasSlots && (
                            <select
                              aria-label={`Use ${doc.title} as`}
                              value={slotId ?? ""}
                              disabled={isProcessing}
                              onClick={(e) => e.stopPropagation()}
                              onChange={(e) => {
                                if (e.target.value) docManager.assignDraftSlot(e.target.value, doc.id);
                              }}
                              className="w-20 flex-shrink-0 rounded border border-gray-200 bg-white px-1 py-0.5 text-[11px] text-gray-600"
                            >
                              {!slotId && <option value="">Use as…</option>}
                              {docManager.slotDefs.map((slot) => (
                                <option key={slot.id} value={slot.id}>
                                  {slot.title}
                                </option>
                              ))}
                            </select>
                          )}
                          {/* Delete button (only for user-uploaded docs) / spacer for reference docs */}
                          {doc.source === "upload" && doc.savedDoc ? (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                docManager.handleDeleteDocument(doc.savedDoc!.id);
                              }}
                              className="text-gray-300 hover:text-red-500"
                              title="Permanently delete"
                            >
                              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" className="w-3.5 h-3.5">
                                <path fillRule="evenodd" d="M5 3.25V4H2.75a.75.75 0 0 0 0 1.5h.3l.815 8.15A1.5 1.5 0 0 0 5.357 15h5.285a1.5 1.5 0 0 0 1.493-1.35l.815-8.15h.3a.75.75 0 0 0 0-1.5H11v-.75A2.25 2.25 0 0 0 8.75 1h-1.5A2.25 2.25 0 0 0 5 3.25Zm2.25-.75a.75.75 0 0 0-.75.75V4h3v-.75a.75.75 0 0 0-.75-.75h-1.5ZM6.05 6a.75.75 0 0 1 .787.713l.275 5.5a.75.75 0 0 1-1.498.075l-.275-5.5A.75.75 0 0 1 6.05 6Zm3.9 0a.75.75 0 0 1 .712.787l-.275 5.5a.75.75 0 0 1-1.498-.075l.275-5.5A.75.75 0 0 1 9.95 6Z" clipRule="evenodd" />
                              </svg>
                            </button>
                          ) : (
                            <span className="w-3.5" />
                          )}
                        </label>
                        <DocumentRowErrors doc={doc} docManager={docManager} />
                      </div>
                    );
                  })}
                </div>
                {isRecentTruncated && (
                  <button
                    type="button"
                    onClick={() => setViewMode("all")}
                    className="mt-1 text-xs text-blue-600 hover:text-blue-800 font-medium"
                  >
                    Show all {totalNonGeneratedCount} documents
                  </button>
                )}
              </div>
            ) : (
              <div className="flex-1 flex items-center justify-center text-xs text-gray-400 mb-4">
                {searchQuery.trim()
                  ? `No documents matching "${searchQuery.trim()}"`
                  : "No documents available"}
              </div>
            )}

            {/* Hidden CUI docs note */}
            {docManager.hiddenCuiDocCount > 0 && (
              <div className="mb-3 flex items-center gap-1.5 text-xs text-gray-400">
                <span>🔒</span>
                <span>
                  {docManager.hiddenCuiDocCount} document{docManager.hiddenCuiDocCount !== 1 ? "s" : ""} hidden — uploaded in CUI mode
                </span>
              </div>
            )}

            {/* CUI detection warning — no CUI API key */}
            {showCuiKeyBanner && (
              <div className="mb-3 flex items-start gap-2 rounded-md border-2 border-amber-400 bg-amber-50 px-3 py-2.5 text-xs text-amber-900 font-medium">
                <span className="mt-0.5 flex-shrink-0 text-base">⚠️</span>
                <span className="flex-1">
                  <strong>No CUI API key configured.</strong>{" "}
                  AI-based CUI scanning is running through the Proprietary (IL2) endpoint
                  instead of the secure CUI (IL5) endpoint. Images in documents with CUI
                  markings are quarantined until you confirm.{" "}
                  <button
                    type="button"
                    className="underline hover:text-amber-950 font-semibold"
                    onClick={() => {
                      docManager.closePickerDiscard();
                      window.dispatchEvent(new CustomEvent(OPEN_SETTINGS_EVENT));
                    }}
                  >
                    Configure CUI key in Settings →
                  </button>
                </span>
              </div>
            )}

            {/* Upload zone */}
            <div
              role="button"
              tabIndex={0}
              aria-label="Upload documents — drop files or click to browse"
              onClick={() => fileInputRef.current?.click()}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  fileInputRef.current?.click();
                }
              }}
              {...dropHandlers}
              className={`flex flex-col items-center gap-2 rounded-md border-2 border-dashed px-4 py-6 cursor-pointer transition-colors text-xs ${
                dragOver
                  ? "border-blue-400 bg-blue-50"
                  : "border-gray-300 hover:border-gray-400"
              }`}
            >
              <span className="text-gray-500">Drop or click to upload</span>
              <span className="text-gray-400">.pdf, .docx, .xlsx, .xls, .csv, .txt, .md, .json, images</span>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept={ACCEPTED_FILE_TYPES}
              multiple
              className="hidden"
              onChange={(e) => {
                const selected = Array.from(e.target.files ?? []);
                if (selected.length > 0) docManager.addFiles(selected);
                e.target.value = "";
              }}
            />

            {/* Upload status */}
            {docManager.files.length > 0 && (
              <div className="mt-3 space-y-1">
                {docManager.files.map((f, idx) => (
                  <div key={`parsing-${f.name}-${idx}`} className="flex items-center gap-2 text-xs bg-gray-50 rounded px-2 py-1.5">
                    <span className="flex-1 truncate text-gray-800">{f.name}</span>
                    {docManager.parsingFiles.has(f) && (
                      <span className="text-blue-500 flex items-center gap-1">
                        <span className="inline-block w-2.5 h-2.5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
                        Parsing…
                      </span>
                    )}
                    {docManager.fileErrors.has(f) && (
                      <AppErrorBox compact error={docManager.fileErrors.get(f)!} />
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Right column: SharePoint search. Always rendered so the layout keeps its shape; while the
              askSage flag is off it holds a "not available yet" placeholder instead of the AskSage controls. */}
          <div className={`${hasSlots ? "w-1/4" : "w-2/5"} flex-shrink-0 flex flex-col min-h-0 border-l border-gray-200 pl-4`}>
            <h4 className="text-xs font-semibold text-gray-700 mb-2 flex items-center gap-1.5">
              📁 SharePoint / OneDrive
            </h4>
            {!askSageEnabled ? (
              <div
                data-testid="sharepoint-placeholder"
                className="flex-1 flex flex-col items-center justify-center text-center px-4"
              >
                <div className="text-3xl mb-2 opacity-40">🔗</div>
                <p className="text-sm font-medium text-gray-500 mb-1">
                  Coming soon
                </p>
                <p className="text-xs text-gray-400">
                  Searching and attaching SharePoint / OneDrive files is not available yet.
                  Upload files with the drop zone instead.
                </p>
              </div>
            ) : askSageConfigured ? (
              <div className="flex-1 min-h-0 flex flex-col">
                <SharePointSearch
                  onAddFile={(file) => docManager.addFiles([file])}
                />
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-center px-4">
                <div className="text-3xl mb-2">🔗</div>
                <p className="text-sm font-medium text-gray-700 mb-1">
                  Search &amp; attach files from SharePoint
                </p>
                <p className="text-xs text-gray-500 mb-4">
                  Connect your AskSage account to search OneDrive and SharePoint directly from here.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    docManager.closePickerDiscard();
                    window.dispatchEvent(
                      new CustomEvent(OPEN_SETTINGS_EVENT, { detail: { section: "asksage" } }),
                    );
                  }}
                  className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 transition-colors"
                >
                  Connect AskSage
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Attach button — blocked while any draft doc is still parsing/scanning */}
        <button
          type="button"
          onClick={() => docManager.requestAttach()}
          disabled={docManager.attachBlocked}
          className={`mt-4 w-full rounded-md px-3 py-2 text-sm font-medium text-white ${
            docManager.attachBlocked
              ? "bg-blue-400 cursor-not-allowed"
              : "bg-blue-600 hover:bg-blue-700"
          }`}
        >
          {docManager.attachBlockedReason ?? "Attach"}
        </button>
      </div>

      {/* CUI detection warning dialog (shown when the user clicks Attach with flagged docs) */}
      <CuiWarningDialog
        open={docManager.showCuiWarning}
        flaggedDocs={docManager.flaggedDraftDocs}
        cuiKeyConfigured={!!getApiKeyFor("cui")}
        onCancel={docManager.cancelCuiWarning}
        onAffirmNotCui={docManager.affirmNotCuiAndAttach}
        onSwitchToCui={docManager.switchToCuiAndAttach}
        onOpenSettings={() => {
          docManager.closePickerDiscard();
          window.dispatchEvent(new CustomEvent(OPEN_SETTINGS_EVENT));
        }}
      />
    </>
  );
}
