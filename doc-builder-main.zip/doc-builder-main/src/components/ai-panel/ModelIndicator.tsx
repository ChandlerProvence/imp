import type { EffortTier } from "../../ai/effortTiers";
import { TIER_ICONS, TIER_LABELS, TIER_TOOLTIPS } from "../../ai/effortTiers";

const TIERS: EffortTier[] = ["low", "medium", "high"];

interface Props {
  value: EffortTier;
  onChange: (tier: EffortTier) => void;
  disabled?: boolean;
}

/**
 * Dropdown selector for AI effort tier.
 * Fast (standard, low) / Balanced (standard, medium) / Thorough (advanced, thinking).
 */
export function ModelIndicator({ value, onChange, disabled }: Props) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value as EffortTier)}
      disabled={disabled}
      title={TIER_TOOLTIPS[value]}
      aria-label="AI effort level"
      className={[
        "rounded-md border border-gray-500 bg-white px-2 py-1 text-xs text-gray-600",
        "focus:outline-none focus:ring-1 focus:ring-blue-400 focus:border-blue-400",
        "transition-colors shrink min-w-0 max-w-[110px] truncate",
        disabled ? "cursor-not-allowed opacity-50" : "cursor-pointer hover:border-gray-600",
      ].join(" ")}
    >
      {TIERS.map((tier) => (
        <option key={tier} value={tier} title={TIER_TOOLTIPS[tier]}>
          {TIER_ICONS[tier]} {TIER_LABELS[tier]}
        </option>
      ))}
    </select>
  );
}
