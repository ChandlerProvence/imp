import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, fireEvent, within } from "@testing-library/react";
import DocumentPickerDialog from "./DocumentPickerDialog";
import type { UseDocumentManagerReturn } from "../../hooks/useDocumentManager";
import { setFeatureFlags } from "../../ai/featureFlags";

vi.mock("../../context/AskSageContext", () => ({
  useAskSage: () => ({ isConfigured: false }),
}));

vi.mock("../../context/AiConfigContext", () => ({
  useAiConfig: () => ({
    activeEndpoint: "non-cui",
    endpointConfig: { shortLabel: "Proprietary" },
    getApiKeyFor: (ep: string) => (ep === "cui" ? null : "non-cui-key"),
  }),
}));

function makeDocManager(overrides: Partial<UseDocumentManagerReturn> = {}): UseDocumentManagerReturn {
  return {
    files: [],
    setFiles: vi.fn(),
    parsingFiles: new Set(),
    fileErrors: new Map(),
    availableDocs: [],
    selectedDocIds: new Set(),
    draftDocIds: new Set(),
    toggleDraftDoc: vi.fn(),
    slotDefs: [],
    draftSlotAssignments: new Map(),
    slotAssignments: new Map(),
    assignDraftSlot: vi.fn(),
    unassignDraftSlot: vi.fn(),
    addFiles: vi.fn(),
    scanningDocIds: new Set(),
    docStatuses: new Map(),
    embeddingProgress: new Map(),
    embeddingErrors: new Map(),
    attachmentErrors: new Map(),
    showDocPicker: true,
    setShowDocPicker: vi.fn(),
    attachBlocked: false,
    attachBlockedReason: null,
    requestAttach: vi.fn(),
    closePickerDiscard: vi.fn(),
    setupDocuments: [],
    documentCount: 0,
    isParsing: false,
    handleToggleDoc: vi.fn(),
    handleRemoveDocument: vi.fn(),
    handleDeleteDocument: vi.fn(),
    handleSearchReferences: vi.fn(),
    buildReferenceDocTexts: vi.fn(() => []),
    buildCombinedDocumentText: vi.fn(() => undefined),
    buildSourceDocumentRoles: vi.fn(() => []),
    styleReferenceDocs: [],
    styleReferencesWithheld: 0,
    resetSelections: vi.fn(),
    docsReady: true,
    docsProcessingStatus: null,
    indexGeneratedDocument: vi.fn(),
    removeGeneratedDocumentIndex: vi.fn(),
    setGeneratedDocument: vi.fn(),
    removeGeneratedDocument: vi.fn(),
    generatedDocIds: [],
    hiddenCuiDocCount: 0,
    showCuiWarning: false,
    flaggedDraftDocs: [],
    cancelCuiWarning: vi.fn(),
    affirmNotCuiAndAttach: vi.fn(),
    switchToCuiAndAttach: vi.fn(),
    ...overrides,
  };
}

describe("DocumentPickerDialog", () => {
  it("Attach button is enabled and shows 'Attach' when nothing is blocking", () => {
    const docManager = makeDocManager();
    render(<DocumentPickerDialog docManager={docManager} />);
    const button = screen.getByText("Attach");
    expect(button).not.toBeDisabled();
  });

  it("Attach button is disabled and shows the block reason while scanning", () => {
    const docManager = makeDocManager({
      attachBlocked: true,
      attachBlockedReason: "Scanning 2 documents for CUI…",
    });
    render(<DocumentPickerDialog docManager={docManager} />);
    const button = screen.getByText("Scanning 2 documents for CUI…");
    expect(button).toBeDisabled();
  });

  it("shows a prominent no-CUI-key banner mentioning IL2 fallback and quarantine", () => {
    const docManager = makeDocManager();
    render(<DocumentPickerDialog docManager={docManager} />);
    const banner = screen.getByText(/No CUI API key configured/);
    expect(banner).toBeInTheDocument();
    expect(banner.closest("div")!.textContent).toMatch(/Proprietary \(IL2\) endpoint/);
    expect(banner.closest("div")!.textContent).toMatch(/quarantined/i);
    expect(screen.queryByTitle("Dismiss")).not.toBeInTheDocument();
  });

  it("X button calls closePickerDiscard", () => {
    const docManager = makeDocManager();
    render(<DocumentPickerDialog docManager={docManager} />);
    fireEvent.click(screen.getByText("×"));
    expect(docManager.closePickerDiscard).toHaveBeenCalledOnce();
  });

  it("Escape calls closePickerDiscard", () => {
    const docManager = makeDocManager();
    render(<DocumentPickerDialog docManager={docManager} />);
    fireEvent.keyDown(screen.getByRole("dialog"), { key: "Escape" });
    expect(docManager.closePickerDiscard).toHaveBeenCalledOnce();
  });

  it("clicking Attach calls requestAttach", () => {
    const docManager = makeDocManager();
    render(<DocumentPickerDialog docManager={docManager} />);
    fireEvent.click(screen.getByText("Attach"));
    expect(docManager.requestAttach).toHaveBeenCalledOnce();
  });

  it("renders a search input", () => {
    const docManager = makeDocManager();
    render(<DocumentPickerDialog docManager={docManager} />);
    expect(screen.getByPlaceholderText("Search documents…")).toBeInTheDocument();
  });

  it("filters documents by title as the user types", () => {
    const docManager = makeDocManager({
      availableDocs: [
        { id: "1", title: "Contract Draft.docx", source: "upload" },
        { id: "2", title: "Budget Report.xlsx", source: "upload" },
        { id: "3", title: "Contract Final.docx", source: "upload" },
      ] as any,
    });
    render(<DocumentPickerDialog docManager={docManager} />);
    fireEvent.change(screen.getByPlaceholderText("Search documents…"), {
      target: { value: "contract" },
    });
    expect(screen.getByText("Contract Draft.docx")).toBeInTheDocument();
    expect(screen.getByText("Contract Final.docx")).toBeInTheDocument();
    expect(screen.queryByText("Budget Report.xlsx")).not.toBeInTheDocument();
  });

  it("shows only the first 20 non-generated docs in Recent mode", () => {
    const docs = Array.from({ length: 25 }, (_, i) => ({
      id: `doc-${i}`,
      title: `Document ${i}.docx`,
      source: "upload" as const,
    }));
    const docManager = makeDocManager({ availableDocs: docs as any });
    render(<DocumentPickerDialog docManager={docManager} />);
    expect(screen.getByText("Document 0.docx")).toBeInTheDocument();
    expect(screen.getByText("Document 19.docx")).toBeInTheDocument();
    expect(screen.queryByText("Document 20.docx")).not.toBeInTheDocument();
    expect(screen.getByText(/Show all 25 documents/)).toBeInTheDocument();
  });

  it("shows all documents when All toggle is clicked", () => {
    const docs = Array.from({ length: 25 }, (_, i) => ({
      id: `doc-${i}`,
      title: `Document ${i}.docx`,
      source: "upload" as const,
    }));
    const docManager = makeDocManager({ availableDocs: docs as any });
    render(<DocumentPickerDialog docManager={docManager} />);
    fireEvent.click(screen.getByText(/^All/));
    expect(screen.getByText("Document 24.docx")).toBeInTheDocument();
  });

  it("always shows generated docs even in Recent mode", () => {
    const docs = [
      { id: "gen-1", title: "Generated: Output.docx", source: "generated" as const },
      ...Array.from({ length: 25 }, (_, i) => ({
        id: `doc-${i}`,
        title: `Upload ${i}.docx`,
        source: "upload" as const,
      })),
    ];
    const docManager = makeDocManager({ availableDocs: docs as any });
    render(<DocumentPickerDialog docManager={docManager} />);
    expect(screen.getByText("Generated: Output.docx")).toBeInTheDocument();
    expect(screen.queryByText("Upload 20.docx")).not.toBeInTheDocument();
  });

  it("searches all documents regardless of Recent mode", () => {
    const docs = Array.from({ length: 25 }, (_, i) => ({
      id: `doc-${i}`,
      title: i === 24 ? "Special Needle.docx" : `Document ${i}.docx`,
      source: "upload" as const,
    }));
    const docManager = makeDocManager({ availableDocs: docs as any });
    render(<DocumentPickerDialog docManager={docManager} />);
    // Doc 24 is beyond the Recent limit of 20
    expect(screen.queryByText("Special Needle.docx")).not.toBeInTheDocument();
    // But search finds it
    fireEvent.change(screen.getByPlaceholderText("Search documents…"), {
      target: { value: "needle" },
    });
    expect(screen.getByText("Special Needle.docx")).toBeInTheDocument();
  });

  it("shows empty state message when search has no matches", () => {
    const docManager = makeDocManager({
      availableDocs: [
        { id: "1", title: "Contract.docx", source: "upload" },
      ] as any,
    });
    render(<DocumentPickerDialog docManager={docManager} />);
    fireEvent.change(screen.getByPlaceholderText("Search documents…"), {
      target: { value: "zzzznotfound" },
    });
    expect(screen.getByText(/No documents matching/)).toBeInTheDocument();
  });

  it("shows a warning icon (not a quarantine pill) for a flagged doc with quarantined images", () => {
    const docManager = makeDocManager({
      availableDocs: [
        {
          id: "q1",
          title: "classified.docx",
          source: "upload",
          savedDoc: {
            id: "q1",
            fileName: "classified.docx",
            mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            fileSize: 5000,
            textContent: "text",
            charCount: 4,
            category: "fms",
            cuiStatus: "flagged",
            quarantinedImages: [
              { placeholder: "[Image quarantined — pending CUI confirmation (IMAGE_0)]", dataUrl: "data:image/png;base64,abc" },
            ],
            createdAt: new Date().toISOString(),
            lastUsedAt: new Date().toISOString(),
          } as any,
        },
      ],
      draftDocIds: new Set(["q1"]),
    });
    render(<DocumentPickerDialog docManager={docManager} />);
    expect(screen.getByLabelText("Potential CUI content detected")).toBeInTheDocument();
    expect(screen.queryByText("Images quarantined")).not.toBeInTheDocument();
    expect(screen.queryByText("Potential CUI Content Detected")).not.toBeInTheDocument();
  });

  it("CUI warning tooltip describes regex detection", () => {
    const docManager = makeDocManager({
      availableDocs: [
        savedItem("r1", "banner.docx", {
          cuiStatus: "flagged",
          cuiDetection: { isCui: true, confidence: "high", reason: "x", method: "regex", markers: ["CUI banner"] },
        }),
      ],
    });
    render(<DocumentPickerDialog docManager={docManager} />);
    const title = screen.getByLabelText("Potential CUI content detected").getAttribute("title");
    expect(title).toMatch(/standard CUI marking\(s\)/);
    expect(title).toContain("CUI banner");
  });

  it("CUI warning tooltip describes AI detection", () => {
    const docManager = makeDocManager({
      availableDocs: [
        savedItem("a1", "notes.docx", {
          cuiStatus: "flagged",
          cuiDetection: { isCui: true, confidence: "medium", reason: "Mentions export-controlled data", method: "ai", markers: [] },
        }),
      ],
    });
    render(<DocumentPickerDialog docManager={docManager} />);
    const title = screen.getByLabelText("Potential CUI content detected").getAttribute("title");
    expect(title).toContain("AI scan");
    expect(title).toContain("medium confidence");
    expect(title).toContain("Mentions export-controlled data");
  });

  it("shows only the CUI pill (no Proprietary endpoint badge) for a CUI-status doc uploaded in Proprietary", () => {
    const docManager = makeDocManager({
      availableDocs: [
        savedItem("c1", "marked.docx", { cuiStatus: "cui", uploadEndpoint: "non-cui" }),
        savedItem("p1", "plain.docx", { cuiStatus: "clean", uploadEndpoint: "non-cui" }),
      ],
    });
    render(<DocumentPickerDialog docManager={docManager} />);
    const cuiRow = screen.getByText("marked.docx").closest("label")!;
    expect(within(cuiRow).getByText("CUI")).toBeInTheDocument();
    expect(within(cuiRow).queryByTitle(/^Uploaded via/)).not.toBeInTheDocument();
    expect(screen.getAllByTitle(/^Uploaded via/)).toHaveLength(1);
  });
});

// ---------------------------------------------------------------------------
// Document slots (issue 92)
// ---------------------------------------------------------------------------

const SLOTS = [
  { id: "pws", title: "PWS (Performance Work Statement)", description: "Scope of work.", priority: "recommended" as const },
  { id: "pr", title: "PR (Purchase Request)", priority: "recommended" as const },
  { id: "prior-mods", title: "Prior Modifications", priority: "optional" as const, multiple: true },
];

function savedItem(id: string, title: string, extra: Record<string, unknown> = {}) {
  return {
    id,
    title,
    source: "upload" as const,
    savedDoc: {
      id,
      fileName: title,
      mimeType: "application/pdf",
      fileSize: 100,
      textContent: "text",
      charCount: 4,
      category: "fms",
      cuiStatus: "clean",
      createdAt: new Date().toISOString(),
      lastUsedAt: new Date().toISOString(),
      ...extra,
    } as any,
  };
}

describe("DocumentPickerDialog — slots", () => {
  it("renders no slot column when the schema has no recommended uploads", () => {
    render(<DocumentPickerDialog docManager={makeDocManager()} />);
    expect(screen.queryByLabelText("Document slots")).not.toBeInTheDocument();
    expect(screen.queryByText("Other documents")).not.toBeInTheDocument();
  });

  it("groups slots into Recommended and Optional", () => {
    render(<DocumentPickerDialog docManager={makeDocManager({ slotDefs: SLOTS })} />);
    const recommended = screen.getByRole("region", { name: "Recommended documents" });
    const optional = screen.getByRole("region", { name: "Optional documents" });
    expect(within(recommended).getByText("PWS (Performance Work Statement)")).toBeInTheDocument();
    expect(within(recommended).getByText("PR (Purchase Request)")).toBeInTheDocument();
    expect(within(optional).getByText("Prior Modifications")).toBeInTheDocument();
    expect(screen.queryByText(/required/i)).not.toBeInTheDocument();
  });

  it("ticks off a slot and keeps the slotted doc checked in the documents list", () => {
    const docManager = makeDocManager({
      slotDefs: SLOTS,
      availableDocs: [savedItem("d1", "pws_final.pdf"), savedItem("d2", "notes.docx")],
      draftDocIds: new Set(["d1"]),
      draftSlotAssignments: new Map([["d1", "pws"]]),
      docStatuses: new Map([["d1", "ready"]]),
    });
    render(<DocumentPickerDialog docManager={docManager} />);
    const pwsCard = screen.getByTestId("slot-pws");
    expect(within(pwsCard).getByText("pws_final.pdf")).toBeInTheDocument();
    expect(within(pwsCard).getByLabelText("Provided")).toBeInTheDocument();
    // Filled slots drop their description
    expect(within(pwsCard).queryByText("Scope of work.")).not.toBeInTheDocument();
    // Both docs stay in the center list; the slotted one shows its role
    const select = screen.getByLabelText("Use pws_final.pdf as") as HTMLSelectElement;
    expect(select.value).toBe("pws");
    expect(within(select).queryByText("Use as…")).not.toBeInTheDocument();
    expect(screen.getByTitle("PWS (Performance Work Statement)")).toHaveTextContent("PWS");
    expect((screen.getByLabelText("Use notes.docx as") as HTMLSelectElement).value).toBe("");
  });

  it("an empty slot shows its description on one line, expandable on click", () => {
    render(<DocumentPickerDialog docManager={makeDocManager({ slotDefs: SLOTS })} />);
    const desc = within(screen.getByTestId("slot-pws")).getByRole("button", { name: "Scope of work." });
    const text = within(desc).getByText("Scope of work.");
    expect(desc).toHaveAttribute("aria-expanded", "false");
    expect(text).toHaveClass("truncate");
    fireEvent.click(desc);
    expect(desc).toHaveAttribute("aria-expanded", "true");
    expect(text).not.toHaveClass("truncate");
  });

  it("✕ on a filled slot calls unassignDraftSlot", () => {
    const docManager = makeDocManager({
      slotDefs: SLOTS,
      availableDocs: [savedItem("d1", "pws_final.pdf")],
      draftDocIds: new Set(["d1"]),
      draftSlotAssignments: new Map([["d1", "pws"]]),
    });
    render(<DocumentPickerDialog docManager={docManager} />);
    fireEvent.click(screen.getByLabelText("Remove pws_final.pdf from PWS (Performance Work Statement)"));
    expect(docManager.unassignDraftSlot).toHaveBeenCalledWith("d1");
  });

  it("'Use as' on a documents row calls assignDraftSlot", () => {
    const docManager = makeDocManager({ slotDefs: SLOTS, availableDocs: [savedItem("d2", "notes.docx")] });
    render(<DocumentPickerDialog docManager={docManager} />);
    fireEvent.change(screen.getByLabelText("Use notes.docx as"), { target: { value: "pr" } });
    expect(docManager.assignDraftSlot).toHaveBeenCalledWith("pr", "d2");
  });

  it("shows the previous role label on an unslotted row", () => {
    const docManager = makeDocManager({
      slotDefs: SLOTS,
      availableDocs: [savedItem("d2", "x123.pdf", { slotRole: { slotId: "pws", title: "PWS (Performance Work Statement)" } })],
    });
    render(<DocumentPickerDialog docManager={docManager} />);
    expect(screen.getByTitle("Previously used as: PWS (Performance Work Statement)")).toHaveTextContent("PWS");
  });

  it("dropping a file on a slot calls addFiles with the slot id", () => {
    const docManager = makeDocManager({ slotDefs: SLOTS });
    render(<DocumentPickerDialog docManager={docManager} />);
    const file = new File(["x"], "pws.pdf", { type: "application/pdf" });
    fireEvent.drop(screen.getByTestId("slot-pws"), { dataTransfer: { files: [file] } });
    expect(docManager.addFiles).toHaveBeenCalledWith([file], "pws");
  });

  it("dropping a file on the main upload zone calls addFiles without a slot", () => {
    const docManager = makeDocManager({ slotDefs: SLOTS });
    render(<DocumentPickerDialog docManager={docManager} />);
    const file = new File(["x"], "notes.pdf", { type: "application/pdf" });
    fireEvent.drop(screen.getByLabelText(/Upload documents/), { dataTransfer: { files: [file] } });
    expect(docManager.addFiles).toHaveBeenCalledWith([file]);
  });

  it("a filled slot row shows the CUI warning icon via the shared status component", () => {
    const docManager = makeDocManager({
      slotDefs: SLOTS,
      availableDocs: [
        savedItem("q1", "pws.docx", {
          cuiStatus: "flagged",
          quarantinedImages: [{ placeholder: "[Image quarantined]", dataUrl: "data:," }],
        }),
      ],
      draftDocIds: new Set(["q1"]),
      draftSlotAssignments: new Map([["q1", "pws"]]),
    });
    render(<DocumentPickerDialog docManager={docManager} />);
    const slot = within(screen.getByTestId("slot-pws"));
    expect(slot.getByLabelText("Potential CUI content detected")).toBeInTheDocument();
    expect(slot.queryByText("Images quarantined")).not.toBeInTheDocument();
  });

  it("files still parsing show once, in the main upload list", () => {
    const file = new File(["x"], "parsing-pws.pdf");
    const docManager = makeDocManager({ slotDefs: SLOTS, files: [file], parsingFiles: new Set([file]) });
    render(<DocumentPickerDialog docManager={docManager} />);
    expect(screen.getAllByText("parsing-pws.pdf")).toHaveLength(1);
    expect(within(screen.getByTestId("slot-pws")).queryByText("parsing-pws.pdf")).not.toBeInTheDocument();
  });

  it("search covers every document, slotted or not", () => {
    const docManager = makeDocManager({
      slotDefs: SLOTS,
      availableDocs: [savedItem("d1", "pws_final.pdf"), savedItem("d2", "pws_draft.pdf"), savedItem("d3", "notes.pdf")],
      draftDocIds: new Set(["d1"]),
      draftSlotAssignments: new Map([["d1", "pws"]]),
    });
    render(<DocumentPickerDialog docManager={docManager} />);
    expect(screen.getByText("All (3)")).toBeInTheDocument();
    fireEvent.change(screen.getByPlaceholderText("Search documents…"), { target: { value: "pws" } });
    expect(screen.getByLabelText("Use pws_draft.pdf as")).toBeInTheDocument();
    expect(screen.getByLabelText("Use pws_final.pdf as")).toBeInTheDocument();
    expect(screen.queryByLabelText("Use notes.pdf as")).not.toBeInTheDocument();
  });
});

describe("DocumentPickerDialog — AskSage gate", () => {
  beforeEach(() => localStorage.clear());

  it("keeps the SharePoint column as a placeholder while the askSage flag is off (the default)", () => {
    render(<DocumentPickerDialog docManager={makeDocManager()} />);
    expect(screen.getByRole("heading", { name: /SharePoint \/ OneDrive/ })).toBeInTheDocument();
    expect(screen.getByTestId("sharepoint-placeholder")).toHaveTextContent(/not available yet/);
    expect(screen.queryByRole("button", { name: "Connect AskSage" })).not.toBeInTheDocument();
    expect(screen.queryByText(/AskSage/)).not.toBeInTheDocument();
  });

  it("shows the setup prompt instead of the placeholder when the flag is on", () => {
    setFeatureFlags({ askSage: true });
    render(<DocumentPickerDialog docManager={makeDocManager()} />);
    expect(screen.getByText(/SharePoint \/ OneDrive/)).toBeInTheDocument();
    expect(screen.queryByTestId("sharepoint-placeholder")).not.toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Connect AskSage" })).toBeInTheDocument();
  });
});
