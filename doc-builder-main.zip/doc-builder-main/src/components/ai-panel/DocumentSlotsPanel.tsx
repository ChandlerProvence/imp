import { useState } from "react";
import type { UnifiedDocItem, UseDocumentManagerReturn } from "../../hooks/useDocumentManager";
import type { RecommendedUpload } from "../../schemas/types";
import DocumentRowStatus, { DocumentRowErrors, isDocProcessing } from "./DocumentRowStatus";
import { useFileDrop } from "./useFileDrop";

interface Props {
  docManager: UseDocumentManagerReturn;
}

/**
 * Left column of the document picker: a checklist of the schema's
 * `recommended_uploads` roles, grouped Recommended then Optional. Documents are
 * attached in the center list; an item ticks off once a document is assigned to
 * it ("Use as…" there, or by dropping a file on the item).
 */
export default function DocumentSlotsPanel({ docManager }: Props) {
  const recommended = docManager.slotDefs.filter((s) => s.priority !== "optional");
  const optional = docManager.slotDefs.filter((s) => s.priority === "optional");

  return (
    <div className="flex-1 min-h-0 overflow-y-scroll pr-1 space-y-4" aria-label="Document slots">
      {recommended.length > 0 && (
        <SlotGroup label="Recommended" slots={recommended} docManager={docManager} />
      )}
      {optional.length > 0 && <SlotGroup label="Optional" slots={optional} docManager={docManager} />}
    </div>
  );
}

function SlotGroup({
  label,
  slots,
  docManager,
}: {
  label: string;
  slots: RecommendedUpload[];
  docManager: UseDocumentManagerReturn;
}) {
  return (
    <section aria-label={`${label} documents`}>
      <h4 className="text-xs font-semibold text-gray-700 uppercase tracking-wide mb-2">{label}</h4>
      <div className="space-y-1.5">
        {slots.map((slot) => (
          <SlotCard key={slot.id} slot={slot} docManager={docManager} />
        ))}
      </div>
    </section>
  );
}

function SlotCard({ slot, docManager }: { slot: RecommendedUpload; docManager: UseDocumentManagerReturn }) {
  const { dragOver, dropHandlers } = useFileDrop((files) => docManager.addFiles(files, slot.id));
  const [expanded, setExpanded] = useState(false);

  const filled: UnifiedDocItem[] = [];
  for (const [docId, slotId] of docManager.draftSlotAssignments) {
    if (slotId !== slot.id) continue;
    filled.push(
      docManager.availableDocs.find((d) => d.id === docId) ?? { id: docId, title: docId, source: "upload" },
    );
  }
  const isFilled = filled.length > 0;

  return (
    <div
      data-testid={`slot-${slot.id}`}
      {...dropHandlers}
      title={`Drop a file here to use it as ${slot.title}`}
      className={`rounded-md border p-1.5 transition-colors ${
        dragOver ? "border-blue-400 bg-blue-50" : isFilled ? "border-green-200 bg-green-50/40" : "border-gray-200"
      }`}
    >
      <div className="flex items-start gap-2">
        <span
          className={`mt-0.5 flex-shrink-0 w-3.5 h-3.5 rounded-full border text-[9px] leading-[12px] text-center ${
            isFilled ? "bg-green-500 border-green-500 text-white" : "border-gray-300"
          }`}
          aria-label={isFilled ? "Provided" : "Not provided"}
        >
          {isFilled ? "✓" : ""}
        </span>
        <div className="flex-1 min-w-0">
          <div className="text-xs font-medium text-gray-800">{slot.title}</div>
          {/* Once filled, the description has done its job */}
          {!isFilled && slot.description && (
            <button
              type="button"
              onClick={() => setExpanded((v) => !v)}
              aria-expanded={expanded}
              className="flex w-full items-start gap-1 text-left text-[11px] text-gray-500 hover:text-gray-700 mt-0.5 leading-tight"
            >
              <span aria-hidden className={`flex-shrink-0 text-[9px] transition-transform ${expanded ? "rotate-90" : ""}`}>
                ▸
              </span>
              <span className={`min-w-0 ${expanded ? "" : "truncate"}`}>{slot.description}</span>
            </button>
          )}
        </div>
      </div>

      {filled.length > 0 && (
        <div className="mt-1 space-y-0.5">
          {filled.map((doc) => (
            <div key={doc.id}>
              <div className="flex items-center gap-2 pl-5 pr-1 py-0.5">
                <span className="flex-1 text-xs text-gray-700 truncate" title={doc.title}>
                  {doc.title}
                </span>
                <DocumentRowStatus doc={doc} docManager={docManager} isSelected />
                <button
                  type="button"
                  onClick={() => docManager.unassignDraftSlot(doc.id)}
                  disabled={isDocProcessing(doc, docManager)}
                  className="text-gray-400 hover:text-gray-700 disabled:opacity-40 text-xs px-1"
                  aria-label={`Remove ${doc.title} from ${slot.title}`}
                  title="Remove from this slot"
                >
                  ✕
                </button>
              </div>
              <DocumentRowErrors doc={doc} docManager={docManager} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
