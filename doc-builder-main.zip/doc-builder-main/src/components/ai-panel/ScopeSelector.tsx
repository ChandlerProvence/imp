import { useMemo } from "react";
import { useLocation } from "react-router-dom";
import type { DocumentSchema } from "../../schemas/types";
import { sectionIdFromPath, type AiScope } from "../../ai/unifiedPrompt";
import { getScopeColors } from "../../utils/scopeColors";

interface Props {
  schema: DocumentSchema | null;
  scope: AiScope;
  onScopeChange: (scope: AiScope) => void;
}

export default function ScopeSelector({ schema, scope, onScopeChange }: Props) {
  const location = useLocation();

  // Current section from the URL (null on prep pages and outside the interview)
  const currentSection = useMemo(() => {
    const id = sectionIdFromPath(location.pathname, schema);
    return id ? schema!.sections.find((s) => s.id === id) ?? null : null;
  }, [location.pathname, schema]);

  // Encode scope to a string value for the <select>
  const currentValue = useMemo(() => {
    switch (scope.type) {
      case "document":
        return "document";
      case "section":
        return `section:${scope.sectionId}`;
      case "field":
        return `field:${scope.fieldKey}`;
    }
  }, [scope]);

  const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value;
    if (val === "document") {
      onScopeChange({ type: "document" });
    } else if (val.startsWith("section:")) {
      onScopeChange({ type: "section", sectionId: val.slice(8) });
    } else if (val.startsWith("field:")) {
      const fieldKey = val.slice(6);
      const sectionId = fieldKey.split(".")[0];
      onScopeChange({ type: "field", sectionId, fieldKey });
    }
  };

  const scopeColors = useMemo(() => getScopeColors(scope.type), [scope.type]);

  if (!schema) return null;

  return (
    <select
      value={currentValue}
      onChange={handleChange}
      className={`text-xs border rounded-md px-2 py-1 bg-white transition-colors focus:outline-none focus:ring-1 max-w-[140px] min-w-0 shrink truncate ${scopeColors.inputBorder} ${scopeColors.iconText} ${scopeColors.inputFocusRing} ${scopeColors.inputFocusBorder}`}
      title="AI scope"
    >
      <option value="document">Entire Document</option>

      {currentSection && (
        <option value={`section:${currentSection.id}`}>
          Section: {currentSection.title}
        </option>
      )}

      {currentSection &&
        currentSection.fields
          .filter((f) => !f.same_as) // Hide linked fields
          .map((f) => (
            <option
              key={`field:${currentSection.id}.${f.id}`}
              value={`field:${currentSection.id}.${f.id}`}
            >
              Field: {f.label}
            </option>
          ))}
    </select>
  );
}
