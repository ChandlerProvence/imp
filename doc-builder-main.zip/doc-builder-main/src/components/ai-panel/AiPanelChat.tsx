import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import AppErrorBox from "../AppErrorBox";
import { useAiPanelContext } from "../../context/AiPanelContext";
import { useSessionContext } from "../../context/SessionContext";
import { buildBulkEditChatUserMessage } from "../../ai/bulkEdit";
import type { BulkEditRequest } from "../../ai/bulkEdit";
import { getScopedSectionIds } from "../../ai/unifiedPrompt";
import { buildGeneralChatUserMessage } from "../../ai/generalChat";
import { getScopeColors } from "../../utils/scopeColors";
import { useTokenEstimate } from "../../hooks/useTokenEstimate";
import { resolveEffortConfig } from "../../ai/effortTiers";
import { parseEmbeddingProgress } from "../../ai/embeddings";
import ChatInput from "../chat/ChatInput";
import UnifiedMessageList from "./UnifiedMessageList";
import ScopeSelector from "./ScopeSelector";
import { TokenRadial } from "./TokenRadial";
import { ModelIndicator } from "./ModelIndicator";
import { shortSlotTitle } from "./DocumentRowStatus";
import type { StyleReferenceState } from "../../hooks/useStyleReference";

/**
 * Whether sending is disabled, and the banner text. Sending waits while
 * attached documents are processed and while the drafting style is being
 * extracted (a draft sent then would miss the style). A failed style analysis
 * does not block.
 */
export function sendBlock(state: {
  docsReady: boolean;
  docsProcessingStatus: string | null;
  hasAttachedDocs: boolean;
  styleStatus: StyleReferenceState["status"];
}): { blocked: boolean; status: string | null } {
  if (!state.docsReady && state.hasAttachedDocs) return { blocked: true, status: state.docsProcessingStatus };
  if (state.styleStatus === "deriving") return { blocked: true, status: "Analyzing writing style…" };
  return { blocked: false, status: null };
}

export default function AiPanelChat() {
  const {
    messages,
    isStreaming,
    isThinking,
    streamingContent,
    isSearching,
    retrievalMeta,
    error,
    sendMessage,
    stopStreaming,
    docManager,
    scope,
    setScope,
    effortTier,
    setEffortTier,
    proposedChanges,
    detectedObservations,
    pendingQuestion,
    answerQuestion,
    setActiveTab,
    completedSteps,
    activeStepKind,
    prefillText,
    clearPrefill,
    styleReference,
  } = useAiPanelContext();

  const { schema, answers } = useSessionContext();

  // Resolve the active model from the effort tier (for token estimation)
  const activeModel = resolveEffortConfig(effortTier).model;

  // Token radial: estimate context usage
  const { tokens: estimatedTokens, contextWindow } = useTokenEstimate(
    messages,
    undefined, // System prompt is built dynamically — estimate from messages only
    activeModel,
  );

  const scopeColors = useMemo(() => getScopeColors(scope.type), [scope.type]);

  const bottomRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, streamingContent]);

  // Build attached doc chips from unified selection (with processing status + error)
  const attachedDocs = useMemo(() => {
    return docManager.setupDocuments.map((doc) => {
      const status = docManager.docStatuses.get(doc.id);
      const embedMsg =
        docManager.embeddingProgress.get(doc.id) ??
        docManager.embeddingProgress.get(`upload:${doc.id}`);
      const statusText =
        status === "fetching" ? "Fetching…" :
        status === "parsing" ? "Parsing…" :
        embedMsg;
      return {
        id: doc.id,
        name: doc.name,
        processing: !!statusText,
        progress: parseEmbeddingProgress(embedMsg),
        statusText,
        error: docManager.attachmentErrors.get(doc.id)?.message,
        appError: docManager.attachmentErrors.get(doc.id),
        role: doc.roleTitle ? shortSlotTitle(doc.roleTitle) : undefined,
      };
    });
  }, [docManager.setupDocuments, docManager.docStatuses, docManager.embeddingProgress, docManager.attachmentErrors]);

  const { blocked: docsProcessing, status: processingStatus } = sendBlock({
    docsReady: docManager.docsReady,
    docsProcessingStatus: docManager.docsProcessingStatus,
    hasAttachedDocs: attachedDocs.length > 0,
    styleStatus: styleReference.status,
  });

  // Detect if this is a restored conversation that previously had documents attached
  // but no documents are currently selected (user needs to re-upload).
  const [docBannerDismissed, setDocBannerDismissed] = useState(false);
  const showDocBanner = useMemo(() => {
    if (docBannerDismissed) return false;
    if (attachedDocs.length > 0) return false; // Docs are currently attached — no warning needed
    // Check if any past user message referenced documents
    return messages.some(
      (m) => m.role === "user" && m.displayLabel?.includes("[Docs:"),
    );
  }, [messages, attachedDocs, docBannerDismissed]);


  /**
   * Wrap sendMessage to include document content when docs are attached.
   * Uses the same buildBulkEditChatUserMessage pattern from the old AI Draft page
   * to embed small docs inline and let large docs be accessed via search_references.
   */
  const handleSend = useCallback(
    (text: string) => {
      const hasDocs = attachedDocs.length > 0;

      // General chat (no document open): plain text, or text plus attached documents.
      if (!schema) {
        const combined = hasDocs ? docManager.buildCombinedDocumentText() : undefined;
        const docNames = attachedDocs.map((d) => d.name).join(", ");
        const label = hasDocs ? (text ? `${text}\n\n[Docs: ${docNames}]` : `[Docs: ${docNames}]`) : undefined;
        sendMessage(buildGeneralChatUserMessage(text, combined), label);
        return;
      }

      if (!hasDocs) {
        // No docs — just send the text as-is
        sendMessage(text || "Fill in all fields based on available context.");
        return;
      }

      // Build document-enriched message using the existing utility
      const refDocTexts = docManager.buildReferenceDocTexts();
      const combinedText = docManager.buildCombinedDocumentText();

      // Defensive guard: if docs are attached but no content is available,
      // warn the user instead of silently dropping to prompt-only mode.
      if (!combinedText) {
        const docNames = attachedDocs.map((d) => d.name).join(", ");
        sendMessage(
          text || "Fill in all fields based on available context.",
          `${text ? text + "\n\n" : ""}⚠️ [Docs: ${docNames} — content unavailable. Re-open the document picker to check for errors.]`,
        );
        return;
      }

      const sourceDocumentRoles = docManager.buildSourceDocumentRoles();
      const request: BulkEditRequest = {
        mode: "document",
        prompt: text || "Fill in all fields based on available context.",
        documentText: combinedText,
        referenceDocTexts: refDocTexts.length > 0 ? refDocTexts : undefined,
        sourceDocumentRoles: sourceDocumentRoles.length > 0 ? sourceDocumentRoles : undefined,
        selectedSectionIds: schema ? getScopedSectionIds(schema, scope) : [],
        schema: schema ?? ({ id: "", title: "", sections: [] } as any),
        currentAnswers: answers,
      };

      const fullContent = buildBulkEditChatUserMessage(request);

      // Build a concise display label for the chat bubble (keep the "[Docs:" prefix —
      // showDocBanner detects restored conversations by it).
      const docNames = attachedDocs.map((d) => (d.role ? `${d.role}: ${d.name}` : d.name)).join(", ");
      const displayLabel = text
        ? `${text}\n\n[Docs: ${docNames}]`
        : `[Docs: ${docNames}]`;

      sendMessage(fullContent, displayLabel);
    },
    [attachedDocs, sendMessage, docManager, schema, scope, answers],
  );

  return (
    <div className="flex flex-col flex-1 min-h-0">
      {/* Document re-upload banner */}
      {showDocBanner && (
        <div className="mx-3 mt-2 rounded-md bg-amber-50 border border-amber-200 px-3 py-2 text-xs text-amber-800 flex items-start gap-2">
          <span className="flex-1">
            This conversation previously used attached documents. Re-upload them via the <strong>+</strong> button to continue asking questions about them.
          </span>
          <button
            type="button"
            onClick={() => setDocBannerDismissed(true)}
            className="shrink-0 text-amber-500 hover:text-amber-700"
            aria-label="Dismiss"
          >
            ✕
          </button>
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        <UnifiedMessageList
          messages={messages}
          streamingContent={streamingContent}
          isSearching={isSearching}
          isThinking={isThinking}
          retrievalMeta={retrievalMeta}
          proposedChangesCount={proposedChanges.length}
          onViewChanges={() => setActiveTab("changes")}
          observationsCount={detectedObservations.length}
          onViewObservations={() => setActiveTab("observations")}
          userBubbleBg={scopeColors.userBubbleBg}
          completedSteps={completedSteps}
          activeStepKind={activeStepKind}
          pendingQuestion={pendingQuestion}
          onAnswerQuestion={answerQuestion}
          emptyState={
            !schema ? (
              <div className="text-center text-sm text-gray-400 max-w-[300px] space-y-2">
                <p>No access to Claude/ChatGPT?</p>
                <p>Have a question about CUI material?</p>
                <p>No problem!</p>
                <p>When there are no active drafting sessions I can be used as a general chatbot!</p>
                <p>Ask a question, or attach documents to ask about them.</p>
              </div>
            ) : undefined
          }
        />
        <div ref={bottomRef} />
      </div>

      {/* Attachment error boxes — one per errored doc, full copyable text */}
      {attachedDocs.filter((d) => d.appError).map((d) => (
        <AppErrorBox key={d.id} className="mx-3 mb-2" error={d.appError!} subject={d.name} />
      ))}

      {/* Error banner */}
      {error && <AppErrorBox error={error} className="mx-3 mb-2" />}

      {/* Document processing banner */}
      {docsProcessing && (
        <div className="mx-3 mb-2 rounded-md bg-amber-50 border border-amber-200 px-3 py-2 text-xs text-amber-800 flex items-center gap-2">
          <span className="inline-block w-3 h-3 border-2 border-amber-500 border-t-transparent rounded-full animate-spin shrink-0" />
          <span>{processingStatus}</span>
        </div>
      )}

      {/* Input */}
      <ChatInput
        onSend={handleSend}
        onStop={stopStreaming}
        isStreaming={isStreaming}
        disabled={docsProcessing}
        onAttach={() => docManager.setShowDocPicker(true)}
        attachedDocs={attachedDocs}
        onRemoveDoc={(id) => docManager.handleRemoveDocument(id)}
        scopeSlot={<ScopeSelector schema={schema} scope={scope} onScopeChange={setScope} />}
        tokenSlot={<TokenRadial tokens={estimatedTokens} contextWindow={contextWindow} />}
        modelSlot={<ModelIndicator value={effortTier} onChange={setEffortTier} disabled={isStreaming} />}
        inputColorClasses={`${scopeColors.inputBorder} ${scopeColors.inputFocusBorder} focus:ring-1 ${scopeColors.inputFocusRing}`}
        sendColorClasses={`${scopeColors.buttonBg} ${scopeColors.buttonBgHover}`}
        prefillText={prefillText}
        onPrefillConsumed={clearPrefill}
        placeholder={pendingQuestion ? "Choose above, or type a reply…" : !schema ? "Ask anything…" : undefined}
      />
    </div>
  );
}
