import type { DetectedObservation } from "../../ai/observationTypes";
import ObservationCard from "./ObservationCard";

interface Props {
  observations: DetectedObservation[];
  onClear: () => void;
  /** Navigate to the Proposed Changes tab scrolled to a specific field. */
  onFieldClick?: (fieldKey: string) => void;
}

export default function ObservationsTab({ observations, onClear, onFieldClick }: Props) {
  if (observations.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="text-center max-w-[220px]">
          <div className="mb-2 flex justify-center text-amber-400">
            <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75m-3-7.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285Z" />
            </svg>
          </div>
          <p className="text-sm text-gray-500 font-medium">No alerts detected</p>
          <p className="text-xs text-gray-400 mt-1">
            The AI will flag contradictions and issues when it notices them during document analysis.
          </p>
        </div>
      </div>
    );
  }

  const highCount = observations.filter((o) => o.severity === "high").length;
  const mediumCount = observations.filter((o) => o.severity === "medium").length;
  const lowCount = observations.filter((o) => o.severity === "low").length;

  return (
    <div className="flex flex-col flex-1 min-h-0">
      {/* Summary bar */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-gray-100 bg-gray-50/50 shrink-0">
        <div className="flex items-center gap-2 text-xs">
          {highCount > 0 && (
            <span className="inline-flex items-center gap-0.5 text-red-700 font-medium">
              <span className="w-2 h-2 rounded-full bg-red-500" />
              {highCount} high
            </span>
          )}
          {mediumCount > 0 && (
            <span className="inline-flex items-center gap-0.5 text-amber-700 font-medium">
              <span className="w-2 h-2 rounded-full bg-amber-500" />
              {mediumCount} medium
            </span>
          )}
          {lowCount > 0 && (
            <span className="inline-flex items-center gap-0.5 text-yellow-700 font-medium">
              <span className="w-2 h-2 rounded-full bg-yellow-400" />
              {lowCount} low
            </span>
          )}
        </div>
        <button
          type="button"
          onClick={onClear}
          className="text-[11px] text-gray-400 hover:text-gray-600 transition-colors"
        >
          Clear all
        </button>
      </div>

      {/* Observation cards */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {observations.map((obs, i) => (
          <ObservationCard
            key={`${obs.topic}-${i}`}
            observation={obs}
            onFieldClick={onFieldClick}
          />
        ))}
      </div>
    </div>
  );
}
