import { useMemo } from "react";

/**
 * Radial progress circle showing context window usage.
 * Fills proportionally as tokens approach the context window limit.
 * Color transitions: blue → amber → red at 60% / 80% thresholds.
 */

interface TokenRadialProps {
  /** Current estimated input tokens. */
  tokens: number;
  /** Context window size (max tokens). */
  contextWindow: number;
  /** Size of the SVG in pixels. */
  size?: number;
}

export function TokenRadial({ tokens, contextWindow, size = 28 }: TokenRadialProps) {
  const percentage = Math.min(tokens / contextWindow, 1);

  const { strokeColor, label } = useMemo(() => {
    // Abbreviate token count: 1234 → "1.2k", 123456 → "123k"
    let tokenLabel: string;
    if (tokens >= 1_000_000) {
      tokenLabel = `${(tokens / 1_000_000).toFixed(1)}M`;
    } else if (tokens >= 1000) {
      tokenLabel = `${(tokens / 1000).toFixed(tokens >= 100_000 ? 0 : 1)}k`;
    } else {
      tokenLabel = String(tokens);
    }

    // Color thresholds
    let color: string;
    if (percentage >= 0.8) {
      color = "#ef4444"; // red-500
    } else if (percentage >= 0.6) {
      color = "#f59e0b"; // amber-500
    } else {
      color = "#6b7280"; // gray-500
    }

    return { strokeColor: color, label: tokenLabel };
  }, [tokens, contextWindow, percentage]);

  // SVG circle math
  const strokeWidth = 2.5;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const dashOffset = circumference * (1 - percentage);

  // Don't render if no tokens estimated yet
  if (tokens <= 0) return null;

  return (
    <div
      className="relative inline-flex items-center justify-center shrink-0"
      title={`~${label} tokens (${Math.round(percentage * 100)}% of context window)`}
      style={{ width: size, height: size }}
    >
      <svg
        width={size}
        height={size}
        className="-rotate-90"
        aria-hidden="true"
      >
        {/* Progress arc (no background ring — just the filled portion) */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={strokeColor}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={dashOffset}
          strokeLinecap="round"
          className="transition-all duration-300 ease-in-out"
        />
      </svg>
      {/* Center label */}
      <span
        className="absolute text-[8px] font-medium leading-none"
        style={{ color: strokeColor }}
      >
        {label}
      </span>
    </div>
  );
}
