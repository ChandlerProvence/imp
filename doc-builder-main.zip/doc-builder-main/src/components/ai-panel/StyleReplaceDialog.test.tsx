import { describe, expect, it, vi } from "vitest";
import { fireEvent, render, screen } from "@testing-library/react";
import type { StyleReferenceState } from "../../hooks/useStyleReference";

const styleReference = {
  status: "confirm",
  replaced: false,
  reanalyze: vi.fn(),
  clear: vi.fn(),
  edit: vi.fn(),
  confirmReplace: vi.fn(),
  keepNote: vi.fn(),
} as StyleReferenceState;

vi.mock("../../context/AiPanelContext", () => ({
  useAiPanelContext: () => ({ styleReference }),
}));

import StyleReplaceDialog from "./StyleReplaceDialog";

describe("StyleReplaceDialog", () => {
  it("asks only while a replacement awaits confirmation", () => {
    styleReference.status = "idle";
    const { unmount } = render(<StyleReplaceDialog />);
    expect(screen.queryByText("Replace your drafting style note?")).not.toBeInTheDocument();
    unmount();

    styleReference.status = "confirm";
    render(<StyleReplaceDialog />);
    expect(screen.getByText("Replace your drafting style note?")).toBeInTheDocument();
  });

  it("replaces or keeps the note", () => {
    styleReference.status = "confirm";
    render(<StyleReplaceDialog />);
    fireEvent.click(screen.getByRole("button", { name: "Replace with new analysis" }));
    expect(styleReference.confirmReplace).toHaveBeenCalled();
    fireEvent.click(screen.getByRole("button", { name: "Keep my note" }));
    expect(styleReference.keepNote).toHaveBeenCalled();
  });
});
