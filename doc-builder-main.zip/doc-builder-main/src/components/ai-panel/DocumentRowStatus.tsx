import type { UnifiedDocItem, UseDocumentManagerReturn } from "../../hooks/useDocumentManager";
import DocumentEndpointBadge from "../DocumentEndpointBadge";
import ProgressRing from "../icons/ProgressRing";
import ErrorBox from "../ErrorBox";
import AppErrorBox from "../AppErrorBox";
import { parseEmbeddingProgress } from "../../ai/embeddings";
import type { CuiDetectionResult } from "../../ai/cuiDetection";

interface Props {
  doc: UnifiedDocItem;
  docManager: UseDocumentManagerReturn;
  /** Whether the doc is in the draft selection (drives the ready ✓). */
  isSelected: boolean;
}

function embedProgressFor(doc: UnifiedDocItem, docManager: UseDocumentManagerReturn): string | undefined {
  return docManager.embeddingProgress.get(doc.id) || docManager.embeddingProgress.get(`upload:${doc.id}`);
}

/** True while a document is fetching, parsing, embedding, or being CUI-scanned. */
export function isDocProcessing(doc: UnifiedDocItem, docManager: UseDocumentManagerReturn): boolean {
  const status = docManager.docStatuses.get(doc.id);
  return (
    status === "fetching" ||
    status === "parsing" ||
    !!embedProgressFor(doc, docManager) ||
    docManager.scanningDocIds.has(doc.id)
  );
}

const spinner = (
  <span className="inline-block w-2.5 h-2.5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
);
const amberPill = "text-xs text-amber-700 bg-amber-100 rounded-full px-2 py-0.5 flex-shrink-0";

const CONFIRM_SUFFIX = "Confirm this document's CUI status before using it.";

/** Tooltip for the flagged-CUI warning icon, worded by detection method. */
export function cuiFlagTooltip(detection: CuiDetectionResult | undefined): string {
  if (!detection) return `Potential CUI content detected. ${CONFIRM_SUFFIX}`;
  if (detection.method === "regex") {
    const markers = detection.markers.length ? ` — ${detection.markers.join(", ")}` : "";
    return `Potential CUI: standard CUI marking(s) found in the document${markers}. ${CONFIRM_SUFFIX}`;
  }
  const reason = detection.reason ? ` — ${detection.reason.replace(/\.\s*$/, "")}` : "";
  return `Potential CUI: the AI scan flagged this document (${detection.confidence} confidence)${reason}. ${CONFIRM_SUFFIX}`;
}

/**
 * Inline status for a document row in the picker: endpoint badge, CUI pills,
 * fetch/parse/embedding progress, attachment error pill, and the ready ✓.
 * Shared by the Other documents list and slot cards.
 */
export default function DocumentRowStatus({ doc, docManager, isSelected }: Props) {
  const status = docManager.docStatuses.get(doc.id);
  const embedProgress = embedProgressFor(doc, docManager);
  const isScanning = docManager.scanningDocIds.has(doc.id);
  const cuiStatus = doc.savedDoc?.cuiStatus;
  const attachErr = docManager.attachmentErrors.get(doc.id);

  return (
    <>
      {/* A CUI-status doc shows only the CUI pill, never alongside "Proprietary". */}
      {cuiStatus !== "cui" && <DocumentEndpointBadge endpoint={doc.savedDoc?.uploadEndpoint} />}
      {isScanning && (
        <span className="text-xs text-blue-500 flex items-center gap-1 flex-shrink-0">
          {spinner}
          Scanning for CUI…
        </span>
      )}
      {!isScanning && cuiStatus === "flagged" && (
        <span
          role="img"
          aria-label="Potential CUI content detected"
          className="text-xs flex-shrink-0 cursor-help"
          title={cuiFlagTooltip(doc.savedDoc?.cuiDetection)}
        >
          ⚠️
        </span>
      )}
      {!isScanning && cuiStatus === "scan-error" && (
        <span className={amberPill}>Potential CUI — scan incomplete</span>
      )}
      {cuiStatus === "cui" && !attachErr && <span className={amberPill}>CUI</span>}
      {status === "fetching" && (
        <span className="text-xs text-blue-500 flex items-center gap-1">
          {spinner}
          Fetching…
        </span>
      )}
      {status === "parsing" && (
        <span className="text-xs text-blue-500 flex items-center gap-1">
          {spinner}
          Parsing…
        </span>
      )}
      {embedProgress && (
        <span className="text-xs text-purple-500 flex items-center gap-1 flex-shrink-0">
          <ProgressRing progress={parseEmbeddingProgress(embedProgress)} className="w-3 h-3" />
          {embedProgress}
        </span>
      )}
      {attachErr && (
        <span className="text-xs text-red-600 bg-red-100 rounded-full px-2 py-0.5 flex-shrink-0">
          Attachment error
        </span>
      )}
      {status === "ready" && isSelected && !embedProgress && !attachErr &&
        cuiStatus !== "flagged" && cuiStatus !== "scan-error" && cuiStatus !== "cui" && (
          <span className="text-xs text-green-600">✓</span>
        )}
    </>
  );
}

/** Full error detail under a document row: CUI scan error and attachment error. */
export function DocumentRowErrors({ doc, docManager }: Omit<Props, "isSelected">) {
  const attachErr = docManager.attachmentErrors.get(doc.id);
  return (
    <>
      {doc.savedDoc?.cuiStatus === "scan-error" && doc.savedDoc.cuiScanError && (
        <ErrorBox
          className="ml-9 mr-2 mb-1.5"
          title="CUI scan failed — document was saved anyway"
          detail={doc.savedDoc.cuiScanError}
          helpText={null}
        />
      )}
      {attachErr && <AppErrorBox className="ml-9 mr-2 mb-1.5" error={attachErr} />}
    </>
  );
}

/** Short form of a slot title for badges: "PWS (Performance Work Statement)" → "PWS". */
export function shortSlotTitle(title: string): string {
  return title.replace(/\s*\([^)]*\)\s*$/, "") || title;
}

/** Small badge showing a document's slot role. */
export function RoleBadge({ title, muted = false }: { title: string; muted?: boolean }) {
  return (
    <span
      className={`text-[10px] font-medium rounded px-1.5 py-0.5 flex-shrink-0 ${
        muted ? "bg-gray-100 text-gray-500" : "bg-indigo-100 text-indigo-700"
      }`}
      title={muted ? `Previously used as: ${title}` : title}
    >
      {shortSlotTitle(title)}
    </span>
  );
}
