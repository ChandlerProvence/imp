import { useState } from "react";
import { downloadChatTroubleshoot } from "../../db/chatTroubleshootExport";

interface Props {
  sessionId: string;
  activeConvKey: string;
  schemaTitle: string;
}

/**
 * A kebab (⋮) menu in the AI panel header with chat-level actions.
 * Currently supports: Export Chat for Troubleshooting.
 */
export default function ChatHeaderMenu({ sessionId, activeConvKey, schemaTitle }: Props) {
  const [open, setOpen] = useState(false);
  const [exporting, setExporting] = useState(false);

  const handleExport = async () => {
    setExporting(true);
    try {
      await downloadChatTroubleshoot(sessionId, activeConvKey, schemaTitle);
    } catch (err) {
      console.error("Failed to export chat for troubleshooting:", err);
    } finally {
      setExporting(false);
      setOpen(false);
    }
  };

  return (
    <div className="relative">
      {/* Kebab trigger */}
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="text-gray-400 hover:text-gray-600 p-1 rounded hover:bg-gray-200 transition-colors"
        title="Chat actions"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 20 20"
          fill="currentColor"
          className="w-3.5 h-3.5"
        >
          <path d="M10 3a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM10 8.5a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM11.5 15.5a1.5 1.5 0 1 0-3 0 1.5 1.5 0 0 0 3 0Z" />
        </svg>
      </button>

      {/* Dropdown */}
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-full mt-1 z-20 w-60 rounded-md border border-gray-200 bg-white shadow-lg py-1">
            <button
              type="button"
              onClick={handleExport}
              disabled={exporting}
              className="w-full flex items-center gap-2 px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {/* Download icon */}
              <svg
                className="w-4 h-4 text-gray-400 shrink-0"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5M16.5 12 12 16.5m0 0L7.5 12m4.5 4.5V3" />
              </svg>
              {exporting ? "Exporting…" : "Export Chat for Troubleshooting"}
            </button>
          </div>
        </>
      )}
    </div>
  );
}
