import { useState } from "react";
import type { DetectedObservation } from "../../ai/observationTypes";

interface Props {
  observation: DetectedObservation;
  /** Callback when user clicks the linked field key. */
  onFieldClick?: (fieldKey: string) => void;
}

const SEVERITY_STYLES = {
  high: "bg-red-100 text-red-800 border-red-200",
  medium: "bg-amber-100 text-amber-800 border-amber-200",
  low: "bg-yellow-50 text-yellow-700 border-yellow-200",
} as const;

const TYPE_STYLES: Record<string, string> = {
  conflict: "bg-amber-50 text-amber-700 border-amber-200",
  gap: "bg-blue-50 text-blue-700 border-blue-200",
  assumption: "bg-gray-100 text-gray-600 border-gray-200",
  quality: "bg-purple-50 text-purple-700 border-purple-200",
  placeholder: "bg-rose-50 text-rose-700 border-rose-200",
};

const TYPE_BORDER_COLORS: Record<string, string> = {
  conflict: "border-l-amber-400",
  gap: "border-l-blue-400",
  assumption: "border-l-gray-400",
  quality: "border-l-purple-400",
  placeholder: "border-l-rose-400",
};

export default function ObservationCard({ observation, onFieldClick }: Props) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div
      className={`rounded-md border border-gray-200 border-l-4 ${TYPE_BORDER_COLORS[observation.type] ?? "border-l-gray-400"} bg-white`}
    >
      {/* Header */}
      <button
        type="button"
        className="w-full px-3 py-2 text-left"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center gap-2 flex-wrap">
          {/* Severity pill */}
          <span
            className={`inline-flex items-center rounded-full px-1.5 py-0.5 text-[10px] font-medium border ${SEVERITY_STYLES[observation.severity]}`}
          >
            {observation.severity}
          </span>
          {/* Type pill */}
          <span
            className={`inline-flex items-center rounded-full px-1.5 py-0.5 text-[10px] font-medium border ${TYPE_STYLES[observation.type] ?? "bg-gray-100 text-gray-600 border-gray-200"}`}
          >
            {observation.type}
          </span>
          {/* Topic */}
          <span className="text-sm font-medium text-gray-800 flex-1 min-w-0 truncate">
            {observation.topic}
          </span>
          {/* Expand arrow */}
          <svg
            className={`w-3.5 h-3.5 text-gray-400 transition-transform ${expanded ? "rotate-180" : ""}`}
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth={2}
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5" />
          </svg>
        </div>
        <p className="text-xs text-gray-600 mt-1 line-clamp-2">{observation.description}</p>
      </button>

      {/* Expanded details */}
      {expanded && (
        <div className="px-3 pb-3 border-t border-gray-100 mt-0 pt-2 space-y-2">
          {/* Sources */}
          {observation.sources.length > 0 && (
            <div className="space-y-1.5">
              <span className="text-[10px] font-medium text-gray-500 uppercase tracking-wide">
                Sources
              </span>
              {observation.sources.map((src, i) => (
                <div key={i} className="rounded bg-gray-50 px-2 py-1.5 text-xs">
                  <span className="font-medium text-gray-700">{src.document}:</span>{" "}
                  <span className="text-gray-600">{src.value}</span>
                  {src.excerpt && (
                    <p className="mt-1 text-[11px] text-gray-500 italic border-l-2 border-gray-200 pl-2">
                      "{src.excerpt}"
                    </p>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Recommendation */}
          {observation.recommendation && (
            <div>
              <span className="text-[10px] font-medium text-gray-500 uppercase tracking-wide">
                Recommendation
              </span>
              <p className="text-xs text-gray-700 mt-0.5">{observation.recommendation}</p>
            </div>
          )}

          {/* Field link */}
          {observation.fieldKey && onFieldClick && (
            <button
              type="button"
              onClick={() => onFieldClick(observation.fieldKey!)}
              className="text-[11px] text-blue-600 hover:text-blue-800 hover:underline"
            >
              View field: {observation.fieldKey}
            </button>
          )}
        </div>
      )}
    </div>
  );
}
