interface Props {
  activeTab: "chat" | "changes" | "observations";
  onTabChange: (tab: "chat" | "changes" | "observations") => void;
  changesCount: number;
  hasUnseenChanges: boolean;
  observationsCount: number;
  hasUnseenObservations: boolean;
}

export default function AiPanelTabBar({
  activeTab,
  onTabChange,
  changesCount,
  hasUnseenChanges,
  observationsCount,
  hasUnseenObservations,
}: Props) {
  const baseClasses = "relative px-3 py-2 text-xs font-medium transition-colors cursor-pointer";
  const activeClasses = "border-b-2 border-blue-600 text-blue-700";
  const inactiveClasses = "border-b-2 border-transparent text-gray-500 hover:text-gray-700";

  return (
    <div
      role="tablist"
      className="flex border-b border-gray-200 bg-gray-50 shrink-0"
    >
      <button
        type="button"
        role="tab"
        aria-selected={activeTab === "chat"}
        className={`${baseClasses} ${activeTab === "chat" ? activeClasses : inactiveClasses}`}
        onClick={() => onTabChange("chat")}
      >
        Chat
      </button>

      <button
        type="button"
        role="tab"
        aria-selected={activeTab === "observations"}
        className={`${baseClasses} ${activeTab === "observations" ? activeClasses : inactiveClasses}`}
        onClick={() => onTabChange("observations")}
      >
        <span className="inline-flex items-center gap-1.5">
          Alerts
          {observationsCount > 0 && (
            <span className="text-[10px] text-amber-600">({observationsCount})</span>
          )}
          {hasUnseenObservations && (
            <span className="w-2 h-2 rounded-full bg-amber-500 inline-block" />
          )}
        </span>
      </button>

      <button
        type="button"
        role="tab"
        aria-selected={activeTab === "changes"}
        className={`${baseClasses} ${activeTab === "changes" ? activeClasses : inactiveClasses}`}
        onClick={() => onTabChange("changes")}
      >
        <span className="inline-flex items-center gap-1.5">
          Proposed Changes
          {changesCount > 0 && (
            <span className="text-[10px] text-gray-400">({changesCount})</span>
          )}
          {hasUnseenChanges && (
            <span className="w-2 h-2 rounded-full bg-blue-500 inline-block" />
          )}
        </span>
      </button>
    </div>
  );
}
