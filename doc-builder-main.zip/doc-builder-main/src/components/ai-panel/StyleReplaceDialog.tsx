import { useAiPanelContext } from "../../context/AiPanelContext";
import ConfirmDialog from "../ConfirmDialog";

/** Asks before a new style reference replaces a drafting style note the user edited. */
export default function StyleReplaceDialog() {
  const { styleReference } = useAiPanelContext();
  return (
    <ConfirmDialog
      open={styleReference.status === "confirm"}
      title="Replace your drafting style note?"
      message="You edited the drafting style note. Analyzing the new style reference will replace your edits with a new note."
      confirmLabel="Replace with new analysis"
      cancelLabel="Keep my note"
      onConfirm={styleReference.confirmReplace}
      onCancel={styleReference.keepNote}
    />
  );
}
