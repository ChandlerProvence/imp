import { useCallback, useState } from "react";
import { useAskSage } from "../../context/AskSageContext";
import {
  getAccessToken,
  invalidateToken,
  searchSharePoint,
  fetchFileContent,
  TokenInvalidError,
  type SharePointItem,
  type McpToolResult,
} from "../../ai/asksage";
import ErrorBox from "../ErrorBox";

interface Props {
  /** Feed a file through the normal upload/parse pipeline (mammoth, pdfjs, sheetjs). */
  onAddFile: (file: File) => void;
}

/** Map file extension → MIME type for constructing File objects from base64. */
const MIME_TYPES: Record<string, string> = {
  docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  pdf: "application/pdf",
  xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  xls: "application/vnd.ms-excel",
  pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  csv: "text/csv",
  txt: "text/plain",
};

// AskSage is disabled pending AskSage team approval; see the STATUS block in src/ai/asksage.ts. Do not delete.

/**
 * SharePoint file search via AskSage M365 MCP tools.
 * Users type a search query, see structured file results, and can fetch + attach
 * files to the document pipeline. All fetched files are routed through the normal
 * upload/parse pipeline (mammoth for .docx, pdfjs for .pdf, etc.).
 */
export default function SharePointSearch({ onAddFile }: Props) {
  const { email, apiKey } = useAskSage();

  // Search state
  const [query, setQuery] = useState("");
  const [items, setItems] = useState<SharePointItem[]>([]);
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);

  // File-fetch state
  const [fetchingId, setFetchingId] = useState<string | null>(null);
  const [fetchError, setFetchError] = useState<string | null>(null);
  const [addedFiles, setAddedFiles] = useState<Set<string>>(new Set());

  // ---------------------------------------------------------------------------
  // Search
  // ---------------------------------------------------------------------------
  const handleSearch = useCallback(async () => {
    if (!query.trim() || !email || !apiKey) return;

    setSearching(true);
    setSearchError(null);
    setItems([]);
    setFetchError(null);

    try {
      let token = await getAccessToken(email, apiKey);
      let result: McpToolResult<{ items: SharePointItem[] }>;
      try {
        result = await searchSharePoint(token, query.trim());
      } catch (err) {
        if (err instanceof TokenInvalidError) {
          // Stale token — refresh and retry once
          invalidateToken();
          token = await getAccessToken(email, apiKey);
          result = await searchSharePoint(token, query.trim());
        } else {
          throw err;
        }
      }

      if (result.success && result.data?.items) {
        setItems(result.data.items);
        if (result.data.items.length === 0) {
          setSearchError("No files found matching your query.");
        }
      } else {
        setSearchError(result.error ?? "Search returned no results.");
      }
    } catch (err) {
      setSearchError(err instanceof Error ? err.message : "Search failed");
    } finally {
      setSearching(false);
    }
  }, [query, email, apiKey]);

  // ---------------------------------------------------------------------------
  // Fetch + add a file
  // ---------------------------------------------------------------------------
  const handleFetchAndAdd = useCallback(
    async (item: SharePointItem) => {
      if (!email || !apiKey) return;

      setFetchingId(item.id);
      setFetchError(null);

      try {
        let token = await getAccessToken(email, apiKey);
        let result;
        try {
          result = await fetchFileContent(token, item.id);
        } catch (err) {
          if (err instanceof TokenInvalidError) {
            invalidateToken();
            token = await getAccessToken(email, apiKey);
            result = await fetchFileContent(token, item.id);
          } else {
            throw err;
          }
        }

        if (result.success && result.data) {
          const data = result.data as Record<string, unknown>;
          const rawContent = data.content ?? data.text ?? data.body;

          if (typeof rawContent !== "string" || !rawContent.trim()) {
            // No content at all — check for a downloadUrl fallback
            if (data.downloadUrl) {
              window.open(String(data.downloadUrl), "_blank", "noopener");
              setFetchError(
                `"${item.name}" content unavailable — opened the download link. ` +
                `Download and upload it manually.`,
              );
            } else {
              setFetchError(`"${item.name}" returned no content. The file may be empty or inaccessible.`);
            }
            return;
          }

          // Build a File object from the returned content and route it through
          // the normal upload pipeline (mammoth / pdfjs / sheetjs).
          const ext = item.name.split(".").pop()?.toLowerCase() ?? "";
          const mimeType = MIME_TYPES[ext] ?? item.mimeType ?? "application/octet-stream";
          const trimmed = rawContent.trim();

          // The MCP may return base64-encoded binary or already-extracted text.
          // Try base64 decode first; fall back to UTF-8 text.
          let fileBytes: Uint8Array | null = null;
          try {
            const binary = atob(trimmed);
            // Sanity check: atob succeeds on short normal words too. Only trust
            // it if the result is significantly shorter (binary) or has non-
            // printable bytes — hallmarks of actual base64-encoded binary.
            const hasNonPrintable = binary.split("").some((ch) => {
              const c = ch.charCodeAt(0);
              return c < 9 || (c > 13 && c < 32);
            });
            if (hasNonPrintable) {
              fileBytes = new Uint8Array(binary.length);
              for (let i = 0; i < binary.length; i++) fileBytes[i] = binary.charCodeAt(i);
            }
          } catch {
            // Not base64 — will treat as text below
          }

          const file = fileBytes
            ? new File([fileBytes.buffer as ArrayBuffer], item.name, { type: mimeType })
            : new File([trimmed], item.name, { type: mimeType });

          onAddFile(file);
          setAddedFiles((prev) => new Set([...prev, item.id]));
        } else {
          setFetchError(`Could not fetch "${item.name}": ${result.error ?? "unknown error"}`);
        }
      } catch (err) {
        setFetchError(
          `Failed to fetch "${item.name}": ${err instanceof Error ? err.message : "unknown error"}`,
        );
      } finally {
        setFetchingId(null);
      }
    },
    [email, apiKey, onAddFile],
  );

  // ---------------------------------------------------------------------------
  // Render helpers
  // ---------------------------------------------------------------------------
  function formatSize(bytes: number): string {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }

  /** Extract a readable site/folder path from the SharePoint webUrl. */
  function extractPath(item: SharePointItem): string {
    // item.path is usually null from search_files. Derive from webUrl instead.
    // webUrl looks like: https://host/sites/SiteName/Shared Documents/Folder/File.docx
    try {
      const url = new URL(item.webUrl);
      // Strip the filename from the end and decode
      const segments = decodeURIComponent(url.pathname).split("/");
      segments.pop(); // remove filename
      // Drop leading empty segment and common prefixes like "sites"
      const meaningful = segments.filter(Boolean);
      // Find the site name (after "sites/") and everything after
      const sitesIdx = meaningful.indexOf("sites");
      const pathParts = sitesIdx >= 0 ? meaningful.slice(sitesIdx + 1) : meaningful;
      return pathParts.join(" / ") || url.hostname;
    } catch {
      return item.path ?? "";
    }
  }

  function fileIcon(item: SharePointItem): string {
    if (item.type === "folder") return "📁";
    const mime = item.mimeType ?? "";
    if (mime.includes("pdf")) return "📕";
    if (mime.includes("word") || mime.includes("document")) return "📘";
    if (mime.includes("sheet") || mime.includes("excel")) return "📗";
    if (mime.includes("presentation") || mime.includes("powerpoint")) return "📙";
    if (mime.includes("image")) return "🖼️";
    return "📄";
  }

  // ---------------------------------------------------------------------------
  // JSX
  // ---------------------------------------------------------------------------
  return (
    <div className="flex flex-col gap-3 h-full min-h-0">
      {/* Search bar */}
      <div className="flex gap-2 flex-shrink-0">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              handleSearch();
            }
          }}
          placeholder='e.g. "NDA templates" or "SOW contract"'
          className="flex-1 rounded-md border border-gray-300 px-3 py-1.5 text-xs shadow-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
        />
        <button
          type="button"
          onClick={handleSearch}
          disabled={searching || !query.trim()}
          className="rounded-md bg-blue-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {searching ? (
            <span className="flex items-center gap-1">
              <span className="inline-block w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Searching…
            </span>
          ) : (
            "Search"
          )}
        </button>
      </div>

      {/* Search error */}
      {searchError && (
        <ErrorBox title="Search failed" detail={searchError} />
      )}

      {/* Result count */}
      {items.length > 0 && (
        <p className="text-xs text-gray-500">
          {items.length} {items.length === 1 ? "result" : "results"} found
        </p>
      )}

      {/* File results — fills remaining height with always-visible scrollbar */}
      {items.length > 0 && (
        <ul className="flex-1 min-h-0 rounded-md border border-gray-200 bg-gray-50 divide-y divide-gray-200 overflow-y-auto">
          {items.map((item) => {
            const isAdded = addedFiles.has(item.id);
            const isFetching = fetchingId === item.id;
            const isFile = item.type === "file";

            return (
              <li key={item.id} className="px-3 py-2 flex items-center gap-2 text-xs">
                <span className="flex-shrink-0">{fileIcon(item)}</span>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-gray-800 truncate" title={item.name}>
                    {item.name}
                  </p>
                  <p className="text-gray-500 truncate" title={item.webUrl}>
                    {extractPath(item)}
                  </p>
                  <p className="text-gray-400 truncate">
                    {formatSize(item.size)}
                    {item.lastModifiedDateTime &&
                      ` · ${new Date(item.lastModifiedDateTime).toLocaleDateString()}`}
                  </p>
                </div>
                {isFile && (
                  isAdded ? (
                    <span className="flex-shrink-0 text-green-600 font-medium">✓ Added</span>
                  ) : (
                    <button
                      type="button"
                      disabled={isFetching || !!fetchingId}
                      onClick={() => handleFetchAndAdd(item)}
                      className="flex-shrink-0 rounded border border-gray-300 bg-white px-2 py-1 text-xs font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50"
                    >
                      {isFetching ? (
                        <span className="flex items-center gap-1">
                          <span className="inline-block w-3 h-3 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
                          Fetching…
                        </span>
                      ) : (
                        "Add"
                      )}
                    </button>
                  )
                )}
              </li>
            );
          })}
        </ul>
      )}

      {/* Fetch error */}
      {fetchError && (
        <ErrorBox title="File fetch failed" detail={fetchError} />
      )}
    </div>
  );
}
