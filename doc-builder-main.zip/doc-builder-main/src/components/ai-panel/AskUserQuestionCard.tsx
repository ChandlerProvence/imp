import { useEffect, useRef, useState } from "react";
import type { AskUserQuestion, QuestionAnswer } from "../../ai/askUserTypes";

interface Props {
  questions: AskUserQuestion[];
  onSubmit: (answers: QuestionAnswer[]) => void;
}

interface Draft {
  selected: Set<string>;
  otherText: string;
  skipped: boolean;
}

function emptyDraft(): Draft {
  return { selected: new Set(), otherText: "", skipped: false };
}

function isAnswered(draft: Draft): boolean {
  return draft.skipped || draft.selected.size > 0 || draft.otherText.trim() !== "";
}

export default function AskUserQuestionCard({ questions, onSubmit }: Props) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [drafts, setDrafts] = useState<Draft[]>(() => questions.map(emptyDraft));
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    cardRef.current?.focus();
  }, []);

  const active = questions[activeIndex];
  const activeDraft = drafts[activeIndex];
  const isLast = activeIndex === questions.length - 1;
  const allAnswered = drafts.every(isAnswered);

  function updateActiveDraft(update: Partial<Draft>) {
    setDrafts((prev) =>
      prev.map((d, i) => (i === activeIndex ? { ...d, ...update, skipped: false } : d)),
    );
  }

  function selectSingle(label: string) {
    updateActiveDraft({ selected: new Set([label]) });
  }

  function toggleMulti(label: string) {
    setDrafts((prev) =>
      prev.map((d, i) => {
        if (i !== activeIndex) return d;
        const next = new Set(d.selected);
        if (next.has(label)) next.delete(label);
        else next.add(label);
        return { ...d, selected: next, skipped: false };
      }),
    );
  }

  function skipActive() {
    setDrafts((prev) =>
      prev.map((d, i) => (i === activeIndex ? { selected: new Set(), otherText: "", skipped: true } : d)),
    );
    advance();
  }

  function advance() {
    if (!isLast) setActiveIndex((i) => i + 1);
  }

  function handleSubmit() {
    const answers: QuestionAnswer[] = questions.map((q, i) => {
      const d = drafts[i];
      return {
        header: q.header,
        question: q.question,
        fieldKey: q.fieldKey,
        selected: [...d.selected],
        otherText: d.otherText.trim() !== "" ? d.otherText.trim() : undefined,
        skipped: d.skipped,
      };
    });
    onSubmit(answers);
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key >= "1" && e.key <= "9") {
      const idx = Number(e.key) - 1;
      if (idx < active.options.length) {
        const label = active.options[idx].label;
        if (active.multiSelect) toggleMulti(label);
        else selectSingle(label);
      }
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (isLast) {
        if (allAnswered) handleSubmit();
      } else if (isAnswered(activeDraft)) {
        advance();
      }
    }
  }

  return (
    <div
      ref={cardRef}
      tabIndex={-1}
      onKeyDown={handleKeyDown}
      className="rounded-md border border-amber-200 border-l-4 border-l-amber-400 bg-amber-50/40 overflow-hidden focus:outline-none"
    >
      {/* Header chips / tabs */}
      {questions.length > 1 && (
        <div className="flex items-center gap-1 px-2 pt-2 flex-wrap">
          {questions.map((q, i) => {
            const answered = isAnswered(drafts[i]);
            return (
              <button
                key={i}
                type="button"
                onClick={() => setActiveIndex(i)}
                className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium border transition-colors ${
                  i === activeIndex
                    ? "bg-amber-200 border-amber-400 text-amber-900"
                    : "bg-white border-amber-200 text-amber-700 hover:bg-amber-100"
                }`}
              >
                {q.header}
                {answered && <span className="text-green-600">✓</span>}
              </button>
            );
          })}
        </div>
      )}

      <div className="px-3 py-3">
        <p className="text-sm font-medium text-gray-800">{active.question}</p>
        {active.multiSelect && (
          <p className="text-[11px] text-gray-500 mt-0.5">Select all that apply</p>
        )}

        <div className="mt-2 space-y-1.5">
          {active.options.map((opt, i) => {
            const checked = activeDraft.selected.has(opt.label);
            return (
              <label
                key={opt.label}
                className="flex items-start gap-2 rounded px-2 py-1.5 hover:bg-amber-100/50 cursor-pointer"
              >
                <input
                  type={active.multiSelect ? "checkbox" : "radio"}
                  name={`ask-user-${activeIndex}`}
                  checked={checked}
                  onChange={() =>
                    active.multiSelect ? toggleMulti(opt.label) : selectSingle(opt.label)
                  }
                  className="mt-0.5 h-3.5 w-3.5 text-amber-600 focus:ring-amber-500"
                />
                <span className="flex-1 min-w-0">
                  <span className="text-sm text-gray-800">
                    {i < 9 && <span className="text-gray-400 mr-1">{i + 1}.</span>}
                    {opt.label}
                  </span>
                  {opt.recommended && (
                    <span className="ml-1.5 inline-flex items-center rounded-full bg-amber-100 border border-amber-300 px-1.5 py-0.5 text-[10px] font-medium text-amber-700">
                      ★ Recommended
                    </span>
                  )}
                  {opt.description && (
                    <p className="text-xs text-gray-500 mt-0.5">{opt.description}</p>
                  )}
                </span>
              </label>
            );
          })}

          {/* Other */}
          <div className="flex items-center gap-2 rounded px-2 py-1.5">
            <span className="text-sm text-gray-500 shrink-0">Other:</span>
            <input
              type="text"
              value={activeDraft.otherText}
              onChange={(e) => updateActiveDraft({ otherText: e.target.value })}
              placeholder="Type a free answer…"
              className="flex-1 min-w-0 rounded border border-gray-300 px-2 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500 focus:border-amber-500"
            />
          </div>
        </div>

        <div className="flex items-center justify-between mt-3">
          <button
            type="button"
            onClick={skipActive}
            className="text-xs text-gray-400 hover:text-gray-600"
          >
            Skip
          </button>
          {isLast ? (
            <button
              type="button"
              onClick={handleSubmit}
              disabled={!allAnswered}
              className="rounded-md bg-amber-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-amber-700 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Submit
            </button>
          ) : (
            <button
              type="button"
              onClick={advance}
              disabled={!isAnswered(activeDraft)}
              className="rounded-md bg-amber-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-amber-700 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Next →
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
