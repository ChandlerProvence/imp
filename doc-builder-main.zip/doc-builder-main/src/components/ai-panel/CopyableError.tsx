import { useState } from "react";

/** Inline error with a copy-to-clipboard button (short errors, parse failures). */
export default function CopyableError({
  message,
  variant = "error",
  copyText,
  hint,
}: {
  message: string;
  variant?: "error" | "warning";
  /** Text copied to the clipboard. Defaults to `message`. */
  copyText?: string;
  /** Hover text. Defaults to `message`. */
  hint?: string;
}) {
  const [copied, setCopied] = useState(false);
  const color = variant === "error" ? "text-red-500" : "text-amber-600";
  const icon = variant === "error" ? "✗" : "⚠";

  const handleCopy = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    navigator.clipboard.writeText(copyText ?? message).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    });
  };

  return (
    <span className={`${color} text-xs flex items-center gap-1 min-w-0`}>
      <span className="truncate max-w-[160px]" title={hint ?? message}>{icon} {message}</span>
      <button
        type="button"
        onClick={handleCopy}
        className="flex-shrink-0 p-0.5 rounded hover:bg-gray-200 transition-colors"
        title="Copy error to clipboard"
      >
        {copied ? (
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" className="w-3 h-3 text-green-600">
            <path fillRule="evenodd" d="M12.416 3.376a.75.75 0 0 1 .208 1.04l-5 7.5a.75.75 0 0 1-1.154.114l-3-3a.75.75 0 0 1 1.06-1.06l2.353 2.353 4.493-6.74a.75.75 0 0 1 1.04-.207Z" clipRule="evenodd" />
          </svg>
        ) : (
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" className="w-3 h-3">
            <path d="M5.5 3.5A1.5 1.5 0 0 1 7 2h2.879a1.5 1.5 0 0 1 1.06.44l2.122 2.12a1.5 1.5 0 0 1 .439 1.061V9.5A1.5 1.5 0 0 1 12 11V3.5H5.5Z" />
            <path d="M3.5 5.5A1.5 1.5 0 0 1 5 4h3.379a1.5 1.5 0 0 1 1.06.44l2.122 2.12a1.5 1.5 0 0 1 .439 1.061V11.5A1.5 1.5 0 0 1 10.5 13H5a1.5 1.5 0 0 1-1.5-1.5v-6Z" />
          </svg>
        )}
      </button>
    </span>
  );
}
