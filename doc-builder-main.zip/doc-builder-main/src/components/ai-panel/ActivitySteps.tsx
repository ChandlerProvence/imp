import type { ResponseStep, ResponseTimings } from "../../ai/types";

// ---------------------------------------------------------------------------
// Shared helpers
// ---------------------------------------------------------------------------

function formatDuration(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  return `${(ms / 1000).toFixed(1)}s`;
}

const STEP_LABELS: Record<string, string> = {
  thinking: "Reasoning",
  generating: "Generating",
  searching: "Searching references",
  tool_processing: "Processing tools",
};

const ACTIVE_LABELS: Record<string, string> = {
  thinking: "Reasoning…",
  generating: "Generating…",
  searching: "Searching references…",
  tool_processing: "Processing tools…",
};

// ---------------------------------------------------------------------------
// Single step row
// ---------------------------------------------------------------------------

/** Build the display text for a completed step. Uses label if available, falls back to generic. */
function stepDisplayText(step: ResponseStep): string {
  if (step.label) {
    if (step.kind === "searching") {
      const truncated = step.label.length > 40 ? step.label.slice(0, 37) + "…" : step.label;
      return `Searched "${truncated}"`;
    }
    // tool_processing or others with a label use the label directly
    return step.label;
  }
  return STEP_LABELS[step.kind] ?? step.kind;
}

function StepRow({ step }: { step: ResponseStep }) {
  return (
    <div className="flex items-center gap-2 text-xs text-gray-400 py-0.5">
      <span className="text-green-500 text-[10px]">✓</span>
      <span className="flex-1 truncate">{stepDisplayText(step)}</span>
      <span className="tabular-nums shrink-0">{formatDuration(step.durationMs)}</span>
    </div>
  );
}

function ActiveStepRow({ kind }: { kind: ResponseStep["kind"] }) {
  return (
    <div className="flex items-center gap-2 text-xs text-gray-500 py-0.5">
      <span className="inline-block w-2.5 h-2.5 border-[1.5px] border-blue-500 border-t-transparent rounded-full animate-spin" />
      <span className="flex-1">{ACTIVE_LABELS[kind] ?? kind}</span>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Live mode — shown during streaming, above the streaming bubble
// ---------------------------------------------------------------------------

interface LiveProps {
  completedSteps: ResponseStep[];
  activeStepKind: ResponseStep["kind"] | null;
}

export function LiveActivitySteps({ completedSteps, activeStepKind }: LiveProps) {
  if (completedSteps.length === 0 && !activeStepKind) return null;

  return (
    <div className="px-3 py-1 select-none">
      {completedSteps.map((step, i) => (
        <StepRow key={i} step={step} />
      ))}
      {activeStepKind && <ActiveStepRow kind={activeStepKind} />}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Static mode — shown on completed messages (from persisted timings)
// ---------------------------------------------------------------------------

interface StaticStepsProps {
  timings: ResponseTimings;
}

/** Renders the step rows above the assistant message (for restored conversations). */
export function StaticStepsBeforeMessage({ timings }: StaticStepsProps) {
  if (timings.steps.length === 0) return null;

  return (
    <div className="px-3 py-1 select-none">
      {timings.steps.map((step, i) => (
        <StepRow key={i} step={step} />
      ))}
    </div>
  );
}

/** Format a token count as a compact "85k" / "1.2M" string. */
function formatTokens(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${Math.round(n / 1_000)}k`;
  return `${n}`;
}

/** Renders just the total duration below the final assistant message. */
export function StaticTotalAfterMessage({ timings }: StaticStepsProps) {
  if (timings.totalMs == null) return null;

  const ctx = timings.usage?.promptTokens;

  return (
    <div className="px-3 mt-1 text-[11px] text-gray-400 tabular-nums select-none">
      Total {formatDuration(timings.totalMs)}
      {ctx != null && ctx > 0 && ` · ${formatTokens(ctx)} ctx`}
    </div>
  );
}
