import { describe, it, expect, vi, beforeEach } from "vitest";
import { screen, fireEvent } from "@testing-library/react";
import { renderWithProviders } from "../../test/renderWithProviders";
import AiPanel from "./AiPanel";

const panel = { panelOpen: true, setPanelOpen: vi.fn(), togglePanel: vi.fn() };

vi.mock("../../context/AiPanelContext", () => ({
  useAiPanelContext: () => ({
    ...panel,
    proposedChanges: [],
    detectedObservations: [],
    docManager: { showDocPicker: false },
    styleReference: { status: "idle" },
    hasActiveSession: false,
    scope: { type: "document" },
    activeTab: "chat",
    setActiveTab: vi.fn(),
  }),
}));
vi.mock("../EndpointBadge", () => ({ default: () => null }));
vi.mock("./AiPanelChat", () => ({ default: () => <div data-testid="ai-panel-chat" /> }));
vi.mock("../bulk-edit/ConversationDropdown", () => ({ default: () => <div data-testid="conversation-dropdown" /> }));

const generalChat = { enabled: true };
vi.mock("../../ai/generalChat", async (importOriginal) => {
  const actual = await importOriginal<typeof import("../../ai/generalChat")>();
  return {
    ...actual,
    get GENERAL_CHAT_ENABLED() {
      return generalChat.enabled;
    },
  };
});

beforeEach(() => {
  panel.panelOpen = true;
  panel.setPanelOpen.mockClear();
  generalChat.enabled = true;
});

describe("AiPanel", () => {
  it("shows the open panel on other pages", () => {
    renderWithProviders(<AiPanel />, { routerEntries: ["/"] });
    expect(screen.getByTitle("Collapse AI Assistant")).toBeInTheDocument();
  });

  const noSession = { sessionContext: { session: null, schema: null } };

  it("offers a general chat with a conversation switcher when no document is open", () => {
    renderWithProviders(<AiPanel />, { routerEntries: ["/"], ...noSession });
    expect(screen.getByTestId("ai-panel-chat")).toBeInTheDocument();
    expect(screen.getByTestId("conversation-dropdown")).toBeInTheDocument();
    expect(screen.queryByText(/Start a document/)).not.toBeInTheDocument();
  });

  it("falls back to the placeholder when general chat is disabled", () => {
    generalChat.enabled = false;
    renderWithProviders(<AiPanel />, { routerEntries: ["/"], ...noSession });
    expect(screen.getByText(/Start a document/)).toBeInTheDocument();
    expect(screen.queryByTestId("ai-panel-chat")).not.toBeInTheDocument();
    expect(screen.queryByTestId("conversation-dropdown")).not.toBeInTheDocument();
  });

  it("starts as its strip on the template editor, and opens there on request", () => {
    renderWithProviders(<AiPanel />, { routerEntries: ["/templates/edit/custom-x"] });
    const strip = screen.getByTitle("Open AI Assistant");
    expect(screen.queryByTitle("Collapse AI Assistant")).not.toBeInTheDocument();

    fireEvent.click(strip);
    expect(panel.setPanelOpen).toHaveBeenCalledWith(true);
    expect(screen.getByTitle("Collapse AI Assistant")).toBeInTheDocument();
  });
});
