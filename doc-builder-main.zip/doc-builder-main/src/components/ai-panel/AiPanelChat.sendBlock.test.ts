import { describe, expect, it } from "vitest";
import { sendBlock } from "./AiPanelChat";

const ready = { docsReady: true, docsProcessingStatus: null, hasAttachedDocs: true, styleStatus: "idle" as const };

describe("sendBlock", () => {
  it("allows sending when nothing is processing", () => {
    expect(sendBlock(ready)).toEqual({ blocked: false, status: null });
  });

  it("blocks while attached documents are processed, with their status", () => {
    expect(sendBlock({ ...ready, docsReady: false, docsProcessingStatus: "Embedding documents…" })).toEqual({
      blocked: true,
      status: "Embedding documents…",
    });
  });

  it("blocks while the drafting style is being extracted", () => {
    expect(sendBlock({ ...ready, styleStatus: "deriving" })).toEqual({
      blocked: true,
      status: "Analyzing writing style…",
    });
  });

  it("does not block after a style analysis fails or finishes", () => {
    expect(sendBlock({ ...ready, styleStatus: "error" }).blocked).toBe(false);
    expect(sendBlock({ ...ready, styleStatus: "done" }).blocked).toBe(false);
  });
});
