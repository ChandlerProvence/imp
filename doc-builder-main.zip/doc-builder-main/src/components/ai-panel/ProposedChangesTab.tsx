import type { ProposedChange } from "../../ai/bulkEdit";
import type { DetectedObservation } from "../../ai/observationTypes";
import FieldChangeCard from "../bulk-edit/FieldChangeCard";

interface Props {
  changes: ProposedChange[];
  onToggleChange: (index: number) => void;
  onAcceptAll: () => void;
  onRejectAll: () => void;
  onApply: () => void;
  /** Current observations — used to show conflict badges on matching field cards. */
  observations?: DetectedObservation[];
  /** Called when a conflict badge is clicked on a field card. */
  onConflictClick?: () => void;
}

export default function ProposedChangesTab({
  changes,
  onToggleChange,
  onAcceptAll,
  onRejectAll,
  onApply,
  observations = [],
  onConflictClick,
}: Props) {
  // Build a set of field keys that have conflict observations
  const conflictFieldKeys = new Set(
    observations
      .filter((o) => o.type === "conflict" && o.fieldKey)
      .map((o) => o.fieldKey!),
  );
  const acceptedCount = changes.filter((c) => c.accepted).length;

  if (changes.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="text-center">
          <p className="text-sm text-gray-500 font-medium">No proposed changes</p>
          <p className="text-xs text-gray-400 mt-1 max-w-[200px]">
            Ask the AI to make edits and proposed changes will appear here
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col flex-1 min-h-0">
      {/* Sticky action bar */}
      <div className="flex items-center gap-2 px-3 py-2 border-b border-gray-100 shrink-0">
        <button
          type="button"
          onClick={onAcceptAll}
          className="text-xs text-gray-600 hover:text-gray-800 font-medium"
        >
          Select All
        </button>
        <span className="text-gray-300">|</span>
        <button
          type="button"
          onClick={onRejectAll}
          className="text-xs text-gray-600 hover:text-gray-800 font-medium"
        >
          Deselect All
        </button>
        <div className="flex-1" />
        <button
          type="button"
          onClick={onApply}
          disabled={acceptedCount === 0}
          className="rounded-md bg-blue-600 px-3 py-1 text-xs font-medium text-white hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          Apply {acceptedCount > 0 ? acceptedCount : ""}
        </button>
      </div>

      {/* Scrollable change list — full remaining height */}
      <div className="flex-1 overflow-y-auto px-3 py-3 space-y-2">
        {changes.map((change, idx) => (
          <FieldChangeCard
            key={`${change.fieldKey}-${idx}`}
            change={change}
            onToggle={() => onToggleChange(idx)}
            hasConflict={conflictFieldKeys.has(change.fieldKey)}
            onConflictClick={onConflictClick}
          />
        ))}
      </div>
    </div>
  );
}
