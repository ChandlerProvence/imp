import ErrorBox from "./ErrorBox";
import CopyableError from "./ai-panel/CopyableError";
import type { AppError } from "../errors";
import { buildDiagnosticsReport } from "../errors/formatDiagnostics";
import { collectDiagnosticsOptions } from "./diagnosticsOptions";

/** Text copied to the clipboard: the error summary + full diagnostics report. */
export function appErrorCopyText(error: AppError, opts?: { schemaId?: string }): string {
  const summary = [`${error.title} [${error.kind}]`, error.message, error.detail].filter(Boolean).join("\n");
  try {
    const report = buildDiagnosticsReport(collectDiagnosticsOptions(opts?.schemaId));
    return `${summary}\n\n${report}`;
  } catch {
    // If diagnostics fail (e.g. during startup), fall back to summary only
    return summary;
  }
}

/**
 * Renders an `AppError`. The single display component for normalized errors —
 * call sites never compose their own title or help text.
 *
 * - default: full `ErrorBox` (title, message, copyable detail, help)
 * - `compact`: one-line `CopyableError` for tight rows (file lists); the
 *   help text is in the hover tooltip and the full detail is copied.
 */
export default function AppErrorBox({
  error,
  compact = false,
  subject,
  className,
}: {
  error: AppError;
  compact?: boolean;
  /** What the error is about (e.g. a file name), appended to the title. */
  subject?: string;
  className?: string;
}) {
  if (compact) {
    return (
      <CopyableError
        message={error.message}
        hint={[error.message, error.help].filter(Boolean).join(" ")}
        copyText={appErrorCopyText(error)}
      />
    );
  }
  return (
    <ErrorBox
      title={subject ? `${error.title} — ${subject}` : error.title}
      message={error.message}
      detail={error.detail}
      copyText={appErrorCopyText(error)}
      helpText={error.help ?? undefined}
      className={className}
    />
  );
}
