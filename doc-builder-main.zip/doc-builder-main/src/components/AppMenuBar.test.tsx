import { describe, it, expect, vi, beforeEach } from "vitest";
import { screen, fireEvent, waitFor } from "@testing-library/react";
import AppMenuBar from "./AppMenuBar";
import { renderWithProviders } from "../test/renderWithProviders";
import { importSession, validateImportFile } from "../db/sessionExport";

type SessionExportFile = Parameters<typeof importSession>[0];

vi.mock("../db/sessionExport", () => ({
  validateImportFile: vi.fn(),
  importSession: vi.fn(),
  downloadSessionExport: vi.fn(() => Promise.resolve(true)),
}));

// Mock the schema imports
vi.mock("../schemas", () => ({
  useSchemaRegistry: () => ({
    list: [
      { id: "nda", title: "NDA", version: 1, sections: [], category: "legal" },
      { id: "fms-case", title: "FMS Case", version: 1, sections: [], category: "fms" },
    ],
    version: 0,
    hydrated: true,
  }),
  filterSchemasByRole: vi.fn((schemas: any[]) => schemas),
  groupSchemasByCategory: vi.fn((schemas: any[]) => [
    { category: { id: "fms", label: "Foreign Military Sales" }, schemas: schemas.filter((s) => s.category === "fms") },
    { category: { id: "legal", label: "Legal" }, schemas: schemas.filter((s) => s.category === "legal") },
  ]),
  groupSchemasBySet: vi.fn((schemas: any[]) =>
    schemas.some((s) => s.id === "fms-case")
      ? [{ set: "FMS Set", schemas }]
      : [{ set: null, schemas }],
  ),
}));

function hover(label: string) {
  fireEvent.mouseEnter(screen.getByText(label).closest("div")!);
}

// Mock SettingsDialog to avoid its internal dependencies
vi.mock("./SettingsDialog", () => ({
  default: ({ open }: { open: boolean }) =>
    open ? <div data-testid="settings-dialog">Settings</div> : null,
}));

describe("AppMenuBar", () => {
  it("renders File, Edit, View menus", () => {
    renderWithProviders(<AppMenuBar />);
    expect(screen.getByText("File")).toBeInTheDocument();
    expect(screen.getByText("Edit")).toBeInTheDocument();
    expect(screen.getByText("View")).toBeInTheDocument();
  });

  it("shows New Document submenu in File menu", () => {
    renderWithProviders(<AppMenuBar />);
    fireEvent.click(screen.getByText("File"));
    expect(screen.getByText("New Document")).toBeInTheDocument();
  });

  it("shows Clear Session in File menu", () => {
    renderWithProviders(<AppMenuBar />);
    fireEvent.click(screen.getByText("File"));
    expect(screen.getByText("Clear Session")).toBeInTheDocument();
  });

  it("calls deleteCurrentSession when Clear Session clicked", () => {
    const { sessionContext } = renderWithProviders(<AppMenuBar />);
    fireEvent.click(screen.getByText("File"));
    fireEvent.click(screen.getByText("Clear Session"));
    expect(sessionContext.deleteCurrentSession).toHaveBeenCalledOnce();
  });

  it("calls clearAnswers when Clear All Answers clicked", () => {
    const { sessionContext } = renderWithProviders(<AppMenuBar />);
    fireEvent.click(screen.getByText("Edit"));
    fireEvent.click(screen.getByText("Clear All Answers"));
    expect(sessionContext.clearAnswers).toHaveBeenCalledOnce();
  });

  it("opens Settings dialog", () => {
    renderWithProviders(<AppMenuBar />);
    fireEvent.click(screen.getByText("Edit"));
    fireEvent.click(screen.getByText("Settings…"));
    expect(screen.getByTestId("settings-dialog")).toBeInTheDocument();
  });

  it("copies a diagnostics report from View → Copy Diagnostics", () => {
    const writeText = vi.fn().mockResolvedValue(undefined);
    Object.assign(navigator, { clipboard: { writeText } });
    renderWithProviders(<AppMenuBar />);
    fireEvent.click(screen.getByText("View"));
    fireEvent.click(screen.getByText("Copy Diagnostics"));
    expect(writeText).toHaveBeenCalledTimes(1);
    expect(writeText.mock.calls[0][0]).toContain("doc-builder-diagnostics");
  });

  it("starts session directly when no existing answers", () => {
    const { sessionContext } = renderWithProviders(<AppMenuBar />, {
      sessionContext: { session: null, answers: {} },
    });
    fireEvent.click(screen.getByText("File"));
    hover("New Document");
    hover("Legal");
    fireEvent.click(screen.getByText("NDA"));
    expect(sessionContext.startSession).toHaveBeenCalledWith("nda");
  });

  it("groups New Document by category, then by set", () => {
    renderWithProviders(<AppMenuBar />);
    fireEvent.click(screen.getByText("File"));
    hover("New Document");
    expect(screen.getByText("Foreign Military Sales")).toBeInTheDocument();
    expect(screen.getByText("Legal")).toBeInTheDocument();
    // Schemas stay hidden until their category is opened
    expect(screen.queryByText("NDA")).not.toBeInTheDocument();

    hover("Foreign Military Sales");
    expect(screen.getByText("FMS Set")).toBeInTheDocument();
    expect(screen.queryByText("FMS Case")).not.toBeInTheDocument();
    hover("FMS Set");
    expect(screen.getByText("FMS Case")).toBeInTheDocument();
  });

  it("starts a set session from Generate full set", () => {
    const { sessionContext } = renderWithProviders(<AppMenuBar />, {
      sessionContext: { session: null, answers: {} },
    });
    fireEvent.click(screen.getByText("File"));
    hover("New Document");
    hover("Foreign Military Sales");
    hover("FMS Set");
    fireEvent.click(screen.getByText("Generate full set (1)"));
    expect(sessionContext.startSetSession).toHaveBeenCalledWith("FMS Set");
    expect(sessionContext.startSession).not.toHaveBeenCalled();
  });
});

describe("AppMenuBar Load Progress import", () => {
  const exportData = { _type: "doc-builder-session-export" } as unknown as SessionExportFile;

  function selectFile(container: HTMLElement, content: string) {
    const input = container.querySelector('input[type="file"][accept=".json"]') as HTMLInputElement;
    const file = new File([content], "s.json", { type: "application/json" });
    fireEvent.change(input, { target: { files: [file] } });
  }

  function withWarnings(warnings: string[]) {
    vi.mocked(validateImportFile).mockResolvedValue({ valid: true, data: exportData, errors: [], warnings });
  }

  beforeEach(() => {
    vi.mocked(validateImportFile).mockReset();
    vi.mocked(importSession).mockReset();
    vi.mocked(importSession).mockResolvedValue({ sessionId: "imported-1", warnings: [] });
  });

  it("shows an error for invalid JSON", async () => {
    const { container } = renderWithProviders(<AppMenuBar />);
    selectFile(container, "{not json");
    expect(await screen.findByText("The selected file is not valid JSON.")).toBeInTheDocument();
    expect(screen.getByText("Import Error")).toBeInTheDocument();
    expect(validateImportFile).not.toHaveBeenCalled();
  });

  it("shows validation errors", async () => {
    vi.mocked(validateImportFile).mockResolvedValue({ valid: false, errors: ["Bad type.", "No session."], warnings: [] });
    const { container } = renderWithProviders(<AppMenuBar />);
    selectFile(container, "{}");
    expect(await screen.findByText("Bad type. No session.")).toBeInTheDocument();
    expect(importSession).not.toHaveBeenCalled();
  });

  it("confirms warnings, then imports and resumes", async () => {
    withWarnings(["Schema version changed."]);
    const { container, sessionContext } = renderWithProviders(<AppMenuBar />);
    selectFile(container, "{}");

    expect(await screen.findByText("Import Warning")).toBeInTheDocument();
    expect(screen.getByText(/Schema version changed\./)).toBeInTheDocument();
    expect(importSession).not.toHaveBeenCalled();

    fireEvent.click(screen.getByRole("button", { name: "Import Anyway" }));
    await waitFor(() => expect(sessionContext.resumeSession).toHaveBeenCalledWith("imported-1"));
    expect(importSession).toHaveBeenCalledWith(exportData);
    expect(screen.queryByText("Import Warning")).not.toBeInTheDocument();
  });

  it("cancelling the warning does not import", async () => {
    withWarnings(["Schema version changed."]);
    const { container, sessionContext } = renderWithProviders(<AppMenuBar />);
    selectFile(container, "{}");

    expect(await screen.findByText("Import Warning")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Cancel" }));
    await waitFor(() => expect(screen.queryByText("Import Warning")).not.toBeInTheDocument());
    expect(importSession).not.toHaveBeenCalled();
    expect(sessionContext.resumeSession).not.toHaveBeenCalled();
  });

  it("imports a clean file and resumes directly", async () => {
    withWarnings([]);
    const { container, sessionContext } = renderWithProviders(<AppMenuBar />);
    selectFile(container, JSON.stringify({ a: 1 }));

    await waitFor(() => expect(sessionContext.resumeSession).toHaveBeenCalledWith("imported-1"));
    expect(validateImportFile).toHaveBeenCalledWith({ a: 1 });
    expect(importSession).toHaveBeenCalledWith(exportData);
    expect(vi.mocked(importSession).mock.invocationCallOrder[0]).toBeLessThan(
      vi.mocked(sessionContext.resumeSession).mock.invocationCallOrder[0],
    );
  });

  it("shows the import failure message when importSession throws", async () => {
    withWarnings([]);
    vi.mocked(importSession).mockRejectedValue(new Error("Quota exceeded"));
    const { container, sessionContext } = renderWithProviders(<AppMenuBar />);
    selectFile(container, "{}");
    expect(await screen.findByText("Quota exceeded")).toBeInTheDocument();
    expect(sessionContext.resumeSession).not.toHaveBeenCalled();
  });
});
