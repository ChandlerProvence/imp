import { afterEach, beforeEach, describe, expect, it, vi, type MockInstance } from "vitest";
import { fireEvent, render, screen } from "@testing-library/react";

vi.mock("../db/resetDatabase", () => ({ clearDataAndReload: vi.fn() }));
vi.mock("./CopyDiagnosticsButton", () => ({
  default: () => <button>Copy diagnostics</button>,
}));

import ErrorBoundary from "./ErrorBoundary";
import { clearDataAndReload } from "../db/resetDatabase";
import { getRecentErrors } from "../errors";

function Boom({ message = "kaboom-42" }: { message?: string }): never {
  throw new Error(message);
}

describe("ErrorBoundary", () => {
  let errorSpy: MockInstance;

  beforeEach(() => {
    errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});
    vi.mocked(clearDataAndReload).mockClear();
  });

  afterEach(() => {
    errorSpy.mockRestore();
    vi.unstubAllGlobals();
  });

  it("renders children when nothing throws", () => {
    render(
      <ErrorBoundary>
        <p>all good</p>
      </ErrorBoundary>,
    );
    expect(screen.getByText("all good")).toBeInTheDocument();
    expect(screen.queryByText("Something went wrong")).not.toBeInTheDocument();
  });

  it("renders the fallback with the error message and actions", () => {
    render(
      <ErrorBoundary>
        <Boom />
      </ErrorBoundary>,
    );
    expect(screen.getByRole("heading", { name: "Something went wrong" })).toBeInTheDocument();
    expect(screen.getByText(/An unexpected error occurred/)).toBeInTheDocument();
    expect(screen.getByText("kaboom-42")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Reload" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Copy diagnostics" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Clear data & reload" })).toBeInTheDocument();
  });

  it("logs and records the caught error", () => {
    render(
      <ErrorBoundary>
        <Boom message="recorded-err-77" />
      </ErrorBoundary>,
    );
    expect(errorSpy).toHaveBeenCalledWith(
      "[ErrorBoundary] Uncaught error:",
      expect.objectContaining({ message: "recorded-err-77" }),
      expect.anything(),
    );
    expect(getRecentErrors().some((e) => e.detail.includes("recorded-err-77"))).toBe(true);
  });

  it("Reload calls window.location.reload", () => {
    const reload = vi.fn();
    vi.stubGlobal("location", { ...window.location, reload });
    render(
      <ErrorBoundary>
        <Boom />
      </ErrorBoundary>,
    );
    fireEvent.click(screen.getByRole("button", { name: "Reload" }));
    expect(reload).toHaveBeenCalledTimes(1);
    expect(clearDataAndReload).not.toHaveBeenCalled();
  });

  it("Clear data & reload calls clearDataAndReload", () => {
    render(
      <ErrorBoundary>
        <Boom />
      </ErrorBoundary>,
    );
    fireEvent.click(screen.getByRole("button", { name: "Clear data & reload" }));
    expect(clearDataAndReload).toHaveBeenCalledTimes(1);
  });
});
