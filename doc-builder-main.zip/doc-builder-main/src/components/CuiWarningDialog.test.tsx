import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import CuiWarningDialog from "./CuiWarningDialog";
import type { UploadedDocument } from "../db/types";

function makeDoc(overrides: Partial<UploadedDocument> = {}): UploadedDocument {
  return {
    id: "doc-1",
    fileName: "contract.pdf",
    mimeType: "application/pdf",
    fileSize: 1000,
    textContent: "CUI content",
    charCount: 1000,
    category: "fms",
    cuiStatus: "flagged",
    cuiDetection: { isCui: true, confidence: "high", reason: "CUI marking found", method: "regex", markers: ["CUI"] },
    createdAt: new Date().toISOString(),
    lastUsedAt: new Date().toISOString(),
    ...overrides,
  };
}

describe("CuiWarningDialog", () => {
  const defaultProps = {
    open: true,
    flaggedDocs: [makeDoc()],
    cuiKeyConfigured: true,
    onCancel: vi.fn(),
    onAffirmNotCui: vi.fn(),
    onSwitchToCui: vi.fn(),
  };

  it("does not render when open is false", () => {
    render(<CuiWarningDialog {...defaultProps} open={false} />);
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  });

  it("does not render when there are no flagged docs", () => {
    render(<CuiWarningDialog {...defaultProps} flaggedDocs={[]} />);
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  });

  it("lists the flagged document and its detection markers", () => {
    render(<CuiWarningDialog {...defaultProps} />);
    expect(screen.getByText("contract.pdf")).toBeInTheDocument();
    expect(screen.getByText(/Detected: CUI/)).toBeInTheDocument();
  });

  it("Cancel calls onCancel", () => {
    const onCancel = vi.fn();
    render(<CuiWarningDialog {...defaultProps} onCancel={onCancel} />);
    fireEvent.click(screen.getByText("Cancel"));
    expect(onCancel).toHaveBeenCalledOnce();
  });

  it("These Are Not CUI — Attach calls onAffirmNotCui", () => {
    const onAffirmNotCui = vi.fn();
    render(<CuiWarningDialog {...defaultProps} onAffirmNotCui={onAffirmNotCui} />);
    fireEvent.click(screen.getByText("These Are Not CUI — Attach"));
    expect(onAffirmNotCui).toHaveBeenCalledOnce();
  });

  it("Switch to CUI Mode & Attach calls onSwitchToCui when a key is configured", () => {
    const onSwitchToCui = vi.fn();
    render(<CuiWarningDialog {...defaultProps} onSwitchToCui={onSwitchToCui} />);
    fireEvent.click(screen.getByText("Switch to CUI Mode & Attach"));
    expect(onSwitchToCui).toHaveBeenCalledOnce();
  });

  it("disables Switch to CUI Mode when no CUI key is configured", () => {
    render(<CuiWarningDialog {...defaultProps} cuiKeyConfigured={false} />);
    expect(screen.getByText("Switch to CUI Mode & Attach")).toBeDisabled();
  });

  it("focuses Switch to CUI Mode on open when a key is configured", () => {
    render(<CuiWarningDialog {...defaultProps} />);
    expect(screen.getByText("Switch to CUI Mode & Attach")).toHaveFocus();
    expect(screen.getByText("These Are Not CUI — Attach")).not.toHaveFocus();
  });

  it("focuses Cancel and offers Settings when no CUI key is configured", () => {
    const onOpenSettings = vi.fn();
    render(<CuiWarningDialog {...defaultProps} cuiKeyConfigured={false} onOpenSettings={onOpenSettings} />);
    expect(screen.getByText("Cancel")).toHaveFocus();
    expect(screen.getByText(/Add a CUI API key in Settings/)).toBeInTheDocument();
    fireEvent.click(screen.getByText("Open Settings →"));
    expect(onOpenSettings).toHaveBeenCalledOnce();
  });

  it("Escape calls onCancel", () => {
    const onCancel = vi.fn();
    render(<CuiWarningDialog {...defaultProps} onCancel={onCancel} />);
    fireEvent.keyDown(document, { key: "Escape" });
    expect(onCancel).toHaveBeenCalledOnce();
  });

  it("shows the full scan-error message in a copyable error box", () => {
    const errored = makeDoc({
      id: "doc-2",
      fileName: "errored.pdf",
      cuiStatus: "scan-error",
      cuiDetection: undefined,
      cuiScanError: "AI CUI scan failed: 503 Service Unavailable",
    });
    render(<CuiWarningDialog {...defaultProps} flaggedDocs={[errored]} />);
    expect(screen.getByText("AI CUI scan failed: 503 Service Unavailable")).toBeInTheDocument();
  });

  it("shows quarantine note when flagged doc has quarantined images", () => {
    const quarantined = makeDoc({
      quarantinedImages: [
        { placeholder: "[Image quarantined — pending CUI confirmation (IMAGE_0)]", dataUrl: "data:image/png;base64,abc" },
        { placeholder: "[Image quarantined — pending CUI confirmation (IMAGE_1)]", dataUrl: "data:image/png;base64,def" },
      ],
    });
    render(<CuiWarningDialog {...defaultProps} flaggedDocs={[quarantined]} />);
    expect(screen.getByText(/2 images quarantined/)).toBeInTheDocument();
    expect(screen.getByText(/converted after you choose/)).toBeInTheDocument();
  });

  it("shows singular quarantine note for a single image", () => {
    const quarantined = makeDoc({
      quarantinedImages: [
        { placeholder: "[Image quarantined — pending CUI confirmation (IMAGE_0)]", dataUrl: "data:image/png;base64,abc" },
      ],
    });
    render(<CuiWarningDialog {...defaultProps} flaggedDocs={[quarantined]} />);
    expect(screen.getByText(/1 image quarantined/)).toBeInTheDocument();
  });
});
