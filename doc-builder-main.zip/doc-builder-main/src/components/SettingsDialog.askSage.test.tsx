import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { AiConfigProvider } from "../context/AiConfigContext";
import { AskSageProvider } from "../context/AskSageContext";
import { UserPreferencesProvider } from "../context/UserPreferencesContext";
import SettingsDialog from "./SettingsDialog";
import { ASKSAGE_API_KEY_KEY, ASKSAGE_EMAIL_KEY } from "../ai/asksage";
import { setFeatureFlags } from "../ai/featureFlags";
import { _resetModelsForTests } from "../ai/models";

function renderSettings() {
  return render(
    <MemoryRouter>
      <UserPreferencesProvider>
        <AiConfigProvider>
          <AskSageProvider>
            <SettingsDialog open onClose={() => {}} />
          </AskSageProvider>
        </AiConfigProvider>
      </UserPreferencesProvider>
    </MemoryRouter>,
  );
}

beforeEach(() => {
  _resetModelsForTests();
  vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new TypeError("Failed to fetch")));
});

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("Settings → AskSage gate", () => {
  it("hides the AskSage section while the askSage flag is off (the default)", () => {
    renderSettings();
    expect(screen.queryByText("AskSage (SharePoint)")).not.toBeInTheDocument();
    expect(screen.queryByLabelText("AskSage email")).not.toBeInTheDocument();
  });

  it("keeps stored AskSage credentials when Settings is saved with the section hidden", () => {
    localStorage.setItem(ASKSAGE_EMAIL_KEY, "user@leidos.com");
    localStorage.setItem(ASKSAGE_API_KEY_KEY, "saved-key");
    renderSettings();
    fireEvent.click(screen.getByRole("button", { name: "Save" }));
    expect(localStorage.getItem(ASKSAGE_EMAIL_KEY)).toBe("user@leidos.com");
    expect(localStorage.getItem(ASKSAGE_API_KEY_KEY)).toBe("saved-key");
  });

  it("shows the AskSage section when the flag is on", () => {
    setFeatureFlags({ askSage: true });
    renderSettings();
    expect(screen.getByText("AskSage (SharePoint)")).toBeInTheDocument();
    expect(screen.getByLabelText("AskSage email")).toBeInTheDocument();
  });
});
