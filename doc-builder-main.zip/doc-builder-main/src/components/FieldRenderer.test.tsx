import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import FieldRenderer from "./FieldRenderer";
import type { FieldDef } from "../schemas/types";
import type { FieldMeta } from "../db/types";

// Mock TableFieldRenderer to avoid pulling in its full tree
vi.mock("./TableFieldRenderer", () => ({
  default: ({ fieldKey }: { fieldKey: string }) => (
    <div data-testid={`table-${fieldKey}`}>TableFieldRenderer</div>
  ),
}));

const baseProps = {
  fieldKey: "section.field",
  value: undefined as string | number | boolean | undefined,
  onChange: vi.fn(),
};

function getInput(): HTMLInputElement {
  return document.getElementById("section.field") as HTMLInputElement;
}

describe("FieldRenderer", () => {
  describe("string field", () => {
    const field: FieldDef = { id: "name", label: "Name", type: "string", required: false };

    it("renders a text input with correct id", () => {
      render(<FieldRenderer {...baseProps} field={field} />);
      const input = getInput();
      expect(input).toBeInTheDocument();
      expect(input.type).toBe("text");
    });

    it("displays the label", () => {
      render(<FieldRenderer {...baseProps} field={field} />);
      expect(screen.getByLabelText("Name")).toBeInTheDocument();
    });

    it("calls onChange on input", () => {
      const onChange = vi.fn();
      render(<FieldRenderer {...baseProps} field={field} onChange={onChange} />);
      fireEvent.change(getInput(), { target: { value: "hello" } });
      expect(onChange).toHaveBeenCalledWith("section.field", "hello");
    });
  });

  describe("number field", () => {
    const field: FieldDef = { id: "count", label: "Count", type: "number", required: false };

    it("renders a decimal text box (not a native number input)", () => {
      render(<FieldRenderer {...baseProps} field={field} />);
      expect(getInput().type).toBe("text");
      expect(getInput()).toHaveAttribute("inputmode", "decimal");
    });

    it("parses thousands separators and dollar signs", () => {
      const onChange = vi.fn();
      render(<FieldRenderer {...baseProps} field={field} onChange={onChange} />);
      fireEvent.change(getInput(), { target: { value: "$1,234.50" } });
      expect(onChange).toHaveBeenCalledWith("section.field", 1234.5);
    });

    it("passes text that isn't a number through for validation to flag", () => {
      const onChange = vi.fn();
      render(<FieldRenderer {...baseProps} field={field} onChange={onChange} />);
      fireEvent.change(getInput(), { target: { value: "1234,5" } });
      expect(onChange).toHaveBeenCalledWith("section.field", "1234,5");
    });

    it("shows currency values formatted", () => {
      render(<FieldRenderer {...baseProps} field={{ ...field, format: "currency" }} value={50000} />);
      expect(getInput().value).toBe("50,000.00");
    });

    it("calls onChange with numeric value", () => {
      const onChange = vi.fn();
      render(<FieldRenderer {...baseProps} field={field} onChange={onChange} />);
      fireEvent.change(getInput(), { target: { value: "42" } });
      expect(onChange).toHaveBeenCalledWith("section.field", 42);
    });
  });

  describe("boolean field", () => {
    const field: FieldDef = { id: "active", label: "Active", type: "boolean", required: false };

    it("renders a checkbox", () => {
      render(<FieldRenderer {...baseProps} field={field} />);
      expect(getInput().type).toBe("checkbox");
    });

    it("calls onChange with checked state", () => {
      const onChange = vi.fn();
      render(<FieldRenderer {...baseProps} field={field} onChange={onChange} />);
      fireEvent.click(getInput());
      expect(onChange).toHaveBeenCalledWith("section.field", true);
    });
  });

  describe("date field", () => {
    const field: FieldDef = { id: "due", label: "Due Date", type: "date", required: false };

    it("renders with type=date attribute", () => {
      render(<FieldRenderer {...baseProps} field={field} />);
      // jsdom may report type as "text" but the attribute should be "date"
      expect(getInput().getAttribute("type")).toBe("date");
    });
  });

  describe("enum field", () => {
    const field: FieldDef = {
      id: "status",
      label: "Status",
      type: "enum",
      required: false,
      options: ["Draft", "Final", "Archived"],
    };

    it("renders a select with options", () => {
      render(<FieldRenderer {...baseProps} field={field} />);
      const select = document.getElementById("section.field") as HTMLSelectElement;
      expect(select.tagName).toBe("SELECT");
      expect(screen.getByText("Draft")).toBeInTheDocument();
      expect(screen.getByText("Final")).toBeInTheDocument();
      expect(screen.getByText("Archived")).toBeInTheDocument();
    });

    it("includes a placeholder option", () => {
      render(<FieldRenderer {...baseProps} field={field} />);
      expect(screen.getByText("— Select —")).toBeInTheDocument();
    });
  });

  describe("freetext field", () => {
    const field: FieldDef = { id: "desc", label: "Description", type: "freetext", required: false };

    it("renders a textarea", () => {
      render(<FieldRenderer {...baseProps} field={field} />);
      const textarea = document.getElementById("section.field") as HTMLTextAreaElement;
      expect(textarea.tagName).toBe("TEXTAREA");
    });

    it("shows AI Draft Field button when onOpenChat is provided", () => {
      render(<FieldRenderer {...baseProps} field={field} onOpenChat={vi.fn()} />);
      expect(screen.getByTitle("Focus AI on this field")).toBeInTheDocument();
    });

    it("does not show AI Draft Field when onOpenChat is not provided", () => {
      render(<FieldRenderer {...baseProps} field={field} />);
      expect(screen.queryByTitle("Focus AI on this field")).not.toBeInTheDocument();
    });

    it("calls onOpenChat with fieldKey when AI Draft Field is clicked", () => {
      const onOpenChat = vi.fn();
      render(<FieldRenderer {...baseProps} field={field} onOpenChat={onOpenChat} />);
      fireEvent.click(screen.getByTitle("Focus AI on this field"));
      expect(onOpenChat).toHaveBeenCalledWith("section.field");
    });

    it("shows ai_hint when field has one", () => {
      const fieldWithHint: FieldDef = { ...field, ai_hint: "Be concise" };
      render(<FieldRenderer {...baseProps} field={fieldWithHint} onOpenChat={vi.fn()} />);
      expect(screen.getByText("Be concise")).toBeInTheDocument();
    });
  });

  describe("table field", () => {
    const field: FieldDef = {
      id: "items",
      label: "Items",
      type: "table",
      required: false,
      columns: [{ id: "name", label: "Name", type: "string" }],
    };

    it("delegates to TableFieldRenderer", () => {
      render(<FieldRenderer {...baseProps} field={field} />);
      expect(screen.getByTestId("table-section.field")).toBeInTheDocument();
    });
  });

  describe("required field indicator", () => {
    it("shows red asterisk for required fields", () => {
      const field: FieldDef = { id: "name", label: "Name", type: "string", required: true };
      render(<FieldRenderer {...baseProps} field={field} />);
      expect(screen.getByText("*")).toBeInTheDocument();
    });

    it("does not show asterisk for optional fields", () => {
      const field: FieldDef = { id: "name", label: "Name", type: "string", required: false };
      render(<FieldRenderer {...baseProps} field={field} />);
      expect(screen.queryByText("*")).not.toBeInTheDocument();
    });

    it("shows asterisk on boolean required fields", () => {
      const field: FieldDef = { id: "active", label: "Active", type: "boolean", required: true };
      render(<FieldRenderer {...baseProps} field={field} />);
      expect(screen.getByText("*")).toBeInTheDocument();
    });
  });

  describe("AI confidence badge", () => {
    const field: FieldDef = { id: "name", label: "Name", type: "string", required: false };
    const meta: FieldMeta = { confidence: 0.85, source: "bulk-edit", aiSetAt: "2026-01-01T00:00:00Z" };

    it("shows badge when meta has non-manual source", () => {
      render(<FieldRenderer {...baseProps} field={field} meta={meta} />);
      expect(screen.getByText("AI 85%")).toBeInTheDocument();
    });

    it("does not show badge for manual source", () => {
      const manualMeta: FieldMeta = { confidence: 1.0, source: "manual", aiSetAt: "" };
      render(<FieldRenderer {...baseProps} field={field} meta={manualMeta} />);
      expect(screen.queryByText(/AI \d+%/)).not.toBeInTheDocument();
    });
  });

  describe("linked field", () => {
    const field: FieldDef = { id: "name", label: "Name", type: "string", required: false };

    it("shows linked label and renders read-only", () => {
      render(
        <FieldRenderer {...baseProps} field={field} linkedFromLabel="Source Field" />,
      );
      expect(screen.getByText(/Linked to Source Field/)).toBeInTheDocument();
      expect(getInput()).toHaveAttribute("readonly");
    });
  });
});

describe("FieldRenderer — validation issues", () => {
  const field: FieldDef = {
    id: "amt",
    label: "Amount",
    type: "number",
    required: false,
    validate: [{ rule: "range", min: 0, max: 100 }],
  };

  it("shows warning messages and marks the input invalid", () => {
    render(
      <FieldRenderer
        {...baseProps}
        field={field}
        value={-1}
        issues={[{ rule: "range", message: "Must be at least 0", severity: "warning" }]}
      />,
    );
    expect(screen.getByRole("alert")).toHaveTextContent("Must be at least 0");
    expect(getInput()).toHaveAttribute("aria-invalid", "true");
  });

  it("shows info messages without marking the input invalid", () => {
    render(
      <FieldRenderer
        {...baseProps}
        field={field}
        value={5}
        issues={[{ rule: "range", message: "Unusually high", severity: "info" }]}
      />,
    );
    expect(screen.getByText("Unusually high")).toBeInTheDocument();
    expect(screen.queryByRole("alert")).toBeNull();
    expect(getInput()).not.toHaveAttribute("aria-invalid");
  });

  it("passes rule-derived native attributes to date inputs", () => {
    const date: FieldDef = { id: "d", label: "Date", type: "date", required: false, validate: [{ rule: "range", min: "2026-01-01", max: "2026-12-31" }] };
    render(<FieldRenderer {...baseProps} field={date} />);
    expect(getInput()).toHaveAttribute("min", "2026-01-01");
    expect(getInput()).toHaveAttribute("max", "2026-12-31");
  });

  it("does not put native min/max on number inputs (the range rule warns instead)", () => {
    render(<FieldRenderer {...baseProps} field={field} />);
    expect(getInput()).not.toHaveAttribute("min");
    expect(getInput()).not.toHaveAttribute("max");
  });
});
