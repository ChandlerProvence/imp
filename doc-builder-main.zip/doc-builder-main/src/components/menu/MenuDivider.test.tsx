import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import MenuDivider from "./MenuDivider";

describe("MenuDivider", () => {
  it("renders a separator element", () => {
    render(<MenuDivider />);
    expect(screen.getByRole("separator")).toBeInTheDocument();
  });
});
