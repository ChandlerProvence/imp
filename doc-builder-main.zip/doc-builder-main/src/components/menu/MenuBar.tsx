import { useEffect, useRef, useState } from "react";
import MenuDropdown, { type MenuItemDef } from "./MenuDropdown";

export interface MenuDef {
  label: string;
  items: MenuItemDef[];
}

interface Props {
  menus: MenuDef[];
  leading?: React.ReactNode;
  trailing?: React.ReactNode;
}

export default function MenuBar({ menus, leading, trailing }: Props) {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const barRef = useRef<HTMLDivElement>(null);

  // Close on outside click
  useEffect(() => {
    if (openIndex === null) return;

    function handleMouseDown(e: MouseEvent) {
      if (barRef.current && !barRef.current.contains(e.target as Node)) {
        setOpenIndex(null);
      }
    }

    document.addEventListener("mousedown", handleMouseDown);
    return () => document.removeEventListener("mousedown", handleMouseDown);
  }, [openIndex]);

  // Close on Escape
  useEffect(() => {
    if (openIndex === null) return;

    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape") {
        setOpenIndex(null);
      }
    }

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [openIndex]);

  return (
    <div
      ref={barRef}
      role="menubar"
      className="flex h-8 items-center bg-gray-800 px-1 text-sm text-gray-200 print:hidden"
    >
      {leading}
      {menus.map((menu, i) => (
        <div key={i} className="relative">
          <button
            type="button"
            role="menuitem"
            aria-haspopup="true"
            aria-expanded={openIndex === i}
            onClick={() => setOpenIndex(openIndex === i ? null : i)}
            onMouseEnter={() => {
              if (openIndex !== null && openIndex !== i) {
                setOpenIndex(i);
              }
            }}
            className={`rounded-sm px-3 py-1 ${
              openIndex === i ? "bg-gray-700" : "hover:bg-gray-700"
            }`}
          >
            {menu.label}
          </button>

          {openIndex === i && (
            <MenuDropdown items={menu.items} onClose={() => setOpenIndex(null)} />
          )}
        </div>
      ))}
      {trailing && <div className="ml-auto flex items-center">{trailing}</div>}
    </div>
  );
}
