export default function MenuDivider() {
  return <hr className="my-1 border-gray-200" role="separator" />;
}
