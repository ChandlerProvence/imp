import { useState, useRef } from "react";
import MenuDivider from "./MenuDivider";

export interface MenuItemProps {
  label: string;
  shortcut?: string;
  disabled?: boolean;
  onClick?: () => void;
  children?: MenuItemProps[];
  /** Render as a separator line instead of an item (used inside submenus). */
  divider?: boolean;
}

interface Props extends MenuItemProps {
  onClose: () => void;
}

export default function MenuItem({ label, shortcut, disabled, onClick, children, onClose }: Props) {
  const [submenuOpen, setSubmenuOpen] = useState(false);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const hasSubmenu = children && children.length > 0;

  function handleClick() {
    if (disabled) return;
    if (hasSubmenu) return; // submenu opens on hover
    onClick?.();
    onClose();
  }

  function handleMouseEnter() {
    if (hasSubmenu) {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      setSubmenuOpen(true);
    }
  }

  function handleMouseLeave() {
    if (hasSubmenu) {
      timeoutRef.current = setTimeout(() => setSubmenuOpen(false), 150);
    }
  }

  return (
    <div
      className="relative"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      <button
        type="button"
        role="menuitem"
        disabled={disabled}
        onClick={handleClick}
        className={`flex w-full items-center justify-between px-3 py-1.5 text-sm text-left ${
          disabled
            ? "text-gray-400 cursor-not-allowed"
            : "text-gray-700 hover:bg-blue-600 hover:text-white"
        }`}
      >
        <span>{label}</span>
        {shortcut && (
          <span className="ml-6 text-xs text-gray-400">{shortcut}</span>
        )}
        {hasSubmenu && <span className="ml-4 text-gray-400">›</span>}
      </button>

      {/* Submenu */}
      {hasSubmenu && submenuOpen && (
        <div
          role="menu"
          className="absolute left-full top-0 ml-0.5 min-w-[180px] rounded border border-gray-200 bg-white py-1 shadow-lg z-50"
        >
          {children.map((item, i) =>
            item.divider ? (
              <MenuDivider key={i} />
            ) : (
              <MenuItem key={i} {...item} onClose={onClose} />
            ),
          )}
        </div>
      )}
    </div>
  );
}
