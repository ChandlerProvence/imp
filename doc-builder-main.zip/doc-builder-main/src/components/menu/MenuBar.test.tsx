import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import MenuBar, { type MenuDef } from "./MenuBar";

const menus: MenuDef[] = [
  {
    label: "File",
    items: [
      { kind: "action", label: "New", onClick: vi.fn() },
      { kind: "action", label: "Open", onClick: vi.fn() },
    ],
  },
  {
    label: "Edit",
    items: [{ kind: "action", label: "Undo", onClick: vi.fn() }],
  },
];

describe("MenuBar", () => {
  it("renders menu labels", () => {
    render(<MenuBar menus={menus} />);
    expect(screen.getByText("File")).toBeInTheDocument();
    expect(screen.getByText("Edit")).toBeInTheDocument();
  });

  it("has menubar role", () => {
    render(<MenuBar menus={menus} />);
    expect(screen.getByRole("menubar")).toBeInTheDocument();
  });

  it("opens dropdown on click", () => {
    render(<MenuBar menus={menus} />);
    expect(screen.queryByText("New")).not.toBeInTheDocument();
    fireEvent.click(screen.getByText("File"));
    expect(screen.getByText("New")).toBeInTheDocument();
    expect(screen.getByText("Open")).toBeInTheDocument();
  });

  it("closes dropdown on second click", () => {
    render(<MenuBar menus={menus} />);
    fireEvent.click(screen.getByText("File"));
    expect(screen.getByText("New")).toBeInTheDocument();
    fireEvent.click(screen.getByText("File"));
    expect(screen.queryByText("New")).not.toBeInTheDocument();
  });

  it("closes dropdown on Escape", () => {
    render(<MenuBar menus={menus} />);
    fireEvent.click(screen.getByText("File"));
    expect(screen.getByText("New")).toBeInTheDocument();
    fireEvent.keyDown(document, { key: "Escape" });
    expect(screen.queryByText("New")).not.toBeInTheDocument();
  });

  it("switches dropdown on hover when one is open", () => {
    render(<MenuBar menus={menus} />);
    fireEvent.click(screen.getByText("File"));
    expect(screen.getByText("New")).toBeInTheDocument();
    fireEvent.mouseEnter(screen.getByText("Edit"));
    expect(screen.queryByText("New")).not.toBeInTheDocument();
    expect(screen.getByText("Undo")).toBeInTheDocument();
  });
});
