import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import MenuItem from "./MenuItem";

describe("MenuItem", () => {
  it("renders label", () => {
    render(<MenuItem label="Save" onClose={vi.fn()} />);
    expect(screen.getByText("Save")).toBeInTheDocument();
  });

  it("renders shortcut when provided", () => {
    render(<MenuItem label="Save" shortcut="Ctrl+S" onClose={vi.fn()} />);
    expect(screen.getByText("Ctrl+S")).toBeInTheDocument();
  });

  it("calls onClick and onClose when clicked", () => {
    const onClick = vi.fn();
    const onClose = vi.fn();
    render(<MenuItem label="Save" onClick={onClick} onClose={onClose} />);
    fireEvent.click(screen.getByRole("menuitem"));
    expect(onClick).toHaveBeenCalledOnce();
    expect(onClose).toHaveBeenCalledOnce();
  });

  it("does not call onClick when disabled", () => {
    const onClick = vi.fn();
    render(<MenuItem label="Save" onClick={onClick} disabled onClose={vi.fn()} />);
    fireEvent.click(screen.getByRole("menuitem"));
    expect(onClick).not.toHaveBeenCalled();
  });

  it("shows submenu indicator when children provided", () => {
    render(
      <MenuItem
        label="Open Recent"
        children={[{ label: "file.txt" }]}
        onClose={vi.fn()}
      />,
    );
    expect(screen.getByText("›")).toBeInTheDocument();
  });

  it("shows submenu on hover", () => {
    render(
      <MenuItem
        label="Open Recent"
        children={[{ label: "file.txt" }]}
        onClose={vi.fn()}
      />,
    );
    expect(screen.queryByText("file.txt")).not.toBeInTheDocument();
    fireEvent.mouseEnter(screen.getByText("Open Recent").closest("div")!);
    expect(screen.getByText("file.txt")).toBeInTheDocument();
  });
});
