import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import MenuDropdown, { type MenuItemDef } from "./MenuDropdown";

describe("MenuDropdown", () => {
  const items: MenuItemDef[] = [
    { kind: "action", label: "Save", shortcut: "Ctrl+S", onClick: vi.fn() },
    { kind: "divider" },
    { kind: "action", label: "Quit", onClick: vi.fn() },
  ];

  it("renders menu items", () => {
    render(<MenuDropdown items={items} onClose={vi.fn()} />);
    expect(screen.getByText("Save")).toBeInTheDocument();
    expect(screen.getByText("Quit")).toBeInTheDocument();
  });

  it("renders dividers", () => {
    render(<MenuDropdown items={items} onClose={vi.fn()} />);
    expect(screen.getByRole("separator")).toBeInTheDocument();
  });

  it("renders dividers inside submenus as separators, not items", () => {
    const nested: MenuItemDef[] = [
      {
        kind: "submenu",
        label: "More",
        children: [
          { kind: "action", label: "A", onClick: vi.fn() },
          { kind: "divider" },
          { kind: "action", label: "B", onClick: vi.fn() },
        ],
      },
    ];
    render(<MenuDropdown items={nested} onClose={vi.fn()} />);
    fireEvent.mouseEnter(screen.getByText("More").closest("div")!);
    expect(screen.getByRole("separator")).toBeInTheDocument();
    // Only "More", "A", "B" — the divider is not an empty menuitem
    expect(screen.getAllByRole("menuitem")).toHaveLength(3);
  });

  it("has menu role", () => {
    render(<MenuDropdown items={items} onClose={vi.fn()} />);
    expect(screen.getByRole("menu")).toBeInTheDocument();
  });

  it("renders shortcut text", () => {
    render(<MenuDropdown items={items} onClose={vi.fn()} />);
    expect(screen.getByText("Ctrl+S")).toBeInTheDocument();
  });
});
