import MenuItem, { type MenuItemProps } from "./MenuItem";
import MenuDivider from "./MenuDivider";

export interface MenuItemDef {
  kind: "action" | "divider" | "submenu";
  label?: string;
  shortcut?: string;
  disabled?: boolean;
  onClick?: () => void;
  children?: MenuItemDef[];
}

interface Props {
  items: MenuItemDef[];
  onClose: () => void;
}

export default function MenuDropdown({ items, onClose }: Props) {
  return (
    <div
      role="menu"
      className="absolute left-0 top-full mt-0.5 min-w-[200px] rounded border border-gray-200 bg-white py-1 shadow-lg z-50"
    >
      {items.map((item, i) => {
        if (item.kind === "divider") {
          return <MenuDivider key={i} />;
        }

        const childProps: MenuItemProps | undefined =
          item.kind === "submenu" && item.children
            ? {
                label: item.label ?? "",
                children: item.children.map(toMenuItemProps),
              }
            : undefined;

        return (
          <MenuItem
            key={i}
            label={item.label ?? ""}
            shortcut={item.shortcut}
            disabled={item.disabled}
            onClick={item.onClick}
            children={childProps?.children}
            onClose={onClose}
          />
        );
      })}
    </div>
  );
}

function toMenuItemProps(def: MenuItemDef): MenuItemProps {
  return {
    label: def.label ?? "",
    shortcut: def.shortcut,
    disabled: def.disabled,
    onClick: def.onClick,
    children: def.children?.map(toMenuItemProps),
    divider: def.kind === "divider",
  };
}
