import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import TableFieldRenderer from "./TableFieldRenderer";
import type { FieldDef } from "../schemas/types";
import { serializeTableData } from "../engine/tableData";

const baseField: FieldDef = {
  id: "items",
  label: "Items",
  type: "table",
  required: false,
  columns: [
    { id: "name", label: "Name", type: "string" },
    { id: "qty", label: "Quantity", type: "number" },
  ],
};

const baseProps = {
  field: baseField,
  fieldKey: "section.items",
  value: undefined as string | number | boolean | undefined,
  onChange: vi.fn(),
};

describe("TableFieldRenderer", () => {
  it("renders column headers", () => {
    render(<TableFieldRenderer {...baseProps} />);
    expect(screen.getByText("Name")).toBeInTheDocument();
    expect(screen.getByText("Quantity")).toBeInTheDocument();
  });

  it("renders Add Row button for dynamic tables", () => {
    render(<TableFieldRenderer {...baseProps} />);
    expect(screen.getByText("Add Row")).toBeInTheDocument();
  });

  it("shows empty state message for dynamic tables with no data", () => {
    render(<TableFieldRenderer {...baseProps} />);
    expect(screen.getByText(/No rows yet/)).toBeInTheDocument();
  });

  it("calls onChange when a cell is edited", () => {
    const onChange = vi.fn();
    const existingData = serializeTableData({ rows: [{ name: "", qty: "" }] });
    render(<TableFieldRenderer {...baseProps} value={existingData} onChange={onChange} />);
    const inputs = screen.getAllByRole("textbox");
    fireEvent.change(inputs[0], { target: { value: "Alice" } });
    expect(onChange).toHaveBeenCalledWith("section.items", expect.any(String));
    const serialized = onChange.mock.calls[0][1] as string;
    const parsed = JSON.parse(serialized);
    expect(parsed.rows[0].name).toBe("Alice");
  });

  it("adds a new row when Add Row is clicked", () => {
    const onChange = vi.fn();
    render(<TableFieldRenderer {...baseProps} onChange={onChange} />);
    fireEvent.click(screen.getByText("Add Row"));
    const serialized = onChange.mock.calls[onChange.mock.calls.length - 1][1] as string;
    const parsed = JSON.parse(serialized);
    expect(parsed.rows.length).toBe(1); // first row added from empty state
  });

  it("renders fixed rows when field.rows is defined", () => {
    const fixedField: FieldDef = {
      ...baseField,
      rows: [
        { id: "r1", label: "Row Alpha" },
        { id: "r2", label: "Row Beta" },
      ],
    };
    render(<TableFieldRenderer {...baseProps} field={fixedField} />);
    expect(screen.getByText("Row Alpha")).toBeInTheDocument();
    expect(screen.getByText("Row Beta")).toBeInTheDocument();
  });

  it("does not show Add Row button for fixed-row tables", () => {
    const fixedField: FieldDef = {
      ...baseField,
      rows: [{ id: "r1", label: "Row One" }],
    };
    render(<TableFieldRenderer {...baseProps} field={fixedField} />);
    expect(screen.queryByText("Add Row")).not.toBeInTheDocument();
  });

  it("renders existing data from value prop", () => {
    const existingData = serializeTableData({
      rows: [{ name: "Bob", qty: "10" }],
    });
    render(<TableFieldRenderer {...baseProps} value={existingData} />);
    const inputs = screen.getAllByRole("textbox");
    expect((inputs[0] as HTMLInputElement).value).toBe("Bob");
  });

  it("renders as read-only when linkedFromLabel is set", () => {
    const existingData = serializeTableData({ rows: [{ name: "Bob", qty: "5" }] });
    render(
      <TableFieldRenderer {...baseProps} value={existingData} linkedFromLabel="Source Table" />,
    );
    const inputs = screen.getAllByRole("textbox");
    expect(inputs[0]).toHaveAttribute("readonly");
  });

  it("stores typed '1,000' as a number and recomputes the formula column", () => {
    const onChange = vi.fn();
    const field: FieldDef = {
      ...baseField,
      columns: [
        { id: "qty", label: "Quantity", type: "number" },
        { id: "rate", label: "Rate", type: "number", format: "currency" },
        { id: "amount", label: "Amount", type: "number", format: "currency", formula: "qty * rate" },
      ],
    };
    const existingData = serializeTableData({ rows: [{ qty: 2, rate: "", amount: "" }] });
    render(<TableFieldRenderer {...baseProps} field={field} value={existingData} onChange={onChange} />);
    fireEvent.change(screen.getByLabelText(/^Rate/), { target: { value: "$1,000" } });
    const row = JSON.parse(onChange.mock.calls.at(-1)![1] as string).rows[0];
    expect(row).toMatchObject({ rate: 1000, amount: 2000 });
  });

  it("shows currency formula cells formatted", () => {
    const field: FieldDef = {
      ...baseField,
      columns: [
        { id: "rate", label: "Rate", type: "number" },
        { id: "amount", label: "Amount", type: "number", format: "currency", formula: "rate * 2" },
      ],
    };
    render(<TableFieldRenderer {...baseProps} field={field} value={serializeTableData({ rows: [{ rate: 37500 }] })} />);
    expect((screen.getByLabelText(/^Amount/) as HTMLInputElement).value).toBe("75,000.00");
  });
});
