import { useCallback, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import type { DocumentSchema } from "../schemas/types";
import { useSessionContext } from "../context/SessionContext";
import { useAiPanelContext } from "../context/AiPanelContext";
import { isSectionFullyLinked } from "../engine/fieldLinks";
import { getVisibleSections } from "../engine/visibility";
import { buildFieldDestinationMap, buildSetFieldDestinationMap } from "../engine/fieldDestinations";
import { getScopeColors } from "../utils/scopeColors";
import MagicWandIcon from "./icons/MagicWandIcon";
import FieldsPanel from "./FieldsPanel";
import TabLockBanner from "./TabLockBanner";
import { prepPagesFor, prepPath } from "../pages/prep/prepPages";

interface Props {
  schema: DocumentSchema;
  sectionId: string;
}

export default function WizardShell({ schema, sectionId }: Props) {
  const navigate = useNavigate();
  const { loading, session, answers, fieldMeta, setAnswer, isSetSession, mergedSchema, isLockedByOtherTab, validationIssues } =
    useSessionContext();
  const { scope, setScope, setPanelOpen } = useAiPanelContext();

  const [showDestinations, setShowDestinations] = useState(
    () => localStorage.getItem("doc-builder:show-field-destinations") === "true",
  );

  const [showHints, setShowHints] = useState(
    () => localStorage.getItem("doc-builder:show-ai-hints") === "true",
  );

  const destinationMap = useMemo(() => {
    if (!showDestinations) return undefined;
    if (isSetSession && mergedSchema) {
      return buildSetFieldDestinationMap(mergedSchema.sourceSchemas);
    }
    return buildFieldDestinationMap(schema);
  }, [showDestinations, schema, isSetSession, mergedSchema]);

  // Only show sections whose `visible_when` condition is satisfied.
  const visibleSections = useMemo(
    () => getVisibleSections(schema, answers),
    [schema, answers],
  );

  const activeSection = schema.sections.find((s) => s.id === sectionId)!;
  const idx = visibleSections.findIndex((s) => s.id === sectionId);
  const prevSection = idx > 0 ? visibleSections[idx - 1] : null;
  const nextSection = idx < visibleSections.length - 1 ? visibleSections[idx + 1] : null;
  // The first section's Back goes to the Prep group when one applies, else Home.
  const lastPrepPage = useMemo(() => prepPagesFor(schema).at(-1) ?? null, [schema]);

  const goToSection = useCallback(
    (targetId: string) => {
      navigate(`/interview/${schema.id}/${targetId}`);
    },
    [navigate, schema.id],
  );

  /** Advance forward, skipping fully-linked sections whose sources are all filled. */
  const goForward = useCallback(() => {
    let target = nextSection;
    while (target && isSectionFullyLinked(target)) {
      // Check if all sources for this section's fields are filled
      const allSourcesFilled = target.fields.every((f) => {
        if (!f.same_as) return true;
        const sourceVal = answers[f.same_as];
        return sourceVal !== undefined && sourceVal !== "";
      });
      if (!allSourcesFilled) break;
      const targetIdx = visibleSections.findIndex((s) => s.id === target!.id);
      target = targetIdx < visibleSections.length - 1 ? visibleSections[targetIdx + 1] : null;
    }
    if (target) {
      goToSection(target.id);
    } else {
      navigate("/review");
    }
  }, [nextSection, answers, visibleSections, goToSection, navigate]);

  /** Focus AI panel on a specific field. */
  const handleFocusAiField = useCallback(
    (fieldKey: string) => {
      setScope({ type: "field", sectionId, fieldKey });
      setPanelOpen(true);
    },
    [sectionId, setScope, setPanelOpen],
  );

  /** Focus AI panel on the current section. */
  const handleFocusAiSection = useCallback(() => {
    setScope({ type: "section", sectionId });
    setPanelOpen(true);
  }, [sectionId, setScope, setPanelOpen]);

  /** Focus AI panel on the entire document. */
  const handleFocusAiDocument = useCallback(() => {
    setScope({ type: "document" });
    setPanelOpen(true);
  }, [setScope, setPanelOpen]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full text-gray-500">
        Loading…
      </div>
    );
  }

  return (
    <div className="flex h-full bg-gray-50">
      {/* Main panel — fields */}
      <div className="flex flex-1 flex-col min-w-0">
        {/* Header */}
        <header className="flex items-center justify-between border-b border-gray-200 bg-white px-6 py-3">
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-semibold text-gray-900">{schema.title}</h1>
            {/* AI Draft Document button */}
            <button
              type="button"
              onClick={handleFocusAiDocument}
              className={`inline-flex items-center justify-center w-6 h-6 rounded-md border transition-colors ${
                scope.type === "document"
                  ? `${getScopeColors("document").iconBgActive} ${getScopeColors("document").iconTextActive} ${getScopeColors("document").iconBorderActive}`
                  : `${getScopeColors("document").iconBg} ${getScopeColors("document").iconText} ${getScopeColors("document").iconBgHover} ${getScopeColors("document").iconBorder}`
              }`}
              title="Focus AI on entire document"
            >
              <MagicWandIcon className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => {
                const next = !showHints;
                setShowHints(next);
                localStorage.setItem("doc-builder:show-ai-hints", String(next));
              }}
              className={`inline-flex items-center gap-1 rounded px-2 py-1 text-xs transition-colors ${
                showHints
                  ? "bg-blue-50 text-blue-700 border border-blue-200"
                  : "text-gray-400 hover:text-gray-600 hover:bg-gray-100 border border-transparent"
              }`}
              title="Show AI hints for fields"
            >
              <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 18v-5.25m0 0a6.01 6.01 0 001.5-.189m-1.5.189a6.01 6.01 0 01-1.5-.189m3.75 7.478a12.06 12.06 0 01-4.5 0m3.75 2.383a14.406 14.406 0 01-3 0M9.75 8.25h4.5m-4.5 2.5h4.5M12 2.25a5.25 5.25 0 00-5.25 5.25c0 2.044 1.168 3.816 2.87 4.682.376.191.63.56.63.978V15a.75.75 0 00.75.75h2a.75.75 0 00.75-.75v-1.84c0-.418.254-.787.63-.978A5.252 5.252 0 0012 2.25z" />
              </svg>
              Hints
            </button>
            <button
              type="button"
              onClick={() => {
                const next = !showDestinations;
                setShowDestinations(next);
                localStorage.setItem("doc-builder:show-field-destinations", String(next));
              }}
              className={`inline-flex items-center gap-1 rounded px-2 py-1 text-xs transition-colors ${
                showDestinations
                  ? "bg-blue-50 text-blue-700 border border-blue-200"
                  : "text-gray-400 hover:text-gray-600 hover:bg-gray-100 border border-transparent"
              }`}
              title="Show where each field appears in the output document"
            >
              <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
              </svg>
              Destinations
            </button>
            <span className="text-xs text-gray-400">
              Section {idx + 1} of {visibleSections.length}
            </span>
          </div>
        </header>

        {/* Tab lock banner */}
        {isLockedByOtherTab && <TabLockBanner />}

        {/* Fields */}
        <FieldsPanel
          section={activeSection}
          answers={answers}
          fieldMeta={fieldMeta}
          onAnswer={setAnswer}
          onOpenChat={handleFocusAiField}
          activeDraftField={null}
          schema={schema}
          destinationMap={destinationMap}
          showHints={showHints}
          onDraftSection={handleFocusAiSection}
          activeScope={scope}
          sessionId={session?.id}
          validationIssues={validationIssues}
          readOnly={isLockedByOtherTab}
        />

        {/* Footer navigation */}
        <footer className="flex items-center justify-between border-t border-gray-200 bg-white px-6 py-3">
          {prevSection ? (
            <button
              type="button"
              onClick={() => goToSection(prevSection.id)}
              className="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              ← Back
            </button>
          ) : (
            <Link
              to={lastPrepPage ? prepPath(schema.id, lastPrepPage.id) : "/"}
              className="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              {lastPrepPage ? "← Prep" : "← Home"}
            </Link>
          )}

          {nextSection ? (
            <button
              type="button"
              onClick={goForward}
              className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
            >
              Next →
            </button>
          ) : (
            <Link
              to="/review"
              className="rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700"
            >
              Review ✓
            </Link>
          )}
        </footer>
      </div>
    </div>
  );
}
