import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import ErrorBox from "./ErrorBox";

describe("ErrorBox", () => {
  beforeEach(() => {
    Object.assign(navigator, {
      clipboard: { writeText: vi.fn().mockResolvedValue(undefined) },
    });
  });

  it("renders title with cross mark prefix", () => {
    render(<ErrorBox title="Connection failed" detail="some error" />);
    expect(screen.getByText("✗ Connection failed")).toBeInTheDocument();
  });

  it("renders default help text when helpText is omitted", () => {
    render(<ErrorBox title="Error" detail="detail" />);
    expect(
      screen.getByText(/copy an error report and send it to/i),
    ).toBeInTheDocument();
  });

  it("renders custom help text", () => {
    render(<ErrorBox title="Error" detail="detail" helpText="Contact IT support." />);
    expect(screen.getByText("Contact IT support.")).toBeInTheDocument();
  });

  it("does not render help text when helpText is null", () => {
    render(<ErrorBox title="Error" detail="detail" helpText={null} />);
    expect(
      screen.queryByText(/copy an error report/i),
    ).not.toBeInTheDocument();
  });

  it("copies detail to clipboard when no copyText is provided", async () => {
    render(<ErrorBox title="Error" detail="the full error message" />);
    const btn = screen.getByRole("button", { name: /copy error report/i });
    fireEvent.click(btn);
    expect(navigator.clipboard.writeText).toHaveBeenCalledWith("the full error message");
  });

  it("copies copyText instead of detail when provided", async () => {
    render(<ErrorBox title="Error" detail="short detail" copyText="full diagnostics report here" />);
    const btn = screen.getByRole("button", { name: /copy error report/i });
    fireEvent.click(btn);
    expect(navigator.clipboard.writeText).toHaveBeenCalledWith("full diagnostics report here");
  });

  it("does not render a detail pre block", () => {
    render(<ErrorBox title="Error" detail="raw detail" />);
    expect(screen.queryByText("raw detail")).not.toBeInTheDocument();
  });

  it("shows Copied! after copy", async () => {
    render(<ErrorBox title="Error" detail="msg" />);
    const btn = screen.getByRole("button", { name: /copy error report/i });
    fireEvent.click(btn);
    await waitFor(() => {
      expect(btn.textContent).toContain("Copied!");
    });
  });

  it("applies additional className to outer container", () => {
    const { container } = render(
      <ErrorBox title="Error" detail="detail" className="mt-2" />,
    );
    expect(container.firstElementChild?.classList.contains("mt-2")).toBe(true);
  });
});
