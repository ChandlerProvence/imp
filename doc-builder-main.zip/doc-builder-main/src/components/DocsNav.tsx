import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { DOC_INDEX, groupDocs, type DocEntry } from "../docs/docsRegistry";

interface Props {
  /** Id of the doc currently displayed. */
  activeId: string;
  onCollapse: () => void;
  /** Override for tests; defaults to the auto-discovered registry. */
  docs?: DocEntry[];
}

interface FilteredEntry {
  doc: DocEntry;
  /** Matched only in body text, not title/filename. */
  contentOnly: boolean;
}

/**
 * Sidebar file list for the Documentation page — rendered by AppSidebar in
 * place of the Steps outline on `/docs/*` routes.
 */
export default function DocsNav({ activeId, onCollapse, docs = DOC_INDEX }: Props) {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [collapsedGroups, setCollapsedGroups] = useState<Set<string>>(new Set());
  const activeRef = useRef<HTMLButtonElement>(null);

  const groups = useMemo(() => groupDocs(docs), [docs]);
  const q = query.trim().toLowerCase();

  const filteredGroups = useMemo(() => {
    return groups
      .map((g) => {
        const entries: FilteredEntry[] = [];
        const contentMatches: FilteredEntry[] = [];
        for (const doc of g.entries) {
          if (!q || doc.title.toLowerCase().includes(q) || doc.id.toLowerCase().includes(q)) {
            entries.push({ doc, contentOnly: false });
          } else if (doc.markdown.toLowerCase().includes(q)) {
            contentMatches.push({ doc, contentOnly: true });
          }
        }
        return { label: g.label, entries: [...entries, ...contentMatches] };
      })
      .filter((g) => g.entries.length > 0);
  }, [groups, q]);

  const matchCount = filteredGroups.reduce((n, g) => n + g.entries.length, 0);

  useEffect(() => {
    activeRef.current?.scrollIntoView?.({ block: "nearest" });
  }, [activeId]);

  function toggleGroup(label: string) {
    setCollapsedGroups((prev) => {
      const next = new Set(prev);
      if (next.has(label)) next.delete(label);
      else next.add(label);
      return next;
    });
  }

  return (
    <nav className="flex min-h-0 flex-1 flex-col border-r border-gray-200 bg-white py-3 text-xs" aria-label="Documentation">
      <div className="flex items-center justify-between px-4 mb-2">
        <h2 className="text-[10px] font-semibold uppercase tracking-wider text-gray-400">
          Documentation
        </h2>
        <button
          type="button"
          onClick={onCollapse}
          className="text-gray-400 hover:text-gray-600 p-0.5 rounded hover:bg-gray-200 transition-colors"
          title="Collapse sidebar (Ctrl+B)"
        >
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-3 h-3">
            <path fillRule="evenodd" d="M11.78 5.22a.75.75 0 0 1 0 1.06L8.06 10l3.72 3.72a.75.75 0 1 1-1.06 1.06l-4.25-4.25a.75.75 0 0 1 0-1.06l4.25-4.25a.75.75 0 0 1 1.06 0Z" clipRule="evenodd" />
          </svg>
        </button>
      </div>

      <div className="px-2 mb-2">
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Filter docs…"
          aria-label="Filter docs"
          className="w-full rounded border border-gray-300 px-2 py-1 text-xs focus:border-blue-400 focus:outline-none focus:ring-1 focus:ring-blue-300"
        />
        {q && (
          <p className="mt-1 px-0.5 text-[10px] text-gray-400">
            {matchCount} of {docs.length}
          </p>
        )}
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto px-2">
        {filteredGroups.length === 0 && (
          <p className="px-2 text-[10px] text-gray-400">No matches</p>
        )}
        {filteredGroups.map((g) => {
          // While filtering, always show matches even in groups the user collapsed
          const open = !!q || !collapsedGroups.has(g.label);
          return (
            <section key={g.label} className="mb-2">
              <button
                type="button"
                onClick={() => toggleGroup(g.label)}
                aria-expanded={open}
                className="flex w-full items-center gap-1 rounded px-2 py-1 text-left text-[10px] font-semibold uppercase tracking-wider text-gray-500 hover:bg-gray-100"
              >
                <span className={`inline-block transition-transform ${open ? "rotate-90" : ""}`}>›</span>
                <span>{g.label}</span>
                <span className="ml-auto font-normal text-gray-400">{g.entries.length}</span>
              </button>
              {open && (
                <ul className="space-y-px">
                  {g.entries.map(({ doc, contentOnly }) => {
                    const active = doc.id === activeId;
                    return (
                      <li key={doc.id}>
                        <button
                          ref={active ? activeRef : undefined}
                          type="button"
                          onClick={() => navigate(`/docs/${doc.id}`)}
                          aria-current={active ? "page" : undefined}
                          className={`w-full rounded px-2 py-1 text-left transition-colors ${
                            active
                              ? "bg-blue-50 text-blue-900 font-medium"
                              : "text-gray-600 hover:bg-gray-100"
                          }`}
                          title={doc.title}
                        >
                          <span className="flex items-center gap-1.5">
                            <span className="truncate">{doc.title}</span>
                            {contentOnly && (
                              <span className="ml-auto shrink-0 rounded bg-gray-100 px-1 text-[9px] font-normal text-gray-500">
                                in text
                              </span>
                            )}
                          </span>
                          <span className="block truncate text-[10px] font-normal text-gray-400">
                            {doc.id}.md
                          </span>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </section>
          );
        })}
      </div>
    </nav>
  );
}
