import { useState } from "react";

interface StringCellInputProps {
  label: string;
  value: string;
  readOnly: boolean;
  cellClass: string;
  onChange: (value: string) => void;
}

/** String cell that expands to a textarea on focus for long values. */
export default function StringCellInput({
  label,
  value,
  readOnly,
  cellClass,
  onChange,
}: StringCellInputProps) {
  const [expanded, setExpanded] = useState(false);
  const showExpanded = expanded || value.length > 50;
  const titleVal = value.length > 30 ? value : undefined;

  if (showExpanded) {
    return (
      <textarea
        aria-label={label}
        title={titleVal}
        className={`${cellClass} resize-none`}
        rows={expanded ? 3 : 2}
        value={value}
        readOnly={readOnly}
        tabIndex={readOnly ? -1 : undefined}
        onFocus={() => setExpanded(true)}
        onBlur={() => setExpanded(false)}
        onChange={(e) => onChange(e.target.value)}
      />
    );
  }

  return (
    <input
      type="text"
      aria-label={label}
      title={titleVal}
      className={cellClass}
      value={value}
      readOnly={readOnly}
      tabIndex={readOnly ? -1 : undefined}
      onFocus={() => setExpanded(true)}
      onChange={(e) => onChange(e.target.value)}
    />
  );
}
