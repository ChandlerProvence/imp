import type { TableColumnDef } from "../../schemas/types";
import StringCellInput from "./StringCellInput";
import NumberInput from "../NumberInput";
import { inputAttrsFor } from "../../engine/validation";

interface CellInputProps {
  column: TableColumnDef;
  value: string | number | boolean;
  readOnly: boolean;
  /** Whether this cell is a formula-computed value (distinct styling). */
  isFormula?: boolean;
  /** Human-readable row context for accessibility labels. */
  rowLabel?: string;
  onChange: (value: string | number | boolean) => void;
}

export default function CellInput({
  column,
  value,
  readOnly,
  isFormula,
  rowLabel,
  onChange,
}: CellInputProps) {
  const baseClass =
    "w-full rounded border border-gray-200 px-2 py-1 text-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500";
  const readOnlyClass =
    "w-full rounded border border-gray-100 bg-gray-50 px-2 py-1 text-sm text-gray-500 cursor-not-allowed";
  const formulaClass =
    "w-full rounded border border-blue-200 bg-blue-50 px-2 py-1 text-sm text-blue-700 font-medium cursor-not-allowed";
  const label = rowLabel ? `${column.label} — ${rowLabel}` : column.label;
  const cellClass = isFormula ? formulaClass : readOnly ? readOnlyClass : baseClass;
  const nativeAttrs = readOnly || isFormula ? {} : inputAttrsFor(column.validate);

  switch (column.type) {
    case "string":
      return (
        <StringCellInput
          label={label}
          value={(value as string) ?? ""}
          readOnly={readOnly || !!isFormula}
          cellClass={cellClass}
          onChange={(v) => onChange(v)}
        />
      );

    case "number":
      return (
        <NumberInput
          aria-label={label}
          className={cellClass}
          value={value}
          format={column.format}
          readOnly={readOnly || isFormula}
          tabIndex={readOnly || isFormula ? -1 : undefined}
          onChange={onChange}
        />
      );

    case "date":
      return (
        <input
          type="date"
          aria-label={label}
          className={cellClass}
          {...nativeAttrs}
          value={(value as string) ?? ""}
          readOnly={readOnly || isFormula}
          tabIndex={readOnly || isFormula ? -1 : undefined}
          onChange={(e) => onChange(e.target.value)}
        />
      );

    case "enum":
      return (
        <select
          aria-label={label}
          className={cellClass}
          value={(value as string) ?? ""}
          disabled={readOnly || isFormula}
          onChange={(e) => onChange(e.target.value)}
        >
          <option value="">—</option>
          {column.options?.map((opt) => (
            <option key={opt} value={opt}>
              {opt}
            </option>
          ))}
        </select>
      );

    case "boolean":
      return (
        <input
          type="checkbox"
          aria-label={label}
          className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
          checked={!!value}
          disabled={readOnly || isFormula}
          onChange={(e) => onChange(e.target.checked)}
        />
      );

    default:
      return null;
  }
}
