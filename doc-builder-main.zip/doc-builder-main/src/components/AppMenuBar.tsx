import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { MenuBar, type MenuDef, type MenuItemDef } from "./menu";
import { useSchemaRegistry, filterSchemasByRole, groupSchemasByCategory, groupSchemasBySet } from "../schemas";
import { useSessionContext } from "../context/SessionContext";
import { useUserPreferences } from "../context/UserPreferencesContext";
import ConfirmDialog from "./ConfirmDialog";
import SettingsDialog from "./SettingsDialog";
import { OPEN_SETTINGS_EVENT } from "./EndpointBadge";
import { MAILING_LIST_MAILTO } from "../config/mailingList";
import { buildDiagnosticsReport } from "../errors/formatDiagnostics";
import { collectDiagnosticsOptions } from "./diagnosticsOptions";
import {
  downloadSessionExport,
  validateImportFile,
  importSession,
} from "../db/sessionExport";

type NewDocumentTarget = { type: "schema"; schemaId: string } | { type: "set"; setId: string };

export default function AppMenuBar() {
  const navigate = useNavigate();
  const { list: registeredSchemas } = useSchemaRegistry();
  const {
    session,
    answers,
    startSession,
    startSetSession,
    deleteCurrentSession,
    clearAnswers,
    resumeSession,
  } = useSessionContext();
  const { role } = useUserPreferences();

  const [showConfirm, setShowConfirm] = useState(false);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [showClearAnswersConfirm, setShowClearAnswersConfirm] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [settingsSection, setSettingsSection] = useState<string | undefined>();
  const [pendingNew, setPendingNew] = useState<NewDocumentTarget | null>(null);

  // Import state
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [importError, setImportError] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [importWarnings, setImportWarnings] = useState<string[]>([]);
  const [showImportWarning, setShowImportWarning] = useState(false);
  const [pendingImportData, setPendingImportData] = useState<Parameters<typeof importSession>[0] | null>(null);

  // Allow EndpointBadge (or anything) to request opening settings via custom event.
  // The event detail may carry { section?: string } to scroll to a specific section.
  useEffect(() => {
    const open = (e: Event) => {
      const section = (e as CustomEvent<{ section?: string }>).detail?.section;
      setSettingsSection(section);
      setShowSettings(true);
    };
    window.addEventListener(OPEN_SETTINGS_EVENT, open);
    return () => window.removeEventListener(OPEN_SETTINGS_EVENT, open);
  }, []);

  function startNew(target: NewDocumentTarget) {
    return target.type === "schema" ? startSession(target.schemaId) : startSetSession(target.setId);
  }

  function handleNewDocument(target: NewDocumentTarget) {
    // If there's a session with answers, confirm before discarding
    if (session && Object.keys(answers).length > 0) {
      setPendingNew(target);
      setShowConfirm(true);
      return;
    }

    // No data to lose — start directly
    startNew(target);
  }

  async function confirmSwitch() {
    if (!pendingNew) return;
    await startNew(pendingNew);
    setShowConfirm(false);
    setPendingNew(null);
  }

  async function saveAndSwitch() {
    if (session) {
      const saved = await downloadSessionExport(session.id);
      if (!saved) return; // User cancelled file picker
    }
    await confirmSwitch();
  }

  function cancelSwitch() {
    setShowConfirm(false);
    setPendingNew(null);
  }

  function handleDeleteSession() {
    if (session && Object.keys(answers).length > 0) {
      setShowClearConfirm(true);
      return;
    }
    deleteCurrentSession();
  }

  async function confirmClearSession() {
    setShowClearConfirm(false);
    await deleteCurrentSession();
  }

  async function saveAndClearSession() {
    if (session) {
      const saved = await downloadSessionExport(session.id);
      if (!saved) return; // User cancelled file picker
    }
    setShowClearConfirm(false);
    await deleteCurrentSession();
  }

  function handleClearAnswers() {
    if (session && Object.keys(answers).length > 0) {
      setShowClearAnswersConfirm(true);
      return;
    }
    clearAnswers();
  }

  async function confirmClearAnswers() {
    setShowClearAnswersConfirm(false);
    await clearAnswers();
  }

  async function saveAndClearAnswers() {
    if (session) {
      const saved = await downloadSessionExport(session.id);
      if (!saved) return; // User cancelled file picker
    }
    setShowClearAnswersConfirm(false);
    await clearAnswers();
  }

  async function handleSaveProgress() {
    if (!session) return;
    try {
      await downloadSessionExport(session.id);
    } catch (err) {
      setSaveError(
        err instanceof Error ? err.message : "Failed to save progress.",
      );
    }
  }

  function handleLoadProgressClick() {
    fileInputRef.current?.click();
  }

  async function handleFileSelected(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    // Reset the input so the same file can be re-selected
    if (fileInputRef.current) fileInputRef.current.value = "";
    if (!file) return;

    let raw: unknown;
    try {
      const text = await file.text();
      raw = JSON.parse(text);
    } catch {
      setImportError("The selected file is not valid JSON.");
      return;
    }

    const result = await validateImportFile(raw);
    if (!result.valid) {
      setImportError(result.errors.join(" "));
      return;
    }

    // If there are warnings, show them and let user confirm
    if (result.warnings.length > 0) {
      setImportWarnings(result.warnings);
      setPendingImportData(result.data!);
      setShowImportWarning(true);
      return;
    }

    await doImport(result.data!);
  }

  async function doImport(data: Parameters<typeof importSession>[0]) {
    try {
      const { sessionId } = await importSession(data);
      await resumeSession(sessionId);
    } catch (err) {
      setImportError(
        err instanceof Error ? err.message : "Failed to import session.",
      );
    }
  }

  async function confirmImportWithWarnings() {
    setShowImportWarning(false);
    if (pendingImportData) {
      await doImport(pendingImportData);
      setPendingImportData(null);
      setImportWarnings([]);
    }
  }

  function cancelImportWarning() {
    setShowImportWarning(false);
    setPendingImportData(null);
    setImportWarnings([]);
  }

  // Build grouped "New Document" submenu
  const visibleSchemas = filterSchemasByRole(registeredSchemas, role === "__all__" ? null : role);
  const groups = groupSchemasByCategory(visibleSchemas);

  // Mirrors Home: one submenu per category, each holding a submenu per document
  // set (with "Generate full set") followed by the category's ungrouped schemas.
  const schemaItem = (s: { id: string; title: string }): MenuItemDef => ({
    kind: "action",
    label: s.title,
    onClick: () => handleNewDocument({ type: "schema", schemaId: s.id }),
  });

  const newDocumentChildren: MenuItemDef[] = groups.map((group) => {
    const children: MenuItemDef[] = [];
    for (const sg of groupSchemasBySet(group.schemas)) {
      if (sg.set === null) {
        children.push(...sg.schemas.map(schemaItem));
        continue;
      }
      const setId = sg.set;
      children.push({
        kind: "submenu",
        label: setId,
        children: [
          {
            kind: "action",
            label: `Generate full set (${sg.schemas.length})`,
            onClick: () => handleNewDocument({ type: "set", setId }),
          },
          { kind: "divider" },
          ...sg.schemas.map(schemaItem),
        ],
      });
    }
    return {
      kind: "submenu",
      label: group.category?.label ?? "Other Documents",
      children,
    };
  });

  const menus: MenuDef[] = [
    {
      label: "File",
      items: [
        {
          kind: "submenu",
          label: "New Document",
          children: newDocumentChildren,
        },
        {
          kind: "action",
          label: "Manage Custom Templates…",
          onClick: () => navigate("/templates"),
        },
        { kind: "divider" },
        {
          kind: "action",
          label: "Save Progress…",
          onClick: handleSaveProgress,
          disabled: !session,
        },
        {
          kind: "action",
          label: "Load Progress…",
          onClick: handleLoadProgressClick,
        },
        {
          kind: "action",
          label: "Back Up or Restore All Data…",
          onClick: () => {
            setSettingsSection("backup");
            setShowSettings(true);
          },
        },
        { kind: "divider" },
        {
          kind: "action",
          label: "Clear Session",
          onClick: handleDeleteSession,
        },
      ],
    },
    {
      label: "Edit",
      items: [
        {
          kind: "action",
          label: "Clear All Answers",
          onClick: handleClearAnswers,
        },
        { kind: "divider" },
        {
          kind: "action",
          label: "Settings…",
          onClick: () => {
            setSettingsSection(undefined);
            setShowSettings(true);
          },
        },
      ],
    },
    {
      label: "View",
      items: [
        {
          kind: "action",
          label: "Go to Review",
          onClick: () => navigate("/review"),
        },
        {
          kind: "action",
          label: "Go to Generate",
          onClick: () => navigate("/preview"),
        },
        { kind: "divider" },
        {
          kind: "action",
          label: "Help",
          onClick: () => navigate("/docs/help/api-key-setup"),
        },
        {
          kind: "action",
          label: "Documentation",
          onClick: () => navigate("/docs/public/development-plan"),
        },
        { kind: "divider" },
        {
          kind: "action",
          label: "Contact & Feedback",
          onClick: () => navigate("/docs/help/contact"),
        },
        {
          kind: "action",
          label: "Copy Diagnostics",
          onClick: () => {
            void navigator.clipboard.writeText(
              buildDiagnosticsReport(collectDiagnosticsOptions(session?.documentTypeId)),
            );
          },
        },
        {
          kind: "action",
          label: "Get Update Notifications…",
          onClick: () => {
            window.location.href = MAILING_LIST_MAILTO;
          },
        },
      ],
    },
  ];

  const homeButton = (
    <button
      type="button"
      onClick={() => navigate("/")}
      className="mr-1 flex items-center gap-1 rounded-sm px-3 py-1 font-semibold hover:bg-gray-700"
      aria-label="Go to home page"
    >
      <span aria-hidden="true">⌂</span> Doc Builder
    </button>
  );

  return (
    <>
      <MenuBar menus={menus} leading={homeButton} />

      {/* Hidden file input for Load Progress */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".json"
        className="hidden"
        onChange={handleFileSelected}
      />

      <ConfirmDialog
        open={showConfirm}
        title="Discard current document?"
        message="You have unsaved answers in your current document. Starting a new document will discard all progress."
        confirmLabel="Discard & Start New"
        cancelLabel="Cancel"
        secondaryLabel="Save Progress"
        destructive
        onConfirm={confirmSwitch}
        onCancel={cancelSwitch}
        onSecondary={saveAndSwitch}
      />

      {/* Clear Session confirmation */}
      <ConfirmDialog
        open={showClearConfirm}
        title="Discard progress?"
        message="Clearing the session will discard all answers and progress."
        confirmLabel="Clear Session"
        cancelLabel="Cancel"
        secondaryLabel="Save Progress"
        destructive
        onConfirm={confirmClearSession}
        onCancel={() => setShowClearConfirm(false)}
        onSecondary={saveAndClearSession}
      />

      {/* Clear All Answers confirmation */}
      <ConfirmDialog
        open={showClearAnswersConfirm}
        title="Clear all answers?"
        message="This will reset all fields to empty."
        confirmLabel="Clear Answers"
        cancelLabel="Cancel"
        secondaryLabel="Save Progress"
        destructive
        onConfirm={confirmClearAnswers}
        onCancel={() => setShowClearAnswersConfirm(false)}
        onSecondary={saveAndClearAnswers}
      />

      {/* Import error dialog */}
      <ConfirmDialog
        open={!!importError}
        title="Import Error"
        message={importError ?? ""}
        confirmLabel="OK"
        cancelLabel=""
        onConfirm={() => setImportError(null)}
        onCancel={() => setImportError(null)}
      />

      {/* Save error dialog */}
      <ConfirmDialog
        open={!!saveError}
        title="Save Error"
        message={saveError ?? ""}
        confirmLabel="OK"
        cancelLabel=""
        onConfirm={() => setSaveError(null)}
        onCancel={() => setSaveError(null)}
      />

      {/* Import warnings dialog */}
      <ConfirmDialog
        open={showImportWarning}
        title="Import Warning"
        message={importWarnings.join("\n\n") + "\n\nDo you want to continue?"}
        confirmLabel="Import Anyway"
        cautious
        cancelLabel="Cancel"
        onConfirm={confirmImportWithWarnings}
        onCancel={cancelImportWarning}
      />

      <SettingsDialog
        open={showSettings}
        onClose={() => {
          setShowSettings(false);
          setSettingsSection(undefined);
        }}
        initialSection={settingsSection}
      />
    </>
  );
}
