import { describe, it, expect, vi } from "vitest";
import { useState } from "react";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import NumberInput from "./NumberInput";
import type { NumberFormat } from "../schemas/types";

/** Controlled harness: stores whatever NumberInput reports, like the wizard does. */
function Harness({ initial = "", format, onStore }: { initial?: string | number; format?: NumberFormat; onStore?: (v: string | number) => void }) {
  const [value, setValue] = useState<string | number>(initial);
  return (
    <>
      <NumberInput
        aria-label="Rate"
        value={value}
        format={format}
        onChange={(v) => {
          setValue(v);
          onStore?.(v);
        }}
      />
      <button type="button">elsewhere</button>
    </>
  );
}

const input = () => screen.getByLabelText("Rate") as HTMLInputElement;

describe("NumberInput", () => {
  it("is a decimal text box, not a native number input", () => {
    render(<Harness />);
    expect(input().type).toBe("text");
    expect(input()).toHaveAttribute("inputmode", "decimal");
  });

  it("stores the parsed number and keeps the text as typed", async () => {
    const onStore = vi.fn();
    render(<Harness onStore={onStore} />);
    await userEvent.type(input(), "1,234.50");
    expect(onStore).toHaveBeenLastCalledWith(1234.5);
    expect(input().value).toBe("1,234.50");
  });

  it("ignores dollar signs", async () => {
    const onStore = vi.fn();
    render(<Harness onStore={onStore} />);
    await userEvent.type(input(), "$2,000");
    expect(onStore).toHaveBeenLastCalledWith(2000);
  });

  it("stores text that isn't a number as-is, so it can be flagged", async () => {
    const onStore = vi.fn();
    render(<Harness onStore={onStore} />);
    await userEvent.type(input(), "1234,5");
    expect(onStore).toHaveBeenLastCalledWith("1234,5");
    expect(input().value).toBe("1234,5");
  });

  it("stores an empty string when cleared", async () => {
    const onStore = vi.fn();
    render(<Harness initial={42} onStore={onStore} />);
    await userEvent.clear(input());
    expect(onStore).toHaveBeenLastCalledWith("");
  });

  it("reformats currency on blur and shows the formatted text on refocus", async () => {
    render(<Harness format="currency" />);
    await userEvent.type(input(), "1234.5");
    expect(input().value).toBe("1234.5");
    await userEvent.click(screen.getByText("elsewhere"));
    expect(input().value).toBe("1,234.50");
    await userEvent.click(input());
    expect(input().value).toBe("1,234.50");
  });

  it("shows stored currency values formatted", () => {
    render(<Harness initial={50000} format="currency" />);
    expect(input().value).toBe("50,000.00");
  });

  it("leaves non-currency numbers and invalid text unformatted on blur", async () => {
    render(<Harness format="number" />);
    await userEvent.type(input(), "1234.5");
    await userEvent.click(screen.getByText("elsewhere"));
    expect(input().value).toBe("1234.5");

    render(<Harness format="currency" />);
    const second = screen.getAllByLabelText("Rate")[1] as HTMLInputElement;
    await userEvent.type(second, "abc");
    await userEvent.click(screen.getAllByText("elsewhere")[1]);
    expect(second.value).toBe("abc");
  });

  it("shows external value changes (e.g. an AI insert)", () => {
    const { rerender } = render(<NumberInput aria-label="Rate" value={10} onChange={() => {}} />);
    rerender(<NumberInput aria-label="Rate" value={25} onChange={() => {}} />);
    expect(input().value).toBe("25");
  });

  it("keeps the user's text while focused when the stored value matches it", async () => {
    const onChange = vi.fn();
    const { rerender } = render(<NumberInput aria-label="Rate" value="" onChange={onChange} />);
    await userEvent.type(input(), "1,000");
    rerender(<NumberInput aria-label="Rate" value={1000} onChange={onChange} />);
    expect(input().value).toBe("1,000");
    // A genuinely different value replaces the draft even while focused.
    rerender(<NumberInput aria-label="Rate" value={7} onChange={onChange} />);
    expect(input().value).toBe("7");
  });

  it("does not change when read-only", async () => {
    const onChange = vi.fn();
    render(<NumberInput aria-label="Rate" value={5} readOnly onChange={onChange} />);
    await userEvent.type(input(), "9");
    expect(onChange).not.toHaveBeenCalled();
    expect(input()).toHaveAttribute("readonly");
  });
});
