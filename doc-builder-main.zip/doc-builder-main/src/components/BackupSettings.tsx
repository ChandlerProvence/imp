import { useContext, useRef, useState } from "react";
import { SessionContext } from "../context/SessionContext";
import {
  BACKUP_STALE_DAYS,
  daysSinceBackup,
  downloadBackup,
  getCurrentSummary,
  restoreBackup,
  validateBackup,
  type BackupSummary,
  type ParsedBackup,
} from "../db/backup";
import { isAnotherTabActive } from "../hooks/useTabLock";
import { toAppError, type AppError } from "../errors";
import AppErrorBox from "./AppErrorBox";

const plural = (n: number, word: string) => `${n} ${word}${n === 1 ? "" : "s"}`;

function describeSummary(s: BackupSummary): string {
  return [plural(s.sessions, "session"), plural(s.documents, "uploaded document"), plural(s.templates, "custom template")].join(", ");
}

function lastBackupText(days: number | null): string {
  if (days === null) return "Never";
  if (days === 0) return "Today";
  return days === 1 ? "Yesterday" : `${days} days ago`;
}

function CuiWarning({ count }: { count: number }) {
  if (count === 0) return null;
  return (
    <p role="alert" className="mt-2 rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-xs text-amber-900">
      ⚠️ {plural(count, "document")} {count === 1 ? "is" : "are"} marked or flagged as CUI. The backup file will contain{" "}
      {count === 1 ? "it" : "them"} — store it only where you are allowed to keep the original CUI documents.
    </p>
  );
}

type Mode =
  | { kind: "idle" }
  | { kind: "confirm-backup"; summary: BackupSummary }
  | { kind: "confirm-restore"; backup: ParsedBackup; otherTab: boolean }
  | { kind: "working"; label: string };

/**
 * Settings section for whole-database backup and restore. Restoring replaces
 * all data in this browser (API keys excepted) and reloads the page.
 */
export default function BackupSettings() {
  // Nullable so the dialog also renders outside a SessionProvider (tests)
  const sessionCtx = useContext(SessionContext);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [mode, setMode] = useState<Mode>({ kind: "idle" });
  const [backupFirst, setBackupFirst] = useState(true);
  const [error, setError] = useState<AppError | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [days, setDays] = useState(() => daysSinceBackup());

  function reset() {
    setMode({ kind: "idle" });
    setError(null);
    setNotice(null);
  }

  async function startBackup() {
    reset();
    try {
      setMode({ kind: "confirm-backup", summary: await getCurrentSummary() });
    } catch (err) {
      setMode({ kind: "idle" });
      setError(toAppError(err, { domain: "db" }));
    }
  }

  async function saveBackup() {
    setMode({ kind: "working", label: "Saving backup…" });
    try {
      const saved = await downloadBackup();
      setMode({ kind: "idle" });
      if (saved) {
        setDays(daysSinceBackup());
        setNotice("Backup saved.");
      }
    } catch (err) {
      setMode({ kind: "idle" });
      setError(toAppError(err, { domain: "db" }));
    }
  }

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    reset();
    setMode({ kind: "working", label: "Checking backup…" });
    try {
      const result = await validateBackup(await file.text());
      if (!result.ok) {
        setMode({ kind: "idle" });
        setError(result.error);
        return;
      }
      const otherTab = isAnotherTabActive() || Boolean(sessionCtx?.isLockedByOtherTab);
      setBackupFirst(true);
      setMode({ kind: "confirm-restore", backup: result.backup, otherTab });
    } catch (err) {
      setMode({ kind: "idle" });
      setError(toAppError(err, { domain: "file", context: { fileName: file.name } }));
    }
  }

  async function confirmRestore(backup: ParsedBackup) {
    try {
      if (backupFirst) {
        setMode({ kind: "working", label: "Backing up current data…" });
        if (!(await downloadBackup())) {
          setMode({ kind: "idle" });
          setNotice("Restore cancelled — your current data wasn't backed up, so nothing was changed.");
          return;
        }
      }
      setMode({ kind: "working", label: "Restoring…" });
      // A debounced save landing after the restore would overwrite restored answers
      sessionCtx?.cancelPendingSave();
      await restoreBackup(backup);
      window.location.reload();
    } catch (err) {
      setMode({ kind: "idle" });
      setError(toAppError(err, { domain: "db" }));
    }
  }

  const buttonClass =
    "rounded-md border border-gray-300 bg-white px-3 py-2 text-xs font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50";
  const busy = mode.kind === "working";
  const stale = days === null || days > BACKUP_STALE_DAYS;

  return (
    <div>
      <span className="block text-sm font-medium text-gray-700 mb-1">Your data</span>
      <p className="text-xs text-gray-500">
        Save your sessions, AI chats, uploaded documents, custom templates, and settings to one file, so you can get them
        back after a browser reset or on another computer. API keys are not included.
      </p>
      <p
        className={`mt-1 text-xs font-medium ${stale ? "text-red-600" : "text-gray-700"}`}
        data-testid="last-backup"
      >
        Last backup: {lastBackupText(days)}
      </p>
      <div className="mt-2 flex gap-2">
        <button type="button" onClick={startBackup} disabled={busy} className={buttonClass}>
          Back up all data…
        </button>
        <button type="button" onClick={() => fileInputRef.current?.click()} disabled={busy} className={buttonClass}>
          Restore from backup…
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept=".json,application/json"
          onChange={handleFile}
          className="hidden"
          data-testid="backup-file-input"
        />
      </div>

      {mode.kind === "working" && <p className="mt-2 text-xs text-gray-500">{mode.label}</p>}
      {notice && <p className="mt-2 text-xs text-green-700">{notice}</p>}
      {error && <AppErrorBox error={error} className="mt-2" />}

      {mode.kind === "confirm-backup" && (
        <div className="mt-3 rounded-md border border-gray-200 bg-gray-50 p-3">
          <p className="text-xs text-gray-700">The backup will include {describeSummary(mode.summary)}.</p>
          <CuiWarning count={mode.summary.cuiDocuments} />
          <div className="mt-3 flex justify-end gap-2">
            <button type="button" onClick={reset} className={buttonClass}>
              Cancel
            </button>
            <button
              type="button"
              onClick={saveBackup}
              className="rounded-md bg-blue-600 px-3 py-2 text-xs font-medium text-white hover:bg-blue-700"
            >
              Save backup
            </button>
          </div>
        </div>
      )}

      {mode.kind === "confirm-restore" && (
        <div className="mt-3 rounded-md border border-red-200 bg-red-50 p-3">
          <p className="text-xs font-medium text-red-800">This replaces all data in this browser.</p>
          <p className="mt-1 text-xs text-gray-700">
            Backup from {mode.backup.exportedAt ? new Date(mode.backup.exportedAt).toLocaleString() : "an unknown date"}:{" "}
            {describeSummary(mode.backup.summary)}. Your current sessions, documents, templates, and settings will be
            removed. API keys stay as they are.
          </p>
          <CuiWarning count={mode.backup.summary.cuiDocuments} />
          {mode.backup.warnings.map((w) => (
            <p key={w} className="mt-2 text-xs text-amber-800">
              {w}
            </p>
          ))}
          {mode.otherTab && (
            <p className="mt-2 text-xs font-medium text-red-800">
              Doc Builder is open in another tab. Close it before restoring, or it may save over the restored data.
            </p>
          )}
          <label className="mt-3 flex items-center gap-2 text-xs text-gray-700">
            <input type="checkbox" checked={backupFirst} onChange={(e) => setBackupFirst(e.target.checked)} />
            Back up current data first
          </label>
          <div className="mt-3 flex justify-end gap-2">
            <button type="button" onClick={reset} className={buttonClass}>
              Cancel
            </button>
            <button
              type="button"
              onClick={() => confirmRestore(mode.backup)}
              className="rounded-md bg-red-600 px-3 py-2 text-xs font-medium text-white hover:bg-red-700"
            >
              Replace all data
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
