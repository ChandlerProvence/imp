import { ENDPOINTS } from "../ai/endpoints";
import type { EndpointId } from "../ai/endpoints";

interface Props {
  endpoint?: EndpointId;
}

/**
 * Small non-interactive pill showing which endpoint was active when a document
 * was uploaded. Amber for CUI, blue for Proprietary. Renders nothing if
 * endpoint is undefined (legacy docs uploaded before tracking was added).
 */
export default function DocumentEndpointBadge({ endpoint }: Props) {
  if (!endpoint) return null;

  const config = ENDPOINTS[endpoint];
  const isCui = endpoint === "cui";

  return (
    <span
      className={`inline-flex items-center rounded-full px-1.5 py-0.5 text-[10px] font-medium ring-1 ring-inset flex-shrink-0 ${
        isCui
          ? "bg-amber-50 text-amber-700 ring-amber-200"
          : "bg-blue-50 text-blue-700 ring-blue-200"
      }`}
      title={`Uploaded via ${config.label}`}
    >
      {config.shortLabel}
    </span>
  );
}
