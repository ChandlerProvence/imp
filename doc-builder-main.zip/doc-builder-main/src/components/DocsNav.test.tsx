import { describe, it, expect, vi } from "vitest";
import { screen, fireEvent } from "@testing-library/react";
import { Routes, Route, useLocation } from "react-router-dom";
import DocsNav from "./DocsNav";
import { renderWithProviders } from "../test/renderWithProviders";
import { buildDocIndex } from "../docs/docsRegistry";

const docs = buildDocIndex({
  "docs/public/development-plan.md": "# Development Plan\n\nRoadmap and sustainment.",
  "docs/public/runbook.md": "# Troubleshooting Runbook\n\nWhat to do on a 401.",
  "docs/help/attachments.md": "# Attachments\n\nDrag files in.",
  "docs/help/settings.md": "# Settings Panel\n",
});

function LocationProbe() {
  return <div data-testid="location">{useLocation().pathname}</div>;
}

function renderNav(activeId = "help/attachments") {
  return renderWithProviders(
    <Routes>
      <Route
        path="*"
        element={
          <>
            <DocsNav activeId={activeId} onCollapse={vi.fn()} docs={docs} />
            <LocationProbe />
          </>
        }
      />
    </Routes>,
    { routerEntries: [`/docs/${activeId}`] },
  );
}

describe("DocsNav", () => {
  it("lists docs grouped under Help and Project", () => {
    renderNav();
    expect(screen.getByRole("button", { name: /^›\s*Help/ })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /^›\s*Project/ })).toBeInTheDocument();
    expect(screen.getByText("Troubleshooting Runbook")).toBeInTheDocument();
    expect(screen.getByText("Settings Panel")).toBeInTheDocument();
  });

  it("marks the active doc", () => {
    renderNav("help/attachments");
    const active = screen.getByText("Attachments").closest("button");
    expect(active).toHaveAttribute("aria-current", "page");
  });

  it("filters by title and flags content-only matches", () => {
    renderNav();
    const input = screen.getByLabelText("Filter docs");

    fireEvent.change(input, { target: { value: "runbook" } });
    expect(screen.getByText("Troubleshooting Runbook")).toBeInTheDocument();
    expect(screen.queryByText("Attachments")).not.toBeInTheDocument();
    expect(screen.getByText("1 of 4")).toBeInTheDocument();

    fireEvent.change(input, { target: { value: "401" } });
    expect(screen.getByText("Troubleshooting Runbook")).toBeInTheDocument();
    expect(screen.getByText("in text")).toBeInTheDocument();

    fireEvent.change(input, { target: { value: "zzz-nothing" } });
    expect(screen.getByText("No matches")).toBeInTheDocument();
  });

  it("collapses a group", () => {
    renderNav();
    fireEvent.click(screen.getByRole("button", { name: /^›\s*Help/ }));
    expect(screen.queryByText("Settings Panel")).not.toBeInTheDocument();
    expect(screen.getByText("Development Plan")).toBeInTheDocument();
  });

  it("navigates when an entry is clicked", () => {
    renderNav();
    fireEvent.click(screen.getByText("Development Plan"));
    expect(screen.getByTestId("location")).toHaveTextContent("/docs/public/development-plan");
  });
});
