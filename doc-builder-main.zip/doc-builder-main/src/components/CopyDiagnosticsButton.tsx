import { useState } from "react";
import { buildDiagnosticsReport } from "../errors/formatDiagnostics";
import { collectDiagnosticsOptions } from "./diagnosticsOptions";

/**
 * Button that copies a structured diagnostic report to the clipboard.
 * Used on crash/recovery pages (ErrorBoundary, StorageUnavailable) and in the
 * Settings footer, so users can send context to an administrator or AI
 * assistant whether or not an error is on screen.
 */
export default function CopyDiagnosticsButton({
  schemaId,
  className = "",
}: {
  /** Include the active schema in the report, if known. */
  schemaId?: string;
  className?: string;
}) {
  const [copied, setCopied] = useState(false);

  function handleCopy() {
    const report = buildDiagnosticsReport(collectDiagnosticsOptions(schemaId));
    navigator.clipboard.writeText(report).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }

  return (
    <button
      type="button"
      onClick={handleCopy}
      className={`inline-flex items-center gap-1 rounded border border-gray-300 bg-white px-3 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-100 transition-colors ${className}`.trim()}
    >
      {copied ? (
        <>
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" className="w-3.5 h-3.5 text-green-600">
            <path fillRule="evenodd" d="M12.416 3.376a.75.75 0 0 1 .208 1.04l-5 7.5a.75.75 0 0 1-1.154.114l-3-3a.75.75 0 0 1 1.06-1.06l2.353 2.353 4.493-6.74a.75.75 0 0 1 1.04-.207Z" clipRule="evenodd" />
          </svg>
          Copied!
        </>
      ) : (
        <>
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" className="w-3.5 h-3.5">
            <path d="M5.5 3.5A1.5 1.5 0 0 1 7 2h2.879a1.5 1.5 0 0 1 1.06.44l2.122 2.12a1.5 1.5 0 0 1 .439 1.061V9.5A1.5 1.5 0 0 1 12 11V3.5H5.5Z" />
            <path d="M3.5 5.5A1.5 1.5 0 0 1 5 4h3.379a1.5 1.5 0 0 1 1.06.44l2.122 2.12a1.5 1.5 0 0 1 .439 1.061V11.5A1.5 1.5 0 0 1 10.5 13H5a1.5 1.5 0 0 1-1.5-1.5v-6Z" />
          </svg>
          Copy diagnostics
        </>
      )}
    </button>
  );
}
