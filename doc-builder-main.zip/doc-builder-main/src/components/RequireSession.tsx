import { Navigate, Outlet, useParams } from "react-router-dom";
import { useSessionContext } from "../context/SessionContext";

/**
 * Route guard: redirects to Home if no active session matches the URL's docTypeId.
 * Centralizes the "is this route valid?" check so individual pages don't each
 * implement their own schema-resolution/redirect logic.
 */
export default function RequireSession() {
  const { docTypeId } = useParams<{ docTypeId: string }>();
  const { session, schema, loading } = useSessionContext();

  if (loading) return null;

  if (!session || !schema || !docTypeId || schema.id !== docTypeId) {
    return <Navigate to="/" replace />;
  }

  return <Outlet />;
}
