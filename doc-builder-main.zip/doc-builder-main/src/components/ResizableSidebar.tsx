import { useCallback, useEffect, useRef, useState } from "react";

interface Props {
  children: React.ReactNode;
  /** Default width in pixels. */
  defaultWidth?: number;
  /** Minimum width in pixels. */
  minWidth?: number;
  /** Maximum width in pixels. */
  maxWidth?: number;
}

const STORAGE_KEY = "doc-builder:sidebar-width";

export default function ResizableSidebar({
  children,
  defaultWidth = 220,
  minWidth = 140,
  maxWidth = 400,
}: Props) {
  const [width, setWidth] = useState(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed = parseInt(stored, 10);
      if (!isNaN(parsed) && parsed >= minWidth && parsed <= maxWidth) return parsed;
    }
    return defaultWidth;
  });

  const dragging = useRef(false);
  const startX = useRef(0);
  const startWidth = useRef(0);

  const handleMouseDown = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      dragging.current = true;
      startX.current = e.clientX;
      startWidth.current = width;
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
    },
    [width],
  );

  // Stable listeners — no deps on `width` to avoid re-registering on every pixel
  useEffect(() => {
    function handleMouseMove(e: MouseEvent) {
      if (!dragging.current) return;
      const delta = e.clientX - startX.current;
      const newWidth = Math.min(maxWidth, Math.max(minWidth, startWidth.current + delta));
      setWidth(newWidth);
    }

    function handleMouseUp() {
      if (!dragging.current) return;
      dragging.current = false;
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
      // Persist once on drop — read current width from the DOM to avoid stale closure
      const el = document.querySelector<HTMLElement>(`[data-sidebar-resize]`);
      if (el) localStorage.setItem(STORAGE_KEY, el.style.width.replace("px", ""));
    }

    document.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("mouseup", handleMouseUp);
    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
    };
  }, [minWidth, maxWidth]);

  return (
    <div
      data-sidebar-resize
      className="relative flex h-full shrink-0"
      style={{ width }}
    >
      {/* Sidebar content */}
      {/* Flex column so children size via flex-1/min-h-0 rather than h-full percentages */}
      <div className="flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden">{children}</div>

      {/* Resize handle */}
      <div
        onMouseDown={handleMouseDown}
        className="absolute top-0 right-0 w-1 h-full cursor-col-resize hover:bg-blue-400 active:bg-blue-500 transition-colors z-10"
      />
    </div>
  );
}
