import { describe, it, expect, vi, beforeEach } from "vitest";
import { renderHook, act, waitFor } from "@testing-library/react";
import type { ReactNode } from "react";
import { MemoryRouter } from "react-router-dom";
import type { Session } from "../db/types";
import { schemaList } from "../schemas/loader";

const schema = schemaList.find((s) => !s.set) ?? schemaList[0];

function makeSession(id: string, answers: Session["answers"] = {}): Session {
  return {
    id,
    documentTypeId: schema.id,
    answers,
    currentSection: schema.sections[0].id,
    sectionConfirmed: {},
  } as Session;
}

const sessions: Record<string, Session> = {
  A: makeSession("A"),
  B: makeSession("B", { "x.y": "kept" }),
};

vi.mock("../db/session", () => ({
  createSession: vi.fn(),
  createSetSession: vi.fn(),
  deleteSession: vi.fn().mockResolvedValue(undefined),
  getLatestSession: vi.fn(() => Promise.resolve(sessions.A)),
  getSession: vi.fn((id: string) => Promise.resolve(sessions[id])),
  updateSession: vi.fn().mockResolvedValue(undefined),
}));

import { updateSession } from "../db/session";
import { SessionProvider, useSessionContext } from "./SessionContext";

const wrapper = ({ children }: { children: ReactNode }) => (
  <MemoryRouter>
    <SessionProvider>{children}</SessionProvider>
  </MemoryRouter>
);

const DEBOUNCE_MS = 300;
const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** Answer writes per session id, in call order. */
function answerWrites(): { id: string; answers: Session["answers"] }[] {
  return vi.mocked(updateSession).mock.calls
    .filter(([, patch]) => "answers" in patch)
    .map(([id, patch]) => ({ id, answers: patch.answers! }));
}

async function setup() {
  const hook = renderHook(() => useSessionContext(), { wrapper });
  await waitFor(() => expect(hook.result.current.session?.id).toBe("A"));
  vi.mocked(updateSession).mockClear();
  return hook;
}

describe("SessionProvider answer persistence", () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it("does not let a pending debounced save overwrite a later batch", async () => {
    const { result } = await setup();

    act(() => result.current.setAnswer("s.typed", "typed"));
    act(() => result.current.setAnswersBatch({ "s.batch": "batch" }));
    await act(() => wait(DEBOUNCE_MS + 50));

    const writes = answerWrites();
    expect(writes.at(-1)!.answers).toMatchObject({ "s.typed": "typed", "s.batch": "batch" });
  });

  it("saves a pending edit to its own session, not the one switched to", async () => {
    const { result } = await setup();

    act(() => result.current.setAnswer("s.typed", "typed"));
    await act(() => result.current.resumeSession("B"));
    await act(() => wait(DEBOUNCE_MS + 50));

    const writes = answerWrites();
    expect(writes).toContainEqual({ id: "A", answers: expect.objectContaining({ "s.typed": "typed" }) });
    expect(writes.filter((w) => w.id === "B" && "s.typed" in w.answers)).toEqual([]);
  });

  it("does not restore answers after they are cleared", async () => {
    const { result } = await setup();

    act(() => result.current.setAnswer("s.typed", "typed"));
    await act(() => result.current.clearAnswers());
    await act(() => wait(DEBOUNCE_MS + 50));

    expect(answerWrites().at(-1)!.answers).toEqual({});
  });
});
