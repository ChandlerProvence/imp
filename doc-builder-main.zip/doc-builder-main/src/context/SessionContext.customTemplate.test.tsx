import { describe, it, expect } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { SessionProvider, useSessionContext } from "./SessionContext";
import { db } from "../db/dexie";
import { createSession } from "../db/session";
import { getSchema } from "../schemas/loader";
import { validateUserTemplatePair, toArrayBuffer } from "../schemas/userTemplateValidation";
import { buildDocx, para } from "../test/docxFixtures";

function Probe() {
  const { loading, schema } = useSessionContext();
  return <div data-testid="probe">{loading ? "loading" : (schema?.id ?? "none")}</div>;
}

describe("SessionProvider with a custom template", () => {
  it("restores the latest session after loading uploaded templates from IndexedDB", async () => {
    const { prepared } = await validateUserTemplatePair({
      schemaText: JSON.stringify({
        id: "vendor-letter",
        title: "Vendor Letter",
        version: 1,
        docx_template: "x.docx",
        sections: [{ id: "main", title: "Main", fields: [{ id: "vendor", label: "Vendor", type: "string", required: true }] }],
        template_key_map: { VENDOR: "main.vendor" },
      }),
      docx: buildDocx(para("{{VENDOR}}")),
    });
    const now = new Date().toISOString();
    // Stored directly: the in-memory registry starts without it, as on a cold page load
    await db.userTemplates.put({
      id: prepared!.id,
      originalId: prepared!.originalId,
      schema: prepared!.schema,
      docx: toArrayBuffer(prepared!.docx),
      docxSha256: prepared!.docxSha256,
      revision: 1,
      createdAt: now,
      updatedAt: now,
    });
    await createSession("custom-vendor-letter", "main");
    expect(getSchema("custom-vendor-letter")).toBeUndefined();

    render(
      <MemoryRouter>
        <SessionProvider>
          <Probe />
        </SessionProvider>
      </MemoryRouter>,
    );

    await waitFor(() => expect(screen.getByTestId("probe").textContent).toBe("custom-vendor-letter"));
  });
});
