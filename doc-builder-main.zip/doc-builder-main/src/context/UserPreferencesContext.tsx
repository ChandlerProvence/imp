import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
} from "react";

const ROLE_STORAGE_KEY = "doc-builder:user-role";
const PROFILE_STORAGE_KEY = "doc-builder:user-profile";

/** Cached user identity (preparer info) for auto-filling new sessions. */
export interface UserProfile {
  name: string;
  title: string;
  phone: string;
  email: string;
}

export interface UserPreferencesContextValue {
  /** Currently selected role ID, or null if none chosen. */
  role: string | null;
  /** Update the selected role. Persists to localStorage. */
  setRole: (roleId: string | null) => void;
  /** Cached user profile for auto-fill, or null if not yet configured. */
  profile: UserProfile | null;
  /** Update the cached user profile. Persists to localStorage. */
  setProfile: (profile: UserProfile | null) => void;
}

/**
 * Read the cached user profile directly from localStorage (synchronous).
 * Use this outside of React component trees (e.g., in SessionContext callbacks).
 */
export function getUserProfile(): UserProfile | null {
  const raw = localStorage.getItem(PROFILE_STORAGE_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as UserProfile;
  } catch {
    return null;
  }
}

export const UserPreferencesContext =
  createContext<UserPreferencesContextValue | null>(null);

export function useUserPreferences(): UserPreferencesContextValue {
  const ctx = useContext(UserPreferencesContext);
  if (!ctx) {
    throw new Error(
      "useUserPreferences must be used within UserPreferencesProvider",
    );
  }
  return ctx;
}

export function UserPreferencesProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [role, setRoleState] = useState<string | null>(() => {
    return localStorage.getItem(ROLE_STORAGE_KEY);
  });

  const [profile, setProfileState] = useState<UserProfile | null>(() => {
    return getUserProfile();
  });

  const setRole = useCallback((roleId: string | null) => {
    if (roleId) {
      localStorage.setItem(ROLE_STORAGE_KEY, roleId);
    } else {
      localStorage.removeItem(ROLE_STORAGE_KEY);
    }
    setRoleState(roleId);
  }, []);

  const setProfile = useCallback((p: UserProfile | null) => {
    if (p) {
      localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(p));
    } else {
      localStorage.removeItem(PROFILE_STORAGE_KEY);
    }
    setProfileState(p);
  }, []);

  const value = useMemo(
    () => ({ role, setRole, profile, setProfile }),
    [role, setRole, profile, setProfile],
  );

  return (
    <UserPreferencesContext.Provider value={value}>
      {children}
    </UserPreferencesContext.Provider>
  );
}
