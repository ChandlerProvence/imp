import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";

vi.mock("../db/session", () => ({
  createSession: vi.fn(),
  createSetSession: vi.fn(),
  deleteSession: vi.fn(),
  getLatestSession: vi.fn().mockRejectedValue(
    Object.assign(new Error("open failed"), {
      name: "OpenFailedError",
      inner: Object.assign(new Error("IndexedDB API missing"), { name: "MissingAPIError" }),
    }),
  ),
  getSession: vi.fn(),
  updateSession: vi.fn().mockResolvedValue(undefined),
}));

import { SessionProvider } from "./SessionContext";

describe("SessionProvider init failure", () => {
  it("shows the storage recovery page instead of hanging on the loader", async () => {
    vi.spyOn(console, "error").mockImplementation(() => {});
    render(
      <MemoryRouter>
        <SessionProvider>
          <div>app content</div>
        </SessionProvider>
      </MemoryRouter>,
    );

    expect(await screen.findByText("Doc Builder can't load your saved work")).toBeInTheDocument();
    expect(screen.getByText(/private\/InPrivate browsing/)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Clear data/ })).toBeInTheDocument();
    expect(screen.queryByText("app content")).toBeNull();
  });
});
