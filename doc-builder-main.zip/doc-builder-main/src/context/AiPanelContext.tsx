import type { AppError } from "../errors";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { useLocation } from "react-router-dom";
import type { DocumentSchema } from "../schemas/types";
import type { BulkEditRequest, ProposedChange } from "../ai/bulkEdit";
import type { DetectedObservation } from "../ai/observationTypes";
import type { PendingQuestion, QuestionAnswer } from "../ai/askUserTypes";
import type { ResponseStep } from "../ai/types";
import type { AiScope } from "../ai/unifiedPrompt";
import { buildUnifiedSystemPrompt, getScopedSectionIds, sectionIdFromPath } from "../ai/unifiedPrompt";
import { inferMultiselectGateUpdates } from "../engine/visibility";
import { AI_TOOLS } from "../ai/toolDefinitions";
import {
  GENERAL_CHAT_ENABLED,
  GENERAL_CHAT_SCHEMA,
  GENERAL_CHAT_SESSION_ID,
  GENERAL_TOOLS,
  buildGeneralChatSystemPrompt,
} from "../ai/generalChat";
import { buildDocumentOutline } from "../ai/documentReviewPrompt";
import {
  getOrBuildCache,
  queryByFieldKey,
  queryByLineRange,
  queryBySearch,
} from "../ai/templateTextService";
import { useAiChat } from "../hooks/useAiChat";
import type { AiChatMessage, SendMessageOptions } from "../hooks/useAiChat";
import { useDocumentManager } from "../hooks/useDocumentManager";
import type { UseDocumentManagerReturn } from "../hooks/useDocumentManager";
import { useSessionContext } from "./SessionContext";
import { useAiConfig } from "./AiConfigContext";
import { deleteConversation, getConversationsForSession } from "../db/chatHistory";
import type { Conversation } from "../db/types";
import { trackWrite } from "../db/writeStatus";
import { effectiveDraftingStyle } from "../schemas/schemaFeatures";
import { prepIdFromPath } from "../pages/prep/prepPages";
import { useStyleReference, type DraftingStylePatch, type StyleReferenceState } from "../hooks/useStyleReference";
import type { EffortTier } from "../ai/effortTiers";

// ---------------------------------------------------------------------------
// Context types
// ---------------------------------------------------------------------------

export interface AiPanelContextValue {
  // Panel visibility
  panelOpen: boolean;
  setPanelOpen: (open: boolean) => void;
  togglePanel: () => void;

  // Scope
  scope: AiScope;
  setScope: (scope: AiScope) => void;

  // Chat state (from useAiChat)
  messages: AiChatMessage[];
  isStreaming: boolean;
  isThinking: boolean;
  streamingContent: string | null;
  isSearching: boolean;
  retrievalMeta: { chunkCount: number; docCount: number } | null;
  error: AppError | null;
  sendMessage: (text: string, displayLabel?: string, options?: SendMessageOptions) => void;
  stopStreaming: () => void;

  // Proposed changes
  proposedChanges: ProposedChange[];
  toggleChange: (index: number) => void;
  acceptAll: () => void;
  rejectAll: () => void;
  applyChanges: () => void;

  // Document manager (exposed for the DocumentPicker)
  docManager: UseDocumentManagerReturn;
  /** Style analysis status, plus re-analyze and clear. */
  styleReference: StyleReferenceState;
  /** Drafting style sent to the AI: the session's note. */
  draftingStyle: string | undefined;

  // Conversation management
  activeConvKey: string;
  chatInstanceKey: number;
  onNewChat: () => void;
  onSelectConversation: (conv: Conversation) => void;
  /** Delete a conversation; if it is the active one, start a new chat. */
  onDeleteConversation: (conv: Conversation) => Promise<void>;
  /** Start a new chat that auto-sends an initial message once the conversation initializes. */
  startNewChatWithMessage: (content: string, displayLabel?: string) => void;

  // Detected observations (conflicts, gaps, assumptions)
  detectedObservations: DetectedObservation[];
  clearObservations: () => void;

  // Pending ask_user question (multiple-choice) awaiting the user's answer
  pendingQuestion: PendingQuestion | null;
  answerQuestion: (answers: QuestionAnswer[]) => void;

  // Tab state
  activeTab: "chat" | "changes" | "observations";
  setActiveTab: (tab: "chat" | "changes" | "observations") => void;
  hasUnseenChanges: boolean;
  hasUnseenObservations: boolean;

  // Effort tier
  effortTier: EffortTier;
  setEffortTier: (tier: EffortTier) => void;

  // Live step timing (real-time activity display)
  completedSteps: ResponseStep[];
  activeStepKind: ResponseStep["kind"] | null;

  // System prompt override (e.g., review prompt set by "Review with AI" button).
  // Scoped to the conversation — cleared on new chat.
  setSystemPromptOverride: (prompt: string | null) => void;

  // Pre-fill text for ChatInput (e.g., review prompt from Preview page)
  prefillText: string | null;
  setPrefillText: (text: string | null) => void;
  clearPrefill: () => void;

  // Whether there's an active session (panel shows placeholder if not)
  hasActiveSession: boolean;
}

// ---------------------------------------------------------------------------
// Context
// ---------------------------------------------------------------------------

const AiPanelContext = createContext<AiPanelContextValue | null>(null);

export function useAiPanelContext(): AiPanelContextValue {
  const ctx = useContext(AiPanelContext);
  if (!ctx) {
    throw new Error("useAiPanelContext must be used within AiPanelProvider");
  }
  return ctx;
}

// ---------------------------------------------------------------------------
// Provider
// ---------------------------------------------------------------------------

const PANEL_OPEN_KEY = "doc-builder:ai-panel-open";

export function AiPanelProvider({ children }: { children: ReactNode }) {
  const {
    session,
    schema,
    answers,
    fieldMeta,
    setAnswersBatch,
    setFieldMetaBatch,
    isSetSession,
    mergedSchema,
    updateSessionFields,
    loading: sessionLoading,
  } = useSessionContext();

  // General chat: with no document open, the same pipeline runs against a
  // stand-in schema and a pseudo session id (see src/ai/generalChat.ts).
  const generalChat = !session && !schema && GENERAL_CHAT_ENABLED;
  const chatSchema = schema ?? (generalChat ? GENERAL_CHAT_SCHEMA : null);
  const chatSessionId = session?.id ?? (generalChat ? GENERAL_CHAT_SESSION_ID : "");

  // Panel visibility (persisted)
  const [panelOpen, setPanelOpenState] = useState<boolean>(() => {
    const stored = localStorage.getItem(PANEL_OPEN_KEY);
    return stored !== null ? stored === "true" : true; // default open
  });

  const setPanelOpen = useCallback((open: boolean) => {
    setPanelOpenState(open);
    localStorage.setItem(PANEL_OPEN_KEY, String(open));
  }, []);

  const togglePanel = useCallback(() => {
    setPanelOpen(!panelOpen);
  }, [panelOpen, setPanelOpen]);

  // Effort tier (defaults to "medium" = Sonnet balanced)
  const [effortTier, setEffortTier] = useState<EffortTier>("medium");

  // Pre-fill text (e.g., review prompt from Preview page)
  const [prefillText, setPrefillText] = useState<string | null>(null);
  const clearPrefill = useCallback(() => setPrefillText(null), []);

  // Scope
  const [scope, setScopeState] = useState<AiScope>({ type: "document" });

  const setScope = useCallback((newScope: AiScope) => {
    setScopeState(newScope);
  }, []);

  // Auto-sync scope when user navigates to a different section
  const location = useLocation();
  const scopeSectionId = scope.type !== "document" ? scope.sectionId : null;
  const scopeFieldKey = scope.type === "field" ? scope.fieldKey : null;

  useEffect(() => {
    // Prep pages have no section; a section or field scope there would hide in
    // the selector while still narrowing requests, so widen to the document.
    if (prepIdFromPath(location.pathname)) {
      if (scope.type !== "document") setScopeState({ type: "document" });
      return;
    }
    const currentSectionId = sectionIdFromPath(location.pathname, schema);
    if (!currentSectionId) return;

    if (scope.type === "section" && scopeSectionId !== currentSectionId) {
      setScopeState({ type: "section", sectionId: currentSectionId });
    } else if (scope.type === "field" && scopeFieldKey) {
      const fieldSectionId = scopeFieldKey.split(".")[0];
      if (fieldSectionId !== currentSectionId) {
        setScopeState({ type: "section", sectionId: currentSectionId });
      }
    }
  }, [location.pathname, schema, scope.type, scopeSectionId, scopeFieldKey]);

  // Document management
  const { activeEndpoint, setActiveEndpoint } = useAiConfig();
  const docManager = useDocumentManager({ schema: chatSchema, activeEndpoint, setActiveEndpoint });

  // Drafting style: derived from the attached style references, stored on the
  // session, and kept like any other session content.
  const persistDraftingStyle = useCallback(
    (patch: DraftingStylePatch) => {
      trackWrite(updateSessionFields(patch));
    },
    [updateSessionFields],
  );
  const styleReference = useStyleReference({
    docs: docManager.styleReferenceDocs,
    draftingStyle: session?.draftingStyle,
    draftingStyleSource: session?.draftingStyleSource,
    draftingStyleEdited: session?.draftingStyleEdited,
    persist: persistDraftingStyle,
    sessionId: session?.id,
  });
  // Only schemas with freetext use the note (a stored one may predate that).
  const draftingStyle = effectiveDraftingStyle(schema, session?.draftingStyle);

  // Build the BulkEditRequest for the current scope (needed for change parsing)
  const bulkEditRequest = useMemo((): BulkEditRequest | null => {
    if (!schema) return null;
    const selectedSectionIds = getScopedSectionIds(schema, scope);
    return {
      mode: "prompt",
      selectedSectionIds,
      schema,
      currentAnswers: answers,
    };
  }, [schema, scope, answers]);

  // System prompt override: when set, buildSystemPrompt returns this instead of the unified prompt.
  // Scoped to the conversation lifetime — cleared when a new conversation starts.
  const systemPromptOverrideRef = useRef<string | null>(null);
  const setSystemPromptOverride = useCallback((prompt: string | null) => {
    systemPromptOverrideRef.current = prompt;
  }, []);

  // System prompt builder (called on each send)
  const buildSystemPrompt = useCallback(() => {
    if (systemPromptOverrideRef.current) return systemPromptOverrideRef.current;
    if (!schema) return generalChat ? buildGeneralChatSystemPrompt() : "";
    return buildUnifiedSystemPrompt(schema, scope, answers, fieldMeta, draftingStyle);
  }, [schema, scope, answers, fieldMeta, draftingStyle, generalChat]);


  // ---------------------------------------------------------------------------
  // Conversation management (dynamic key for new/switch)
  // ---------------------------------------------------------------------------

  const [activeConvKey, setActiveConvKey] = useState<string | null>(null);
  const [chatInstanceKey, setChatInstanceKey] = useState(0);

  // Initialize the conversation key. On page load (after session hydration) the
  // most recent __unified_chat conversation is restored. When the chat session
  // changes afterwards — a document or set is started, opened, or closed — the
  // panel starts on a new chat; earlier ones stay in the dropdown.
  const resolvedOnceRef = useRef(false);
  useEffect(() => {
    if (sessionLoading || !chatSessionId) {
      setActiveConvKey(null);
      return;
    }
    if (resolvedOnceRef.current) {
      setActiveConvKey(`__unified_chat:${crypto.randomUUID()}`);
      setChatInstanceKey((k) => k + 1);
      return;
    }
    let cancelled = false;
    getConversationsForSession(chatSessionId).then((convs) => {
      if (cancelled) return;
      resolvedOnceRef.current = true;
      const unified = convs.filter((c) => c.fieldKey.startsWith("__unified_chat:"));
      if (unified.length > 0) {
        // Most recent first (getConversationsForSession orders by updatedAt desc)
        setActiveConvKey(unified[0].fieldKey);
      } else {
        setActiveConvKey(`__unified_chat:${crypto.randomUUID()}`);
      }
    });
    return () => { cancelled = true; };
  }, [chatSessionId, sessionLoading]);

  // Reset document attachments and notification dots when session changes
  const prevSessionIdRef = useRef(chatSessionId);
  useEffect(() => {
    if (prevSessionIdRef.current !== chatSessionId) {
      prevSessionIdRef.current = chatSessionId;
      docManager.resetSelections();
      setHasUnseenChanges(false);
      setHasUnseenObservations(false);
      prevChangesLenRef.current = 0;
      prevObservationsLenRef.current = 0;
    }
  }, [chatSessionId, docManager]);

  // Pending initial message: consumed once by useAiChat when the new conversation initializes.
  // Stored as state so it's available in the render where conversationKey first changes.
  const [pendingInitialMessage, setPendingInitialMessage] = useState<
    { content: string; displayLabel?: string } | undefined
  >(undefined);

  const onNewChat = useCallback(() => {
    systemPromptOverrideRef.current = null;
    setActiveConvKey(`__unified_chat:${crypto.randomUUID()}`);
    setChatInstanceKey((k) => k + 1);
  }, []);

  /** Start a new chat that auto-sends an initial message once the conversation initializes. */
  const startNewChatWithMessage = useCallback((content: string, displayLabel?: string) => {
    setPendingInitialMessage({ content, displayLabel });
    setActiveConvKey(`__unified_chat:${crypto.randomUUID()}`);
    setChatInstanceKey((k) => k + 1);
  }, []);

  const onSelectConversation = useCallback((conv: Conversation) => {
    setActiveConvKey(conv.fieldKey);
    setChatInstanceKey((k) => k + 1);
  }, []);

  const onDeleteConversation = useCallback(async (conv: Conversation) => {
    await deleteConversation(conv.sessionId, conv.fieldKey);
    setActiveConvKey((current) => {
      if (current !== conv.fieldKey) return current;
      systemPromptOverrideRef.current = null;
      return `__unified_chat:${crypto.randomUUID()}`;
    });
    // Remount so the chat reloads (the list refreshes on this key too).
    setChatInstanceKey((k) => k + 1);
  }, []);

  // Resolved conversation key (fallback while loading)
  const conversationKey = activeConvKey ?? "__unified_chat:none";

  // Clear pending initial message after useAiChat has consumed it
  useEffect(() => {
    if (pendingInitialMessage) {
      setPendingInitialMessage(undefined);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chatInstanceKey]);

  // get_field_info tool handler: pure synchronous schema lookup
  const handleGetFieldInfo = useCallback(
    (args: { section_ids?: string[]; include_answers?: boolean; include_outline?: boolean }): string => {
      if (!schema) return "No schema available.";
      const { section_ids, include_answers, include_outline } = args;

      const sections = section_ids
        ? schema.sections.filter((s) => section_ids.includes(s.id))
        : schema.sections;

      if (sections.length === 0) {
        return `No matching sections found. Available sections: ${schema.sections.map((s) => s.id).join(", ")}`;
      }

      const parts: string[] = [];
      if (include_answers) {
        parts.push(
          "Note: \"Current value\" entries are the working draft of the document being built. Values marked (AI-proposed) are your own earlier proposals — they are not source evidence.",
          "",
        );
      }

      for (const section of sections) {
        parts.push(`### ${section.title} (${section.id})`);
        for (const field of section.fields) {
          if (field.same_as || field.formula !== undefined) continue;
          const fieldKey = `${section.id}.${field.id}`;
          let desc = `- ${fieldKey}: ${field.type}`;
          if (field.type === "date") desc += " (YYYY-MM-DD)";
          if (field.type === "enum" && field.options) {
            desc += ` [${field.options.join("|")}]`;
          }
          desc += ` — "${field.label}"`;
          if (field.ai_hint) desc += `\n  AI hint: ${field.ai_hint}`;
          if (field.type === "table" && field.columns) {
            desc += `\n  Columns: ${field.columns.map((c) => `${c.id} (${c.type}): "${c.label}"`).join(", ")}`;
          }
          if (include_answers) {
            const value = answers[fieldKey];
            if (value !== undefined && value !== "") {
              const meta = fieldMeta[fieldKey];
              const aiTag = meta && meta.source !== "manual" ? " (AI-proposed)" : "";
              desc += `\n  Current value: ${String(value).slice(0, 500)}${String(value).length > 500 ? "..." : ""}${aiTag}`;
            } else {
              desc += "\n  Current value: (empty)";
            }
          }
          parts.push(desc);
        }
        parts.push("");
      }

      if (include_outline) {
        // Build outline from any available generated markdown content.
        // This is a fallback — the main document content is available during review.
        parts.push("## Document Outline");
        parts.push("(Use search_references to retrieve specific section content.)");
        // If the schema has an output_template, extract outline from it
        if (schema.output_template) {
          parts.push(buildDocumentOutline(schema.output_template, "markdown"));
        } else {
          parts.push("(No template outline available — use search_references to explore sections.)");
        }
      }

      return parts.join("\n");
    },
    [schema, answers, fieldMeta],
  );

  // get_template_context tool handler: async template text lookup.
  // For set sessions, resolves the correct source schema from the selected
  // generated doc(s) or from the field_key's owning schema.
  const handleGetTemplateContext = useCallback(
    async (args: {
      schema_id?: string;
      field_key?: string;
      from_line?: number;
      search?: string;
      lines?: number;
    }): Promise<string> => {
      if (!schema) return "No schema available.";

      // Resolve the target schema — for set sessions, prefer the individual source schema.
      let targetSchema = schema;
      if (isSetSession && mergedSchema) {
        if (args.schema_id) {
          // Explicit schema_id from the AI
          const found = mergedSchema.sourceSchemas.find((s) => s.id === args.schema_id);
          if (!found) {
            const available = mergedSchema.sourceSchemas.map((s) => s.id).join(", ");
            return `Unknown schema_id "${args.schema_id}". Available: ${available}`;
          }
          targetSchema = found;
        } else if (args.field_key) {
          // Infer from field_key ownership
          const ownerSchemaIds = mergedSchema.fieldUsage.get(args.field_key);
          if (ownerSchemaIds?.length) {
            const found = mergedSchema.sourceSchemas.find((s) => s.id === ownerSchemaIds[0]);
            if (found) targetSchema = found;
          }
        } else {
          // from_line or search with no schema_id — try to pick from selected docs
          const selectedGenIds = docManager.generatedDocIds.filter((id) => docManager.selectedDocIds.has(id));
          if (selectedGenIds.length === 1) {
            const selectedSchemaId = selectedGenIds[0].replace(/^generated:/, "");
            const found = mergedSchema.sourceSchemas.find((s) => s.id === selectedSchemaId);
            if (found) targetSchema = found;
          } else {
            // Multiple or no generated docs selected — list available schemas
            const available = mergedSchema.sourceSchemas
              .filter((s) => s.docx_template || s.output_template)
              .map((s) => `${s.id} ("${s.title}")`)
              .join(", ");
            return `This is a document set. Specify schema_id to select which document's template to query. Available: ${available}`;
          }
        }
      }

      if (!targetSchema.docx_template && !targetSchema.output_template) {
        return "This document type has no template. Template context is not available.";
      }

      // Validate: exactly one query mode
      const modes = [args.field_key, args.from_line, args.search].filter((v) => v !== undefined);
      if (modes.length === 0) {
        return "Specify one of: field_key (center on a field), from_line (start at a line number), or search (find text).";
      }
      if (modes.length > 1) {
        return "Use only one query mode at a time: field_key, from_line, or search.";
      }

      try {
        const cache = await getOrBuildCache(targetSchema);
        let result;

        if (args.field_key) {
          const window = Math.min(args.lines ?? 20, 60);
          result = queryByFieldKey(cache, targetSchema, args.field_key, window);
        } else if (args.from_line) {
          const count = Math.min(args.lines ?? 40, 120);
          result = queryByLineRange(cache, args.from_line, count);
        } else {
          const window = Math.min(args.lines ?? 20, 60);
          result = queryBySearch(cache, args.search!, window);
        }

        const parts: string[] = [];
        if (result.matchInfo) parts.push(result.matchInfo);
        if (result.lines) parts.push("", result.lines);
        parts.push("", result.outline);
        return parts.join("\n");
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Unknown error";
        return `Could not load template context: ${msg}`;
      }
    },
    [schema, isSetSession, mergedSchema, docManager],
  );

  // Document conversations use the standard AI_TOOLS (drafting + review in one);
  // general chat drops the drafting tools.
  const resolvedTools = generalChat ? GENERAL_TOOLS : AI_TOOLS;

  // Chat hook
  const chat = useAiChat({
    sessionId: chatSessionId,
    conversationKey,
    schema: chatSchema ?? ({ id: "", title: "", sections: [] } as unknown as DocumentSchema),
    buildSystemPrompt,
    tools: resolvedTools,
    request: bulkEditRequest ?? {
      mode: "prompt",
      selectedSectionIds: [],
      schema: { id: "", title: "", sections: [] } as unknown as DocumentSchema,
      currentAnswers: {},
    },
    onSearchReferences: docManager.handleSearchReferences,
    onGetFieldInfo: handleGetFieldInfo,
    onGetTemplateContext: handleGetTemplateContext,
    conversationType: "bulk-edit",
    scope,
    effortTier,
    initialMessage: pendingInitialMessage,
  });

  // Document notifications are no longer auto-injected.
  // The user manually presses Send (with or without text) when docs are attached.

  // Proposed changes management
  const toggleChange = useCallback((index: number) => {
    chat.setAccumulatedChanges((prev) =>
      prev.map((c, i) => (i === index ? { ...c, accepted: !c.accepted } : c)),
    );
  }, [chat]);

  const acceptAll = useCallback(() => {
    chat.setAccumulatedChanges((prev) => prev.map((c) => ({ ...c, accepted: true })));
  }, [chat]);

  const rejectAll = useCallback(() => {
    chat.setAccumulatedChanges((prev) => prev.map((c) => ({ ...c, accepted: false })));
  }, [chat]);

  const applyChanges = useCallback(() => {
    const accepted = chat.accumulatedChanges.filter((c) => c.accepted);
    if (accepted.length === 0) return;
    const now = new Date().toISOString();
    const updates: Record<string, string | number | boolean> = {};
    const meta: Record<string, { confidence: number; source: "bulk-edit"; aiSetAt: string }> = {};
    for (const change of accepted) {
      updates[change.fieldKey] = change.proposedValue;
      meta[change.fieldKey] = { confidence: change.confidence, source: "bulk-edit" as const, aiSetAt: now };
    }
    // Auto-check multiselect gate values for any gated sections receiving updates
    if (schema) {
      const gateUpdates = inferMultiselectGateUpdates(schema, updates, answers);
      Object.assign(updates, gateUpdates);
    }
    setAnswersBatch(updates);
    setFieldMetaBatch(meta);
    // Clear applied changes from the accumulated list
    chat.setAccumulatedChanges((prev) => prev.filter((c) => !c.accepted));
  }, [chat, schema, answers, setAnswersBatch, setFieldMetaBatch]);

  // ---------------------------------------------------------------------------
  // Tab state: "chat" | "changes"
  // ---------------------------------------------------------------------------

  const [activeTab, setActiveTabState] = useState<"chat" | "changes" | "observations">("chat");
  const [hasUnseenChanges, setHasUnseenChanges] = useState(false);
  const [hasUnseenObservations, setHasUnseenObservations] = useState(false);
  const prevChangesLenRef = useRef(0);
  const prevObservationsLenRef = useRef(0);

  // Track new changes arriving → show notification dot
  useEffect(() => {
    const currentLen = chat.accumulatedChanges.length;
    const prevLen = prevChangesLenRef.current;

    if (currentLen > prevLen && activeTab !== "changes") {
      // New changes arrived while user is on Chat tab
      setHasUnseenChanges(true);
    } else if (currentLen === 0 && prevLen > 0) {
      // All changes cleared (after apply) — switch back to Chat
      setActiveTabState("chat");
    }

    prevChangesLenRef.current = currentLen;
  }, [chat.accumulatedChanges.length, activeTab]);

  // Track new observations arriving → show notification dot (no auto-switch)
  useEffect(() => {
    const currentLen = chat.detectedObservations.length;
    const prevLen = prevObservationsLenRef.current;

    if (currentLen > prevLen && activeTab !== "observations") {
      setHasUnseenObservations(true);
    }

    prevObservationsLenRef.current = currentLen;
  }, [chat.detectedObservations.length, activeTab]);

  // Reset tab to "chat" when conversation switches
  useEffect(() => {
    setActiveTabState("chat");
    setHasUnseenChanges(false);
    setHasUnseenObservations(false);
  }, [chatInstanceKey]);

  // A pending question blocks the conversation — always surface it on the Chat tab,
  // never hide it behind a notification dot on another tab.
  useEffect(() => {
    if (chat.pendingQuestion) {
      setActiveTabState("chat");
    }
  }, [chat.pendingQuestion]);

  const setActiveTab = useCallback((tab: "chat" | "changes" | "observations") => {
    setActiveTabState(tab);
    if (tab === "changes") {
      setHasUnseenChanges(false);
    } else if (tab === "observations") {
      setHasUnseenObservations(false);
    }
  }, []);

  const value = useMemo(
    (): AiPanelContextValue => ({
      panelOpen,
      setPanelOpen,
      togglePanel,
      scope,
      setScope,
      messages: chat.messages,
      isStreaming: chat.isStreaming,
      isThinking: chat.isThinking,
      streamingContent: chat.streamingContent,
      isSearching: chat.isSearching,
      retrievalMeta: chat.retrievalMeta,
      error: chat.error,
      sendMessage: chat.sendMessage,
      stopStreaming: chat.stopStreaming,
      proposedChanges: chat.accumulatedChanges,
      toggleChange,
      acceptAll,
      rejectAll,
      applyChanges,
      detectedObservations: chat.detectedObservations,
      clearObservations: chat.clearObservations,
      pendingQuestion: chat.pendingQuestion,
      answerQuestion: chat.answerQuestion,
      docManager,
      styleReference,
      draftingStyle,
      activeConvKey: conversationKey,
      chatInstanceKey,
      onNewChat,
      onSelectConversation,
      onDeleteConversation,
      startNewChatWithMessage,
      effortTier,
      setEffortTier,
      completedSteps: chat.completedSteps,
      activeStepKind: chat.activeStepKind,
      activeTab,
      setActiveTab,
      hasUnseenChanges,
      hasUnseenObservations,
      setSystemPromptOverride,
      prefillText,
      setPrefillText,
      clearPrefill,
      hasActiveSession: !!session,
    }),
    [
      panelOpen,
      setPanelOpen,
      togglePanel,
      scope,
      setScope,
      effortTier,
      setEffortTier,
      chat.messages,
      chat.isStreaming,
      chat.isThinking,
      chat.streamingContent,
      chat.isSearching,
      chat.retrievalMeta,
      chat.error,
      chat.sendMessage,
      chat.stopStreaming,
      chat.accumulatedChanges,
      chat.detectedObservations,
      chat.clearObservations,
      chat.pendingQuestion,
      chat.answerQuestion,
      chat.completedSteps,
      chat.activeStepKind,
      toggleChange,
      acceptAll,
      rejectAll,
      applyChanges,
      docManager,
      styleReference,
      draftingStyle,
      conversationKey,
      chatInstanceKey,
      onNewChat,
      onSelectConversation,
      onDeleteConversation,
      startNewChatWithMessage,
      activeTab,
      setActiveTab,
      hasUnseenChanges,
      hasUnseenObservations,
      setSystemPromptOverride,
      prefillText,
      setPrefillText,
      clearPrefill,
      session,
    ],
  );

  return (
    <AiPanelContext.Provider value={value}>
      {children}
    </AiPanelContext.Provider>
  );
}
