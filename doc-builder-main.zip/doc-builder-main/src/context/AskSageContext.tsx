import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
} from "react";
import {
  ASKSAGE_EMAIL_KEY,
  ASKSAGE_API_KEY_KEY,
  saveAsksageCredentials,
  clearAsksageCredentials,
  testAsksageConnection,
} from "../ai/asksage";

// ---------------------------------------------------------------------------
// Context shape
// ---------------------------------------------------------------------------

// AskSage is disabled pending AskSage team approval; see the STATUS block in src/ai/asksage.ts. Do not delete.

export interface AskSageContextValue {
  /** User's email for AskSage authentication. */
  email: string | null;
  /** AskSage API key. */
  apiKey: string | null;
  /** True when both email and API key are set. */
  isConfigured: boolean;
  /** Store credentials (persists to localStorage). */
  setCredentials: (email: string, apiKey: string) => void;
  /** Remove stored credentials. */
  clearCredentials: () => void;
  /** Current connection test status. */
  connectionStatus: "untested" | "testing" | "connected" | "error";
  /** Error message from the last failed connection test. */
  connectionError: string | null;
  /** Run a connection test against AskSage. */
  testConnection: () => Promise<void>;
}

const AskSageContext = createContext<AskSageContextValue | null>(null);

// ---------------------------------------------------------------------------
// Hook
// ---------------------------------------------------------------------------

export function useAskSage(): AskSageContextValue {
  const ctx = useContext(AskSageContext);
  if (!ctx) {
    throw new Error("useAskSage must be used within AskSageProvider");
  }
  return ctx;
}

// ---------------------------------------------------------------------------
// Provider
// ---------------------------------------------------------------------------

export function AskSageProvider({ children }: { children: React.ReactNode }) {
  const [email, setEmail] = useState<string | null>(
    () => localStorage.getItem(ASKSAGE_EMAIL_KEY),
  );
  const [apiKey, setApiKey] = useState<string | null>(
    () => localStorage.getItem(ASKSAGE_API_KEY_KEY),
  );
  const [connectionStatus, setConnectionStatus] = useState<
    "untested" | "testing" | "connected" | "error"
  >("untested");
  const [connectionError, setConnectionError] = useState<string | null>(null);

  const setCredentials = useCallback((newEmail: string, newApiKey: string) => {
    saveAsksageCredentials(newEmail, newApiKey);
    setEmail(newEmail.trim() || null);
    setApiKey(newApiKey.trim() || null);
    // Reset connection status when credentials change
    setConnectionStatus("untested");
    setConnectionError(null);
  }, []);

  const clearCreds = useCallback(() => {
    clearAsksageCredentials();
    setEmail(null);
    setApiKey(null);
    setConnectionStatus("untested");
    setConnectionError(null);
  }, []);

  const testConnection = useCallback(async () => {
    if (!email || !apiKey) {
      setConnectionStatus("error");
      setConnectionError("Email and API key are required");
      return;
    }
    setConnectionStatus("testing");
    setConnectionError(null);
    const result = await testAsksageConnection(email, apiKey);
    setConnectionStatus(result.ok ? "connected" : "error");
    setConnectionError(result.error ?? null);
  }, [email, apiKey]);

  const value = useMemo<AskSageContextValue>(() => ({
    email,
    apiKey,
    isConfigured: Boolean(email && apiKey),
    setCredentials,
    clearCredentials: clearCreds,
    connectionStatus,
    connectionError,
    testConnection,
  }), [email, apiKey, setCredentials, clearCreds, connectionStatus, connectionError, testConnection]);

  return (
    <AskSageContext.Provider value={value}>
      {children}
    </AskSageContext.Provider>
  );
}
