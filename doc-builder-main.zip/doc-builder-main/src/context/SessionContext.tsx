import { toAppError, type AppError } from "../errors";
import { trackWrite } from "../db/writeStatus";
import StorageUnavailable from "../components/StorageUnavailable";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { useLocation, useNavigate } from "react-router-dom";
import type { FieldMeta, Session } from "../db/types";
import type { DocumentSchema } from "../schemas/types";
import type { SectionStatus } from "../engine/types";
import { computeSectionStatus } from "../engine/sectionStatus";
import { evaluateContentBlocks } from "../engine/contentBlocks";
import { validateAnswers, type ValidationIssues } from "../engine/validation";
import { getSchema, subscribeSchemas } from "../schemas/loader";
import { hydrateUserSchemas } from "../schemas/userSchemas";
import { isCustomSchemaId } from "../schemas/customIds";
import {
  createSession,
  createSetSession,
  deleteSession,
  getLatestSession,
  getSession,
  updateSession,
} from "../db/session";
import { upsertConversation } from "../db/chatHistory";
import { db } from "../db/dexie";
import {
  buildFieldLinkMap,
  getTransitiveFollowers,
  healLinkedAnswers,
  type FieldLinkMap,
} from "../engine/fieldLinks";
import { applyFieldDefaults } from "../engine/fieldDefaults";
import { mergeSetSchemas, type MergedSchema } from "../schemas/mergeSet";
import { getSetById } from "../schemas/sets";
import { getUserProfile } from "./UserPreferencesContext";
import { useTabLock } from "../hooks/useTabLock";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface SessionContextValue {
  /** Current session (null while loading or when no session exists). */
  session: Session | null;
  /** Schema for the current session's document type (merged schema for set sessions). */
  schema: DocumentSchema | null;
  /** Live answers (optimistically updated). */
  answers: Record<string, string | number | boolean>;
  /** Per-field AI metadata (confidence, source). */
  fieldMeta: Record<string, FieldMeta>;
  /** Computed section completion statuses. */
  sectionStatuses: Record<string, SectionStatus>;
  /** Validation rule problems keyed by answer key (warnings only — never blocks). */
  validationIssues: ValidationIssues;
  /** True during initial load from IndexedDB. */
  loading: boolean;
  /** Whether the current session is a multi-document set session. */
  isSetSession: boolean;
  /** Merged schema details for set sessions (null for single-doc sessions). */
  mergedSchema: MergedSchema | null;
  /** True when another tab holds the editing lock for this session. */
  isLockedByOtherTab: boolean;

  /** Update a single answer (optimistic + debounced persist). Clears field metadata. */
  setAnswer: (key: string, value: string | number | boolean) => void;
  /** Update multiple answers at once (single persist, no debounce). */
  setAnswersBatch: (updates: Record<string, string | number | boolean>) => void;
  /** Set AI metadata for a single field. */
  setFieldMeta: (key: string, meta: FieldMeta) => void;
  /** Set AI metadata for multiple fields at once (immediate persist). */
  setFieldMetaBatch: (updates: Record<string, FieldMeta>) => void;
  /** Create a new session, deleting any existing one, and navigate to it. */
  startSession: (schemaId: string) => Promise<void>;
  /** Start a set session (multi-document), deleting any existing session. */
  startSetSession: (setId: string) => Promise<void>;
  /** Delete the current session and navigate to home. */
  deleteCurrentSession: () => Promise<void>;
  /** Clear all answers in the current session (no page reload). */
  clearAnswers: () => Promise<void>;
  /** Patch session flags (reviewApproved, generated) and the drafting style note. */
  updateSessionFields: (
    patch: Partial<Pick<Session, "reviewApproved" | "generated" | "draftingStyle" | "draftingStyleSource" | "draftingStyleEdited">>,
  ) => Promise<void>;
  /** Load and switch to a specific session by ID (e.g. after import). */
  resumeSession: (sessionId: string) => Promise<void>;
  /** Drop unsaved debounced answers without writing them (e.g. before a full restore). */
  cancelPendingSave: () => void;
}

// ---------------------------------------------------------------------------
// Context
// ---------------------------------------------------------------------------

export const SessionContext = createContext<SessionContextValue | null>(null);

export function useSessionContext(): SessionContextValue {
  const ctx = useContext(SessionContext);
  if (!ctx) {
    throw new Error("useSessionContext must be used within SessionProvider");
  }
  return ctx;
}

// ---------------------------------------------------------------------------
// Auto-fill from cached user profile
// ---------------------------------------------------------------------------

/**
 * Scans schema fields for `auto_fill` annotations and returns pre-filled
 * answers from the cached user profile in localStorage.
 */
function computeAutoFillAnswers(
  docSchema: DocumentSchema,
): Record<string, string> {
  const profile = getUserProfile();
  if (!profile) return {};

  const profileMap: Record<string, string> = {
    "user_profile.name": profile.name,
    "user_profile.title": profile.title,
    "user_profile.phone": profile.phone,
    "user_profile.email": profile.email,
  };

  const prefilled: Record<string, string> = {};
  for (const section of docSchema.sections) {
    for (const field of section.fields) {
      if (field.auto_fill && profileMap[field.auto_fill]) {
        prefilled[`${section.id}.${field.id}`] = profileMap[field.auto_fill];
      }
    }
  }
  return prefilled;
}

// ---------------------------------------------------------------------------
// Provider
// ---------------------------------------------------------------------------

export function SessionProvider({ children }: { children: React.ReactNode }) {
  const navigate = useNavigate();
  const location = useLocation();

  const [session, setSession] = useState<Session | null>(null);
  const [schema, setSchema] = useState<DocumentSchema | null>(null);
  const [mergedSchemaState, setMergedSchemaState] = useState<MergedSchema | null>(null);
  const [answers, setAnswers] = useState<Record<string, string | number | boolean>>({});
  const [fieldMeta, setFieldMetaState] = useState<Record<string, FieldMeta>>({});
  const [loading, setLoading] = useState(true);
  const [initError, setInitError] = useState<AppError | null>(null);

  const sessionIdRef = useRef<string | null>(null);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  // Answers awaiting the debounced save, with the session they belong to. The
  // id is captured when scheduling so a save can't land in a session the user
  // has since switched to.
  const pendingSave = useRef<{ sessionId: string; answers: Record<string, string | number | boolean> } | null>(null);

  /** Drop the pending debounced save (its answers are superseded or discarded). */
  const cancelPendingSave = useCallback(() => {
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = null;
    pendingSave.current = null;
  }, []);

  /** Write the pending debounced save now. */
  const flushPendingSave = useCallback((): Promise<void> => {
    const pending = pendingSave.current;
    cancelPendingSave();
    if (!pending) return Promise.resolve();
    return trackWrite(updateSession(pending.sessionId, { answers: pending.answers }));
  }, [cancelPendingSave]);

  // Don't lose the last keystrokes when the provider unmounts mid-debounce.
  useEffect(() => () => { void flushPendingSave(); }, [flushPendingSave]);

  const isSetSession = Boolean(session?.setId);

  // -------------------------------------------------------------------------
  // Tab lock: prevent concurrent editing from multiple tabs
  // -------------------------------------------------------------------------
  const { hasLock, isLockedByOtherTab } = useTabLock(session?.id ?? null);

  // -------------------------------------------------------------------------
  // Field link map (memoized from schema)
  // -------------------------------------------------------------------------
  const linkMap = useMemo<FieldLinkMap | null>(() => {
    if (!schema) return null;
    return buildFieldLinkMap(schema);
  }, [schema]);

  // -------------------------------------------------------------------------
  // Bootstrap: load latest session from IndexedDB once on mount
  // -------------------------------------------------------------------------
  useEffect(() => {
    let cancelled = false;
    async function init() {
      // Uploaded templates must be registered before the session's schema is
      // resolved (never rejects — falls back to built-ins only)
      await hydrateUserSchemas();
      let s: Session | undefined;
      try {
        s = await getLatestSession();
      } catch (err) {
        // IndexedDB unavailable/corrupt — show the recovery page instead of
        // hanging on the loading state
        console.error("[storage] Failed to open session storage:", err);
        if (!cancelled) {
          setInitError(toAppError(err, { domain: "db" }));
          setLoading(false);
        }
        return;
      }
      if (cancelled) return;
      if (s) {
        let loadedSchema: DocumentSchema | null = null;
        let merged: MergedSchema | null = null;

        if (s.setId && s.schemaIds) {
          // Set session: resolve all member schemas and merge
          const memberSchemas = s.schemaIds
            .map((id) => getSchema(id))
            .filter((x): x is DocumentSchema => x !== undefined);
          if (memberSchemas.length > 0) {
            merged = mergeSetSchemas(memberSchemas, s.setId);
            loadedSchema = merged.schema;
          }
        } else {
          loadedSchema = getSchema(s.documentTypeId) ?? null;
        }

        setSession(s);
        setSchema(loadedSchema);
        setMergedSchemaState(merged);

        // Heal linked answers on load (handles schema changes after save)
        let loadedAnswers = s.answers;
        if (loadedSchema) {
          const map = buildFieldLinkMap(loadedSchema);
          // Defaults fill fields added to the schema after this session was saved.
          loadedAnswers = applyFieldDefaults(loadedSchema, healLinkedAnswers(s.answers, map));
          if (loadedAnswers !== s.answers) {
            trackWrite(updateSession(s.id, { answers: loadedAnswers }));
          }
        }
        setAnswers(loadedAnswers);
        setFieldMetaState(s.fieldMeta ?? {});
        sessionIdRef.current = s.id;
      }
      setLoading(false);
    }
    init();
    return () => { cancelled = true; };
  }, []);

  // -------------------------------------------------------------------------
  // Custom templates can be replaced or removed while a session is open
  // (here or in another tab) — pick up the registry's current schema object.
  // -------------------------------------------------------------------------
  const documentTypeId = session?.setId ? null : session?.documentTypeId;
  useEffect(() => {
    if (!documentTypeId || !isCustomSchemaId(documentTypeId)) return;
    return subscribeSchemas(() => {
      const current = getSchema(documentTypeId) ?? null;
      setSchema((prev) => (prev === current ? prev : current));
    });
  }, [documentTypeId]);

  // -------------------------------------------------------------------------
  // Sync URL → IndexedDB: persist currentSection when the interview URL changes
  // -------------------------------------------------------------------------
  useEffect(() => {
    const match = location.pathname.match(/^\/interview\/[^/]+\/(.+)$/);
    if (match && sessionIdRef.current) {
      const sectionId = match[1];
      trackWrite(updateSession(sessionIdRef.current, { currentSection: sectionId }));
    }
  }, [location.pathname]);

  // -------------------------------------------------------------------------
  // Derived: section statuses
  // -------------------------------------------------------------------------
  const blocks = useMemo(
    () => (schema ? evaluateContentBlocks(schema, answers) : {}),
    [schema, answers],
  );

  const sectionStatuses = useMemo(() => {
    if (!schema) return {};
    const statuses: Record<string, SectionStatus> = {};
    for (const section of schema.sections) {
      statuses[section.id] = computeSectionStatus(section, schema, answers, blocks);
    }
    return statuses;
  }, [schema, answers, blocks]);

  const validationIssues = useMemo(
    () => (schema ? validateAnswers(schema, answers) : {}),
    [schema, answers],
  );

  // -------------------------------------------------------------------------
  // Helpers
  // -------------------------------------------------------------------------

  /**
   * Ensure all chat conversations for a session have metadata records in the
   * `conversations` table. This is called before session deletion so that
   * orphaned conversations remain discoverable in the history view.
   */
  async function ensureConversationMetadata(sessionId: string) {
    // Find all distinct fieldKeys with messages for this session
    const messages = await db.chatMessages
      .where("sessionId")
      .equals(sessionId)
      .toArray();

    const fieldKeys = new Set(messages.map((m) => m.fieldKey));
    if (fieldKeys.size === 0) return;

    // Resolve schema for labels
    const sess = await db.sessions.get(sessionId);
    const sessSchema = sess ? getSchema(sess.documentTypeId) : null;

    for (const fieldKey of fieldKeys) {
      const isBulkEdit = fieldKey === "__bulk_edit";
      let label = "Bulk Edit";
      if (!isBulkEdit && sessSchema) {
        // Resolve human-readable label from schema
        const [sectionId, fieldId] = fieldKey.split(".");
        const section = sessSchema.sections.find((s) => s.id === sectionId);
        const field = section?.fields.find((f) => f.id === fieldId);
        label = field?.label ?? fieldKey;
      }

      await upsertConversation({
        sessionId,
        fieldKey,
        documentTypeId: sess?.documentTypeId ?? "unknown",
        documentTypeTitle: sessSchema?.title ?? "Unknown Document",
        label,
        conversationType: isBulkEdit ? "bulk-edit" : "field-chat",
      });
    }
  }

  // -------------------------------------------------------------------------
  // Actions
  // -------------------------------------------------------------------------

  const setAnswer = useCallback(
    (key: string, value: string | number | boolean) => {
      if (!hasLock) return; // read-only when another tab holds the lock

      setAnswers((prev) => {
        const next = { ...prev, [key]: value };

        // Propagate to followers via same_as links
        if (linkMap) {
          const followers = getTransitiveFollowers(key, linkMap);
          for (const followerKey of followers) {
            next[followerKey] = value;
          }
        }

        // Debounced persist (300ms)
        if (saveTimer.current) clearTimeout(saveTimer.current);
        if (sessionIdRef.current) {
          pendingSave.current = { sessionId: sessionIdRef.current, answers: next };
          saveTimer.current = setTimeout(() => { void flushPendingSave(); }, 300);
        }

        return next;
      });

      // Clear AI metadata when the user manually edits a field
      setFieldMetaState((prev) => {
        if (!(key in prev)) return prev;
        const next = { ...prev };
        delete next[key];
        // Persist the cleared metadata
        if (sessionIdRef.current) {
          trackWrite(updateSession(sessionIdRef.current, { fieldMeta: next }));
        }
        return next;
      });
    },
    [linkMap, hasLock, flushPendingSave],
  );

  const setAnswersBatch = useCallback(
    (updates: Record<string, string | number | boolean>) => {
      if (!hasLock) return; // read-only when another tab holds the lock

      setAnswers((prev) => {
        const next = { ...prev, ...updates };

        // Propagate links for every key in the batch
        if (linkMap) {
          for (const [key, value] of Object.entries(updates)) {
            const followers = getTransitiveFollowers(key, linkMap);
            for (const followerKey of followers) {
              next[followerKey] = value;
            }
          }
        }

        // Immediate persist (no debounce for batch operations). `next` includes
        // any debounced edit, so the pending save is superseded — and would
        // otherwise overwrite this batch when it fires.
        cancelPendingSave();
        if (sessionIdRef.current) {
          trackWrite(updateSession(sessionIdRef.current, { answers: next }));
        }
        return next;
      });
    },
    [linkMap, hasLock, cancelPendingSave],
  );

  const setFieldMeta = useCallback(
    (key: string, meta: FieldMeta) => {
      setFieldMetaState((prev) => {
        const next = { ...prev, [key]: meta };
        if (sessionIdRef.current) {
          trackWrite(updateSession(sessionIdRef.current, { fieldMeta: next }));
        }
        return next;
      });
    },
    [],
  );

  const setFieldMetaBatch = useCallback(
    (updates: Record<string, FieldMeta>) => {
      setFieldMetaState((prev) => {
        const next = { ...prev, ...updates };
        if (sessionIdRef.current) {
          trackWrite(updateSession(sessionIdRef.current, { fieldMeta: next }));
        }
        return next;
      });
    },
    [],
  );

  const startSession = useCallback(
    async (schemaId: string) => {
      cancelPendingSave();
      // Delete existing session if any.
      // Chat messages are intentionally NOT cascade-deleted — they are retained
      // in the history view for user reference after session deletion.
      if (sessionIdRef.current) {
        await ensureConversationMetadata(sessionIdRef.current);
        await deleteSession(sessionIdRef.current);
      }

      await hydrateUserSchemas();
      const loadedSchema = getSchema(schemaId);
      if (!loadedSchema) return;

      const firstSectionId = loadedSchema.sections[0].id;
      const created = await createSession(schemaId, firstSectionId);

      // Pre-fill from cached user profile
      const prefilled = applyFieldDefaults(loadedSchema, computeAutoFillAnswers(loadedSchema));
      if (Object.keys(prefilled).length > 0) {
        await updateSession(created.id, { answers: prefilled });
        created.answers = prefilled;
      }

      setSession(created);
      setSchema(loadedSchema);
      setAnswers(prefilled);
      setFieldMetaState({});
      sessionIdRef.current = created.id;

      navigate(`/interview/${schemaId}/${loadedSchema.sections[0].id}`);
    },
    [navigate, cancelPendingSave],
  );

  const startSetSession = useCallback(
    async (setId: string) => {
      cancelPendingSave();
      // Delete existing session if any
      if (sessionIdRef.current) {
        await ensureConversationMetadata(sessionIdRef.current);
        await deleteSession(sessionIdRef.current);
      }

      // Find all schemas belonging to this set via set definition
      const setDef = getSetById(setId);
      if (!setDef) return;
      const setSchemas = setDef.schemas
        .map((id) => getSchema(id))
        .filter((s): s is DocumentSchema => s !== undefined);
      if (setSchemas.length === 0) return;

      const merged = mergeSetSchemas(setSchemas, setId);
      const firstSectionId = merged.schema.sections[0].id;
      const schemaIds = setSchemas.map((s) => s.id);

      const created = await createSetSession(setId, schemaIds, firstSectionId);

      // Pre-fill from cached user profile
      const prefilled = applyFieldDefaults(merged.schema, computeAutoFillAnswers(merged.schema));
      if (Object.keys(prefilled).length > 0) {
        await updateSession(created.id, { answers: prefilled });
        created.answers = prefilled;
      }

      setSession(created);
      setSchema(merged.schema);
      setMergedSchemaState(merged);
      setAnswers(prefilled);
      setFieldMetaState({});
      sessionIdRef.current = created.id;

      navigate(`/interview/${merged.schema.id}/${firstSectionId}`);
    },
    [navigate, cancelPendingSave],
  );

  const deleteCurrentSession = useCallback(async () => {
    // Chat messages are intentionally NOT cascade-deleted — they are retained
    // in the history view for user reference after session deletion.
    cancelPendingSave();
    if (sessionIdRef.current) {
      await ensureConversationMetadata(sessionIdRef.current);
      await deleteSession(sessionIdRef.current);
    }
    setSession(null);
    setSchema(null);
    setAnswers({});
    setFieldMetaState({});
    sessionIdRef.current = null;
    navigate("/");
  }, [navigate, cancelPendingSave]);

  const clearAnswers = useCallback(async () => {
    cancelPendingSave();
    if (sessionIdRef.current) {
      await updateSession(sessionIdRef.current, { answers: {}, fieldMeta: {} });
    }
    setAnswers({});
    setFieldMetaState({});
  }, [cancelPendingSave]);

  const updateSessionFields = useCallback(
    async (patch: Partial<Pick<Session, "reviewApproved" | "generated" | "draftingStyle" | "draftingStyleSource" | "draftingStyleEdited">>) => {
      const id = sessionIdRef.current;
      if (!id) return;
      await updateSession(id, patch);
      // Skip the in-memory patch if the user switched sessions during the write.
      setSession((prev) => (prev && prev.id === id ? { ...prev, ...patch } : prev));
    },
    [],
  );

  const resumeSession = useCallback(
    async (sessionId: string) => {
      // Persist the current session's last edits before switching (or before
      // re-reading it, when resuming the same session).
      await flushPendingSave();
      await hydrateUserSchemas();
      const s = await getSession(sessionId);
      if (!s) return;

      let loadedSchema: DocumentSchema | null = null;
      let merged: MergedSchema | null = null;

      if (s.setId && s.schemaIds) {
        const memberSchemas = s.schemaIds
          .map((id) => getSchema(id))
          .filter((x): x is DocumentSchema => x !== undefined);
        if (memberSchemas.length > 0) {
          merged = mergeSetSchemas(memberSchemas, s.setId);
          loadedSchema = merged.schema;
        }
      } else {
        loadedSchema = getSchema(s.documentTypeId) ?? null;
      }

      if (!loadedSchema) return;

      // Heal linked answers and fill defaults for fields added since the save
      const map = buildFieldLinkMap(loadedSchema);
      const healedAnswers = applyFieldDefaults(loadedSchema, healLinkedAnswers(s.answers, map));
      if (healedAnswers !== s.answers) {
        await updateSession(s.id, { answers: healedAnswers });
      }

      // Validate currentSection still exists in schema; fall back to first section
      const sectionExists = loadedSchema.sections.some(
        (sec) => sec.id === s.currentSection,
      );
      const targetSection = sectionExists
        ? s.currentSection
        : loadedSchema.sections[0].id;

      if (!sectionExists) {
        await updateSession(s.id, { currentSection: targetSection });
        s.currentSection = targetSection;
      }

      setSession(s);
      setSchema(loadedSchema);
      setMergedSchemaState(merged);
      setAnswers(healedAnswers);
      setFieldMetaState(s.fieldMeta ?? {});
      sessionIdRef.current = s.id;

      navigate(`/interview/${loadedSchema.id}/${targetSection}`);
    },
    [navigate, flushPendingSave],
  );

  // -------------------------------------------------------------------------
  // Render
  // -------------------------------------------------------------------------

  const value: SessionContextValue = useMemo(
    () => ({
      session,
      schema,
      answers,
      fieldMeta,
      sectionStatuses,
      validationIssues,
      loading,
      isSetSession,
      mergedSchema: mergedSchemaState,
      isLockedByOtherTab,
      setAnswer,
      setAnswersBatch,
      setFieldMeta,
      setFieldMetaBatch,
      startSession,
      startSetSession,
      deleteCurrentSession,
      clearAnswers,
      updateSessionFields,
      resumeSession,
      cancelPendingSave,
    }),
    [
      session,
      schema,
      answers,
      fieldMeta,
      sectionStatuses,
      validationIssues,
      loading,
      isSetSession,
      mergedSchemaState,
      isLockedByOtherTab,
      setAnswer,
      setAnswersBatch,
      setFieldMeta,
      setFieldMetaBatch,
      startSession,
      startSetSession,
      deleteCurrentSession,
      clearAnswers,
      updateSessionFields,
      resumeSession,
      cancelPendingSave,
    ],
  );

  return (
    <SessionContext.Provider value={value}>
      {initError ? <StorageUnavailable error={initError} /> : children}
    </SessionContext.Provider>
  );
}
