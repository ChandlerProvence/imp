import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import {
  ACTIVE_ENDPOINT_KEY,
  ENDPOINTS,
  LEGACY_API_KEY_STORAGE,
  apiKeyStorageKey,
  getActiveEndpointId,
  getResolvedBaseUrl,
} from "../ai/endpoints";
import type { EndpointConfig, EndpointId } from "../ai/endpoints";
import { discoverModels } from "../ai/litellm";
import {
  getDiscoveredModels,
  getModelResolution,
  resolveModel,
  subscribeModels,
  type RoleResolution,
} from "../ai/models";

// ---------------------------------------------------------------------------
// Context shape
// ---------------------------------------------------------------------------

export interface AiConfigContextValue {
  /** Currently active endpoint ID. */
  activeEndpoint: EndpointId;
  /** Switch the active endpoint (persists to localStorage). */
  setActiveEndpoint: (ep: EndpointId) => void;
  /** Full config object for the active endpoint. */
  endpointConfig: EndpointConfig;
  /** API key for the active endpoint (null if not set). */
  apiKey: string | null;
  /** Store an API key for a specific endpoint. */
  setApiKey: (ep: EndpointId, key: string) => void;
  /** Read the API key for a specific endpoint. */
  getApiKeyFor: (ep: EndpointId) => string | null;
  /** Resolved base URL (dev proxy path or production URL). */
  baseUrl: string;
  /** Resolved standard model ID for the active endpoint. */
  modelStandard: string;
  /** Resolved advanced model ID for the active endpoint. */
  modelAdvanced: string;
  /** Resolved embedding model ID for the active endpoint. */
  embeddingModel: string;
  /** Per-role resolution (id + source) for an endpoint. */
  modelResolution: (ep: EndpointId) => RoleResolution[];
  /** Model IDs the proxy reported for an endpoint (null until discovered). */
  availableModels: (ep: EndpointId) => string[] | null;
  /** Bumps whenever overrides, discovery, or availability change. */
  modelsVersion: number;
}

const AiConfigContext = createContext<AiConfigContextValue | null>(null);

// ---------------------------------------------------------------------------
// Hook
// ---------------------------------------------------------------------------

export function useAiConfig(): AiConfigContextValue {
  const ctx = useContext(AiConfigContext);
  if (!ctx) {
    throw new Error("useAiConfig must be used within AiConfigProvider");
  }
  return ctx;
}

// ---------------------------------------------------------------------------
// Provider
// ---------------------------------------------------------------------------

/** Migrate the legacy single API key to the new per-endpoint storage. */
function migrateLegacyKey() {
  const legacy = localStorage.getItem(LEGACY_API_KEY_STORAGE);
  if (legacy && !localStorage.getItem(apiKeyStorageKey("non-cui"))) {
    localStorage.setItem(apiKeyStorageKey("non-cui"), legacy);
    localStorage.removeItem(LEGACY_API_KEY_STORAGE);
  }
}

export function AiConfigProvider({ children }: { children: React.ReactNode }) {

  const [activeEndpoint, setActiveEndpointState] = useState<EndpointId>(
    getActiveEndpointId,
  );

  // Track per-endpoint keys in state so changes re-render consumers
  const [keys, setKeys] = useState<Record<EndpointId, string | null>>(() => {
    // Migrate before the first read so a legacy key is visible on first load
    migrateLegacyKey();
    return {
      cui: localStorage.getItem(apiKeyStorageKey("cui")),
      "non-cui": localStorage.getItem(apiKeyStorageKey("non-cui")),
    };
  });

  const setActiveEndpoint = useCallback((ep: EndpointId) => {
    localStorage.setItem(ACTIVE_ENDPOINT_KEY, ep);
    setActiveEndpointState(ep);
  }, []);

  const setApiKey = useCallback((ep: EndpointId, key: string) => {
    const trimmed = key.trim();
    if (trimmed) {
      localStorage.setItem(apiKeyStorageKey(ep), trimmed);
    } else {
      localStorage.removeItem(apiKeyStorageKey(ep));
    }
    setKeys((prev) => ({ ...prev, [ep]: trimmed || null }));
  }, []);

  const getApiKeyFor = useCallback(
    (ep: EndpointId) => keys[ep],
    [keys],
  );

  // Re-render consumers when model state changes (including from non-React
  // code, e.g. litellm.ts marking a model unavailable mid-session)
  const [modelsVersion, setModelsVersion] = useState(0);
  useEffect(() => subscribeModels(() => setModelsVersion((v) => v + 1)), []);

  // Discover available models for each endpoint that has a key. Failures are
  // silent: the cached list (or the configured defaults) keeps working.
  useEffect(() => {
    const controller = new AbortController();
    for (const ep of Object.keys(keys) as EndpointId[]) {
      const key = keys[ep];
      if (!key) continue;
      discoverModels(ep, key, controller.signal).catch(() => {
        // aborted on unmount / key change
      });
    }
    return () => controller.abort();
  }, [keys]);


  const value = useMemo<AiConfigContextValue>(() => {
    const config = ENDPOINTS[activeEndpoint];
    return {
      activeEndpoint,
      setActiveEndpoint,
      endpointConfig: config,
      apiKey: keys[activeEndpoint],
      setApiKey,
      getApiKeyFor,
      baseUrl: getResolvedBaseUrl(activeEndpoint),
      modelStandard: resolveModel(activeEndpoint, "standard"),
      modelAdvanced: resolveModel(activeEndpoint, "advanced"),
      embeddingModel: resolveModel(activeEndpoint, "embedding"),
      modelResolution: getModelResolution,
      availableModels: getDiscoveredModels,
      modelsVersion,
    };
    // modelsVersion invalidates the resolved IDs above
  }, [activeEndpoint, keys, setActiveEndpoint, setApiKey, getApiKeyFor, modelsVersion]);

  return (
    <AiConfigContext.Provider value={value}>
      {children}
    </AiConfigContext.Provider>
  );
}
