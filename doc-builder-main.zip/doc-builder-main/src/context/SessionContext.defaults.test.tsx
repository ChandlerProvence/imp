/**
 * Schema field defaults reach both new sessions and sessions saved before the
 * defaulted field existed (e.g. fms-to-mod `includes_tte`), so the interview
 * checkbox shows the value the totals already use.
 */
import { describe, it, expect, vi, beforeEach } from "vitest";
import { renderHook, act, waitFor } from "@testing-library/react";
import type { ReactNode } from "react";
import { MemoryRouter } from "react-router-dom";
import type { Session } from "../db/types";

const KEY = "pricing.includes_tte";

const saved = {
  id: "old",
  documentTypeId: "fms-to-mod",
  answers: { "pricing.includes_rr": false },
  currentSection: "header",
  sectionConfirmed: {},
} as unknown as Session;

vi.mock("../db/session", () => ({
  createSession: vi.fn((documentTypeId: string, currentSection: string) =>
    Promise.resolve({ id: "new", documentTypeId, answers: {}, currentSection, sectionConfirmed: {} }),
  ),
  createSetSession: vi.fn(),
  deleteSession: vi.fn().mockResolvedValue(undefined),
  getLatestSession: vi.fn(() => Promise.resolve(saved)),
  getSession: vi.fn(() => Promise.resolve(saved)),
  updateSession: vi.fn().mockResolvedValue(undefined),
}));

import { updateSession } from "../db/session";
import { SessionProvider, useSessionContext } from "./SessionContext";

const wrapper = ({ children }: { children: ReactNode }) => (
  <MemoryRouter>
    <SessionProvider>{children}</SessionProvider>
  </MemoryRouter>
);

describe("SessionProvider field defaults", () => {
  beforeEach(() => {
    localStorage.clear();
    vi.mocked(updateSession).mockClear();
  });

  it("fills a missing defaulted answer when a saved session loads, and saves it", async () => {
    const { result } = renderHook(() => useSessionContext(), { wrapper });
    await waitFor(() => expect(result.current.session?.id).toBe("old"));
    expect(result.current.answers[KEY]).toBe(true);
    expect(result.current.answers["pricing.includes_rr"]).toBe(false);
    expect(vi.mocked(updateSession)).toHaveBeenCalledWith("old", {
      answers: expect.objectContaining({ [KEY]: true }),
    });
  });

  it("pre-fills defaults in a new session", async () => {
    const { result } = renderHook(() => useSessionContext(), { wrapper });
    await waitFor(() => expect(result.current.session?.id).toBe("old"));
    await act(() => result.current.startSession("fms-to-mod"));
    expect(result.current.session?.id).toBe("new");
    expect(result.current.answers[KEY]).toBe(true);
  });
});
