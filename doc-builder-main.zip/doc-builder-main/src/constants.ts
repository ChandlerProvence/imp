// ---------------------------------------------------------------------------
// Application-wide constants
// ---------------------------------------------------------------------------

/** AI confidence score thresholds for visual indicators. */
export const CONFIDENCE = {
  /** High confidence — shown as green. */
  HIGH: 0.8,
  /** Medium confidence — shown as amber. */
  MEDIUM: 0.5,
} as const;

/** Get the Tailwind badge color classes for an AI confidence score (background + text + border). */
export function confidenceColor(confidence: number): string {
  if (confidence >= CONFIDENCE.HIGH) return "bg-green-100 text-green-700 border-green-200";
  if (confidence >= CONFIDENCE.MEDIUM) return "bg-amber-100 text-amber-700 border-amber-200";
  return "bg-red-100 text-red-700 border-red-200";
}

/** Get the Tailwind text-only color class for an AI confidence score. */
export function confidenceTextColor(confidence: number): string {
  if (confidence >= CONFIDENCE.HIGH) return "text-green-600";
  if (confidence >= CONFIDENCE.MEDIUM) return "text-amber-600";
  return "text-red-600";
}
