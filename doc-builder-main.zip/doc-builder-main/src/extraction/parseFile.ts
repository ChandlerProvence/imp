import mammoth from "mammoth";
import PizZip from "pizzip";
import { parseCsv } from "./parseCsv";
import { appErrorException, isAppErrorException, toAppErrorException } from "../errors";

// ---------------------------------------------------------------------------
// Image file utilities
// ---------------------------------------------------------------------------

export const IMAGE_EXTENSIONS = new Set(["png", "jpg", "jpeg", "gif", "webp", "tiff"]);
export const MAX_IMAGE_SIZE = 10 * 1024 * 1024; // 10 MB
/** Upper bound for document uploads — pdf.js and mammoth load the whole file into memory. */
export const MAX_DOCUMENT_SIZE = 50 * 1024 * 1024; // 50 MB

/**
 * Average non-whitespace characters per page below which a PDF is treated as
 * a scan with no text layer (page numbers and stray marks stay well under this).
 */
const MIN_PDF_CHARS_PER_PAGE = 20;

const SUPPORTED_EXTENSIONS = new Set(["docx", "pdf", "xlsx", "xls", "csv", "txt", "md", "json"]);

const toMb = (bytes: number) => String(Math.round((bytes / (1024 * 1024)) * 10) / 10);

/**
 * Reject files we know can't be parsed before reading them: oversize files,
 * legacy .doc, and unsupported extensions. Throws an `AppErrorException`.
 */
export function assertParseable(file: File): void {
  const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
  const limit = IMAGE_EXTENSIONS.has(ext) ? MAX_IMAGE_SIZE : MAX_DOCUMENT_SIZE;
  if (file.size > limit) {
    throw appErrorException("file.too-large", {
      context: { fileName: file.name, sizeMb: toMb(file.size), limitMb: toMb(limit) },
      detail: `${file.name}: ${file.size} bytes > ${limit}`,
    });
  }
  if (ext === "doc") {
    throw appErrorException("file.legacy-doc", { context: { fileName: file.name } });
  }
  if (!SUPPORTED_EXTENSIONS.has(ext) && !IMAGE_EXTENSIONS.has(ext)) {
    throw appErrorException("file.unsupported", { context: { fileName: file.name, ext } });
  }
}

/** Returns true if the filename has a recognized image extension. */
export function isImageFile(fileName: string): boolean {
  const ext = fileName.split(".").pop()?.toLowerCase() ?? "";
  return IMAGE_EXTENSIONS.has(ext);
}

/**
 * Converts a File to a data URL (base64-encoded). Rejects files > MAX_IMAGE_SIZE.
 */
export function fileToDataUrl(file: File): Promise<string> {
  if (file.size > MAX_IMAGE_SIZE) {
    return Promise.reject(
      appErrorException("file.too-large", {
        context: { fileName: file.name, sizeMb: toMb(file.size), limitMb: toMb(MAX_IMAGE_SIZE) },
      }),
    );
  }
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error("Failed to read image file."));
    reader.readAsDataURL(file);
  });
}

// ---------------------------------------------------------------------------
// DOCX parsing with embedded image extraction
// ---------------------------------------------------------------------------

export interface DocxImageInfo {
  placeholder: string;
  dataUrl: string;
  altText?: string;
}

export interface DocxParseResult {
  text: string;
  images: DocxImageInfo[];
}

/**
 * Parse a DOCX file, extracting both text and embedded images.
 * Images are represented as placeholders (`[IMAGE_0]`, etc.) in the text.
 */
export async function parseDocxWithImages(file: File): Promise<DocxParseResult> {
  try {
    return await parseDocxWithImagesCore(file);
  } catch (err) {
    if (isAppErrorException(err)) throw err;
    // Any mammoth/JSZip failure means the file isn't a readable .docx
    // (corrupt, encrypted — which Word stores as a non-zip container — or misnamed)
    throw appErrorException("file.corrupt-docx", { context: { fileName: file.name }, cause: err });
  }
}

async function parseDocxWithImagesCore(file: File): Promise<DocxParseResult> {
  const buffer = await file.arrayBuffer();
  const images: DocxImageInfo[] = [];
  let imageIndex = 0;

  const result = await mammoth.convertToHtml(
    { arrayBuffer: buffer },
    {
      convertImage: mammoth.images.imgElement((image) => {
        const placeholder = `[IMAGE_${imageIndex}]`;
        const contentType = image.contentType ?? "image/png";
        return image.read("base64").then((base64Data) => {
          images.push({
            placeholder,
            dataUrl: `data:${contentType};base64,${base64Data}`,
            altText: undefined,
          });
          imageIndex++;
          // Return an img tag with the placeholder as alt text for later extraction
          return { src: "", alt: placeholder };
        });
      }),
    },
  );

  // Convert mammoth HTML to structured plain text with image placeholders
  const text = htmlToText(result.value);

  return { text, images };
}

/**
 * Extract plain text from DOCX header and footer XML parts.
 *
 * Mammoth doesn't extract headers/footers, so this is the only way to get
 * CUI banners that live there (e.g. "CUI//SP-PRVCY" stamped in a header).
 * Intentionally simple — all we need is plain text for the regex CUI scan,
 * not structured content.
 */
export function extractDocxHeaderFooterText(buffer: ArrayBuffer): string {
  try {
    const zip = new PizZip(buffer);
    const parts: string[] = [];

    for (const entry of Object.keys(zip.files)) {
      // Match word/header1.xml, word/footer2.xml, etc.
      if (/^word\/(header|footer)\d*\.xml$/i.test(entry)) {
        const raw = zip.file(entry)?.asText();
        if (raw) {
          // Strip XML tags and collapse whitespace
          const text = raw
            .replace(/<[^>]+>/g, " ")
            .replace(/\s+/g, " ")
            .trim();
          if (text) parts.push(text);
        }
      }
    }

    return parts.join("\n");
  } catch {
    // If the zip is malformed or anything fails, return empty — this is
    // a best-effort enhancement for CUI scanning, not a hard requirement.
    return "";
  }
}

/**
 * Lightweight HTML-to-text converter for mammoth's simple HTML output.
 * Preserves structure (paragraphs, lists, headings) and image placeholders.
 */
function htmlToText(html: string): string {
  let text = html;
  // Replace <br> with newline
  text = text.replace(/<br\s*\/?>/gi, "\n");
  // Replace headings with newline-delimited bold-like text
  text = text.replace(/<h[1-6][^>]*>(.*?)<\/h[1-6]>/gi, "\n$1\n\n");
  // Replace paragraphs with double newlines
  text = text.replace(/<\/p>/gi, "\n\n");
  text = text.replace(/<p[^>]*>/gi, "");
  // Replace list items with bullet points
  text = text.replace(/<li[^>]*>/gi, "• ");
  text = text.replace(/<\/li>/gi, "\n");
  // Replace img tags — extract alt text (which contains our placeholder)
  text = text.replace(/<img[^>]*alt="([^"]*)"[^>]*\/?>/gi, "$1");
  text = text.replace(/<img[^>]*\/?>/gi, "");
  // Strip all remaining tags
  text = text.replace(/<[^>]+>/g, "");
  // Decode common HTML entities
  text = text.replace(/&amp;/g, "&");
  text = text.replace(/&lt;/g, "<");
  text = text.replace(/&gt;/g, ">");
  text = text.replace(/&quot;/g, '"');
  text = text.replace(/&#39;/g, "'");
  text = text.replace(/&nbsp;/g, " ");
  // Collapse excessive blank lines
  text = text.replace(/\n{3,}/g, "\n\n");
  return text.trim();
}

// ---------------------------------------------------------------------------
// Main parseFile function
// ---------------------------------------------------------------------------

/**
 * Extract plain text from an uploaded file.
 * Supports .docx (mammoth), .pdf (pdfjs-dist), .xlsx/.xls (SheetJS), .csv, and .txt (direct read).
 */
export async function parseFile(file: File): Promise<string> {
  assertParseable(file);
  const ext = file.name.split(".").pop()?.toLowerCase();

  switch (ext) {
    case "docx":
      return parseDocx(file);
    case "pdf":
      return parsePdf(file);
    case "xlsx":
    case "xls":
      return parseExcelFile(file);
    case "csv":
      return parseCsvFile(file);
    case "txt":
    case "md":
    case "json":
      return file.text();
    default:
      throw appErrorException("file.unsupported", { context: { fileName: file.name, ext: ext ?? "" } });
  }
}

async function parseCsvFile(file: File): Promise<string> {
  const text = await file.text();
  return parseCsv(text);
}

async function parseExcelFile(file: File): Promise<string> {
  // Dynamic import to keep the initial bundle small — SheetJS is ~300KB
  const { parseExcel } = await import("./parseExcel");
  try {
    return await parseExcel(file);
  } catch (err) {
    throw appErrorException("file.spreadsheet", { context: { fileName: file.name }, cause: err });
  }
}

async function parseDocx(file: File): Promise<string> {
  // Use the image-aware parser but discard image data (caller gets plain text only).
  // Image placeholders remain in the text for callers that don't resolve them.
  const { text } = await parseDocxWithImages(file);
  return text;
}

async function parsePdf(file: File): Promise<string> {
  // Dynamic import to keep the initial bundle small — pdf.js is large
  const pdfjsLib = await import("pdfjs-dist");
  const pdfjsWorker = await import("pdfjs-dist/build/pdf.worker.min.mjs?url");
  pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorker.default;

  const buffer = await file.arrayBuffer();
  let pdf: Awaited<ReturnType<typeof pdfjsLib.getDocument>["promise"]>;
  try {
    pdf = await pdfjsLib.getDocument({ data: buffer }).promise;
  } catch (err) {
    const mapped = toAppErrorException(err, { domain: "file", context: { fileName: file.name } });
    if (mapped.appError.domain === "file") throw mapped;
    throw appErrorException("file.corrupt-pdf", { context: { fileName: file.name }, cause: err });
  }

  const pages: string[] = [];
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    const text = content.items
      .map((item) => ("str" in item ? item.str : ""))
      .join(" ");
    pages.push(text);
    // Release page resources to reduce memory pressure during large PDF parsing
    page.cleanup();
  }

  const textChars = pages.join("").replace(/\s/g, "").length;
  if (pdf.numPages > 0 && textChars / pdf.numPages < MIN_PDF_CHARS_PER_PAGE) {
    throw appErrorException("file.no-text", {
      context: { fileName: file.name },
      detail: `${file.name}: ${textChars} text characters across ${pdf.numPages} page(s)`,
    });
  }

  return pages.join("\n\n");
}
