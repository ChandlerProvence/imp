import { parseFile, assertParseable, isImageFile, fileToDataUrl, parseDocxWithImages, extractDocxHeaderFooterText, type DocxImageInfo } from "./parseFile";
import { extractImageDescription } from "./extractImageDescription";
import { mapWithLimit } from "../utils/concurrency";
import type { EndpointId } from "../ai/endpoints";

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/** Maximum number of embedded images to process per DOCX file. */
const MAX_DOCX_IMAGES = 10;

// ---------------------------------------------------------------------------
// parseFileStructure — extract text and images without network calls
// ---------------------------------------------------------------------------

export { type DocxImageInfo };

export interface ParsedFileStructure {
  /** Extracted text with `[IMAGE_n]` placeholders for embedded images. */
  text: string;
  /** Raw text from DOCX headers/footers (for CUI scanning). Empty for non-DOCX. */
  headerFooterText: string;
  /** Embedded images (DOCX) or the standalone image. Empty for other file types. */
  images: DocxImageInfo[];
  /** True when the file is a standalone image (not a DOCX with embedded images). */
  standaloneImage: boolean;
}

/**
 * Parse a file's structure — text, header/footer text, and embedded images —
 * without making any network calls. Image data URLs are extracted but not
 * sent to the vision API; call `resolveImages` separately for that.
 */
export async function parseFileStructure(file: File): Promise<ParsedFileStructure> {
  assertParseable(file);

  // Standalone image file
  if (isImageFile(file.name)) {
    const dataUrl = await fileToDataUrl(file);
    return {
      text: "[IMAGE_0]",
      headerFooterText: "",
      images: [{ placeholder: "[IMAGE_0]", dataUrl }],
      standaloneImage: true,
    };
  }

  // DOCX — use the image-aware parser + header/footer extraction
  const ext = file.name.split(".").pop()?.toLowerCase();
  if (ext === "docx") {
    const buffer = await file.arrayBuffer();
    const result = await parseDocxWithImages(file);
    const headerFooterText = extractDocxHeaderFooterText(buffer);
    return {
      text: result.text,
      headerFooterText,
      images: result.images,
      standaloneImage: false,
    };
  }

  // All other file types — standard text extraction, no images
  const text = await parseFile(file);
  return { text, headerFooterText: "", images: [], standaloneImage: false };
}

// ---------------------------------------------------------------------------
// resolveImages — convert image placeholders to text via the vision API
// ---------------------------------------------------------------------------

export interface ResolveImagesOptions {
  /** The parsed file structure from `parseFileStructure`. */
  parsed: Pick<ParsedFileStructure, "text" | "images" | "standaloneImage">;
  /** Original file name (for the vision prompt). */
  fileName: string;
  /** Which endpoint to route vision calls through. */
  endpoint: EndpointId;
  /** Optional AbortSignal for cancellation. */
  signal?: AbortSignal;
  /** Optional progress callback. */
  onProgress?: (status: string) => void;
}

/**
 * Convert image placeholders in parsed text to text descriptions via the
 * vision API. Returns the final text with all images resolved.
 *
 * For standalone images, returns the raw description (no wrapping).
 * For DOCX images, replaces `[IMAGE_n]` placeholders with `[Image: …]` blocks.
 */
export async function resolveImages({
  parsed,
  fileName,
  endpoint,
  signal,
  onProgress,
}: ResolveImagesOptions): Promise<string> {
  if (parsed.images.length === 0) return parsed.text;

  // Standalone image — return raw description
  if (parsed.standaloneImage) {
    onProgress?.("Extracting text from image…");
    const description = await extractImageDescription(
      parsed.images[0].dataUrl,
      fileName,
      signal,
      endpoint,
    );
    return description;
  }

  // DOCX embedded images
  const imagesToProcess = parsed.images.slice(0, MAX_DOCX_IMAGES);
  const skippedCount = parsed.images.length - imagesToProcess.length;

  onProgress?.(`Extracting text from ${imagesToProcess.length} embedded image${imagesToProcess.length > 1 ? "s" : ""}…`);

  // Process images in parallel with concurrency limit
  const rawDescriptions = await mapWithLimit(imagesToProcess, 2, async (img) => {
    if (signal?.aborted) throw new DOMException("Aborted", "AbortError");
    const desc = await extractImageDescription(
      img.dataUrl,
      `${fileName} — embedded image`,
      signal,
      endpoint,
    );
    return { placeholder: img.placeholder, description: desc };
  });

  // Replace placeholders with descriptions (skip errored items)
  let text = parsed.text;
  for (const item of rawDescriptions) {
    if ("error" in item) continue;
    text = text.replace(item.placeholder, `\n[Image: ${item.description}]\n`);
  }

  // Add note about skipped images if any
  if (skippedCount > 0) {
    text += `\n\n[Note: ${skippedCount} additional image${skippedCount > 1 ? "s were" : " was"} not processed]`;
  }

  return text;
}

// ---------------------------------------------------------------------------
// parseFileWithVision — convenience wrapper (existing API, kept for compat)
// ---------------------------------------------------------------------------

export interface ParseFileWithVisionResult {
  text: string;
  /** True if this file required vision API calls. */
  usedVision: boolean;
}

export interface ParseFileWithVisionOptions {
  /**
   * Which endpoint vision calls should route through. Defaults to the active endpoint.
   */
  visionEndpoint?: EndpointId;
}

/**
 * Parse a file, using the vision API for standalone images and DOCX embedded images.
 * Convenience wrapper that runs `parseFileStructure` + `resolveImages` in sequence.
 */
export async function parseFileWithVision(
  file: File,
  signal?: AbortSignal,
  onProgress?: (status: string) => void,
  opts?: ParseFileWithVisionOptions,
): Promise<ParseFileWithVisionResult> {
  const visionEndpoint = opts?.visionEndpoint;

  onProgress?.("Parsing document…");
  const parsed = await parseFileStructure(file);

  if (parsed.images.length === 0) {
    return { text: parsed.text, usedVision: false };
  }

  if (!visionEndpoint) {
    // No endpoint provided — caller must use the two-step API instead
    return { text: parsed.text, usedVision: false };
  }

  const text = await resolveImages({
    parsed,
    fileName: file.name,
    endpoint: visionEndpoint,
    signal,
    onProgress,
  });

  return { text, usedVision: true };
}
