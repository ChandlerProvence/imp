import { describe, it, expect } from "vitest";
import PizZip from "pizzip";
import { extractDocxHeaderFooterText } from "./parseFile";

// ---------------------------------------------------------------------------
// Helper: build a minimal zip buffer with arbitrary entries
// ---------------------------------------------------------------------------

function makeZipBuffer(entries: Record<string, string>): ArrayBuffer {
  const zip = new PizZip();
  for (const [path, content] of Object.entries(entries)) {
    zip.file(path, content);
  }
  const buf = zip.generate({ type: "arraybuffer" });
  return buf;
}

// ---------------------------------------------------------------------------
// extractDocxHeaderFooterText
// ---------------------------------------------------------------------------

describe("extractDocxHeaderFooterText", () => {
  it("returns header text containing CUI banner", () => {
    const xml =
      '<w:hdr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">' +
      "<w:p><w:r><w:t>CONTROLLED UNCLASSIFIED INFORMATION</w:t></w:r></w:p>" +
      "</w:hdr>";

    const buffer = makeZipBuffer({ "word/header1.xml": xml });
    const result = extractDocxHeaderFooterText(buffer);

    expect(result).toContain("CONTROLLED UNCLASSIFIED INFORMATION");
  });

  it("returns empty string when there are no header or footer files", () => {
    const buffer = makeZipBuffer({
      "word/document.xml": "<w:document/>",
      "[Content_Types].xml": "<Types/>",
    });
    const result = extractDocxHeaderFooterText(buffer);

    expect(result).toBe("");
  });

  it("strips XML tags so output contains no angle brackets", () => {
    const xml =
      '<w:ftr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">' +
      "<w:p><w:r><w:t>CUI//SP-PRVCY</w:t></w:r></w:p>" +
      "</w:ftr>";

    const buffer = makeZipBuffer({ "word/footer1.xml": xml });
    const result = extractDocxHeaderFooterText(buffer);

    expect(result).not.toMatch(/[<>]/);
    expect(result).toContain("CUI//SP-PRVCY");
  });
});
