/**
 * Parse a CSV file into a markdown-table text representation.
 * Handles RFC 4180 quoting (quoted fields, escaped quotes, commas in values).
 */
export function parseCsv(text: string): string {
  const rows = parseCsvRows(text);

  // Skip entirely empty rows
  const nonEmptyRows = rows.filter((row) =>
    row.some((cell) => cell !== ""),
  );

  if (nonEmptyRows.length === 0) {
    return "(Empty CSV)";
  }

  // First row is the header
  const headerCells = nonEmptyRows[0].map((cell) => cellToString(cell));
  const separator = headerCells.map(() => "---");
  const dataRows = nonEmptyRows.slice(1);

  const lines: string[] = [];
  lines.push(`| ${headerCells.join(" | ")} |`);
  lines.push(`| ${separator.join(" | ")} |`);

  for (const row of dataRows) {
    const cells = row.map((cell) => cellToString(cell));
    // Pad to header length so columns align
    while (cells.length < headerCells.length) cells.push("");
    lines.push(`| ${cells.join(" | ")} |`);
  }

  return lines.join("\n");
}

/** Convert a cell value to a pipe-safe string for markdown tables. */
function cellToString(cell: string): string {
  return cell.replace(/\|/g, "\\|").replace(/\n/g, " ");
}

/**
 * Parse CSV text into rows of string arrays (RFC 4180 compliant).
 * Handles: quoted fields, escaped quotes (""), commas inside quotes, newlines inside quotes.
 */
function parseCsvRows(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let i = 0;

  while (i < text.length) {
    // Skip leading whitespace before a field (but not newlines)
    // Actually, per RFC 4180 we should not skip — treat literally
    if (text[i] === '"') {
      // Quoted field
      i++; // skip opening quote
      let field = "";
      while (i < text.length) {
        if (text[i] === '"') {
          if (i + 1 < text.length && text[i + 1] === '"') {
            // Escaped quote
            field += '"';
            i += 2;
          } else {
            // Closing quote
            i++; // skip closing quote
            break;
          }
        } else {
          field += text[i];
          i++;
        }
      }
      row.push(field);
      // Advance past delimiter or end of line
      if (i < text.length && text[i] === ",") {
        i++;
      } else if (i < text.length && (text[i] === "\r" || text[i] === "\n")) {
        if (text[i] === "\r" && i + 1 < text.length && text[i + 1] === "\n") {
          i += 2;
        } else {
          i++;
        }
        rows.push(row);
        row = [];
      }
    } else if (text[i] === "," ) {
      // Empty field before comma
      row.push("");
      i++;
    } else if (text[i] === "\r" || text[i] === "\n") {
      // End of row
      if (text[i] === "\r" && i + 1 < text.length && text[i + 1] === "\n") {
        i += 2;
      } else {
        i++;
      }
      rows.push(row);
      row = [];
    } else {
      // Unquoted field
      let field = "";
      while (i < text.length && text[i] !== "," && text[i] !== "\r" && text[i] !== "\n") {
        field += text[i];
        i++;
      }
      row.push(field);
      if (i < text.length && text[i] === ",") {
        i++;
      } else if (i < text.length && (text[i] === "\r" || text[i] === "\n")) {
        if (text[i] === "\r" && i + 1 < text.length && text[i + 1] === "\n") {
          i += 2;
        } else {
          i++;
        }
        rows.push(row);
        row = [];
      }
    }
  }

  // Push last row if it has content
  if (row.length > 0) {
    rows.push(row);
  }

  return rows;
}
