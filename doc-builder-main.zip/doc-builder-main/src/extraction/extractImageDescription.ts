import Anthropic from "@anthropic-ai/sdk";
import type { Base64ImageSource, ImageBlockParam } from "@anthropic-ai/sdk/resources/messages";
import { appErrorException, isAbortError, toAppErrorException } from "../errors";
import { apiKeyStorageKey, getActiveEndpointId, getResolvedBaseUrl, type EndpointId } from "../ai/endpoints";
import { resolveModel } from "../ai/models";

// ---------------------------------------------------------------------------
// Image description extraction via vision API
// ---------------------------------------------------------------------------

const IMAGE_EXTRACTION_SYSTEM_PROMPT = `You are a document content extractor. Extract ALL text, tables, form fields, labels, numbers, and structural content from the image. Output as markdown.

Rules:
- Preserve the original structure (headings, lists, tables, paragraphs)
- Reproduce all text verbatim — do not summarize or paraphrase
- For tables, use markdown table syntax
- For forms, list each label: value pair
- For diagrams/charts, describe the data and relationships
- If the image contains handwriting, transcribe it as accurately as possible
- If parts are illegible, note [illegible] in that spot
- Do NOT add commentary or interpretation — just extract the content`;

/**
 * Sends an image to the vision API and returns a text description/transcription.
 * Uses the extraction (Sonnet) model for cost efficiency.
 *
 * @param endpoint Which endpoint to route the vision call through. Defaults to
 *   the currently active endpoint. Callers that need to keep image content off
 *   IL2 before a CUI determination (document upload) should pass "cui" explicitly.
 */
export async function extractImageDescription(
  dataUrl: string,
  fileName: string,
  signal?: AbortSignal,
  endpoint?: EndpointId,
): Promise<string> {
  const ep = endpoint ?? getActiveEndpointId();
  const apiKey = localStorage.getItem(apiKeyStorageKey(ep));
  if (!apiKey) {
    throw appErrorException("ai.no-key", { detail: `Image text extraction for ${fileName} needs an API key` });
  }

  // Parse the data URL to extract media_type and base64 data
  const match = dataUrl.match(/^data:(image\/[^;]+);base64,(.+)$/);
  if (!match) {
    throw new Error(`Invalid image data URL for ${fileName}.`);
  }
  const [, mediaType, base64Data] = match;

  const baseURL = (() => {
    const raw = getResolvedBaseUrl(ep);
    if (raw.startsWith("http")) return raw;
    return `${window.location.origin}${raw}`;
  })();

  const model = resolveModel(ep, "standard");

  const client = new Anthropic({
    baseURL,
    apiKey,
    dangerouslyAllowBrowser: true,
  });

  const imageBlock: ImageBlockParam = {
    type: "image",
    source: {
      type: "base64",
      media_type: mediaType as Base64ImageSource["media_type"],
      data: base64Data,
    },
  };

  let response: Anthropic.Message;
  try {
    response = await client.messages.create(
      {
        model,
        max_tokens: 4096,
        system: IMAGE_EXTRACTION_SYSTEM_PROMPT,
        messages: [
          {
            role: "user",
            content: [
              { type: "text", text: `Extract all content from this image (${fileName}):` },
              imageBlock,
            ],
          },
        ],
      },
      { signal: signal ?? undefined },
    );
  } catch (err) {
    if (isAbortError(err)) throw err;
    throw toAppErrorException(err, { domain: "ai", context: { model, fileName } });
  }

  const text = response.content
    .filter((b): b is Anthropic.TextBlock => b.type === "text")
    .map((b) => b.text)
    .join("");

  if (!text.trim()) {
    return "[No text content could be extracted from this image]";
  }

  return text;
}
