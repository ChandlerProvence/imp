import { describe, it, expect, vi, beforeEach } from "vitest";
import type { DocxImageInfo, DocxParseResult } from "./parseFile";

// ---------------------------------------------------------------------------
// Mocks
// ---------------------------------------------------------------------------

vi.mock("./extractImageDescription", () => ({
  extractImageDescription: vi.fn(),
}));

vi.mock("./parseFile", async (importOriginal) => {
  const actual = await importOriginal<typeof import("./parseFile")>();
  return {
    ...actual,
    parseDocxWithImages: vi.fn(),
    extractDocxHeaderFooterText: vi.fn(),
    parseFile: vi.fn(),
  };
});

import {
  parseDocxWithImages,
  extractDocxHeaderFooterText,
  parseFile,
} from "./parseFile";
import { extractImageDescription } from "./extractImageDescription";
import { parseFileStructure, resolveImages } from "./parseFileEnhanced";
import type { EndpointId } from "../ai/endpoints";

const mockParseDocxWithImages = vi.mocked(parseDocxWithImages);
const mockExtractDocxHeaderFooterText = vi.mocked(extractDocxHeaderFooterText);
const mockParseFile = vi.mocked(parseFile);
const mockExtractImageDescription = vi.mocked(extractImageDescription);

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Create a minimal File object with the given name and optional content. */
function fakeFile(name: string, content = ""): File {
  return new File([content], name, { type: "application/octet-stream" });
}

/** Build an array of fake DocxImageInfo entries. */
function fakeImages(count: number): DocxImageInfo[] {
  return Array.from({ length: count }, (_, i) => ({
    placeholder: `[IMAGE_${i}]`,
    dataUrl: `data:image/png;base64,img${i}`,
  }));
}

// ---------------------------------------------------------------------------
// Setup
// ---------------------------------------------------------------------------

beforeEach(() => {
  vi.clearAllMocks();
});

// ===========================================================================
// resolveImages
// ===========================================================================

describe("resolveImages", () => {
  const defaultEndpoint: EndpointId = "non-cui";

  it("replaces image placeholders with [Image: ...] descriptions", async () => {
    const images = fakeImages(2);
    const parsed = {
      text: "Before\n[IMAGE_0]\nMiddle\n[IMAGE_1]\nAfter",
      images,
      standaloneImage: false,
    };

    mockExtractImageDescription
      .mockResolvedValueOnce("Chart showing revenue growth")
      .mockResolvedValueOnce("Table of quarterly results");

    const result = await resolveImages({
      parsed,
      fileName: "report.docx",
      endpoint: defaultEndpoint,
    });

    expect(result).toContain("[Image: Chart showing revenue growth]");
    expect(result).toContain("[Image: Table of quarterly results]");
    // Original placeholders should be gone
    expect(result).not.toContain("[IMAGE_0]");
    expect(result).not.toContain("[IMAGE_1]");
  });

  it("processes at most 10 images and appends a skipped note for the rest", async () => {
    const images = fakeImages(12);
    const placeholders = images.map((img) => img.placeholder).join("\n");
    const parsed = {
      text: placeholders,
      images,
      standaloneImage: false,
    };

    // All 10 processed images return a description
    mockExtractImageDescription.mockResolvedValue("image content");

    const result = await resolveImages({
      parsed,
      fileName: "big.docx",
      endpoint: defaultEndpoint,
    });

    // Only 10 calls should have been made
    expect(mockExtractImageDescription).toHaveBeenCalledTimes(10);

    // The note about skipped images should be appended
    expect(result).toContain("2 additional images were not processed");
  });

  it("passes the endpoint through to extractImageDescription", async () => {
    const images = fakeImages(1);
    const parsed = {
      text: "[IMAGE_0]",
      images,
      standaloneImage: false,
    };
    const cuiEndpoint: EndpointId = "cui";

    mockExtractImageDescription.mockResolvedValueOnce("desc");

    await resolveImages({
      parsed,
      fileName: "doc.docx",
      endpoint: cuiEndpoint,
    });

    expect(mockExtractImageDescription).toHaveBeenCalledWith(
      images[0].dataUrl,
      expect.any(String),
      undefined, // signal
      cuiEndpoint,
    );
  });

  it("returns the raw description for a standalone image (no wrapping)", async () => {
    const rawDescription = "# Meeting Notes\n\n- Item 1\n- Item 2";
    const images: DocxImageInfo[] = [
      { placeholder: "[IMAGE_0]", dataUrl: "data:image/png;base64,abc" },
    ];
    const parsed = {
      text: "[IMAGE_0]",
      images,
      standaloneImage: true,
    };

    mockExtractImageDescription.mockResolvedValueOnce(rawDescription);

    const result = await resolveImages({
      parsed,
      fileName: "photo.png",
      endpoint: defaultEndpoint,
    });

    // Should return the raw description, NOT wrapped in [Image: ...]
    expect(result).toBe(rawDescription);
    expect(result).not.toContain("[Image:");
  });

  it("returns the original text when there are no images", async () => {
    const parsed = {
      text: "Plain text document",
      images: [],
      standaloneImage: false,
    };

    const result = await resolveImages({
      parsed,
      fileName: "plain.docx",
      endpoint: defaultEndpoint,
    });

    expect(result).toBe("Plain text document");
    expect(mockExtractImageDescription).not.toHaveBeenCalled();
  });
});

// ===========================================================================
// parseFileStructure
// ===========================================================================

describe("parseFileStructure", () => {
  it("returns images and headerFooterText for a .docx file", async () => {
    const images = fakeImages(3);
    const docxResult: DocxParseResult = {
      text: "Intro\n[IMAGE_0]\nBody\n[IMAGE_1]\nEnd\n[IMAGE_2]",
      images,
    };
    mockParseDocxWithImages.mockResolvedValueOnce(docxResult);
    mockExtractDocxHeaderFooterText.mockReturnValueOnce("CUI//SP-PRVCY");

    const file = fakeFile("contract.docx");
    const result = await parseFileStructure(file);

    expect(result.text).toBe(docxResult.text);
    expect(result.images).toEqual(images);
    expect(result.headerFooterText).toBe("CUI//SP-PRVCY");
    expect(result.standaloneImage).toBe(false);
  });

  it("returns standaloneImage: true with one image for an image file", async () => {
    // Create a small PNG-like file so fileToDataUrl can read it
    const pngBytes = new Uint8Array([0x89, 0x50, 0x4e, 0x47]);
    const file = new File([pngBytes], "photo.png", { type: "image/png" });

    const result = await parseFileStructure(file);

    expect(result.standaloneImage).toBe(true);
    expect(result.images).toHaveLength(1);
    expect(result.images[0].placeholder).toBe("[IMAGE_0]");
    expect(result.images[0].dataUrl).toMatch(/^data:/);
    expect(result.text).toBe("[IMAGE_0]");
    expect(result.headerFooterText).toBe("");
  });

  it("returns empty images and empty headerFooterText for a .pdf file", async () => {
    mockParseFile.mockResolvedValueOnce("Extracted PDF text content");

    const file = fakeFile("document.pdf");
    const result = await parseFileStructure(file);

    expect(result.text).toBe("Extracted PDF text content");
    expect(result.images).toEqual([]);
    expect(result.headerFooterText).toBe("");
    expect(result.standaloneImage).toBe(false);
  });

  it("delegates to parseFile for unsupported-for-images file types", async () => {
    mockParseFile.mockResolvedValueOnce("CSV content here");

    const file = fakeFile("data.csv");
    const result = await parseFileStructure(file);

    expect(result.text).toBe("CSV content here");
    expect(result.images).toEqual([]);
    expect(result.standaloneImage).toBe(false);
    expect(mockParseFile).toHaveBeenCalledWith(file);
  });
});
