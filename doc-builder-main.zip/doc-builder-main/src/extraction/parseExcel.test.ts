import { describe, it, expect } from "vitest";
import * as XLSX from "xlsx";
import { parseExcel } from "./parseExcel";
import { parseFile } from "./parseFile";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function makeExcelFile(
  sheets: Record<string, (string | number | boolean | null)[][]>,
  ext: "xlsx" | "xls" = "xlsx",
): File {
  const wb = XLSX.utils.book_new();
  for (const [name, data] of Object.entries(sheets)) {
    const ws = XLSX.utils.aoa_to_sheet(data);
    XLSX.utils.book_append_sheet(wb, ws, name);
  }
  const buf = XLSX.write(wb, { type: "array", bookType: ext });
  const mime =
    ext === "xlsx"
      ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      : "application/vnd.ms-excel";
  return new File([buf], `test.${ext}`, { type: mime });
}

// ---------------------------------------------------------------------------
// parseExcel
// ---------------------------------------------------------------------------

describe("parseExcel", () => {
  it("produces a markdown table for a simple sheet", async () => {
    const file = makeExcelFile({
      Data: [
        ["Name", "Age", "City"],
        ["Alice", 30, "Portland"],
        ["Bob", 25, "Seattle"],
      ],
    });

    const result = await parseExcel(file);

    expect(result).toContain("## Sheet: Data");
    expect(result).toContain("| Name | Age | City |");
    expect(result).toContain("| --- | --- | --- |");
    expect(result).toContain("| Alice | 30 | Portland |");
    expect(result).toContain("| Bob | 25 | Seattle |");
  });

  it("handles multiple sheets with headers", async () => {
    const file = makeExcelFile({
      Sheet1: [
        ["A", "B"],
        ["1", "2"],
      ],
      Sheet2: [
        ["X", "Y"],
        ["3", "4"],
      ],
    });

    const result = await parseExcel(file);

    expect(result).toContain("## Sheet: Sheet1");
    expect(result).toContain("## Sheet: Sheet2");
    expect(result).toContain("| A | B |");
    expect(result).toContain("| X | Y |");
  });

  it("skips entirely empty rows", async () => {
    const file = makeExcelFile({
      Data: [
        ["Header1", "Header2"],
        [null, null],
        ["val1", "val2"],
        [null, null],
        ["val3", "val4"],
      ],
    });

    const result = await parseExcel(file);

    // Should have header + 2 data rows, no empty rows
    const lines = result.split("\n").filter((l) => l.startsWith("|"));
    // header + separator + 2 data rows = 4 pipe lines
    expect(lines).toHaveLength(4);
    expect(result).toContain("| val1 | val2 |");
    expect(result).toContain("| val3 | val4 |");
  });

  it("skips entirely empty sheets", async () => {
    const file = makeExcelFile({
      Empty: [[null, null], [null, null]],
      HasData: [
        ["Col1"],
        ["value"],
      ],
    });

    const result = await parseExcel(file);

    expect(result).not.toContain("## Sheet: Empty");
    expect(result).toContain("## Sheet: HasData");
  });

  it("escapes pipe characters in cell values", async () => {
    const file = makeExcelFile({
      Data: [
        ["Command", "Description"],
        ["a | b", "pipe in value"],
      ],
    });

    const result = await parseExcel(file);

    expect(result).toContain("a \\| b");
  });

  it("flattens newlines in cell values", async () => {
    const file = makeExcelFile({
      Data: [
        ["Notes"],
        ["Line 1\nLine 2"],
      ],
    });

    const result = await parseExcel(file);

    expect(result).toContain("| Line 1 Line 2 |");
    expect(result).not.toContain("\nLine 2");
  });

  it("returns placeholder for completely empty workbook", async () => {
    const file = makeExcelFile({
      Empty: [[null]],
    });

    const result = await parseExcel(file);

    expect(result).toBe("(Empty spreadsheet)");
  });

  it("pads short rows to match header length", async () => {
    const file = makeExcelFile({
      Data: [
        ["A", "B", "C"],
        ["only one"],
      ],
    });

    const result = await parseExcel(file);

    // The data row should have 3 cells (padded with empty)
    expect(result).toContain("| only one |  |  |");
  });
});

// ---------------------------------------------------------------------------
// parseFile Excel dispatch
// ---------------------------------------------------------------------------

describe("parseFile Excel dispatch", () => {
  it("routes .xlsx to parseExcel", async () => {
    const file = makeExcelFile(
      { Sheet1: [["Hello"], ["World"]] },
      "xlsx",
    );

    const result = await parseFile(file);

    expect(result).toContain("## Sheet: Sheet1");
    expect(result).toContain("| Hello |");
  });

  it("routes .xls to parseExcel", async () => {
    const file = makeExcelFile(
      { Sheet1: [["Hello"], ["World"]] },
      "xls",
    );

    const result = await parseFile(file);

    expect(result).toContain("## Sheet: Sheet1");
    expect(result).toContain("| Hello |");
  });
});
