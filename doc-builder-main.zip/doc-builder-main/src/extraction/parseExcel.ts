/**
 * Parse an Excel file (.xlsx or .xls) into a markdown-table text representation.
 * Dynamically imported from parseFile.ts for bundle splitting.
 */
export async function parseExcel(file: File): Promise<string> {
  const XLSX = await import("xlsx");
  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: "array" });

  const sections: string[] = [];

  for (const sheetName of workbook.SheetNames) {
    const sheet = workbook.Sheets[sheetName];
    if (!sheet) continue;

    // Get data as array-of-arrays; raw: false formats dates as strings
    const rows: (string | number | boolean | null)[][] = XLSX.utils.sheet_to_json(
      sheet,
      { header: 1, defval: null, raw: false },
    );

    // Skip entirely empty sheets
    const nonEmptyRows = rows.filter((row) =>
      row.some((cell) => cell !== null && cell !== undefined && cell !== ""),
    );
    if (nonEmptyRows.length === 0) continue;

    // Build markdown table — first non-empty row is the header
    const headerRow = nonEmptyRows[0] ?? [];
    const headerCells = headerRow.map((cell) => cellToString(cell));
    const separator = headerCells.map(() => "---");
    const dataRows = nonEmptyRows.slice(1);

    const lines: string[] = [];
    lines.push(`## Sheet: ${sheetName}`);
    lines.push("");
    lines.push(`| ${headerCells.join(" | ")} |`);
    lines.push(`| ${separator.join(" | ")} |`);

    for (const row of dataRows) {
      const cells = row.map((cell) => cellToString(cell));
      // Pad to header length so columns align
      while (cells.length < headerCells.length) cells.push("");
      lines.push(`| ${cells.join(" | ")} |`);
    }

    sections.push(lines.join("\n"));
  }

  if (sections.length === 0) {
    return "(Empty spreadsheet)";
  }

  return sections.join("\n\n");
}

/** Convert a cell value to a pipe-safe string for markdown tables. */
function cellToString(cell: unknown): string {
  if (cell === null || cell === undefined) return "";
  return String(cell).replace(/\|/g, "\\|").replace(/\n/g, " ");
}
