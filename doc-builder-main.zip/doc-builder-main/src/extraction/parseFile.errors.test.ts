import { describe, it, expect, vi, beforeEach } from "vitest";

const getDocument = vi.fn();
vi.mock("pdfjs-dist", () => ({ GlobalWorkerOptions: {}, getDocument }));
vi.mock("pdfjs-dist/build/pdf.worker.min.mjs?url", () => ({ default: "" }));

import { parseFile, assertParseable, MAX_DOCUMENT_SIZE } from "./parseFile";
import { isAppErrorException } from "../errors";

function fileOf(name: string, content: BlobPart = "x", size?: number): File {
  const f = new File([content], name);
  if (size !== undefined) Object.defineProperty(f, "size", { value: size });
  return f;
}

async function kindOf(p: Promise<unknown>): Promise<string> {
  try {
    await p;
  } catch (err) {
    if (isAppErrorException(err)) return err.appError.kind;
    throw err;
  }
  throw new Error("expected rejection");
}

function pdfWithPages(texts: string[]) {
  return {
    promise: Promise.resolve({
      numPages: texts.length,
      getPage: (i: number) =>
        Promise.resolve({
          getTextContent: () => Promise.resolve({ items: [{ str: texts[i - 1] }] }),
          cleanup: () => {},
        }),
    }),
  };
}

beforeEach(() => getDocument.mockReset());

describe("assertParseable", () => {
  it("rejects oversize documents with sizes in the message", () => {
    try {
      assertParseable(fileOf("big.pdf", "x", MAX_DOCUMENT_SIZE + 1));
      throw new Error("expected throw");
    } catch (err) {
      expect(isAppErrorException(err) && err.appError.kind).toBe("file.too-large");
      expect(isAppErrorException(err) && err.appError.message).toMatch(/big\.pdf is 50 MB\. The limit is 50 MB\./);
    }
  });

  it("applies the smaller image limit to images", () => {
    expect(() => assertParseable(fileOf("pic.png", "x", 11 * 1024 * 1024))).toThrow(/limit is 10 MB/);
  });

  it("rejects legacy .doc with Save As guidance", () => {
    expect(() => assertParseable(fileOf("old.doc"))).toThrow(/old-style \.doc/);
  });

  it("rejects unsupported extensions", () => {
    expect(() => assertParseable(fileOf("deck.pptx"))).toThrow(/\.pptx files can't be read/);
  });

  it("accepts supported files", () => {
    expect(() => assertParseable(fileOf("notes.txt"))).not.toThrow();
    expect(() => assertParseable(fileOf("scan.jpg"))).not.toThrow();
  });
});

describe("parseFile error mapping", () => {
  it("maps a non-zip .docx to file.corrupt-docx", async () => {
    expect(await kindOf(parseFile(fileOf("broken.docx", "definitely not a zip")))).toBe("file.corrupt-docx");
  });

  it("maps a password-protected PDF to file.encrypted-pdf", async () => {
    getDocument.mockReturnValue({
      promise: Promise.reject(Object.assign(new Error("No password given"), { name: "PasswordException" })),
    });
    expect(await kindOf(parseFile(fileOf("locked.pdf")))).toBe("file.encrypted-pdf");
  });

  it("maps an unrecognised pdf.js failure to file.corrupt-pdf", async () => {
    getDocument.mockReturnValue({ promise: Promise.reject(new Error("bad XRef entry")) });
    expect(await kindOf(parseFile(fileOf("weird.pdf")))).toBe("file.corrupt-pdf");
  });

  it("rejects a PDF with no text layer as file.no-text", async () => {
    getDocument.mockReturnValue(pdfWithPages(["", " 2 ", ""]));
    expect(await kindOf(parseFile(fileOf("scan.pdf")))).toBe("file.no-text");
  });

  it("returns text for a PDF with a real text layer", async () => {
    getDocument.mockReturnValue(pdfWithPages(["This page has plenty of selectable text on it."]));
    await expect(parseFile(fileOf("ok.pdf"))).resolves.toContain("plenty of selectable text");
  });
});
