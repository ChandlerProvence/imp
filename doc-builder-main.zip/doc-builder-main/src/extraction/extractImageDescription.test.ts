import { describe, it, expect, vi, beforeEach } from "vitest";

vi.mock("@anthropic-ai/sdk", async (importOriginal) => {
  const { mockAnthropicModule } = await import("../test/mockAnthropic");
  return mockAnthropicModule(await importOriginal());
});

import Anthropic from "@anthropic-ai/sdk";
import { anthropicMocks, message, resetAnthropicMocks, textBlock, toolUseBlock } from "../test/mockAnthropic";
import { extractImageDescription } from "./extractImageDescription";
import { ACTIVE_ENDPOINT_KEY, ENDPOINTS, apiKeyStorageKey, getResolvedBaseUrl } from "../ai/endpoints";
import { _resetModelsForTests, setModelOverride } from "../ai/models";
import { isAppErrorException } from "../errors";

const PNG = "data:image/png;base64,iVBORw0KGgo=";

async function rejection(p: Promise<unknown>): Promise<unknown> {
  try {
    await p;
  } catch (e) {
    return e;
  }
  throw new Error("expected rejection");
}

beforeEach(() => {
  resetAnthropicMocks();
  _resetModelsForTests();
  localStorage.setItem(apiKeyStorageKey("non-cui"), "k-il2");
});

describe("extractImageDescription", () => {
  it("sends the image as a base64 block with the data URL's media type, using the standard model", async () => {
    anthropicMocks.create.mockResolvedValue(message({ content: [textBlock("# Title")] }));
    const ctrl = new AbortController();
    expect(await extractImageDescription(PNG, "scan.png", ctrl.signal)).toBe("# Title");

    expect(anthropicMocks.constructed[0]).toEqual({
      baseURL: `${window.location.origin}${getResolvedBaseUrl("non-cui")}`,
      apiKey: "k-il2",
      dangerouslyAllowBrowser: true,
    });
    const [params, opts] = anthropicMocks.create.mock.calls[0];
    expect(params).toEqual({
      model: ENDPOINTS["non-cui"].models.standard,
      max_tokens: 4096,
      system: expect.stringContaining("document content extractor"),
      messages: [
        {
          role: "user",
          content: [
            { type: "text", text: "Extract all content from this image (scan.png):" },
            { type: "image", source: { type: "base64", media_type: "image/png", data: "iVBORw0KGgo=" } },
          ],
        },
      ],
    });
    expect(opts?.signal).toBe(ctrl.signal);
  });

  it("passes other image media types through", async () => {
    anthropicMocks.create.mockResolvedValue(message({ content: [textBlock("x")] }));
    await extractImageDescription("data:image/jpeg;base64,/9j/AA==", "p.jpg");
    const content = (anthropicMocks.create.mock.calls[0][0].messages as { content: unknown[] }[])[0].content;
    expect(content[1]).toMatchObject({ source: { media_type: "image/jpeg", data: "/9j/AA==" } });
  });

  it("routes through the endpoint override, using its key and model", async () => {
    localStorage.setItem(apiKeyStorageKey("cui"), "k-cui");
    anthropicMocks.create.mockResolvedValue(message({ content: [textBlock("x")] }));
    await extractImageDescription(PNG, "a.png", undefined, "cui");
    expect(anthropicMocks.constructed[0]).toMatchObject({
      apiKey: "k-cui",
      baseURL: `${window.location.origin}${getResolvedBaseUrl("cui")}`,
    });
    expect(anthropicMocks.create.mock.calls[0][0].model).toBe(ENDPOINTS.cui.models.standard);
  });

  it("defaults to the active endpoint and honours a model override", async () => {
    localStorage.setItem(ACTIVE_ENDPOINT_KEY, "cui");
    localStorage.setItem(apiKeyStorageKey("cui"), "k-cui");
    setModelOverride("cui", "standard", "vision-x");
    anthropicMocks.create.mockResolvedValue(message({ content: [textBlock("x")] }));
    await extractImageDescription(PNG, "a.png");
    expect(anthropicMocks.constructed[0].apiKey).toBe("k-cui");
    expect(anthropicMocks.create.mock.calls[0][0].model).toBe("vision-x");
  });

  it("joins text blocks and ignores non-text blocks", async () => {
    anthropicMocks.create.mockResolvedValue(message({ content: [textBlock("a"), toolUseBlock("t", {}), textBlock("b")] }));
    expect(await extractImageDescription(PNG, "a.png")).toBe("ab");
  });

  it("returns a placeholder when the reply has no text", async () => {
    anthropicMocks.create.mockResolvedValue(message({ content: [textBlock("  \n ")] }));
    expect(await extractImageDescription(PNG, "a.png")).toBe("[No text content could be extracted from this image]");
  });

  it("throws ai.no-key (naming the file) when the endpoint has no key", async () => {
    const err = await rejection(extractImageDescription(PNG, "a.png", undefined, "cui"));
    expect(isAppErrorException(err) && err.appError.kind).toBe("ai.no-key");
    expect(isAppErrorException(err) && err.appError.detail).toContain("a.png");
    expect(anthropicMocks.create).not.toHaveBeenCalled();
  });

  it("throws a plain Error for a non-image or malformed data URL", async () => {
    const err = await rejection(extractImageDescription("data:application/pdf;base64,AAA", "a.pdf"));
    expect(err).toBeInstanceOf(Error);
    expect(isAppErrorException(err)).toBe(false);
    expect((err as Error).message).toBe("Invalid image data URL for a.pdf.");
    expect(anthropicMocks.create).not.toHaveBeenCalled();
  });

  it("rethrows an abort error unchanged", async () => {
    const abortErr = new Anthropic.APIUserAbortError();
    anthropicMocks.create.mockRejectedValue(abortErr);
    expect(await rejection(extractImageDescription(PNG, "a.png", AbortSignal.abort()))).toBe(abortErr);
  });

  it("wraps API errors as AppErrors with model and file context", async () => {
    anthropicMocks.create.mockRejectedValue(
      new Anthropic.AuthenticationError(401, { error: { message: "bad key" } }, "bad key", new Headers()),
    );
    const err = await rejection(extractImageDescription(PNG, "a.png"));
    expect(isAppErrorException(err)).toBe(true);
    if (isAppErrorException(err)) {
      expect(err.appError.kind).toBe("ai.auth");
      expect(err.appError.context).toEqual({ model: ENDPOINTS["non-cui"].models.standard, fileName: "a.png" });
    }
  });

  it("maps a 400 to ai.bad-request", async () => {
    anthropicMocks.create.mockRejectedValue(new Anthropic.BadRequestError(400, undefined, "image too large", new Headers()));
    const err = await rejection(extractImageDescription(PNG, "a.png"));
    expect(isAppErrorException(err) && err.appError.kind).toBe("ai.bad-request");
  });
});
