import { describe, it, expect } from "vitest";
import { parseCsv } from "./parseCsv";
import { parseFile } from "./parseFile";

// ---------------------------------------------------------------------------
// parseCsv
// ---------------------------------------------------------------------------

describe("parseCsv", () => {
  it("produces a markdown table for simple CSV", () => {
    const csv = "Name,Age,City\nAlice,30,Portland\nBob,25,Seattle\n";
    const result = parseCsv(csv);

    expect(result).toContain("| Name | Age | City |");
    expect(result).toContain("| --- | --- | --- |");
    expect(result).toContain("| Alice | 30 | Portland |");
    expect(result).toContain("| Bob | 25 | Seattle |");
  });

  it("handles quoted fields with commas", () => {
    const csv = 'Name,Description\nWidget,"A small, useful item"\n';
    const result = parseCsv(csv);

    expect(result).toContain("| Widget | A small, useful item |");
  });

  it("handles escaped quotes inside quoted fields", () => {
    const csv = 'Name,Quote\nAlice,"She said ""hello"""\n';
    const result = parseCsv(csv);

    expect(result).toContain('| Alice | She said "hello" |');
  });

  it("handles newlines inside quoted fields", () => {
    const csv = 'Name,Notes\nAlice,"Line 1\nLine 2"\n';
    const result = parseCsv(csv);

    // Newlines in cells are flattened to spaces
    expect(result).toContain("| Alice | Line 1 Line 2 |");
  });

  it("skips entirely empty rows", () => {
    const csv = "A,B\n\nval1,val2\n\nval3,val4\n";
    const result = parseCsv(csv);

    const dataLines = result.split("\n").filter((l) => l.startsWith("| ") && !l.includes("---"));
    // header + 2 data rows = 3
    expect(dataLines).toHaveLength(3);
  });

  it("escapes pipe characters in cell values", () => {
    const csv = "Command,Desc\na | b,pipe test\n";
    const result = parseCsv(csv);

    expect(result).toContain("a \\| b");
  });

  it("returns placeholder for empty CSV", () => {
    const result = parseCsv("");
    expect(result).toBe("(Empty CSV)");
  });

  it("returns placeholder for CSV with only empty rows", () => {
    const result = parseCsv("\n\n\n");
    expect(result).toBe("(Empty CSV)");
  });

  it("pads short rows to match header length", () => {
    const csv = "A,B,C\nonly one\n";
    const result = parseCsv(csv);

    expect(result).toContain("| only one |  |  |");
  });

  it("handles CRLF line endings", () => {
    const csv = "Name,Age\r\nAlice,30\r\nBob,25\r\n";
    const result = parseCsv(csv);

    expect(result).toContain("| Alice | 30 |");
    expect(result).toContain("| Bob | 25 |");
  });

  it("handles file without trailing newline", () => {
    const csv = "X,Y\n1,2";
    const result = parseCsv(csv);

    expect(result).toContain("| X | Y |");
    expect(result).toContain("| 1 | 2 |");
  });
});

// ---------------------------------------------------------------------------
// parseFile CSV dispatch
// ---------------------------------------------------------------------------

describe("parseFile CSV dispatch", () => {
  it("routes .csv to parseCsv and returns markdown table", async () => {
    const csv = "Col1,Col2\nA,B\n";
    const file = new File([csv], "data.csv", { type: "text/csv" });

    const result = await parseFile(file);

    expect(result).toContain("| Col1 | Col2 |");
    expect(result).toContain("| A | B |");
  });
});
