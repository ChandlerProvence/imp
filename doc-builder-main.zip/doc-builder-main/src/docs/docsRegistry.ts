/**
 * Auto-discovered registry of markdown files for the in-app Documentation page.
 * Only `docs/public/` and `docs/help/` are published; other files under `docs/`
 * are internal and never bundled.
 */

export interface DocEntry {
  /** Path relative to `docs/` without the `.md` extension, e.g. `help/api-key-setup`. */
  id: string;
  /** Sidebar group label derived from the folder. */
  group: string;
  /** First `# ` heading, or a prettified filename. */
  title: string;
  markdown: string;
}

export interface DocGroup {
  label: string;
  entries: DocEntry[];
}

export const DEFAULT_DOC_ID = "public/development-plan";

const GROUP_LABELS: Record<string, string> = {
  public: "Project",
  help: "Help",
};

/** Fixed groups first, in this order; any other folders follow alphabetically. */
const GROUP_ORDER = ["Help", "Project"];

function titleCase(s: string): string {
  return s
    .split(/[-_\s]+/)
    .filter(Boolean)
    .map((w) => w[0].toUpperCase() + w.slice(1))
    .join(" ");
}

/** First level-1 heading outside fenced code blocks. */
function firstHeading(markdown: string): string | null {
  let inFence = false;
  for (const line of markdown.split("\n")) {
    if (/^\s*(```|~~~)/.test(line)) inFence = !inFence;
    else if (!inFence) {
      const m = line.match(/^#\s+(.+?)\s*#*\s*$/);
      if (m) return m[1];
    }
  }
  return null;
}

/**
 * Build entries from a glob result. Keys may be any path containing a `docs/`
 * segment (e.g. `../../docs/help/x.md`); everything up to it is stripped.
 */
export function buildDocIndex(raw: Record<string, string>): DocEntry[] {
  return Object.entries(raw).map(([path, markdown]) => {
    const id = path.replace(/^(?:\.\.?\/)*docs\//, "").replace(/\.md$/, "");
    const slash = id.lastIndexOf("/");
    const folder = slash === -1 ? "" : id.slice(0, slash);
    const filename = id.slice(slash + 1);
    return {
      id,
      group: GROUP_LABELS[folder] ?? titleCase(folder),
      title: firstHeading(markdown) ?? titleCase(filename),
      markdown,
    };
  });
}

/** Group entries for display: fixed groups first, then alphabetical; entries by title. */
export function groupDocs(entries: DocEntry[]): DocGroup[] {
  const byGroup = new Map<string, DocEntry[]>();
  for (const e of entries) {
    const list = byGroup.get(e.group) ?? [];
    list.push(e);
    byGroup.set(e.group, list);
  }
  const rank = (label: string) => {
    const i = GROUP_ORDER.indexOf(label);
    return i === -1 ? GROUP_ORDER.length : i;
  };
  return [...byGroup.entries()]
    .sort(([a], [b]) => rank(a) - rank(b) || a.localeCompare(b))
    .map(([label, list]) => ({
      label,
      entries: [...list].sort((a, b) => a.title.localeCompare(b.title)),
    }));
}

const RAW = import.meta.glob<string>(["../../docs/public/**/*.md", "../../docs/help/**/*.md"], {
  query: "?raw",
  import: "default",
  eager: true,
});

export const DOC_INDEX: DocEntry[] = buildDocIndex(RAW);

export function findDoc(id: string | undefined, index: DocEntry[] = DOC_INDEX): DocEntry | undefined {
  if (!id) return undefined;
  const clean = id.replace(/\/+$/, "").replace(/\.md$/, "");
  // Project docs lived at the docs/ root before moving to docs/public/; keep old URLs working
  return index.find((d) => d.id === clean) ?? index.find((d) => d.id === `public/${clean}`);
}

/**
 * Resolve a markdown link inside doc `currentId` to an in-app route
 * (`/docs/<id>`), or `null` if it doesn't point at a known doc. Fragments are
 * dropped because rendered headings don't carry ids yet.
 */
export function resolveDocHref(
  currentId: string,
  href: string | undefined,
  index: DocEntry[] = DOC_INDEX,
): string | null {
  if (!href || href.startsWith("#") || /^[a-z][a-z0-9+.-]*:/i.test(href)) return null;
  const path = href.split(/[?#]/)[0];
  if (!path) return null;

  let segments: string[];
  if (path.startsWith("/docs/")) {
    segments = path.slice("/docs/".length).split("/");
  } else if (path.startsWith("/")) {
    return null;
  } else {
    segments = [...currentId.split("/").slice(0, -1), ...path.split("/")];
  }

  const resolved: string[] = [];
  for (const seg of segments) {
    if (seg === "" || seg === ".") continue;
    if (seg === "..") {
      if (resolved.length === 0) return null; // escapes docs/
      resolved.pop();
    } else {
      resolved.push(seg);
    }
  }

  const target = findDoc(resolved.join("/"), index);
  return target ? `/docs/${target.id}` : null;
}
