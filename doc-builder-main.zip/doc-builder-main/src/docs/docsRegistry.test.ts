import { describe, it, expect } from "vitest";
import { buildDocIndex, groupDocs, findDoc, resolveDocHref, DOC_INDEX, DEFAULT_DOC_ID } from "./docsRegistry";

const RAW = {
  "../../docs/public/development-plan.md": "# Development Plan\n\nBody",
  "../../docs/public/pop-proposal.md": "# POP Proposal\n\nSee [x](fms-procurement-process.md#11-gaps).",
  "../../docs/public/fms-procurement-process.md": "# FMS Procurement\n",
  "../../docs/public/progress-slides-2026-07-30.md": "**BANNER**\n\n---\n\n# Progress Update\n",
  "../../docs/public/no-heading-file.md": "just text\n```sh\n# not a heading\n```\n",
  "../../docs/help/api-key-setup.md": "# AI Assistant Setup\n",
  "../../docs/help/asksage-setup.md": "# SharePoint Setup\n",
  "../../docs/archive/old-notes.md": "# Old Notes\n",
};

const index = buildDocIndex(RAW);

describe("buildDocIndex", () => {
  it("derives ids relative to docs/ without the extension", () => {
    expect(index.map((d) => d.id).sort()).toEqual([
      "archive/old-notes",
      "help/api-key-setup",
      "help/asksage-setup",
      "public/development-plan",
      "public/fms-procurement-process",
      "public/no-heading-file",
      "public/pop-proposal",
      "public/progress-slides-2026-07-30",
    ]);
  });

  it("uses the first heading as the title, skipping code fences", () => {
    expect(findDoc("public/progress-slides-2026-07-30", index)?.title).toBe("Progress Update");
    expect(findDoc("public/no-heading-file", index)?.title).toBe("No Heading File");
  });

  it("maps folders to group labels", () => {
    expect(findDoc("help/api-key-setup", index)?.group).toBe("Help");
    expect(findDoc("public/development-plan", index)?.group).toBe("Project");
    expect(findDoc("archive/old-notes", index)?.group).toBe("Archive");
  });
});

describe("groupDocs", () => {
  it("orders Help, Project, then other folders; entries by title", () => {
    const groups = groupDocs(index);
    expect(groups.map((g) => g.label)).toEqual(["Help", "Project", "Archive"]);
    expect(groups[0].entries.map((e) => e.title)).toEqual(["AI Assistant Setup", "SharePoint Setup"]);
  });
});

describe("findDoc", () => {
  it("tolerates trailing slashes and .md", () => {
    expect(findDoc("help/api-key-setup/", index)?.id).toBe("help/api-key-setup");
    expect(findDoc("public/pop-proposal.md", index)?.id).toBe("public/pop-proposal");
    expect(findDoc("missing", index)).toBeUndefined();
    expect(findDoc(undefined, index)).toBeUndefined();
  });

  it("falls back to public/ for pre-move ids", () => {
    expect(findDoc("development-plan", index)?.id).toBe("public/development-plan");
    expect(findDoc("pop-proposal.md", index)?.id).toBe("public/pop-proposal");
  });
});

describe("resolveDocHref", () => {
  it("resolves sibling .md links and drops fragments", () => {
    expect(resolveDocHref("public/pop-proposal", "fms-procurement-process.md#11-gaps", index)).toBe(
      "/docs/public/fms-procurement-process",
    );
  });

  it("resolves extensionless links relative to the current folder", () => {
    expect(resolveDocHref("help/api-key-setup", "asksage-setup", index)).toBe("/docs/help/asksage-setup");
  });

  it("resolves ../ links and absolute /docs/ links", () => {
    expect(resolveDocHref("help/api-key-setup", "../public/development-plan.md", index)).toBe(
      "/docs/public/development-plan",
    );
    expect(resolveDocHref("public/development-plan", "../help/api-key-setup.md", index)).toBe(
      "/docs/help/api-key-setup",
    );
    expect(resolveDocHref("public/development-plan", "/docs/help/api-key-setup", index)).toBe(
      "/docs/help/api-key-setup",
    );
  });

  it("returns null for unknown, external, fragment, and out-of-tree links", () => {
    expect(resolveDocHref("public/pop-proposal", "missing.md", index)).toBeNull();
    expect(resolveDocHref("public/pop-proposal", "https://example.com/a.md", index)).toBeNull();
    expect(resolveDocHref("public/pop-proposal", "mailto:a@b.c", index)).toBeNull();
    expect(resolveDocHref("public/pop-proposal", "#section", index)).toBeNull();
    expect(resolveDocHref("public/pop-proposal", "../../README.md", index)).toBeNull();
    expect(resolveDocHref("public/pop-proposal", undefined, index)).toBeNull();
  });
});

describe("DOC_INDEX (real docs/ folder)", () => {
  it("includes the default doc and the help pages", () => {
    expect(findDoc(DEFAULT_DOC_ID)).toBeDefined();
    expect(DOC_INDEX.some((d) => d.id === "help/api-key-setup")).toBe(true);
  });

  it("publishes only docs/public/ and docs/help/", () => {
    const leaked = DOC_INDEX.filter((d) => !/^(public|help)\//.test(d.id)).map((d) => d.id);
    expect(leaked).toEqual([]);
  });
});
