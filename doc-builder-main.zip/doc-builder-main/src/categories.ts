/** A category for visually grouping document schemas. */
export interface CategoryDef {
  id: string;
  label: string;
  /** Display order. Lower numbers appear first. */
  order: number;
}

/**
 * Known categories with display metadata.
 * Schemas referencing an unknown category still render with a title-cased label.
 */
export const CATEGORIES: CategoryDef[] = [
  { id: "fms", label: "Foreign Military Sales", order: 1 },
  { id: "legal", label: "Legal", order: 2 },
  { id: "program-management", label: "Program Management", order: 3 },
  // User-uploaded templates (see src/schemas/userTemplates.ts) — always last
  { id: "custom", label: "Custom Templates", order: 99 },
];

/** Quick lookup by category id. */
export const CATEGORY_MAP: Map<string, CategoryDef> = new Map(
  CATEGORIES.map((c) => [c.id, c]),
);
