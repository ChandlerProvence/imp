# Doc Builder for LCSP and CDRL Automation: Selling Points

*Last updated: October 23, 2026.*

*Why Doc Builder fits the Life Cycle Sustainment Plan (LCSP) and other Contract Data Requirements List (CDRL) deliverables, what it does for an LCSP author today, and what it has already delivered on the FMS F-16 Sustainment program. Figures are marked as timed, confirmed, or estimated; sources are the process baseline (`docs/public/fms-procurement-process.md`), the portal proposal (`docs/public/pop-proposal.md`), the tutorial outline (`docs/public/tutorial-outline.md`), and the LCSP schema itself (`src/schemas/lcsp/`).*

**Live app:** <https://ams-oot.pages.lsde.leidos.com/doc-builder/>

---

## The problem

A CDRL deliverable such as the LCSP is a long document with a prescribed outline, written from material that already exists elsewhere. The DoD LCSP Outline v3.0 and DoDI 5000.91 fix the structure: twelve Integrated Product Support (IPS) elements, numbered sections to the fourth level, mandated tables and figures, a signature page, a record of changes. The content comes from the technical volume, the Statement of Work or PWS, the RFP, and monthly status reports. The author's job is to turn those sources into roughly fifty narrative sections and two dozen tables that agree with each other and with the outline.

Done by hand, that job has four costs:

- **Days of drafting.** The LCSP template has 54 narrative sections and 23 tables. Each section has to be written from scratch or adapted from a prior plan, then checked against the outline's expectations for that section. The tutorial outline puts a manual fill at days of work.
- **Internal inconsistency.** The maintenance concept in 4.3.1 drives depot activation, supply support, technical data, support equipment, and manpower. A change in one is a change in six places, and a reviewer finds the mismatches late.
- **Source disagreement that nobody catches.** The technical volume describes the contractor's approach; the PWS states the Government's requirement. They routinely differ on maintenance levels, deliverables, and scope. A plan written from one without checking the other inherits the gap.
- **Resubmission.** An LCSP is a living document, updated at each milestone, after Business Case Analysis approval, every five years, and for major upgrades. Each cycle repeats the assembly: new record-of-changes row, revised sections, regenerated ToC and lists of tables and figures, re-marked CUI cover.

Every CDRL with a Data Item Description shares this shape: fixed outline, recurring header facts (contract number, CDRL number, program, CUI markings), prose per section, tables, and periodic resubmission. The LCSP is the largest example in the tool today, not the only one it fits.

---

## Who it is for

| Audience | What they get |
|---|---|
| **LCSP authors and product support managers** | A guided interview over the full LCSP Outline v3.0 structure. Attach the technical volume and PWS, let the AI draft every narrative section and table it can support, accept or redraft section by section, and download a Word document in the official template with a working ToC. |
| **Program managers and CDRL owners** | A repeatable path from "we owe this deliverable" to a reviewable draft, with the Government-authoritative source (PWS) preferred over the contractor's approach (technical volume) where they differ, and disagreements between them listed rather than buried. |
| **Reviewers (PSM, PCO, PFM, lead engineer, PEO, CAE)** | Signature page and record of changes built into the output. Review comments are incorporated by pointing the AI at one section at a time, so the rest of the plan is untouched. |
| **Programs with a CDRL backlog** | Adding a deliverable is a tagged Word template plus a JSON schema, about two developer hours, with no application code. Deliverables that share header facts can share one interview. |
| **Security and IT** | LCSP inputs are usually CUI. The tool has a CUI (IL5) endpoint, automatic CUI detection on upload, and a cover page that carries Controlled By, CUI Category, and Limited Dissemination Control. No server, no database to host. |

---

## What it does for an LCSP today

### 1. The full LCSP Outline v3.0 as a schema

The LCSP document type is built from the Government's integrated LCSP template (`iLCSP.docx`), with 106 instructional paragraphs and the "Overview and Expectations" front matter stripped so only the plan remains. The schema mirrors the outline:

| Part of the plan | In the schema |
|---|---|
| Cover page | 11 fields: program, date, version, contract, task order, document number, CDRL number, Controlled By, CUI category, LDC, POC |
| Plan approvals | 8 signature lines (PSM, PCO, PFM, lead engineer, PM, PEO, sustainment command representative, CAE), name and date each |
| Sections 1 through 12 | 54 narrative fields, numbered to the level of 4.12.3 Manufacturing Risk |
| Mandated tables | 23, from Table 3-1 Sustainment Performance Requirements through Table 10-1 IPTs and the acronym list |
| Mandated figures | 8 image fields (Figures 2-1 through 9-3), supplied by the user and placed at the tagged location |
| Record of changes, update record, update issues | 3 tables in Section 1 for the living-document cycle |

Every narrative field carries guidance drawn from the outline and DoDI 5000.91. The hint for 3.1 Performance Requirements, for example, asks for each sustainment KPP, KSA, APA, threshold and objective, source document, contract reference, test reference, and planned value at IOC and FOC. That guidance is what the AI drafts against and what the user sees when they toggle hints in the interview.

### 2. Drafting from the documents an LCSP author actually has

The schema declares the source documents and what each is authoritative for:

| Upload slot | Treated as authoritative for |
|---|---|
| Technical Volume | The technical approach, system design, and proposed sustainment strategy. Does not set contractual requirements. |
| SoW / PWS | Contractual sustainment scope, performance requirements, deliverables. Preferred over the Technical Volume where the two differ on what is required. |
| RFP (optional) | Solicitation requirements and evaluation criteria, as the Government's stated need. |
| Monthly Status Reports (optional, multiple) | Current status, metrics, open issues, risks. Most recent wins; defers to the PWS on scope. |

Attach them and the AI proposes drafts for the narrative sections and tables, each as an accept-or-reject item. Nothing enters the plan without a person accepting it. For narrative sections the AI writes complete prose; specific facts (names, dates, metrics, sites, contract clauses) must come from a source, and drafts that rest mainly on standard practice are marked with lower confidence and their unconfirmed facts listed in the reply instead of written into the plan.

Large inputs are handled client-side. A 188,000-character technical volume and a 144,000-character PWS are chunked, embedded, and stored in the browser; the passages relevant to each section are retrieved at drafting time. Supported inputs are `.pdf`, `.docx`, `.xlsx`, `.csv`, `.txt`, `.md`, `.json`, and images.

### 3. Section-by-section control

Focus buttons on the document, each section, and each field point the AI at exactly that scope. The recommended LCSP workflow is one section at a time: scope to Product Support Strategy, send, read the draft as it streams (about 60 to 120 seconds for a mid-size section), give feedback, apply, move on. A whole-document pass is available as the hands-free path.

Review-comment incorporation uses the same mechanism. Click the wand next to 4.12.2 Supply Chain Risk Management and type "Add detail on counterfeit parts prevention and reference DFARS 252.246-7008." Only that section changes.

A per-session **drafting style** note governs form without touching facts. Attach a document the customer wrote under the Style reference slot and one analysis call derives the note (narrative versus bulleted, sentence length, conventions); it is then added to every drafting and review prompt. Presets and hand-written notes are also available.

### 4. Catching disagreements between the technical volume and the PWS

With two or more documents attached, the AI reports contradictions, gaps, and assumptions to a Conflicts tab with severity, the documents involved, and a recommended action. A proposed section tied to a conflict carries a badge that jumps to the finding. Differing maintenance-level assumptions between the approach and the requirement, the staged example in the tutorial, surface here before they reach the PSM.

After drafting, **Review with AI** on the Preview page reads the rendered plan end to end and flags unfilled placeholders, sections that contradict each other, totals that do not add up, and incomplete prose. The review is conversational.

### 5. Real Word output in the official template

Output is a genuine `.docx` generated from the Government template through Docxtemplater. Markdown headings in a narrative section become real Word headings one level below the section's own heading, mapped to the template's own styles (`Heading2Manual` and so on), so they feed the Table of Contents. ToC, List of Tables, and List of Figures are native Word fields; one Ctrl+A, F9 in Word fills page numbers and links, and the download banner says so. Figures embed at their tagged location. The cover and signature page come out ready for the approval meeting.

### 6. The living-document cycle

Save Progress writes the whole session, including answers, conversation history, and style note, to a portable JSON file. The cycle the tutorial teaches: draft v1.0 from the technical volume, save, take the Word file to the PSM review, load the saved session, incorporate feedback by scoped redraft, add a record-of-changes row, save, repeat at Milestone B and every five years. A loaded file is checked against the current schema version and any affected answers are named before import.

### 7. CUI handled by default

Two endpoints are configured, Proprietary (IL2) and CUI (IL5). Every upload under IL2 is screened for CUI markings (CUI banners and category codes, FOUO, NOFORN, ITAR, distribution statements B through F, export-control notices), with an AI classification on the IL5 endpoint when the regex finds nothing. A flagged document's text goes to no AI endpoint until the user switches to CUI mode or affirms it is not CUI. Every document shows the endpoint it was saved under.

### 8. Adding the next CDRL

Users add document types themselves at `/templates`: upload a tagged `.docx` plus a schema, or upload the Word file alone and build the schema from the tags in the browser, then edit sections, fields, hints, and order in an in-app editor with a live preview. Uploads run the same integrity checks as CI, with error codes and a **Copy for your AI assistant** button backed by a shipped authoring guide. **Submit for team use** produces a bundle a developer imports with one command.

Deliverables that share facts can share one interview. On the F-16 program a single form fills a four-document Task Order set; the same mechanism would let a cover block (program, contract, CDRL number, CUI markings, POC) be entered once for every CDRL in a submission.

---

## Differentiators

### Versus drafting by hand in Word

| By hand | Doc Builder |
|---|---|
| Open last cycle's LCSP, retype the cover, hunt for what changed | Cover, approvals, and record of changes are fields; load the saved session and revise the sections that changed |
| Read the technical volume and PWS, write 54 sections | Attach both; the AI drafts each section against the outline's guidance and the sources, with facts traced to a document |
| Notice on page 60 that the maintenance concept contradicts page 20 | Conflicts tab lists disagreements between sources; Review with AI lists disagreements within the draft |
| Hand-number subheadings and rebuild the ToC | Headings map to the template's styles; ToC, LoT, LoF update with one keystroke |
| Remember what each outline paragraph expects | The expectation is the field's hint, visible to the author and used by the AI |

### Versus a general-purpose chatbot or a shared Claude project

A chatbot can write an LCSP section, but it does not know the outline, the template, or which of two attached documents to trust. Doc Builder constrains the AI to the schema: every draft lands in the right section, the PWS is declared authoritative over the technical volume for requirements, specific facts must be grounded, and the output renders into the official template without copy-and-paste. The prompt is the schema, so every author on the program gets the same guidance instead of their own saved prompts.

### Versus a document-automation or forms product

Mail merge and forms tools fill tags from a flat table. Doc Builder adds extraction from unstructured 150-page sources, retrieval over documents too large for a prompt, cross-document conflict detection, per-section AI redraft, a review pass on the finished output, heading-aware Word generation that feeds the ToC, and CUI routing. It is schema-first, so a new CDRL is a JSON file and a tagged template, not a vendor engagement.

### Versus building a hosted AI tool

Doc Builder is static files on GitLab Pages with state in the browser. Hosting cost is zero, there is no server to patch or accredit, and no connector licensing. It is designed for provider portability: tool definitions are plain JSON schema, errors are classified by HTTP status rather than SDK class, and LiteLLM is the compatibility layer, so moving to another authorized model family through the proxy is a configuration change. That matters for a .mil deployment where the authorized model service may differ.

---

## Evidence from the FMS F-16 Sustainment program

Doc Builder has been in daily production use by F-16 FMS Subcontract Administrators since mid-2026. The LCSP work rides on the same engine, prompts, Word generator, CUI handling, and template pipeline. What the F-16 program has shown:

| Result | Value | Basis |
|---|---|---|
| Document types in daily use | 19 FMS types in 6 Task Order document sets, plus a source-document consistency review and a funding request summary | Confirmed, repository |
| Volume handled | 261 PRs processed January to mid-October 2026, each a full document set | Confirmed by the team |
| Shipping Hub price reasonableness memo | ~1 hr to ~45 min, 15 to 20 min saved per document | **Timed** pilot, one user |
| Template filling across a TT&E Task Order set | ~1 to 1.5 hr by hand to AI-drafted and reviewed; ~1 hr saved | Manual figure from the August 2026 value stream map; saving is a developer estimate |
| Cross-checking PR, PWS, Source Selection, and price sheet | ~20 to 30 min by hand to AI-flagged; ~0.5 hr saved | Same basis |
| Hands-on time per Task Order | ~2.5 to 3.25 hr to 0.5 to 1.5 hr; ~1.5 hr saved | Estimate, not timed |
| SCA hours protected per year at the 2026 rate of ~30 PRs a month | ~540 | Derived |
| Time to add a document type | ~2 developer hours (tag the template, generate the schema, validate, register) | Observed on every F-16 type added in 2026 |
| Hosting | $0 | Static files, existing LiteLLM proxy |

Two points carry over directly to CDRL work. First, the F-16 documents are mostly short structured fields and were adopted for daily use; the LCSP exercises the narrative-drafting path, which is the same code with longer fields. Second, the F-16 program added five document sets in one year with no application changes, which is the extensibility a CDRL backlog needs.

---

## Measurable benefits for the LCSP, stated honestly

No LCSP has been timed end to end yet, and there is no matched case where the inputs and a finished LCSP belong to the same program. The claims below are what the repository supports today.

| Measure | Value | Basis |
|---|---|---|
| LCSP structure covered | 14 sections, 112 fields: 54 narrative, 23 tables, 8 figures, 11 cover, 16 approval | Confirmed, schema |
| Manual fill effort | Days | Tutorial outline statement, not timed |
| AI draft of one mid-size narrative section | ~60 to 120 seconds streaming, then author review | Observed in live demos |
| Whole-document AI pass | Several minutes | Observed |
| Sources per draft | Technical volume, PWS, RFP, multiple status reports, each with an authoritative-for rule | Confirmed, schema |
| Demonstrated to a program-management audience | ABADS MD team, October 2026; questions recorded in the tutorial outline | Confirmed |

**Accuracy, as the tool treats it.** No accuracy percentage is claimed. Every AI value is accepted or rejected by a person; specific facts must be grounded in a source; a response cut off by the model's output limit drops the partial value and re-asks; the consistency and final reviews report what they checked and found rather than certifying the plan. Subject-matter experts, not the development team, judge LCSP prose quality, and the project has written a five-part rubric (coverage, specificity, traceability, consistency, honest gaps) to measure it as drafting improves.

**Known limits, so expectations are set correctly:**

- A whole-document pass can stop before every section is drafted; section-by-section drafting avoids this, and a stepped fill run that keeps the model drafting until each section is covered is in progress.
- Very large sources are read through retrieval, which can leave a section generic when the best passages are not the ones retrieved. Heading-aware reading of source chapters is planned next.
- Some LCSP sections (O&S cost estimate, funding tables, integrated schedule, depot source of repair) ask for things a technical volume and PWS do not contain. Those stay thin until the program supplies the cost estimate, schedule, risk register, or prior LCSP; adding slots for them is planned.
- The AI does not draft figures; the author supplies them and finishes placement in Word.
- ToC, List of Tables, and List of Figures need the one-keystroke field update in Word after download.

---

## In one paragraph

Doc Builder turns a technical volume, a PWS, and the status reports on an author's desk into a reviewable LCSP in the Government's own template, section by section, with each fact traced to a source, disagreements between sources listed, the PWS preferred over the contractor's approach where they differ, and a Word file whose headings, ToC, figures, signature page, and CUI cover are ready for the PSM review. It runs in the browser on the existing AI proxy with nothing to host. The engine underneath has been in daily use on the FMS F-16 Sustainment program since mid-2026 across 19 document types, where it is estimated to save about 1.5 hours per Task Order and a new document type costs about two hours to add. The LCSP is the first CDRL on that engine; the next one is a tagged template and a schema.
