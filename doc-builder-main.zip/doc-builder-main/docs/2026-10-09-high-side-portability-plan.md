# High-Side Portability Plan — run Doc Builder from a hard drive on a disconnected network

**Date:** 2026-10-09
**Status:** Proposed. Nothing in this plan has started. **Re-scoped 2026-10-22:** there is no current plan for a high-side deployment. Phases 2–4, and the runtime config part of Phase 1, are now owned by the *.mil deployment* track in `docs/public/development-plan.md`, which uses this document as its design reference. The removable-media bundle, the LiteLLM carry-across kit, and Phase 5 are shelved.
**Related:** `docs/2026-10-08-code-quality-plan.md` Phase 2 (shared AI request code) is a prerequisite for Phase 4 here; several *Sustainment* items in `docs/public/development-plan.md` are pulled forward (listed under *Dependencies on existing backlog*).

## Goal

Let a team copy Doc Builder onto removable media, load it onto a network with no path to the internet or to the Leidos Model Gateway, and run it there, including the AI assistant against whatever model service that network offers (an OpenAI-compatible endpoint such as Azure OpenAI Government or a GPT model behind a gateway). Two capabilities, in order of importance:

1. **The app runs with no outside network.** A static file server on the high side serves the built app; every feature that does not need a model works exactly as it does on GitLab Pages today.
2. **The AI backend is configurable.** An administrator points the app at a different URL and a different model family (GPT rather than Claude) by editing one file, without rebuilding. Doc Builder keeps working through a LiteLLM proxy when one is available on the high side, and can also talk to an OpenAI-compatible endpoint directly when one is not.

## What already works in our favour

- **No backend and no runtime CDN.** All state is in IndexedDB; the only external origins in `src/` are the two LMG proxies and AskSage (`src/utils/urlAllowlist.ts`). The pdf.js worker is bundled (`?url` import), and the only CSS import is Tailwind. Nothing is fetched from the internet at runtime except AI calls.
- **Base path and local serving exist.** `VITE_BASE_PATH` is honoured in `vite.config.ts`, and `npm run build:local` / `serve:local` already build for `/`.
- **The internal message format is OpenAI-shaped.** `LiteLLMMessage` and `ToolCall` in `src/ai/types.ts` mirror OpenAI chat completions; `litellm.ts` translates *to* Anthropic Messages format. The reverse direction is mostly identity.
- **LiteLLM already translates for a GPT model.** CUI scanning sends Anthropic-format requests with forced `tool_choice` to `gpt-5-6-luna-mantle-aws-gov-il5` (`src/ai/cuiDetection.ts`), so an Anthropic-format app behind LiteLLM works against OpenAI models today.
- **Embeddings are provider-neutral.** `src/ai/embeddings.ts` uses plain `fetch` against `/v1/embeddings` in OpenAI format.
- **Errors are classified by status and message text**, not SDK class (`src/errors/classifiers/ai.ts`), with one exception noted in Phase 4.
- **Data moves as files.** *Save Progress…* exports sessions; custom templates travel inside them and as `.template-bundle.json`. No account or server is involved.
- **The old fetch-based OpenAI-format client is in history.** `src/ai/litellm-legacy.ts` was deleted in commit `22724dc`; it is a starting point for the OpenAI provider in Phase 4.

## What blocks a high-side deployment today

| Blocker | Where | Phase |
|---|---|---|
| `BrowserRouter` needs a server that rewrites unknown paths to `index.html`; GitLab Pages does this with `404.html`, a plain static server or IIS without URL Rewrite does not; `file://` does not work at all | `src/App.tsx` | 1 |
| Endpoints, model IDs and the fetch allowlist are hardcoded to the two LMG hosts | `src/ai/endpoints.ts`, `src/utils/urlAllowlist.ts` | 2 |
| `EndpointId` is the literal union `"cui" \| "non-cui"`; 23 comparisons in 17 files decide behaviour (CUI scanning, badges, hidden documents, settings tabs) from those two ids | `src/ai/*`, `src/hooks/useDocumentManager.ts`, `src/components/*`, `src/db/types.ts` (`uploadEndpoint`) | 2 |
| Model roles are Claude family names (`sonnet`, `opus`, `luna`) and substitution ranks by `/sonnet\|opus/` regexes; Settings and tier tooltips say "Sonnet" | `src/ai/models.ts`, `src/ai/effortTiers.ts`, `src/components/ModelSettings.tsx` | 3 |
| All chat, vision and CUI calls go through `@anthropic-ai/sdk` in Anthropic Messages format; a bare OpenAI-compatible endpoint cannot serve them | `src/ai/litellm.ts`, `src/ai/cuiDetection.ts`, `src/extraction/extractImageDescription.ts` | 4 |
| AskSage/SharePoint UI and the LMG-specific help page assume Leidos services; support contact is a hardcoded person | `src/ai/asksage.ts`, `docs/help/api-key-setup.md`, `src/errors/catalog.ts` | 1 |
| `npm ci` needs the registry and the SheetJS CDN; `.docx` templates are Git LFS objects that a plain copy of the repo may not include | `package.json`, `.gitattributes` | 5 |
| CUI detection assumes a low side and a high side exist in the same app; on an all-CUI network it only nags | `src/ai/cuiDetection.ts`, `useDocumentManager.ts` | 1, 2 |

## Design principles

- **Every phase is shippable.** Phase 1 alone gives a usable high-side deployment with manual entry and Word generation. Each later phase adds AI capability without changing what Phase 1 delivered.
- **Configure at run time, not build time.** The high side cannot rebuild. Everything an administrator must change lives in one JSON file next to `index.html`. Build-time flags exist only for things a browser cannot change after the fact (router mode, base path).
- **The deployment config is the trust anchor.** The fetch allowlist is derived from the endpoints the config declares. Whether users may add their own endpoints is a config decision, so a high-side administrator controls where document text can be sent.
- **Prefer LiteLLM, but do not require it.** CLAUDE.md names LiteLLM as the compatibility layer, and it already translates for GPT. Phase 2 makes the proxy URL configurable so a local LiteLLM is enough. Phase 4 adds a native OpenAI-format provider for networks where nobody can operate a proxy.
- **One code path per concern.** Provider differences live in `src/ai/providers/*`; the rest of the app keeps calling `streamChatCompletion` / `fetchChatCompletion` with `LiteLLMMessage[]`. No Anthropic-only parameter outside `featureFlags.ts`, as today.
- **Nothing about the Pages deployment changes by default.** The GitLab Pages build keeps `BrowserRouter`, the two LMG endpoints and the current help text. High-side behaviour is opt-in through the config file and a build profile.

## Phase overview

| Phase | What an administrator or user can do at the end | Est. |
|---|---|---|
| 1 | Unzip a release on a disconnected machine, serve `dist/` with any static server (IIS, nginx, `python3 -m http.server`, the bundled Node script), and use every non-AI feature; AskSage and CUI scanning turned off by config | 8 hr |
| 2 | Point the app at any LiteLLM-compatible URL (a local LiteLLM in front of GPT or Azure OpenAI) by editing `app-config.json`; single-endpoint deployments show no IL2/IL5 switching UI; users may add endpoints only where the config allows | 10 hr |
| 3 | Pick models by effort tier (Fast / Balanced / Thorough) rather than Claude family, so a GPT-only endpoint has sensible defaults and the Settings UI never says "Sonnet" | 4 hr |
| 4 | Talk directly to an OpenAI-compatible chat-completions endpoint with no LiteLLM in between, including tools, streaming, vision and CUI classification | 12 hr |
| 5 | Rebuild from source on the high side from a vendored npm cache; follow a written upgrade procedure that preserves users' IndexedDB data | 4 hr |

Estimates assume one developer with Claude Code, matching `development-plan.md`.

---

## Phase 1 — Offline release bundle, no AI changes

**Product at the end:** a zip that a high-side administrator unpacks under any static web server. Users create documents by hand, generate `.docx`, save and load progress, and manage custom templates. AI features show "not configured" until Phase 2.

### 1.1 Router mode and base path build profile [2 hr]

- New build-time flag `VITE_ROUTER=hash`. `src/App.tsx` renders `HashRouter` when set, `BrowserRouter` with `basename` otherwise. Hash routing needs no server rewrite rule, so the bundle works under IIS without the URL Rewrite module, under nginx with no `try_files`, and under a one-line Python server.
- The `#open-settings:<section>` deep-link protocol (`src/pages/Documentation.tsx`, `src/components/EndpointBadge.tsx`) collides with hash routing. Move it to a `?settings=<section>` search parameter handled in both router modes; keep the old hash form working in browser mode for existing links.
- `npm run build:highside` = `VITE_BASE_PATH=/ VITE_ROUTER=hash vite build`. Everything that fetches by `import.meta.env.BASE_URL` (templates, reference-docs manifest, help links) already follows the base path.
- `404.html` copy stays a Pages-only CI step; the bundle does not need it.

### 1.2 Runtime deployment config [3 hr]

New file `static/app-config.json` (Vite `publicDir` is `static`, so it lands next to `index.html`). Loaded once in `src/main.tsx` before the first render; a 404 or a parse failure falls back to built-in defaults that reproduce today's behaviour exactly, with a dismissible banner on parse failure (`config.invalid` catalog entry).

```jsonc
{
  "deploymentName": "Doc Builder (high side)",
  "supportContact": "Your admin team <admins@example.mil>",
  "features": {
    "asksage": false,          // hides SharePoint search, AskSage settings, help page
    "cuiDetection": false,     // skips regex pre-screen and AI classification on upload
    "allowUserEndpoints": false
  },
  "endpoints": []              // consumed from Phase 2; empty keeps built-ins
}
```

- `src/config/deploymentConfig.ts`: TypeScript type, validator (same style as `userTemplateValidation.ts`), defaults, `getDeploymentConfig()` accessor usable from non-React code, `useDeploymentConfig()` hook.
- `SUPPORT_CONTACT` in `src/errors/catalog.ts` becomes a function of the config so every "copy the Error Report and send it to …" message names the right people.
- `features.asksage: false` removes the SharePoint column from the document picker, the AskSage block in Settings and the help page from `docsRegistry`. This satisfies the *Remove or quarantine experimental surfaces* sustainment item for every deployment, since the Pages config can also turn it off.
- `features.cuiDetection: false` short-circuits `checkForCui()` to `"not-cui"` and hides the `🛡 CUI` affordances. On an all-CUI network the scan has nothing to protect against; the alternative, keeping the regex pre-screen as a marking aid, is open question 6.
- Diagnostics (`formatDiagnostics.ts`) include `deploymentName` and the build SHA so high-side error reports identify the build.

### 1.3 Release packaging [2 hr]

`tools/package-release.sh` builds `release/doc-builder-<version>-<sha>.zip`:

```
dist/                      # npm run build:highside output, app-config.json included
deploy/INSTALL.md          # serve it, verify it, upgrade it
deploy/web.config          # IIS: MIME types for .mjs/.wasm/.json, no rewrite needed
deploy/nginx.conf.example
deploy/serve.mjs           # zero-dependency Node static server (Node 18+), fallback when no IIS/nginx
deploy/app-config.highside.json   # commented template of every config key
VERSION                    # version, git SHA, build date
SHA256SUMS                 # one line per file; transfer processes usually require this
```

- IIS serves `.mjs` as `application/octet-stream` unless told otherwise, and the pdf.js worker is an `.mjs` file. `web.config` fixes that; `INSTALL.md` says why.
- Excluded by construction: `cases/`, `e2e/test-results/`, `.env*`, anything under `.git/`.
- CI job `release-bundle` on `main` (and on tags) attaches the zip as an artifact, so "copy to the drive" starts from a CI build, not a laptop.
- Build SHA injection via `CI_COMMIT_SHORT_SHA` → Vite `define` is the remaining half of the *In-app diagnostic report* sustainment item and is done here.

### 1.4 Documentation [1 hr]

- `deploy/INSTALL.md` (also published as `docs/highside/install.md`): hosting options with the exact commands, the stable-origin rule (IndexedDB and localStorage are per host and port, so changing either makes users' data "disappear"), browser requirements, and what "no AI configured" looks like.
- `docs/help/api-key-setup.md` gains a short "If your administrator gave you a URL" preface; the LMG phases stay for the Pages deployment.

**Acceptance test:** on a VM with networking disabled, unzip the bundle, serve it with `python3 -m http.server --directory dist` and separately with IIS using the shipped `web.config`. In each: create a `fms-to-mod` session, fill it by hand, generate `.docx`, Save Progress, reload, Load Progress, open the Documentation page from a deep link. The browser console shows no failed network request. In CI, a job serves the hash build with a static server that has **no** SPA fallback and runs the non-AI e2e specs (01, 02, 03, 04, 06, 07, 09, 10-custom-templates).

---

## Phase 2 — Configurable endpoints (any LiteLLM-compatible URL)

**Product at the end:** an administrator lists one or more endpoints in `app-config.json`; the app sends Anthropic-format requests to them exactly as it does to LMG today. A high side with a LiteLLM instance in front of GPT or Azure OpenAI has a working AI assistant with no wire-format change in the app.

### 2.1 Endpoint registry [5 hr]

- `EndpointId` becomes `string`. `EndpointConfig` gains:
  - `format: "anthropic-messages" | "openai-chat"` (Phase 2 accepts only the first; the second is reserved for Phase 4 and rejected by the validator until then).
  - `classification?: string` for display ("IL2", "IL5", "High side"), replacing the hardcoded label/shortLabel pairing.
  - `cuiScanning: { enabled: boolean; targetEndpointId?: string }` replacing every `ep === "cui"` decision about where scanning runs and which endpoint counts as the safe one.
  - `tone?: "blue" | "amber" | "green" | "gray"` for the badge colours in `EndpointSettings.tsx` and `EndpointBadge.tsx`.
  - `source: "builtin" | "config" | "user"`.
- Registry = built-ins (unless the config sets `replaceBuiltins: true`) + config endpoints + user-added endpoints from localStorage. `ENDPOINTS` stops being a constant; `getEndpoint(id)` and `listEndpoints()` replace direct indexing.
- The 23 literal `"cui"` / `"non-cui"` comparisons become property reads. `Record<EndpointId, …>` state in `SettingsDialog`, `EndpointSettings`, `AiConfigContext` becomes keyed by string. `uploadEndpoint` in `src/db/types.ts` is already a string at rest; documents whose endpoint id no longer exists get an "unknown endpoint" badge instead of being hidden.
- Documents hidden in "Proprietary mode" today because they were uploaded under CUI: with classifications, the rule becomes "hide documents uploaded under an endpoint with a *different* classification than the active one" and is skipped entirely when the deployment has one endpoint.
- Model discovery (`GET /v1/models`, `/model/info`) and the Test button work unchanged against any LiteLLM.

### 2.2 Allowlist from the registry and dev proxy [1 hr]

- `urlAllowlist.ts` reads allowed origins from the registry: built-in and config endpoints always; user-added endpoints only when `features.allowUserEndpoints` is true. The shipped Pages config lists the two LMG endpoints with `allowUserEndpoints: false`; the high-side template lists the local endpoint(s). This absorbs the *Network boundary enforcement* backlog item: the boundary is the config file.
- Dev server: the two hardcoded Vite proxies stay for LMG. Custom endpoints are called directly in dev; LiteLLM's proxy sends permissive CORS headers by default, which `INSTALL.md` tells administrators to keep. A `ai.cors` catalog entry explains the failure when a custom endpoint does not (today the browser's opaque `TypeError` becomes a generic network error).

### 2.3 Settings UI [3 hr]

- *Add endpoint* in Settings → AI Endpoints (visible only when `allowUserEndpoints` is true): label, base URL, format (Anthropic via LiteLLM until Phase 4), classification, default model id per role. Config endpoints render read-only with a "set by your administrator" note; user endpoints can be edited and removed.
- Single-endpoint deployments hide the tab strip, the "AI requests use:" line, `EndpointBadge`, `DocumentEndpointBadge`, the mode banner in the picker, and the CUI "switch endpoint" prompts. The key input, Test button and model pickers remain.
- Help: new `docs/help/custom-endpoint.md` ("Connecting to your organisation's AI endpoint"), registered in `docsRegistry`.

### 2.4 LiteLLM high-side kit [1 hr]

`docs/highside/litellm.md`: how to carry LiteLLM across. `pip download "litellm[proxy]"` on the low side for the high side's exact Python version and platform; a `litellm_config.yaml` example mapping the role model names to OpenAI or Azure OpenAI deployments; a master key and per-user virtual keys so the app's existing key flow is unchanged; running as a Windows service or systemd unit; verifying with `curl …/v1/models`, which is what the app's Test button calls. Note the wheel set is large and Python-version-specific, so the kit is rebuilt per target.

**Acceptance test:** run LiteLLM on a laptop in front of an OpenAI key, serve the Phase 1 bundle with an `app-config.json` naming only that endpoint, and complete every AI flow: chat with `propose_changes` and `search_references`, extraction from an uploaded PDF, embedding of a >10k-char document, image extraction, *Review with AI*, model discovery, and the Test button. The e2e suite passes with the mock's intercepted origin read from the config instead of the hardcoded LMG host (`e2e/fixtures/ai-mock.fixture.ts`).

---

## Phase 3 — Model roles by effort tier

**Product at the end:** Settings shows one row per tier (Fast / Balanced / Thorough) plus Extraction, Embeddings and CUI scanning. Defaults for a GPT-only endpoint are sensible without the user touching anything, and nothing in the UI or substitution logic assumes a Claude model name.

This is the *Settings by effort tier instead of model family* sustainment item, pulled forward because a GPT endpoint makes the current Sonnet/Opus rows wrong on sight. Scope as written there, plus:

- `ModelRole` becomes `"extraction" | "fast" | "balanced" | "thorough" | "embedding" | "cui-scan"`; `resolveEffortConfig()` reads tier configuration (model, effort, thinking) from the endpoint instead of mapping tiers to `sonnet`/`opus`.
- Substitution ranking in `models.ts` falls back from the family regexes to shared id tokens plus version when the configured id has no Claude family token, so `gpt-4.1` substitutes for a retired `gpt-4.1-2025-04-14` and never for an embedding model.
- `TIER_TOOLTIPS` derive from the resolved model id. `ModelSubstitutionNotice` wording loses "Sonnet".
- Migration of `doc-builder:model-overrides`: `sonnet` → `extraction` + `fast` + `balanced`, `opus` → `thorough`, `luna` → `cui-scan`.
- Endpoint config in `app-config.json` declares per-tier defaults; Phase 2's validator is extended, not replaced.

**Acceptance test:** with the Phase 2 laptop LiteLLM exposing only `gpt-*` and `text-embedding-*` models, a fresh browser profile gets working defaults for every role with no overrides, Settings never displays a Claude family name, and existing users' overrides on the Pages deployment resolve to the same model ids after migration (unit test over a fixture of today's localStorage shapes).

---

## Phase 4 — Native OpenAI chat-completions provider

**Product at the end:** an endpoint with `format: "openai-chat"` works with no LiteLLM in between. Azure OpenAI's OpenAI-compatible surface, an on-prem gateway, or a local vLLM/Ollama server can back the assistant directly.

### 4.0 Prerequisite: shared request code [included in code-quality Phase 2]

`docs/2026-10-08-code-quality-plan.md` Phase 2 creates `src/ai/http.ts` (client creation, retry, usage mapping) and removes the five scattered `new Anthropic(...)` sites. Do it first; Phase 4 is much smaller on top of it.

### 4.1 `ChatProvider` interface [3 hr]

- `src/ai/providers/types.ts`: `complete(messages, opts)`, `stream(messages, callbacks, opts)`, `countTokens(messages, opts)`, `describeImage(image, prompt, opts)`, `classifyWithTool(messages, tool, opts)`. Inputs and outputs are the existing app types (`LiteLLMMessage`, `ToolDefinition`, `StreamCallbacks`, `TokenUsage`).
- `src/ai/providers/anthropicMessages.ts`: the current bodies of `litellm.ts`, `cuiDetection.ts`'s SDK call and `extractImageDescription.ts`, moved not rewritten.
- `litellm.ts` becomes a facade that picks the provider from the active endpoint's `format`. Public function names do not change, so no caller moves.
- Feature flags gain a per-format mask: `promptCaching`, `effort`, `thinking`, `tokenCounting` are off for `openai-chat` regardless of user setting; `structuredOutputs` (forced `tool_choice`) stays on because both formats support it.

### 4.2 `openaiChat` provider [5 hr]

- Start from `git show 22724dc^:src/ai/litellm-legacy.ts` (fetch + SSE parsing); keep its structure, replace its error handling with `toAppErrorException`.
- Translation: system messages stay as `role: "system"`; assistant `tool_calls` and `role: "tool"` results pass through (the app format already is the OpenAI format); `ToolDefinition.input_schema` → `{ type: "function", function: { name, description, parameters } }`; `toolChoice: { type: "tool", name }` → `{ type: "function", function: { name } }`; `max_tokens` → `max_completion_tokens` with `max_tokens` fallback on 400; `stream_options: { include_usage: true }` for `TokenUsage`; `finish_reason` → `StopReason` (`stop` → `end_turn`, `length` → `max_tokens`, `tool_calls` → `tool_use`).
- Streaming: accumulate parallel `tool_calls` deltas by `index`, then dispatch via `onToolCalls` exactly as the Anthropic path does; `onThinking` never fires.
- Vision: image content part `{ type: "image_url", image_url: { url: dataUrl } }` for `describeImage`.
- CUI classification: same `classify_cui` tool, forced via `tool_choice`.
- Prompt caching and thinking are simply absent; `countTokens` returns the estimate path that already exists.

### 4.3 Errors [1 hr]

- Replace `err instanceof Anthropic.BadRequestError` in the streaming catch (the one SDK-class check in the app) with a status check from `toAppError`, so feature auto-disable works for both providers.
- Add OpenAI error-body shapes to `classifiers/ai.ts` with fixture rows in `classifiers.contract.test.ts`: `context_length_exceeded` → `ai.prompt-too-large`, `model_not_found` → `ai.model-unavailable`, `insufficient_quota` and `rate_limit_exceeded` → `ai.rate-limit`, `invalid_api_key` → `ai.auth`.

### 4.4 Tests [3 hr]

- Unit: translation both ways with golden fixtures; multi-tool-call accumulation; usage mapping; finish-reason mapping.
- E2E: `ai-mock.fixture.ts` gains a `/v1/chat/completions` handler emitting `chat.completion.chunk` events (its header comment already anticipates this). Specs 05 and 08 run under both formats via a fixture parameter.
- Manual: Ollama or vLLM locally, and Azure OpenAI's `/openai/v1` surface if a Government subscription is reachable from the low side.

**Acceptance test:** every AI e2e spec passes against both mock formats; against a real OpenAI-compatible server, extraction with tools, freetext drafting, `ask_user`, `report_observations` and *Review with AI* complete; the activity log shows usage numbers; disabling the endpoint's network shows the same friendly errors as today.

---

## Phase 5 — Offline build kit and upgrade path

**Product at the end:** a high-side developer can rebuild `dist/` from source without a registry, and an administrator can upgrade an installation without losing users' data.

- **Vendored install** [3 hr] — `tools/build-offline-kit.sh` produces `doc-builder-src-<sha>.zip`: a `git bundle` of the repo with LFS objects fetched (`git lfs fetch --all` first; a plain clone copied to a drive carries LFS *pointers*, and the templates would be 130-byte text files), an `npm-cache/` directory populated from the lockfile so `npm ci --offline --cache ./npm-cache` succeeds, the SheetJS tarball vendored under `vendor/` (the *Freeze the supply chain* sustainment item), exact-pinned runtime versions, and `BUILD-OFFLINE.md`. Playwright and its browser image are excluded; e2e runs low side. A CI job verifies the kit in a `--network none` container.
- **Upgrade procedure** [1 hr] — in `INSTALL.md`: keep host and port identical (per-origin storage), ask users to run *Export all data* first (the *Whole-database backup/restore* item; until it ships, *Save Progress…* per session), replace `dist/`, hard-refresh; `preloadErrorReload.ts` already recovers from stale chunk 404s; `VERSION` and the footer SHA confirm the new build. Dexie migrations run on first open as they do on Pages.

**Acceptance test:** on a network-disabled VM with only Node 22 installed, unzip the kit, `npm ci --offline`, `npm run build:highside`, and compare the output to the low-side CI artifact: identical file set, identical content modulo content hashes in filenames.

---

## Sequencing and alternatives considered

- **Why Phase 1 is independent of AI.** Manual entry plus Word generation is the core value; a high side with no model service still gets a working tool, and the bundle format is what every later phase ships in.
- **Why Phase 2 before Phase 4.** LiteLLM already translates Anthropic-format requests for a GPT model in production (CUI scanning). If the high side can run a LiteLLM instance, the app needs no new wire format and Phase 2 finishes the job. Phase 4 exists for networks where nobody can install or operate a Python service; open question 1 decides whether it is needed at all.
- **Why Phase 3 sits between them.** Phase 2 works with GPT behind LiteLLM, but a user has to override the "Sonnet" role with a GPT id by hand. Phase 3 makes a GPT-only deployment look intentional and is cheap; it is also an existing sustainment item.
- **Hash routing rather than requiring SPA fallback.** IIS URL Rewrite is a separate download that high-side servers often lack; nginx and Apache configs vary by site; `python3 -m http.server` has no fallback at all. Hash routing works under all of them. Browser routing stays the default for Pages, where deep links to `/doc-builder/docs/...` are already shared.
- **Runtime config rather than build-time env.** The high side cannot rebuild, and one JSON file is what an administrator can be asked to edit. Build-time flags are kept only for router mode and base path.
- **Alternative rejected: `file://` double-click.** ES modules, `fetch` of templates and the manifest, the pdf.js worker and IndexedDB all misbehave or are blocked on `file://`. A static server is a hard requirement and `INSTALL.md` says so on line one.
- **Alternative rejected: desktop wrapper (Electron / Tauri).** Solves serving and routing, but adds a second build toolchain, code signing, and an installer that needs admin rights on the high side. The browser is already there.
- **Alternative rejected: OpenAI-direct only (drop the Anthropic SDK).** It would remove prompt caching, thinking and effort for the Pages deployment, where Claude through LMG is the daily workload. Two providers behind one interface keep both.

## Cross-cutting work

- **Deployment profiles.** `deploy/configs/pages.json` and `deploy/configs/highside.json` are the two shipped `app-config.json` variants; the Pages build copies the first, `build:highside` copies the second. A test asserts both validate.
- **Error handling.** New catalog entries: `config.invalid`, `ai.cors`, `ai.endpoint-unknown`. Each with a classifier case and a contract-test row per the project rule.
- **Diagnostics.** Error reports and the chat troubleshooting export include `deploymentName`, build SHA and the active endpoint's `format`, since high-side reports arrive as screenshots or retyped text and cannot be reproduced low side.
- **Security review.** The config-derived allowlist and user-added endpoints are the one place this plan widens where document text may be sent. Run `/security-review` on the Phase 2 MR and document the trust rule in `RUNBOOK.md`.
- **Docs.** `README.md` gains a *High-side deployment* section pointing at `docs/highside/`; `RUNBOOK.md` gains "high-side user reports a problem" (ask for the Error Report; it now names the build).
- **CI.** `release-bundle`, the no-fallback static-server e2e job (Phase 1), the both-formats e2e matrix (Phase 4), and the `--network none` offline-build check (Phase 5).

## Dependencies on existing backlog

| Existing item (`development-plan.md`) | Relationship |
|---|---|
| Remove or quarantine experimental surfaces (AskSage) | Done by Phase 1's `features.asksage` flag |
| In-app diagnostic report — build SHA injection | Done in Phase 1.3 |
| Network boundary enforcement | Absorbed into Phase 2.2 |
| Settings by effort tier instead of model family | Is Phase 3 |
| Provider-portability guardrails — `ChatProvider` interface | Is Phase 4.1 |
| Code-quality plan Phase 2 (`src/ai/http.ts`) | Prerequisite for Phase 4 |
| Freeze the supply chain | Done in Phase 5 |
| Whole-database backup/restore | Wanted by the Phase 5 upgrade procedure; not blocking |
| Structured outputs to replace `jsonMode` | Unaffected; forced `tool_choice` remains the portable path and both providers support it |

## Risks

- **Transfer tooling.** Some cross-domain transfer agents block or quarantine `.js`/`.mjs`/`.wasm` files or nested zips. If so, the bundle may need a different archive format or a rename-and-restore step; find out before Phase 1.3 is final (open question 4).
- **Browser policy.** Locked-down browsers may disable IndexedDB or localStorage; the app already shows `StorageUnavailable`, but nothing works without storage. Confirm the high-side browser and policy (open question 5).
- **LiteLLM kit size and drift.** The `litellm[proxy]` wheel set is hundreds of megabytes and Python-version-specific. Each target needs its own kit; pin the LiteLLM version in `docs/highside/litellm.md` and test the exact version low side first.
- **Azure OpenAI native API.** Azure's classic API uses `api-key` headers, `?api-version=` and deployment-name URLs, which Phase 4 does not implement. Azure's OpenAI-compatible `/openai/v1` surface is what Phase 4 targets; if the high side only offers the classic API, LiteLLM (Phase 2) is the path.
- **Model quality.** Extraction and drafting prompts were tuned against Claude. GPT models through either path may need prompt adjustments; the LLM-gated tests (`RUN_LLM_TESTS=true`) are the way to find out, run low side against the same model family.

## Open questions

1. **What is actually available on the high side?** An OpenAI-compatible HTTP endpoint (which one: Azure OpenAI Government, an on-prem gateway, something else), and can a LiteLLM service be installed and kept running there? This decides whether Phase 4 is needed.
2. **Hosting.** IIS, nginx, or a user's own workstation with Python or Node? Determines which `deploy/` files matter and whether `serve.mjs` is worth shipping.
3. **Rebuild on the high side, or built artifact only?** Phase 5 is skippable if nobody will touch source there.
4. **Transfer process requirements.** Checksum format, approved media, file-type restrictions, maximum archive size.
5. **Browser and policy.** Which browser and version, and whether IndexedDB, localStorage, and the File System Access API are permitted.
6. **CUI detection on an all-CUI network.** Fully off (the Phase 1 default), or keep the regex pre-screen as a marking reminder without the IL2/IL5 switching behaviour?
7. **Who owns the high-side configuration?** The `app-config.json` trust rule assumes an administrator edits it and users do not. If users serve the app from their own machines, `allowUserEndpoints` must be true and the allowlist protects less.
