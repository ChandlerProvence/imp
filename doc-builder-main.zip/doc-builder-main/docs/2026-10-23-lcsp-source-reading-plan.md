# Let the model read the sources — LCSP drafting quality, Phase 1

**Date:** 2026-10-23
**Status:** Proposed. Nothing started.
**Parent:** Phase 1 of `docs/2026-10-20-lcsp-drafting-quality-plan.md`. This document is the implementation plan for that phase and supersedes its Phase 1 section where they differ (differences are listed at the end).
**Absorbs:** *Raise RAG threshold* in `docs/public/development-plan.md` (Refactors).

## Goal

A drafting step can read the relevant chapter of a large source document end to end, instead of seeing ten 800-character fragments per search. Nothing here depends on the stepped fill run (`docs/2026-10-13-fill-run-steps-plan.md`).

## Guidelines

Revised 2026-10-23 at the user's direction. Neither of these is a hard constraint.

- **Quality first, without waste.** The company enforces no token limits. Spend tokens where they improve drafts, and avoid spending that buys nothing, such as re-sending text the model has finished with.
- **Portability is a future goal.** Anthropic-only parameters are acceptable behind `src/ai/featureFlags.ts`, as long as the app still works with the flag off. Prompt caching is the one this plan uses.
- **Context-window headroom is the real limit.** Today's fill run already reached ~99k tokens per call (2026-10-13 troubleshoot export). `buildApiMessages` in `src/hooks/useAiChat.ts` re-sends the whole history on every round, so a long run can approach the window regardless of cost.

All three WFR inputs total ~400k chars, about 120k tokens. Putting all of them in context, as Claude on the web does for content under its window, would leave too little room for the LCSP field listing and a long fill run. The plan includes documents whole up to a budget, caches them, and reads the rest by section.

## What the code does today

| Piece | Where | Behavior |
|---|---|---|
| Direct-inclusion threshold | `SMALL_DOC_THRESHOLD` in `src/ai/embeddings.ts` | 10,000 chars. Larger docs are embedded and get a 2,000-char preview in the prompt. |
| Chunking | `chunkText` in `src/ai/embeddings.ts` | 800 chars, 200 overlap, split on blank lines. No heading awareness; tables are flattened. |
| Retrieval | `retrieveRelevantChunks`, `handleSearchReferences` in `src/hooks/useDocumentManager.ts` | Top 10 by cosine similarity across every embedded doc. Results labeled by role and filename only. |
| Prompt assembly | `buildCombinedDocumentText` in `useDocumentManager.ts`; `buildBulkEditChatUserMessage` in `src/ai/bulkEdit.ts` | Small docs whole, large docs as a 2,000-char preview with `truncated="true"`. Whole string sliced at 100,000 chars, silently, mid-document if necessary. |
| .docx text | `htmlToText` in `src/extraction/parseFile.ts` | Mammoth HTML to plain text. Headings become bare lines, so levels are lost. Table cells run together. |
| PDF text | `parsePdf` in `src/extraction/parseFile.ts` | Text items joined with spaces; one blank line between pages. Line breaks inside a page are lost, so headings merge into body text. |
| Tool dispatch | `useAiChat.ts` if/else chain; tool list `AI_TOOLS` in `src/ai/toolDefinitions.ts` | Six tools. `search_references` takes only `query`. |

Measured on the WFR example inputs in `trash/lcsp_example_inputs/`:

| Document | Text size | Structure recoverable? |
|---|---|---|
| Tech volume (.docx) | ~188k chars | Yes. Mammoth emits 44 `<h1>`–`<h5>` headings, all numbered (`1.2.1 Contractor Program Management`). Median section ~2.5k chars, largest ~19k. 45 tables. |
| PWS (.pdf) | ~144k chars, 50 pages | Yes, if line breaks are kept. With pdf.js `hasEOL` line joins, a numbered-heading pattern finds 83 candidates in the first 40 pages (`1.3.2.1 GOVERNMENT FURNISHED INFORMATION (GFI)`), with a few false positives from numbered list items. |
| RFP (.pdf) | ~70k chars | Not measured; same path as the PWS. |

Consequence for the threshold: a 60k threshold includes the RFP whole but not the tech volume or PWS. For the LCSP case most of the gain has to come from structure, an outline, and reading on demand.

## Design decisions

1. **Structure comes from the stored text, not a new table.** A pure `buildSourceOutline(text)` derives the heading tree from `UploadedDocument.textContent` at runtime (memoized by doc id + text length/hash). Reading a section slices `textContent` by the outline's character offsets. No second copy of the text, no Dexie version bump, and it works for small docs, large docs, and `generated:*` docs alike.
2. **Headings are marked at extraction time; numbering is the fallback.** New .docx uploads keep mammoth's heading levels as markdown `#` markers in `textContent`. Older records and PDFs fall back to a numbered-heading heuristic. Documents with neither get positional parts (`Part 1 of 9`, ~12k chars each) so the reading tool still works.
3. **The outline goes in the prompt, not behind a tool.** The large-doc `<document truncated="true">` element carries the document's outline instead of a 2,000-char preview. The model sees what it can read without having to remember to ask. This replaces the parent plan's `list_reference_outline` tool.
4. **Retrieval chunks follow headings.** Chunks never cross a heading, carry their heading breadcrumb, and are embedded with the breadcrumb prefixed. The breadcrumb is how a search hit turns into a `read_reference_section` call.
5. **Inclusion is budgeted, not sliced, and cached.** Whole-document inclusion fills a character budget, smallest docs first. Docs that do not fit go to retrieval with an outline, and the user message is never cut mid-document. The document block gets a prompt-cache breakpoint, so re-sending it on each round is cheap when caching is on.
6. **Old reads are trimmed only under context pressure.** When the estimated context passes a threshold, `buildApiMessages` replaces older section reads with one-line stubs. Below the threshold everything is sent in full, so the model keeps what it read. The stored conversation always keeps the full text.
7. **Retrieval improves without extra model calls first.** Keyword search runs alongside embeddings in the browser, and hits already seen in the conversation are not returned again. Model-written chunk context and model reranking are deferred until Phase 0 shows retrieval misses these don't fix.

All new tools are raw JSON schema in `toolDefinitions.ts`, work under forced `tool_choice`, and pass through LiteLLM unchanged. The only new Anthropic-specific piece is the cache breakpoint in step 2a, behind the existing `promptCaching` flag.

## Steps

### 1. Keep structure in extracted text — `src/extraction/parseFile.ts`

- `htmlToText`: emit headings as `#`×level + text on their own line (`## 1.2.1 Contractor Program Management`). This is the same idea as `htmlToTemplateText` in `src/ai/templateTextService.ts`, which uses `[H1]` markers; use markdown here because the text is also shown to the model as document content.
- `htmlToText`: render tables row by row as `| cell | cell |` lines, with list items inside a cell joined by `; `. Today cells run together and rows are indistinguishable.
- `parsePdf`: join text items with a newline where `item.hasEOL` is true, otherwise a space. Keep the blank line between pages and add a `[Page N]` marker line at each page start so read results can cite pages.
- No migration. `contentHash` is computed from the file bytes, so a re-upload of the same file replaces the record's `textContent` through `saveUploadedDocument` and picks up the new format. Old records keep working through the step 3 fallbacks.

Check before merging: CUI regex scanning and the style-analysis input (`stripMachineBlocks` in `src/ai/draftingStyle.ts`) are unaffected by `#` and `|` characters. Re-run their tests.

### 2. Budgeted direct inclusion — `useDocumentManager.ts`, `embeddings.ts`, `bulkEdit.ts`

- `SMALL_DOC_THRESHOLD` 10,000 → 60,000 (~18k tokens). A PWS or RFP of ordinary length is included whole.
- New `DIRECT_INCLUSION_BUDGET = 150_000` chars (~45k tokens) in `embeddings.ts`. `buildCombinedDocumentText` includes eligible docs whole, smallest first, until the budget is spent; the rest are emitted as outline elements (step 5) and must be embedded.
- Every place that branches on `SMALL_DOC_THRESHOLD` (attach, release-quarantine, endpoint-switch re-embed, generated docs; about six call sites) asks one helper instead, `needsRetrieval(docId)`, that reflects the budget decision. Otherwise a doc that falls out of the budget is neither inline nor embedded.
- `buildBulkEditChatUserMessage`: replace the `slice(0, 100_000)` with a check that the combined text fits budget plus outlines; if it does not, drop whole documents to outline form rather than cutting.

The budget is sized for context-window room, not cost. 150k chars leaves ~150k tokens of a 200k window for the system prompt, the LCSP field listing, reads, and the conversation. Make it a named constant so it can be tuned after the Phase 0 comparison.

### 2a. Cache the source block — `src/ai/litellm.ts`, `src/ai/bulkEdit.ts`

Today `translateMessages` puts a cache breakpoint on the system prompt only. The documents travel in the first user message, so they are billed in full on every round.

- Split `buildBulkEditChatUserMessage` output into a stable source block (role guidance, inline documents, outlines) and the instruction that follows it.
- When `promptCaching` is on, send the first user message as two text blocks and put a second `cache_control` breakpoint on the source block. Anthropic allows up to four breakpoints, and this uses two.
- With the flag off, the message is the same text as one string. Behavior is identical; only cost differs.
- Rounds after the first read the system prompt and source block from cache. Pinning the program brief in drafting-quality Phase 2 benefits the same way.

### 3. Outline builder — new `src/ai/sourceOutline.ts`

```ts
export interface OutlineEntry {
  id: string;          // stable within a text version: "h12"
  level: number;       // 1–6
  title: string;       // "1.2.1 Contractor Program Management"
  number?: string;     // "1.2.1" when the title starts with one
  start: number;       // char offset of the heading line
  end: number;         // offset where the next heading at same or higher level starts
  path: string[];      // ancestor titles, for breadcrumbs
}
export function buildSourceOutline(text: string): OutlineEntry[];
export function formatOutline(entries: OutlineEntry[], maxChars?: number): string;
export function findSection(entries: OutlineEntry[], query: string): OutlineEntry | undefined;
```

Detection order: markdown `#` lines; otherwise numbered lines matching `^\d+(\.\d+){0,5}\.?\s+\S` that are short (< 120 chars), not ending in sentence punctuation, and whose numbers are monotonic with their neighbors (this removes most numbered list items, such as the PWS's `8. Facility/facilities and work areas…`); otherwise positional parts. Front matter before the first heading becomes an entry titled `(front matter)`.

`findSection` matches by exact number (`"1.3.2"`), then exact title, then case-insensitive prefix, then contains. Ambiguous matches return the first and the read result lists the others.

`formatOutline` renders one line per entry, indented by level, with size: `1.3.2 Government Furnished Property (GFP)… [4.1k]`. Capped at ~4k chars per document (~1.2k tokens) by dropping the deepest levels first. Bracketed compliance references in titles (`[A.Vol I.1; B.Vol I.2.a; PWS 1.3]`) are stripped from the outline but kept in the text.

### 4. Heading-aware chunking — `src/ai/embeddings.ts`

- `chunkText` takes the outline: chunk within each section's `[start, end)` only, never across a heading. Target 1,500 chars, 200 overlap within a section. Table rows (`|` lines from step 1) are not split mid-row.
- Each chunk gains `headingPath: string` (`"1.2 Technical Solution › 1.2.1 Contractor Program Management"`). The embedded text is `headingPath + "\n" + text`, so the vector reflects where the passage sits.
- `EmbeddingChunkRecord` gains optional `headingPath?: string` and `chunker?: number`. Neither is indexed, so `src/db/dexie.ts` needs no new version.
- Cache check in `embedAndStoreDocument` becomes sourceHash + model + `chunker === CHUNKER_VERSION` (2). Stale caches re-embed on next attach. `embeddingChunks` is already excluded from backups.

### 5. Outline in the prompt — `buildCombinedDocumentText`

For a document that needs retrieval, emit:

```
<document role="pws" title="SoW / PWS" filename="WFR PWS Dec 2023.pdf" mode="outline" full-length="144210">
This document is too long to include. Its outline is below. Read a section with read_reference_section, or find passages with search_references.
1.0 SCOPE [1.2k]
  1.1 GENERAL [0.8k]
  ...
</document>
```

`truncated="true"` and the 2,000-char preview go away.

### 6. `read_reference_section` tool

Definition in `toolDefinitions.ts`, added to `AI_TOOLS`:

```
read_reference_section({
  document: string,      // filename or role id, as shown on the <document> element
  section?: string,      // heading number or title from the outline
  cursor?: integer,      // continue a previous read
  max_chars?: integer    // default 8000, max 16000
})
```

Handler `handleReadReferenceSection` in `useDocumentManager.ts`, next to `handleSearchReferences`:

- Resolves `document` against the committed selection only. Style references and docs withheld for CUI-outside-CUI are refused with the same rule `handleSearchReferences` uses (`isStyleRef`, endpoint check).
- Returns the section text (including its subsections) from `textContent`, prefixed with the breadcrumb and, for PDFs, the page range. When the section exceeds `max_chars`, it cuts at a paragraph or table-row boundary and returns `next_cursor` plus the titles of the subsections not yet read.
- Unknown section: returns the outline and the closest three matches, not an error, so the model can retry in the same turn.
- Works for docs included whole too, so citations and re-reads use the same path.

Wiring: `onReadReferenceSection` option on `useAiChat` (`src/hooks/useAiChat.ts`), passed from `src/context/AiPanelContext.tsx`; a dispatch branch shaped like the `get_template_context` one (async, pushed to `searchPromises`, one result per call id); an activity step labeled `Read: <document> § <section>`.

### 7. Better `search_references` results

- **Hybrid ranking.** Add a client-side BM25 keyword index over the same chunks (new `src/ai/keywordIndex.ts`, built in memory from chunk text when chunks load; no library, no storage). Merge the BM25 and cosine rankings with reciprocal rank fusion. This catches acronyms, CDRL numbers, and paragraph references (`PWS 3.1.1`, `GFE`) that embeddings rank poorly. Anthropic's contextual-retrieval study reports most of its gain from embeddings plus BM25 together; the part left out here, model-written chunk context and model reranking, costs model calls.
- **Options.** Optional `top_k` (default 10, max 25) and an optional `document` filter.
- **No repeats.** `handleSearchReferences` takes the set of chunk ids and section ids already returned in this conversation and skips them, so a second search returns new material rather than the same passages.
- **Labels.** Each hit carries the breadcrumb: `[3] (SoW / PWS — WFR PWS Dec 2023.pdf › 3.2 Fielding Support):`. The tool description tells the model to read that section when a hit is useful.

### 7a. Trim old reads under context pressure — `src/hooks/useAiChat.ts`

In `buildApiMessages`, when the estimated context (`estimateConversationTokens` in `src/ai/tokenEstimate.ts`) passes 60% of the model's context window, replace older `read_reference_section` and `search_references` results with a stub, oldest first, until it is back under:

```
[Read earlier: WFR PWS Dec 2023.pdf § 3.2 Fielding Support, 5.8k chars. Call read_reference_section again if you need it.]
```

- **Never trimmed:** results from the latest two rounds.
- **Only API messages change.** The stored `AiChatMessage` keeps the full text, so the chat display, chat history, and troubleshoot export are unaffected.
- **Why a threshold and not always.** Trimming early saves tokens but makes the model re-read what it already had. Under the threshold, quality wins. Over it, the alternative is running out of window.
- **Cache-safe.** Trimmed results sit after the cached system prompt and source block, so trimming never invalidates the cache.
- Fill-run plan Phase C, isolated step contexts, would make this mostly unnecessary. Build 7a only if Phase C is not scheduled.

### 8. Prompt — `src/ai/bulkEdit.ts`, `src/ai/documentReviewPrompt.ts`

New `## Reading Sources` block in `buildBulkEditChatSystemPrompt`, after `## Rules`. It is stable text, so it stays in the cached system-prompt prefix:

- Documents with `mode="outline"` are not in the message. Their outline shows what you can read.
- Before drafting a freetext field, read the source sections whose headings match the field's subject with `read_reference_section`. Use `search_references` to find sections the outline does not make obvious.
- Prefer reading a whole section over assembling search fragments. Cite the document and section number in observations.
- Start with the deepest matching section, then widen to the parent chapter if it lacks what the field needs.
- In long conversations, older reads may appear as a one-line stub. Re-read only if you need the text again.

`documentReviewPrompt.ts` lists the tools by name; add the new one there. `FREETEXT_DRAFTING_RULE` is unchanged.

### 9. Guard rails

- **Per-call cap.** 16k chars bounds each read. A runaway loop of reads is the waste case to prevent; the cap plus the activity log make one visible.
- **No new error kinds.** Read failures return a tool-result error message, like `get_template_context`.

### Rough token picture for an LCSP fill run

Assumptions: WFR inputs, 12 rounds, about 3 reads and 1 search per round. Characters are converted at 3.3 per token.

| Component per call | Today | After |
|---|---|---|
| Source block | ~100k chars, uncached | RFP (~70k) inline + 2 outlines ≈ 78k chars, cached after round 1 |
| Tool results | ~8k chars of search hits per round, all re-sent | ~3 reads × 8k + hits per round, all re-sent until the trim threshold |

Context per call grows faster than today because reads are larger than search hits. Cost per call falls when caching is on, because the source block is read from cache. Phase 0 and the comparison run measure both; nothing here is a gate.

## Tests

| Area | File | Cases |
|---|---|---|
| Extraction | `src/extraction/parseFile.test.ts` | Headings emitted with `#` by level; table rows as `|` lines; PDF lines split on `hasEOL`, `[Page N]` markers. |
| Outline | new `src/ai/sourceOutline.test.ts` | Markdown headings; numbered headings with numbered-list false positives rejected; positional fallback; `end` offsets nest; `findSection` by number, title, prefix, ambiguity; `formatOutline` cap drops deepest level first. Fixture: a short heading-rich .docx and a text PDF dump. |
| Chunking | `src/ai/embeddings.test.ts` | No chunk crosses a heading; breadcrumb present and prefixed in embedded text; table rows intact; `chunker` version mismatch forces re-embed. |
| Inclusion | `useDocumentManager` tests | Budget fills smallest first; overflow doc gets `mode="outline"` and is embedded; nothing is cut mid-document; style references stay out. |
| Read tool | `useDocumentManager` tests | Section read, cursor continuation, unknown section returns outline + suggestions, unselected and style-reference docs refused, CUI-withheld doc refused. |
| Dispatch | `src/hooks/useAiChat.test.ts` | One `read_reference_section` call yields exactly one tool result with its call id; works alongside a parallel `search_references`. |
| Trimming | `src/hooks/useAiChat.test.ts` | Below the threshold nothing is stubbed; above it the oldest reads are stubbed first; the latest two rounds are never stubbed; stored messages keep full text; tool-call/result pairing stays valid. |
| Caching | `src/ai/litellm` tests | With `promptCaching` on, the first user message carries a breakpoint on the source block; with it off, the request text is identical and has no `cache_control`. |
| Keyword search | new `src/ai/keywordIndex.test.ts` | Exact acronym and paragraph-number queries rank the right chunk first; fusion keeps a strong semantic hit; already-seen chunks are skipped. |
| Prompt | `src/ai/bulkEdit.validation.test.ts` | `## Reading Sources` present; no `slice(0, 100_000)` truncation path; review prompt names the tool. |
| Regression | existing NDA / TT&E prompt tests | Small single-doc sessions produce the same user message apart from markdown heading markers. |

Then `npm test` and `npm run build`.

## Verification against the baseline

Phase 0 of the parent plan (baseline run plus `lcsp-judge`) should be recorded before this merges; otherwise there is nothing to compare against. After merge, rerun the WFR case on the Thorough tier and compare:

- Judge *Traceability* and *Specificity* on the "source exists" fields should rise.
- `read_reference_section` calls should appear in the sustainment-strategy sections; `search_references` calls per section may fall.
- Context tokens per call, total input tokens, and cache share, from `tools/chat-run-metrics.ts`. Report them. Flag the change if total input tokens more than double with no judge gain; that is the "wasteful" case.
- Both runs use the app's default settings, with thinking, effort, and prompt caching on, so the comparison reflects what users get.
- Fallback check: one run with `promptCaching` off confirms the app still works without it.

## Estimate

| Step | Hours |
|---|---|
| 1 Extraction structure | 1.0 |
| 2 Budgeted inclusion | 1.5 |
| 2a Cache the source block | 1.0 |
| 3 Outline builder | 1.5 |
| 4 Chunking | 1.0 |
| 5 Outline in prompt | 0.5 |
| 6 Read tool + wiring | 2.0 |
| 7 Search: keyword index, fusion, no repeats | 1.5 |
| 7a History trimming | 1.5 |
| 8 Prompt | 0.5 |
| Tests beyond the above, manual WFR run | 1.5 |
| **Total** | **~13.5** |

The parent plan estimated 8 hr. The extra covers extraction (step 1), the budget helper and caching (steps 2 and 2a), hybrid search (step 7), and trimming (step 7a). Skipping 7a when fill-run Phase C is scheduled brings it to ~12.

## Differences from the parent plan

- **No `list_reference_outline` tool.** The outline is in the `<document>` element instead, so the model cannot skip it.
- **No Dexie schema change.** Structure is derived from `textContent`; chunk records gain unindexed optional fields only.
- **Budget of 150k chars, not 400k.** 400k chars is ~120k tokens, which leaves too little of a 200k window for the field listing and a long fill run. Caching makes 150k affordable.
- **Chunks ~1,500 chars, not ~4k.** Smaller chunks keep embeddings specific; the read tool supplies the surrounding context that larger chunks were meant to give.
- **Extraction changes added.** Without them, PDF headings are not recoverable and .docx heading levels are lost.
- **Caching and headroom added.** The source block is cached, and old reads are trimmed only when the context window gets tight.

## Considered and left out

- **Whole-corpus in context, as Claude on the web does under its window.** Caching would make the cost acceptable, but ~120k tokens of sources leaves too little window for a long LCSP fill run. Revisit once fill-run Phase C isolates step contexts, since each step's context would then be small.
- **Model-written context per chunk (contextual embeddings).** Roughly 270 extra model calls to index the WFR inputs, repeated on every re-embed. The heading breadcrumb gives most of the same signal for free. Revisit if Phase 0 shows retrieval misses that breadcrumbs don't fix.
- **Model reranking.** An extra call per search. Keyword fusion and heading labels come first.

## Documentation

Final step: ask the user whether to update `changelog.d/` (new fragment), `README.md` (AI panel: sources are read by section; larger documents included whole), `docs/public/development-plan.md` (tick *LCSP drafting quality* Phase 1 and *Raise RAG threshold*), and the *Client-side RAG* paragraph in `CLAUDE.md`, whose constants this changes. Do not run `/update-docs` automatically.
