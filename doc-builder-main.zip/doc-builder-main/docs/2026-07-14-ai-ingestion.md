# Phase 4 — AI Ingestion (Extraction)

## Context

Phases 0–3 are complete: the app scaffolds, loads schemas, runs an interactive interview wizard, and generates formatted documents. Phase 4 adds the core AI value proposition: users upload an existing document (PDF/docx/txt) and the app extracts field values via LiteLLM, pre-filling the interview instead of requiring manual entry.

The plan doc specifies a simple single-pass MVP: upload → extract text client-side → send text + schema to LLM → parse structured JSON → pre-fill session answers.

---

## Implementation Plan

### 1. Install dependencies

Add to `package.json`:
- `mammoth` — .docx → raw text extraction (client-side)
- `pdfjs-dist` — PDF → raw text extraction (client-side, Mozilla's pdf.js)

### 2. Create `/src/extraction/` module

**`src/extraction/types.ts`** — Types for extraction results:
```ts
interface ExtractionResult {
  answers: Record<string, string | number | boolean>;  // same shape as session answers
  confidence: Record<string, number>;                  // 0–1 per field key
  model: string;
  extractedAt: Date;
}
```

**`src/extraction/parseFile.ts`** — Client-side text extraction:
- `parseFile(file: File): Promise<string>` — routes by MIME type:
  - `.pdf` → pdfjs-dist `getDocument()` → iterate pages → `getTextContent()`
  - `.docx` → mammoth `extractRawText()`
  - `.txt` / fallback → `file.text()`

**`src/extraction/extract.ts`** — LiteLLM API call:
- `extractFields(text: string, schema: DocumentSchema, apiKey: string, model?: string): Promise<ExtractionResult>`
- Builds a system prompt listing all sections/fields with types and descriptions
- Instructs the model to return JSON: `{ "section_id.field_id": { "value": ..., "confidence": 0.0-1.0 } }`
- Uses `response_format: { type: "json_object" }` for structured output
- Parses response, validates field keys against schema, coerces types
- Default model: `claude-4-6-sonnet-aws-comm-il2`

**`src/extraction/index.ts`** — Public exports.

### 3. API key management (localStorage)

**`src/extraction/apiKey.ts`** — Simple helpers:
- `getApiKey(): string | null` — reads from `localStorage.getItem("doc-builder-api-key")`
- `setApiKey(key: string): void`
- `clearApiKey(): void`

### 4. Settings page

**`src/pages/Settings.tsx`** — New route `/settings`:
- Text input to paste LiteLLM API key (masked with show/hide toggle)
- Model selector dropdown (sonnet for extraction, opus for drafting)
- Clear key button
- Privacy note: "Your API key is stored in your browser and sent only to lmg.leadai.leidos.com"
- Save confirmation toast

Add route to `src/App.tsx`: `<Route path="/settings" element={<Settings />} />`

### 5. Upload UI on Home page

Modify `src/pages/Home.tsx` — after clicking a document type, instead of immediately navigating to interview, show two options:
- "Start Blank" → current behavior (navigate to `/interview/:docTypeId`)
- "Upload Existing Document" → opens file picker, triggers extraction flow

Implementation approach: Add an `UploadModal` component that:
1. Accepts file (drag-and-drop + click-to-browse)
2. Shows extraction progress (parsing → calling AI → done)
3. On success, creates a session with pre-filled answers, then navigates to `/interview/:docTypeId`

### 6. Extend Session model

Add optional field to `src/db/types.ts`:
```ts
/** Confidence scores from AI extraction (if session was pre-filled). */
extractionConfidence?: Record<string, number>;
```

Update `src/db/session.ts` `updateSession` to accept this new field.

### 7. Confidence indicators in interview UI

Modify `src/components/FieldRenderer.tsx`:
- Accept optional `confidence?: number` prop
- If confidence exists and < 0.7, show a yellow "⚠ AI-extracted — please verify" badge next to the field
- If confidence ≥ 0.7, show a subtle green "✓ AI-filled" indicator
- No indicator if field was manually entered (no confidence score)

### 8. Wire extraction into WizardShell/useInterview

Modify `src/engine/useInterview.ts`:
- When loading a session that has `extractionConfidence`, expose it via the hook
- Pass confidence down through `WizardShell` → `FieldsPanel` → `FieldRenderer`

### 9. Menu bar settings link

Add a "Settings" link in `src/components/AppMenuBar.tsx` that navigates to `#/settings`.

---

## File Change Summary

| Action | File |
|--------|------|
| Create | `src/extraction/types.ts` |
| Create | `src/extraction/parseFile.ts` |
| Create | `src/extraction/extract.ts` |
| Create | `src/extraction/apiKey.ts` |
| Create | `src/extraction/index.ts` |
| Create | `src/pages/Settings.tsx` |
| Create | `src/components/UploadModal.tsx` |
| Modify | `src/App.tsx` — add `/settings` route |
| Modify | `src/pages/Home.tsx` — add upload option per doc type |
| Modify | `src/db/types.ts` — add `extractionConfidence` to Session |
| Modify | `src/db/session.ts` — accept new field in updateSession |
| Modify | `src/components/FieldRenderer.tsx` — confidence indicators |
| Modify | `src/components/FieldsPanel.tsx` — pass confidence prop |
| Modify | `src/components/WizardShell.tsx` — pass confidence from hook |
| Modify | `src/engine/useInterview.ts` — expose confidence |
| Modify | `src/components/AppMenuBar.tsx` — settings link |
| Modify | `package.json` — add mammoth, pdfjs-dist |

---

## Verification

1. `npm run dev` — app starts without errors
2. Navigate to Settings → enter API key → confirm saved in localStorage
3. On Home, click a document type → see "Start Blank" / "Upload Document" options
4. Upload a .txt file containing NDA-like text → observe extraction progress UI
5. After extraction, interview opens with fields pre-filled + confidence badges
6. Edit a pre-filled field → badge disappears, normal save behavior
7. Complete interview → Review → Preview works with extracted values
8. `npm run build` — production build succeeds with no type errors
