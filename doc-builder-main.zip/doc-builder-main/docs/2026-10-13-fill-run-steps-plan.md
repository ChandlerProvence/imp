# Keep the bulk-edit model drafting until in-scope fields are covered

## Context

An LCSP "fill all fields" run (chat troubleshoot export, 2026-10-13) stopped after 10 `propose_changes` calls with 53 of ~100 fields still empty. Nothing in the app stopped it: no round cap, no `max_tokens` truncation, prompt at ~99k tokens. The model chose to wrap up and listed ~30 draftable freetext/table fields as "lacking source detail" instead of drafting them.

Root causes, in order of leverage:

1. **Prompt gives the model an exit.** In `buildBulkEditChatSystemPrompt` ([src/ai/bulkEdit.ts:644-656](src/ai/bulkEdit.ts#L644-L656)): "Call with ALL changes in a single batch", "Omit fields you cannot determine", and "If you cannot determine a value... state which field and why" override `FREETEXT_DRAFTING_RULE` ([src/ai/promptUtils.ts:57-63](src/ai/promptUtils.ts#L57-L63)) for narrative fields. The tool result's `fields_still_empty` is "for your reference" and mixes unfillable fact fields with draftable freetext/table fields.
2. **Stopping is unchecked.** The hook ([src/hooks/useAiChat.ts](src/hooks/useAiChat.ts)) ends the turn whenever the model returns text without tool calls. Nothing verifies coverage. Claude Code treats stopping as a checked action: an explicit checklist, an end-of-turn self-check instruction, and a Stop hook that can veto and re-prompt.
3. **Context grows without bound.** Each continuation re-sends the whole history; only the system prompt is cached ([src/ai/litellm.ts:246-256](src/ai/litellm.ts#L246-L256)). The run hit 99k tokens/call at 47 fields. Finishing 100 fields in one thread would approach the context limit and multiply cost. Claude Code handles this by offloading work to subagents with a fresh context and keeping only the conclusion.

Outcome wanted: on a fill-all request, every freetext/table field in scope ends up with a draft; fact-only fields stay empty only when no source states them; cost per call stays flat as the document grows.

Decisions made with the user: no model-only fix; build the harness pieces (checklist, veto/retry, isolated step contexts). Step unit is **one section per step**, not one field (per-field multiplies calls ~5x for no coverage gain; per-field is the fallback for stragglers).

## Phase A — Prompt and tool result (no new control flow)

### A1. Split the tool result — [src/hooks/useAiChat.ts](src/hooks/useAiChat.ts)

`getEmptyFieldKeys` (line 194) returns `{ key, label }`; add `type: field.type`.

In the `propose_changes` handler (~lines 547-570) replace `fields_still_empty` with:

- `fields_to_draft` / `fields_to_draft_count`: empty fields of type `freetext`. (Shipped 2026-10-26 as freetext only. Tables were planned here but every FMS table is a fact table, so they stay under `fields_awaiting_source_facts` until the two-stance plan's `ai_mode` can mark a table as compose.)
- `fields_awaiting_source_facts`: all other empty fields.

When `fields_to_draft` is non-empty, make `message` imperative in both the normal and truncated branches:

> "N changes received. M freetext/table fields in scope are still empty: call `propose_changes` again for them (a few per call) before you finish. Fields under fields_awaiting_source_facts may stay empty if no source states a value."

Drop `fields_still_empty` (only the model consumed it).

### A2. Reword "Proposing Changes" — [src/ai/bulkEdit.ts:644-656](src/ai/bulkEdit.ts#L644-L656)

- "Call with ALL changes in a single batch." → "Group related fields into each `propose_changes` call (roughly 3-6 long narrative fields, more if short) and keep calling it until every in-scope field is covered. Several calls per turn is the expected workflow for long documents."
- "Include only fields where you have a value... Omit fields you cannot determine." → "For string/number/date/enum/multiselect fields, omit a field when no source states a value and say so. For freetext and table fields, always propose a draft (see the freetext drafting rule); lower the confidence instead of omitting."
- "Before finishing, verify... for your reference." → "**End-of-turn check:** before you write a final reply, re-read the latest tool result. If `fields_to_draft` is non-empty, you are not done: call `propose_changes` again for those fields. Never summarize remaining fields as a substitute for drafting them. Fields under `fields_awaiting_source_facts` may stay empty only when no source states them; list those with the reason."

Leave `FREETEXT_DRAFTING_RULE`, `GROUNDING_RULES`, and "Be concise." unchanged.

### A3. Tests

- [src/hooks/getEmptyFieldKeys.test.ts](src/hooks/getEmptyFieldKeys.test.ts): assert `type` is returned.
- [src/hooks/useAiChat.test.ts](src/hooks/useAiChat.test.ts): reuse `runToolTurn`. Case 1: schema with empty freetext + empty string field → tool result has `fields_to_draft` (freetext key), `fields_awaiting_source_facts` (string key), message contains "call `propose_changes` again". Case 2: only fact-only fields remain → no `fields_to_draft`, plain message.
- [src/ai/bulkEdit.validation.test.ts](src/ai/bulkEdit.validation.test.ts): prompt contains "fields_to_draft" and "End-of-turn check"; does not contain "single batch" or "Omit fields you cannot determine".

## Phase B — Harness-enforced steps (Claude Code's checklist + Stop hook)

New module `src/ai/fillPlan.ts` (pure, testable) plus a step runner in the hook. Applies only to **fill-all requests** (document or section scope, initial message is the fill prompt, i.e. `request.prompt` undefined or the default "Fill in all fields..." string in [src/ai/bulkEdit.ts:727](src/ai/bulkEdit.ts#L727)). Ordinary chat turns are untouched.

### B1. Plan builder — `src/ai/fillPlan.ts`

```ts
export interface FillStep { id: string; sectionId: string; label: string; fieldKeys: string[] }
export function buildFillPlan(schema, selectedSectionIds, currentAnswers, pendingProposals): FillStep[]
```

- One step per in-scope section that has at least one empty, model-fillable field (reuse the skip rules from `getEmptyFieldKeys`: `same_as`, `computed`, `image`; also honor `visible_when` via `src/engine/contentBlocks.ts` so hidden sections are not stepped).
- Steps ordered by schema order. (Amended 2026-10-26 by `docs/2026-10-26-extract-compose-stances-plan.md`: steps are grouped by stance first, extract before compose, then by schema order within each group; each `FillStep` carries `stance`.) `fieldKeys` lists every empty field in the section (both draftable and fact-only), so the model sees facts it might still find.
- Sections with more than ~8 draftable fields are split into sub-steps of ≤8 (LCSP `sustainment_strategy` has ~37 fields → 5 sub-steps).
- Also export `coverageGap(step, proposals): { toDraft: string[]; factOnly: string[] }` using the same freetext/table split as A1.

### B2. Step runner — [src/hooks/useAiChat.ts](src/hooks/useAiChat.ts)

Add `fillRunRef` state: `{ steps, index, retries, status }` and expose `fillProgress: { index, total, label } | null` plus `cancelFillRun()`.

Flow:

1. `sendMessage` for a fill-all request builds the plan and stores it; the first step's instruction is appended to the user message instead of sending the whole-document fill prompt: "Step 1 of N — section 'Cover': draft these fields: … Call `propose_changes`; several calls are fine."
2. In `onDone` (turn ended without tool calls), if a fill run is active: compute `coverageGap(currentStep, accumulated proposals)`.
   - `toDraft` non-empty and `retries < 1`: **veto the stop** (the Stop-hook analogue). Append a synthetic user message with `displayLabel: "Continuing: M fields left in <section>"` and content "The turn ended with these freetext/table fields still empty: … Draft them now with `propose_changes`. Do not summarize." Send it. `retries++`.
   - `toDraft` non-empty after one retry: record the keys in `fillRunRef.skipped`, move on (bounded; no infinite loop, mirrors `stop_hook_active`).
   - `toDraft` empty: advance `index`; if more steps, send the next step's instruction as a synthetic user message; else finish and append a short assistant-visible summary message listing `skipped` and fact-only empties.
3. `stopStreaming` and `cancelFillRun` clear `fillRunRef`. `generationRef` guards still apply so a cancelled run never sends.
4. Synthetic messages are persisted like any user message so the troubleshoot export shows the full run. Add optional `AiChatMessage.step?: { index: number; total: number; label: string }` for rendering.

### B3. UI

- [src/components/ai-panel/AiPanelChat.tsx](src/components/ai-panel/AiPanelChat.tsx) and [src/components/bulk-edit/BulkEditChatView.tsx](src/components/bulk-edit/BulkEditChatView.tsx): show a progress line above the composer while `fillProgress` is set ("Step 4 of 12 · Sustainment Strategy (8 fields)") with a Cancel button wired to `cancelFillRun`.
- [src/components/ai-panel/UnifiedMessageList.tsx](src/components/ai-panel/UnifiedMessageList.tsx): render messages with `step` as a compact divider instead of a user bubble.
- The chat troubleshoot export ([src/ai](src/ai) exporter, grep `doc-builder-chat-troubleshoot`) gains `fillRun: { steps, skipped }` so future transcripts show the plan.

### B4. Tests

- `src/ai/fillPlan.test.ts`: plan excludes computed/same_as/image and already-answered fields; splits large sections; `coverageGap` split matches A1.
- `useAiChat.test.ts`: (a) fill-all send carries step 1 instruction; (b) `onDone` with uncovered draftable fields sends exactly one synthetic continuation, a second `onDone` with the same gap advances instead of retrying; (c) covered step advances to step 2; (d) `cancelFillRun` stops further sends; (e) a non-fill message never triggers a step.

## Phase C — Isolated step contexts (Claude Code's subagents)

Goal: per-call prompt size stays flat. Without this, Phase B on a 100-field document still re-sends a growing history every call.

### C1. Step-scoped history

In `sendToLLM`, when a fill run is active, build the API message list from **only the current step's messages** (the step instruction, its tool calls/results, its continuation) rather than the whole conversation. Tag each persisted message with `stepId` so the slice is a filter, not a heuristic. The full conversation is still persisted and displayed; only what is sent to the model is sliced.

The first step must still carry the source-document guidance and document text. Factor the document portion of `buildBulkEditChatUserMessage` ([src/ai/bulkEdit.ts:~685](src/ai/bulkEdit.ts#L685)) into a reusable `buildSourceContextBlock(request)` and prepend it to every step's instruction. Small docs are re-sent each step (they are already truncated to ~2k chars when `search_references` is available, per the transcript); large docs continue to flow through `search_references`.

### C2. Working draft includes pending proposals

Proposals are not applied until the user accepts them ([src/context/AiPanelContext.tsx:507](src/context/AiPanelContext.tsx#L507)), so a fresh step would not see earlier drafts. In `buildSystemPrompt` ([src/context/AiPanelContext.tsx:222](src/context/AiPanelContext.tsx#L222)) merge `chat.accumulatedChanges` into the answers passed to `buildUnifiedSystemPrompt`, marking them AI-proposed via `fieldMeta` so `formatExistingAnswers` tags them "(AI-proposed)" (the existing "never cite your own proposals as evidence" rule then applies). This also lets each step see the facts (contract number, dates) found in step 1.

Caching note: this makes the system prompt change between steps, so the `cache_control` block on it stops hitting. Net effect is still a large reduction (flat ~30-40k/call vs growing to 100k+). If it matters later, split the system prompt into two blocks (stable rules + field listing first, volatile working draft last) and cache only the first; `buildAnthropicParams` in litellm.ts already emits `TextBlockParam[]`.

### C3. Scope per step

Each step's system prompt is built with `scope = { type: "section", sectionId }` ([src/ai/unifiedPrompt.ts:71](src/ai/unifiedPrompt.ts#L71)) so the field listing and `getEmptyFieldKeys` are limited to that section. `request.selectedSectionIds` for parsing must be set to the step's section for the duration of the step (the parser rejects out-of-scope keys; keep that behavior, it is the guard against the model wandering).

### C4. Tests

- `useAiChat.test.ts`: with a two-step plan, the second `streamChatCompletion` call's messages contain step 2's instruction and none of step 1's tool results; the persisted `messages` array still contains both.
- `AiPanelContext` test (new, near [src/hooks/useDocumentManager.*.test.ts](src/hooks) style): system prompt built during a fill run includes a pending proposal tagged "(AI-proposed)".

## Delivery order

1. Phase A alone is shippable and low risk; land it first.
2. Phase B and C land together. B without C would push long documents into context pressure; C without B has nothing to drive it.

## Verification

1. `npm test -- fillPlan getEmptyFieldKeys useAiChat bulkEdit unifiedPrompt` and `npm run build`.
2. Manual LCSP run (CUI endpoint, same five documents, "Fill in all fields"): expect a progress line stepping through sections; at the end the only empties are approvals, `cover.task_order`, `cover.document_number`, `cover.ldc`, and the two revision-only introduction fields. Export the troubleshoot JSON: every step's calls should show prompt tokens in a flat band (tens of thousands), not climbing toward 100k.
3. Regression on a short schema (NDA) with one small document: a single step, one or two calls, no retry loop on fact-only fields.
4. Cancel mid-run: no further requests fire; proposals made so far remain in the Changes tab.
5. Ordinary follow-up chat ("what did the SOW say about FSR response time?") in the same conversation still works and does not start a fill run.

## Documentation

Final step: ask the user whether to update `changelog.d/` (new fragment for branch `tutorial`: `### Added` for the stepped fill run, `### Fixed` for the early-stop), `README.md` (AI panel behavior), and `docs/public/development-plan.md`. Do not run `/update-docs` automatically.
