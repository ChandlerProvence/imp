# Prompt evaluation loop — can Claude Code tell whether a prompt change did what it was meant to?

**Date:** 2026-10-23
**Status:** Proposed. Nothing started.
**Builds on:** the `RUN_LLM_TESTS` stubs in `src/ai/extractionAccuracy.test.ts` and `src/ai/extractionTypeConformance.test.ts`; the headless pattern in `tools/render-docx.ts`; the rubric in `docs/2026-10-20-lcsp-drafting-quality-plan.md` Phase 0.
**Relates to:** `docs/2026-10-13-fill-run-steps-plan.md` (first case to evaluate; Phase B supplies the step loop this plan runs headlessly); `docs/2026-10-08-code-quality-plan.md` Phase 3 (tool-call dispatcher; this plan does the minimum extraction and Phase 3 can absorb it).

## Goal

A semi-automated loop in which a prompt change is stated as a hypothesis, Claude Code runs the AI Assistant's real prompt path against fixed cases before and after the change, computes the metric the hypothesis names, reads the outputs where the metric moved, and reports whether the behavior change is the intended one. The human decides; Claude Code measures and reads.

## Why a hypothesis, not a score

A generic quality score cannot say whether one edit worked. "Fewer freetext fields left empty on an LCSP fill run" and "no `search_references` call returns zero hits" are different edits with different evidence. Each change therefore carries a one-line hypothesis naming one target metric and a direction, plus a fixed set of guard-rail metrics that must not regress. The loop reports both. A target that moves while a guard rail regresses is a finding, not a win.

## Same model, so what is being tested

The app calls the standard, advanced and light models through the LiteLLM proxy. This Claude Code session runs a different model on a different path and does not hold a proxy key unless given one. But a shared model would not make the test circular. What the loop measures is the pipeline around the model: system prompt wording, `ai_hint` text, tool definitions and tool results, chunking and retrieval, type coercion. Same model plus a different prompt gives different output, and that difference is the thing measured.

The judge (Phase 3) is a separate call with its own prompt, run on the standard model. A judge that differs from the drafter is preferable; grading your own output inherits your own blind spots. Claude Code reading a sample of outputs is a second, independent judge.

## What exists today

| Piece | State | Consequence for this plan |
|---|---|---|
| Prompt builders (`buildBulkEditChatSystemPrompt`, `buildBulkEditChatUserMessage`, `buildUnifiedSystemPrompt`) | Pure functions, no browser imports | Run under `tsx` as is |
| `src/ai/litellm.ts` | Reads the API key and endpoint from `localStorage`; builds the base URL from `window.location.origin` | Needs a small Node shim: key from env, endpoint by id, absolute URL |
| Tool dispatch (`propose_changes`, `search_references`, `get_field_info`, `get_template_context`, `report_observations`, `ask_user`) | Inline in `src/hooks/useAiChat.ts` ~L500–L600 | Must be extracted to a pure module before the runner can execute a full tool loop |
| Retrieval (`retrieveRelevantChunks`, `handleSearchReferences`) | In `useDocumentManager`, backed by Dexie | Runner keeps chunks and embeddings in memory for one run; no Dexie |
| Fill-run step loop | Planned in `src/ai/fillPlan.ts` (pure) and the hook (fill-run plan Phase B) | The step runner should be a pure async function taking a send-turn callback so hook and CLI share it |
| LLM-gated tests | `describe.skipIf(!RUN_LLM_TESTS)` stubs with `it.todo` | Phase 1 gives them a runner to call |
| Prompt snapshots | `src/ai/__snapshots__/draftingStyle.test.ts.snap` only | Phase 0 extends the pattern |
| LCSP judge | Specified as an agent in the LCSP plan Phase 0; not written | Phase 3 writes a scripted judge from the same rubric; the agent form stays for CUI cases |
| Cases | `cases/` gitignored; `src/test/fixtures/answers/*.answers.json` committed | Eval cases need a committed, non-CUI home plus a gitignored one |

## Design

### Three tiers of check, cheapest first

1. **Prompt snapshot (no LLM, runs in CI).** For a handful of fixture requests, snapshot the rendered system prompt and user message. Confirms the edit landed and shows the exact text diff. Fails loudly when a prompt changes unintentionally.
2. **Headless run against the proxy.** `tools/eval-run.ts` takes a case directory, builds the request through the real prompt builders, drives the real tool loop, and writes everything it saw to a run folder. Each case runs three times by default, because one run proves nothing.
3. **Scoring.** Two kinds, kept separate:
   - **Behavioral metrics** computed from the transcript, deterministic and free: fields proposed over fields draftable (split freetext / table / fact); empties by field type; `propose_changes` calls; `search_references` calls and zero-hit searches; turns; prompt and completion tokens per call and in total; wall time; count of forbidden phrases (e.g. "lacking source detail"); `ask_user` calls; `report_observations` by type; parse failures and skipped entries from `parseBulkEditResponse`.
   - **Judge metrics** from a scripted LLM judge on the standard model: the five rubric items from the LCSP plan (coverage, specificity, traceability, consistency, honest gaps), 0–2 per freetext field, with the sources attached. A script rather than an agent here, so Claude Code compares numbers across runs instead of rereading prose.

### Case format

```
evals/
  cases/<case-id>/                 # committed; non-CUI, synthetic or scrubbed
    case.json                      # schema id, scope, tier, endpoint id, initial prompt, doc slots and roles, drafting style
    answers.json                   # starting answers (may be {})
    input/*.docx|pdf|md|txt        # source documents
    hypothesis.md                  # optional default hypothesis for this case
cases/<case-id>/eval/              # gitignored twin for real or CUI material; same layout
.eval-runs/                        # gitignored
  <case-id>/<prompt-hash>/<model>/<run-n>/
    request.json                   # rendered system prompt, user message, tools, parameters
    transcript.json                # every turn: assistant text, tool calls, tool results, usage, stop reason, timings
    proposals.json                 # accumulated ProposedChange[] plus skipped entries
    metrics.json                   # behavioral metrics
    judge.json                     # Phase 3, when run
  <case-id>/compare-<a>-<b>.md     # comparison reports
```

`prompt-hash` is a hash of the rendered system prompt, user message and tool definitions for that case, so an unchanged prompt never reruns and a baseline is computed once. Every run records the model ids returned by the proxy, the tier parameters and the git commit, so a proxy-side model update is distinguishable from a prompt regression.

### Hypothesis file

Written at the start of a change, on the branch, next to the change. Something like:

```markdown
# Hypothesis
Change: reword "Proposing Changes" in buildBulkEditChatSystemPrompt (fill-run plan A2).
Cases: lcsp-synthetic, fms-sh-proposal-short
Target: freetext_filled_ratio rises (currently ~0.45 on lcsp-synthetic)
Guard rails: prompt_tokens_per_call flat (±10%); unsupported_claims does not rise; parse_failures = 0
Runs: 3
```

The loop reads this file; the comparison report answers it line by line.

### The loop, as a skill (`/prompt-eval`)

1. Read `hypothesis.md` (or ask for one). Resolve the cases. Refuse CUI cases on an IL2 session unless the run is scores-only.
2. **Baseline.** Check out the prompt-relevant modules at `main` into a temp worktree, or reuse a cached baseline keyed by prompt hash. Run the cases.
3. **Candidate.** Run the same cases at the working tree.
4. **Compare.** For the target metric and each guard rail: median and spread over the runs, baseline vs candidate. Flag any guard rail that regresses beyond its tolerance.
5. **Read.** Claude Code opens the transcripts where the target moved most and least and says, in a paragraph, whether the behavior change is the one the hypothesis describes, and what else changed. On non-CUI cases only.
6. **Iterate, bounded.** If the hypothesis is not met, Claude Code may propose one prompt adjustment, rerun, and compare again. At most two iterations without a human decision.
7. **Report.** Write `compare-<a>-<b>.md`; print the table and the reading. The human decides whether the change ships.

## Phases

### Phase 0 — Prompt snapshots [1 hr]

- `src/ai/promptSnapshot.test.ts`: for four fixture requests (one short schema with inline docs, one with a `visible_when` gate, one with a drafting style, one fill-all LCSP step), snapshot the system prompt, user message and tool list.
- Snapshot updates become part of any prompt-changing MR, so the diff shows the exact wording change.

Tests: the snapshots themselves.

### Phase 1 — Headless runner, single turn, inline documents [5 hr]

- `src/ai/nodeClient.ts` (or a shim inside `tools/`): resolves the endpoint by id, reads the key from `LITELLM_API_KEY` or `.env`, builds an absolute base URL, and calls `fetchChatCompletion` / `streamChatCompletion` unchanged. No change to `litellm.ts` beyond letting the key and origin be injected.
- Extract `propose_changes` handling from `useAiChat.ts` into `src/ai/toolHandlers.ts`: a pure `handleProposeChanges(ctx, call, meta)` returning the tool result payload and the parsed changes, with the max-tokens truncation guard and `getEmptyFieldKeys` intact. The hook calls it; behavior unchanged. `get_field_info` and `get_template_context` follow if they are pure already.
- `tools/eval-run.ts <case-dir> [--runs 3] [--tier thorough] [--out .eval-runs]`: builds the request, runs the tool loop until the model stops or a round cap is hit, writes the run folder. Phase 1 handles only cases whose documents fit inline (no `search_references`); the tool is still offered and a call returns an empty result with a flag in metrics.
- `src/ai/evalMetrics.ts`: behavioral metrics from a transcript; unit-tested against a recorded transcript fixture.
- `tools/eval-compare.ts <case> <hash-a> <hash-b>`: the comparison table, median and spread, guard-rail flags, Markdown out.
- One committed case: `evals/cases/lcsp-synthetic/` built from the existing synthetic answers and a short synthetic tech volume, non-CUI.
- Fill in the `RUN_LLM_TESTS` stubs in `extractionAccuracy.test.ts` using the runner against the FMS answer fixtures, so the gated suites finally do something.

Tests: `toolHandlers` unit tests (the hook's propose_changes tests move here); `evalMetrics` on the fixture transcript; a `useAiChat` behavior test that the hook still accumulates proposals after the extraction.

### Phase 2 — Full tool loop and the fill run [5 hr]

Depends on fill-run plan Phase B for the step loop; retrieval can land first.

- In-memory retrieval for the runner: chunk with the app's chunker, embed through the proxy's embedding model, cosine top-K in memory. The runner and `useDocumentManager` share the chunk and ranking code; only the store differs. Embeddings cached under `.eval-runs/embeddings/<doc-hash>.json` so reruns are free.
- `search_references` and `report_observations` handlers join `toolHandlers.ts`.
- The fill-run step loop becomes `runFillPlan(plan, sendTurn, hooks)` in `src/ai/fillRun.ts`, pure and async; the hook passes a `sendTurn` that streams through the UI, the runner passes one that calls the proxy directly. Metrics gain per-step coverage, retries and skipped keys.
- Long-document cases become possible: the WFR-shaped synthetic case and, under `cases/`, the real WFR case on the CUI endpoint, scores only.

Tests: retrieval parity test (same chunks ranked the same by the app path and the runner path on a fixture doc); `runFillPlan` unit tests with a scripted `sendTurn` (covers fill-run plan B4 as well).

### Phase 3 — Scripted judge [4 hr]

- `tools/eval-judge.ts <run-dir>`: for each freetext field proposed, one call on the standard model with the field's `ai_hint`, the draft, and the relevant source text (inline docs whole; retrieved sections for long docs), returning a JSON score for the five rubric items and a list of unsupported claims with quoted sentences. Consistency is one extra call over the whole draft.
- Judge prompt lives in `src/ai/evalJudgePrompt.ts` and is itself snapshot-tested.
- Calibration: ten fields read by a human on the first baseline, recorded in `evals/cases/<case>/calibration.md`; the judge is re-checked against that set when its prompt changes.
- The `lcsp-judge` agent from the LCSP plan is still the right form for CUI cases where this session cannot read the text. Both consume the same rubric.

Tests: judge output parser on canned responses; a scoring-stability check (same run judged twice, scores within one point) run under `RUN_LLM_TESTS`.

### Phase 4 — The `/prompt-eval` skill [2 hr]

- `.claude/skills/prompt-eval/SKILL.md` implementing the loop above: hypothesis read, baseline via cache or temp worktree, candidate run, compare, read, bounded iterate, report.
- Ledger: `.claude/eval-ledger.json` records hypothesis, cases, prompt hashes, outcome and decision, in the style of `.claude/quality-ledger.json`, so repeated edits to the same prompt block show their history.

## Constraints to design around

- **Non-determinism.** Three runs per case minimum; report median and spread; a target metric that moves less than the spread is "no change". Pin `temperature` where the tier allows; record where it does not.
- **Impact level.** CUI material runs only on the CUI endpoint and only in a session cleared for it. On this IL2 session the loop can run such cases scores-only and must not open the transcripts. Keep at least one good non-CUI case per prompt path so the reading step is possible.
- **Cost.** A full LCSP fill run on the Thorough tier is many calls; three runs times two prompts times a judge pass adds up. Default to the Balanced tier for the loop, use Thorough only when the hypothesis is about tier behavior, and judge on the standard model. Print the token total at the end of every run.
- **Baseline drift.** The baseline is keyed by prompt hash and model id. When the proxy swaps a model, every cached baseline is invalid; the compare tool refuses to compare across model ids without `--force`.
- **Judge flattery.** Judges drift and reward length. Calibration against the human-read set is what keeps scores honest; never change the judge prompt and the drafting prompt in the same MR.

## First use

The fill-run early stop (`docs/2026-10-13-fill-run-steps-plan.md`, Phase A2). The metric is freetext fields proposed over freetext fields draftable, no judge needed, and the prompt lines to change are already identified in `buildBulkEditChatSystemPrompt`. Phase 0 and Phase 1 of this plan are enough to run that experiment. Build those, prove the loop on that case, then add retrieval and the judge for the LCSP quality work.

## Out of scope

- Browser-driven evaluation through the e2e suite. Slower and harder to reproduce; the headless runner shares the prompt builders and tool handlers, which is where the changes under test live. Revisit if a change touches the hook's own control flow and `runFillPlan` does not cover it.
- Automatic prompt optimization. The loop proposes at most one adjustment per iteration and stops after two; the human decides.
- A CI gate on live LLM runs. Everything behind `RUN_LLM_TESTS` stays opt-in; CI runs the snapshots.

## Documentation step

When a phase ships, ask the user whether to update `changelog.d/`, `README.md` (a short "Evaluating prompt changes" note under development) and `docs/public/development-plan.md`. Do not run `/update-docs` unprompted.
