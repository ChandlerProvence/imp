# Build plan: guided document builder

A schema-driven, TurboTax-style app for building standardized documents, with AI-assisted drafting from uploaded source material. Deployed as a static single-page application via **GitLab Pages** — no backend server required.

---

## 0. Tech stack

- **Frontend (the whole app)**: React + TypeScript, Tailwind, a JSON-schema-driven form renderer (react-jsonschema-form or a thin custom layer)
- **Build tool**: Vite — fast dev server, produces static output for Pages
- **Persistence**: IndexedDB via **Dexie** (~15 KB) for sessions, answers, and in-progress documents — browser-native, survives refresh, multi-tab safe, zero backend needed. Chosen over sql.js (WASM SQLite) because the access patterns are simple key lookups and list scans — no relational joins needed, and Dexie avoids the 1 MB WASM bundle + manual persistence plumbing.
- **AI**: LiteLLM proxy at `https://lmg.leadai.leidos.com` (OpenAI-compatible API). User provides their LiteLLM API key (stored in localStorage). Calls made from the browser via the OpenAI chat completions format.
  - **Available models:** `claude-4-6-sonnet-aws-comm-il2` (fast, cost-effective — default for extraction), `claude-4-6-opus-aws-comm-il2` (highest quality — recommended for drafting). User can select model in settings; more models will be added over time.
  - **CORS:** confirmed working — GitLab Pages origin can call the LiteLLM endpoint directly from the browser.
- **Document output (MVP)**: Markdown → rendered HTML preview; user copies or prints to PDF from the browser. No template authoring required to ship.
- **Deployment**: GitLab Pages — static files served from `public/` artifact on every push to `main`

### Why this works without a backend

| Original plan concern | Client-side solution |
|-----------------------|---------------------|
| Postgres for sessions/answers | IndexedDB — structured, queryable, persistent |
| Server-side schema loader | Schemas bundled at build time (JSON imports) or fetched as static assets |
| Interview engine endpoints | All logic runs in React state — no network calls |
| Document generation endpoint | Markdown → HTML preview rendered in-browser; print to PDF via browser |
| AI extraction endpoint | `fetch()` to `https://lmg.leadai.leidos.com/chat/completions` (OpenAI-compatible) with user's LiteLLM key |

---

## 1. Repo structure

```
/doc-builder
  /src/
    /components/         # wizard shell, field renderer, upload UI, key-entry modal
    /pages/              # route-level views (home, interview, review, dashboard)
    /engine/             # interview engine: session state, section completion tracking
    /generation/         # Markdown rendering from completed answers → HTML preview
    /extraction/         # AI ingestion: text parsing, LiteLLM proxy calls (OpenAI-compatible)
    /db/                 # IndexedDB schema and access layer (Dexie)
    /schemas/            # document-type definitions (JSON, imported at build time)
      nda.schema.json
      lease.schema.json
  /public/               # static assets (favicon, etc.)
  index.html
  vite.config.ts
  .gitlab-ci.yml         # Pages deployment
  package.json
  PLAN.md                # this file
```

---

## 2. Phased build plan

### Phase 0 — Scaffolding
**Goal:** empty app runs locally and deploys to GitLab Pages.
- Init Vite + React + TypeScript project with Tailwind
- Configure `.gitlab-ci.yml` with a `pages` job (see §6)
- One placeholder page rendered at the root
- **Acceptance:** `npm run dev` shows the page locally. Pushing to `main` triggers a CI pipeline and the app is live at the GitLab Pages URL.

### Phase 1 — Schema definition format
**Goal:** define the document-type schema format (the extensibility backbone).
- Define TypeScript types for a "document type definition" (see §3 below for the shape)
- Build a loader that imports `/src/schemas/*.json` at build time and exports typed objects with a basic runtime sanity check (required fields present, field types valid)
- Write one real example: `nda.schema.json` with ~8 fields
- **Acceptance:** importing `nda.schema.json` produces a typed object usable in React components; a schema missing a required key (e.g. `id`) logs a clear error at dev time.
- **🔮 Extension:** add formal JSON Schema meta-validation (a meta-schema that rejects malformed files at build time) when third parties or non-developers start authoring schemas.

### Phase 2 — Interview engine (no AI yet)
**Goal:** a user can pick "NDA," answer questions in a wizard, and reach a "review" screen — hand-typed answers only.
- IndexedDB layer: session model (id, document type, answers keyed by `section_id.field_id`, current step, per-section confirmed status)
- One active session at a time (MVP) — starting a new document replaces the current session. Dashboard shows the single in-progress or most-recently-completed document.
- All fields and sections are visible at all times (no conditional logic in MVP)
- **Layout**: two-panel design (expands to three in Phase 4b):
  - **Left panel — section outline nav.** Lists all sections from the schema (e.g. "Parties," "Term," "Confidentiality"). Users can click any section to jump directly to it. Each section shows a status indicator:
    - ○ Empty — not yet visited
    - ◐ In progress — some fields answered
    - ✓ Green checkmark — all required fields completed and confirmed
  - **Main panel — field content.** Renders the fields for the currently active section. Supports back/forward navigation within a section and auto-saves to IndexedDB on every change. For `freetext` fields, shows a plain `<textarea>` where the user can write or paste prose.
- The outline nav is always visible during the interview, giving users a sense of progress and the ability to work non-linearly (skip ahead, come back to fill gaps).
- **Acceptance:** complete the NDA schema's interview end to end; clicking a section in the left nav jumps to it; sections show green checkmarks once all required fields are filled; refreshing the page resumes where you left off (IndexedDB restore).
- **🔮 Extensions:**
  - Add `visible_if` conditional logic (fields/sections show/hide based on earlier answers) once the base wizard is solid and a real schema needs it.
  - Replace plain `<textarea>` with a rich text editor (Tiptap, Lexical) for `freetext` fields when formatting control (bold, lists, headings) becomes a user need.

### Phase 3 — Document generation
**Goal:** a completed interview produces a formatted, downloadable document.
- Define a Markdown template per document type — a string in the schema (or a co-located `.md` file) with `{{field_id}}` placeholders
- Generation: substitute completed answers into the template → render Markdown → display as a styled HTML preview page
- Export options: "Print / Save as PDF" (browser-native `window.print()` with a print stylesheet), and "Copy as Markdown" for pasting elsewhere
- **Acceptance:** completing the Phase 2 wizard and clicking "Generate" shows a formatted HTML preview of the NDA with all answers filled in. User can print to PDF from the browser.
- **🔮 Extension:** add .docx output via docxtemplater (or docx.js) with authored Word templates when pixel-precise formatting, corporate letterhead, or specific Word styling is required. See Phase 3b below.

### Phase 3b — Word template generation (.docx output)
**Goal:** schemas can reference a `.docx` template file; generation fills placeholders and produces a downloadable Word document — preserving the template's native formatting (fonts, headers/footers, tables, logos).

#### Overview

Instead of (or in addition to) a Markdown `output_template`, a schema can declare a `docx_template` pointing to a colocated Word file. The file contains `{{PLACEHOLDER}}` tags in the document body. At generation time the app fetches the `.docx`, substitutes values via docxtemplater, and triggers a browser download.

#### File layout (colocation)

Each document type is a self-contained directory under `src/schemas/`:

```
src/schemas/
  nda/
    schema.json                              ← Markdown-only (existing)
  sh-request-memo/
    schema.json                              ← interview fields + template_key_map
    Tab_2_Memo_SH_Request_Fillable.docx      ← Word template with {{TAGS}}
```

A Vite plugin copies all `.docx` files from `src/schemas/` into `dist/templates/` at build time so they're fetchable as static assets at runtime.

#### Schema additions

```json
{
  "id": "sh-request-memo",
  "title": "SH Request Memo (Tab 2)",
  "version": 1,
  "sections": [ ... ],
  "docx_template": "Tab_2_Memo_SH_Request_Fillable.docx",
  "template_key_map": {
    "PREPARER_NAME": "header.preparer_name",
    "MEMO_DATE": "header.memo_date",
    "FMS_CASE": "case_info.fms_case"
  }
}
```

- `docx_template` — filename of the colocated `.docx` file
- `template_key_map` — maps each placeholder tag in the Word document to the interview answer key (`section_id.field_id`)
- `output_template` becomes optional (but can coexist for in-app HTML preview)

A schema must provide at least one of `output_template` or `docx_template`.

#### Dependencies

- `docxtemplater` — template engine for .docx XML (replaces `{{tag}}` inside Word's XML runs)
- `pizzip` — in-memory ZIP (docx = ZIP of XML files)
- `file-saver` — triggers browser download from Blob

#### Key design decisions

1. **Colocation:** schema and its `.docx` template live in the same directory (`src/schemas/<id>/`). Adding a new document type means adding one folder with everything inside — discoverable, self-contained, reviewable in one place.
2. **Build-time copy:** a Vite plugin (`vite-plugin-static-copy` or custom) copies `src/schemas/**/*.docx` → `dist/templates/` so templates are fetchable at runtime without bundling binary files.
3. **Key mapping:** explicit `template_key_map` rather than forcing template authors to use `section.field` dotted keys inside Word. Keeps templates natural and the mapping auditable.
4. **Delimiter config:** configure docxtemplater with `delimiters: { start: "{{", end: "}}" }` to match the double-brace convention used in templates.
5. **Coexistence:** schemas with both `output_template` and `docx_template` show an HTML preview AND a "Download as Word" button. Schemas with only `docx_template` show an informational card + download button.

#### Auto-generating schemas from Word templates (LLM-assisted)

Developers do **not** hand-write schemas from scratch. The recommended workflow:

1. Author or obtain a `.docx` template with `{{PLACEHOLDER}}` tags
2. Provide the template to an LLM (Claude, ChatGPT, etc.) with the prompting instructions in `README.md` §"Creating a New Document Template"
3. The LLM returns a complete `schema.json` — review, adjust, commit
4. Place both files in `src/schemas/<id>/`, register the schema in `loader.ts`

See `README.md` for the full LLM prompting guide.

#### Acceptance
- A `.docx` template in `public/templates/` + its schema produces a filled Word document download
- Existing Markdown-only schemas (like NDA) are unaffected
- Adding a new Word-templated document type requires zero application code changes

### Phase 4 — AI ingestion (extraction-to-draft)
**Goal:** a user can upload an existing document and get a pre-filled interview instead of a blank one.

#### MVP approach (ship first)

Simple single-pass extraction: upload → extract raw text in browser → send full text + schema to LLM → get field values back.

- API key entry: settings page where the user pastes their LiteLLM API key, stored in localStorage (never leaves the browser except to the LiteLLM proxy)
- Upload handling: accept PDF/docx/text in the browser; extract raw text using client-side libs (mammoth for .docx, pdf.js for PDF)
- Extraction call via OpenAI-compatible format:
  ```ts
  fetch('https://lmg.leadai.leidos.com/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: selectedModel,
      messages: [
        { role: 'system', content: 'Extract field values from this document...' },
        { role: 'user', content: rawText }
      ],
      response_format: { type: 'json_object' }  // structured output
    })
  })
  ```
  ```
  Available models (select in settings):
    - claude-4-6-sonnet-aws-comm-il2  (default for extraction — fast)
    - claude-4-6-opus-aws-comm-il2    (for complex drafting — highest quality)
  ```
  Response parsed into `{ field_name: { value, confidence } }`
- Wire extracted values into the session as pre-filled answers; low-confidence fields flagged for confirmation
- **Why this is sufficient for MVP:** one API call, no chunking logic, no extra infrastructure. Works well for short-to-medium documents (NDAs, offer letters — typically 2–10 pages).
- **Acceptance:** uploading a sample NDA produces a session with most fields pre-populated. The user walks through confirmation. Works with no backend — only the user's browser and the LiteLLM proxy.

#### Extension 1: Chunking + multi-pass (when documents get long)

**When to reach for this:** documents exceed ~30 pages, or extraction starts missing values buried deep in the text.

- Split the raw text into logical chunks (by heading/section if structure is detectable, or by token-count windows with overlap)
- Run extraction per-chunk: each call receives the schema + one chunk, returns partial field values
- Merge pass: combine results across chunks — take highest-confidence value per field, flag conflicts for user review
- Same UI — user still sees a pre-filled wizard with confirmation. The multi-pass is invisible to them.
- **Acceptance:** a 50+ page document extracts correctly across chunks; fields that appear in multiple chunks resolve to the highest-confidence value without duplicates.

#### Extension 2: Layout-aware parsing (when formatting matters)

**When to reach for this:** documents with complex tables, multi-column layouts, headers/footers, or structured forms where mammoth/pdf.js flattens important structure.

- Replace or supplement mammoth/pdf.js with a layout-aware parser that preserves:
  - Table structure (rows/columns as structured data, not flattened text)
  - Section headings and hierarchy
  - Reading order in multi-column layouts
  - Form field labels + values as key-value pairs
- Options (evaluate when needed):
  - **unstructured.io** — open-source, runs as a service or self-hosted
  - **Azure Document Intelligence** — cloud API, strong table/form extraction
  - **pdf2json** — lighter-weight, preserves some layout metadata
- The extraction LLM call receives structured input (e.g. sections with labeled tables) rather than a wall of flat text — higher accuracy with less token usage
- **Interface stays the same:** upload → pre-filled wizard. Only the parsing internals change. The extraction module should be designed with a `Parser` interface from the start so swapping implementations is a config change, not a rewrite.

### Phase 4b — AI writing assistant (conversational drafting)
**Goal:** users can draft free-text sections through a conversation with an AI assistant, with awareness of the rest of the document.
- **Right panel chat UI:** a collapsible chat panel that opens when the user clicks "Draft with AI" on any `freetext` field. The layout becomes three-panel (outline | fields | chat). Conversation history is persisted per-section in IndexedDB.
- **Context (MVP — automatic):** the system prompt always includes the current section's schema definition + all already-completed field values across the entire session. Simple and sufficient — the AI always knows everything the user has filled in so far. No manual scope picker needed.
- **Conversation flow:**
  1. User asks: "Help me write the confidentiality obligations section"
  2. AI responds with a draft, may ask clarifying questions ("Should this cover oral disclosures?")
  3. User iterates: "Make it mutual" / "Add a carve-out for public information"
  4. When satisfied, user clicks "Use this" → the AI's output is inserted into the `freetext` field in the main panel
- **Edit after insertion:** the user can always hand-edit the inserted text, or reopen the chat to refine further. The chat history is preserved so the AI remembers prior context.
- **Acceptance:** user can open the chat panel, have a multi-turn conversation, and insert the drafted text into a `freetext` field. Reopening the chat resumes the prior conversation. The assistant correctly references field values from other completed sections.
- **🔮 Extension:** add a section scope selector at the top of the chat panel so users can explicitly choose which sections to include in context. Useful when documents get large enough that sending all completed fields is too noisy or exceeds token limits.

### Phase 5 — Second document type (extensibility test)
**Goal:** prove the schema-driven design delivers on extensibility.
- Author a second schema (e.g. a lease or offer letter) with its Markdown template — **no new application code should be required**, only a schema JSON file
- **Acceptance:** the second document type works through the full pipeline (interview → generation → extraction) with zero changes to `/src/engine` or `/src/components`. If changes were needed, fix the schema format.

### Phase 6 — Polish and hardening
- Validation error states in the wizard (required fields, format checks)
- Session list / dashboard showing in-progress and completed documents (reads from IndexedDB)
- Export/import sessions as JSON (portability — IndexedDB is per-browser)
- Graceful handling of missing/invalid API key, LiteLLM proxy errors, rate limits
- ~~CORS note:~~ ✅ Confirmed — the LiteLLM proxy allows browser-origin requests from GitLab Pages. No CORS shim needed.

---

## 3. Schema shape (starting point for Phase 1)

```json
{
  "id": "nda",
  "title": "Non-disclosure agreement",
  "version": 1,
  "sections": [
    {
      "id": "parties",
      "title": "Parties",
      "fields": [
        {
          "id": "disclosing_party_name",
          "label": "Disclosing party name",
          "type": "string",
          "required": true
        },
        {
          "id": "is_mutual",
          "label": "Is this a mutual NDA?",
          "type": "boolean",
          "required": true
        },
        {
          "id": "receiving_party_name",
          "label": "Receiving party name",
          "type": "string",
          "required": true
        }
      ]
    },
    {
      "id": "obligations",
      "title": "Confidentiality Obligations",
      "fields": [
        {
          "id": "obligations_text",
          "label": "Describe the confidentiality obligations",
          "type": "freetext",
          "required": true,
          "ai_hint": "Draft mutual or one-way confidentiality obligations appropriate for the named parties."
        }
      ]
    }
  ],
  "output_template": "## Non-Disclosure Agreement\n\n**Parties:** {{parties.disclosing_party_name}} and {{parties.receiving_party_name}}\n\n**Mutual:** {{parties.is_mutual}}\n\n### Confidentiality Obligations\n\n{{obligations.obligations_text}}"
}
```

**Field types (MVP):** `string`, `number`, `boolean`, `date`, `enum` (with an `options` list of plain strings — no separate label/value), and `freetext` (multi-paragraph prose — rendered as a `<textarea>`, eligible for AI-assisted drafting via Phase 4b).

The `output_template` is a Markdown string with `{{section_id.field_id}}` placeholders (namespaced by section) — the generation step substitutes values and renders to HTML.

The `ai_hint` field is optional guidance passed to the AI writing assistant when helping draft that field.

**🔮 Extensions (add to schema when needed):**
- `visible_if: { "field": "is_mutual", "equals": true }` — conditional field visibility based on other answers. Add when schemas have fields that genuinely shouldn't appear in certain cases.
- `depends_on: ["field_id", ...]` — explicit list of fields whose values are passed as extra context to the AI assistant. Add when the automatic "send all completed fields" approach (MVP) gets too noisy on large documents.

---

## 4. User stories

### Story A: Building a document from scratch

1. **Land on the app** — User opens the GitLab Pages URL. Sees a dashboard with document types to choose from (NDA, Lease, etc.) and any in-progress sessions.
2. **Pick a document type** — User clicks "NDA." A new session starts. The wizard opens with the section outline on the left and the first section's fields on the right.
3. **Walk through the interview** — User fills in fields section by section:
   - "Disclosing party name?" → types "Acme Corp"
   - "Is this a mutual NDA?" → selects Yes
   - "Receiving party name?" → types "Globex Inc"
   - As each section is completed, a ✓ green checkmark appears next to it in the left outline.
   - User can click any section in the outline to jump to it — no need to go strictly in order.
   - Progress auto-saves to IndexedDB on every answer.
4. **Review** — Once all sections show green checkmarks, a summary screen shows all answers. User can click any section to go back and edit.
5. **Generate** — User clicks "Generate." A formatted HTML preview of the NDA appears with all answers filled in. User can print to PDF or copy as Markdown.

### Story B: Pre-filling from an existing document

1. **Pick a document type** — Same as above, selects "NDA."
2. **Upload instead of starting blank** — User clicks "Upload existing document" and drops in a PDF/docx of an NDA they already have.
3. **AI extraction** — The app sends the document text to the LiteLLM proxy, gets back extracted field values with confidence scores. *(Requires the user to have entered their API key in settings once.)*
4. **Guided confirmation** — The wizard opens with fields pre-filled. The left outline shows sections as ◐ (in progress) rather than ✓ — the user must confirm each section. High-confidence fields show a green "looks right" indicator; low-confidence fields are highlighted for attention.
5. **Approve section by section** — User reviews a section's pre-filled values, edits any that are wrong, and clicks "Confirm section." The section flips to ✓ in the outline.
6. **Generate** — Same as Story A — formatted HTML preview, print to PDF.

### Story C: Drafting a section with the AI assistant

1. **Reach a freetext section** — User is on the "Confidentiality Obligations" section. The main panel shows a textarea (blank or with prior draft). A "Draft with AI" button is visible.
2. **Open the chat panel** — User clicks "Draft with AI." A right panel slides open with a conversation interface. The AI automatically has access to all fields the user has completed so far.
3. **Converse** — User types: "Draft the obligations section — make it mutual, include a carve-out for publicly available information."
4. **AI responds** — The assistant drafts the prose, aware that the disclosing party is "Acme Corp," that it's mutual, and the receiving party is "Globex Inc" (pulled from completed fields).
5. **Iterate** — User: "Add a 2-year survival period after termination." AI revises the draft.
6. **Accept** — User clicks "Use this" on the message they like. The text is inserted into the textarea in the main panel. User can hand-edit further.
7. **Section completes** — Once the user is satisfied, they confirm the section. ✓ appears in the left outline. The chat history is saved — reopening the chat later picks up where they left off.

### Story D: Resuming work

1. **Close the browser mid-interview** — Answers are already in IndexedDB.
2. **Come back later** — Open the app, see the in-progress session on the dashboard (with a progress indicator showing e.g. "3/5 sections complete"), click to resume.
3. **Pick up where they left off** — The outline shows which sections are done (✓), in progress (◐), or empty (○). User continues from any section they choose.

### Story E: Setting up the API key

1. **First time using AI features** — User clicks "Upload existing document," gets a prompt: "Enter your LiteLLM API key to enable AI extraction."
2. **Paste key** — Stored in localStorage. One-time setup. UI clearly states the key is sent only to `lmg.leadai.leidos.com` and never stored on any other server.
3. **Done** — All future uploads use the saved key. User can update or remove it from settings at any time.

---

## 5. Notes for implementation

- Work phase by phase, in order — each phase's acceptance test is a real gate, not a suggestion.
- Treat Phase 5 as the real test of the architecture. If adding the second document type touches engine/component code, stop and fix the schema format.
- Keep the AI extraction and the interview engine decoupled: extraction produces answers in the same shape as manual entry — no separate code paths for "AI-filled" vs "user-typed."
- Since there's no backend, all state lives in IndexedDB. Test that refresh, tab close, and multi-tab scenarios work without data loss.
- The LiteLLM API key never touches any server you control — it goes straight from localStorage to `lmg.leadai.leidos.com`. Make this clear in the UI.

---

## 6. GitLab Pages deployment

### 6.1 How it works

GitLab Pages serves static files from a `public/` artifact produced by a CI job named `pages`. Vite's build output is a static bundle — perfect fit.

The app will be available at:
```
https://ams-oot.gitlab.lsde.leidos.com/doc-builder/
```

### 6.2 `.gitlab-ci.yml`

```yaml
stages:
  - test
  - deploy

sast:
  stage: test

secret_detection:
  stage: test

pages:
  stage: deploy
  image: node:20-alpine
  script:
    - npm ci
    - npm run build          # Vite outputs to dist/
    - mv dist public         # GitLab Pages requires public/
  artifacts:
    paths:
      - public
  only:
    - main

include:
  - template: Security/SAST.gitlab-ci.yml
  - template: Security/Secret-Detection.gitlab-ci.yml
```

### 6.3 Vite config for sub-path

GitLab Pages serves project sites under a sub-path (`/doc-builder/`). Configure Vite's base path:

```ts
// vite.config.ts
export default defineConfig({
  base: '/doc-builder/',
  // ...
})
```

And use `HashRouter` (or configure the router's `basename`) so client-side routing works without server-side rewrites.

### 6.4 Enabling Pages

1. **Settings → General → Visibility** — ensure Pages access is set (project members or public, depending on audience)
2. Push to `main` — the `pages` job runs, artifact is picked up, site goes live
3. No environment variables needed in CI — the app has no server-side secrets (API key lives in the user's browser)

### 6.5 Notes

- GitLab Pages on self-managed instances requires the Pages daemon to be enabled by an admin. Verify with your GitLab admin if the Pages URL doesn't resolve after a successful pipeline.
- Since the app is a SPA with client-side routing, add a `public/404.html` that redirects to `index.html` (or use HashRouter to avoid the problem entirely).
- The entire app — including interview logic, document generation, and AI extraction — runs in the user's browser. Nothing is stored on or transmitted to your GitLab instance beyond the static files themselves.
