# When to adopt an agent framework (LangGraph and similar)

**Date:** 2026-10-26
**Status:** Decision record. Not now; revisit at the triggers below.

## What the app's orchestration is today

One hook, `src/hooks/useAiChat.ts`, runs a chat loop with six tools through LiteLLM. The planned fill run (`docs/2026-10-13-fill-run-steps-plan.md`) adds a step list, a coverage check that can veto a stop once, and per-step history slicing. The two-stance plan (`docs/2026-10-26-extract-compose-stances-plan.md`) adds stance-ordered steps, per-step tier routing, and a brief step between phases. The drafting-quality plan adds one review call and at most one revise call per compose step.

Drawn as a graph, that is a linear pipeline with one bounded retry edge and one conditional edge (review → revise if high severity). Every node is deterministic code except the model calls themselves. There is no branching the model decides, no parallel fan-out, and no need to resume a run from the middle after a crash.

## What a framework buys and what it costs here

| Framework feature | Would it help Doc Builder today? |
|---|---|
| Graph definition with conditional edges | Marginal. Two conditional edges fit in a `switch`. |
| Checkpointing and resume | Partially. Conversations already persist to IndexedDB per message; a fill run that dies mid-way can restart from the last completed step with ~30 lines in the step runner. |
| Human-in-the-loop interrupts | The app already has them: proposals are pending until accepted, the brief card is user-editable, Cancel stops the run. |
| Parallel branches | Not wanted. Compose steps are sequential on purpose so later sections see earlier drafts. Extract steps could fan out, but the proxy rate limit and the UI's one-stream model make that a cost, not a gain. |
| Multi-agent handoff | Not wanted. One model, one tool set, stance selects the prompt block. |
| Tracing and observability | The chat troubleshoot export plus `tools/chat-run-metrics.ts` already give per-call tokens, tool calls and coverage. LangSmith-style tracing would need an external endpoint, which CUI and the IL2/IL5 proxy rule out. |
| Provider abstraction | Negative. LangChain's Anthropic and OpenAI adapters each carry their own message and tool shapes, and `cache_control`, thinking and `output_config` support lag the SDK. LiteLLM is already the portability layer. |
| Browser runtime | LangGraph.js runs in the browser, but it pulls a large dependency tree into a bundle that is already 2.1 MB and on the backlog to shrink. |

The net: a framework would replace about 300 planned lines of step-runner code with a graph definition of similar size, add a dependency that couples the app to one vendor's abstractions, and remove nothing the app needs.

## Triggers that would change the answer

Adopt a framework when two or more of these are true.

1. **Model-decided branching.** The run needs the model to choose among more than two or three paths at a node (which document to read next, which sections to revisit, whether to request a new upload), and the choice is made repeatedly. Hand-written dispatch stops being readable past that point.
2. **Resume across sessions is a product requirement.** A fill run that takes an hour and must survive a browser restart, with the user picking up exactly where it stopped, is a checkpointing problem the framework solves well.
3. **Parallel subagents with their own contexts.** If compose steps are split into independent drafters per section group that must merge, with a reconciliation node, the graph is doing real work.
4. **A backend appears.** Frameworks fit a server that orchestrates long runs much better than a browser tab. If the high-side portability work or a future deployment puts a service behind the app, the orchestration can move there and a framework is a natural fit.
5. **More than one orchestration.** When a second workflow of similar shape appears (a review-only run, a set-wide fill across several documents, a template-generation pipeline), shared infrastructure starts paying for itself.

Until then, keep the step runner as plain TypeScript with the explicit structure the fill-run plan already lays out: a plan builder (pure), a runner (hook state), and a coverage check (pure). Write it so a graph could be extracted later: each step is a function of `(state) → state'`, retries are bounded by data not by control flow, and no step reads React state directly.

## If and when

Prefer LangGraph.js over LangChain's chains, since the graph API is the part that maps to the problem. Keep LiteLLM as the model boundary and write a thin model node that calls `src/ai/litellm.ts` rather than using the framework's provider adapters, so the feature flags and classifiers stay in force. Checkpoint to the existing Dexie database with a custom saver, not to the framework's default store.
