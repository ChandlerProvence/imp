**LEIDOS PROPRIETARY**

# Procurement Operations Portal — Decision Brief

*FMS F-16 Sustainment — Supply Chain Procurement · October 23, 2026 · Full proposal: <https://ams-oot.pages.lsde.leidos.com/doc-builder/docs/public/pop-proposal>*

## The problem

The program's goal is 7 business days from PR to Task Order at 125 PRs a month, four times this year's rate. Nobody can say whether it is being met: the start date is in Costpoint, the end date in POF, and the steps between leave no record. *[Measured 2026 baseline to be inserted.]* Each PR takes 2–3 hours of hands-on work and then waits hours to days between steps. Doc Builder, in daily use, took an estimated hour and a half out of the hands-on part. The waiting is untouched.

## The decision

**Approve Phase 1 of a shared portal: about 140 developer hours (~$21K) plus $2–5K a year in hosting.** One workspace per Task Order, a TOM-to-SCA handoff that checks the package before the SCA starts, a shared queue, and continuous measurement of the 7-day goal, with Doc Builder embedded.

| Per PR | At goal volume, 125 PRs/mo | At today's, 30 PRs/mo |
|---|---|---|
| Phase 1 pays for itself in year 1 if it recovers | ~13 min (~$16) | ~55 min |
| The structured handoff alone is estimated to recover | 15–30 min | 15–30 min |

Two items need no separate decision. Keeping Doc Builder current at 1–2 developer hours a week protects an estimated $40K a year in SCA time today, $170K at goal; it should continue. Phase 2, about 230 hours of Costpoint, POF, SharePoint, and Outlook integration, is not requested. It is decided after one quarter of Phase 1 data: 2a if measured volume averages 50 PRs a month or more; 2b when IT grants Costpoint and POF access and measured prerequisite waits exceed a day.

**Why not Microsoft Lists and a small AI service, at ~80 hours and under $10 a month?** It delivers the queue, the handoff check, and the measurement, and is the right fallback if 140 hours is not available. It was not chosen because the SCA would enter every Task Order's data twice, in the list and in Doc Builder, and because the team would change tools twice: by the second Phase 2 integration the service has become the portal's backend and the portal gets built anyway. The extra 60 hours now saves about that many later. The portal also carries to other programs and a .mil host as one unit, a benefit to Leidos more than to this program.

## After one quarter you will see

Median and 90th-percentile PR-to-issue time against the 7-day goal, the share over 7 days, where each PR waited and for how long, the return rate, and throughput per person, from timestamps the work itself leaves. Phase 2 is decided on these.

## What could go wrong

| Risk | Then |
|---|---|
| FMS data classification rules out commercial Azure, or the tenant is GCC | Confirm with IT first; the portal redeploys to Azure Government (~20% above list) as one unit |
| Nobody owns the portal after the single developer | Name an owner before build; containerized, documented; Lists is the exit |
| Costpoint or POF APIs are restricted | Those steps stay manual, as in Phase 1 |

All figures but the 261-PR count and the program goals are estimates (developer hours ±50%); Phase 1 replaces them with measurements. Dollars assume $75/hr SCA and $150/hr developer rates, for finance to replace. Hosting is Azure list; confirm IT's chargeback model. Sources are in the full proposal.

*Leidos Proprietary — not to be reproduced, disclosed, or exported without written approval of Leidos.*
