# FMS F-16 Sustainment — Procurement Process Documentation

*Living reference document. Updated as discovery progresses.*

*Last updated: August 3, 2026*

---

## Contents

1. [Overview — The End-to-End Flow](#1-overview--the-end-to-end-flow)
2. [TOM Workflow: Sourcing Through Handoff](#2-tom-workflow-sourcing-through-handoff)
3. [The TOM → SCA Handoff](#3-the-tom--sca-handoff)
4. [SCA Workflow: SH Task Order Issuance](#4-sca-workflow-sh-task-order-issuance)
5. [SCA Workflow: TT&E Task Order Issuance (PR to TO Award)](#5-sca-workflow-tte-task-order-issuance-pr-to-to-award)
6. [Where the Time and Risk Go](#6-where-the-time-and-risk-go)
7. [Process Ladder — SH Task Order](#7-process-ladder--sh-task-order)
8. [Process Ladder — TT&E Task Order](#8-process-ladder--tte-task-order)
9. [Process Metrics & Baseline — TT&E](#9-process-metrics--baseline--tte)
10. [Identified Problems](#10-identified-problems)
11. [Information Gaps](#11-information-gaps)
12. [Glossary](#12-glossary)

---

## 1. Overview — The End-to-End Flow

1. FMS countries generate repair requirements in Catena, requesting F-16 parts for Test, Teardown & Evaluation (TT&E) and/or repair.
2. TOMs, aligned by country, receive the Catena request and source it via email to qualified Sources of Repair (SORs), copying SCAs.
3. SORs return capability and/or pricing (typically 5 days for existing parts, 15 for new). SCAs request pricing from the SOR for new parts.
4. The TOM evaluates responses, completes a SOR selection document, and transmits it to Contracts for customer submission.
5. On customer award, the TOM builds a Task Order folder in the FMS SharePoint site and works with Finance to create and approve the Purchase Requisition (PR).
6. Once the PR is approved, pricing is confirmed on the Master Agreement, and the PWS is final, the TOM emails the SCA a link to the PWS folder — and a parallel SH Task Order PWS/PR is created for the Shipping Hub subcontractor.
7. The SCA issues the SOR Task Order(s); only then can the SH Task Order be issued for shipment of the parts.

---

## 2. TOM Workflow: Sourcing Through Handoff

Before the SCA can issue an SH Task Order, the TOM must complete all upstream sourcing, selection, and funding work. This workflow runs in parallel across multiple countries and vendors:

```mermaid
flowchart TD
    A[Catena repair requirement received] --> B[Identify qualified SORs for the part/NSN]
    B --> C[Email sourcing request to SORs — copy SCA]
    C --> D{SOR responses received?}
    D -- No --> E[Follow up — 5-day / 15-day clock]
    E --> D
    D -- Yes --> F[Evaluate capability & pricing]
    F --> G[Complete SOR selection document]
    G --> H[Transmit selection to Contracts for customer submission]
    H --> I{Customer award received?}
    I -- No --> J[Wait for customer decision]
    J --> I
    I -- Yes --> K[Build Task Order folder in SharePoint]
    K --> L[Work with Finance to create PR]
    L --> M{PR approved?}
    M -- No --> N[Wait / resolve issues with Finance]
    N --> M
    M -- Yes --> O[Confirm pricing on Master Agreement]
    O --> P[Finalize PWS]
    P --> Q[Create parallel SH Task Order PWS & PR]
    Q --> R[Issue SOR Task Order]
    R --> S[Email SCA: PWS link + SH TO ready for issuance]
```

### Step-by-step narrative

- **Receive requirement & identify SORs** — Catena generates the repair requirement. The TOM identifies qualified SORs from memory and institutional knowledge of which vendors hold IDIQ positions for which parts.
- **Email sourcing requests** — TOM emails each qualified SOR, copying the SCA. Responses are tracked informally via email — no deadline dashboard or centralized view.
- **Evaluate SOR responses** — For existing parts, expect 5-day turnaround; for new parts, 15 days. Follow up manually on overdue responses.
- **Complete SOR selection document** — A structured evaluation justifying the chosen vendor. This is manual document assembly with similar pain points to the SCA's template work.
- **Transmit to Contracts** — Selection document sent to Contracts for customer submission; wait for customer award.
- **Post-award setup** — Build the Task Order folder in SharePoint, work with Finance to create the Purchase Requisition, confirm pricing on the Master Agreement, and finalize the PWS.
- **Create SH Task Order PWS & PR** — The TOM creates the parallel Shipping Hub Task Order PWS and PR for the Shipping Hub subcontractor.
- **Issue SOR Task Order** — The TOM issues the SOR Task Order(s).
- **Hand off to SCA** — TOM emails the SCA a link to the PWS folder, signaling the SH Task Order is ready for issuance.

---

## 3. The TOM → SCA Handoff

The handoff from TOM to SCA is the critical process boundary that gates SH Task Order issuance. Today it is an **informal email** — the TOM sends the SCA a link to the PWS folder. There is no structured verification that all prerequisites are met, no auditability, and no data transfer beyond the link itself.

### Prerequisites that must be complete before the SCA can act

| Prerequisite | How verified today | Risk |
|---|---|---|
| PWS finalized and uploaded to SharePoint | TOM sends link in email | SCA may receive the link before the PWS is truly final |
| SOR Task Order issued | TOM emails or verbally confirms | Confirmation can be missed or delayed (P-1) |
| Purchase Requisition(s) approved | TOM confirms or SCA checks Costpoint | May be stale or incomplete |
| Pricing confirmed on Master Agreement | TOM confirms | Not independently verifiable by SCA |
| Task Order folder built in SharePoint | Implicit — PWS link points to it | Folder may be incomplete |

### What's missing from the handoff today

- No checklist or structured data package — the SCA receives a link and must re-derive the context (how many shipments, which SORs, which PRs, what dates).
- No prerequisite validation — the SCA discovers missing prerequisites *during* their work, creating rework loops.
- No audit trail — if a confirmation was given verbally or the email is buried, there's no record.
- No visibility — the TOM doesn't know where the SCA is in the issuance process after handoff; the SCA doesn't know what's coming next from the TOM.

---

## 4. SCA Workflow: SH Task Order Issuance

This is the workflow that runs after TOM handoff. Today it runs as a long sequence of manual, judgment-and-confirmation steps. The 16-step baseline below was mapped during a process walk-through with the Supply Chain team (source: *FMS Shipping Hub TO Process Baseline*).

```mermaid
flowchart TD
    A[1. PWS link received via Teams — count SOR shipments] --> B[2. Check SCA Master Tracker for SOR TO status]
    B --> C{3. SOR TOs issued & confirmed?}
    C -- No --> W[Wait for email/Teams confirmation]
    W --> C
    C -- Yes --> D[4. Verify approved PRs per SOR shipment]
    D --> E{5. All PRs approved?}
    E -- Yes, proceed --> F[7. Save PWS to desktop]
    E -- No, wait --> E
    E -- Partially fund --> G[6. Process CP modification later when remaining PRs approved]
    G --> F
    F --> H[8. Convert PWS to PDF — note creation date]
    H --> I[9. Fill yellow-highlighted fields in Tab 2/3/5 templates → PDF]
    I --> J[10. Download Prime Award docs from Teams]
    J --> K[11. Process PR in Costpoint — create SH TO award]
    K --> L[12. CP assigns TO release number]
    L --> M[13. Complete award document & file index checklist]
    M --> N[14. Issue award package to IPT via email]
    N --> O[15. Create POF folder — upload all docs]
    O --> P[16. Update SCA Master Tracker]
```

### Step-by-step narrative (16-step baseline)

| # | Step | Touch time | Queue time | Action owner | Tool(s) |
|---|---|---|---|---|---|
| 1 | **PWS link received — count SOR shipments.** TOM sends a Teams channel notification with the PWS link once the PR is approved. SCA opens the PWS to determine how many SOR shipments are included. | 10–15 min | Varies (dependent on PR approval cycle) | SCA | Teams; PWS document |
| 2 | **Check SCA Master Tracker for SOR TO status.** Cross-reference SOR numbers from the PWS against the tracker to confirm issuance status. | 2 min | — | SCA | SCA Master Tracker (Excel/Teams) |
| 3 | **Wait for SOR TO issuance confirmation.** SH TO cannot be issued until the corresponding SOR TO(s) exist. SCA monitors for a copy on the award email or a direct confirmation. | 0 min (passive) | Variable — hours to days | SCA (monitoring) | Outlook / Email |
| 4 | **Verify approved PRs per SOR shipment.** Check Costpoint for an approved PR matching each PWS shipment line. | 5 min | — | SCA | Costpoint |
| 5 | **Decision: proceed / wait / partially fund.** If only one SOR with one approved PR → proceed. If multiple SORs and not all PRs approved → wait or partially fund and modify later. | 5 min | Variable if waiting | SCA | Costpoint; professional judgment |
| 6 | **Process CP modification (if partially funded).** Once remaining PR(s) are approved, process a modification in Costpoint to add the additional SOR shipments. | 10 min | Dependent on PR approval | SCA | Costpoint |
| 7 | **Save PWS to desktop.** Begin assembling the procurement file for upload to the POF system. | 5 min | — | SCA | Desktop / file system; POF |
| 8 | **Convert PWS to PDF — note creation date.** The PWS creation date becomes the document date for Tab 2, Tab 3, and Tab 5 memoranda. | 1 min | — | SCA | PDF converter (Adobe) |
| 9 | **Fill yellow-highlighted fields in Tab 2/3/5 templates → convert to PDF.** Manually update all highlighted fields with TO-specific information. | 10–15 min | — | SCA | Word templates; PDF converter |
| 10 | **Download Prime Award documents.** Retrieve from the FMS Teams channel (same location as PWS). | 3–4 min | — | SCA | Teams |
| 11 | **Process PR in Costpoint — create SH TO award.** Enter all required header and CP fields. | 3–4 min | — | SCA | Costpoint |
| 12 | **CP assigns TO release number.** System-generated upon award processing — no manual action. | 0 min | Immediate | Costpoint (system) | Costpoint |
| 13 | **Complete award document & file index checklist.** Fill remaining template fields; create the required checklist to accompany the procurement file. | 10 min | — | SCA | Word template; Excel/checklist |
| 14 | **Issue award package to IPT.** Email the completed SH TO award package (including PDF PWS) to the shipping vendor. | 3 min | — | SCA | Outlook / Email |
| 15 | **Create POF folder — upload all docs.** Create the official folder in POF and upload all procurement documentation. File remains while awaiting the fully executed and signed TO. | 10 min | Awaiting signed TO (days) | SCA | POF System |
| 16 | **Update SCA Master Tracker.** Record TO issuance details in the official tracker. | 2 min | — | SCA | SCA Master Tracker (Excel/Teams) |
| | **Totals** | **~79–91 min (~1.3–1.5 hrs)** | **Variable (hours to days on Steps 3, 5, 6, 15)** | | |

> **Note:** Touch-time and queue-time values are planning-level estimates based on the process narrative. They should be validated with actual time-tracking data before prioritizing automation investment.

---

## 5. SCA Workflow: TT&E Task Order Issuance (PR to TO Award)

This workflow covers the buyer's (SCA's) process for converting an approved Purchase Request into an executed Task Order for TT&E work. It parallels the SH Task Order workflow but is triggered by PR receipt rather than a PWS link from the TOM. The process was mapped during a team working session (source: *AI for F-16 Supply Chain Process Walk-Through*).

### Relationship to the SH Task Order workflow

Both workflows share the same document-assembly pattern (template fill, format conversion, Costpoint processing, POF folder creation), but they differ in:

- **Trigger:** SH workflow starts with a PWS link from the TOM; TT&E workflow starts with a PR notification.
- **Upstream dependency:** The TT&E PR arrives after the TOM has already completed PWS and Source Selection with the SOR — these are prerequisites, not parallel work for the buyer.
- **Document structure:** TT&E uses a 10-tab award file structure (vs. the SH workflow's tab set).
- **Pricing validation:** TT&E requires an explicit IDIQ price-sheet validation step before document generation.
- **Signature:** Only the Tab 5 Price Reasonableness Memo requires a signature (ink or electronic).

### Upstream context

Before the buyer receives a PR, the TOM works with the Source of Repair (SOR)/subcontractor to prepare the PWS and Source Selection package. These documents are supposed to be completed and stored in the SharePoint Procurement folder before the PR is submitted. When they are not, the buyer must send the PR back — a significant source of rework.

### Workflow

```mermaid
flowchart TD
    U[TOM prepares PWS & Source Selection with SOR] --> A[1. PR submitted by TOM — buyer notified]
    A --> B[2. Review PR against PWS & Source Selection]
    A --> V[3. Validate pricing against IDIQ price sheet]
    B --> C{PR complete & accurate?}
    C -- No --> D[Return PR to TOM for correction]
    D --> A
    C -- Yes --> E[4. Create 10-tab award folder in POF — Tab 1: PR]
    V --> H{All parts/rates on contract?}
    H -- No --> I[Escalate: add part/rate at IDIQ level]
    I --> H
    H -- Yes --> E
    E --> J[5. Tab 2: Source capability confirmation & memo]
    J --> K[6. Tab 3: Manual data-entry memo]
    K --> L[7. Tab 4: Pull GFP / award documentation]
    L --> M[8. Tab 5: Price reasonableness memo & pricing table — SIGNATURE REQUIRED]
    M --> N[9. Final tab: populate source/TO-specific fields; convert TO & PWS to PDF]
    N --> IC[10. Index Checklist — complete and upload]
    IC --> O[11. Upload complete file to POF; issue TO to subcontractor]
    O --> P[Subcontractor signs and returns executed TO]
```

### Step-by-step narrative

| Step | Activity | Touch Time | Queue / Wait | Input | Output | System(s) | Details |
|---|---|---|---|---|---|---|---|
| **Upstream** | TOM prepares PWS & Source Selection with SOR | TBD | TBD | Requirement / need for repair or supply | Completed PWS and Source Selection package | SharePoint (Procurement folder) | TOM works with the SOR/subcontractor to finalize these documents before PR creation. PR is not reviewed by the buyer until these are in hand. |
| **1. PR Notification** | TOM submits PR; buyer notified | N/A (notification only) | TBD | Approved PR (with PWS & Source Selection) | Email notification that PR is ready for buyer review | Email; CostPoint APR report | Buyer is notified via (a) email notification for a specific PR in "Approved" status, or (b) daily APR report filtered to the buyer's name. New program emphasis: 7-business-day turnaround from PR receipt to completion. |
| **2. Review PR** | Validate PR against PWS & Source Selection | ~20–30 min | Goal: 3 business days; Actual: up to ~7 business days | PR (PDF from CP), PWS (Word from SP), Source Selection (Excel from SP) | Confirmed PR ready for processing | CostPoint; SharePoint | Pull PR from CostPoint, review against PWS and Source Selection from SharePoint. If missing or inconsistent → return to TOM for correction. |
| **3. Validate Pricing** | Confirm parts/rates against IDIQ price sheet | ~15 min (varies with # of NSNs) | Done in parallel with PR review | IDIQ contract / subcontract price sheet (PDF/Excel) | Validated pricing or error notification to SCA | Subcontract file / price sheet | If a part/rate is not on the IDIQ, it must be added at the IDIQ level before proceeding — blocking dependency. 8 parts takes longer. |
| **4. Create Award Folder** | Build 10-tab folder structure in POF — Tab 1: PR | ~20 min | 1–2 days (other priorities / queue) | Reviewed PR (PDF from CP), Source Selection (Excel from SP) | Task order folder created with Tab 1 populated | POF / SharePoint | Create folder named for the TO number. Note: PR document in Tab 1 technically no longer required per compliance but reportedly still being requested for the index checklist — flagged to confirm/reconcile. |
| **5. Tab 2** | Source capability confirmation & memo to file | ~5–10 min | Quick if email on hand; longer if must be tracked down | Email chain (TOM request + source's capability/turnaround confirmation); Process Memo (from SP) | Tab 2 populated: capability-confirmation email PDF + process memo PDF | Outlook / email | The email from which the PWS creation date is derived. No standardized filing method for this correspondence — described as personal preference. Subject lines are relatively standardized but sending/receiving contacts vary. Team noted interest in a more reliable repository. |
| **6. Tab 3** | Manual data-entry memo | ~15–20 min | 0–1 day (if pulled away) | PR, SOR IDIQ price sheet, date from RFP email & SOR response, PWS (quantity/NSN) | Completed Tab 3 memo (PDF) | Word template (mostly pre-populated; header + highlighted fields are manual) | Update subject line, date, and name; check PR for what is being funded; double-check price sheet/rate on contract; determine total task value based on quantity/NSN. May be updated once approval from Tab 2 is confirmed. |
| **7. Tab 4** | Pull GFP / award documentation | ~5–10 min | 0–1 day (if pulled away) | SharePoint TO folder ("Award") | Tab 4 documents: Prime TO (PDF), Prime GFP (PDF) | CDMS Plus; SharePoint Teams-channel award folder | Practices differ by person — some pull from CDMS Plus for most current version, others from Teams award folder. Flagged as a place to standardize. |
| **8. Tab 5** | Price reasonableness memo & pricing table | ~20 min | 0–1 day (if pulled away) | Validated pricing (Step 3), NSN(s) from IDIQ price sheet, quantities from PWS/PR | Signed price reasonableness memo + pricing table (PDF) | Word/Excel template; Claude-assisted drafting (piloted) | **Only document requiring signature** (ink or electronic). Claude-assisted process for shipping-hub orders cut ~15–20 min off this step. |
| **9. Final Tab** | Populate source/TO-specific fields; convert TO & PWS to PDF | ~20 min | 0–1 day (if pulled away) | Task-order-specific data (NSN, quantity, TO number, date, etc.); PWS; TO template (Prism & Word) | Completed PDF versions of TO & PWS | Word/Excel template | Much of this information repeats from source to source — strong candidate for a standard input form/database. Team typically uses Tabs 1–5 and the final tab (nothing currently populates Tab 6). |
| **10. Index Checklist** | Complete and upload the index checklist | ~5–10 min | 0–1 day (if pulled away) | Total value of award (TO/PR), CRN (first six digits of account # on PR), PR #; Draft Index Checklist (from Prism) | Completed index checklist (Excel) uploaded to "cover" tab | POF / Excel | New step identified in VSM — previously collapsed into Final Tab. |
| **11. Issue Task Order** | Upload complete file & send TO to subcontractor | ~20 min | 1–2 weeks (dependent on SOR responsiveness; not part of cycle-time metric) | Completed award file (POF) | Executed task order (subcontractor signs and returns via email) | POF; email | Last step once the file has been fully built out. |

### Key observations from the working session

- **Pricing validation runs in parallel with PR review** — Step 3 (validate pricing against IDIQ) is done concurrently with Step 2 (review PR); this is not a sequential dependency.
- **Document retrieval = ~50% of process time** — The remaining ~50% is document generation/review, identified as the strongest automation target.
- **Claude-assisted drafting already piloted** — Heather tested Claude for the shipping hub variant of Tab 5/8 and reduced per-order time by ~15–20 minutes (from ~1 hr to ~45 min).
- **Repeating data entry** — The same data points (NSN, quantity, TO number, dates, pricing) are entered into multiple tabs/documents; strong candidate for a single intake → auto-populate pattern.
- **Tab structure is partially utilized** — Team typically uses Tabs 1–5 plus the final tab, not all 10 (nothing currently populates Tab 6).
- **Inconsistent document sourcing** — Team members use different systems (Teams vs. CDMS Plus) for the same documents; some were unaware of where certain records live. Flagged during the session as a place to standardize.
- **PR quality issues** — PRs sometimes arrive with errors that should have been caught upstream, triggering rework loops.
- **Competing priorities** — Buyers also handle funding requests, new subcontractor setup, and pricing negotiations, all competing for the same queue time (0–1 day queue between most steps).
- **Index Checklist is a distinct step** — Previously collapsed into the final tab work; now identified as its own step with specific inputs (total award value, CRN, PR #) and a dedicated template from Prism.
- **Tab 1 PR requirement in flux** — Per compliance, the PR document is technically no longer required in Tab 1, though it is reportedly still being requested for the index checklist. Flagged to confirm/reconcile.

---

## 6. Where the Time and Risk Go

The friction in these workflows clusters around two distinct but related patterns:

**SCA friction (SH Task Order issuance):** 69% of process steps depend on undocumented tribal knowledge; scattered information, informal confirmations, manual template population (Step 9 is the highest-value automation target), manual tracker upkeep, and stale funding data. Total touch time ~79–91 min per TO, but queue time (SOR TO confirmation, PR approvals, signed TO return) adds hours to days. Formalized as problems P-1 through P-8 in §10.

**TOM friction (sourcing through handoff):** Informal response tracking, manual SOR evaluation documents, no deadline visibility across solicitations, and an unstructured handoff that shifts discovery burden to the SCA. Formalized as problems P-9 through P-13 in §10.

**SCA friction (TT&E Task Order issuance):** Repeat data entry across tabs, inconsistent document retrieval practices, IDIQ pricing gaps that block progress, unstructured email filing, and PR quality issues from upstream. Formalized as problems P-14 through P-20 in §10.

All three sets of problems share root causes — manual document assembly, email-based coordination, and no single system of engagement. The difference is that SCA pain is primarily *assembly* (fill, format, convert, check), while TOM pain is primarily *coordination* (track, follow up, verify prerequisites, hand off). The TT&E workflow confirms that the assembly pattern is consistent across task-order types, making a single tool approach viable.

---

## 7. Process Ladder — SH Task Order

The table below maps the SH Task Order workflow to time categories and identifies tribal knowledge and automation opportunities. Data sourced from the *FMS Shipping Hub TO Process Baseline* spreadsheet.

> **Important assumption:** Touch-time and queue-time values are planning-level estimates based on the described process narrative, not measured data. These should be validated with actual time-tracking data before being used to prioritize automation investment.

| # | Step | Touch time | Queue time | Tribal Knowledge? | Automation / AI Opportunity |
|---|---|---|---|---|---|
| 1 | PWS link received — count SOR shipments | 10–15 min | Varies (PR approval cycle) | **Y** — Where in the PWS to find SOR shipment details and how to interpret them is learned through experience; no documented job aid exists | Teams bot / automated parser could flag new PWS postings and auto-extract the SOR shipment count using NLP |
| 2 | Check SCA Master Tracker for SOR TO status | 2 min | — | **Y** — Tracker layout and how to cross-reference SOR numbers to PWS line items is institutional knowledge; not written down | Auto-updating SharePoint list or Power Automate flow with built-in lookup logic |
| 3 | Wait for SOR TO issuance confirmation | 0 min (passive) | Variable (hours to days) | **Y** — No formal SLA or escalation path; follow-up timing and method are learned by experience | Automated status alert (email/Teams trigger) fired on SOR TO issuance |
| 4 | Verify approved PRs per SOR shipment | 5 min | — | N | CP report/dashboard auto-matching PWS shipment lines to PR approval status |
| 5 | Decision: proceed / wait / partially fund | 5 min | Variable if waiting | **Y** — Criteria for when to wait vs. partially fund is a judgment call, not a documented policy or threshold | Documented decision rule codified as a workflow step to standardize across team |
| 6 | Process CP modification (if partially funded) | 10 min | Dependent on PR approval | N | Automated trigger on PR approval → pre-populate CP modification fields |
| 7 | Save PWS to desktop; begin file assembly | 5 min | — | N | Auto-save rule from Teams channel to designated folder structure |
| 8 | Convert PWS to PDF; note creation date | 1 min | — | **Y** — Rule "PWS creation date = memo document date" is not written down; new team members learn verbally | Script/macro auto-converts file and pulls date from PWS metadata |
| 9 | Fill yellow-highlighted fields in Tab 2/3/5 → PDF | 10–15 min | — | **Y** — Which fields must change per TO type, and whether source data comes from PWS, CP, or tracker, is learned on the job | ⭐ **HIGH-VALUE:** Mail-merge / AI-assisted form-filler pulling data from PWS/CP to auto-populate highlighted fields |
| 10 | Download Prime Award documents | 3–4 min | — | N | Auto-sync/download from Teams into POF or local staging folder |
| 11 | Process PR in Costpoint — create SH TO award | 3–4 min | — | **Y** — Which CP fields are required vs. optional specifically for SH Task Orders is not formally documented | CP field auto-population via integration or RPA using PR/PWS source data |
| 12 | CP assigns TO release number | 0 min | Immediate (system) | N | Already system-generated; no action needed |
| 13 | Complete award document & file index checklist | 10 min | — | **Y** — What counts as "complete" and checklist requirements are informally known rather than documented | ⭐ **HIGH-VALUE:** Template auto-fill using CP data + auto-generated checklist keyed to TO type |
| 14 | Issue award package to IPT via email | 3 min | — | N | Templated email with auto-attached documents triggered on award completion |
| 15 | Create POF folder — upload all docs | 10 min | Awaiting signed TO (days) | **Y** — POF folder-naming conventions and structure learned by example | Standardized folder-naming template/macro or auto-upload integration |
| 16 | Update SCA Master Tracker | 2 min | — | **Y** — Required fields and formatting conventions passed down informally | Auto-populate tracker from CP Task Order release event (system integration) |
| | **Totals** | **~79–91 min (~1.3–1.5 hrs)** | **Hours to days (Steps 3, 5, 6, 15)** | **11 of 16 steps (69%)** | |

### Summary

- **Total active touch time:** ~79–91 minutes per SH Task Order (substantially lower than the original 2.5–4.5 hr estimate)
- **Tribal knowledge dependency:** 11 of 16 steps (69%) rely on undocumented institutional knowledge
- **High-value automation candidates:** Steps 1, 2, 5, 9, 11, 13, 16 — with Steps 9 and 13 (template population) flagged as the highest-priority targets for the AI team
- **Most repetitive step:** Step 9 (template field fill) — most template-driven, manual step in the process

---

## 8. Process Ladder — TT&E Task Order

The table below maps the TT&E Task Order workflow steps to their time categories. Data sourced from the team working session and updated with the Value Stream Map (August 2026).

| # | Step | Touch time | Queue / Wait time | System(s) / Tool(s) | Notes |
|---|---|---|---|---|---|
| Upstream | TOM prepares PWS & Source Selection with SOR | TBD | TBD | SharePoint (Procurement folder) | Must be complete before PR is submitted to buyer |
| 1 | PR Notification / Trigger | N/A (notification only) | Goal: 3 business days; Actual: up to ~7 business days | Email; CostPoint APR report | New emphasis: 7-business-day turnaround from PR receipt to completion |
| 2 | Review PR against PWS & Source Selection | ~20–30 min (if complete) | Goal: 3 business days from receipt to first review; Actual: up to ~7 business days | CostPoint; SharePoint | If info missing/inconsistent → return to TOM (rework loop). One buyer estimated folder-creation + this review together at ~20 min. |
| 3 | Validate pricing against IDIQ price sheet | ~15 min (varies with # of NSNs) | 0 — done in parallel with PR review | Subcontract file / price sheet | Blocking: if part/rate not on IDIQ, must be added at IDIQ level first. 8 parts takes longer. |
| 4 | Create 10-tab award folder in POF | ~20 min | 1–2 days (other priorities reviewing queue in mass) | POF / SharePoint | Tab 1 populated with PR document. Note: PR technically no longer required per compliance, though reportedly still requested for index checklist — flagged to confirm. |
| 5 | Tab 2 — Source capability confirmation & memo | ~5–10 min | Quick if email on hand; longer if must be tracked down | Outlook / email | No standardized method for filing this correspondence. Subject lines are relatively standardized but contacts vary. Team noted interest in a more reliable repository. Red text in template may be obsolete. |
| 6 | Tab 3 — Manual data-entry memo | ~15–20 min | 0–1 day (if pulled away due to higher priority) | Word template (mostly pre-populated; header + highlighted fields are manual) | Estimate confirmed by team. May be updated once approval from Step 5 is confirmed. |
| 7 | Tab 4 — Pull GFP / award documentation | ~5–10 min | 0–1 day (if pulled away due to higher priority) | CDMS Plus; SharePoint Teams-channel award folder | Practices differ by person — some pull from CDMS Plus for most current version, others from Teams award folder. Flagged as a place to standardize. |
| 8 | Tab 5 — Price reasonableness memo & pricing table | ~20 min | 0–1 day (if pulled away due to higher priority) | Word/Excel template; Claude-assisted drafting (piloted) | **Only document requiring signature** (ink or electronic). Claude-assisted process cut ~15–20 min off this step for shipping-hub orders. |
| 9 | Final Tab — Populate source/TO-specific fields; convert TO & PWS to PDF | ~20 min | 0–1 day (if pulled away due to higher priority) | Word/Excel template; Prism | Much of this information repeats from source to source — strong candidate for standard input form/database. Team uses Tabs 1–5 + final tab (Tab 6 not populated). |
| 10 | Index Checklist — Complete and upload | ~5–10 min | 0–1 day (if pulled away due to higher priority) | POF / Excel | Inputs: total value of award (TO/PR), CRN (first 6 digits of account # on PR), PR #. Draft from Prism. |
| 11 | Upload complete file / Issue Task Order | ~20 min | 1–2 weeks (dependent on SOR responsiveness; not part of cycle-time metric) | POF; email | Subcontractor signs and returns executed TO via email. Last step once file is fully built. |
| | **Totals** | **~150–195 min (~2.5–3.25 hrs touch time)** | **Goal: 7 business days end-to-end** | | Team confirmed: ~8 TOs/day throughput ceiling |

> **Note:** Touch-time estimates updated from VSM data (August 2026). The 8 TOs/day throughput ceiling remains the confirmed practical limit for one buyer working without interruptions. Total touch-time is higher than the previously reported ~1–1.5 hrs because the VSM captured steps (Tab 4, Tab 5, Final Tab, Index Checklist, Issue TO) that were not individually timed during the initial session.

---

## 9. Process Metrics & Baseline — TT&E

These metrics were discussed and confirmed during the team working session:

| Metric | Value | Notes | Confirmed? |
|---|---|---|---|
| Total touch time per TO award (clean PR, no corrections) | ~2.5–3.25 hours (VSM); ~1–1.5 hours (team estimate) | VSM captures all steps individually; team estimate likely excludes some tabs. Discrepancy flagged for reconciliation. | ✓ VSM data; 🔲 Reconcile with team estimate |
| Manual throughput (one buyer, no interruptions) | ~8 TO awards / day | Practical ceiling when this is the only task | ✓ Yes |
| Time saved with Claude-assisted drafting (SH pilot) | ~15–20 min per order | Tested result: ~1 hr → ~45 min for shipping hub | ✓ Yes |
| Total PRs processed by team (2026, cumulative) | 261 PRs | Majority received/processed May–July 2026 | ✓ Yes |
| Team monthly goal | 125 PRs / month | Stated program goal | ✓ Yes |
| PR queue time before first review — goal | 3 business days | Target state | ✓ Yes |
| PR queue time before first review — actual | Up to ~7 business days | Volume is sporadic; PRs can arrive in batches | ✓ Yes |
| New PR turnaround emphasis (receipt to completion) | 7 business days | Newly stated program emphasis | ✓ Yes |
| Share of process time on document retrieval | ~50% (estimate) | Remaining ~50% is document generation/review | Estimate only |
| Does day-count metric include weekends? | TBD | Action item: confirm with Nathan Koziol, Program PM | 🔲 Open |

---

## 10. Identified Problems

Based on the current-state narrative, the following problems are identified. **Items marked 🔲 need Supply Chain validation or additional detail.**

### SCA workflow problems

| ID | Problem | Category | Step(s) affected | Frequency / severity |
|---|---|---|---|---|
| P-1 | SOR TO confirmation arrives informally (email/verbal) — easy to miss, no auditability. No formal SLA or escalation path exists. | Lag / handoff failure | 3 | 🔲 *How often is a confirmation missed or delayed?* |
| P-2 | PR approval status must be checked manually across Costpoint | Difficulty / rework | 4, 11 | 🔲 *Avg. number of PR checks per TO?* |
| P-3 | Yellow-highlighted fields filled by hand across Tab 2, Tab 3, and Tab 5 templates — source data comes from PWS, CP, or tracker (undocumented) | Error-prone manual effort | 9 | Every SH TO — ⭐ **highest-value automation target** |
| P-4 | Multiple format conversions (Word → PDF) done manually | Low-value effort | 8, 9 | Every SH TO |
| P-5 | Master Tracker updated as a separate manual step — required fields and formatting conventions passed down informally | Lag / error | 16 | 🔲 *How often does the tracker fall behind?* |
| P-6 | Partial-fund decision made without full visibility into PR pipeline — criteria are a judgment call with no documented policy or threshold | Difficulty / judgment under uncertainty | 5 | 🔲 *What % of TOs require modification later?* |
| P-7 | Information scattered across Teams, email, SharePoint, Costpoint, POF | Difficulty / delay | 1–16 | Every SH TO |
| P-8 | Process entry point is manual and channel-dependent — a missed Teams message delays the entire workflow | Lag / single point of failure | 1 | Every SH TO |
| P-8a | 69% of process steps (11 of 16) rely on undocumented tribal knowledge — onboarding and cross-training carry high risk | Knowledge concentration / fragility | 1–16 | Structural |
| P-8b | Award-document template fill and file-index checklist requirements are informally known rather than documented | Error-prone manual effort | 13 | Every SH TO — ⭐ **high-value automation target** |
| P-8c | POF folder-naming conventions and structure are learned by example — new team members at risk of non-compliance | Standardization gap | 15 | Every SH TO |

### TOM workflow problems

| ID | Problem | Category | Step(s) affected | Frequency / severity |
|---|---|---|---|---|
| P-9 | SOR response tracking is informal — TOM monitors email inbox with no deadline dashboard or centralized view of who has responded vs. who is overdue | Lag / missed follow-up | §2 steps 3–4 | Every sourcing action (multiple SORs per requirement) |
| P-10 | SOR capability matching done from memory / institutional knowledge — no reference database of which SORs hold positions for which parts | Difficulty / single-point-of-failure knowledge | §2 step 2 | Every sourcing action |
| P-11 | SOR selection document assembled manually — same template-fill pattern as SCA work, with evaluation rationale drafted from scratch | Error-prone manual effort | §2 step 5 | Every SOR selection |
| P-12 | TOM → SCA handoff is an informal email with no structured prerequisite verification — SCA must re-derive context and may discover missing prerequisites during work | Handoff failure / rework | §3 | Every SH TO |
| P-13 | PR creation and approval status tracked informally between TOM and Finance — TOM polls Costpoint or waits for email confirmation | Lag / delay | §2 steps 8–9 | 🔲 *Avg. PR approval time? How often does TOM need to follow up?* |

---

### TT&E workflow problems

| ID | Problem | Category | Step(s) affected | Frequency / severity |
|---|---|---|---|---|
| P-14 | Same data points (NSN, quantity, TO number, dates, pricing) entered repeatedly across multiple tabs/documents | Error-prone manual effort / waste | 3, 6, 8, 9 | Every TT&E TO |
| P-15 | Document retrieval consumes ~50% of total process time — pulling records from SharePoint, CDMS Plus, email | Low-value effort / delay | 5, 7, 8 | Every TT&E TO |
| P-16 | Inconsistent document sourcing — team members use different systems (Teams vs. CDMS Plus) for the same documents; some unaware of canonical locations | Difficulty / error | 7 | Ongoing — discovered during working session |
| P-17 | No standardized method for organizing/filing SOR capability-confirmation emails — described as "tribal knowledge" | Difficulty / single-point-of-failure knowledge | 5 | Every TT&E TO |
| P-18 | IDIQ pricing gaps block progress — if a part/rate is not yet on the contract, it must be added at the IDIQ level before the TO can proceed | Blocking dependency / delay | 4 | 🔲 *How often does this occur?* |
| P-19 | PR quality from program — PRs arrive with errors/issues that should have been caught upstream, triggering rework loops | Rework / delay | 2 | 🔲 *What % of PRs are returned? Reported as "more than it should be"* |
| P-20 | Tab 5 signature requirement creates a bottleneck — only document needing ink/electronic signature, with no digital workflow | Lag / manual process | 8 | Every TT&E TO |

---

## 11. Information Gaps

The following information must be collected from the Supply Chain team to validate the process understanding, establish baselines, and enable tool development.

### Process validation

- [x] ~~Validated touch time for each step in §7 (Process Ladder)~~ — Planning-level estimates captured in the SH TO Process Baseline (see §7); still need actual time-tracking validation
- [x] ~~Validated queue time (especially Steps 1, 4, 5, 10)~~ — Captured as "variable" / "hours to days" in baseline; actual measurements still needed
- [ ] Average end-to-end process time (PWS link → SH TO issued) — Touch time baselined at ~79–91 min; total elapsed time (including queue) not yet measured
- [ ] **Cycle-time reconstruction from system-of-record dates (pre-portal baseline for the portal proposal's Phase 1 dashboards)** — Export 2026 PRs from Costpoint with approval dates; match to POF folder/filing dates by Task Order number; compute PR-approved → TO-issued in business days (median, 90th percentile, share over 7 business days). Also recover PR-approved → first review where the tracker or email holds a date. A few hours for an SCA plus the developer; gives the 7-business-day goal its first actual measurement.
- [ ] PR return rate — from the same export, count PRs returned to the TOM for correction (P-19) as a share of PRs received, using Costpoint status history or tracker notes.
- [ ] Volume: How many SH Task Orders are processed per month?

### Problem quantification

- [ ] Frequency of missed/delayed SOR TO confirmations (P-1) — Baseline confirms "no formal SLA or escalation path" but frequency data still needed
- [ ] Average number of PR checks per Task Order (P-2)
- [ ] Frequency of tracker falling behind actual state (P-5)
- [ ] Percentage of TOs requiring later modification due to partial funding (P-6) — Baseline confirms decision is undocumented judgment call
- [ ] Current error rate in manually-filled template fields (P-3)
- [x] ~~Any additional upstream pain points not yet captured (P-8)~~ — Baseline identifies: missed Teams messages delaying workflow entry (Step 1), manual cross-referencing errors at high volume (Step 2), inconsistent practice risk across processors (Step 5)

### Sample artifacts

- [ ] 3–5 sample real PWS files and completed award packages — including examples of "good," "incomplete," and "problematic" inputs
- [ ] A completed, issued SH Task Order package (all documents as delivered to the Shipping Hub vendor) as a reference output
- [ ] Input variability: do PWS files always follow the same format/structure, or do they vary by country, SOR type, or other factors?

### Business rules & conventions

- [ ] Fallback data sources: when a required field is not present in the PWS, where does the SCA go to find it? (e.g., Master Tracker, Costpoint, email, ask the TOM) — Baseline confirms source data comes from PWS, CP, or tracker, but mapping per field not yet documented
- [ ] Validation and business rules applied during template fill: calculations, thresholds, date checks, formatting rules, funding-total cross-checks, or compliance checks — Baseline confirms "PWS creation date = memo document date" rule (undocumented)
- [ ] Country- or customer-specific path variations: different template sections, approval chains, funding rules, or additional documents required
- [ ] POF folder naming conventions, folder structure, and metadata requirements — Baseline confirms these are "learned by example rather than documented in a guide"
- [ ] Decision criteria for "wait vs. partially fund" (Step 5) — Baseline confirms this is undocumented; candidate for SOP standardization

### TOM workflow

- [ ] SOR selection document template (current version) and a completed example
- [ ] SOR capability/qualification data — which SORs hold positions for which parts/NSNs under the IDIQ (any format: spreadsheet, list, or verbal description)
- [ ] Sourcing email examples — what does a typical solicitation email to a SOR look like?
- [ ] TOM's handoff process — what information does the TOM typically include in the email to the SCA? What does the SCA need that's often missing?
- [ ] SOR response volume and timing — how many SORs are typically solicited per requirement? What's the actual response rate within the 5-day/15-day window?
- [ ] PR creation process — what information does the TOM provide to Finance, and how long does approval typically take?

---

### TT&E workflow

- [x] ~~Validated touch time for Steps 5, 7, 8, 9, 10 in §8 (not discussed in session)~~ — Updated from Value Stream Map (August 2026): Tab 2 ~5–10 min, Tab 4 ~5–10 min, Tab 5 ~20 min, Final Tab ~20 min, Index Checklist ~5–10 min, Issue TO ~20 min
- [ ] Frequency of IDIQ pricing gaps blocking progress (P-18)
- [ ] Percentage of PRs returned to TOM for correction (P-19)
- [ ] Clarification: does the 7-business-day turnaround metric count calendar days or business days? (Action item: Nathan Koziol, Program PM)
- [ ] Sample 10-tab award file (completed example) for template analysis
- [ ] Tab 4 document sourcing — canonical location decision (Teams vs. CDMS Plus)
- [ ] Tab 5 signature workflow — current routing and approval chain
- [ ] Which tabs are actually used vs. unused in practice (team noted "typically tabs 1–5 plus final tab")

---

## 12. Glossary

| Term | Definition |
|---|---|
| **APR Report** | CostPoint report used by buyers to identify new PRs assigned to them |
| **Catena** | The system FMS countries use to submit repair requirements |
| **CDMS Plus** | Contract Data Management System — stores GFP and award documentation |
| **Costpoint** | Deltek Costpoint — the enterprise ERP system used for procurement, PRs, and financial tracking |
| **FMS** | Foreign Military Sales — the US government program through which allied nations procure defense equipment and services |
| **GFP** | Government-Furnished Property — government-owned property provided to a contractor for contract performance |
| **IDIQ** | Indefinite Delivery/Indefinite Quantity — the umbrella contract under which Task Orders are issued |
| **IPT** | Integrated Product Team — here refers to the Shipping Hub vendor receiving the award package |
| **Master Tracker** | The SCA's Excel spreadsheet tracking all in-flight and completed SH Task Orders |
| **NSN** | National Stock Number — the standard part identifier used to match parts to qualified SORs |
| **POF** | Procurement Official File — the official file of record for each procurement action (10-tab structure for TT&E) |
| **PR** | Purchase Requisition — the funding authorization in Costpoint |
| **PWS** | Performance Work Statement — the scope document that defines what work a Task Order covers |
| **R&R** | Remove & Replace / Repair & Return — the repair execution phase |
| **SCA** | Subcontract Administrator — issues Task Orders (SH and TT&E) to subcontractors |
| **SH** | Shipping Hub — subcontractor that handles logistics/shipment of parts between FMS customer and SOR |
| **SOR** | Source of Repair — qualified vendor that performs repair work under an IDIQ contract |
| **TO** | Task Order — a specific work authorization issued under an IDIQ contract |
| **TOM** | Task Order Manager — manages upstream sourcing, selection, and funding; hands off to SCA for issuance |
| **TT&E** | Test, Teardown & Evaluation — the initial assessment phase for a repair requirement |
| **VSM** | Value Stream Map — visualization of the end-to-end flow identifying value-add vs. waste |

---

*This document captures the process as currently understood. Items marked 🔲 are unvalidated estimates. Update this document as discovery sessions with the Supply Chain team fill in gaps.*
