**LEIDOS PROPRIETARY**

# Procurement Operations Portal — Design Notes

*Engineering background for the [portal proposal](pop-proposal.md). Nothing here is needed to make the funding decision; it is for the developer, IT reviewers, and anyone who later maintains the portal. Decision material is in the [proposal](pop-proposal.md), the [brief](pop-brief.md), and the [appendices](pop-proposal-appendices.md).*

---

## 1. MCP server architecture

### What MCP is

The **Model Context Protocol (MCP)** is an open standard that defines how AI tools connect to data sources. An MCP server is a lightweight service exposing structured operations (read, query, write) over a system's API in a way any MCP-compatible client can consume.

**MCP is vendor-agnostic.** An MCP server built for Costpoint works with any MCP-compatible client — Claude, or any tool implementing the open protocol. If the organization changes AI providers, the MCP servers still work.

### Why MCP servers are a standalone deliverable

1. **Immediate conversational access.** Once live, any authorized user can query that system in natural language — without the portal, without Doc Builder. "What's the PR status for TO-2847?" works directly.
2. **Usable from any AI surface.** Claude web, Claude Desktop, Claude Code, the API, or any MCP-compatible tool.
3. **Vendor-agnostic investment.** Open standard; not Claude-specific.
4. **Composable across use cases.** A Costpoint MCP server serves procurement, finance reporting, audit — any workflow needing funding data.
5. **Incremental and low-risk.** Each server built, tested, and deployed independently.

### MCP servers by data source

| MCP Server | What it exposes | Underlying API | Procurement use |
|---|---|---|---|
| `sharepoint-fms` | Search/download documents, list folders | Microsoft Graph API | PWS ingestion; Prime Award retrieval |
| `costpoint-pr` | PR approval status, TO details, award posting | Costpoint web services | PR readiness; TO posting |
| `pof` | Create folders, upload files, query status | POF API / file transfer | Automated filing of packages |
| `outlook-procurement` | Search/read emails, detect responses, send | Microsoft Graph API | SOR response tracking; IPT delivery |
| `sor-reference` | SOR qualifications by NSN/part | Static data (versioned) | SOR capability matching |
| `catena` | Repair requirements, status | Catena API (if available) | Seed TOM sourcing view (later) |

### What the portal adds on top

| Portal layer | What it does | Why it's not in the MCP |
|---|---|---|
| Event listeners (webhooks) | Detect new PWS links, SOR TO issuance, PR approvals in real time | Push-based; MCPs are request-response |
| Dependency engine | Release work to queue only when all prerequisites confirmed | Business logic specific to this workflow |
| Shared work queue | Multi-user task assignment and tracking | Application UX, not data access |
| Scheduled polling | Periodically check Costpoint for changes | Orchestration timing |

### Investment model

| What you build | What it gives you | Locked to a vendor? | Locked to this project? |
|---|---|---|---|
| MCP server for a data source | AI-accessible data — any client, any workflow | **No** | **No** |
| Portal orchestration layer | Automated procurement workflow | No | Yes |

---

---

## 2. Development approach

The portal is developed by a single developer using AI-assisted development (Claude Code), which has compressed delivery on this project by roughly 3–5× for REST APIs, React UI, database schemas, and integration code. The figure is the developer's observation on this codebase, not a benchmark.

- **Rapid iteration:** Full-stack features in days rather than weeks.
- **Maintainability:** Fully documented, version-controlled, automated tests. Any developer with Claude Code can onboard.
- **No licensing cost:** Entire stack is open-source (React, Node.js, PostgreSQL, Redis).
- **No platform lock-in:** All logic in code under version control.

---

---

## 3. Design principles

These principles govern every design decision in the tool and portal:

1. **Prove value before investing.** Deliver highest-impact improvements first on existing infrastructure. Use measured results to justify further investment.
2. **One front door.** A single tool (growing into a portal) replaces working in Teams, email, spreadsheets, and Costpoint separately.
3. **Systems of record stay put.** The portal integrates; it does not replace Costpoint, POF, or SharePoint. Protects compliance.
4. **AI is a feature, not an app.** AI is embedded inside the tool — the user never leaves to "go use AI."
5. **Eliminate, then accelerate.** First remove work that should not exist; speed follows.
6. **The tracker is a by-product.** Status updates automatically as work is done.
7. **Configure, don't code.** New document types are added by schema + template — never by writing application code. This keeps the platform extensible without developer bottlenecks.

### Capability evolution

| Capability | Today | Portal |
|---|---|---|
| Document set generation (TT&E, STR, Repair Mod, TT&E with Mod, SH) | Upload sources to completed package in one guided flow | Same — carried forward |
| AI extraction + field drafting | Full (engine powering the workflow) | Same — carried forward |
| Validation | Field and cross-field rules, AI discrepancy review of uploads | Same, plus the package cross-checked at handoff (Phase 1) and values pulled from systems of record (Phase 2b) |
| Embedded AI assistant | Available throughout workflow (drafting, checks, Q&A) | Same — carried forward |
| Tracker output | Updated by hand | Generated from workflow actions; shared, real-time (Phase 1) |
| Prerequisites & dependencies | Confirmed by email, Teams, and Costpoint; nothing in the tool | Confirmed on a checklist and released to the queue when met (Phase 1); confirmed by Costpoint events (Phase 2b) |
| Shared state (queue, handoff, comments, history) | None — each browser holds its own sessions | Core of the portal (Phase 1) |
| AI key custody and audit log | Keys in each browser; no log | Portal backend (Phase 1) |
| Source-document intake | Upload; SharePoint search | Shared per Task Order (Phase 1); pulled from SharePoint and Outlook (Phase 2a) |
| Framework extensibility | Proven (20 schemas across six sets, zero code changes) | Same, plus AI-generated schemas and a shared template catalogue (Phase 2a) |

---

---

## 4. Extensibility architecture

### How a document type is defined

Every document type in Doc Builder is fully specified by two artifacts:

1. **A plain-text schema file** — defines:
   - Interview sections and fields (questions the user answers)
   - Field types (text, date, number, dropdown, free-text narrative, table)
   - Validation rules (required fields, cross-field consistency checks)
   - AI extraction hints (how to find each data point in source documents)
   - Template mapping (which placeholder tag maps to which interview answer)

2. **A Word template (.docx)** — the output format:
   - Uses `{{PLACEHOLDER}}` tags where dynamic content appears
   - Retains all existing formatting, headers, footers, logos, classification markings
   - Is the same template the team already uses today, with tags added

### What happens at runtime

```
Upload source document → AI extracts fields per schema → User reviews/edits →
Generate .docx from Word template with answers substituted
```

The application engine is generic. It reads whichever schema is selected, presents the corresponding interview, runs extraction against that schema's field definitions, and generates output from that schema's template. Adding a new document type requires zero changes to this engine.

Twenty FMS schemas are configured today, grouped into six document sets (TT&E, Straight to Repair, Repair, TT&E with Modification, Shipping Hub, PWS) plus standalone documents such as the Funding Request Summary and the source-document consistency review. Each was added by the process below.

### Adding a new document type today

**Developer path** (built-in template, available to everyone):

| Step | Who | Time |
|---|---|---|
| 1. Prepare Word template with `{{TAGS}}` | Template owner | ~30 minutes |
| 2. Generate schema from template using AI agent | Developer | ~1 hour |
| 3. Validate and register in the system | Developer | ~15 minutes |
| 4. Available to users | Automatic | Immediate |

Total: **~2 hours** to add a fully functional new document type with AI extraction, guided interview, validation, and Word output generation.

An in-app template upload and schema editor shipped in October 2026 as the first step toward team-maintained templates; today it is a developer and power-user tool.

### Remaining template-authoring work (Phase 2a of this proposal)

AI-generated schemas from a tagged Word file, turning a finished document into a template in the browser, revising a template without losing its schema, and a shared catalogue, so that a template owner with no technical background can add or revise a document without a developer.

### What this means for scaling

| Scaling dimension | How it works |
|---|---|
| New document types | Schema + template; no code changes |
| New teams | Role-based access; schemas scoped by team or program |
| New workflows | Schemas grouped into workflow families; each family shares validation and tracking |
| New source documents | AI extraction hints in schema tell the engine where to look |
| Template updates | Replace the .docx file; schema unchanged |

The platform investment (hosting, AI engine, validation, integrations) is made once. Each additional document type is incremental configuration — not new development.

---

*Leidos Proprietary — not to be reproduced, disclosed, or exported without written approval of Leidos.*
