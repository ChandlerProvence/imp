# Doc Builder — Tutorial Outline

A presenter's outline for a **35–40 minute** walkthrough of Doc Builder for new users. It opens with the fast path: one document, drop in the source files, press Send, download. The audience sees the whole value in five minutes before meeting any controls. The rest of the session revisits the same flow with every option explained. The demo is AI-first: attach source documents, let the assistant propose values, then adjust in the interview wizard. Manual data entry is shown only as the adjustment step, not as a primary workflow.

> **Timing reality check:** the first live delivery (ABADS MD team, Oct 2026) ran the full hour — ~45 min of walkthrough plus Q&A, with live AI waits and audience questions arriving mid-demo. Book 60 minutes and treat the 35–40 min figure as the content budget, not the meeting length. See Appendix A.

Audience assumptions: FMS specialists / SCAs who will use the app daily, and optionally program-management staff producing LCSPs. Template and schema changes are handled by the development team, but users should leave understanding roughly what a change involves so they can make good requests. For a program-management audience, Part 5 (LCSP) is the payoff — do not skip it; trim Part 4 instead.

Related docs: [README.md](../../README.md) for feature reference, [docs/help/](../help/) for the in-app user help pages (also reachable via **View → Documentation**), [RUNBOOK.md](../RUNBOOK.md) for troubleshooting.

---

## 0. Presenter Prep (do before the session)

Things that go wrong live if skipped.

- [ ] **Working API key** on the Proprietary (IL2) endpoint, tested via **Settings → Test**, and **saved before the session starts** — Part 1 runs on it without showing Settings. Optionally a CUI (IL5) key if you plan to show CUI mode.
- [ ] **Fast-path input documents** for Part 1 in their own folder: a PWS and a vendor proposal for the TT&E Task Order Award. Two or three files, all small and all clean — nothing over 10k characters, no staged contradiction, and nothing that trips the CUI scanner. Part 1 should run without any detours. Do a dry run beforehand and note how long the AI takes.
- [ ] **Demo input documents** staged in a folder for the TT&E set: a PWS, a vendor proposal/quote (ideally one `.pdf`, one `.docx`, one `.xlsx`), and one small `.txt` to add mid-conversation. Include one document **>10k characters** so the embedding path is exercised, and a pair with a deliberate contradiction (e.g. differing period-of-performance dates) to trigger Conflict detection.
- [ ] *(If including Part 5 — LCSP)* **LCSP demo input documents** in a separate folder: a Technical Volume and a SoW or PWS, with a deliberate contradiction (e.g. differing maintenance-level assumptions). Optionally an RFP and a recent Monthly Status Report. At least one document should be >10k characters.
- [ ] **Fresh browser profile or cleared IndexedDB** so the Home page starts clean.
- [ ] **A saved progress `.json`** from a prior run, in case live AI is slow or down — lets you skip ahead via **File → Load Progress…**.
- [ ] *(If including Part 5 — LCSP)* **A pre-drafted LCSP saved progress `.json`.** A full-document LCSP pass takes several minutes and the first live run deliberately skipped it. Draft one section live and load the finished version to show the rest.
- [ ] **A non-CUI document that trips the CUI scanner** (keyword hits or AI flag) so the three-way dialog fires on cue. Know in advance that it is not CUI so you can say so confidently.
- [ ] **Model Gateway key page** open in a second tab (or a screenshot) — walking through "create key → copy to password manager → paste → Test → Save" live was well received.
- [ ] **Put the API-key setup link in the meeting invite and paste it into chat** at the start. Attendees asked for it afterwards.
- [ ] **Word installed** on the demo machine to open the generated `.docx` and show the ToC refresh step.
- [ ] Confirm the production URL loads: `https://ams-oot.pages.lsde.leidos.com/doc-builder/`.
- [ ] Open one `schema.json` and its `.docx` template side by side in a second window for Part 7 (e.g. `src/schemas/fms-tte-award/`, or `src/schemas/lcsp/` if including Part 5).

---

## 1. The Fast Path — One Document, Upload, Send (5 min)

**Goal:** within the first five minutes the audience sees a finished Word document produced from their kind of source files with almost no clicks. Everything after this is refinement. Showing it first means nobody is overwhelmed by the controls before they have seen what the tool does.

Open with one sentence, no slides: *"I'm going to make a TT&E task order award from a PWS and a proposal. Watch how few clicks it takes, and save your questions — we'll go back over every button afterwards."*

1. **Home → TT&E → FMS TT&E – Task Order Award.** Expand the TT&E set and click the single document, **not** "Generate full set". One document keeps the demo simple.
2. **Open the AI panel** (✨) → **+**. Drag the fast-path files onto the **drop zone in the center column**. Don't assign them to the Recommended uploads slots on the left, and don't explain the picker's columns yet. The AI reads every attached file no matter where it was dropped.
3. Wait for the status chips to show ready (a few seconds for small files) → **Attach**.
4. **Leave the text box empty and press Send.** With nothing typed, the app sends its default instruction: fill every field from the attached documents.

   > 🕐 **While the AI works** (~30–60 s): keep it short. *"It's reading the PWS and the proposal and filling in every blank in the Word template: dates, contract numbers, prices, the narrative paragraphs. It doesn't invent the structure. The template is fixed, and it only fills in the values."* Don't open the tabs or explain the status line yet.

5. When it finishes, the **Proposed Changes** tab lists the proposals, all of them already selected. Click **Apply**. The form fills in.
6. **View → Go to Generate** → **Download as Word (.docx)** → open it in Word.

Close the section by saying: *"That's the whole workflow: pick the document, drop in your files, Send, Apply, download. Most days that's all you'll do. The next half hour covers the controls for when you want more: reviewing what the AI did, fixing individual answers, and redrafting one section."*

Don't stop for setup, endpoints, effort tiers, scope, confidence scores, or the Review page here. Each of these is covered later. If someone asks, say *"good question, we'll get to it in a few minutes"* and write it down.

> **If the AI is slow or fails live:** load the saved progress `.json` (**File → Load Progress…**), then go straight to step 6. The point of this part is the finished document, not the wait.

---

## 2. Orientation (3 min)

**Goal:** audience understands what the tool is and is not.

- One-liner, pointing back at what they just saw: *attach your source documents, the AI fills in a controlled Word template, you adjust and download.*
- What it is **not**: not a document management system, not a chatbot that writes freeform — every output is a fixed template that the dev team controls.
- **There is no backend.** It is a static GitLab Pages site that runs in your browser, on the Leidos network only. Consequences to state up front:
  - Your data is per-browser-profile, per-machine. Nobody else can see your work — not teammates, not the dev team. (The dev team also cannot see who is using the app or how much.)
  - The only thing leaving the browser is AI traffic to the LiteLLM proxy.
  - **Clearing your browser cache or cookies deletes everything you have entered** unless you have backed up. Say this twice — once here, once in Part 6. It was the single most repeated warning in the first session.
  - Collaboration happens in Word: download the `.docx` and circulate it. A hosted version with shared state is possible if resources appear, but that is not today's deployment.
- Show the Home page: role picker → document type cards grouped by category → **"Generate full set"** buttons. Role selection only filters what you see (e.g. **Program Management** shows just the LCSP); it is not access control.
- *Optional, 1 min:* jump to Generate on an existing session to show the inline preview and explain what a template is: *"We take the Word document, replace each program-specific value with `{{DOUBLE_BRACKETS}}`, and the app fills those in with what you type or what the AI drafts."* Doing this early made Part 7 land faster.

---

## 3. One-Time Setup (4 min)

**Goal:** every attendee can leave with a working configuration.

1. **Edit → Settings → Your Information** — name, title, phone, email. Preparer/SCS fields pre-populate from this on every new document. (The Edit menu also has **Clear All Answers** — a reset button. Mention it; don't demo it.)
2. **AI Endpoint Configuration**
   - Two endpoints: Proprietary (IL2) for unclassified work, CUI (IL5) for controlled information.
   - Both endpoints are the Leidos Model Gateway (LiteLLM). The **endpoint badge** in the AI panel header shows which one is active; clicking it opens Settings.
   - Paste key → **Test** → green "Connected" → **Save**.
   - Pain point: obtaining a key is a separate attestation process — see [help/api-key-setup.md](../help/api-key-setup.md), also reachable in-app via **View → Help**. Hand out the link; if time allows, show the Model Gateway "create key" page so people recognize it (create → copy to a password manager now, it is the only chance → paste → Test → Save).
   - Pain point: a 401 mid-session means the key expired or was revoked, not a bug. **Settings → Test** is the first thing to check when the AI stops responding.
3. **Model selection** (same Settings page, per endpoint): dropdowns for the Sonnet (Fast/Balanced) and Opus (Thorough) models, plus the CUI-scan model (the cheapest general-purpose model on the gateway) and the embedding model. Defaults are pinned to a known model so results do not shift under anyone mid-evaluation; when a newer model exists the dropdown shows a **"Newer model available"** hint. Recommend trying the newer one once people are comfortable. The list comes from the gateway; GPT and Grok entries appear but are untested.
4. **AskSage / SharePoint section**: tell people to leave it blank. See Part 4a.
5. Where keys live: localStorage, sent only to the chosen proxy. Clearing browser data clears keys *and* sessions — re-entering keys is the most annoying thing to lose.

---

## 4. The Core Workflow — Document Set with AI Drafting (15 min)

Bridge from Part 1: *"Now let's do it again, this time for the full set and with every control explained."* Start a new session via **"Generate full set"** on TT&E. Use the larger demo document folder from Part 0.

### 4a. Attach sources (4 min)

1. **Merged interview**: the four TT&E documents share one form — preparer, contract number, memo date, etc. are asked once and flow into all of them. You can generate the full set or pick individual documents. Don't type anything yet — go straight to the AI panel.
2. **Open the AI panel** (✨ button in the header). Point out the three elements in its header: the **endpoint badge** (colored pill — Proprietary or CUI), the **conversation dropdown** (for starting or switching chat sessions), and the **kebab menu** (⋮ — Export Chat for Troubleshooting, covered in Part 6).
3. **Attach documents**: click the **+** button in the chat input toolbar to open the **Document Picker**. Walk through its three columns:
   - **Left column**: **Recommended uploads** — slots defined by the template (e.g. "PWS", "Vendor Proposal"). These tell the user exactly what to go find before starting. Assign a document to a slot with the **dropdown on its row**; the slot shows a green check once filled. **None are required** — the AI will work with whatever is attached — but quality tracks the inputs (see Appendix C, Q1).
   - Some slots come **pre-filled with a bundled reference document** (e.g. the TT&E contact sheet) that ships with the app, so nobody has to upload it. Mention that this is an option for any document type that has a standard reference.
   - **Center column**: your document library — every file ever uploaded, with search and a Recent / All toggle, plus a **drop zone**. The banner says **"Uploading in Proprietary mode"** or **"Uploading in CUI mode"** — a reminder of where the files are going. Drop the proposal and spreadsheet here.
   - **Right column**: **SharePoint / OneDrive** search. It works in local dev but is blocked by permissions in the GitLab Pages deployment. Say so plainly and move on; a Leidos SharePoint MCP is expected to replace this integration.
   - Status chips: parsing → embedding (for the large doc) → ready. Pain point: **Attach is disabled until every document is ready**; large PDFs take longest.
   - **CUI scan** runs automatically on IL2 only (there is nothing to scan for in CUI mode). Two passes: a keyword/regex check, then an AI check that can flag unmarked CUI. Flagged documents get a summary of why. On **Attach**, a second warning lists documents with medium/high likelihood and the reasons, with a three-way choice (Switch to CUI mode / Not CUI / Cancel). Switching flips the endpoint badge and re-embeds under the CUI endpoint. See [help/attachments.md](../help/attachments.md).

   > 🕐 **While documents process** (~15–30 s for the large doc): explain what's happening. *"The app is reading your files locally — Word documents, PDFs, spreadsheets — and converting them to text. For large documents, it also breaks the text into chunks and creates embeddings so the AI can find the most relevant passages later. Nothing leaves your browser during this step except the embedding request."* If the CUI scan fires, use it as a live example.

   - Click **Attach** to close the picker. Each attached document appears as a **pill** above the chat input.
   - Point out the amber/blue endpoint banner in the AI panel header — it tells you where your uploads are going.
4. **Chat input toolbar**: below the text area, point out the controls the audience will use daily:
   - **Effort tier** (Fast / Balanced / Thorough): leave on Balanced for the demo. The tooltip spells out the mapping — Thorough uses the Opus model, Balanced is Sonnet at medium effort, Fast is Sonnet at low effort. Thorough is for when Balanced answers feel thin; it just takes longer. See [help/ai-controls.md](../help/ai-controls.md).
   - **Scope selector** ("Entire Document" / current section / specific field): controls what the AI is allowed to change. The same scope can be set from the wizard — the **purple** button in the header selects the whole document, the **green** one the current section, and the ✨ next to a field selects that field; the toolbar selector updates to match. Leave on "Entire Document" for the initial fill; scoped mode is shown in step 9.
   - **Token indicator** (radial ring): shows how much of the AI's context window is used. Turns amber when sources are large — a signal to trim or use Balanced instead of Thorough.

### 4b. Accept proposals (4 min)

5. Send the default prompt ("fill what you can from these documents").

   > 🕐 **While the AI streams** (~30–90 s): this is the longest wait and the best time to explain what's happening under the hood. Cover as many of these as the wait allows:
   > - *"The AI is reading every source you attached and trying to fill every field in the template — dates, names, dollar amounts, and multi-paragraph narrative sections. Each proposal comes with a confidence score."*
   > - *"The template controls the structure. The AI can't add sections, skip sections, or change headings — it fills the blanks the dev team defined. That's what makes the output consistent across different users."*
   > - *"When your sources disagree — say the PWS says December and the proposal says January — the model flags it as a conflict rather than guessing which one is right. You'll see those in the Alerts tab."*
   > - *"If the model can't find something in your sources, it may ask you a question instead of guessing. That shows up as an inline card you answer right here in the chat."*
   > - If the stream is still going, point out the **Proposed Changes tab** badge incrementing in real time — each tick is another field filled.
   > - The status line under the response shows what the model is doing right now — usually *searching the attached documents for a keyword* or *generating proposed changes*.
   > - If the wait runs long, this is a good moment to open **Settings** and cover Part 3 step 3 (model selection) and the backup section — the first session did exactly this and it filled the gap well.

   - **Read the response, not just the proposals.** It explains which documents it used and how it reached each value. If that is not enough, ask it a follow-up — *"where did you get the case number?"* — before applying.
   - The response ends with a summary of what it filled and what it could not, and a **View N proposed changes →** link into the **Proposed Changes tab**, which lists every field with its value and confidence.
   - **Triage by confidence**: skip anything at 0%, look hard at anything under ~70%, accept the rest. Reject one to show it is not forced. *"This is the first level of review — one more check before the AI touches the form."*
   - **Alerts tab**: the AI raises an alert when it tried to draft a field but something is wrong — information is missing from the sources, the sources contradict each other, or it had to make an assumption it is not sure about and wants your call. If the staged contradiction was detected, show the observation card and the badge linking from the proposal to the conflict.
   - If the model calls **`ask_user`**, answer the inline question card.
6. **Apply** → the interview reopens with most sections ◐ or ✓ in the left outline. Each AI-filled field carries a **confidence badge** next to its label, so you can always tell what you typed from what the AI wrote and how sure it was.

### 4c. Adjust in the wizard (4 min)

This is where users will spend most of their time. Frame it as **the second level of review**: walk every step, confirm what the AI filled, fix what it missed.

7. **Three-panel layout**: section outline (left, ○ ◐ ✓ status), fields (center), AI panel (right). Click any section in the outline to jump to it. See [help/interview-nav.md](../help/interview-nav.md).
8. Walk through one section and fix a value by hand — a date, an enum, a table row. Point out:
   - Required asterisks; red/yellow highlights on the Review page for unfilled required/optional fields.
   - **Editable tables**: add and delete rows. Where a template has totals, **row and column arithmetic** is computed for you and checked on the Review page.
   - **Linked fields** (greyed out) update automatically when their source changes — you cannot and need not edit them.
   - **Conditional sections** appear or disappear based on a gate field (e.g. a change-type multiselect reveals a Funding Change section).
   - **Hints toggle** (💡 in the header): guidance text appears under each field. *"These hints are for you, but they are also what the AI just read when it drafted the field. If we want the AI to write a section differently — different emphasis, bullets vs. paragraphs, a different tone — this is where we tune it, and every future document picks up the change."* This is the best answer to "how do we make it write the way we want", so don't skip it. **Destinations** (📄) shows which Word placeholder each field feeds; call it a developer-oriented toggle and turn it off. Leave Hints on.
9. **Scoped redraft** — this is the feature users reach for daily when incorporating review comments. Two ways to scope:
   - Click the ✨ next to a freetext field — this sets the scope to that field automatically.
   - Or use the **scope dropdown** in the chat input toolbar to select a section or field by name.

   Give a realistic prompt, e.g. on a delivery schedule field: *"Expand on the delivery milestones and incorporate the dates from the PWS."* The AI rewrites only that field. See [help/focus-and-scope.md](../help/focus-and-scope.md).

   > 🕐 **While it redrafts** (~10–20 s): *"Notice the scope badge says 'Field' — the model can still see the rest of the document for context, but it's only allowed to change this one field. That's how you incorporate a review comment on one section without the AI rewriting everything else."*

10. **Add a document mid-conversation**: attach the `.txt`; the model proposes further changes without being asked.

### 4d. Review and download (3 min)

Present this as **four levels of review** — the framing that answered "is the proposals list the final checklist?" in the first session:

| Level | Where | What you catch |
|-------|-------|----------------|
| 1 | Proposed Changes tab | Low-confidence or wrong proposals, before they touch the form |
| 2 | Wizard steps + Review page | Missing required fields, type errors, failed numeric checks |
| 3 | Generate page preview | Plain-text read of the assembled document — does it make sense end to end? |
| 4 | Downloaded Word document | Other people's review. Circulate it like any Word file: comments, track changes, no surprises |

11. **View → Go to Review**: unfilled required fields are flagged in red and block approval; optional unfilled fields show in yellow but do not. Type checks and numeric dependency checks (e.g. totals) surface here too. Approve to proceed.
12. **View → Go to Generate**: expand an accordion row to show the inline preview of the rendered Word document. Click **Review with AI** — this sends the rendered output back to the model for a final quality check (leftover placeholders, internal inconsistencies, totals that don't add up). Findings land in the **Alerts tab** of the AI panel. This is the last gate before download.

    > 🕐 **While the review runs** (~20–40 s): *"The AI is reading the fully assembled document — the same thing you'll get in the Word file — and looking for problems: placeholders that didn't fill, dates that contradict each other, numbers that don't add up across sections. Think of it as a second pair of eyes before you send it out."* If findings appear, open the Alerts tab to show them.

13. **Download All (.zip)**. Open the TT&E award in Word. *"From here it is a normal Word document. This is where you bring in other reviewers, because nobody can see inside your browser."*
14. Pain point: **Table of Contents / List of Tables / List of Figures show stale or no page numbers until updated.** The app marks them as real Word ToC fields but does not compute page numbers. The download banner says so: Ctrl+A → F9 in Word, or right-click the table → **Update Field → Update entire table**. Demonstrate it — the audience reaction to seeing the numbers populate was the high point of the first session. Repeat after any manual edits that shift pages.

---

## 5. LCSP Deep Dive — *skip if the audience does not produce LCSPs* (5 min)

**Goal:** show how the same workflow handles a large, narrative-heavy standalone document — the Life Cycle Sustainment Plan. Everything in Part 4 still applies; this section highlights what is different.

> **Presenter note:** If the audience is entirely FMS, skip to Part 6. If it is mixed, run this part and call out the contrasts with the TT&E demo they just saw. If it is entirely program-management, you can run this part *instead of* Part 4 — start a new LCSP session from the Home page and follow the same attach → propose → adjust → review → download arc, substituting the notes below.

### 5a. Starting a single document (1 min)

1. **Role picker**: switch to **Program Management** — the LCSP card appears. Point out that role selection controls which documents are visible; an LCSP user who leaves the role on FMS will not see their document.
2. **LCSP card → New**. Unlike the TT&E set, there is no "Generate full set" — this is a single-document session. The interview works the same way, just without cross-document field sharing. **Check the endpoint badge says CUI** before attaching anything — LCSP inputs usually are.
3. Open the AI panel (✨). The **Recommended uploads** card lists Technical Volume, SoW/PWS, RFP, and Monthly Status Reports — the documents an LCSP author actually has on their desk. The Technical Volume and the SoW/PWS are the two that matter; without the Tech Volume the draft will be poor. Attach both plus one or two Monthly Status Reports.

### 5b. AI drafting at scale (2 min)

The LCSP has **~50 freetext narrative fields** across 12 sections (some nested to §4.12.3). Without AI drafting it would take days to fill manually. This is where the tool pays for itself.

> **Recommend section-by-section, not one whole-document pass.** Set the scope to one section (the **green** header button), send, read the draft as it streams, give feedback, apply, move on. Reasons to say out loud: (a) the sections are big and a reviewer can only absorb one at a time; (b) feedback lands immediately on the section it concerns; (c) the current prompts are tuned to stay grounded in the attached documents, and on a whole-document pass the model will sometimes stop at sections that need interpretation rather than invent content. The grounding-vs-completeness balance is still being adjusted. Whole-document drafting works and is the hands-free path once people trust the output, but it is a several-minute wait.

4. **Scope to "Product Support Strategy"** (or another mid-size narrative section) and send the default prompt. For the rest of the sections, load the pre-drafted session from Part 0.

   > 🕐 **While the AI streams** (~60–120 s — the longest wait in the demo): this is a good time to talk about what makes the LCSP different from the TT&E documents they saw earlier. Cover as many as the wait allows:
   > - *"The TT&E documents are mostly short structured fields — contract numbers, dates, dollar amounts. The LCSP is almost entirely multi-paragraph narrative. The AI is writing dozens of prose sections right now, not just copying values."*
   > - *"Each section has guidance from the template author — the same hints you see when you toggle the 💡 button. The guidance tells the AI what to cover: for Supply Support, it's spares planning and provisioning; for Cybersecurity, it's vulnerability management and patching. That's how it knows what to write for each IPS element."*
   > - *"The model knows which source to trust for what. The SoW/PWS is authoritative for contractual requirements; the Technical Volume is authoritative for the proposed approach. When they conflict, the model flags it rather than picking a side."*
   > - Point out the **Proposed Changes tab** badge climbing — each tick is another section drafted.

5. **Expand the freetext proposal** (long values are collapsed — "click to expand") so the audience sees multi-paragraph prose, not just one-liners. Note it will skip Figure fields and say so; the AI does not draft figures.
6. **Tone tuning live**: if the draft came back as bullet points, type *"Don't use bullet points — write these as paragraphs"* and send. The redraft replaces the section. *"This is the per-document way to steer tone. If we want it this way every time, we put it in the field's hint (Part 4c step 8) and it applies to every future LCSP."*
7. **Markdown headings**: the draft may contain `#` lines. Explain that a single `#` becomes a Word heading one level below the section's own heading (`##` two levels), styled with real Word heading styles — so they feed the Table of Contents. Worth a sentence because it looks odd to anyone unfamiliar with Markdown.
8. If the staged contradiction (e.g. differing maintenance-level assumptions) was detected, show the **Alerts tab** — this is especially valuable for LCSPs where source documents routinely disagree on approach vs. requirements.
9. **Apply** and scroll the section outline — the ○ ◐ ✓ indicators show at a glance which of the 12+ sections still need attention. Load the pre-drafted session here to show the rest filled.

### 5c. Tables, images, acronyms, and scoped redraft (1 min)

10. **Tables**: open a risk summary or funding table (e.g. Table 4-8). Show adding a row, selecting an enum (Impact: Low / Medium / High / Critical), and deleting a row. The LCSP has ~17 structured tables.
11. **Images**: open a Figure field (e.g. Figure 2-1: Reference Design Concept). The user uploads a diagram and it is dropped, unformatted, at the tagged location in the Word document. For anything beyond that, position and size it in Word after download. The AI cannot create these — the user provides them.
12. **Acronyms** is deliberately the **last** section of the form. Draft it after everything else so the table reflects the acronyms actually used, rather than guessing up front.
13. **Scoped redraft with a realistic prompt**: click ✨ next to the **4.12.2 Supply Chain Risk Management** field and type something like: *"Add detail on counterfeit parts prevention and reference DFARS 252.246-7008."* This shows the AI touching only the targeted section — the feature that saves hours during review-comment incorporation.

### 5d. Approval block and living-document workflow (1 min)

14. **Plan Approvals** section: show the eight signature lines (PSM through CAE). *Leave these blank until the approval meeting — they are here so the generated Word document has the signature page ready.*
15. **Record of Changes** table in the Introduction: *The LCSP is a living document updated at each milestone. When you revise, add a row here. Save Progress captures the whole state so you can pick it up at the next review cycle.*
16. Frame the iteration loop: *Draft v1.0 from your Technical Volume → Save Progress → take the generated Word document to the PSM review → load the saved session → incorporate feedback via scoped redraft → Save Progress → repeat at MS B, then every five years per DoDI 5000.91.*

---

## 6. Saving Your Work and Recovering (4 min)

Cover these explicitly — they generate most support questions.

| Topic | What to show / say |
|-------|--------------------|
| **Resume** | Reload the page; the session, chat history, and attached documents come back. |
| **Save / Load Progress** | **File → Save Progress…** writes a `.json` snapshot of one session. **File → Load Progress…** restores it, even on another machine. Save before leaving for the day. Demo the round trip — save, then load — it takes 20 seconds and makes the point. |
| **Back Up All Data** | **File → Back Up or Restore All Data…** opens Settings → Your Data. This backs up *everything* — all sessions, chat history, uploaded documents, custom templates, settings, and API keys — into a single file. Use it before an IT re-image or profile reset, and remind people that **clearing cookies/cache wipes all of it**. The indicator in Settings turns red when a backup is stale. |
| **Navigation guard** | Starting a new document with unsaved answers prompts Cancel / Discard / Save Progress. |
| **Starting over** | **File → Clear Session** discards the current session and returns to the Home page. **Edit → Clear All Answers** resets all fields but keeps the session and chat history. Both confirm first if you have unsaved answers. |
| **Multi-tab lock** | Opening the same session in a second tab makes that tab read-only (yellow banner). |
| **AI chat sessions** | The **conversation dropdown** in the AI panel header lets you start a new chat or switch between previous ones. Starting a new chat does not lose the old one. |
| **AI unavailable** | A bad or expired key shows an error, but the wizard and document generation still work. Check **Settings → Test** first. |
| **Export Chat for Troubleshooting** | Kebab menu (⋮) in the AI panel header → JSON with the conversation and endpoint info (no field values). This is what to email the dev team when the AI misbehaves. Say what happens next: *"I feed that file to the coding assistant with 'here is the conversation, here is what went wrong', and it proposes the fix."* People are more willing to send exports when they know they are used. |
| **View menu** | **View → Help** has the API-key walkthrough (attestation form → create key → where to paste it → Test) and other how-tos; **View → Documentation** has the project docs including the development plan; **View → Contact & Feedback** is the support path. |

---

## 7. How Changes Get Made (3 min)

**Goal:** users can describe what they want changed and understand why it takes a developer.

- Every document type is **two files** owned by the dev team: a **Word template** with `{{PLACEHOLDER}}` tags where values go, and a **JSON schema** that defines the interview questions and maps each placeholder to a field. Show them side by side briefly.
- What a request looks like and what it touches:

  | Request | What changes |
  |---------|--------------|
  | "Reword this boilerplate paragraph" | Word template only |
  | "Add a new question / field" | Schema (new field) **and** template (new `{{TAG}}`) |
  | "Change the dropdown options" | Schema only |
  | "Make this section optional" | Schema (required flag or visibility rule) |
  | "Rename a label or the AI guidance for a field" | Schema only |
  | *(LCSP)* "Add a Figure placeholder for the maintenance org chart" | Schema (new `image` field) **and** template (new `{{TAG}}`) |
  | *(LCSP)* "Change the risk-impact dropdown from four levels to five" | Schema only (add an `options` entry) |

- Changes go through the normal release process: dev edits → automated template integrity tests → merge → the live site updates. Existing saved progress files still load; a warning lists any fields that moved.
- Best way to ask: name the document, the section, and paste the current vs desired wording. A screenshot of the field in the wizard helps.
- **What the dev team needs to add a new document type** (this question came up as "what are your information requirements and timeline?"): an example of the finished document, or better, a Word template where the program-specific values are already replaced with `{{PLACEHOLDERS}}`. From that the dev team generates the schema, adds hints, and tests. Adding a document type is template work, not app development — but it still takes funded developer time, so route the request through program leadership.
- **Custom templates**: users *can* upload their own schema + Word template pairs via **File → Manage Custom Templates**. Downloading an existing template gives a zip with the `.docx`, the schema JSON, an **AI editing guide** to hand to a chatbot, and a README — so a user can, for example, move a section to the end and re-upload. These are local to the user's browser until submitted for team use. Still in progress; mention it but don't demo it unless someone asks.

---

## 8. Wrap-Up (1 min)

- Recap: *set up once → start a set or single document → attach sources → accept proposals → adjust in the wizard → review → download → F9 in Word → Save Progress.*
- **Pre-empt "that's a lot of clicks."** The first session drew exactly that reaction, and that session had no fast-path opener. Point back to Part 1: the walkthrough shows every option, but day-to-day use is what they saw in the first five minutes, *attach → Send → Apply → download*. Once Settings is done it is close to hands-free. Say this before anyone has to ask.
- Three habits:
  1. **Settings → Test** when the AI stops responding.
  2. **Save Progress** before closing for the day.
  3. **Export Chat for Troubleshooting** when reporting AI problems.
- **Ask for a concrete next step**: two or three named people draft a real document with the tool before the next meeting and bring feedback. Offer to share the recording for teams building internal training material.
- Q&A. Feed recurring questions back into `docs/help/`, Appendix C, or this outline.

---

## Appendix A — Timing

| Part | Minutes | Skippable? |
|------|---------|------------|
| 1 Fast path | 5 | No — this is the opener |
| 2 Orientation | 3 | |
| 3 Setup | 4 | |
| 4 Core workflow (TT&E) | 15 | |
| 5 LCSP deep dive | 5 | Yes — skip if audience does not produce LCSPs |
| 6 Saving and recovery | 4 | |
| 7 How changes get made | 3 | |
| 8 Wrap-up | 1 | |
| **Total without Part 5** | **35** | |
| **Total with Part 5** | **40** | |
| Live AI waits + audience questions (observed) | **+15–25** | |

Plan a 60-minute slot. The first live run spent ~47 minutes on what are now Parts 2–7 (it had no fast-path opener) with questions arriving mid-demo, then ~13 minutes on wrap-up and next steps.

If running short: drop Part 5 first for an FMS audience (saves 5 min); for a program-management audience drop Part 4 steps 10 and 12 (mid-conversation attach, Review with AI) and run Part 5 in full. Never cut Part 1 or the ToC refresh (4d step 14) — it was the moment the audience saw the output as real.

## Appendix B — Known Rough Edges to Acknowledge if Asked

Drawn from the *Sustainment* list in [development-plan.md](development-plan.md) and from the first live session; state them honestly rather than being surprised by them.

- Model IDs are hardcoded; a proxy-side model retirement breaks all AI features until a redeploy.
- No in-app diagnostics/version display yet beyond the chat export.
- Validation is type-level only; no cross-field or min/max rules.
- Custom templates are local to the user's browser until submitted and promoted by the dev team.
- **SharePoint / OneDrive search** does not work in the GitLab Pages deployment (permissions). Works in local dev only; a Leidos SharePoint MCP is expected to supersede it.
- **Whole-document LCSP drafting can stop early.** Prompts were recently tightened to keep content grounded in the attached documents; the trade-off is that the model sometimes declines sections that require interpretation instead of drafting them. Section-by-section drafting avoids this. Tuning is ongoing.
- **The AI does not draft figures** and image placement is unformatted — finish figures in Word.
- **Table of Contents / lists of tables and figures** need a manual field update in Word after download.
- **No usage telemetry.** Because the app is static, the dev team cannot see who uses it or how often; feedback has to come from users.

## Appendix C — Questions from the First Live Session

Asked by the ABADS MD team (Oct 2026). Have these answers ready; several will recur.

| # | Question | Answer given |
|---|----------|--------------|
| 1 | *None of the recommended uploads are required — how accurate is the output if I skip them?* | Depends on the document and the slot. For the LCSP the Technical Volume and the SoW/PWS carry almost everything; without the Tech Volume the draft will be poor. Monthly Status Reports and the RFP are nice-to-have. The checklist exists to tell you what to go find. |
| 2 | *Does it only populate the template, or can it develop technical content?* | Both. The TT&E demo mostly shows fact extraction (dates, numbers, names). The LCSP shows multi-paragraph drafting: it takes the attached material and applies typical standards for how each section should be written. The dev team cannot judge LCSP prose quality — that is exactly the feedback needed from subject-matter experts. |
| 3 | *Is the Proposed Changes list the checklist for finalizing before review?* | It is the first of four review levels (see 4d). The real review is walking the wizard steps and the Review page, then reading the Generate preview, then circulating the Word file. |
| 4 | *Does the Word output have a working Table of Contents with page numbers?* | The headings and ToC are real Word fields, so one **Update Field → Entire table** (or Ctrl+A, F9) in Word fills in page numbers and links. Repeat after manual edits. Same for list of tables and list of figures. |
| 5 | *That is a lot of clicks before anything is produced — can it be streamlined?* | The demo shows every option. Normal use is attach → send with scope "Entire Document" → apply. Once Settings is done it is largely hands-free. Still, note the feedback and ask what felt slow. |
| 6 | *Can we add our other deliverables (CDRLs)? What do you need from us, and when is it "production"?* | It is in production now — another program uses it daily. Adding a document type needs an example document, ideally already templatized with `{{PLACEHOLDERS}}`, and funded developer time. One form can feed several deliverables when they share fields, which is where the big time savings are. |
| 7 | *Can we add our own templates ourselves?* | In progress. Download an existing template to get the `.docx`, the schema JSON, an AI editing guide, and a README; edit; re-upload under **File → Manage Custom Templates**. Local to your browser until promoted. |
| 8 | *Can you share the recording?* | Yes — plan to. Teams want it for internal training. |
