**LEIDOS PROPRIETARY**

# POP Proposal — Appendices

Appendices supporting the [Procurement Operations Portal Proposal](pop-proposal.md). Engineering background (MCP architecture, development approach, design principles, extensibility) is in the separate [design notes](pop-design-notes.md).

---

## Appendix A. Workflow Comparison Diagrams

The following diagrams show the SCA Task Order workflows (TT&E and SH) as they run today and as they would run in the portal with both phases built. In Phase 1 the "Portal" branches hold with two differences: prerequisites are confirmed on the TOM's handoff checklist rather than detected from Costpoint, and the SCA posts to Costpoint and files to POF by hand as today. TOM-side diagrams are held in a separate supplement until the TOM workflow is validated with that team.

### A.1 SCA end-to-end sequence — today vs. portal

```mermaid
sequenceDiagram
    participant SCA
    participant Tool as Doc Builder (today)
    participant Portal as Portal
    participant Systems as External Systems

    Note over SCA,Systems: SCA — FMS Task Order Issuance (TT&E / SH)
    alt Today
        SCA->>SCA: Confirms prerequisites by email, Teams, and Costpoint
        SCA->>Tool: Uploads source documents and reviews AI-drafted fields
        Tool->>Tool: AI cross-checks sources, generates the document set
        SCA->>SCA: Enters values into Costpoint, files to POF, issues package
        SCA->>SCA: Updates tracker by hand
    else Portal
        Portal->>Portal: Prerequisites auto-detected as met
        Portal->>SCA: Releases TO to shared work queue with full context
        SCA->>Portal: Opens queue item with full context pre-loaded
        Portal->>Portal: Same AI fill + validate + generate
        Portal->>Systems: Pushes award to Costpoint, issues package, populates POF
        Portal->>Systems: Shared tracker updates automatically
    end
```

### A.2 SCA automation progression

| Step | Before Doc Builder | Today | Portal |
|---|---|---|---|
| Source document intake | Manual | Manual: Upload (SharePoint search available) + Auto: AI extract | Auto: Shared intake, direct SharePoint/Outlook access |
| PR review & validation | Manual: Costpoint lookup + manual cross-check | Manual: Upload PR + Auto: AI cross-check against PWS and pricing | Auto: API-polled live |
| IDIQ pricing validation | Manual price-sheet lookup | Manual: Upload price sheet + Auto: AI cross-check | Auto: Reference data lookup |
| Template field entry | Manual (~20–25 min) | Auto: AI drafts + Manual: Review | Auto: AI drafts + Manual: Review |
| Document generation | Manual (15–20 min) | Auto: One-click | Auto: One-click |
| Costpoint entry | Manual | Manual | Auto: API + Manual: Approve |
| Award issuance & POF | Manual (20–30 min) | Manual (documents generated) | Auto: One-click + Manual: Approve |
| Tracker update | Manual | Manual | Auto: Generated automatically |


> Table shows the TT&E workflow progression (the higher-volume workflow). The SH workflow follows the same pattern with PWS detection replacing PR notification and SOR TO confirmation replacing IDIQ validation.

---

---

## Appendix B. Value Stream Methodology & Prioritization

### Methodology

This proposal is structured as a value stream improvement initiative. The five-step methodology:

| Step | Activity | Timing |
|---|---|---|
| 1. Map the current process | Document each step — touch time, process time, queue time | Done (process baseline) |
| 2. Identify problems | Surface lags, errors, handoff failures, rework loops | Done (process baseline) |
| 3. Identify potential improvements | Propose interventions for each problem | Done (this proposal) |
| 4. Prioritize improvements | Rank by impact vs. effort; sequence into delivery plan | Done (this proposal) |
| 5. Implement & measure | Deploy; measure change against baseline | Phase 1 build (ongoing) |

### Improvements mapped to problems

| ID | Problem addressed | Proposed improvement | Requires infra? | Status |
|---|---|---|---|---|
| I-3 | P-3 (manual field entry) | AI extraction from source documents drafts all template fields | **No** | Shipped (Doc Builder) |
| I-4 | P-4 (format conversions) | Automated Word rendering from templates | **No** | Shipped (Doc Builder) |
| I-7a | P-7 (scattered information) | Single guided workflow with AI cross-checks and reference Q&A | **No** | Shipped (Doc Builder) |
| I-5a | P-5 (stale tracker) | Tracker rows generated from workflow actions | Yes (shared state) | Phase 1 |
| I-5b | P-5 (stale tracker) | Shared tracker writes automatically across all users | Yes | Phase 1 or 2 |
| I-7b | P-7 (scattered information) | Multi-user portal aggregating all systems via API | Yes | Phase 1 or 2 |
| I-1 | P-1 (informal confirmations) | Event-driven dependency tracking; TOs release on confirmed prerequisites | Yes | Phase 1 or 2 |
| I-2 | P-2 (manual PR checks) | Costpoint API integration; auto-surface PR readiness | Yes | Phase 1 or 2 |
| I-6 | P-6 (partial-fund visibility) | Full PR pipeline state in one view | Yes | Phase 1 or 2 |

TOM-specific improvements (I-10 through I-15) are held in a separate supplement until the TOM workflow is validated.

### Prioritization

The items that needed no infrastructure were built first, in Doc Builder, and are in daily use. The portal items follow in the order the main proposal's sequencing gives.

| Priority | Improvement | Rationale | Status |
|---|---|---|---|
| 1 | I-3 — AI-drafted template fields | Highest touch-time savings; every TT&E and SH TO | Shipped |
| 2 | I-4 — Automated Word rendering | Same engine; eliminates mechanical effort | Shipped |
| 3 | I-7a — Guided workflow + AI | Enforces ordering, cross-checks sources | Shipped |
| 4 | I-7b, I-1 — Shared workspace, handoff, and dependency engine | Where the queue time goes; needs shared state; prerequisites confirmed by people until Costpoint integration | Phase 1 |
| 5 | I-5a, I-5b — Generated tracker and cycle-time measurement | By-product of work recorded in the portal; produces the numbers the Phase 2 gate uses | Phase 1 |
| 6 | I-7b (intake) — SharePoint/Outlook access, Doc Builder extensions | Touch-time return; released if measured volume supports it | Phase 2a |
| 7 | I-2, I-6 — Costpoint and POF integration | Longest approval; released when access is granted and measured queue time shows where a watch pays | Phase 2b |

### Measurement plan

Phase 1 of the portal is the instrument. Every metric below is derived from timestamps the workspace, handoff, and queue record as work is done; nobody fills in a timing sheet. The first quarter of Phase 1 data is the gate for Phase 2.

| Metric | How measured | Available |
|---|---|---|
| PR approved → Task Order issued (median, 90th percentile, share over 7 business days) | Baseline: Costpoint approval dates matched to POF filing dates for 2026 PRs, pulled during the Phase 1 build. Phase 1: workspace history | Baseline at Phase 1 launch; then continuous |
| PR approved → first SCA review | Queue entry to first SCA action | Phase 1 |
| Handoff → first SCA action | Handoff timestamp to queue pickup | Phase 1 |
| Queue time per Task Order | Time waiting on prerequisites (SOR TO, PR approval), from checklist timestamps; from Costpoint events in Phase 2b | Phase 1 |
| PR return rate | Handoffs sent back for a missing or inconsistent prerequisite | Phase 1 |
| Rework rate | Modifications issued due to partial-funding on stale data | Phase 1 |
| Touch time per Task Order (TT&E / SH) | Timer from first action to issuance, excluding waits | Phase 1 |
| Tracker accuracy | Spot-check generated tracker vs. actual issuance dates (monthly) | Phase 1 |
| Error rate | Field-entry errors caught in review or post-issuance | Phase 1 |

---

---

## Appendix C. Alternatives Considered

The main proposal recommends a custom portal for Phase 1 (Option B below) and presents Microsoft 365 for the tracker with a thin AI service (Option A) as the alternative considered in detail. This appendix gives the comparison behind that recommendation and the alternatives that were ruled out earlier. A work tracker, whatever it is, can record *that* a step happened. Only something that reads the documents can check *what is in them*; that is the line between the tracker and the AI service in Option A, and between Option A and Option B.

### C.1 Options compared

| | Option A: M365 + AI service (alternative considered) | Option B: Portal (recommended) | Jira + AI service | Lists only (fallback) |
|---|---|---|---|---|
| Task Order record, queue, handoff, comments, notifications | Microsoft Lists item per Task Order; board and filtered views; Approvals app for handoff sign-off; list validation blocks "Ready for SCA" until all four prerequisites are Yes | Custom workspace, queue, and dependency engine | Jira issue per Task Order; transition validators; boards | Same as Option A |
| Source documents | SharePoint Document Set per Task Order; the files are already there | Uploaded to the portal (Phase 1); pulled from SharePoint (Phase 2a) | Attachments, or links back to SharePoint | Document Set |
| Cycle-time measurement | List version history timestamps every status change; flows stamp "Ready for SCA at" and "Issued at"; Power BI reports with business-day arithmetic | Recorded by the workspace as a side effect of the work | Status-change history; control charts; business-day SLAs in Jira Service Management | Version history and flows; Power BI or Excel |
| Verified handoff (the package cross-checked, not a checkbox) | AI service runs Doc Builder's discrepancy review on the Task Order's folder when the TOM marks it ready | Built in | AI service, same as A | None |
| PR quality triage on arrival | AI service | Built in | AI service | None |
| Server-held AI keys, AI audit log | AI service | Built in | AI service | None; keys stay in browsers as today |
| Doc Builder drafts from the shared documents | Doc Builder signs in with Entra ID and reads the Task Order's folder through Graph | Embedded; the Task Order record is the data every document drafts from | Doc Builder reads SharePoint through Graph; Jira holds a link | SCA downloads and uploads as today |
| What the team learns | Nothing new for the tracker: Lists, Teams, Outlook, and Approvals as they use them now; Doc Builder as today | A new application, designed around the Task Order and co-designed with pilot users | Jira, new to the team | Lists |
| One front door | No: the SCA works in the list, then Doc Builder, then back | Yes | No | No |
| Record and documents are one thing | No: list columns and Doc Builder answers are two copies the service keeps in sync | Yes | No | No |
| Where the logic lives | AI service in code under version control; queue rules, timestamps, and notifications as list settings and Power Automate flows in the tenant, configured by hand and owned by an account | All in code under version control, tested, portable to any host | AI service in code; Jira configuration in Atlassian's tenant | List settings and flows |
| Reuse for another process (a different document workflow, another program) | AI service is shared. Each new process is a new list, flows, and dashboard, set up by hand in the tenant (~2–3 days each); a PnP provisioning template and an exported Power Platform solution make it repeatable | Built once as a generic work-item engine: a new process is a schema plus a prerequisite checklist, the same configure-don't-code model Doc Builder uses | Same as A: Jira project per process, configured by hand | Same as A, without the shared service |
| Move to another tenant or cloud (.mil: GCC High, DoD, or a government host) | Doc Builder and the AI service are code and redeploy to Azure Government (~20% higher list prices) or a container host. Lists, Power Automate, and Power BI exist in GCC High and DoD, but the list, flows, and dashboards must be re-created in the destination tenant from templates; Graph and Entra endpoints change per cloud; Power BI has no Free tier in Government, so every viewer needs a Pro license | The whole application redeploys as one unit (container or VM with PostgreSQL and Redis); nothing to re-create by hand. Its own ATO work is larger because it carries a database and cache | Jira Cloud does not follow: Atlassian Government Cloud is FedRAMP Moderate, below IL4/IL5; self-hosted Jira Data Center is another system to accredit | List re-created by hand in the new tenant |
| Phase 2 path | 2a intake is largely done by the Graph sign-in; 2b connectors attach to the AI service. Field-level provenance, cross-Task-Order memory, and shared reference data each add state the service must own; at about three of them it is the portal's backend | As proposed | Same as A, plus Jira seat costs continue | Connectors have nothing to attach to |
| Build (developer estimates, ±50%; see main proposal note 13) | ~80 hr | ~140 hr | ~80 hr + Jira setup | ~25 hr |
| Support | ~1 hr/month | ~2 hr/month | ~1 hr/month | ~0.5 hr/month |
| New IT approvals | Function hosting, Entra ID app registration, Graph `Sites.Selected` permission | VM or App Service, Entra ID app registration | Jira Cloud tenancy, Atlassian SSO, plus the Function and Graph items | None beyond list ownership |
| Running cost per month (sources in C.3) | ~$1–5 at list; under $10 with monitoring | ~$180–400 | ~$155 (Jira Standard + SSO) to ~$300+ (with Service Management), 12 users | ~$0 |
| Three-year running cost | ~$0.1–0.4K; ~$1.5–2.5K more if Power BI Pro must be bought for 3–5 viewers on E3 | ~$6.5–14.4K | ~$5.6–11K+ | ~$0 |
| Confidence in the cost figures | Azure list prices and Microsoft 365 inclusions verified; internal chargeback model unknown | Azure list prices verified; tier choice is the developer's | Jira Standard and Guard verified; Service Management recalled | High |

**Why Option A runs so cheaply.** The portal's hosting is sized for an always-on web application with its own database and cache. In Option A, Lists is the web tier and SharePoint is the shared state, both already paid for. The AI service has no always-on part: it runs on Azure Functions (Flex Consumption plan), whose monthly free grant of 250,000 executions and 100,000 GB-seconds covers a few hundred cross-checks a month with room to spare (a 30-second check on a 2 GB instance is 60 GB-seconds; 500 of them is 30,000), and its audit log lives in Table Storage at $0.045 per GB-month, which for a few thousand rows a month is cents. Only standard Power Automate connectors are used (SharePoint, Outlook, Teams, Approvals, HTTP to the Function); Microsoft's licensing table confirms these are included with Microsoft 365 and premium connectors are not, so the design must stay within standard connectors to avoid $15/user/month Premium seats. Power BI Pro, for shared dashboards, is included in Microsoft 365 E5 and not in E3; if the team is on E3, either buy Pro ($14/user/month list) for the people who view the dashboards or report from list views and Excel. Which license the team holds, whether the tenant is commercial or GCC, and whether IT charges a flat rate per Azure subscription are the three facts that could move the Option A figure, and all three should be confirmed before quoting it. Sources and what is verified are in C.3.

**Why Option B costs more and what it buys.** Of the portal's 140 hours, about 76 (workspace, queue, notifications, dashboards, comments) build what Lists already does; the rest is the backend, the handoff logic, and the audit log, which Option A also builds as the AI service. The portal's return for the extra ~60 hours and ~$180–400 a month is the rows Option A cannot deliver: one front door; a Task Order record that *is* the data every document in the set drafts from, with no second copy to drift; measurement and gating in tested code rather than in flows and list settings someone has to own; and an application for the Phase 2 connectors to attach to. Those are the reasons the main proposal gives for recommending B, and they are the ones that bear on the program's 7-day goal.

**What would make Option A the right call.** If the program funds Phase 1 but not at 140 hours, Option A delivers the queue, the verified handoff, and the measurement for about half the hours and almost no hosting, and the Lists-only fallback delivers the queue and measurement alone for about 25 hours. Option A can also be run first and Option B built later: the AI service is the portal's backend either way. Two design rules keep that path open if A is chosen: the AI service treats the tracker as an adapter (a Lists adapter now, the portal's own database later), and the list, flows, and dashboard are kept as exportable templates (a PnP provisioning template and a Power Platform solution) rather than hand-built artifacts. That discipline is roughly 8 hours on top of Option A's 80. The cost of starting with A is that by the second or third Phase 2 integration the service has become the portal's backend with a worse front end, and the ~76 hours of tracker work in B are spent then instead of now.

**Portability, for Leidos rather than for the program.** Two futures are plausible beyond this program: applying the same approach to other document-driven processes, and deploying in a .mil environment (the development plan already carries a [.mil deployment track](development-plan.md) for Doc Builder itself: a government-operated host, government-managed browsers, and whatever model service is authorized there, most likely OpenAI models through a proxy). Both favour code over tenant configuration. Under Option B, a new process is a schema plus a prerequisite checklist, and a new environment is a redeploy of one unit. Under Option A, Doc Builder and the AI service move the same way, but the list, flows, and dashboards are tenant configuration and must be re-created wherever the process goes: about two or three days per process per tenant if templates were kept, longer if not. Microsoft's services are all present in GCC High and DoD (Power Automate standard connectors, Lists, Power BI), so Option A is not blocked in .mil, only more manual; Azure Government list prices run about 20% above commercial for either option. Jira does not survive either future well: Atlassian's Government Cloud is authorized at FedRAMP Moderate, and self-hosted Jira is another system to accredit. This is a reason to prefer B, but it is a reason that belongs to Leidos, and the main proposal presents it as such rather than as a program benefit.

### C.2 Ruled out

**Jira (Cloud) with the same AI service.** Functionally close to Option A; Jira's status history, transition validators, and (in Jira Service Management) business-day SLAs fit the problem well. Ruled out because the team has no Jira license: Jira Standard is $8.60 per user per month for the first 100 seats (Atlassian's published example), Atlassian Guard Standard adds $4.35 per user for SSO, and Jira Service Management Standard, if business-day SLAs are wanted, is recalled at roughly $20–22 per agent (not verified at writing). For 12 users that is ~$155/month on Jira Standard with SSO and ~$300+/month with Service Management, which approaches the portal's hosting while delivering less than Option A. The documents stay in SharePoint regardless, so Jira adds a system without replacing one, and the data leaves the Microsoft tenant, which complicates the Leidos Proprietary and CUI posture. If a Jira license already existed, this would be a near-equivalent of Option A.

**Lists only, with Doc Builder left as it is.** The fallback if neither option is approved, and still an improvement on today: a queue, a prerequisite checklist, and automatic status timestamps for roughly 25 hours of setup and no new hosting. It lacks everything the AI service provides: nobody checks the package at handoff, PRs are not triaged, keys stay in browsers, and there is no AI audit log. The SCA still downloads the files and uploads them to Doc Builder. An earlier draft of this proposal said a list "records a date only when someone types one"; that was wrong. List version history and Power Automate record status changes automatically, so measurement of the 7-business-day goal is available on this path too.

### C.3 Sources for the cost figures

Checked October 23, 2026. Azure figures come from Microsoft's Retail Prices API, which returns the same pay-as-you-go list prices the pricing pages display; East US region, 730 hours a month. Licensing figures are from the vendors' published pages. Items that could not be verified are marked. Government-cloud (GCC) prices differ from the commercial list prices below, and Leidos internal chargeback may differ from both.

| Figure | Source | Status |
|---|---|---|
| Azure Functions Flex Consumption free grant: 250,000 executions and 100,000 GB-seconds a month; the older Consumption plan (1 million / 400,000) is legacy | [Azure Functions pricing](https://azure.microsoft.com/en-us/pricing/details/functions/); [Functions hosting plans](https://learn.microsoft.com/en-us/azure/azure-functions/functions-scale) | Verified |
| Functions Flex Consumption on-demand rates beyond the grant: $0.40 per million executions, $0.000026 per GB-second (East US) | [Azure Retail Prices API](https://learn.microsoft.com/en-us/rest/api/cost-management/retail-prices/azure-retail-prices); matches Microsoft's [worked example](https://learn.microsoft.com/en-us/azure/azure-functions/functions-consumption-costs) | Verified |
| Table Storage LRS $0.045 per GB-month, $0.00036 per 10,000 transactions; blob Hot LRS $0.0208 per GB-month (audit log and the Function's storage account: cents a month) | [Azure Retail Prices API](https://learn.microsoft.com/en-us/rest/api/cost-management/retail-prices/azure-retail-prices); [Table Storage pricing](https://azure.microsoft.com/en-us/pricing/details/storage/tables/) | Verified |
| Microsoft 365 includes Power Automate standard connectors; premium and custom connectors are not included | [Power Automate seeded licenses](https://learn.microsoft.com/en-us/power-platform/admin/power-automate-licensing/deep-dive-on-specific-license#compare-seeded-licenses) | Verified |
| Power Automate Premium $15/user/month; Process $150/bot/month | [Power Automate pricing](https://www.microsoft.com/en-us/power-platform/products/power-automate/pricing) | Verified |
| Power BI Pro $14/user/month paid yearly; included in Microsoft 365 E5 and Office 365 E5 | [Power BI pricing](https://www.microsoft.com/en-us/power-platform/products/power-bi/pricing); [Power BI licenses](https://learn.microsoft.com/en-us/power-bi/fundamentals/end-user-license) | Verified |
| Lists version history records changes per item | [Versioning in lists and libraries](https://support.microsoft.com/en-us/office/enable-and-configure-versioning-for-a-list-or-library-1555d642-23ee-446a-990a-bcab618c7a37) | Verified that versioning exists; the Phase 1 design relies on flows stamping explicit timestamp columns as well |
| Graph `Sites.Selected` limits an app to one site collection | [Selected permissions overview](https://learn.microsoft.com/en-us/graph/permissions-selected-overview) | Verified |
| Jira Standard $8.60/user/month, seats 1–100 | [Atlassian cloud licensing](https://www.atlassian.com/licensing/cloud) | Verified (Atlassian's own example) |
| Atlassian Guard Standard $4.35/user/month | [Atlassian Guard pricing](https://www.atlassian.com/software/guard/pricing) | Verified |
| Jira Service Management Standard ~$20–22/agent/month | [JSM pricing](https://www.atlassian.com/software/jira/service-management/pricing) | Not verified at writing; recalled |
| App Service Linux P1v3 $0.155/hour ($113/month), P2v3 $0.31/hour ($226/month) | [Azure Retail Prices API](https://learn.microsoft.com/en-us/rest/api/cost-management/retail-prices/azure-retail-prices); [App Service pricing](https://azure.microsoft.com/en-us/pricing/details/app-service/linux/) | Verified |
| PostgreSQL Flexible Server Burstable B2S $0.068/hour ($50/month), B2ms $0.136/hour ($99/month); General Purpose 2 vCore $0.178/hour ($130/month) | [Azure Retail Prices API](https://learn.microsoft.com/en-us/rest/api/cost-management/retail-prices/azure-retail-prices); [PostgreSQL pricing](https://azure.microsoft.com/en-us/pricing/details/postgresql/flexible-server/) | Verified; data storage rate not returned, ~$5–10/month is an estimate |
| Redis Basic C0 $0.022/hour ($16/month), C1 $0.055/hour ($40/month) | [Azure Retail Prices API](https://learn.microsoft.com/en-us/rest/api/cost-management/retail-prices/azure-retail-prices); [Redis pricing](https://azure.microsoft.com/en-us/pricing/details/cache/) | Verified |
| Option B tier choice (2 vCPU / 8 GB at the low end, 4 vCPU / 16 GB at the high end) | Developer's sizing for ~15 users and ~6 PRs a day | Estimate |
| Azure Government (US Gov Virginia) list prices for the same services: Functions Flex $0.50 per million executions and $0.000033 per GB-second; App Service Linux P1v3 $0.185/hour; PostgreSQL Burstable B2ms $0.162/hour (roughly 20% above commercial) | [Azure Retail Prices API](https://learn.microsoft.com/en-us/rest/api/cost-management/retail-prices/azure-retail-prices), `armRegionName eq 'usgovvirginia'` | Verified |
| Power Automate is offered in GCC, GCC High (IL4), and DoD (IL5); Microsoft 365 US Government plans include its standard-connector capabilities; "there are exceptions to the principle of maintaining product functional parity" | [Power Automate US Government](https://learn.microsoft.com/en-us/power-automate/us-govt) | Verified |
| Graph endpoints differ per cloud: `graph.microsoft.com` (commercial and GCC), `graph.microsoft.us` (GCC High), `dod-graph.microsoft.us` (DoD); tokens are not interchangeable | [Microsoft Graph national cloud deployments](https://learn.microsoft.com/en-us/graph/deployments) | Verified |
| Power BI in GCC, GCC High, and DoD; "Power BI US Government isn't available as a Free license", so every user needs Pro or PPU | [Power BI for US Government](https://learn.microsoft.com/en-us/fabric/enterprise/powerbi/service-government-us-overview) | Verified |
| Atlassian Government Cloud authorization level (FedRAMP Moderate) | Atlassian's published FedRAMP listing | Recalled; confirm on the [FedRAMP Marketplace](https://marketplace.fedramp.gov/) before relying on it |
| Microsoft 365 tier (E3 or E5), commercial or GCC tenant, Azure chargeback model | Leidos IT | Unconfirmed; the chargeback model affects the portal's hosting figure, and the tier decides Power BI cost in the Option A alternative |

### C.4 Also ruled out

**Microsoft Power Platform (Power Apps, Power Automate, Dataverse)** as the application itself, as distinct from the standard connectors Option A uses. Ruled out because reaching the LiteLLM proxy from Power Apps needs custom connectors, because the AI-assisted development approach that has carried this project cannot work in visual low-code tooling, because licensing runs about $5–6K a year for connectors the Graph API gives in days of work, and because embedding the existing React application inside Power Apps adds a seam rather than extending what exists. The hardest integration, Costpoint, is custom work on either platform.

---

## Appendix D. Work Breakdown

Developer hours for a single developer with AI-assisted development, the same basis as the project's development plan (main proposal note 13). Costpoint and POF integration carry the most uncertainty; their APIs are unexplored, which is one reason they sit in Phase 2b.

| Work | Hours |
|---|---|
| **Doc Builder refinement and support** | **1–2 / week, averaged (4–8 / month)** |
| New and revised document templates as program documents change; field, rule, and wording adjustments the SCAs request; promoting team-submitted templates to official; model retirements and dependency updates; bug fixes. No build work | ongoing |
| **Phase 1: coordination and measurement** | **~140, then ~2 / month** |
| Backend foundation: server, database, SSO, access control, server-held keys, deployment | 40 |
| Shared Task Order workspace: documents, status, comments, participants, history | 24 |
| Structured TOM-to-SCA handoff with the package cross-check, using the baseline's prerequisite list as the checklist | 16 |
| Work queue and dependency engine, notifications, team load view | 32 |
| Performance tracking, auto-generated tracker, program dashboards | 20 |
| Audit log of AI interactions | 8 |
| *Alternative: Microsoft 365 + thin AI service (Appendix C, Option A)* | *~80, then ~1 / month* |
| *Lists list, Document Set library, views, prerequisite validation, Approvals handoff, timestamp and notification flows (16); Power BI dashboards (8); Azure Function with server-held keys (16); the package cross-check and PR triage running headless (20); audit log (8); Doc Builder reading the Task Order's folder through Graph (12)* | |
| **Phase 2a: intake and document-tool extensions** | **~150** |
| Source-document intake with SharePoint/Outlook access and shared indexing | 28 |
| SharePoint/Outlook connector, built as a reusable MCP server ([design notes](pop-design-notes.md#1-mcp-server-architecture)) | 16 |
| Price Analysis, E&TS; remaining field-level validation rules; in-portal editing of locked text | 20 |
| TOM workflow documents: SOR selection, sourcing emails, AI pre-fill of the existing SH PWS template (scope confirmed with the TOM team first) | 24 |
| Team-maintained templates, remaining work: AI-generated schemas from a tagged Word file, turning a finished document into a template in the browser, revising a template without losing its schema, and a shared template catalogue (upload and in-app editing shipped October 2026) | 64 |
| **Phase 2b: systems of record** | **~80** |
| Costpoint connector (MCP server): PR approval watch, award posting | 24 |
| POF connector (MCP server): folder creation, filing | 16 |
| Shared reference data (SOR capabilities, IDIQ pricing) and library for the AI assistant | 22 |
| Shared editing and PDF export | 16 |
| **Build total if both phases are approved** | **~370** |

**Phase 2 touch-time basis.** Phase 2a's only quantified return is shared intake at about 0.5 hr per PR, from the team's estimate that document retrieval is about half of process time (note 11). Price Analysis and E&TS follow the same ~1 hr/document pattern on documents not yet covered but are not counted. TOM documents are estimated at 30–60 min falling to 10–15 min per SOR selection, from initial interviews, not validated. Team-maintained templates remove the developer from the template loop and are justified on extensibility, not hours. Phase 2b's Issue TO (~20 min) and POF folder (~10 min) steps (note 12) are the manual work the connectors replace; the Costpoint watch replaces manual PR polling at an unknown frequency.

**Sequencing.** Refinement is ongoing. Phase 1 starts the backend once hosting and SSO registration are provisioned; at 20 hours a week the team is working in the portal in about two months. One quarter of measurement follows. Phase 2a and 2b each release on their own gate (main proposal, Return on investment). 2b comes last because Costpoint and POF access have the longest approvals; those are requested during Phase 1 so they are not on the critical path.

---

*Leidos Proprietary — not to be reproduced, disclosed, or exported without written approval of Leidos.*
