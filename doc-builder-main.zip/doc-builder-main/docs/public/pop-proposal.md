**LEIDOS PROPRIETARY**

# Procurement Operations Portal Proposal

*FMS F-16 Sustainment — Supply Chain Procurement · October 23, 2026*

*One-page version: [Decision Brief](pop-brief.md). Appendices: [workflow diagrams, value stream, alternatives, work breakdown](pop-proposal-appendices.md). Engineering background: [design notes](pop-design-notes.md).*

## Summary

The program has set a goal of turning each PR into a Task Order, or a modification to one, within 7 business days, at 125 PRs a month. That is four times this year's rate.¹ ² Nobody can say today whether the goal is being met. The start date is in Costpoint, the end date is in POF, and nothing records the steps between. *[Measured baseline to be inserted here once the 2026 Costpoint and POF dates are matched: median business days PR-to-issue and share over 7 days.]*

What the team does know is where its own time goes. Each PR takes 2–3 hours of hands-on work and then waits hours to days between steps, in email, Teams, and Costpoint.⁵ Doc Builder, in daily use since this summer, took an estimated hour and a half out of the hands-on part.⁷ The waiting is untouched.

**The decision in front of the program is Phase 1 of a shared portal: about 140 developer hours, roughly $21K at the assumed rates below, plus $2–5K a year in hosting.** It gives the team one workspace per Task Order, a TOM-to-SCA handoff that checks the package before the SCA starts, a shared queue, and continuous measurement of the 7-day goal. It pays for itself if it recovers 13 minutes per PR at target volume, or 55 minutes at today's, against waits the team describes in hours and days.

Two smaller items ride along. Keeping Doc Builder current costs 1–2 developer hours a week and protects a saving the team already has; it should simply continue. Phase 2, about 230 hours of integrations with Costpoint, POF, SharePoint, and Outlook, is not requested now. It is decided after one quarter of Phase 1 data against the numeric gate in [Return on investment](#return-on-investment).

A Microsoft 365 alternative was costed in detail at about 80 hours and under $10 a month. The portal is recommended over it for two reasons that bear on this program: the SCA enters each Task Order's data once rather than twice, and the team changes tools once rather than twice. If 140 hours is not available, the Microsoft 365 option is the right fallback and the proposal says how to build it so the portal can follow.

*Superscripts refer to [Notes on the figures](#notes-on-the-figures), which give the source and confidence of every number.*

---

## The problem

The process baseline ([`fms-procurement-process.md`](fms-procurement-process.md)) found two kinds of friction. SCA friction is assembly: fill, format, convert, check. Doc Builder addressed that. TOM friction, and the days of elapsed time, are coordination: track, follow up, verify prerequisites, hand off. Nothing addresses that today.

The team estimates a PR waits up to 7 business days for first review against a 3-day goal.³ Volume arrives in batches, a buyer can award about 8 a day,⁴ and buyers also carry funding requests, subcontractor setup, and pricing negotiations in the same queue. The TOM hands off with a bare link, so the SCA spends an estimated 15–30 minutes re-deriving context⁹ and sometimes discovers a missing PWS, pricing, or SOR Task Order mid-work, which sends the item back. PRs arrive with upstream errors "more than they should." The tracker is a separate manual step and falls behind. Eleven of 16 steps rest on knowledge in someone's head.⁶

None of this has a count. How often a confirmation is missed, how many PRs are returned, how long approval takes: the baseline lists these as open questions because no system records them.¹⁰ That is the gap Phase 1 closes first. Every other return in this proposal is an estimate until it does.

---

## Return on investment

Volume and per-unit figures are per PR, since each approved PR becomes one procurement action with a full document set. Investment is developer hours; return is SCA hours. **Dollar figures assume a loaded SCA rate of $75 an hour and a developer rate of $150 an hour, a 2:1 ratio. These are placeholders for finance to replace; every dollar figure scales with them.**

| Ask | Developer hours | Build cost | Running cost per year |
|---|---|---|---|
| Keep Doc Builder current | 1–2 a week, averaged (50–100 a year) | | $7.5–15K |
| **Portal Phase 1** | **~140 (±50%), then ~24 a year** | **~$21K** | **~$3.6K support + $2.2–4.8K hosting¹⁴** |
| Portal Phase 2 (gated) | ~230 | ~$34.5K | |
| *Microsoft 365 alternative for Phase 1* | *~80, then ~12 a year* | *~$12K* | *~$1.8K support + under $120 hosting¹⁵* |

**Keeping Doc Builder current.** The tool saves an estimated 1.5 hours per PR,⁷ about 540 SCA hours a year at today's 30 PRs a month and 2,250 at the goal of 125. In dollars that is roughly $40K a year today and $170K at goal. It runs as static files and needs no developer to stay up, but documents follow the program: five document sets were added this year, SCAs ask for fields and rules as they use it, and models on the AI proxy retire. One to two hours a week keeps it current at a fifth to a third of what it saves. Unfunded, it keeps running and stops improving.

**Phase 1.** Year-one cost is about $27–30K including hosting; three-year cost is about $38–46K. Spread over the PRs processed, the break-even is:

| PRs a month | Recover per PR, year 1 | Recover per PR, 3 years |
|---|---|---|
| 125 (program goal)¹ | ~13 min (~$16) | ~6 min |
| 50 | ~33 min | ~14 min |
| 30 (2026 average)² | ~55 min | ~24 min |

The structured handoff alone is estimated to remove 15–30 minutes of SCA re-derivation per PR,⁹ before any queue time, rework, or tracker upkeep. If that estimate is anywhere near right, Phase 1 clears its threshold on the handoff and everything else is upside. Hosting works out to $1.50–3 per PR at goal and $6–13 at today's volume.

What Phase 1 measures, and what is known today:

| Measure | Today | Source once Phase 1 runs |
|---|---|---|
| PR approved to first SCA review | Goal 3 business days; actual up to ~7, from recollection³ | Queue timestamps |
| PR approved to Task Order issued | Goal 7 business days; not measured | Workspace history |
| PRs returned to TOM for correction | "More than it should be"¹⁰ | Handoff and rework events |
| SCA time re-deriving handoff context | 15–30 min, estimate⁹ | Removed by the structured handoff |
| Tracker lag | Unknown | Tracker generated from events |

**A baseline before launch.** Costpoint holds the approval date and POF the filing date for all 261 PRs this year. Matching them by Task Order number and computing elapsed business days is a few hours of work for an SCA and the developer. It should be done now, so the summary above carries a measured number and the dashboards have something to improve on.

**Phase 2 and its gate.** Phase 2a (SharePoint and Outlook intake, more documents, team-maintained templates, about 150 hours) is estimated to save a further half hour per PR on document retrieval alone.¹¹ Phase 2b (Costpoint and POF connectors, shared reference data, about 80 hours) has no touch-time estimate yet because the APIs are unexplored. At 230 hours and 2:1, Phase 2 nets positive in year one only at goal volume (+$22K), is negative at 50 PRs a month (−$12K), and breaks even over three years at today's pace.

Phase 2 is therefore not approved now. After one quarter of Phase 1 data:

- **2a releases** if measured volume averages at least 50 PRs a month over the quarter, the level at which its payback is under 18 months, and document retrieval still shows up as the largest hands-on step.
- **2b releases** when IT has granted Costpoint and POF access and measured queue time on prerequisite confirmation exceeds one business day at the median, which is where an automatic watch pays.

If neither condition is met, the program keeps Phase 1 and the measurement, and revisits in another quarter.

---

## What the portal is

One workspace for the team. Costpoint, POF, and SharePoint remain the systems of record; the portal sits in front of them.

| Function | What the team gets | Phase |
|---|---|---|
| **Source documents** | One shared intake per Task Order; everyone working it sees the same files | 1 by upload; 2a pulls from SharePoint and Outlook |
| **Communicate** | Comments and handoff notes on the Task Order, not in email; notifications when a person's action is next | 1 |
| **Hand off** | TOM-to-SCA handoff with prerequisites confirmed and context attached; the portal cross-checks the PWS, PR, pricing, and SOR Task Order before the item moves | 1 |
| **Prioritize** | Team queue ordered by due date against the 7-day goal; leads see load and reassign | 1; prerequisites confirmed by Costpoint in 2b |
| **Generate documents** | Doc Builder, embedded, drafting from data already in the portal | 1 |
| **Track performance** | Cycle time, queue time, throughput, and rework per Task Order, per person, team-wide; tracker generated automatically | 1 |

A Task Order through Phase 1: the TOM opens it at award, uploads the PWS, PR, pricing, and SOR Task Order as each is ready, and hands off through a checklist that confirms all four. The portal cross-checks the four documents against each other and moves the item to the SCA queue with everything attached and a timestamp. The SCA opens it with the sources already there and the memos, award, and checklist drafted and cross-checked by Doc Builder from the same record. The SCA posts to Costpoint and files to POF as today, then marks the Task Order issued. The TOM sees it issued; the lead sees where it waited; the program sees throughput against the goal.

Phase 2 adds the connectors: the portal pulls source documents itself, watches Costpoint for PR approval and SOR Task Order issuance so prerequisites confirm without anyone checking, and posts the award and files to POF with one approval. Diagrams are in [Appendix A](pop-proposal-appendices.md#appendix-a-workflow-comparison-diagrams); the hour-by-hour work breakdown is [Appendix D](pop-proposal-appendices.md#appendix-d-work-breakdown).

---

## What exists today

[Doc Builder](https://ams-oot.pages.lsde.leidos.com/doc-builder/) runs in the browser against the existing LiteLLM AI proxy, with no hosting cost. Five Task Order document sets are in daily use (TT&E, Straight to Repair, Repair Modification, TT&E with Modification, Shipping Hub) plus standalone documents including the Funding Request Summary, fillable TT&E and SH PWS templates, and a source-document consistency review. It drafts field values from uploaded documents, flags discrepancies between them, reviews the finished package, and detects and routes CUI. Each document set was added as a schema plus a Word template with no application code, so a new or revised document is about two developer hours.

The saving per TT&E Task Order, the one workflow analyzed so far:

| Step | Manual | With Doc Builder | Estimated saved |
|---|---|---|---|
| Fill template fields across the document set | ~1–1.5 hr | AI drafts; SCA reviews | ~1 hr |
| Cross-check PR against PWS, Source Selection, price sheet | ~20–30 min | AI flags discrepancies | ~0.5 hr |
| Gather source documents; final review; Costpoint; POF; issue | Manual | Manual | 0 |

The "Manual" column is from the August 2026 value stream map.⁵ The "Saved" column is the developer's estimate and has not been timed with an SCA.⁷ The team's own earlier estimate of total touch time was lower than the VSM's, and if it is closer to right the saving is nearer 0.5–1 hour than 1.5. The only timed result is the Shipping Hub pilot: one memo went from about an hour to about 45 minutes for one user.⁸ Timing three SCAs on three PRs would settle this and is the single most useful piece of evidence this proposal lacks.

---

## Cost and approvals

| Item | Estimate |
|---|---|
| Developer time | 1–2 hr/week for Doc Builder; ~140 hr Phase 1 now; ~230 hr Phase 2 gated; ~2 hr/month portal support once live |
| Hosting, Phase 1 (Azure App Service 2–4 vCPU, PostgreSQL, Redis) | $180–400/month at Azure East US list prices¹⁴ |
| AI usage, licensing, Entra ID registration | $0: existing proxy, open-source stack, admin setup |

The team is small enough that the 2 vCPU tier would do, which is the low end of the range. Internal chargeback may differ from list; confirm with IT before quoting.

| Approval | Owner | Lead time | Needed for |
|---|---|---|---|
| App Service provisioning | IT | 2–4 weeks | Phase 1 |
| Entra ID app registration for SSO | IT | 1–2 weeks | Phase 1 |
| Graph permissions (SharePoint, Outlook) | IT | 1–2 weeks | Phase 2a |
| Costpoint API access | IT + Finance | 4–8 weeks | Phase 2b |
| POF integration | IT | 2–4 weeks | Phase 2b |

Phase 1 needs the first two. The rest are requested during Phase 1 so they are in hand when the gate is decided. At 20 hours a week the team is working in the portal about two months after hosting is provisioned.

---

## Why this approach

Doc Builder alone cannot do this. A browser tool has no shared state: no queue, no handoff record, no cycle-time measurement. The problems that cost days need a system the team shares. A shared Claude project has no notion of a Task Order or a queue. Jira would cost about $155 a month in seats for a team that has no license and would move the data out of the Microsoft tenant. Power Platform would mean custom connectors to reach the AI proxy and licensing of $5–6K a year. The full comparison is [Appendix C](pop-proposal-appendices.md#appendix-c-alternatives-considered).

The serious alternative is Microsoft 365: a Lists list and SharePoint Document Set per Task Order for the queue and files, Power Automate for timestamps and notifications, Power BI for dashboards, and a small Azure Function built from Doc Builder's engine for the package cross-check and AI audit log. It was costed at about 80 hours and under $10 a month,¹⁵ and it does deliver the queue, the verified handoff, and the measurement.

It was not chosen for two reasons that cost this program time directly, and two that are about who carries the maintenance.

The SCA would work in two places and enter the data twice. Under the alternative the Task Order's NSN, quantity, TO number, and pricing live in list columns and again in Doc Builder's answers, with a service keeping the two in step. Every PR means a trip from the list to Doc Builder and back. In the portal the record is the data every document drafts from; a value is entered once. That is a few minutes per PR, which at goal volume is the same order as the whole break-even difference between the options.

The team would change tools twice. Appendix C shows that the alternative can be built so the portal follows later, but by the second or third Phase 2 integration the "thin" Function has become the portal's backend with a worse front end, and the portal's workspace gets built anyway. The team learns Lists, then learns the portal. Building the portal first costs about 60 more hours now and saves roughly that many later, plus one change of tools.

The maintenance reasons: the alternative's timestamps and gates live in Power Automate flows and list settings owned by an account, and break when that account changes; the portal records them in tested code. And every rule in code means the same application can serve another program's document process, or redeploy to a .mil host, without re-creating lists and flows by hand. That last benefit accrues to Leidos more than to this program, and it is not why the portal is recommended.

**If 140 hours is not approved,** the Microsoft 365 option should be built instead, with two design rules that keep the portal path open: the Function treats the tracker as an adapter, and the list, flows, and dashboard are kept as exportable templates. That discipline is about 8 hours on top of 80. Even the Lists-only fallback, about 25 hours with no AI service, gives the team a queue and automatic timestamps, and should be set up if nothing else is.

**Compliance.** Data is Leidos Proprietary: SSO and role-based access, POF as file of record, IL2- and CUI-compliant models with automatic CUI routing, IT review of every integration before it is built. Keys move from browsers to the server and every AI interaction is logged, which tightens today's posture. Whether FMS procurement data may be hosted on commercial Azure at all, and whether the tenant is commercial or GCC, has not been confirmed with IT and is the first risk below.

---

## Risks

| Risk | Then |
|---|---|
| **FMS data classification does not permit commercial Azure hosting, or the tenant is GCC** | Confirm with IT before provisioning. Azure Government runs about 20% above commercial list;¹⁶ the portal redeploys there as one unit. The Microsoft 365 alternative is available in GCC and GCC High. Neither option is blocked, but the cost figures change |
| **Nobody owns the portal after the single developer** | IT already supports Lists; nobody supports a bespoke application today. Mitigation: name an owner in the program before build, containerize so it runs anywhere, keep handoff documentation current, and hold the Lists fallback as the exit. The code is documented, version-controlled, and tested; the tool runs without a developer, but it does not evolve without one |
| The Doc Builder saving is smaller than the 1.5-hour estimate | Refinement breaks even at 0.3–0.6 hr per PR at today's volume; time three SCAs on three PRs to settle it |
| Volume stays below goal | Phase 1 breaks even at ~24 min per PR over three years at today's volume; the quarter-one data shows whether that is recovered before Phase 2 is committed |
| Costpoint or POF APIs are restricted | Phase 2b stays human-in-loop, as in Phase 1 |
| Approvals are slow | Phase 1 needs only hosting and SSO; Phase 2 approvals start during Phase 1; Doc Builder keeps running as today |
| Hosting is billed above list | The 2 vCPU tier is enough; confirm the chargeback model before quoting |
| The team does not take to a new application | Co-designed with pilot users; same outputs, less effort; the handoff check removes a step rather than adding one |
| TOM workflow is unvalidated | Phase 1's handoff uses the baseline's prerequisite list as-is; TOM documents are Phase 2a and scoped with the TOM team before build |

---

## Next steps

1. Approve Phase 1: about 140 developer hours plus hosting.
2. Confirm Doc Builder refinement continues at 1–2 hours a week.
3. Ask IT four questions in one email: data-classification constraints on hosting, commercial or GCC tenant, Azure chargeback model, and E3 or E5 licensing. Then start the hosting and SSO requests, and the Graph, Costpoint, and POF requests in parallel.
4. Pull 2026 PR approval dates from Costpoint and filing dates from POF this month, so the summary carries a measured baseline.
5. Time three SCAs on three PRs, manual and with Doc Builder.
6. Name a portal owner and identify pilot users.
7. Schedule the TOM validation session before Phase 2a.

---

## Notes on the figures

Every number is one of two kinds. **Confirmed**: stated by the team and recorded in the process baseline, [`fms-procurement-process.md`](fms-procurement-process.md). **Estimate**: a recollection from a working session or the developer's projection, not timed. Phase 1 replaces the estimates with measurements. Dollar figures use an assumed $75/hr loaded SCA rate and $150/hr developer rate; finance should replace both.

| # | Figure | Source | Confidence |
|---|---|---|---|
| 1 | 7-business-day turnaround; 125 PRs/month goal | Program goal, confirmed in the team working session (baseline §9). Business vs. calendar days is an open item (§11) | Confirmed |
| 2 | ~30 PRs a month, 2026 average | 261 PRs January to mid-October 2026 (§9) over ~9.5 months. Most arrived May–July, so the average hides batches | Confirmed count; derived rate |
| 3 | PR waits up to ~7 business days for first review; 3-day goal | Baseline §9, team recollection; §11 notes "actual measurements still needed" | Estimate |
| 4 | ~8 awards a day per buyer | Baseline §9, one buyer, no interruptions | Confirmed |
| 5 | Queue time hours to days; touch time 2–3 hr per PR | Queue: §7 ladder, steps 3, 5, 6, 15. Touch: August 2026 value stream map ~2.5–3.25 hr per TT&E award (§8); team's own estimate ~1–1.5 hr; unreconciled in §9 | Estimate |
| 6 | 11 of 16 steps rest on undocumented knowledge | Baseline §7, analyst classification of the SH ladder | Estimate |
| 7 | Doc Builder saves ~1.5 hr per TT&E PR | Developer estimate from the manual TT&E steps (§8) against what Doc Builder automates. Smaller if the team's lower touch-time figure is right | Estimate, not timed |
| 8 | ~540 hr/year protected at today's volume; 15 min saved on a Shipping Hub memo | 540 = 1.5 × 30 × 12. Shipping Hub: ~1 hr to ~45 min, one user, one document (§5) | Derived; pilot timed |
| 9 | SCA spends 15–30 min re-deriving handoff context | Baseline §3 and P-12 describe the problem; the minutes are from TOM interviews, pending validation | Estimate |
| 10 | Rework loops, missed confirmations, tracker lag | Baseline §10 problems P-1, P-5, P-12, P-19; frequencies are open questions in §11 | Confirmed to occur; frequency unknown |
| 11 | Document retrieval ~50% of process time; ~0.5 hr/PR saved by shared intake | Baseline §9, marked "estimate only" (P-15) | Estimate |
| 12 | Issue TO ~20 min; POF folder ~10 min | Baseline §7 and §8 ladders | Estimate |
| 13 | ~370 developer hours total; ~80 for the Microsoft 365 alternative; ~3–5× compression with AI-assisted development | Developer estimates from this project to date; the compression figure is the developer's observation, not a benchmark. Phase 1 carries ±50%. The alternative's 80 hours assumes the engine moves to Azure Functions with little change, that standard Power Automate connectors suffice, and that IT grants Graph read permission; if any fails its hours grow toward the portal's | Estimate, ±50% |
| 14 | Portal hosting $180–400/month | Azure East US pay-as-you-go list prices, retrieved October 23, 2026: App Service Linux P1v3–P2v3 $113–226, PostgreSQL Flexible Server B2S–B2ms $50–99 plus ~$5–10 storage, Redis Basic C0–C1 $16–40. Tier choices are the developer's; internal chargeback may differ. Itemized sources: [Appendix C.3](pop-proposal-appendices.md#c3-sources-for-the-cost-figures) | List prices verified; tiers and storage estimated |
| 15 | Microsoft 365 alternative under $10/month; Jira ~$155/month for 12 seats | Azure Functions within its free grant, Table Storage audit log at cents a month; Lists and standard Power Automate connectors included in Microsoft 365; Power BI Pro included on E5, $14/user/month on E3. Jira Standard $8.60 plus Atlassian Guard $4.35 per user. Tenant tier and chargeback model unconfirmed. Sources: [Appendix C.3](pop-proposal-appendices.md#c3-sources-for-the-cost-figures) | List prices verified; tenant facts unconfirmed |
| 16 | Azure Government ~20% above commercial | Azure Retail Prices API, US Gov Virginia, October 23, 2026. Sources: [Appendix C.3](pop-proposal-appendices.md#c3-sources-for-the-cost-figures) | Verified |

---

*Leidos Proprietary — not to be reproduced, disclosed, or exported without written approval of Leidos.*
