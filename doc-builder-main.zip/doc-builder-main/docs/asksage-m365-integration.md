# AskSage M365 Integration — Lessons Learned

> Last updated: 2026-09-09

> **Note:** The AskSage (SharePoint / OneDrive) integration is currently disabled pending approval from the AskSage team (a CORS allowance for the production origin). It is hidden by the `askSage` feature flag in `src/ai/featureFlags.ts`; the code is kept on purpose. See the STATUS block at the top of `src/ai/asksage.ts` for what's needed and how to re-enable it.

## TL;DR

The M365 integration on AskSage (`api.asksage.leidos.com`) uses **hosted MCP tools**, not the `/server/execute-plugin` endpoint. The correct API is `POST /server/query` with:

- **`enabled_mcp_tools`** and **`tools_to_execute`** listing tool names
- **`tools`** array with full definitions including `function_type: "mcp"` and `require_approval: false`
- **Model: `aws-bedrock-claude-45-sonnet-gov`** (Claude on Bedrock/GovCloud — GPT models silently ignore MCP tools)
- **`message`** as a conversation array, not a plain string
- **Response** contains `<mcp-content>` XML tags wrapping JSON in the `message` field

The `require_approval: false` flag in the tool definition is critical — without it, the API enters a two-step approval flow. The reference implementation is the `m365@growth-skills` Claude Code skill at `/home/chuw/code/m365-asksage-claude-skill/`.

---

## Architecture

```
┌───────────────────┐     ┌───────────────────────┐     ┌────────────────────┐
│  Doc Builder SPA  │────▶│  AskSage REST API     │────▶│  Microsoft Graph   │
│  (browser)        │     │  api.asksage.leidos.com│     │  (via hosted MCP)  │
└───────────────────┘     └───────────────────────┘     └────────────────────┘
```

### M365 is NOT a Plugin

The AskSage instance has two systems for external tools:

| System    | Endpoint                  | M365? | Notes |
|-----------|---------------------------|-------|-------|
| **Plugins** | `POST /server/execute-plugin` | ❌ No  | Legacy. Plugins like `SAM_GOV`, `SUMMARIZE`, etc. The `m365` plugin name does not exist. |
| **MCP Tools** | `POST /server/query` + `enabled_mcp_tools` | ✅ Yes | 14 tools via hosted "Microsoft 365" MCP server. |

### Available M365 MCP Tools

Retrieved via `GET /server/list-mcp-tools`:

| unique_id | Tool Name | Description |
|-----------|-----------|-------------|
| `1_list_calendar_events` | `list_calendar_events` | List events from a calendar within a date range |
| `1_create_calendar_event` | `create_calendar_event` | Create a new calendar event |
| `1_update_calendar_event` | `update_calendar_event` | Update an existing calendar event |
| `1_delete_calendar_event` | `delete_calendar_event` | Delete a calendar event |
| `1_cancel_calendar_event` | `cancel_calendar_event` | Cancel a meeting with notices |
| `1_search_calendar_events` | `search_calendar_events` | Search events via Microsoft Search API |
| `1_get_calendar_availability` | `get_calendar_availability` | Get free/busy schedule |
| `1_search_emails` | `search_emails` | Search emails via Microsoft Search API |
| `1_list_emails` | `list_emails` | List emails from a mailbox |
| `1_send_email` | `send_email` | Send an email |
| `1_list_items` | `list_items` | List files and folders |
| `1_search_files` | `search_files` | Search files across OneDrive and SharePoint |
| `1_ms_get_file_content` | `ms_get_file_content` | Retrieve and process file contents |
| `1_get_item_metadata` | `get_item_metadata` | Get detailed metadata for a file/folder |

---

## API Reference (Verified via Testing)

### Endpoint: `POST /server/query`

The `/server/query` endpoint supports both `application/json` and `multipart/form-data` (form-encoded). Both work for sending queries. The Python SDK uses form-encoded; both are valid per the Swagger spec.

#### Parameters (from SwaggerHub spec v1.56)

| Parameter | Type | Description |
|-----------|------|-------------|
| `message` | string or JSON array | Single prompt or conversation history |
| `model` | string | Model name (e.g., `gpt-4.1-gov`) |
| `dataset` | string | Dataset to query (`none` for no RAG) |
| `temperature` | number | Sampling temperature |
| `limit_references` | integer | 0 = no embeddings |
| `tools` | array/string | OpenAI-format tool definitions |
| `tool_choice` | string/object | `auto`, `required`, `none`, or `{"type":"function","function":{"name":"..."}}` |
| **`enabled_mcp_tools`** | array of strings | **MCP tool unique_ids to enable** (e.g., `["1_search_files"]`) |
| **`tools_to_execute`** | array of strings | **Specific tools to execute** (purpose unclear — did not bypass approval in testing) |
| `streaming` | boolean | Enable streaming (text/plain with `@\|@sep@\|@` delimiter) |
| `mode` | string | Completion mode |
| `system_prompt` | string | Override system prompt |
| `reasoning_effort` | string | `low`, `medium`, `high` |
| `live` | integer | Web search mode (0=off) |

#### Response Shape: `CompletionResponse`

```json
{
  "response": "OK",
  "message": "Generated text or null when tool_calls present",
  "uuid": "unique-completion-id",
  "status": 200,
  "tool_calls": [
    {
      "id": "call_abc123",
      "type": "function",
      "function": {
        "name": "search_files",
        "arguments": "{\"query\":\"NDA\"}"
      }
    }
  ],
  "tool_calls_unified": [
    {
      "id": "call_abc123",
      "function_type": "custom",
      "type": "function",
      "function": {
        "name": "search_files",
        "arguments": { "query": "NDA" }
      },
      "require_approval": true
    }
  ],
  "tool_responses": [],
  "references": "",
  "citations": [],
  "sources": [],
  "provenance": { "model": "gpt-4.1-gov", ... },
  "embedding_down": false,
  "vectors_down": false
}
```

### Endpoint: `POST /server/openai/v1/chat/completions`

OpenAI-compatible endpoint. Uses `Authorization: Bearer <token>` instead of `x-access-tokens`. Returns standard OpenAI chat completion format with `tool_calls` in the assistant message, but **does not execute MCP tools server-side** — tool results must be provided by the caller.

---

## Bypassing the Approval Flow

### The Problem (Before Discovering the Reference Skill)

When tool definitions are sent without the right MCP metadata fields, the API returns `require_approval: true` and enters a two-step approval flow. We tested many approaches that all failed:

| Approach | Result |
|----------|--------|
| `tools_to_execute: ["1_search_files"]` (unique_id) | `require_approval: true` |
| `tools_to_execute: ["call_abc123"]` (call ID) | `require_approval: true` |
| Request-level `auto_approve: true` | Parameter ignored |
| Request-level `require_approval: false` | Parameter ignored |
| Conversation continuation with tool approval message | New tool_call generated |
| GPT model (`gpt-4.1-gov`) | Silently ignored MCP tools |

### The Solution (From Reference Skill)

The key is in the **tool definition itself**, not the request parameters. Each tool must include:

```json
{
  "name": "search_files",
  "description": "Search for files and folders across OneDrive and SharePoint.",
  "server_id": 1,
  "server_name": "Microsoft 365",
  "function_type": "mcp",
  "require_approval": false,
  "parameters": { ... }
}
```

The three fields that were missing from our earlier tests:
1. **`function_type: "mcp"`** — tells the server this is a hosted MCP tool (not `custom`)
2. **`require_approval: false`** — authorizes server-side execution without approval loop
3. **`server_id: 1` / `server_name: "Microsoft 365"`** — identifies the MCP server

Additionally, the **model must be `aws-bedrock-claude-45-sonnet-gov`** (Claude on Bedrock/GovCloud). GPT models do not trigger MCP tool execution.

### Response Format

When MCP tools execute successfully, the results are embedded in the `message` field wrapped in XML tags:

```
<mcp-content>
[{"tool": "search_files", "response": [{"status": "success", "data": [...]}]}]
</mcp-content>
```

Extract the JSON between `<mcp-content>` and `</mcp-content>` tags.

## Reference Implementation

The `m365@growth-skills` Claude Code skill at `/home/chuw/code/m365-asksage-claude-skill/` is the canonical reference. Key files:

| File | Purpose |
|------|---------|
| `scripts/_mcp.py` | MCP tool definitions (lines 26-257), `mcp_call()`, `extract_mcp_content()`, `mcp_query_nl()` |
| `scripts/_client.py` | HTTP transport (urllib), token handling, TLS config |
| `scripts/m365_files.py` | File operations: search, list, get content |
| `scripts/m365_query.py` | Natural language query interface |
| `docs/DISCOVERY.md` | API reverse-engineering notes |

---

## API Endpoints Reference

All endpoints are at `https://api.asksage.leidos.com`.

| Method | Path | Content-Type | Auth Header | Purpose |
|--------|------|-------------|-------------|---------|
| POST | `/user/get-token-with-api-key` | `application/json` | (none) | Get access token |
| POST | `/server/get-models` | `application/json` | `x-access-tokens` | List models |
| GET | `/server/list-mcp-tools` | — | `x-access-tokens` | List MCP tools |
| GET | `/server/list-mcp-servers` | — | `x-access-tokens` | List MCP servers |
| POST | `/server/query` | JSON or form-encoded | `x-access-tokens` | Main query endpoint |
| POST | `/server/execute-plugin` | form-encoded | `x-access-tokens` | Legacy plugin execution |
| POST | `/server/execute-agent` | `application/json` | `x-access-tokens` | Agent execution |
| POST | `/server/openai/v1/chat/completions` | `application/json` | `Authorization: Bearer` | OpenAI-compatible |

## Models

**For MCP tool execution (confirmed working 2026-09-09):**
- `google-claude-46-sonnet` ✅ (tested, works)
- `google-claude-45-sonnet` ✅ (tested, works)
- `aws-bedrock-claude-45-sonnet-gov` ⚠️ (reference skill default, but returning 502 as of 2026-09-09)
- `aws-bedrock-claude-fable-5-1-gov` ⚠️ (also 502 as of 2026-09-09)

**Models that do NOT work for MCP:** GPT models (`gpt-4.1-gov`, etc.) silently ignore `function_type: "mcp"` tools and return text instead. Any Claude model with MCP support should work.

**Recommended fallback order:** Try `google-claude-46-sonnet` first, fall back to `aws-bedrock-claude-45-sonnet-gov`.

**Environment variable override:** `ASK_SAGE_MCP_MODEL` (optional, used by the m365 skill)

---

## Configuration

### Prerequisites
1. AskSage enterprise account (10M+ monthly tokens or dedicated tenant)
2. M365 MCP enabled by AskSage admin (contact support@asksage.ai)
3. User has linked their Microsoft account via AskSage Account settings

### Credentials (stored in localStorage)
- `doc-builder:asksage-email` — Leidos email
- `doc-builder:asksage-api-key` — AskSage API key

### Vite Dev Proxy
```javascript
// vite.config.ts
'/api/asksage': {
  target: 'https://api.asksage.leidos.com',
  changeOrigin: true,
  secure: false,  // self-signed cert
  rewrite: (path) => path.replace(/^\/api\/asksage/, ''),
}
```

### URL Allowlist
`https://api.asksage.leidos.com` is in `src/utils/urlAllowlist.ts`.

---

## Exact Request Format (Verified Working)

### Deterministic MCP Tool Call

From the reference skill's `mcp_call()` — makes the model call a specific tool with specific parameters:

```json
POST /server/query
Content-Type: application/json
x-access-tokens: <JWT>

{
  "message": [
    {"user": "gpt", "message": "I can help you with Microsoft 365 operations."},
    {"user": "me", "message": "Call the search_files tool with exactly these parameters: {\"query\": \"NDA\"}"}
  ],
  "model": "aws-bedrock-claude-45-sonnet-gov",
  "streaming": false,
  "tool_choice": "auto",
  "tools": [
    {
      "name": "search_files",
      "description": "Search for files and folders across OneDrive and SharePoint.",
      "server_id": 1,
      "server_name": "Microsoft 365",
      "function_type": "mcp",
      "require_approval": false,
      "parameters": {
        "type": "object",
        "properties": {
          "query": {"type": "string", "description": "Search query string"},
          "max_results": {"type": "integer", "description": "Maximum number of results"}
        },
        "required": ["query"]
      }
    }
  ],
  "enabled_mcp_tools": ["search_files"],
  "tools_to_execute": ["search_files"],
  "dataset": "none"
}
```

### Natural Language Query (All File Tools)

From `mcp_query_nl()` — lets the model decide which tools to call:

```json
{
  "message": [
    {"user": "gpt", "message": "I can help you with Microsoft 365 operations."},
    {"user": "me", "message": "Find any NDA documents on SharePoint"}
  ],
  "model": "aws-bedrock-claude-45-sonnet-gov",
  "streaming": false,
  "tool_choice": "auto",
  "tools": [ /* all file tool definitions */ ],
  "enabled_mcp_tools": ["search_files", "list_items", "ms_get_file_content", "get_item_metadata"],
  "tools_to_execute": ["search_files", "list_items", "ms_get_file_content", "get_item_metadata"],
  "dataset": "none"
}
```

### Success Response Shape

```json
{
  "response": "OK",
  "message": "\n\n<mcp-content>\n[{\"tool\": \"search_files\", \"response\": [{\"status\": \"success\", \"data\": [...]}]}]\n</mcp-content>\n\n...",
  "status": 200,
  "tool_calls": [...],
  "tool_calls_unified": [...],
  "tool_responses": [...]
}
```

### MCP Content Extraction

```typescript
function extractMcpContent(message: string): unknown[] | null {
  const start = message.indexOf("<mcp-content>");
  const end = message.indexOf("</mcp-content>");
  if (start === -1 || end === -1) return null;
  const json = message.slice(start + "<mcp-content>".length, end).trim();
  return JSON.parse(json);
}
```

---

## Debugging Checklist

When M365 tool calls fail, check in this order:

1. **Empty/null message with `require_approval: true`** → Tool definitions missing `function_type: "mcp"` or `require_approval: false`
2. **`"Internal error, please contact customer support"` with `error.code: "model_error"` and `error.http_status: 502`** → The model's backend is down. Try a different Claude model (see Models section above). This is transient.
3. **Model silently ignores tools (returns text response, no tool_calls)** → Wrong model. Must be a Claude model, not GPT. GPT models silently ignore `function_type: "mcp"` tools.
4. **"Internal error with the MCP server"** → Wrong parameter names. Use exact names from tool schemas (e.g., `item_id` not `file_id`, `to_recipients` not `to`)
5. **Empty response from `/execute-plugin`** → Wrong endpoint. M365 uses `/server/query`, not `/execute-plugin`
6. **No `<mcp-content>` in response** → Check `tool_calls_unified` for `function_type: "custom"` (should be `"mcp"` — means the tool def is wrong)
7. **`oauth_status` not `"connected"`** → User hasn't linked Microsoft account in AskSage. Check via `GET /server/list-mcp-servers`
