**LEIDOS PROPRIETARY**

---

# Doc Builder — Progress Update (July 16–30)

## Development

| Area | What shipped | Why |
|---|---|---|
| **AI Drafting Engine** | Conversational chat interface replaces one-shot extraction; AI proposes changes via structured tool calls; chat history persists | Eliminates brittle XML parsing; lets SCAs iterate with the AI instead of re-running from scratch |
| **Client-Side RAG** | Upload reference docs → chunk → embed → retrieve at draft time (hybrid: small docs inline, large docs vector-retrieved) | Real procurement packages exceed prompt limits; RAG handles arbitrarily large source sets |
| **Table Fields** | Schemas support tabular data — editable grids, .docx table export | FMS templates (PWS, pricing memos) are table-heavy; couldn't model them without this |
| **Linked Fields** | A field entered once auto-populates everywhere it's referenced | Prevents inconsistency — party names, contract numbers, dates appear in 3–7 places per package |
| **Document Set Builder** | Generate an entire package (3–4 coordinated docs) from one session | A single procurement action produces multiple documents that share data — generating individually was error-prone |
| **Schema Agents** | Claude Code agents read a .docx template → produce a schema automatically | Manually authoring schemas from 20-page Word templates was the #1 onboarding bottleneck (~4 hrs → ~1 hr) |
| **7 New FMS Schemas** | TT&E proposal/award/PWS, SH PWS, price reasonableness memos | Covers both complete procurement workflows (TT&E = 3 docs, SH = 4 docs) |
| **Role Selector** | Users pick their role → homepage shows only relevant document types | 9 schemas is too many to browse; roles scope what you see |
| **Testing (0 → full)** | Unit tests, 20+ component specs, Playwright E2E (7 specs), CI fix | Needed to catch nav/state bugs that only surface in real browser flows |

---

## Value Stream Mapping & Proposal

| Activity | Status |
|---|---|
| Mapped TT&E end-to-end workflow (source intake → issuance → tracker) | ✅ Complete — documented in `fms-procurement-process.md` |
| Mapped SH end-to-end workflow (PWS receipt → 4-doc package → issuance) | ✅ Complete |
| Drafted phased proposal (`pop-proposal.md`) — zero-risk, gate-before-invest | ✅ Complete — ready for review |
| Separated TOM workflow capabilities into companion doc (pending validation) | ✅ Complete |
| LMG API keys requested for SCA team | ⏳ Pending — expect access next week |

**Immediate blocker:** Need one complete source package (all docs/emails for a single TO) + filled templates to start Phase 1 validation.

---

# Procurement Operations Portal — Proposal Summary

## 🎯 Problem

FMS SCAs spend **80–90 min per Task Order** manually transcribing data from source documents into Word templates. At ~125 TOs/month = **170–190 hours/month** of manual data entry.

## 💡 Solution

Schema-driven AI workflow tool — upload source documents → AI extracts & fills templates → SCA reviews (not enters) → one-click document generation. Covers both TT&E (3 docs) and SH (4 docs) workflows.

## 📐 Phased Approach

| Phase | Timeline | Cost | Proves |
|---|---|---|---|
| **1 — Prove the Engine** | 1–2 weeks | $0 | AI extracts fields at ≥80% accuracy |
| **2 — Deliver the Workflow** | 4–6 weeks | $0 | Measurable time reduction on live TOs |
| **3 — Full Portal** | 10–14 weeks | ~$150–400/mo | System integrations automate the rest |

Each phase gates the next. Investment follows demonstrated results.

## ✅ What Exists Today

Working prototype deployed (Doc Builder) — AI extraction, guided interview, document generation, AI writing assistant. **9 FMS schemas** configured covering both TT&E and SH. Needs testing on real data.

## 🙋 Immediate Ask

**One complete source package** (all documents/emails for a single TO) + corresponding filled templates. No cost, no approvals, no infrastructure. Results in 1–2 weeks.

---

# Next Steps

| # | Action | Why | Target |
|---|--------|-----|--------|
| 1 | **Obtain a test package** — one complete set of source docs + corresponding filled templates for a single TO | Enables Phase 1 accuracy measurement (target ≥80% field extraction) | Next 1–2 weeks |
| 2 | **Continue app development** | Expand capability and fix rough edges | Ongoing |
| 3 | **Review value stream map** with process owners — map automation levels to concrete hours-saved estimates | Converts qualitative "saves time" into a defensible business case | Before Phase 2 gate |

### Development priorities (item 2)

- **Excel input** — import field values from .xlsx uploads (users maintain data in spreadsheets today)
- **Excel output** — export session answers to .xlsx for downstream workflows
- **Validation layer** — required-field checks, type constraints, block export with missing data
- Bug fixes as discovered during real-data testing

---

*Leidos Proprietary — not to be reproduced, disclosed, or exported without written approval of Leidos.*
