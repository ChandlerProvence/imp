# Fix bugs found by the Phase 0 tests

## Context

The code-quality Phase 0 tests, added 2026-10-22 on branch `worktree-sustainment-asksage-tests`, describe what the code does today. Where today's behavior looked wrong, the tests record the correct behavior as `it.fails` or `it.todo` instead of changing the source. This plan fixes those bugs.

Fix them before code-quality Phase 2 (`docs/2026-10-08-code-quality-plan.md`). The refactor phases are supposed to change no behavior, so they should start from a baseline where these bugs are already gone.

**How each fix works:**
- Turn the `it.fails` / `it.todo` into a normal `it`. It must fail before the fix and pass after.
- Remove or update any characterization test that recorded the buggy behavior. Search the test file for "today:".
- Follow the CLAUDE.md error rules: `toAppError` / `appErrorException`, with wording in `catalog.ts`.

**Delivery:** one branch and one MR, with one commit per bug. The fixes are small and independent, so each can be reverted alone.

| # | Bug | Where it shows up | Priority | Estimate |
|---|---|---|---|---|
| 1 | Thinking deltas never reach `onThinking` | AI chat on the Thorough tier | P1 | 1 hr |
| 2 | The `promptCaching` flag is ignored on streaming calls | Proxies that reject `cache_control` | P2 | 0.5 hr |
| 3 | Download All overwrites set members with the same filename | Document-set zip | P1 | 0.5 hr |
| 4 | `useTokenEstimate` throws away the first API count | Context meter in the chat panel | P2 | 0.5 hr |
| 5 | `useTokenEstimate` leaves a rejected `countTokens` uncaught | Console and global error handler | P2 | 0.5 hr |
| 6 | HTML entities are decoded twice | Review prompt and template text | P3 | 0.5 hr |

Total: about 3.5 hr, plus a manual check.

---

## 1. Thinking deltas never reach `onThinking` [P1]

**Where:** [src/ai/litellm.ts](../src/ai/litellm.ts), in `streamChatCompletion`, around lines 589–623.

**What happens:**
- The stream registers `(stream as any).on("event", …)` to catch raw SSE events.
- In `@anthropic-ai/sdk` 0.116 the `MessageStream` emits raw events as `"streamEvent"` (`MessageStream.d.ts:8`). It never emits `"event"`. The `as any` cast is what hid the mismatch from the type checker.
- So `content_block_start` and `thinking_delta` events are never seen, and `onThinking` never fires.
- In `useAiChat`, `onThinking` is what sets `isThinking` and starts the "thinking" timing step. On the Thorough tier (`enableThinking: true` in `effortTiers.ts`), the "Thinking…" indicator never appears, and the time spent thinking is counted in the next step. `onThinkingDone` still fires through `"contentBlock"`, so nothing gets stuck on.
- **Side effect:** the raw-event listener is also what resets the stream timeout for events that aren't text (both branches). Today only `"text"` and `"contentBlock"` reset it. The timeout is 24 hours, so this is harmless now, but it would matter if anyone shortened `STREAM_CHUNK_TIMEOUT_MS`.

**Fix:**
- Listen on `"streamEvent"`, which has the typed signature `(event: MessageStreamEvent, snapshot)`, and drop both `as any` casts and their `eslint-disable` lines.
- Narrow on `event.type`, `event.content_block.type` and `event.delta.type` with the SDK types.
- Keep the `"contentBlock"` handler for `onThinkingDone`.
- Keep the listener-only branch that resets the timeout, using `"streamEvent"` too.

**Portability:** the event name is SDK-specific, but this code is already in the SDK-specific layer, the future `anthropicMessages` provider (*High-side portability* Phase 4). Nothing leaks into shared code.

**Tests** (in `src/ai/litellm.chat.test.ts`):
- Change `it.fails("streams thinking deltas to onThinking")` to `it`.
- `fakeStream` in `src/test/mockAnthropic.ts` already emits `"streamEvent"`, like the real SDK, so the mock needs no change. That is why the test fails today.
- Add a test that a raw event with no text resets the stream timeout. Use a short `streamTimeout` and fake timers.

**Manual check:** in `npm run dev`, start a chat on the Thorough tier. "Thinking…" should appear before the answer, and the timing breakdown should show a thinking step.

## 2. The `promptCaching` flag is ignored on streaming calls [P2]

**Where:** `litellm.ts:510`, `const enableCaching = options?.enableCaching !== false;`.

**What happens:**
- `translateMessages` falls back to `isFeatureEnabled("promptCaching")` only when `enableCaching` is `undefined`. `streamChatCompletion` always passes a boolean, and it passes `true` unless the caller explicitly says `false`.
- So turning off the flag, by hand or with a session auto-disable, doesn't stop `cache_control` on chat streams, which are the main AI path. `fetchChatCompletion` and `countTokens` do respect the flag.
- The flag is the escape hatch for a proxy that rejects `cache_control` (CLAUDE.md, provider portability), so this matters for LiteLLM backends that aren't Anthropic.

**Fix:** pass `options?.enableCaching` through unchanged, so `undefined` falls back to the flag. Check that no caller relies on caching being forced on when the flag is off: `grep enableCaching` shows only the type and `litellm.ts`.

**Tests:** in `litellm.chat.test.ts`, change `it.fails("honours the promptCaching flag when enableCaching is not given")` to `it`. Add a case that an explicit `enableCaching: true` still wins over the flag being off. That is the current contract of `translateMessages`, so keep it.

## 3. Download All overwrites set members with the same filename [P1]

**Where:** [src/generation/downloadAll.ts](../src/generation/downloadAll.ts), the loop around `zip.file(...)`.

**What happens:**
- `resolveOutputFilename` can return the same name for two members. Examples: two schemas whose `output_filename` patterns depend on the same answers, or the fallback name when answers are empty.
- `zip.file` replaces the earlier entry, but `successCount` counts both. The user gets one fewer document than the set has and no error.

**Fix:**
- Keep a `Set` of names already used in the zip. When a name repeats, add ` (2)`, ` (3)`, and so on before the extension, the same convention a browser uses for downloads.
- This is not an error, so nothing is added to the catalog.
- Apply the check to both the `.docx` and `.md` branches. Compare the full name including the extension, so `Memo.docx` and `Memo.md` don't count as duplicates.

**Tests:** in `downloadAll.test.ts`, change `it.fails("keeps both documents when two members resolve to the same filename")` to `it`, and check that the entries are `Name.docx` and `Name (2).docx`. Add a case with three duplicates.

## 4. `useTokenEstimate` throws away the first API count [P2]

**Where:** [src/hooks/useTokenEstimate.ts](../src/hooks/useTokenEstimate.ts), the "Update local estimate immediately" effect.

**What happens:**
- The effect depends on `[localEstimate, source]`.
- When the first API count arrives, `setSource("api")` changes `source`. The effect runs again and `setTokens(localEstimate)` overwrites the API count. Now `source` says `"api"` but `tokens` holds the estimate.
- Later counts stick, because `source` doesn't change again.
- In the chat panel's context meter (`AiPanelChat.tsx:71`), the first accurate count after a change of conversation is replaced by the rougher estimate.

**Fix:**
- Make the effect depend on `localEstimate` only.
- Use a functional update for the idle → estimate transition: `setSource((s) => (s === "idle" ? "estimate" : s))`.
- Decide what `source` should be when messages change after an API count. The local estimate should show at once, so set `source` back to `"estimate"` until the next count arrives; otherwise the meter claims "api" for a number that's only an estimate. Write the chosen behavior into the hook's doc comment.

**Tests:** in `useTokenEstimate.test.ts`, change `it.fails("replaces the estimate with the first API count")` to `it`. Delete the "today: the first API count is overwritten…" characterization test. Add a test that a message change after an API count shows the estimate with `source: "estimate"`.

## 5. `useTokenEstimate` leaves a rejected `countTokens` uncaught [P2]

**Where:** the same hook, in the debounced callback. Also `countTokens` in `litellm.ts:702`.

**What happens:**
- `countTokens` catches errors from the API call, but `translateMessages`, `translateTools` and the `new Anthropic(...)` construction all run before its `try`.
- If any of them throws, the hook's `await` rejects with no handler. The global `unhandledrejection` handler (`errors/globalHandlers.ts`) records it, and the meter keeps its old value.
- Example: a message shape that `translateMessages` doesn't expect.

**Fix:** do both, as belt and braces:
- **(a)** In `countTokens`, move the `try` up so it covers the client construction and the translation. Fall back to `{ source: "estimate" }` in the same way the existing catch does.
- **(b)** In the hook, wrap the `await` in `try`/`catch`. On failure, keep the local estimate (`setTokens(localEstimate)`, `setSource("estimate")`).
- Also guard against a state update after unmount, or after a newer debounce has started. A generation counter or an `active` flag in the effect cleanup is enough.

**Tests:**
- Replace `it.todo("falls back to the local estimate when countTokens rejects")` with a real test. The agent found that asserting on unhandled rejections inside fake timers was flaky. The fix makes that unnecessary: assert that `tokens` equals the local estimate and `source` is `"estimate"` after `vi.advanceTimersByTimeAsync(1000)` with `countTokens` mocked to reject.
- Add a `litellm.chat.test.ts` case where `translateMessages` throws inside `countTokens` (pass a malformed message), and check that it returns the estimate.

## 6. HTML entities are decoded twice [P3]

**Where:** `stripHtmlTags` in [src/ai/documentReviewPrompt.ts](../src/ai/documentReviewPrompt.ts) (around line 148), and the private `htmlToTemplateText` in [src/ai/templateTextService.ts](../src/ai/templateTextService.ts) (around line 135).

**What happens:**
- Both decode `&amp;` before `&lt;`, `&gt;` and the others. So `&amp;lt;`, which is the encoding of a literal `&lt;`, becomes `<` instead of `&lt;`.
- The effect is small. A document that literally contains `&lt;` text reaches the AI review prompt or the template-text tools as `<`. It isn't a security issue: the output is plain text that goes into a prompt, not into the DOM.

**Fix:**
- Decode in a single pass: `.replace(/&(amp|lt|gt|quot|#39|nbsp);/g, (_, e) => MAP[e])`. Equivalently, decode `&amp;` last.
- Put the decoder in one small shared helper, for example `decodeBasicEntities` in `src/ai/promptUtils.ts`, and use it from both modules so they can't drift apart.
- Don't switch to `DOMParser`. These functions are also used where a DOM may not exist (`tools/render-docx.ts` runs under tsx).

**Tests:** in `documentReviewPrompt.test.ts`, change `it.fails("decodes an escaped entity only once")` to `it`. Add a matching case to `templateTextService.test.ts` that goes through a public query function.

---

## Verification

- `npm run typecheck`, `npm run lint` with no new warnings (fix 1 removes two `eslint-disable` lines), and `npm test`. The six expected-fail entries should be gone, leaving 0 `it.fails` in these files.
- In `npm run dev`:
  - **Thorough tier:** "Thinking…" shows while the model thinks.
  - **Download All:** on a set where two members resolve to the same filename, the zip has both files. To set this up, clear the answers that drive `output_filename`.
  - **Context meter:** it settles on the API count after about 1 second, and it doesn't drop back to the estimate.
  - **Caching off:** run `localStorage.setItem("doc-builder:ai-feature-flags", '{"promptCaching":false}')`. In DevTools → Network, the chat request then has no `cache_control`.

## Documentation step

After the fixes ship, ask the user whether to update `changelog.d/`, `README.md` and `docs/public/development-plan.md`, which marks *Fix bugs found by the Phase 0 tests* done. Do not run `/update-docs` automatically.
