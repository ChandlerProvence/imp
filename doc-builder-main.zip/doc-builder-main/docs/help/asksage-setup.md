# SharePoint Setup

> **Note:** The AskSage (SharePoint / OneDrive) integration is currently disabled pending approval from the AskSage team. The steps below will apply once it is re-enabled.

The SharePoint integration lets you search and attach reference documents from your organization's SharePoint and OneDrive. It connects through AskSage. This is separate from the [AI assistant](api-key-setup), which handles extraction, drafting, and other AI features.

Follow the steps below — they must be done in order because each one depends on the previous.

---

## Step 1: Request AskSage Access

1. Submit the [AskSage Onboarding and Attestation form on CIO Central](https://prism.leidos.com/ai_hub/asksage/asksage_wiki_library/asksage_onboarding_guide)
2. Wait for the approval email from CIO Central — new users cannot sign in until the form is approved
3. After approval, allow **30–60 minutes** for your account credentials to finish propagating across the system. During this time you may not be able to sign in.

> **Important:** Do not proceed to Step 2 until you have received the approval email and waited for credentials to propagate. Skipping ahead produces errors that look like broken settings rather than missing access.

---

## Step 2: Sign In to AskSage

1. Go to [chat.asksage.leidos.com](https://chat.asksage.leidos.com)
2. Click **Sign in with your Enterprise SSO**
3. If a "Select a certificate" pop-up appears, select **Cancel**
4. Select the Microsoft account associated with your **Leidos email address**

---

## Step 3: Complete MFA Setup

After your first sign-in, AskSage requires multifactor authentication (MFA). Follow the prompts in **Settings → Account** to register Microsoft Authenticator or a Yubikey/hardware device.

> For detailed MFA setup instructions, see the [AskSage Onboarding Guide on Prism](https://prism.leidos.com/ai_hub/asksage/asksage_wiki_library/asksage_onboarding_guide).

---

## Step 4: Create an API Key

1. Click **your name** in the lower-left corner of the screen → **Settings** → **API Keys**
2. Click **+ Create Key** and give it a name you will recognize later (e.g., "doc-builder")
3. Copy the generated value — this is your AskSage JWT

> **Tip:** You can return to the API Keys page at any time to view, create, or revoke keys.

---

## Step 5: Enter Credentials in Doc Builder

1. Open Doc Builder
2. Go to **Edit → [Settings](#open-settings:asksage)** in the menu bar
3. Scroll down to the **AskSage (SharePoint)** section
4. Enter your **Leidos email** in the email field
5. Paste your **API key** (the JWT from Step 4) into the API key field
6. Click the **Test** button — you should see a green **✓ Connected** message
7. Click **Save**

SharePoint search will now be available when attaching reference documents.

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Test button shows a red error | Double-check that you are using the same email you registered with and that the token has not expired |
| Options not visible in Settings | Make sure you are on the **Account** tab (Step 4) |
| Cannot sign in at all | Your access request may not be approved yet, or credentials are still propagating — see Step 1 |

---

## References

- [AskSage Onboarding Guide (Prism)](https://prism.leidos.com/ai_hub/asksage/asksage_wiki_library/asksage_onboarding_guide)
- [How to Read Your Email and Calendar via AskSage (Prism)](https://prism.leidos.com/growth_office/growth_initiatives/growth_transformation_office/generative_ai_wiki_articles/how_to_read_your_email_and_calendar_via_asksage)

---

## Tips

- You only need AskSage credentials if you want to search and attach SharePoint / OneDrive files. The core AI drafting features use a separate key — see the [AI Assistant Setup](api-key-setup) help topic.
- Credentials are stored in your browser's local storage and are sent only to the AskSage API — never to any other server.
