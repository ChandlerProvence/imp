# Interview Navigation

The interview interface guides you through document sections one at a time, with a sidebar showing your progress.

---

## Section Outline (Left Sidebar)

The sidebar lists all sections in your document. Each section shows a status indicator:

| Symbol | Status | Meaning |
|--------|--------|---------|
| ○ | Empty | No fields in this section have been filled |
| ◐ | In progress | Some fields have values, but not all |
| ✓ | Complete | All required fields in this section are filled |

Click any section in the sidebar to jump directly to it.

---

## Footer Navigation

At the bottom of the interview form:

- **← Previous** — Go back one section
- **Next →** — Advance to the next section
- **Review** — Appears on the last section; takes you to the review page

You can navigate freely between sections — there's no requirement to complete them in order.

---

## Field Types

Different fields appear with different input controls:

- **Text** — Single-line input for short values (names, titles, dates)
- **Freetext** — Multi-line textarea for paragraphs (eligible for AI drafting)
- **Enum** — Dropdown menu with predefined options
- **Boolean** — Yes/No toggle
- **Number** — Numeric input
- **Date** — Date picker

Fields marked as required show an asterisk (*) and must be filled before the document can be generated.

---

## Section Focus (✨)

Each section in the sidebar has a ✨ wand button. Clicking it:
1. Opens the AI panel (if closed)
2. Sets the AI scope to that section
3. Positions you to ask the AI for help with that section's fields

See [Focus & Scope](focus-and-scope) for more details.

---

## Tips

- Use the status indicators to quickly spot which sections still need work.
- You can jump between sections freely — answers are saved automatically as you type.
- For freetext fields, click the field's ✨ focus button and ask the AI to draft content for you.
- The Review page at the end shows all your answers together so you can verify everything before generating the document.
