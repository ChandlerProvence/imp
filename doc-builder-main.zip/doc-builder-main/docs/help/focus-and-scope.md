# Focus & Scope

The ✨ focus buttons let you quickly point the AI assistant at a specific part of your document without manually adjusting scope settings.

---

## Focus Buttons

Focus buttons appear as small ✨ wand icons throughout the interview interface. Clicking one opens the AI panel (if closed) and sets the scope to that level.

### Document-level focus
- **Location:** Interview header toolbar
- **Effect:** Sets scope to "Entire Document" and opens the AI panel
- **Use when:** You want to ask the AI about the document as a whole

### Section-level focus
- **Location:** Next to each section name in the sidebar outline
- **Effect:** Sets scope to that specific section
- **Use when:** You want help with all the fields in a particular section

### Field-level focus
- **Location:** Next to individual fields in the form
- **Effect:** Sets scope to that single field
- **Use when:** You want the AI to draft or refine one specific field value

---

## How Focus Relates to Scope

The focus buttons are shortcuts that change the **scope selector** in the AI panel header. After clicking a focus button, you can still manually adjust the scope dropdown if needed.

The AI uses the active scope to decide:
1. Which fields and answers to include in its context
2. Which field(s) it can write to when generating a draft
3. How to interpret your instructions (broad vs. targeted)

---

## Tips

- Use section-level focus when starting work on a new section — it keeps the AI answers relevant without manually switching scope.
- After clicking a field focus button, you can immediately type a prompt like "draft this" and the AI knows exactly which field to write.
- The scope stays set after you use a focus button — if you send multiple messages, they'll all use that same scope until you change it.
