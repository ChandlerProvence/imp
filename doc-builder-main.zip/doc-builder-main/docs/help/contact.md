# Contact & Feedback

Have a question, found a bug, or have an idea to make Doc Builder better? I'd love to hear from you.

---

## Get in Touch

**Winston Chu**
Email: [winston.chu@leidos.com](mailto:winston.chu@leidos.com)

---

## 📬 Update Notifications

Want to hear about new features, new document types, and fixes? Email me to join the Doc Builder mailing list. Use the subject line **[Doc Builder] Add me to the update mailing list**, or [click here to open a prefilled email](mailto:winston.chu@leidos.com?subject=%5BDoc%20Builder%5D%20Add%20me%20to%20the%20update%20mailing%20list). You can also choose **Help → Get Update Notifications…** from the menu bar.

---

## What to Send

### 🐛 Bug Reports

If something isn't working as expected, please include:

- What you were trying to do
- What happened instead
- The document type / schema you were using (if applicable)
- Your browser (e.g., Chrome 126, Edge 125)
- Any error messages you saw (screenshots are helpful!)

### 💡 Feature Requests

Have an idea that would make your workflow easier? Tell me:

- What problem you're trying to solve
- How you'd like it to work
- How often you run into this need

All suggestions are welcome — from small quality-of-life improvements to entirely new document types.

### ❓ Questions & Help

If the [Help topics](/docs/help/api-key-setup) don't answer your question, just reach out. No question is too small.

---

## Response Time

I aim to respond within one business day. For urgent issues that are blocking your work, mention "urgent" in the subject line.
