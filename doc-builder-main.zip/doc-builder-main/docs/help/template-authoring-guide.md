# Template Authoring Guide (for AI assistants)

## For you

**You may not need this guide.** Doc Builder can build and edit a schema itself:

- If your Word file already has `{{TAGS}}`, open **File › Manage Custom Templates › Add template…**, add the Word file on its own, and click **Build the schema from the tags**.
- To change the labels, types, sections, or choices of an official template, choose it under **Modify an official template** and click **Edit in app**.
- To change one of your own templates, click **Edit** on its row.

The Help page *Building and Editing Templates in the App* explains the editor. Use this guide when you want a chatbot to change the Word file, turn a finished document into a template, or change advanced settings the editor can't.

Doc Builder fills in a **Word template** (`.docx` with `{{TAGS}}`) using answers collected by a **schema** (`.schema.json`). You can change either with an AI chatbot:

1. Download a template from **File › Manage Custom Templates**: either "Modify an official template" or "Download for editing" on one of yours. You can also start from your own Word document.
2. Give your chatbot this guide, the `.schema.json`, and the `.docx`, then describe the change you want.
3. Apply the Word changes it lists, save its schema JSON as the `.schema.json` file, and drop both files on **Manage Custom Templates › Add template**.
4. If the upload reports problems, click **Copy for your AI assistant**, paste the result into the chat, and repeat.

Everything below is written for the chatbot.

---

## Instructions for the AI assistant

You are helping a user edit or create a Doc Builder template. Follow this guide exactly; the upload checks are strict.

### What to return

1. **The complete schema as JSON** in a single code block. Never return a partial schema or a diff — the user will save your block as the file.
2. **The Word changes** as numbered steps the user can follow in Word: the exact text to find, the exact replacement, and where each `{{TAG}}` goes. To change existing text, prefer Word's **Find and Replace**; to add a line, tell the user where to press Enter and to type the whole tag in one go (and undo any AutoCorrect change). Either way each tag stays in one piece.
   - Only if you can run code and edit `.docx` files directly (for example with python-docx) may you return an edited file instead. Every `{{TAG}}` must sit inside a single run, and nothing else in the document may change.
3. A short summary of what changed, for the user to check.

### How the pieces connect

A tag in the Word file is filled from a field in the schema:

```
Word:      Vendor: {{VENDOR}}
Schema:    "template_key_map": { "VENDOR": "parties.vendor_name" }
                                             └─ section id ─┘└─ field id ─┘
           "sections": [ { "id": "parties", "fields": [ { "id": "vendor_name", ... } ] } ]
```

- Every tag in the Word file must appear in `template_key_map` (or `content_blocks`, see below). Column tags inside a table loop are the exception — see **Tables**.
- Every `template_key_map` key must appear as a tag in the Word file.
- Every `template_key_map` value must be an existing `"section_id.field_id"`.

### Placeholder syntax in Word

| Syntax | Use |
|---|---|
| `{{TAG}}` | Insert a value. Tag names use letters, digits, and `_` (convention: UPPER_SNAKE_CASE). |
| `{{#ROWS}}` … `{{/ROWS}}` | Repeat a **table row** once per row of a `table` field. Put `{{#ROWS}}` in the first cell and `{{/ROWS}}` in the last cell of the same row; put column tags in the cells between. |
| `{{#BLOCK}}` … `{{/BLOCK}}` | Show the enclosed text only when the content block `BLOCK` is true. |
| `{{TAG: hint text}}` | Optional. The hint is removed on upload and becomes the field's `ai_hint`. |

Rules:
- A **freetext** tag must be alone in its own paragraph — the whole paragraph is replaced by the drafted text.
- Headers and footers may only contain tags for simple fields (string, number, date, enum, boolean).
- If a **required** field is left empty, its `{{TAG}}` stays visible in the generated document. Optional empty fields print nothing.

### Schema format

```json
{
  "id": "vendor-letter",
  "title": "Vendor Letter",
  "version": 1,
  "docx_template": "vendor-letter.docx",
  "sections": [ { "id": "...", "title": "...", "fields": [ ... ] } ],
  "template_key_map": { "TAG": "section_id.field_id" }
}
```

Every field has `id`, `label`, `type`, and `required` (true/false). Field types:

| `type` | Stores | Notes |
|---|---|---|
| `string` | Short text | |
| `number` | A number | Optional `"format"`: `"currency"` (prints `12,300.00` — put the `$` in the Word text), `"number"`, or `"integer"`. |
| `boolean` | Yes/No checkbox | Prints `Yes` or `No`. Often used to switch a content block on or off. |
| `date` | A date | Optional `"display_format"`: `"MM-DD-YYYY"` (default), `"YYYY.MM.DD"` (2028.06.28), `"long"` (June 28, 2028), `"short"` (Jun 28, 2028). |
| `enum` | One choice | Requires `"options": ["A", "B"]`. Prints the chosen option. |
| `multiselect` | Several choices | Requires `"options"`. Use it to drive content blocks (`contains`); don't map it to a tag — it prints as raw data. |
| `freetext` | Multi-paragraph text | The AI assistant in Doc Builder can draft it; add an `"ai_hint"` describing what to write. Tag must be alone in its paragraph. |
| `table` | Rows of columns | Needs `"columns"` (each with `id`, `label`, `type` of `string`, `number`, `date`, `enum`, or `boolean`). Map the loop tag to the table field, and map column tags with `template_column_map`. |
| `image` | A picture | The tag is replaced by the uploaded image. Put the tag alone in its paragraph. |

**Tables.** For a Word row `{{#ITEMS}}{{ITEM_DESC}} | {{ITEM_QTY}}{{/ITEMS}}`:

```json
"template_key_map":    { "ITEMS": "pricing.items" },
"template_column_map": { "ITEMS": { "ITEM_DESC": "description", "ITEM_QTY": "quantity" } }
```

where `pricing.items` is a `table` field whose `columns` include ids `description` and `quantity`. If a loop has no `template_column_map` entry, its column tags must be exactly the column ids (e.g. `{{description}}`) — leave existing loops that work this way as they are.

**Conditional content.** `content_blocks` names a block and when it's on. Use the name in `{{#NAME}}…{{/NAME}}` in Word, and optionally as `"visible_when": "NAME"` on a section or field so the interview hides it too:

```json
"content_blocks": {
  "HAS_WARRANTY": { "when": { "field": "terms.includes_warranty", "is_truthy": true } }
}
```

Each `when` names one `field` and exactly one operator: `contains` (multiselect includes a value), `equals`, `not_equals`, `is_truthy` (true when the field has any value — works for any field type), `gte`, or `lt` (numbers). Block names are not added to `template_key_map`.

To hide whole lines — for example a `PO Number: {{PO}}` label line when the optional PO field is empty — put `{{#HAS_PO}}` alone on the line above and `{{/HAS_PO}}` alone on the line below, with `"HAS_PO": { "when": { "field": "…po_number", "is_truthy": true } }`. Those marker lines disappear from the output. If both markers are on the same line as the text, the text is hidden but an empty line is left.

**File name.** Optional `"output_filename": "Vendor Letter - {{parties.vendor_name}}"` — placeholders here use `section_id.field_id`.

**Calculated values** (reference only — see *Advanced features* below before changing one). A `number` field or table column with a `"formula"` is calculated and read-only. `"format"` works as for any number, `"decimals"` (0–6, default 2) sets the digits for `currency` and `number`, and `"display": "abs"` on a field prints the value without its sign while conditions still see it. Schema-level `"constants": { "TAX_RATE": 0.06 }` names numbers formulas can use.

```json
"constants": { "TAX_RATE": 0.06 },
"sections": [ { "id": "pricing", "title": "Pricing", "fields": [
  { "id": "items", "label": "Items", "type": "table", "required": true, "columns": [
    { "id": "qty", "label": "Qty", "type": "number" },
    { "id": "unit_price", "label": "Unit price", "type": "number", "format": "currency" },
    { "id": "line_total", "label": "Line total", "type": "number", "formula": "qty * unit_price", "format": "currency" }
  ] },
  { "id": "total", "label": "Total with tax", "type": "number", "required": true,
    "formula": "SUM(items.line_total) * (1 + TAX_RATE)", "format": "currency" }
] } ]
```

A formula uses `+ - * / ^` and parentheses (no leading minus: write `0 - x`), numbers, and `COALESCE(a, b, …)` (first value that isn't empty) and `ABS(x)`. What a name can refer to depends on where the formula is:

| Formula on | A bare name `x` | `section.field` | `SUM` / `AVG` / `MIN` / `MAX` / `COUNT` |
|---|---|---|---|
| table column | another number column of the same table, or a constant | not allowed | not allowed |
| field | a number field in the same section, or a constant | any number field | `SUM(table.column)`; `COUNT(table)` counts rows, `COUNT(table.column)` counts filled cells; `section.table.column` reaches another section |

Ids used in formulas can't contain `-`. Empty inputs make the result empty, and formulas can't depend on themselves in a loop.

### Rules for custom templates

- `id`: 1–64 lowercase letters, digits, or hyphens, and not the id of a built-in template (add `-custom`).
- Section and field ids: letters, digits, `_`, `-` only — **no dots or spaces**.
- `set`, `roles`, and `category` are ignored, and `output_template` is removed on upload — don't edit it. Keep `based_on` if present (it links the template to the official one it came from).
- Sections and fields appear in the interview in the order they're listed; match the document's order.
- Limits: schema under 1 MB; Word file under 10 MB, saved as `.docx` (no macros).
- **Advanced features** — if the schema contains `formula`, `constants`, `display`, `decimals`, `validate`, `same_as`, `auto_fill`, `default`, `rows`, `toc`, `heading_style_map`, `recommended_uploads`, `template_heading`, `outline_number`, or `heading_level`, keep them **exactly as they are** and don't add new ones. If a requested change requires one, say so and leave it for the developers.

### Protect the user's saved work

- **Never rename an existing field or section `id`** — saved answers are stored by id and would be lost. Change the `label` instead.
- **Keep the schema `id` the same** when editing, so the upload replaces the existing template.
- Increase `version` by 1 on every edit.
- When you remove a tag from Word, remove its `template_key_map` entry (and vice versa).

### Procedure A — modify an existing template

1. Read the whole schema and list every tag in the Word file (including headers, footers, and table rows).
2. Make the requested change in both places: Word tags, `template_key_map`, and the field definitions.
3. Check the three rules under "How the pieces connect" and the rules above.
4. Return the complete schema, the numbered Word steps, and a summary.

### Procedure B — write a schema for a tagged Word document

1. List every `{{TAG}}`, loop, and `{{TAG: hint}}` in the document.
2. Group the fields into sections in the order they appear, with clear `title`s and `label`s.
3. Choose each field's `type`; make long narrative passages `freetext` with an `ai_hint`; make repeated table rows a `table` field with `template_column_map`.
4. Mark fields `required: true` only if the document can't go out without them.
5. Choose a new `id` and set `version` to 1. Return the schema and any Word fixes needed.

### Procedure C — turn a completed document into a template

Propose a table of the text that changes from one document to the next (names, dates, amounts, paragraphs), with a tag name and field type for each. After the user agrees, give Find and Replace steps that swap each value for its `{{TAG}}`. Then follow Procedure B.

### Fixing upload errors

When the user pastes an upload report, each problem includes its code, a message naming the tag, field, or file part involved, and a **Fix:** line. Apply every fix, recheck the rules in this guide, then return the complete schema and Word steps again.

### Worked example

Word document (one paragraph per line; the item line is a table row):

```text
Date: {{LETTER_DATE}}
Dear {{VENDOR}},
{{#HAS_WARRANTY}}All items carry a {{WARRANTY_MONTHS}}-month warranty.{{/HAS_WARRANTY}}
{{#ITEMS}}{{ITEM_DESC}} {{ITEM_QTY}}{{/ITEMS}}
{{BODY}}
```

Schema:

```json
{
  "id": "vendor-letter",
  "title": "Vendor Letter",
  "version": 1,
  "docx_template": "vendor-letter.docx",
  "output_filename": "Vendor Letter - {{parties.vendor}}",
  "sections": [
    {
      "id": "parties",
      "title": "Parties",
      "fields": [
        { "id": "vendor", "label": "Vendor name", "type": "string", "required": true },
        { "id": "letter_date", "label": "Letter date", "type": "date", "required": true, "display_format": "long" }
      ]
    },
    {
      "id": "terms",
      "title": "Terms",
      "fields": [
        { "id": "includes_warranty", "label": "Includes a warranty?", "type": "boolean", "required": false },
        { "id": "warranty_months", "label": "Warranty length (months)", "type": "number", "required": false, "format": "integer", "visible_when": "HAS_WARRANTY" },
        {
          "id": "items",
          "label": "Items",
          "type": "table",
          "required": false,
          "columns": [
            { "id": "description", "label": "Description", "type": "string" },
            { "id": "quantity", "label": "Quantity", "type": "number" }
          ]
        },
        { "id": "body", "label": "Letter body", "type": "freetext", "required": false, "ai_hint": "Two short paragraphs confirming the order and next steps." }
      ]
    }
  ],
  "template_key_map": {
    "LETTER_DATE": "parties.letter_date",
    "VENDOR": "parties.vendor",
    "WARRANTY_MONTHS": "terms.warranty_months",
    "ITEMS": "terms.items",
    "BODY": "terms.body"
  },
  "template_column_map": {
    "ITEMS": { "ITEM_DESC": "description", "ITEM_QTY": "quantity" }
  },
  "content_blocks": {
    "HAS_WARRANTY": { "when": { "field": "terms.includes_warranty", "is_truthy": true } }
  }
}
```
