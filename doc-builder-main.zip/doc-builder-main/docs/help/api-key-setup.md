# AI Assistant Setup

The AI assistant handles extraction, drafting, and all other AI features in Doc Builder. It connects through the Leidos Model Gateway (LMG). This is separate from the [SharePoint integration](asksage-setup), which lets you search and attach files from SharePoint / OneDrive (currently disabled pending approval from the AskSage team).

Follow these phases in order to get connected.

> Phases 1 and 2 are pulled directly from the [LMG Getting Started guide](https://docs.dev.leadai.leidos.com/getting-started/enterprise/). Refer there for the most up-to-date instructions.

## Phase 1: Attestation Form

Complete the LMG Attestation Form on CIO Central to request access.

1. Open the [LMG Platform Attestation Form on CIO Central](https://ciocentral.servicenowservices.com/sp_ldos?id=sc_cat_item&sys_id=507fc68387c6ba10cdd542a70cbb3528&table=sc_cat_item&searchTerm=leidos%20model%20gateway)
2. Fill out all required fields. For the Doc Builder use case, use these suggested responses:

- **How are you using LMG and Claude Code?**
  - Select **"Connecting LLM based apps and IR&Ds"** from the dropdown
- **Business use case**
  - `LMG is used as the AI backend for the Doc Builder app (https://ams-oot.pages.lsde.leidos.com/doc-builder/)`

3. Submit the form

> **Note:** Approval typically takes 1–2 business days.

## Phase 2: Generate Your API Key

After attestation is approved, generate your key through the LiteLLM web UI.

1. **Log in** — navigate to the LiteLLM web UI for your environment:
   - **Commercial IL2:** <https://lmg.leadai.leidos.com/ui>
   - **Government CUI IL4/IL5:** <https://lmg-cui.leadai.leidos.com/ui>
2. **Authenticate via SSO** — click the SSO/Okta button and sign in with your Leidos credentials
3. **Generate Key:**
   - Navigate to the **Virtual Keys** page
   - Click **"Generate new key"**
   - Leave the team field blank (do not select a team)
   - Assign a descriptive key name (e.g., "dev-laptop")
   - Under Models, select **All Team Models**
4. **Store securely** — copy the key immediately and save it in your password manager

> ⚠️ **You cannot retrieve this key later.** Copy it immediately. The key should start with `sk-`.

## Phase 3: Enter the Key in Doc Builder

1. Open Doc Builder
2. Go to **Edit → [Settings](#open-settings)** in the menu bar
3. In the **AI Endpoints** section, click the tab for your endpoint — **Proprietary (IL2)** or **CUI (IL5)**
4. Paste your key into the API Key field inside that tab
5. Click **Test** — you should see a green **✓ Connected** message
6. If this endpoint should handle AI requests, click **"Use this endpoint for AI requests"** inside the tab (whichever tab shows the "In use" badge is the active one)
7. Click **Save**

AI drafting features will now be available.

> **Tip:** You can re-test your key at any time by opening Settings and clicking **Test** in the endpoint's tab. If the key has expired or been revoked, you'll see a specific error message explaining what went wrong.

> **Models:** The tab also shows a **Models for …** section where the app automatically lists the models available on that endpoint. You can override the default for any role (Standard, Advanced, Light for CUI scanning, and Embeddings) by selecting a different model from the dropdown, or entering a custom ID via "Other…". Model choices apply only to that tab's endpoint. Use **Refresh model list** to re-query the proxy after a model is added or retired.

## Test Your Key (Alternative — CLI)

If you prefer to verify your key outside the app, you can use curl or PowerShell. Use the gateway URL for your environment:

- **Commercial IL2:** `https://lmg.leadai.leidos.com`
- **Government CUI IL4/IL5:** `https://lmg-cui.leadai.leidos.com`

**Mac/Linux (curl):**

```bash
# Commercial IL2
curl -X POST https://lmg.leadai.leidos.com/v1/messages \
  -H "Content-Type: application/json" \
  -H "x-api-key: YOUR_API_KEY" \
  -d '{
    "model": "claude-4-6-opus-aws-comm-il2",
    "max_tokens": 1024,
    "messages": [{"role": "user", "content": "Hello, Claude!"}]
  }'
```

```bash
# Government CUI IL4/IL5
curl -X POST https://lmg-cui.leadai.leidos.com/v1/messages \
  -H "Content-Type: application/json" \
  -H "x-api-key: YOUR_API_KEY" \
  -d '{
    "model": "claude-4-6-opus-aws-gov-il4",
    "max_tokens": 1024,
    "messages": [{"role": "user", "content": "Hello, Claude!"}]
  }'
```

**Windows (PowerShell):**

```powershell
# Commercial IL2
$headers = @{
    "Content-Type" = "application/json"
    "x-api-key" = "YOUR_API_KEY"
}
$body = @{
    model = "claude-4-6-opus-aws-comm-il2"
    max_tokens = 1024
    messages = @(@{ role = "user"; content = "Hello, Claude!" })
} | ConvertTo-Json

Invoke-RestMethod -Uri "https://lmg.leadai.leidos.com/v1/messages" -Method Post -Headers $headers -Body $body
```

```powershell
# Government CUI IL4/IL5
$headers = @{
    "Content-Type" = "application/json"
    "x-api-key" = "YOUR_API_KEY"
}
$body = @{
    model = "claude-4-6-opus-aws-gov-il4"
    max_tokens = 1024
    messages = @(@{ role = "user"; content = "Hello, Claude!" })
} | ConvertTo-Json

Invoke-RestMethod -Uri "https://lmg-cui.leadai.leidos.com/v1/messages" -Method Post -Headers $headers -Body $body
```

