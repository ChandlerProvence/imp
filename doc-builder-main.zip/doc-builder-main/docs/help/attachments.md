# Attachments

The ➕ attachments button lets you attach reference documents that the AI can read when helping you draft content.

---

## Adding Attachments

1. Click the **➕** button at the bottom-left of the chat input area
2. The document picker dialog opens showing available uploaded documents
3. Select one or more documents to attach
4. Attached documents appear as chips above the text input

Once attached, the AI includes the content of those documents as context when responding to your messages.

---

## How Attachments Work

When you attach documents, the AI uses a hybrid retrieval approach:

- **Small documents** (≤10k characters) — included in full alongside your prompt
- **Large documents** — chunked and semantically searched; the most relevant passages are retrieved and sent to the AI

This means the AI can reference specific details from your attached documents when drafting content or answering questions.

---

## Managing Attachments

- **Remove an attachment:** Click the ✕ on any attached document chip to detach it
- **Attachments persist per message:** Each message you send includes whatever documents are currently attached
- **Multiple documents:** You can attach several documents at once for cross-reference tasks

---

## Tips

- Attach source documents before asking the AI to draft content — it will pull relevant details automatically.
- For "extract from this document" workflows, attach the source and ask the AI to fill specific fields based on what it finds.
- If the AI seems to miss details from a large document, try asking a more specific question — it helps the retrieval system find the right passages.
- You don't need to keep documents attached for every message — only attach them when the AI needs that context.
