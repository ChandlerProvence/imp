# AI Controls

The AI panel includes controls that let you tune how the assistant responds. These appear at the top of the chat panel.

---

## Effort Tier

The effort selector determines how much compute the AI uses to answer your request.

| Icon | Level | Model | Best for |
|------|-------|-------|----------|
| ⚡ | **Fast** | Standard model (low effort) | Quick factual answers, simple rephrasing, short completions |
| ⚖️ | **Balanced** | Standard model (medium effort) | General drafting, moderate analysis, most everyday tasks |
| 🔬 | **Thorough** | Advanced model (extended thinking) | Complex reasoning, detailed drafts, nuanced analysis |

**How to use:** Click the effort dropdown in the AI panel header and choose a level. The selection persists for the session.

---

## Scope Selector

The scope dropdown controls *what context* the AI sees when answering.

- **Entire Document** — The AI sees all fields and answers across every section. Use this for cross-section questions or when drafting content that references multiple parts of the document.
- **Section: [name]** — The AI sees only the fields in the current section. Good for focused work within one topic area.
- **[Field name]** — The AI is scoped to a single field. Best when you want a targeted draft for one specific field.

The scope selector is color-coded:
- 🟣 Purple border = document scope
- 🔵 Blue border = section scope
- 🟢 Green border = field scope

---

## Without a Document

When no document is open (for example on Home, Manage Templates, or Documentation), the AI Assistant runs in **general mode**: a plain chat where you can ask a question or attach documents to ask about them. No access to Claude or ChatGPT, or need to ask about CUI material? Use the panel as a general chatbot whenever no drafting session is active (switch to the CUI endpoint first for CUI content). Effort tiers, questions from the AI, and attachments work as usual, but the AI cannot propose changes, so there are no Changes or Observations tabs and no scope selector. Uploads here are kept separate from your document sessions. These conversations are saved and can be resumed from the conversation dropdown; opening or closing a document starts a new conversation.

---

## Chat Sessions

The **Chat Sessions** dropdown in the panel header lists your conversations for the current document (or for general mode). Pick one to resume it, or choose **New Chat Session**. Hover a row and click the trash icon to delete that conversation; if it was the one you were viewing, a new empty chat opens.

---

## Tips

- Start with ⚖️ **Balanced** for most work — it's fast enough for iteration while still producing quality output.
- Switch to 🔬 **Thorough** when you need the AI to think carefully (e.g., legal language, complex technical writing).
- Narrow the scope when you want the AI to stay focused on one area without getting distracted by unrelated fields.
- Widen the scope to "Entire Document" when your question spans multiple sections (e.g., "make the parties section consistent with the terms section").
