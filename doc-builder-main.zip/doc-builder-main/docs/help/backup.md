# Backing Up Your Data

Doc Builder has no server. Everything you do — documents in progress, AI chats, uploaded documents, custom templates, and settings — is saved only in this browser. A browser profile reset, an IT re-image, or the browser clearing its storage erases it.

A backup saves all of it to one file you can keep on your computer or a network drive.

[Open backup settings](#open-settings:backup)

---

## Back up

1. Open **File → Back Up or Restore All Data…** (or **Edit → Settings…** and scroll to **Your data**).
2. Click **Back up all data…**. Doc Builder shows what the file will include.
3. Click **Save backup** and choose where to save it. The file is named `doc-builder-backup-<date>.json`.

Settings shows **Last backup** under **Your data**. It turns red if you've never backed up or your last backup is more than two weeks old.

### What's included

| Included | Not included |
|----------|--------------|
| Documents in progress, with their answers, progress, and images | API keys — re-enter them after restoring |
| AI chat history | Search indexes for large documents — rebuilt automatically the next time you attach the document |
| Uploaded documents (the extracted text and CUI status) | |
| Custom templates | |
| Your profile, group, model choices, and display preferences | |

### CUI documents

If any uploaded document is marked or flagged as CUI, the backup file contains it, and Doc Builder warns you before saving. **Store the backup only where you are allowed to keep the original CUI documents.**

---

## Restore

1. Open **File → Back Up or Restore All Data…**.
2. Click **Restore from backup…** and choose a backup file.
3. Review what's in the backup, then click **Replace all data**.

**Restoring replaces everything in this browser** with the contents of the backup. Anything you've done since the backup was made is removed. To be safe, **Back up current data first** is ticked by default, so Doc Builder saves a backup of what's here now before replacing it. API keys are kept.

Close any other Doc Builder tabs before restoring, or they may save over the restored data. The page reloads when the restore finishes.

If a custom template in the backup is damaged, it is skipped and listed before you confirm. Documents that use it will ask you to add the template again.

---

## Backups and progress files

**File → Save Progress…** saves just the document you're working on, to share it or move it to another computer. A backup saves *everything* and is the way to recover after losing your browser data.
