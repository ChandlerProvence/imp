# Settings Panel

The Settings panel lets you configure your profile, group, AI endpoint, and API keys. Open it from the menu bar: **Edit → Settings…**

---

## Group

The group selector filters which document types appear on the home screen.

| Option | Effect |
|--------|--------|
| **All Documents (no filter)** | Every available document type is shown |
| **Supply Chain** | Only Foreign Military Sales documents |
| **Contracts / Legal** | NDAs, agreements, and legal documents |
| **Program Management** | Life cycle and sustainment planning docs |

Choose the group that matches your work. You can change it anytime — it only affects which templates are listed, not any documents you've already started.

---

## Your Information

Fill in your name, title, phone, and email. These values auto-fill the **SCS / Preparer** fields whenever you start a new document, saving you from re-typing the same information each time.

- **Name** — Your full name as it should appear on documents
- **Title** — Your job title (e.g., "Subcontracts Administrator")
- **Phone** — Contact phone number
- **Email** — Contact email address

You can leave any field blank — only the fields you fill will be auto-populated.

---

## Your Data

Back up everything Doc Builder has saved in this browser — documents in progress, AI chats, uploaded documents, custom templates, and settings — to one file, or restore from one. These buttons act immediately; you don't need to click **Save**.

> 💡 See [Backing Up Your Data](backup) for what's included and how restoring works.

---

## AI Endpoint

Doc Builder connects to the Leidos Model Gateway (LMG) for AI features. Two deployments are available:

| Endpoint | Classification | Use for |
|----------|---------------|---------|
| **Proprietary (IL2)** | Commercial / unclassified | Standard company-proprietary documents |
| **CUI (IL5)** | Controlled Unclassified Information | Documents containing CUI markings |

Click the toggle to switch between endpoints. The active endpoint determines which models and proxy URL are used for all AI operations (extraction, drafting, embeddings).

---

## API Keys

Each endpoint requires its own API key from the Leidos Model Gateway.

- Enter your key in the password field for each endpoint
- Click **Test** to verify the connection — you'll see a green ✓ if it works or a red ✗ with an error message if not
- The active endpoint's key field is highlighted with a colored border (blue for Proprietary, amber for CUI)

**Security note:** Keys are stored in your browser's local storage and are sent only to the selected LiteLLM proxy — never to any other server.

> 💡 Need help getting an API key? See the [AI Assistant Setup](api-key-setup) help topic for step-by-step instructions.

---

## AI Connection Info

The read-only panel at the bottom of Settings shows the resolved connection details for the currently selected endpoint:

- **Endpoint** — The proxy URL requests are sent to
- **Model (Standard)** — Used for extraction and fast AI tasks
- **Model (Advanced)** — Used for thorough drafting and complex reasoning

This is useful for troubleshooting — if AI features aren't working, check that the endpoint and models look correct.

---

## AskSage (SharePoint)

> **Note:** The AskSage (SharePoint / OneDrive) integration is currently disabled pending approval from the AskSage team. This section will appear in Settings once it is re-enabled.

The AskSage section lets you connect to SharePoint for searching and attaching reference documents.

- **Email** — Your Leidos email address (the one you registered with AskSage)
- **API Key** — Your AskSage API token (JWT)
- Click **Test** to verify the connection

> 💡 Need help setting up AskSage? See the [AskSage Setup](asksage-setup) help topic for step-by-step instructions.

---

## Tips

- Fill in your profile once and it carries forward to every new document — no need to retype your info.
- You can store keys for both endpoints simultaneously. Switching endpoints doesn't erase the other key.
- If you work with both proprietary and CUI documents, keep both keys saved and toggle as needed.
- Use the **Test** button after entering or updating a key to confirm it works before starting a document.
