# Building and Editing Templates in the App

A custom template has two parts: a **Word file** with `{{TAGS}}` where the answers go, and a **schema** that says what to ask for each tag (its label, type, and section). You can build and edit the schema in Doc Builder without touching any JSON or using an AI chatbot.

Open **File › Manage Custom Templates** to start. There are three ways in:

- **From your own Word file:** add the tags in Word, then click **Add template…** and add the Word file on its own. Click **Build the schema from the tags**.
- **From an official template:** under **Modify an official template**, choose one and click **Edit in app**. You get your own copy to change.
- **An existing custom template:** click **Edit** on its row.

---

## What the editor can't change

The editor changes what is asked and how answers look. These need the template files instead:

| What | Not possible in the app |
|---|---|
| **The Word file** | Changing its text, or adding or removing tags. Fields and table columns come from the tags, so they can't be added or deleted in the app either. |
| **Ids** | Field and section ids, and the template id once the template has been saved. |
| **Field types** | Image fields. |
| **Calculations** | Formulas on fields and table columns, and the constants they use. |
| **Linked answers** | Copying another field's answer, and filling a field from your profile. |
| **Conditions** | Text or questions that appear only under certain conditions. |
| **Checks** | Validation rules, such as a number range or one date coming after another. |
| **Tables** | Fixed rows, and the minimum or maximum number of rows. |
| **Formatting and output** | A fixed date format on a tag, the downloaded file name, the table of contents, and heading styles. |
| **AI context** | Recommended uploads, reference documents, and download hints. |

A template that already uses any of these keeps them when you edit it in the app. They're listed under **Kept as is**, and fields that use them show a **Locked** badge.

To make these changes, download the template (**Download for editing** on your template's row, or **Download as starting point** for an official one), change the files with the [template authoring guide](template-authoring-guide.md), and add them back with **Add template…**.

---

## Tag your Word file

Type each tag in Word where the answer should appear:

| You type | What you get |
|---|---|
| `{{VENDOR}}` | One answer, filled in where the tag is. Use letters, digits, and `_`. |
| `{{VENDOR: legal name of the vendor}}` | The same, plus a hint for the AI assistant. The hint is removed from the Word file. |
| A tag alone in its own paragraph | A long-text field that can hold several paragraphs. |
| `{{#ITEMS}}{{NAME}}` … `{{QTY}}{{/ITEMS}}` in a table row | A table: the row repeats once for each entry, with one column per tag inside it. |

Type each tag in one go, so Word keeps it in one piece. If AutoCorrect changes it, undo the change.

Tags in headers and footers work, but they can only hold a single line, not long text or a table.

### What Doc Builder guesses

When it builds the schema, Doc Builder:

- makes one section for each top-level heading that has tags under it, and puts tags above the first heading in **Document details**;
- turns each tag into a field labelled from its name (`SCS_NAME` becomes "SCS name");
- guesses **Date** for names containing `DATE`, and **Number** for names like `AMOUNT`, `TOTAL`, `QTY`, or `COST`;
- makes everything optional.

Anything it wants you to check is listed at the top of the editor. If the Word file has no tags at all, it says so and doesn't create anything.

---

## Use the editor

The editor has three columns: sections on the left, fields in the middle, and the Word file on the right.

### Sections

Each section is a page of questions. Rename a section, move it up or down, or add a new one. A section can merge into another, and an empty section can be removed.

### Fields

For each field you can change:

- **Label:** the question people see. Write it the way you'd ask it.
- **Type:** Short text, Long text (paragraphs), Number, Date, Yes / no, One choice from a list, or Several choices from a list. Choice types need at least one choice.
- **Required:** whether the question must be answered. Unanswered required questions are flagged on the Review page.
- **Date format** and **Number format:** how the answer looks in the document.
- **Hint for the AI assistant:** what belongs here, where to find it, how to phrase it.
- **Order and section:** **Move up**, **Move down**, and **Move to section…**.

Table fields list their columns, each with its own label, type, and required setting.

The field's id and the tag it fills are shown under each field. Ids can't be changed in the app.

### Locked settings

Some templates, mostly copies of official ones, use advanced settings such as calculated fields, fields copied from another field, or text that only appears under certain conditions. A field that uses one, or that another part of the template depends on, shows a **Locked** badge. Hover over a greyed-out control to see why, or open the badge for the details.

You can still change a locked field's label, hint, and required setting. To change the locked parts, edit the template files; see *What the editor can't change* above. Settings that belong to the whole template are listed under **Kept as is**.

### Preview and Tags

The right-hand column has two tabs:

- **Preview** shows the Word file with every answer replaced by its label in brackets, such as `[Vendor name]`. It updates as you edit. Click a field to find it in the preview; click again to go to the next place it appears. Headers and footers aren't shown.
- **Tags** lists every tag in the Word file, the field that fills it, and the paragraph it sits in. Click a field name to jump to it.

---

## Save

**Check** runs the same checks as an upload and lists anything that needs fixing, with how to fix each one. It doesn't save anything, so use it as often as you like.

**Save** runs the same checks first, and saves only if they pass:

- If something needs fixing, the problems are listed and nothing is saved.
- If you're replacing a template you already have, it shows what changed and how many saved documents use the template, and asks before saving. Those documents switch to the new version.

A saved template appears under **Custom Templates** on the home page.

### Drafts

Templates built from a Word file or copied from an official one start as drafts. A draft is saved in this browser as you work, so you can leave and come back: it's listed under **Drafts** on the Manage Custom Templates page, with **Continue editing** and **Discard**. A draft becomes a template when you save it.

Changes to a template you've already saved aren't kept until you click **Save**. Doc Builder asks before you leave with unsaved changes.

### Copies of official templates

A copy you made with **Edit in app** remembers which official template it came from. Its row offers **Switch to official**, which moves your saved documents back to the official version and archives your copy. You can restore the copy later.

---

## Share it

When a template works for you, use **Submit for team use** so it can be added to Doc Builder for everyone.
