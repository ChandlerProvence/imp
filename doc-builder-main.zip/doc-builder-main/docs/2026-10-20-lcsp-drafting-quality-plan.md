# LCSP drafting quality — can the AI Assistant draft a good LCSP from a tech volume and SoW?

**Date:** 2026-10-20
**Status:** Proposed. Nothing in this plan has started.
**Builds on:** `docs/2026-10-13-fill-run-steps-plan.md` (stepped fill run; Phases A–C not yet shipped). That plan makes the model *finish* an LCSP. This plan is about whether what it finishes is *good*.
**Absorbs:** the *Agentic workflow — multi-pass extraction with self-review* and *Raise RAG threshold* items in `docs/public/development-plan.md`.
**Amended by:** `docs/2026-10-26-extract-compose-stances-plan.md` (2026-10-26). The brief step moves between the extract and compose phases of the fill run, and Phase 3 review applies to compose steps only; extract proposals get a mechanical source check instead.

## Question

The LCSP schema (`src/schemas/lcsp/`) has 54 freetext fields, 23 tables and 58 other fields across 14 sections. The freetext fields ask for long, interdependent narrative: maintenance concept, depot activation, supply support, technical data, sustaining engineering, O&S cost. Given a technical volume and a SoW/PWS, can the AI Assistant draft these well, or does it need more capability (self-reflection, task breakdown, web search)?

## Answer in brief

The model is not the limiting factor. What limits quality today is (1) how little of the source material the model can actually see, (2) the absence of any shared model of the program that keeps 54 sections consistent with each other, and (3) the fact that a contractor tech volume and SoW simply do not contain what several LCSP sections ask for.

Of the capabilities asked about:

| Capability | Verdict | Why |
|---|---|---|
| Better source access | **Do first** | Every real input is above the 10k-char direct-inclusion threshold, so the model only ever sees 10 fragments of 800 chars per search. This is the main cause of generic, "standard practice" prose. |
| Task breakdown | **Yes, as a planning pass** | A program brief extracted up front, pinned into every drafting step, is what keeps 4.3.1 Maintenance Concept and 4.7 Manpower agreeing. The stepped fill run (2026-10-13 plan) already supplies the per-section breakdown. |
| Self-reflection | **Yes, scoped and bounded** | One review-and-revise pass per section against the sources and the brief. Not an open-ended agent loop. |
| Web search | **No** | Facts must come from uploaded documents; the proxy sits at IL2/IL5 with CUI in play; the regulatory frame (DoDI 5000.91, the 12 IPS elements, LCSP Outline v3.0) is already in the model and the field hints. Adds risk, no grounded information. |
| New inputs | **Yes, schema-only** | O&S cost, funding, schedule, depot source-of-repair, review criteria will stay generic no matter how good the drafter is unless the program office supplies them. |

## What the drafting path does today

Drafting runs through one chat loop in `src/hooks/useAiChat.ts` with six tools (`src/ai/toolDefinitions.ts`): `propose_changes`, `search_references`, `report_observations`, `get_field_info`, `get_template_context`, `ask_user`. On the Thorough tier (`src/ai/effortTiers.ts`) it uses the advanced model with a 10k thinking budget and a 64k output cap per turn. There is no cap on tool rounds; `fields_still_empty` in the tool result nudges the model to continue.

Source access, from `src/ai/embeddings.ts` and `src/ai/bulkEdit.ts`:

| Constant | Value | Effect |
|---|---|---|
| `SMALL_DOC_THRESHOLD` | 10,000 chars | Anything larger is never shown in full |
| `CHUNK_SIZE` / `CHUNK_OVERLAP` | 800 / 200 chars | Tables, figures and multi-paragraph arguments are sliced mid-thought |
| `TOP_K` | 10 | One `search_references` call returns ~8k chars |
| Prompt cap | 100,000 chars | Hard ceiling on direct inclusion |

The example inputs in `trash/lcsp_example_inputs/` (WFR C5ISR field support proposal):

| Document | Size | Structure |
|---|---|---|
| Proposal Tech Volume (.docx) | ~188k chars | 45 headings, 45 tables, 22 figures |
| PWS Dec 2023 (.pdf) | ~144k chars | — |
| RFP Jan 2023 (.pdf) | ~70k chars | — |

All three go through RAG only. Together they are ~400k chars, so even the backlog item *Raise RAG threshold* (direct inclusion up to ~150–200k) does not fit them in one prompt. For a section like 4.3.1 Maintenance Concept the model gets whatever ten fragments best match a single query string; nothing drives it to search again, and nothing lets it read a chapter of the tech volume end to end. `FREETEXT_DRAFTING_RULE` (`src/ai/promptUtils.ts`) then correctly tells it to draft from standard practice at confidence < 0.6 — which is exactly the generic output being asked about.

The second structural problem is coupling. The maintenance concept drives depot activation, supply support, technical data, support equipment and manpower. Drafting 54 fields as a flat list inside one growing conversation gives the model no shared picture of the system, so late sections drift from early ones, and the "Working Draft echo" the prompt already warns about (`ANSWERS_SECTION_PREAMBLE`) gets worse as the thread lengthens.

## Evaluation without a matched case

There is no LCSP ground-truth fixture and no case where the inputs and the finished LCSP belong to the same program. What exists:

- **Example inputs:** the three WFR documents above.
- **Non-matching example LCSPs:** finished LCSPs for other programs. Useful as *exemplars of what good looks like* (depth, specificity, structure, length per section), not as diff targets.
- **Reference material** in `trash/LCSP references/`: DoDI 5000.02, DoDI 5000.91, LCSP Outline v3.0 (Oct 2022). These define what each section must cover.

So the `gt-bootstrap` / `groundTruth` test path does not apply. Quality has to be judged with a rubric instead of a diff. Phase 0 builds that rubric and records a baseline *before* any capability work, so each later phase can show a measured change rather than an impression.

Rubric, scored per freetext field on the generated draft (0–2 each, by an LLM judge with the sources attached, spot-checked by a human):

1. **Coverage** — does the section address the topics its `ai_hint` and LCSP Outline v3.0 call for? (Hint topics become a checklist; the judge marks each present/absent.)
2. **Specificity** — ratio of program-specific statements (names a subsystem, site, PSP, metric, contract clause) to generic ones. The non-matching exemplars calibrate what "specific enough" means for this document type.
3. **Traceability** — for every specific factual claim, can the judge find a supporting passage in the sources? Count unsupported claims. This is the hallucination metric.
4. **Consistency** — contradictions with other drafted sections (maintenance levels, PSP roster, site list, metric names). Judged across the whole draft, attributed to the field pair.
5. **Honest gaps** — when the sources genuinely do not cover a topic, did the draft say so (confidence < 0.6, gap listed in the reply) rather than inventing?

Plus two mechanical measures from the chat troubleshoot export: tokens per call (should stay flat) and number of `search_references` calls per section (should rise in Phase 1, then stabilize).

Important caveat about the example case: the WFR tech volume is a *services* proposal (fielding, training, readiness support), not a weapon-system design volume. Sections on FMECA, reliability growth, depot activation and O&S cost estimates will score low on coverage for *any* drafter because the material does not exist. Phase 0 must separate "no source" fields (score them on *Honest gaps* only) from "source exists, drafter missed it" fields, which are the ones this plan can improve. Expect the capability phases to move the second group; expect Phase 4 (inputs) to be the only thing that moves the first.

## Phase 0 — Baseline and rubric (no product change)

1. Create `cases/lcsp-wfr/input/` (gitignored, like all cases) with the three WFR documents; copy the reference PDFs alongside. Put the non-matching exemplar LCSPs under `cases/lcsp-wfr/exemplars/`.
2. Run the app as it is today (Thorough tier, CUI endpoint, documents in their slots, "Fill in all fields"). Save the generated `.docx`, the exported answers and the chat troubleshoot JSON as `cases/lcsp-wfr/baseline/`.
3. Write the judge as a Claude Code agent definition (`.claude/agents/lcsp-judge.md`, read-only, in the style of `schema-judge`) that takes a case directory, extracts text from the draft and sources with `tools/docx-diff.py extract`, and scores each freetext field on the five rubric items, writing `scores.json` and a short findings report. Running the judge as an agent (rather than a script that calls the proxy) keeps the API key and CUI handling where they already are, and matches how the other quality agents work.
4. A first pass of the judge over the baseline, with the "no source" / "source exists" split per field written down in `cases/lcsp-wfr/field-classes.json`. Human read of ten fields to calibrate the judge.

Output: a baseline score sheet and the list of fields where the sources *do* contain the answer and the draft missed it. That list is the target for Phases 1–3. **[~4 hr]**

## Phase 1 — Let the model read the sources

Goal: a drafting step can read the relevant *chapter* of a source document, not ten fragments of it.

1. **Raise the limits** (the existing *Raise RAG threshold* backlog item): `SMALL_DOC_THRESHOLD` to ~60k chars and the prompt cap in `bulkEdit.ts` to ~400k chars so a PWS or RFP of ordinary length is included whole. The tech volume still goes through retrieval.
2. **Heading-aware chunking** in `src/ai/embeddings.ts`: for `.docx` sources, chunk on the heading structure mammoth already exposes (`h1`–`h6`) with a max chunk size of ~4k chars and a parent-heading breadcrumb on every chunk (`1.2.5 Task Order Operational Support › 1.2.5.1.5 Support`). For PDFs, fall back to current fixed-size chunking but keep page numbers. Embedding chunk records gain `heading`, `headingPath`, `ordinal`. This is a Dexie schema change for `embeddingChunks`; re-index on upgrade (the table is already excluded from backups).
3. **Two new tools** in `src/ai/toolDefinitions.ts`, mirroring `get_template_context` but for sources:
   - `list_reference_outline({ document? })` — heading tree per attached document with chunk counts, role title and filename.
   - `read_reference_section({ document, heading | from_chunk, max_chars? })` — contiguous text under a heading, capped at ~12k chars, with a `truncated`/`next` cursor. Backed by `headingPath`/`ordinal` in the chunk store, so no second copy of the text.
   Both are raw JSON schema, work under forced `tool_choice`, and go through LiteLLM unchanged.
4. **Retrieval tuning for drafting scope:** `search_references` accepts an optional `top_k` (default 10, max 25) and `document` filter; results carry the heading breadcrumb so the model can follow up with `read_reference_section`.
5. **Prompt:** one added rule in `buildBulkEditChatSystemPrompt`: before drafting a freetext field, call `list_reference_outline` once per conversation, then read the sections whose headings match the field's topic. The per-step instruction from the fill run (Phase B of the 2026-10-13 plan) names the likely source chapters when the role hint allows it (e.g. PWS §3 for 4.x sustainment strategy).

Tests: chunker unit tests on a heading-rich fixture docx (breadcrumbs, size cap, table integrity); tool handlers in `useDocumentManager` (outline, section read, cursor); a `useAiChat` behaviour test that a `read_reference_section` call gets exactly one result. Re-run the Phase 0 judge; expect *Traceability* and *Specificity* to rise on the "source exists" fields and `search_references` calls per section to rise.

Does not depend on the fill-run plan. **[~8 hr]**

## Phase 2 — Program brief (task breakdown as a planning pass)

Goal: every drafting step works from the same picture of the program.

1. **Brief schema** in `src/ai/programBrief.ts`: a fixed JSON shape — system/program identity, mission and operating concept, subsystems and configuration items, sites and operating units, support concept (levels, CLS vs organic, PSI/PSP roster with roles), sustainment metrics (KPP/KSA/APA with thresholds and source), schedule anchors (PoP, transition, IOC/FOC, option periods), contract vehicle and CDRLs relevant to sustainment, known risks, and **gaps** (topics the sources do not cover, with the LCSP sections affected). Every entry carries a `source` (document role + heading) or is in `gaps`.
2. **`propose_program_brief` tool** (raw JSON schema, forced `tool_choice`) called in a dedicated first step of the fill run with the full source outline available and Phase 1's read tools. Stored on the session (new Dexie field or table `programBriefs`, keyed by session), shown to the user in the AI panel as a collapsible card with *Edit* so they can correct it before drafting proceeds. The brief is user-editable precisely because it is where an SME's knowledge of the program enters.
3. **Pinning:** `buildBulkEditChatSystemPrompt` gains a `## Program brief` block (stable across steps, so it sits in the cached system-prompt prefix) rendered from the stored brief. Drafting rules reference it: "Names, levels, sites, metrics and the PSP roster come from the brief; do not introduce ones not in it unless a source states them, in which case add them to the brief via `propose_program_brief`."
4. **Fill-run integration:** the brief step sits between the extract phase and the compose phase of `buildFillPlan` (2026-10-13 plan B1, as amended by the two-stance plan) when the schema declares `program_brief: true`, so it can read the facts extract steps have already proposed. Before the two-stance plan ships, it is step 0. Schemas that do not declare it are unaffected (NDA, FMS forms). This is the only coupling to the fill-run plan; until that plan ships, the brief step can be triggered by a *Build program brief* button in the panel.
5. **Reporting gaps:** at the end of the run the summary message lists `gaps` from the brief against the LCSP sections they affect, replacing today's ad-hoc "couldn't confirm" remarks.

Tests: brief render/pin round-trip; `propose_program_brief` handler persists and re-renders; a test that the system prompt includes the brief and that the prompt cache prefix is unchanged between steps. Re-run the judge; expect *Consistency* to rise and *Honest gaps* to be explicit.

**[~6 hr]**

## Phase 3 — Bounded self-review per section

Goal: catch unsupported claims and contradictions before the user sees the draft, without an open-ended loop.

1. After a **compose** fill-run step's `propose_changes` is accepted by the harness (coverage gap empty, 2026-10-13 plan B2), run **one review call**. Extract steps skip this and get the mechanical source check in the two-stance plan (step 5) instead. Run with a review system prompt derived from `documentReviewPrompt.ts`: the step's drafted fields, the program brief, the source outline and the read tools. Output is `report_observations` only, with types limited to `assumption` (unsupported claim, quoting the sentence), `conflict` (with brief or another drafted field, naming both), and `gap` (hint topic missing). No prose.
2. If any observation is `high` severity, run **one revise call** scoped to the same fields with the observations attached ("Fix these; change nothing else"). Then stop regardless of outcome. Observations that remain are shown in the Observations tab as today.
3. Tier gating: review and revise use the Balanced tier (standard model, medium effort) regardless of the drafting tier; the cost is one to two extra calls per section, and the judge decides whether that is worth it.
4. Toggle in the fill-run progress line (*Review each section*: on by default for schemas with `program_brief: true`, off otherwise).

Tests: harness runs exactly one review and at most one revise per step; observations are attributed to field keys; a step with no high-severity observations makes no revise call. Re-run the judge; expect *Traceability* unsupported-claim count to fall. If it does not fall measurably against Phase 2, drop Phase 3 — the review pass is the most expensive piece and the one most likely to be theatre.

Depends on the fill-run plan Phase B. **[~6 hr]**

## Phase 4 — Close the input gap (schema only)

No code. Add `recommended_uploads` slots to `lcsp.schema.json` with role hints, for the documents that carry what the tech volume and SoW cannot:

| Slot | Feeds |
|---|---|
| Integrated Master Schedule / fielding schedule | 8 Integrated Schedule, 4.3.2 depot activation timeline |
| LCCE or O&S cost estimate (CARD if available) | 9.2.x cost estimate, drivers, affordability |
| Program risk register | 4.12.x risks, obsolescence, supply chain |
| Product Support BCA / maintenance plan / DSOR decision | 2 PSS, 4.3.x maintenance concept and depot |
| CDRL list / technical data and IP plan | 4.5 technical data, 5.1 competition |
| Prior LCSP or sustainment annexes | everything, as the "update from" baseline |

Each hint says what the document is authoritative for and what it is not (pattern from the existing Technical Volume and PWS slots). Add a `program-management` role note that monthly status reports are the source for 3.3 monitoring and current metrics. Update `docs/help/template-authoring-guide.md` only if a new slot property is introduced (none planned).

Re-run the judge on the "no source" fields with a second case that has these documents, if one becomes available; otherwise this phase is justified by the field-class split from Phase 0 alone. **[~2 hr]**

## Not doing

- **Web search.** See the table above. If a regulatory-reference capability is ever wanted, bundle the LCSP Outline and DoDI 5000.91 as a `default_reference` document (the mechanism already exists for the FMS contact sheet) so the model reads the authoritative text through `read_reference_section`. That is grounded, offline and portable; a search tool is none of those.
- **An open-ended agent loop** (model decides when to stop reviewing). The 2026-10-13 plan's finding stands: stopping is a checked action and retries are bounded.
- **Anthropic-only machinery.** Every new tool is raw JSON schema with forced `tool_choice`; the brief and review passes are ordinary messages through LiteLLM. Nothing new goes behind `featureFlags.ts`.

## Delivery order and dependencies

```
Phase 0 (baseline) ──► Phase 1 (read sources) ──► Phase 2 (brief) ──► Phase 3 (review)
                                                        │
2026-10-13 fill-run plan Phases A–C ────────────────────┘ (B needed by 2.4 and all of 3)
Phase 4 (schema slots) — independent, any time after Phase 0
```

Phase 0 and Phase 1 can ship without the fill-run plan. Phase 2 ships with a manual trigger if the fill run is not yet in. Phase 3 needs the fill run. Each phase re-runs the Phase 0 judge and records the scores in `cases/lcsp-wfr/scores/<phase>.json`; the plan is working if *Traceability* and *Specificity* rise on the "source exists" fields while *Honest gaps* holds on the rest.

Total: ~26 hr, of which ~14 hr (Phases 1–2) carry most of the expected gain.

## Verification

1. `npm test` and `npm run build` after each phase.
2. Judge scores per phase as above, with the human calibration read repeated at the end of Phase 2.
3. Regression on a short schema with one small document (NDA): no outline calls, no brief step, one or two `propose_changes` calls, unchanged behaviour.
4. Chat troubleshoot export after a full LCSP run: tokens per call in a flat band; `read_reference_section` calls present in sustainment-strategy steps; brief present in the system prompt of every step after step 0.
5. Provider check: the new tools and the brief step run unchanged with `thinking`, `effort` and `promptCaching` flags off.

## Documentation

Final step of each phase: ask the user whether to update `changelog.d/` (new fragment per branch), `README.md` (AI panel: program brief card, section review toggle, outline/read tools) and `docs/public/development-plan.md` (tick the phase under *LCSP drafting quality*). Do not run `/update-docs` automatically.
