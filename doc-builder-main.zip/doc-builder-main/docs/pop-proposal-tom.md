**LEIDOS PROPRIETARY**

# Procurement Operations Portal — TOM Workflow
## Proposal Supplement (Pending Workflow Validation)

*FMS F-16 Sustainment — TOM Procurement Workflow Modernization*

| | |
|---|---|
| **Status** | **Draft, held out of the published proposal package until validated with the TOM team** |
| **Parent document** | `docs/public/pop-proposal.md` |
| **Date** | October 19, 2026 |

---

> **Why this is separate and unpublished:** The SCA workflow is well understood and in production. The TOM workflow is based on initial interviews and has not been confirmed with the TOM team. This file was moved out of `docs/public/` on October 23, 2026 so that the proposal package carries only validated material; it returns, merged into the proposal and appendices, after the validation session answers the open questions at the end.

---

## Contents

1. [TOM Document Capabilities](#tom-document-capabilities)
2. [TOM Metrics](#tom-metrics)
3. [TOM Information Needs](#tom-information-needs)
4. [Sequencing](#sequencing)
5. [TOM Automation](#tom-automation)
6. [Appendix A — TOM Workflow Diagrams](#appendix-a--tom-workflow-diagrams)
7. [Appendix B — TOM Improvements (Value Stream)](#appendix-b--tom-improvements-value-stream)
8. [Open Questions](#open-questions-must-validate)

---

## TOM Document Capabilities

*Merges into the proposal's "What funding delivers". Of these, only a basic fillable SH PWS template exists in Doc Builder today; the rest are not built. The first four are the 24-hour "TOM workflow documents" line under Phase 2a and wait on the validation session below. The handoff is the 16-hour "Structured TOM-to-SCA handoff" line under Phase 1; it uses the prerequisite list in `docs/public/fms-procurement-process.md` §3 as its checklist and does not wait on validation.*

| Capability | What it does |
|---|---|
| **SOR Selection Document Assembly** | Schema-driven template; AI drafts evaluation rationale from SOR response data; auto-fills comparison fields. |
| **SH PWS Creation** | A basic fillable SH PWS template exists today. Funded work: AI pre-fills it from the parent requirement and sourcing data. |
| **SOR Capability Reference** | Searchable lookup (JSON/CSV) of which SORs hold positions for which NSNs. Eliminates institutional-memory dependency. |
| **Sourcing Email Generator** | AI drafts solicitation emails from structured requirement data. TOM reviews and sends. |
| **Structured TOM → SCA Handoff** | Validated checklist replaces informal email. TOM marks each prerequisite complete; tool validates before releasing to SCA. Carries full context (shipment count, PRs, vendors, dates). |

---

## TOM Metrics

*Merges into the proposal's "Return on investment" under Phase 2a once the TOM baseline is validated. The two handoff rows are Phase 1 and are already counted there.*

All "Today" figures in this table are from initial interviews, not timed; they are open question 6 below.

| Metric | Today | Expected once built | Confidence |
|---|---|---|---|
| SOR selection document | Drafted from scratch (~30–60 min, interview estimate) | AI-drafted; TOM reviews (~10–15 min, projected) | Medium — same engine, untested on this doc |
| SOR capability lookup | From memory (variable, single-point-of-failure) | Instant searchable reference (seconds) | High — if reference data provided |
| Sourcing emails | Written individually per SOR | AI-generated; TOM reviews and sends | Medium — depends on email examples |
| Handoff completeness | Informal email; SCA discovers gaps during work | Validated checklist; all prerequisites confirmed | High — tool enforces |
| Context transfer at handoff | SCA re-derives from bare link (15–30 min rework, interview estimate; baseline §3) | Full context package (0 min SCA rework) | High that the rework is removed; the 15–30 min size is unvalidated |

---

## TOM Information Needs

*Inputs needed from the TOM team before build.*

| Need | Purpose |
|---|---|
| SOR selection document template + completed example | Build TOM schema |
| SOR capability reference data (any format) | Build searchable lookup |
| Sourcing email examples | Train AI drafting |
| TOM handoff examples (what's sent vs. what's needed) | Design structured handoff |

---

## Sequencing

*Relative to the start of Phase 2a, after the validation session. The structured handoff ships in Phase 1 independently of this schedule.*

| Period | TOM-specific activity |
|---|---|
| Weeks 1–3 | Build TOM capabilities: SOR selection doc assembly, capability reference, sourcing email generator, structured handoff |
| Weeks 3–5 | Pilot with 1 TOM on live sourcing; measure improvement; collect feedback |

---

## TOM Automation

*Merges into the proposal's "What funding delivers". Outlook response tracking is Phase 2a; the dependency engine and handoff release are Phase 1 with prerequisites confirmed by the TOM; the Costpoint PR watch is Phase 2b.*

### What the portal adds for TOM

| Friction | Why it needs the portal |
|---|---|
| TOM monitors email for SOR responses | Detecting replies needs Outlook access and a server to watch the mailbox |
| TOM hands off via informal email | A checklist the TOM fills is a document; a handoff the SCA receives with context attached, and that releases work when prerequisites are met, needs shared state |

### TOM automation in the portal

- SOR response tracking via Outlook Graph API
- Event-driven dependency engine: SOR TO + PR + PWS → auto-release to SCA queue
- PR monitoring via Costpoint API with auto-notification to TOM

### TOM metrics in the portal

| Metric | Today | Target with portal |
|---|---|---|
| TOM→SCA handoff latency | Hours/days via email | Near-instant release to the SCA queue on prerequisite completion |
| SOR response tracking | TOM monitors email; overdue responses missed | Auto-detected; dashboard shows status |

---

## Appendix A — TOM Workflow Diagrams

*Merges into Appendix A of the appendices document.*

### TOM portions of end-to-end sequence (today vs. portal)

```mermaid
sequenceDiagram
    participant TOM
    participant Portal as Portal (with Doc Builder embedded)
    participant Systems as External Systems

    Note over TOM,Systems: TOM — Sourcing & Selection
    alt Today
        TOM->>TOM: Identifies candidate SORs from memory
        TOM->>TOM: Writes and sends solicitation emails individually
        TOM->>TOM: Monitors inbox for responses; no deadline view
        TOM->>TOM: Drafts SOR selection document from scratch
    else Portal
        Systems-->>Portal: Catena requirement detected (optional)
        TOM->>Portal: Confirms requirement; looks up SORs in capability reference
        Portal->>Portal: AI drafts solicitations; TOM reviews and sends
        Systems-->>Portal: SOR response emails detected via Graph API
        Portal->>Portal: AI extracts capability and pricing from responses
        TOM->>Portal: Reviews comparison; AI drafts selection document
    end

    Note over TOM,Systems: TOM — PR & PWS Finalization
    alt Today
        TOM->>TOM: Works with Finance on PR; polls Costpoint or waits for email
        TOM->>TOM: Fills SH PWS template in Doc Builder, or by hand
    else Portal
        Portal->>Systems: Monitors PR approval via Costpoint API
        Systems-->>Portal: PR approved — notifies TOM
        TOM->>Portal: Creates SH PWS from the PWS schema; AI pre-fills from the requirement
    end

    Note over TOM,Systems: HANDOFF — TOM to SCA
    alt Today
        TOM->>TOM: Emails the SCA a link to the PWS folder
    else Portal
        TOM->>Portal: Completes handoff checklist; portal verifies PWS, PR, pricing, SOR TO
        Portal->>Portal: Releases the Task Order to the SCA queue with context attached
    end
```

### Automation progression — TOM-specific steps

Doc Builder has only a basic SH PWS template for the TOM today, so the "Today" column is mostly the manual process. The middle column is what the funded Doc Builder extensions give on their own; the last column adds the portal's integrations.

| Step | Today | Doc Builder extended | Portal |
|---|---|---|---|
| SOR capability lookup | 👤 From memory | ⚙️ Searchable reference | Same |
| SOR solicitation | 👤 Manual email | ⚙️ AI-drafted + 👤 Review/send | ⚙️ AI-drafted, sent from portal + 👤 Approve |
| SOR response tracking | 👤 Monitor email | 👤 Monitor email | ⚙️ Detected via Graph API; due-date view |
| SOR selection document | 👤 Manual (30–60 min) | ⚙️ AI-drafted + 👤 Review | Same |
| PR tracking (TOM side) | 👤 Poll Costpoint | 👤 Poll Costpoint | ⚙️ Polled via Costpoint API; TOM notified |
| SH PWS creation | 👤 Fillable template (basic) or by hand | ⚙️ AI pre-fills from requirement + 👤 Review | Same |
| Handoff to SCA | 👤 Informal email | 👤 Informal email | ⚙️ Verified checklist; release to SCA queue with context |

Legend: 👤 = human action required · ⚙️ = automated by tool/portal

---

## Appendix B — TOM Improvements (Value Stream)

*Merges into Appendix B "Improvements mapped to problems" and "Prioritization" tables.*

### Improvements mapped to problems

| ID | Problem addressed | Proposed improvement | Requires infra? |
|---|---|---|---|
| I-10 | P-11 (manual SOR selection doc) | SOR selection document via Doc Builder engine | **No** |
| I-11 | P-10 (capability from memory) | SOR capability reference — searchable lookup by NSN | **No** |
| I-12 | P-9 (informal response tracking) | AI-drafted sourcing emails from structured data | **No** |
| I-13 | P-12 (unstructured handoff) | Structured handoff checklist with prerequisite verification and context carried to the SCA queue | Yes (shared state) |
| I-14 | P-9 (no deadline visibility) | SOR response tracking via Outlook Graph API | Yes |
| I-15 | P-13 (PR tracking TOM/Finance) | PR monitoring with auto-notification on approval | Yes |

### Prioritization (TOM items)

Order within the TOM work, after the validation session. The first two need no infrastructure and sit in Phase 2a; the handoff needs the portal's shared state and ships in Phase 1.

| Order | Improvement | Rationale |
|---|---|---|
| 1 | I-10 — SOR selection doc assembly | Same engine; eliminates manual template work |
| 2 | I-12 — AI-drafted sourcing emails | AI generates; TOM reviews |
| 3 | I-13 — Structured handoff | Verifies prerequisites; eliminates SCA rework |

---

## Open Questions (Must Validate)

Validation gates Phase 2a (TOM documents and Outlook tracking), not Phase 1. The Phase 1 handoff checklist uses the prerequisites already documented in the process baseline and is co-designed with pilot users during the build. Before the Phase 2a content can be merged back into the main proposal, we need to confirm:

1. **TOM's actual sourcing workflow** — Is the SOR solicitation → response → selection flow accurate? What steps are we missing?
2. **SOR capability reference** — Does this data exist in any form today? Who maintains it?
3. **Handoff mechanics** — What exactly does the TOM send the SCA today? Email? Teams? What's attached?
4. **PR coordination with Finance** — What's the TOM's role vs. Finance's? How does the TOM know when a PR is approved?
5. **PWS creation** — Does the TOM create the SH PWS, or does it come from elsewhere?
6. **Time estimates** — Are the "30–60 min" figures for SOR selection doc accurate?

---

*Leidos Proprietary — not to be reproduced, disclosed, or exported without written approval of Leidos.*
