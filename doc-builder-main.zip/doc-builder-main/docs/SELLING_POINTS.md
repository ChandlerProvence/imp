# Doc Builder: Selling Points

*Last updated: October 23, 2026.*

*Why the tool exists, who it serves, what it does, and what it has been measured to save. Figures are marked as timed, confirmed, or estimated; sources are the process baseline (`docs/public/fms-procurement-process.md`) and the portal proposal (`docs/public/pop-proposal.md`). For the LCSP and CDRL use case specifically, see `SELLING_POINTS_LCSP_CDRL.md`.*

**Live app:** <https://ams-oot.pages.lsde.leidos.com/doc-builder/>

---

## The problem

Procurement teams produce the same package of documents over and over. On the FMS F-16 Sustainment program, every approved Purchase Requisition (PR) becomes a Task Order, and every Task Order needs a set of Word documents: a memo to file, a proposal memo, a price reasonableness memo, and the award itself. Each document repeats facts that already exist in the source material: the NSN and quantity from the PWS, the price from the IDIQ price sheet, the PR number, the vendor, the period of performance, the preparer's name and phone.

Before Doc Builder, that package was assembled by hand:

- **Re-typing.** The same NSN, quantity, and price were keyed into four documents from three source files. The August 2026 value stream map timed the template-filling steps alone at roughly 1 to 1.5 hours per TT&E Task Order.
- **Cross-checking by eye.** Confirming that the PR, PWS, Source Selection, and price sheet agree took another 20 to 30 minutes, and errors that slipped through became rework loops. PRs arrive with upstream errors "more than they should," and the share returned has never been counted.
- **Tribal knowledge.** Eleven of the sixteen steps in the Shipping Hub ladder rest on undocumented knowledge in someone's head rather than a written rule. Onboarding and cross-training carry that risk.
- **Templates that drift.** Each person kept their own copy of each Word template, so wording, formatting, and which fields were filled varied by author.
- **Volume that is about to quadruple.** The program's goal is 125 PRs a month, four times the 2026 average of about 30, with a 7-business-day turnaround. One buyer working without interruption can award about 8 a day by hand.

The same pattern appears anywhere a team drafts standardized documents from a pile of source files: NDAs, Life Cycle Sustainment Plans, modification memos, compliance checklists.

---

## Who it is for

| Audience | What they get |
|---|---|
| **Subcontract Administrators (SCAs)** | A guided, TurboTax-style interview per document set. Upload the source files, let the AI draft every field it can support with evidence, accept or reject each value, download a finished Word package. |
| **Task Order Managers (TOMs)** | Fillable PWS templates for TT&E and Shipping Hub work, and a source-document consistency review that catches disagreements between the PR, PWS, and pricing before the SCA starts. |
| **Program and functional leads** | Standardized output from the team's own approved templates, calculated totals that cannot be mistyped, and validation rules that flag out-of-policy values such as funding that exceeds the task order price. |
| **Template owners and power users** | Upload a new document type as a tagged Word file plus a JSON schema, or build the schema from the tags in the browser, with no developer and no code deploy. |
| **Other programs** | A schema-driven engine that is not tied to FMS. Adding a document type is configuration, not code. The Life Cycle Sustainment Plan schema (14 sections, 112 fields) shows the same engine on a long narrative document. |
| **Security and IT** | No server, no database to host, no new system to accredit. Data stays in the user's browser; AI calls go only to the existing LiteLLM proxy. Automatic CUI detection routes controlled documents to the IL5 endpoint. |

---

## Key features, with concrete examples

### 1. Fill once, generate the whole set

A **document set** merges several document types into one interview, de-duplicating shared fields. The TT&E set (memo to file, proposal memo, price reasonableness memo, award) asks for the NSN, quantity, vendor, and PR number once and writes them into all four documents. Six sets ship today: TT&E, TT&E with Modification, Straight-to-Repair, Repair, Shipping Hub, and PWS.

On the Preview page each document expands to an inline rendering of the actual `.docx`. **Download All (.zip)** packages the set in one click.

### 2. AI drafting from your own source documents

Each document type declares **recommended upload slots**. The TT&E award asks for the active PWS, the PR, the SOR response, the IDIQ price sheet, the Source Selection, and contact information. Drop the files in, and the AI proposes a value for every field it can support from them, in one structured batch.

Proposals arrive as an **accept/reject list**, not as text pasted into a box. Each value is checked against the field's type and allowed options before it can be applied. Nothing is written into the document without a human accepting it.

For narrative fields the AI drafts complete prose and marks drafts that rest mainly on standard practice rather than a source with lower confidence, listing unconfirmed facts in its reply rather than silently inventing them.

Example: upload a vendor quote, a PWS, and a price sheet to the Repair price reasonableness memo. The AI fills the parts table (NSN, nomenclature, quantity, unit rate per line), the vendor and contract numbers, the period of performance, and drafts the price reasonableness narrative citing the IDIQ rate as the basis. The SCA reviews fifteen proposed values instead of looking up and typing fifteen values.

### 3. Large documents handled client-side

Small documents (under about 10,000 characters) go into the prompt whole. Large ones are chunked, embedded, and stored in the browser's IndexedDB; at drafting time the most relevant passages are retrieved and sent alongside the small documents. A 60-page PWS does not blow the prompt budget, and the embedding index persists across sessions so a document is processed once.

Supported inputs: `.pdf`, `.docx`, `.xlsx`, `.xls`, `.csv`, `.txt`, `.md`, `.json`, and images. Scanned PDFs without a text layer and password-protected files are rejected with a clear message rather than producing empty drafts.

### 4. Cross-document consistency checks

Two layers catch disagreements between source documents:

- **Automatic observations.** Whenever two or more documents are attached, the AI reports contradictions, gaps, and assumptions to a Conflicts tab with severity, the documents involved, and a recommended action. A proposed field value tied to a conflict carries a badge that jumps to the finding.
- **Source Document Consistency Review.** A standalone document type that systematically compares every shared fact across uploads: NSNs, quantities, unit and extended prices (recomputing the arithmetic), dates, contract and case numbers, parties, contacts, scope wording. Each disagreement becomes a row in a findings table the SCA dispositions as Open, Dismissed, Sent for correction, or Corrected. It is told never to certify the documents as correct, only to report what was checked and found.

This is the 20 to 30 minute "review PR against PWS and Source Selection" step from the process baseline, done by machine and recorded.

### 5. AI review of the finished package

**Review with AI** on the Preview page sends the rendered output back for a final check: unfilled placeholders, related values that contradict each other, totals that do not add up, incomplete sentences, and for sets, facts that differ between documents. Findings land in the same Conflicts tab and the review is conversational, so the user can ask about any flagged item.

### 6. Calculations and validation that live in the schema

Numbers that are derived are never typed:

- In the TT&E award, each parts row's total unit cost is `COALESCE(tte_rate, 0) + COALESCE(rr_rate, 0) + COALESCE(str_rate, 0)` and the firm-fixed price is `SUM(parts_list.total_unit_cost)`.
- In the Task Order Modification, the price change is `total_ff_price - price_from` and the funding change is `funded_amount - funding_from`.

Validation rules warn without blocking. The modification schema flags a funded value greater than the task order price with the message "Funded value exceeds the task order price; excess funds normally need to be deobligated." Rules are visible in the wizard, the sidebar, the Review page, and to the AI, so every layer agrees.

### 7. Conditional documents

**Content blocks** turn sections of the Word template on and off from the answers. The Task Order Modification has ten: scope change, price change, funding change, buyer representations, precedence, payment schedule attachment, and so on. A funding-only modification produces a document with only the funding paragraphs, and the fields for the other changes are hidden in the interview, in the AI's view, and in the output.

### 8. Real Word output from the team's own templates

Output is a genuine `.docx` generated through Docxtemplater from the template the team already uses, with `{{TAGS}}` added. Formatting, headers, tables, and signature blocks are untouched. Markdown in narrative fields becomes proper Word paragraphs, lists, and tables. Table of Contents fields are real Word fields. Images embed with their captions. Output filenames are built from answers, such as the TO number.

### 9. Controlled information handled automatically

Two endpoints are configured: Proprietary (IL2) and CUI (IL5). On upload under IL2, every document is screened for CUI markings with a regex pre-screen (CUI banners, category codes, FOUO, NOFORN, ITAR, distribution statements B through F, export-control notices), followed by an AI classification on the IL5 endpoint when the regex finds nothing. A flagged document is saved but its text is sent to no AI endpoint until the user either switches to CUI mode or affirms it is not CUI. Images with CUI markings are quarantined from vision extraction. Every document shows a badge for the endpoint it was saved under, and CUI documents are hidden while in Proprietary mode.

### 10. Team-maintained templates

Users add document types themselves at `/templates`:

- Upload a tagged `.docx` plus a `.schema.json`, or upload the Word file alone and choose **Build the schema from the tags**.
- Edit sections, fields, types, hints, and order in an in-app editor with a live preview of the rendered template.
- The upload runs the same integrity checks as CI. Problems appear with stable error codes and a **Copy for your AI assistant** button, and a shipped authoring guide tells any chatbot how to fix them.
- **Submit for team use** produces a bundle a developer imports with one command; when it ships as a built-in, holders of the custom copy are offered a one-click switch.

Progress files embed any custom template they use, so a shared session installs its template on the colleague's browser.

### 11. Built for daily use without a developer on call

- **Save and load progress** as a portable JSON file; compatibility warnings explain exactly which answers are affected when a schema has changed since the save.
- **Multi-tab safety** locks a session to one editing tab.
- **Full backup and restore** of all browser data.
- **Automatic model substitution** when the proxy retires a model, with a banner naming the old and new model.
- **Copy Error Report** on every error and **Export Chat for Troubleshooting** on every conversation, both scrubbed of field values and document content.
- **Fast / Balanced / Thorough** effort tiers per conversation, with the Thorough tier using the advanced model with extended thinking.
- **Focus buttons** on the document, each section, and each field point the AI at exactly the scope the user means.
- **SharePoint and OneDrive search** inside the document picker through AskSage, so source files do not have to be downloaded first.
- **Profile auto-fill** puts the preparer's name, title, phone, and email into every new document.

---

## Differentiators

### Versus doing it by hand

| By hand | Doc Builder |
|---|---|
| Key the same NSN, quantity, and price into four Word files | Enter once, or accept the AI's extraction once; all four documents fill |
| Eyeball the PR against the PWS and price sheet | Consistency review lists every disagreement with the values and documents involved |
| Compute totals in your head or in a side spreadsheet | Totals are formulas in the schema and cannot be mistyped |
| Remember which paragraphs to delete for a funding-only mod | Content blocks remove them from the interview and the output |
| Each author's copy of the template drifts | One template per document type, version-controlled, with integrity tests in CI |
| New hire learns eleven undocumented steps | Field hints, upload slots, and validation rules encode the rule next to the field |

### Versus a general-purpose chatbot or a shared Claude project

A chatbot can draft prose, but it has no notion of a document type, a field, a set, or a Word template. Doc Builder constrains the AI to a schema: every value lands in a typed field, is checked against allowed options, is traceable to the user's acceptance, and renders into the approved template without copy-and-paste. Grounding rules require specific facts (names, dates, amounts, identifiers) to come from the sources, and unconfirmed facts are surfaced instead of written. Chat-based workflows also drift as each user saves their own prompts; here the prompt is the schema, shared by everyone.

### Versus Word mail merge or a form-to-document tool

Mail merge fills tags from a flat table. Doc Builder adds extraction from unstructured source files, retrieval over large documents, cross-document conflict detection, formulas, conditional sections, validation rules, a review pass on the finished output, CUI routing, and a guided interview with per-field AI help. And unlike a forms product, it is schema-first: a new document type is a JSON file and a tagged template, with zero application code and no licensing.

### Versus Power Apps, Dataverse, or a hosted portal

Doc Builder is static files on GitLab Pages with state in the browser. Hosting cost is zero, there is no server to patch or accredit, and no connector licensing (Power Platform was costed at roughly $5 to 6K a year for the equivalent). The whole application redeploys as one unit to another host, including a .mil environment, and it is designed for provider portability: tool definitions are plain JSON schema, errors are classified by HTTP status rather than SDK class, and LiteLLM is the compatibility layer, so moving to OpenAI-family models through the proxy is a configuration change.

What it does not do, by design: shared queues, handoffs, or cycle-time measurement across a team. Those need shared state and are the subject of the separate portal proposal, which embeds Doc Builder rather than replacing it.

---

## Measurable benefits

The project's own documents distinguish timed results from estimates. Both are listed.

### Time per document (timed and estimated)

| Measure | Value | Basis |
|---|---|---|
| Shipping Hub price reasonableness memo, one user, one document | ~1 hr → ~45 min (15 to 20 min saved) | **Timed** pilot, recorded in the process baseline |
| Fill template fields across the TT&E set (Tabs 2 to 5, Final Tab, Index Checklist) | ~1 to 1.5 hr by hand → AI drafts, SCA reviews; ~1 hr saved | Manual figure from the August 2026 value stream map; saving is a developer estimate, not timed |
| Cross-check PR against PWS, Source Selection, price sheet | ~20 to 30 min by hand → AI flags discrepancies; ~0.5 hr saved | Same basis |
| **Hands-on time per TT&E Task Order** | **~2.5 to 3.25 hr → 0.5 to 1.5 hr; ~1.5 hr saved** | Estimate; if the team's lower manual figure (~1 to 1.5 hr) is right, the saving is nearer 0.5 to 1 hr |

### Annual effect at program volume (derived)

| PRs per month | SCA hours saved per year at ~1.5 hr each |
|---|---|
| 30 (2026 average, from 261 PRs confirmed Jan to mid-Oct) | ~540 |
| 125 (program goal) | ~2,250 |

### Effort to extend (observed)

| Task | Effort |
|---|---|
| Add a new document type (tag the Word template, generate the schema, validate, register) | ~2 developer hours |
| Add a document type as a user, without a developer | Upload at `/templates`; validation runs in the browser |
| Add a schema to a set, or create a set | Edit one `.set.json` file |
| Add a validation rule or error kind | One module plus one registry line |

### Cost and footprint

| Item | Value |
|---|---|
| Hosting | $0; static files on GitLab Pages, state in the browser |
| AI | Existing LiteLLM proxy; no new licensing |
| Keep-current effort once in production | 1 to 2 developer hours a week, averaged |

### Quality safeguards (counted in the repository)

| Safeguard | Count |
|---|---|
| Built-in document types | 21 (19 FMS, including 5 variants that share a template; Life Cycle Sustainment Plan; NDA) |
| Document sets | 6 |
| Automated unit and component tests | ~1,470 |
| End-to-end browser test suites | 12 |
| Template integrity checks | Run in CI and on every user upload, same code path |
| Ground-truth regression fixtures | Hand-authored reference documents re-rendered and diffed on every test run |

### Accuracy, as the tool treats it

No accuracy percentage is claimed. The design makes errors visible rather than promising their absence:

- Every AI value is accepted or rejected by a person before it enters the document.
- Specific facts must be grounded in a source; ungrounded ones are reported, not written.
- A response cut off by the model's output limit drops the partial value and re-asks, so a truncated number is never applied.
- Derived numbers are formulas, not entries.
- The consistency review and the final AI review are explicitly told not to certify correctness, only to report what was checked and what was found.

---

## In one paragraph

Doc Builder turns a pile of source documents and an approved Word template into a finished, consistent document package through a guided interview with AI drafting. It encodes the team's rules in a schema instead of in people's heads, calculates what can be calculated, hides what does not apply, checks the sources against each other and the output against itself, keeps controlled information on the right endpoint, and does all of it in the browser with no server to run. It is in daily use on the FMS F-16 Sustainment program, where it is estimated to save about 1.5 hours of hands-on work per Task Order, and a new document type costs about two hours to add, or none if a user uploads it themselves.
