# Code-quality plan

This plan comes from a clean-code review of the codebase done on 2026-10-07. The overall grade was B+.
- **What's already good:** TypeScript is strict-clean, lint is clean, tests pass, comments explain *why*, and most logic lives in the engine rather than the views.
- **What needs work:** a few units do too much, some code is copied instead of shared, errors are swallowed in places, and there are a handful of real bugs.

The plan was re-checked on 2026-10-08 against `main` after the error-handling framework merged (`src/errors/`, `trackWrite`, the classifiers). That framework already fixed some of the original findings; they are listed under *Resolved upstream* at the end.

## Delivery

- Each phase is its own branch and MR into `main`, so it can be reviewed and reverted on its own.
- Phase 1 (bugs) ships first. The refactor phases change no behavior unless a step says so.
- **Gates for every phase:**
  - `npm run typecheck`, `npm run lint` (no new warnings) and `npm test` must pass.
  - New regression tests must fail before the fix and pass after it.
  - The existing `useDocumentManager.{cui,slots,defaultReference}.test.ts` suites are the safety net for the Phase 4 hook refactor. They must pass **unchanged**, except for that phase's consumer-update step.
- **Rules from CLAUDE.md:**
  - User-facing errors go through `toAppError` / `appErrorException`, and their wording lives in `src/errors/catalog.ts`.
  - Background IndexedDB writes go through `trackWrite()`.
  - Tool definitions stay as raw JSON schema. Nothing should require going to Anthropic directly; everything keeps working through the LiteLLM proxy.

**Decision:** a required table counts as filled only when it is **complete** (`tableIsComplete`). This applies everywhere, including the Review page.

## Test coverage before refactoring [added 2026-10-20]

A coverage run on 2026-10-20 measured all of `src/` at 64% line and 56% branch coverage. The default `npm run test:coverage` reports 57% because the `include` list in `vitest.config` leaves out `db/`, `errors/`, `extraction/`, `hooks/` and `context/`. Several phases rewrite files with little or no coverage, so the order below adds tests first wherever a refactor would otherwise have no safety net.

The development plan tracks the test steps (order step 1, and step 0 of Phases 2, 3 and 5) as a separate **Important** sustainment item, *Tests for untested AI and page code*. They're worth having even if the refactor phases never ship.

| Phase | Files it changes (line / branch coverage) | When to write the tests |
|---|---|---|
| 2 | `litellm.ts` 20% / 18%, `asksage.ts` 11% / 2%, `cuiDetection.ts` 25% / 12%, `extractImageDescription.ts` 4% / 0% | **Before.** Characterization tests come first; see Phase 2, step 0. |
| 3 | `useAiChat.ts` 47% / 38%, `SessionContext.tsx` 65% / 44%, `AiPanelContext.tsx` 0% | **Mostly during.** Tests on today's internals (refs, the recursive `sendToLLMRef`) would be thrown away. Before starting, add only a few behavior-level tests; see Phase 3, step 0. |
| 4 | `useDocumentManager.ts` 80% / 71% | **Ready now.** The existing `useDocumentManager.*.test.ts` suites are the safety net. |
| 5 | `Preview.tsx` 0%, `Home.tsx` 0%, `AppMenuBar.tsx` 35%, `ManageTemplates.tsx` 0% | **Before.** The Preview smoke tests move to the start of the phase; see Phase 5, step 0. |
| 6 | `loader.ts`, `generateDocx.ts` 79% / 76% | **Ready now.** The before-and-after render diff and the ground-truth tests check that output is unchanged. |

**Order:**
1. **Tests for code that no phase rewrites.** These tests will last. They cover the prompt builders (`templateTextService.ts` 10% branch, `promptUtils.ts` 10% branch, `documentReviewPrompt.ts` 14%, `unifiedPrompt.ts` 37%), `errors/globalHandlers.ts` and `ErrorBoundary.tsx` (both 0%), and `db/chatHistory.ts`, `db/chatTroubleshootExport.ts`, `generation/downloadAll.ts`, `hooks/useTokenEstimate.ts` and `ai/tokenEstimate.ts` (all 0%). This can be its own MR or part of Phase 2.
2. Phase 2.
3. Phase 3.
4. Phases 4 and 6, in either order.
5. Phase 5.
6. **Coverage floor in CI.** Widen the coverage `include` list to `src/**` and add per-directory thresholds, at least for `engine/`, `errors/` and `generation/`. Do this last: a floor turned on earlier would block the refactor MRs while coverage moves around.

**Status (2026-10-22):** the order step 1 tests and the step 0 tests for Phases 2, 3 and 5 have shipped (branch `worktree-sustainment-asksage-tests`; `src/**` line coverage 68.8% → 75.6%). AskSage is hidden behind the `askSage` flag pending AskSage team approval and is kept, so skip the Phase 2 `asksage.ts` cleanup and its tests until it is turned back on. The six suspected bugs these tests found are in `docs/2026-10-22-phase0-bug-fixes-plan.md`; fix them before Phase 2 so the refactor starts from a green, bug-free baseline.

**Decision needed before Phase 2 (settled 2026-10-22, see above):** the development plan's sustainment item *Remove or quarantine experimental surfaces* may delete `asksage.ts`, or hide it behind a flag. Settle that first. If AskSage isn't in daily use, flag it off or delete it, and skip both the Phase 2 `asksage.ts` cleanup and its tests.

---

## Phase 1 — Correctness fixes (`fix/review-bugs`)

| # | Bug | Fix | Regression test |
|---|-----|-----|-----------------|
| 1 | **AI chat tool results** (`src/hooks/useAiChat.ts`, `onToolCalls`). A failed `search_references` is mapped back to its call id by indexing into a list of only the search calls. If `get_template_context` calls are mixed in, the id comes out wrong or `undefined`, and the result is dropped. The model then gets a `tool_use` with no `tool_result`. `JSON.parse` on search and template-context arguments has no guard; a throw there leaves `toolCycleActiveRef` stuck and the UI hangs. Unknown tools, and tools with no handler, get no result at all. | Each async tool promise catches its own error and turns it into an error result keyed by its own `call.id`; the index mapping is deleted. Guarded argument parsing. A final branch that returns "tool unavailable". A `.catch` on the continuation that resets the cycle and surfaces the error. | `useAiChat.test.ts` (new): a template-context call plus a failed search in one turn; malformed arguments; an unknown tool |
| 2 | **BulkEditDrawer files stuck "parsing"** (`BulkEditDrawer.tsx`, parse effect). Adding a file while another is still parsing makes the effect clean up, which cancels the earlier result. That file is already marked processed, so it is never parsed again. | Replace the per-effect cancel flag with a mount-scoped ref, and ignore results for files that have since been removed. | Add A, then add B before A resolves → both get parsed |
| 3 | **Feature flags** (`src/ai/featureFlags.ts`). A corrupt localStorage value makes `JSON.parse` throw on every AI call. `setFeatureFlags` would permanently save the session-only auto-disables. The console text points to a Settings section that doesn't exist. | Wrap the read in try/catch and fall back to the defaults. `setFeatureFlags` merges onto the persisted flags only. Correct the console text. | `featureFlags.test.ts` (new) |
| 4 | **Stale debounced save** (`src/context/SessionContext.tsx`). `setAnswersBatch` saves immediately but doesn't cancel a pending `setAnswer` debounce, so an older snapshot can overwrite the batch 300 ms later. The timer is never cleared on session switch or unmount. | Cancel the pending debounce in `setAnswersBatch`. Clear it on session change and on unmount. | `setAnswer` then `setAnswersBatch` → the stored answers include the batch |
| 5 | **CUI status writes not tracked** (`useDocumentManager.ts`: `requestAttach`, `affirmNotCuiAndAttach`, `switchToCuiAndAttach`). `updateCuiStatus` isn't awaited, so a failed write is an unhandled rejection and IndexedDB falls out of step with the UI. | Wrap the calls in `trackWrite()` so a failure raises the `SaveErrorBanner`. | A rejected write raises the write error |
| 6 | **Review and sidebar disagree** (`src/pages/Review.tsx`). Review keeps its own copies of `fieldHasValue` / `countUnfilledFields` and treats any partially filled required table as filled. The sidebar shows it as in progress. | Export `fieldHasValue`, `fieldIsComplete` and `countUnfilledFields` from `src/engine/sectionStatus.ts`. Required fields use `fieldIsComplete`. Delete the Review copies. | A partially filled required table counts as unfilled |
| 7 | **Wrong download hints** (`src/pages/Preview.tsx`). After downloading one document of a set, the banner shows every schema's hints, not just the downloaded one's. | Store which hints to show along with the success state. | Covered by the Phase 5 Preview tests; checked by hand in Phase 1 |

## Phase 2 — Shared AI request code and small cleanups (`refactor/ai-http`)

0. **Characterization tests first**, in their own commit before any refactoring. Test only the public functions, with `fetch` / the SDK mocked, so the tests still pass after the extraction unchanged:
   - `litellm.ts`: `fetchCompletion` streaming and non-streaming, retry on a retryable error, no retry on a non-retryable one, timeout, abort, usage mapping, `listModels`.
   - `asksage.ts` (unless it's deleted; see *Decision needed before Phase 2*): one success and one failure for each of the 3 fetch sites, plus the CORS failure.
   - `cuiDetection.ts` and `extractImageDescription.ts`: the request shape, plus success and failure.
1. **New `src/ai/http.ts`**, provider-neutral:
   - `createSdkClient(apiKey, baseURL?)` replaces the 5 `new Anthropic(...)` sites (`litellm.ts` ×3, `cuiDetection.ts`, `extraction/extractImageDescription.ts`). The inline copy of the base-URL logic in `extractImageDescription` goes too.
   - `mapUsage(usage)` uses one typed guard. It replaces the two copies of the usage mapping in `litellm.ts` and their `as unknown as Record` casts.
   - `withRetry(fn, { maxRetries, delayMs, backoff, signal })` decides what to retry from `toAppErrorException(err).appError.retryable`, the way `embeddings.ts` already does. `chatCompletion` and `fetchEmbeddingBatchCore` both use it.
2. **asksage.ts**:
   - One `postJson()` wrapper with the CORS check, used by the 3 fetch sites.
   - An `m365Tool()` factory for the 4 repeated tool definitions.
   - Runtime shape guards in place of the `McpToolResult` casts.
   - Delete the hardcoded `/home/...` path.
   - Delete the unused `MCP_MODELS[1]` and the "Bedrock fallback" comment.
3. **Stale or dead code**:
   - The litellm "two-phase timeout" has a multiplier of 1, so it does nothing. Keep one timeout that resets on each event.
   - Fix the `topologicalSort` doc comment: it doesn't throw on a cycle.
   - Fix the stacked docblocks in `loader.ts`.
4. **formulaEngine**:
   - Move `getDeps` and the adjacency setup to module level; they are shared by `topologicalSort` and `detectFormulaCycles`.
   - In dev, the bare catches log a formula parse error once per formula. Return types don't change.
5. **Duplicates**:
   - `sanitizeFilename` moves to `src/utils/` (used by `sessionExport` and `chatTroubleshootExport`).
   - `bulkEdit` coercion gets shared `parseBoolean`, `parseDate` and `matchEnum` helpers. Each caller keeps its current failure return value, pinned by a test.
   - Check this against `src/engine/validation/coerce.ts` first and reuse it where the semantics match.

## Phase 3 — Chat tool dispatch and persistence (`refactor/ai-chat-dispatch`)

0. **Behavior-level tests first**, driven through the hook's public API only:
   - send, then a tool call, then exactly one continuation;
   - `stopStreaming` partway through a turn;
   - a conversation restored after remount.

   Don't add tests for refs or internal ordering; this phase replaces them.
1. **Pure modules**:
   - `src/ai/toolArgs.ts`: `parseObservationsArgs` and `parseProposeChangesArgs(json, request, { dropLastKey })`.
   - `src/ai/chatRestore.ts`: `extractFromHistory(msgs, request)`. It restores **every** tool call in a message; it uses `filter`, not `find`.
2. **`src/ai/toolDispatch.ts`**: `dispatchToolCalls(calls, handlers, ctx): Promise<ToolOutcome[]>`.
   - It never rejects. `outcomes[i].toolCallId === calls[i].id`, and each call gets exactly one result or one deferral (`ask_user`).
   - The handler factories live in `src/ai/toolHandlers.ts`.
   - `ctx.getBatchChanges()` fixes `fields_still_empty` when a turn makes several `propose_changes` calls.
   - `ctx.onEffects` sends changes and observations to the UI as they settle.
3. **useAiChat**:
   - `sendToLLM` uses the dispatcher.
   - The handlers are held in a ref, so `sendToLLM` no longer depends on their identity.
   - `messagesRef` becomes the source of truth through an `append()` helper.
   - The 3 auto-sends inside `setMessages` updaters move outside the updaters. With StrictMode on, these currently send twice in dev.
4. **SessionContext**:
   - All `setX` updaters become pure.
   - Persistence moves to `useSessionPersistence(sessionId)`, which is called after the state update. It still uses `trackWrite`.
5. **Tests**:
   - `toolDispatch.test.ts`: interleaved failures, unknown tool, bad JSON, deferral, truncation.
   - `chatRestore.test.ts`.
   - `useAiChat.test.ts`: under a StrictMode wrapper there is exactly one continuation; `stopStreaming` before a search resolves → no continuation.

## Phase 4 — Split `useDocumentManager` (`refactor/document-manager`)

Use a store-style reducer, not separate sub-hooks. The parse effect, `commitDraft` and the remove/reset paths each write 6–10 of the same state slices; splitting those slices across sub-hooks would just move the coupling into props passed between them.

`src/hooks/documentManager/`:
- `useDocStore.ts`: `[state, dispatch, getState]`. The reducer runs against a ref, so reads are synchronous. This replaces the `draftDocIdsRef`, `draftSlotByDocRef`, `filesRef` and `fileSlotTargetsRef` mirrors.
- `state.ts`: `DocState` plus domain actions (`UPLOAD_SAVED`, `DRAFT_ADDED/REMOVED`, `DRAFT_ID_REPLACED`, `SLOT_PLACED`, `COMMIT_APPLIED`, `DOC_DETACHED`, `GENERATED_*`, `EMBED_*`, `CUI_STATUS_SET`, `RESET`).
- Pure functions, each with its own unit tests:
  - `classifyParsedFile.ts`: the CUI gate and quarantine decision.
  - `planCommit.ts`.
  - `promptText.ts`: returns `usedIds`; the facade calls `updateLastUsed`.
  - `selectors.ts`.
- `embedding.ts`: `embedWithProgress({ docId, title, text, dispatch, isCurrent })`. One helper replaces the 3 copies and adds the missing version guard to the endpoint-switch re-embed.
- `useUploadPipeline.ts` and `useManifestDocs.ts`.
- `useDocumentManager.ts`: a thin facade with the same API, stable callbacks and a memoized return value. Today it returns a new object on every render, which re-renders every `AiPanelContext` consumer.

Steps (tests pass after each one):
1. Extract the pure functions.
2. Add `useDocStore` with a temporary `patch` action, and convert the `setX` calls mechanically.
3. Swap in the domain actions one group at a time: remove/delete → generated docs → `replaceDraftId`/`placeInSlot` → commit → upload → reset.
4. Make the callbacks stable and memoize the return value.
5. Move the upload pipeline and the manifest fetch into their own hooks.
6. Add the re-embed version guard, with a test.
7. Update the consumers:
   - narrow the deps in `AiPanelContext`;
   - delete the ref workaround in `Preview.tsx`;
   - remove `buildReferenceDocTexts` (it always returns `[]`).

## Phase 5 — Shared UI pieces and view cleanup (`refactor/ui-primitives`)

0. **Smoke tests first**, moved here from step 6: Preview in single and set mode (rendering, copy, download, hints), and the AppMenuBar and Home session-import flows. They must pass unchanged after steps 1–5.
1. **`src/components/ui/`**:
   - `Modal` + `useFocusTrap`: restores focus on close and skips disabled elements.
   - `Button` with variants.
   - `IconButton` with a required `aria-label`.
2. **Adopt them in**:
   - SettingsDialog, ConfirmDialog and CuiWarningDialog (these 3 have copied focus traps);
   - DocumentPickerDialog and BulkEditDrawer (neither has a trap; the drawer also has no dialog role or Escape handling);
   - the force-approve modal in Review;
   - every icon-only button that has no `aria-label`;
   - the repeated button class strings.
3. **Hooks**:
   - `useCopyToClipboard()` replaces the 2 copied `execCommand` fallbacks in Preview.
   - `useDownloadAction(fn)` replaces 3 copies of the download state handling.
   - `useSessionImport()` replaces the copies in AppMenuBar and Home.
   - `useSaveThen(action)` replaces AppMenuBar's 3 confirm-and-save flows, and adds the error handling they lack.
4. **Preview.tsx**:
   - `usePreviewDocuments()` takes the docx previews, the generated-docs effect and `triggerReview`.
   - Rendering splits into `<SinglePreview>` and `<SetPreview>`.
   - Shared `<ReviewWithAiButton>`, `<DownloadHintsBanner>` and `<DownloadHintsBox>`.
5. **SettingsDialog**:
   - An `<ApiKeyField endpoint>` component for both key blocks.
   - The 14-setter reset effect is replaced by remounting the body with a `key` when the dialog opens.
6. **Tests**:
   - `Modal.test.tsx`;
   - `useSessionImport.test.ts`;
   - a smoke test for BulkEditDrawer (the Preview smoke tests are in step 0).

## Phase 6 — Schema loader and docx render pipeline (`refactor/loader-render`)

1. **`validateSchema`** (`src/schemas/loader.ts`):
   - Split it into stage validators (top level, sections, tables, `same_as`, computed fields, derived fields, soft normalization, content blocks, validation rules), each returning `{ errors, warnings }`.
   - Soft normalization returns a cleaned **copy** instead of deleting keys from the imported JSON module.
   - The entry point returns `{ schema | null, errors, warnings }`.
2. **Diagnostics**: export `schemaDiagnostics`, and show a dismissible banner on Home in dev builds when a schema fails to load. Today such a schema silently disappears.
3. **`renderDocxFromArrayBuffer`** (`src/generation/generateDocx.ts`):
   - Make each `// ──` stage its own function: text replacements, freetext XML, answer preparation (no reassigning the parameter), template data, derived fields, content blocks, TOC, images.
   - The orchestrator stays at about 30 lines.
4. **Proving the output is unchanged**:
   - Before the refactor, render every schema's fixtures with `tools/render-docx.ts --text`.
   - After it, re-render and diff; the output must be identical.
   - `npm test -- groundTruth` must pass.

---

## Verification (manual, per phase, in `npm run dev`)

- **Phase 1:**
  - in AI chat, trigger a template-context call and a search in the same turn;
  - add two files quickly in Bulk Edit;
  - open Review with a partially filled required table;
  - download one document of a set and check the hints shown.
- **Phases 3–4:**
  - attaching and detaching documents;
  - the CUI warning flow;
  - switching endpoint, which re-embeds;
  - generated docs on Preview;
  - a full drafting turn with tool calls;
  - restoring a conversation after reload.
- **Phase 5:**
  - keyboard-only use of every dialog: Tab wraps, Escape closes, focus returns to the trigger;
  - copy and download in single and set mode.
- **Phase 6:** download a `.docx` for one schema from each set and open it in Word.

## Resolved upstream (no action)

- **Embeddings retried a 400 by matching message text.** Retry decisions now come from `classifyHttpStatus` plus the catalog's `retryable` (`src/ai/embeddings.ts`, `embeddings.errors.test.ts`).
- **The litellm error mapping was spread across the file.** It is now centralized in `src/errors/classifiers/ai.ts`.
