# Centralized Field Registry — Design Document

## Problem

Fields are currently defined inline in each `.schema.json` file (15 schemas, ~12+ sharing fields like `header.country`, `header.scs_name`, `contacts.tom_phone`). When a field's definition is repaired in one document set, it can break another set because there's no single source of truth — consistency depends entirely on manual discipline. The `mergeSetSchemas()` function deduplicates by key (`section_id.field_id`) using "first definition wins," which means subtle differences in `ai_hint`, `label`, or `required` go undetected.

## Goal

Introduce a field catalog as the canonical source of truth. One edit to a field definition propagates to all documents that use it. Documents become ordered collections of field references plus per-document metadata (TKM, overrides, template info).

---

## Architecture

### Data Model

```
Field Catalog (source of truth)     Document Definitions         Sets (unchanged)
─────────────────────────────────   ────────────────────────     ────────────────
_fields/fms-header.fields.json      _documents/fms-tte-award     sets/tte.set.json
  "header.country": {                 .doc.json: {                 { schemas: [...] }
    label, type, required,              id, title, version,
    ai_hint, auto_fill, ...             docx_template,
  }                                     template_key_map,
                                        sections: [
                                          { ref: "header",
                                            fields: ["header.country", ...] }
                                        ],
                                        field_overrides: { ... }
                                      }
```

### Compilation

A build script reads catalog + doc definitions → produces the existing `.schema.json` format. Runtime code (`loader.ts`, `mergeSet.ts`, engine, generation) is **unchanged**.

### Field Identity

Fields keep the existing `section_id.field_id` composite key (e.g., `header.country`). This preserves:
- All stored IndexedDB session answers
- AI tool call format (`propose_changes`)
- Template placeholder format (`{{section_id.field_id}}`)
- `same_as`, `computed`, and `derived_fields` references

No migration of stored data is required.

### Document Definition Format (`*.doc.json`)

Each document specifies:
- **Which fields** it uses (ordered list per section)
- **Template metadata** (TKM, template_column_map, docx_template, output_filename)
- **Field overrides** — limited set of per-document properties:
  - `required`, `ai_hint`, `label`, `template_heading`, `outline_number`, `heading_level`
- **Computed/derived fields** (these are document-specific, not shared)
- **Reference docs & recommended uploads**

### Overridable vs. Fixed Properties

| Overridable per-document | Fixed in catalog (must be consistent) |
|--------------------------|---------------------------------------|
| `required` | `type` |
| `ai_hint` | `options` (enum values) |
| `label` | `columns` (table structure) |
| `template_heading` | `auto_fill` |
| `outline_number` | `computed` / `same_as` |
| `heading_level` | |

### Compilation Pipeline (`scripts/compile-schemas.ts`)

1. Load all `_fields/*.fields.json` → unified field map
2. Load all `_documents/*.doc.json`
3. For each document: resolve field references, apply overrides, assemble sections, write compiled `.schema.json`
4. Validate compiled output with existing `validateSchema()` logic
5. Error on: missing field references, type conflicts, invalid overrides

Compiled `.schema.json` files stay committed to git (so `loader.ts` static imports work unchanged and `npm run dev` doesn't require a mandatory compile step).

---

## File Layout

```
src/schemas/
  _fields/                              # NEW — Field catalog
    fms-header.fields.json              # Header/identification fields
    fms-contacts.fields.json            # TOM, SCS contact fields
    fms-pricing.fields.json             # Pricing tables and computed totals
    fms-task-order.fields.json          # POP, PWS, modification fields
    shared.fields.json                  # Cross-domain (NDA, LCSP, etc.)

  _documents/                           # NEW — Document definitions
    fms-tte-award.doc.json
    fms-tte-proposal.doc.json
    fms-tte-price-reasonableness.doc.json
    fms-tte-no-sow-memo.doc.json
    fms-tte-mod.doc.json
    fms-sh-request.doc.json
    fms-sh-proposal.doc.json
    fms-sh-award.doc.json
    fms-sh-price-reasonableness.doc.json
    fms-pws-sh.doc.json
    fms-pws-tte.doc.json
    fms-repair-to.doc.json
    fms-repair-price-reasonableness.doc.json
    lcsp.doc.json
    nda.doc.json

  sets/                                 # UNCHANGED
  fms-tte-award/                        # UNCHANGED (compiled .schema.json + .docx template)
  loader.ts                             # UNCHANGED
  mergeSet.ts                           # UNCHANGED
  types.ts                              # UNCHANGED

scripts/
  compile-schemas.ts                    # NEW — Compiler
  extract-field-catalog.ts             # NEW — One-time migration script
```

---

## Implementation Steps

### 1. Define catalog & document JSON schemas
Create `src/schemas/_fields/field-catalog.schema.json` and `src/schemas/_documents/document.schema.json` for editor validation/autocomplete.

### 2. Write the extraction script (`scripts/extract-field-catalog.ts`)
- Read all existing `.schema.json` files
- For each unique `section_id.field_id` across all schemas: pick the canonical definition (longest ai_hint, OR for required, assert type consistency, flag conflicts for manual review)
- Group into domain-based catalog files
- Generate `.doc.json` definitions referencing the catalog
- Output a report of inconsistencies found (different hints, labels, etc.)

### 3. Write the compiler (`scripts/compile-schemas.ts`)
- Load catalog → resolve document definitions → produce `.schema.json` files
- Validate output with existing `validateSchema()`
- Add `"_generated": true` marker to compiled files (so agents know not to hand-edit)
- Add npm script: `"compile-schemas": "tsx scripts/compile-schemas.ts"` and wire into `prebuild`

### 4. Run extraction, verify byte-for-byte match
- Execute the extraction script
- Compile from the new sources
- Diff against existing schemas — should match (minus intentional fixes)
- Run `npm test` and `npm run build` to confirm no regressions

### 5. Fix inconsistencies in the catalog
- Review the extraction report
- Normalize ai_hints, labels, required flags in the catalog (single edits)
- Recompile

### 6. Update agent instructions
- `schema-repair.md`: edit catalog + doc definitions instead of compiled schemas
- `schema-generate.md`: produce doc definitions + catalog entries for new fields
- Add "do not hand-edit" comment to top of compiled `.schema.json` files

---

## Build-Time Validation (Compiler Checks)

The compiler enforces rules that today depend on manual discipline:

1. **Field existence**: Every field referenced in a `.doc.json` must exist in the catalog
2. **Type consistency**: A field's type in the catalog cannot conflict with how it is used
3. **Section consistency**: A field's section prefix must match the section it is placed in
4. **Override constraints**: Only allowed properties can be overridden
5. **Complete TKM coverage**: Every field in a document should have a TKM entry (or be in output_template)
6. **Cross-set safety**: Warn if a field is referenced in documents from different sets with conflicting overrides that would break `mergeSetSchemas()`

---

## Verification

1. **Byte-level regression:** After extraction + compilation, diff compiled output against pre-migration schemas
2. **Test suite:** `npm test` passes unchanged
3. **Build:** `npm run build` succeeds
4. **Round-trip:** Edit a field in the catalog → recompile → verify all consuming schemas updated
5. **Cross-set safety:** Modify a field used in multiple sets → confirm no set breaks
6. **Agent workflow:** Run schema-validate on compiled output → no new issues

---

## Key Benefits

- **Single source of truth:** One field definition, used by many documents
- **Safe repair:** Fixing a field in the catalog fixes it everywhere — no cross-set breakage
- **Build-time error detection:** Inconsistencies caught before deployment
- **Zero runtime changes:** Compiled output is identical to today's schemas; no engine/UI/DB changes
- **Incremental adoption:** Existing schemas continue to work as-is during migration
