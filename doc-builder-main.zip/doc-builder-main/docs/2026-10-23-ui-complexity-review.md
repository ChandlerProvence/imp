# UI Complexity Review: Less Intimidating, Still Intuitive

**Date:** 2026-10-23
**Status:** Analysis only. Nothing has been implemented.
**Method:** Every screen's controls were inventoried by reading the source. The app was not run, so visual weight is inferred from the Tailwind classes.

## The problem

When options are visible, people can **recognize** what to do instead of having to remember it, and that makes the app intuitive. When every option has the **same visual weight**, people have to weigh all of them at once, and that makes it intimidating. Separating those two effects removes most of the intimidation and keeps most of the intuitiveness.

## Principles used

| Principle | Source | What it means here |
|---|---|---|
| Progressive disclosure | Xerox Star; Nielsen | Show the common options. Keep advanced ones one predictable step away, always in the same place. |
| Staged disclosure | TurboTax interview mode | One step at a time. The wizard already works this way. |
| Recognition over recall; Hick's Law | Nielsen; Hick–Hyman | Visible options help, but decision time grows with the number of options that look equally important. |
| Visual hierarchy and chunking | Gestalt; Miller | Grouping options and making some of them quieter often works better than removing them. |
| Multi-layered interfaces | Shneiderman; Findlater & McGrenere | Users choose to move into richer layers (*adaptable*). Avoid interfaces that rearrange themselves (*adaptive*), because they break people's spatial memory. |
| Overview first, details on demand | Shneiderman | Show the outline of the task first, and expand only what the user is focused on. |
| Contextual controls | Office contextual ribbon tabs | A control appears where and when it applies. |
| Conservation of complexity | Tesler's Law | Good defaults move complexity out of the UI and into the system. |
| Low floor, high ceiling | Papert; Resnick | Make starting easy without limiting experts. |
| Reversibility reduces fear | Carroll's "training wheels" | Visible undo, a "Saved" indicator, and "you can change this later" make busy screens feel safe. |

### Tiering method

Rate each control on **how often it's used** and **how costly it is to miss**, then put it in one tier:

1. **Prominent:** frequent and core to the task. At most one or two primary actions per screen.
2. **Visible but quiet:** frequent but secondary. Subdued styling, grouped with related controls.
3. **One step away:** used occasionally. Put it behind a ⋯ menu, an "Advanced" toggle, or show it on hover or focus.
4. **Settings:** rare, or set once.

Most intimidating screens have tier-2 and tier-3 controls promoted to tier 1.

## Overall assessment

The core flow (Interview sections → Review → Generate) is already well disciplined:
- Each step has one clear primary action.
- Review has a single green button.
- The Hints and Destinations toggles are off by default.

Nearly all of the intimidation comes from four places:
1. The first-load screen.
2. AI controls repeated on every Interview field.
3. Buttons on each Manage Templates row.
4. The Template Editor.

## 1. First load (Home)

**What a new user sees:**
- Three columns, two of them empty:
  - The left sidebar reads "STEPS / No document open".
  - The AI panel is open at **50% of the window** with "Start a document to use AI-assisted drafting" (`AiPanelContext.tsx:159-162`).
  - The role cards sit in a narrow middle column.
- The mailing-list banner shows above everything.
- There is no API-key onboarding. The only no-key warning is an amber note inside Settings (`EndpointSettings.tsx:84-88`).
- Settings shows "Last backup: **Never**" in red before the user has any data.

About 15 controls are on screen when one is needed: choose a role.

| Tier | Controls |
|---|---|
| Prominent | Role cards, then document cards |
| Quiet | Load Progress… |
| One step away | Mailing-list request: ask after the first successful download |
| Hidden until relevant | Sidebar and AI panel while no session exists; the red backup warning until there is data to lose |

**Recommendations:**
- Collapse the sidebar and the AI panel when no session exists.
- Move the mailing-list request to after the first download.
- Prompt for the API key the first time the user tries an AI feature, instead of letting the feature fail.
- Show the backup warning only once data exists.

## 2. Interview (the biggest source)

**Repeated AI controls:**
- There are three levels of wand buttons:
  - document (violet, 24px)
  - section (emerald, 24px)
  - field (orange, 20px)
- A section with 10 fields shows about 12 colored wands.
- The chat panel's ScopeSelector duplicates these wands, because it lists every field as an option (`ScopeSelector.tsx:52-78`).
- Date, number, and enum fields each get a wand, but AI drafting rarely helps with those.

**Layout:**
- The AI panel defaults to 50% of the window (`ResizableRightPanel.tsx:24-37`).
- Non-table fields are capped at `max-w-xl`.
- As a result, the form isn't the clear focus.

| Tier | Controls |
|---|---|
| Prominent | Field inputs, Next → |
| Quiet | Section outline, section wand, chat textarea, Send |
| Contextual (hover or focus) | Field wand on non-freetext fields. Keep it always visible on freetext fields. |
| One step away | Model selector (Fast / Balanced / Thorough) moves to Settings or a ⋯ menu. "Shift+Enter for new line" moves into the placeholder. |
| Already right | Hints and Destinations toggles, off by default |

**Recommendations:**
- Show the field wand on hover or focus, except on freetext fields.
- Reduce the default AI panel width to about 35%.
- Move the model selector out of the chat input row.

**Leave as is:** the Alerts and Proposed Changes tabs stay visible even when empty. Hiding them until they have content would be the *adaptive* pattern that research says to avoid. Showing counts on the tabs is the better choice.

## 3. Manage Templates

**What's wrong:** no action stands out as the main one.
- Three blue primary buttons are visible by default:
  - Add template…
  - Edit in app
  - Submit for team use, once per row
- Each active template row has 6–8 buttons (`ManageTemplates.tsx:291-319`).
- "Modify an official template" and "Create a new template" are always-open cards, holding 5 controls and 3 copy-prompt buttons between them.

**Recommendations:**
- **Each row:**
  - Keep **Draft document** and **Edit** visible.
  - Show **Submit for team use** only while the template is local-only.
  - Move Download for editing, Export bundle, Replace…, Switch to official, and Delete into a ⋯ menu.
- **The page:**
  - Make **Add template…** the only primary action.
  - It leads to a choice of how to start: upload Word + schema, start from an official template, or build with an AI chatbot.
  - This replaces the two always-open cards.

## 4. Template Editor

**What's wrong:**
- A 10-field template shows **80–100 inputs and buttons at once**.
- Each field card has 7 controls (`FieldCard.tsx`):
  - label
  - type
  - required
  - AI-hint textarea
  - move up
  - move down
  - move to section
- Options and column sub-editors add more on top of that.

**Recommendations:**
- Collapse each field card to one summary line: `Label · type · required · {{TAG}}`.
- Expand only the selected field, one at a time. This is the clearest progressive-disclosure case in the app.
- Replace move up/down with a drag handle, or put it in a ⋯ menu.
- Hide the AI-hint textarea behind "+ Add AI hint" until the field has a hint.

## 5. Smaller items

- **Review:** good overall.
  - Up to five summary banners can stack: required, problems, optional, approved, and set.
  - Combine them into one summary line.
- **Preview:**
  - The goal action is blue here but green on Review. Pick one color for "complete this step".
  - In set mode, each row has 3–5 small buttons. **Word** plus a ⋯ menu is enough.
  - Set mode shows Download All (.zip) twice.
- **Documentation:** a "Copy" button is injected after *every* inline code span (`Documentation.tsx:35-77`). Limit it to code blocks, or show it on hover.
- **Reassurance:** the only save feedback is the SaveErrorBanner, which appears when saving fails. A quiet "Saved" indicator would make experimenting feel safer.

## Defects found during the inventory

These are not design-philosophy issues and can be fixed on their own:

| Issue | Location |
|---|---|
| Delete on an archived template runs immediately, with no confirmation and no red styling | `src/pages/ManageTemplates.tsx:449` |
| `ConfirmDialog` always renders its optional secondary action as filled blue. "Delete documents too" (blue) sits next to "Delete template" (red), and the "is ready" dialog has two blue primary buttons | `src/components/ConfirmDialog.tsx:104-110` |
| The table field wand never shows its active state | `src/components/TableFieldRenderer.tsx:192` |
| The collapsed sidebar lists all `schema.sections`, including ones the expanded outline hides | `src/components/AppSidebar.tsx:217` |
| File → Clear Session and Edit → Clear All Answers stay enabled with no session | `src/components/AppMenuBar.tsx:293, 303` |
| Icon-only buttons without `aria-label`: the Preview set-row chevron and the DocsNav collapse button | `src/pages/Preview.tsx:476`, `src/components/DocsNav.tsx:70` |
| `BulkEditDrawer` and most of `src/components/bulk-edit/` are never mounted. Only `ConversationDropdown` and `FieldChangeCard` are used | `src/components/bulk-edit/` |

## Suggested priority

These three give the most relief for the least change:

1. **Home:** collapse the side panels when no session exists, and defer the mailing-list request.
2. **Interview:** show the field wand on hover or focus except on freetext fields, and narrow the default AI panel.
3. **Template Editor:** collapse field cards to summary lines.

Next, fix the Manage Templates ⋯ menus and the defects table. Most of the defects are one-line changes.
