# Plan: Add Component Unit Tests (Vitest + React Testing Library)

## Context

Unit tests exist for pure-function modules (engine, generation, ai, schemas) but **zero component tests** exist. This plan adds full React component testing for all 32 `.tsx` components using explicit assertions (no snapshots).

---

## Setup

### Install dependencies

```bash
npm install -D @testing-library/react@16 @testing-library/jest-dom@6 @testing-library/user-event@14 jsdom fake-indexeddb
```

### Update `vitest.config.ts`

- Change `environment` from `"node"` to `"jsdom"`
- Add `"src/**/*.test.tsx"` to `include`
- Add `setupFiles: ["src/test/setup.ts"]`
- Add `src/components/**` and `src/pages/**` to coverage include

### Source changes (2 one-line exports)

- `src/context/SessionContext.tsx` — add `export { SessionContext };` (line ~82 area)
- `src/context/UserPreferencesContext.tsx` — add `export { UserPreferencesContext };`

This allows test wrappers to provide mock context values directly without bootstrapping the real providers (which need IndexedDB, react-router, etc.).

---

## Test Infrastructure (`src/test/`)

### `src/test/setup.ts`
- Import `@testing-library/jest-dom/vitest` (adds DOM matchers)
- Import `fake-indexeddb/auto` (polyfills IndexedDB for Dexie)
- Mock `localStorage` with an in-memory implementation, reset between tests
- Mock `Element.prototype.scrollIntoView` (missing in jsdom)
- Mock `window.matchMedia`
- `afterEach` cleanup

### `src/test/renderWithProviders.tsx`
- Custom `render()` wrapper that wraps components in:
  - `MemoryRouter` (configurable `initialEntries`)
  - `SessionContext.Provider` with mock value
  - `UserPreferencesContext.Provider` with mock value
- Accepts overrides for context values per-test

### `src/test/mocks.ts`
- `createMockSessionContext(overrides?)` — all methods as `vi.fn()`
- `createMockUserPreferences(overrides?)` — role + setRole mock
- `createMockSchema(overrides?)` / `createMockSection()` / `createMockField()` — minimal fixtures
- `createMockSession(overrides?)` — minimal Session object

---

## Test Files (32 total, colocated as `Component.test.tsx`)

### Phase 1: Presentational (no context needed)

| Component | Key assertions |
|-----------|---------------|
| `menu/MenuDivider` | Renders an `<hr>` element |
| `ConfirmDialog` | Hidden when `open=false`; shows title/message when open; fires onConfirm/onCancel |
| `bulk-edit/VerboseLog` | Renders log entries |
| `FieldRenderer` | Renders correct input type per field.type; fires onChange; shows AI badge; linked read-only state |
| `FieldsPanel` | Maps fields to FieldRenderer; resolves linked labels |
| `chat/ChatBubble` | User vs assistant styling; markdown rendering; draft "Use this" button |
| `chat/MessageList` | Maps messages; shows empty state |
| `bulk-edit/SectionSelector` | Checkbox interactions; select all/deselect all |
| `bulk-edit/BulkEditPreview` | No changes message; grouped display; toggle/accept/reject |
| `bulk-edit/ProposedChangesPanel` | Renders change list; apply/reject buttons |
| `bulk-edit/FieldChangeCard` | Shows before/after values; field label resolution |
| `bulk-edit/ReferenceDocsPanel` | Renders doc list; remove button fires callback |
| `bulk-edit/ContextBar` | Renders section chips and doc count |

### Phase 2: Router-dependent (wrap in MemoryRouter)

| Component | Key assertions |
|-----------|---------------|
| `SectionOutline` | Status icons (○/◐/✓); active section highlighting; Link navigation |
| `menu/MenuDropdown` | Renders items; fires onClose |
| `menu/MenuItem` | Click fires onClick; submenu on hover |
| `menu/MenuBar` | Opens/closes dropdowns; Escape closes |

### Phase 3: Local state/hooks

| Component | Key assertions |
|-----------|---------------|
| `chat/ChatInput` | Send on click/Ctrl+Enter; Stop button when streaming; disabled states |
| `bulk-edit/BulkEditInput` | Textarea changes; file drop handling |
| `ResizableSidebar` | Renders children; drag resizes; localStorage persistence |
| `bulk-edit/ConversationList` | List rendering; selection highlight; click callback |
| `bulk-edit/ConversationDropdown` | Dropdown toggle; selection; new conversation |
| `bulk-edit/UploadedDocsLibrary` | Checkbox selection; multi-select |
| `SettingsDialog` | Opens/closes; saves role+apiKey via context hooks |
| `TableFieldRenderer` | Renders columns; add/remove rows; cell editing; fixed-row mode |

### Phase 4: Context-heavy (use renderWithProviders + module mocks)

| Component | Key assertions |
|-----------|---------------|
| `AppMenuBar` | Menu items render; New Document calls startSession; Clear/Delete with confirm |
| `AppSidebar` | Section outline from context schema; active section from URL |
| `WizardShell` | Shows fields for active section; next/back navigation; chat panel toggle |
| `chat/ChatPanel` | Loads messages; sends user message; streams response; error state |
| `bulk-edit/BulkEditDrawer` | Tab switching; close callback |
| `bulk-edit/SetupCard` | Section selection; file upload; start button |
| `bulk-edit/BulkEditChatView` | Streaming; tool call (propose_changes) rendering |

---

## Module Mock Strategy

| Dependency | Mock approach |
|------------|--------------|
| react-router | `MemoryRouter` wrapper + optional `vi.mock` for `useNavigate` |
| SessionContext | Direct `<SessionContext.Provider value={mock}>` via exported context |
| UserPreferencesContext | Direct `<UserPreferencesContext.Provider value={mock}>` |
| `src/ai/litellm` | `vi.mock()` — mock `streamChatCompletion` with controlled callbacks |
| `src/db/chatHistory` | `vi.mock()` — mock getConversation, addMessage, etc. |
| `src/db/session` | `vi.mock()` where needed |
| `src/extraction/parseFile` | `vi.mock()` returning resolved text |
| localStorage | In-memory mock in setup.ts |

---

## Verification

```bash
npm test                    # All tests pass (existing + new)
npm run test:coverage       # Coverage includes components
```
