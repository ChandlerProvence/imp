# Template Authoring Plan — Phase 2 breakdown

**Date:** 2026-10-09
**Status:** Steps 0, A, and B complete (2026-10-09), Step C complete (2026-10-13), Step D shipped 2026-10-19, Step E (documentation sync) done, branch `worktree-template-authoring-phase2`. Step D2 (added 2026-10-13) was paused on 2026-10-19 until *Collapse overlapping schema mechanisms* part (a); that landed on branch `worktree-formula-collapse` (2026-10-19), so D2 is ready to start.
**Parent:** Phase 2 of `docs/2026-10-09-template-authoring-plan.md`. This document breaks that phase into steps that each ship on their own.

## Context

Phase 1 (shipped 2026-10-08) lets users upload a `.schema.json` + `.docx` pair and validates it in the browser. The schema is still hand-written or produced by an external chatbot with copy-paste round trips. Phase 2 removes JSON from the user's path: upload a tagged `.docx` alone, get a starter schema scaffolded from the tags, fix labels, types, and sections in a form, preview the output with sample answers, install. The same editor also fixes already-installed custom templates and clones official templates ("Edit in app").

**Acceptance test** (from the parent plan): a user with Word and no chatbot adds six tags including one table loop to a sample document, uploads the `.docx` only, corrects two field types and all labels in the editor, previews, installs, and generates a document, with zero JSON edited and zero validation errors the editor cannot fix in place.

## What exists and is reused

| Need | Reuse |
|---|---|
| Tag inventory (scalar, loop, column, header/footer, hints, split runs) | `scanTemplate()` in `src/schemas/templateScan.ts` → `TemplateScan` |
| Hint stripping / split-run merge | `cleanTemplateTags()` in `templateScan.ts` |
| One validator | `validateUserTemplatePair({ schemaText, docx })` in `src/schemas/userTemplateValidation.ts`; accepts `custom-` prefixed ids, rewrites id/category/docx_template, returns `PreparedTemplate` |
| Install / replace in place | `installTemplate(prepared, { basedOn })` in `src/schemas/userSchemas.ts` (bumps `schema.version` and `revision`) |
| Field-diff impact message | `buildFieldManifest` / `diffFieldManifests` in `src/schemas/fieldManifest.ts`; `DiffSummary` (private in `UploadTemplateDialog.tsx` today) |
| Issue rendering | `ValidationReport` in `src/components/templates/` |
| Clone a built-in as a custom copy | logic inside `buildStartingPointZip()` in `src/schemas/userTemplateBundle.ts` (id `<id>-custom`, title "(custom)", `based_on`, bake `template_text_replace`) |
| Render with answers → HTML | `renderDocxFromArrayBuffer()` in `src/generation/generateDocx.ts` + `docxToHtmlPreview()` in `src/generation/docxPreview.ts`; displayed with `<ReactMarkdown rehypePlugins={[rehypeRaw]}>` as on the Preview page |
| Custom template storage | `userTemplates` table (Dexie v12), `UserTemplate` in `src/db/types.ts`, access in `src/db/userTemplates.ts` |
| Docx test fixtures | `buildDocx` / `para` / `headerXml` in `src/test/docxFixtures.ts` |

Gaps found while planning: `scanTemplate` has no paragraph or heading context; there are no humanize or snake-case helpers in `src/`; `SectionDef` has no `description` property, so the parent plan's "add a description" is dropped; there is no drag-and-drop library (reorder uses up/down buttons and a "move to section" select); no routes use `React.lazy` yet.

Two deliberate deviations from the parent plan:

- The scaffold appends `-custom` to a filename-derived id only when the id collides with a built-in. A from-scratch template is not a copy of anything, and the stored id would otherwise read `custom-foo-custom`.
- Section descriptions are not offered (no schema support).

---

## Step 0 — Record the plan [0.5 hr]

This document, a pointer from the parent plan, and the step breakdown under Phase 2 in `docs/public/development-plan.md`. No README change (plan only).

## Step A — Pure modules: structure walk, scaffold, sample answers [4 hr]

No UI. Fixture-tested; reused by Phase 3 (`templateContext.ts`) and Phase 4 (viewer).

### A1. `src/schemas/templateStructure.ts`

`extractTemplateStructure(input): TemplateStructure`

- Walks every `word/*.xml` text part with the same paragraph and text regexes as `templateScan.ts` (exported from there rather than duplicated).
- Per paragraph: `{ part: "document" | "header" | "footer", index, text, headingLevel?, styleId?, outlineNumber?, inTable, tags: { name, prefix, offset }[] }`.
  - Heading detection: `<w:pStyle w:val="Heading(\d)…"/>`, the same family `tools/docx-utils.py extract-structure` uses; outline number via `^(\d+(?:\.\d+)*)\s`.
  - `inTable`: paragraph offset falls inside a `<w:tbl>…</w:tbl>` range.
- Also returns `headingStyleMap` (level → style id when styles deviate from plain `Heading{N}`) and `tagContext(tag)` returning the paragraph and its nearest preceding heading path.

### A2. `src/schemas/scaffoldSchema.ts`

`scaffoldSchema(scan, structure, { filename, basedOn? }): { schema, notes }`

Deterministic rules ported from `.claude/agents/schema-generate.md`:

- **Ids.** `originalId` is the kebab-case filename stem with `.docx` and the suffixes ` - Template`, ` Template`, `_Template`, ` Fillable`, `_Fillable`, `_R&R` removed (rule 16). `-custom` appended only on a built-in collision. `title` is the humanized stem. `version: 1`, `docx_template: "<id>.docx"`.
- **Sections.** One per top-level heading (lowest heading level present in the body) that has at least one tag beneath it, in document order. Tags before the first heading go to `header` ("Document details"). No headings → one section `main`. Section id is the snake of the heading text, deduplicated with `_2`, `_3`.
- **Scalar tags.** One field each, in the section of the paragraph where the tag first appears. Field id is the lowercase snake of the tag; label is the humanized tag (`SCS_NAME` → "SCS name"). Type: `date` if the name matches `/date|_dt$|_on$/i`; `number` if `/amount|count|qty|total|price|cost|rate|num(ber)?$/i`; `freetext` if the tag is the whole text of a body paragraph outside a table (with `template_heading`, `outline_number`, `heading_level` from the structure, rule 18); else `string`. Freetext candidates in headers or footers are downgraded to `string` with a note (rule 17). `required: false` everywhere. `ai_hint` from inline hints.
- **Loops.** One `table` field per loop tag, columns from the column tags (same name regexes, restricted to table column types), `template_column_map` written explicitly. A loop with no column tags gets one `value` column and a note.
- **`template_key_map`.** Every scalar and loop tag → `section.field`.
- Output passes `validateUserTemplatePair()` with zero errors by construction; tests assert that for every fixture.
- Naming helpers (`toSnakeId`, `humanize`, `kebabStem`) live in `src/schemas/naming.ts` for the editor to reuse.

### A3. `src/schemas/sampleAnswers.ts`

`placeholderAnswers(schema)`: every answer is the field label in brackets so a preview doubles as a tag-location map. string/freetext/date → `[Label]` (the date formatter passes non-ISO text through); number → `[Label]` unless the field has a `format`, then `1234.56`; boolean → `true`; enum → first option; multiselect → JSON array of the first option; table → two rows of `[Column label]`; `computed` and `same_as` skipped.

### A4. Tests

- `src/test/docxFixtures.ts` gains `headingPara(level, text, styleId?)` and `table(rows)`.
- `templateStructure.test.ts`: headings, outline numbers, in-table flag, header part.
- `scaffoldSchema.test.ts`: scalar only; hints; loop with columns; header/footer freetext downgrade; no headings; filename suffix stripping; built-in id collision. Each asserts the validator returns `ok` and every scanned tag is mapped.
- `sampleAnswers.test.ts`: render a scaffolded fixture and assert no `{{` remains.

## Step B — Drafts, route, and the schema editor [6 hr]

- **Draft storage.** `TemplateDraft { id: "draft-<uuid>", schema, docx, sourceName, basedOn?, notes, createdAt, updatedAt }` in `src/db/types.ts`; Dexie v13 adds `templateDrafts: "id, updatedAt"`; `src/db/templateDrafts.ts` mirrors `userTemplates.ts`. `src/schemas/templateDrafts.ts`: `createDraftFromDocx(file)` (clean → scan → structure → scaffold → put), `createDraftFromBuiltIn(schema)` (uses a `startingPointCopy()` extracted from `buildStartingPointZip`), `installDraft(draft, schema)` (validate → `installTemplate` → delete draft).
- **Route.** `/templates/edit/:id` via `React.lazy` in `App.tsx`. `src/pages/TemplateEditorPage.tsx` resolves the id to an installed template (`custom-`) or a draft (`draft-`), scans the docx once, renders `<TemplateEditor>`.
- **Editor** in `src/components/templates/TemplateEditor/`. `useTemplateEditor.ts` is a reducer over the schema: title, section rename/move/add/remove-if-empty/merge, field label/type/required/hint/options/date format/number format, field move within and between sections, column label/type/required/options. Every path change goes through one `retargetFieldPath()` that rewrites `template_key_map`, `output_filename`, and `same_as`. Only owned keys are touched; everything else carries through.
- **Guardrails.** A field is locked for move and type change when it has `computed`, `same_as`, `auto_fill`, `validate`, `rows`, `aggregates`, `visible_when`, or is referenced by another field; a badge explains why; label, hint, and required stay editable. Schema-level `content_blocks`, `derived_fields`, `toc`, `heading_style_map`, `recommended_uploads`, `reference_docs` are listed read-only.
- **Type picker.** Scalar-tag fields: `string | number | boolean | date | enum | multiselect | freetext` (`freetext` disabled for header/footer tags). Loop-tag fields are fixed to `table`. `image` is not offered. Field ids are read-only.
- **Panels.** `SectionList`, `FieldCard`, `ColumnEditor`, `OptionsEditor`, `TemplateTagsPanel` (tag → field → paragraph and heading path), `LockedBadge`.
- **Save.** *Check* runs the validator and reports without saving (added 2026-10-13); *Save* runs the validator, shows `ValidationReport`; when ok, installed templates show `DiffSummary` (moved to its own file) and the session count, then `installTemplate`; drafts call `installDraft`. Drafts autosave on change. *Download schema JSON* for users who want the file.
- **`/templates` page.** *Edit* on each row; a *Drafts* section with *Continue editing* / *Discard*.
- **Tests.** Reducer path-retargeting and lock rules; editor component test with `renderWithProviders`; drafts against fake-indexeddb.

## Step C — Preview before install [2 hr]

`TemplatePreview.tsx` as a collapsible panel in the editor: render with `placeholderAnswers`, convert to HTML, display; debounced on change; render errors shown through `AppErrorBox`. Clicking a field card scrolls the preview to its `[Label]` marker.

## Step D — Upload flow, Edit in app, docs [3 hr]

- `UploadTemplateDialog`: with a `.docx` and no schema, offer **Build the schema from the tags** → draft → editor. A docx with no tags raises a new `no-tags-found` issue (catalog entry; add the emitting file to the "every issue code is emitted somewhere" test). Scaffold notes show once at the top of the editor.
- *Modify an official template* gains **Edit in app** → `createDraftFromBuiltIn` → editor; the draft carries `basedOn` so *Switch to official* keeps working.
- Docs that ship with the feature: `docs/help/template-editor.md`; a short "you may not need this" preface in `docs/help/template-authoring-guide.md` (keeping every type and operator mention so the drift test passes); upload dialog and `/templates` copy mention the in-app path first.
- E2E in `e2e/tests/10-custom-templates.spec.ts`: the acceptance test (docx-only upload → editor → preview → save → draft document → preview page), and *Edit in app* → save → *Switch to official* visible.

## Step D2 — Let the AI guide encode dependencies [3–5 hr, added 2026-10-13]

**Why.** The editor can't add dependencies between fields (Phase 6 adds the simple ones). That makes a dependency the main reason anyone downloads the files for a chatbot. But the guide's *Rules for custom templates* tells the chatbot to keep `computed`, `formula`, `derived_fields`, `validate`, `same_as`, `auto_fill`, `aggregates`, `rows`, `toc`, `heading_style_map`, `recommended_uploads`, `template_heading`, `outline_number`, and `heading_level` exactly as they are, never add new ones, and "leave it for the developers". So neither path can add a dependency today. The rule came in with the guide (`d8ed96b`, 2026-10-08) and no reason was recorded.

**What validation already catches.** Upload validation runs the loader's checks (`collectSchemaErrors`) and reports each failure as `schema-invalid`, naming the field:

- `auto_fill`: one of the four profile keys.
- `same_as`: the source exists, isn't the field itself, has the same type, isn't a table or multiselect, and the links don't form a cycle.
- `validate`: every rule is checked against the rule registry, including its parameters, which field types it applies to, and that the fields it refers to exist.
- Formulas (`formula` on number fields and columns, schema `constants`): one validator in `src/engine/formula/validate.ts` checks syntax, every name against its scope, number types, aggregate arguments, `format` / `decimals` / `display`, constant names, and cycles across all formulas. Each message names the place and the token and lists what is allowed (`src/engine/formula/validate.test.ts` has every message).
- `rows`, `recommended_uploads`: structure.
- Since the refactor, `collectSchemaErrors` reports `same_as`, formula, `visible_when`, and `validate` errors in one pass; only unreadable sections or fields (non-objects, missing string ids) skip the cross-reference checks.

So a malformed dependency is rejected on upload. What validation can't catch is a well-formed but wrong formula: `price + qty` passes as easily as `price * qty`.

**Proposal, by group:**

| Group | Proposal | Reasoning |
|---|---|---|
| `same_as`, `auto_fill`, `validate` | **Allow** (decided 2026-10-13) | Small, fully checked, not affected by any planned refactor. |
| Fixed `rows`, `recommended_uploads` | **Allow** | Well checked. |
| Formulas (`formula`, `constants`, `format` / `decimals` / `display`), including totals (`SUM(table.column)`) | **Allow** (refactor landed) | One syntax, fully validated. A well-formed but wrong formula still looks right; see the sample-number preview below. |
| `toc`, `heading_style_map`, `template_heading` / `outline_number` / `heading_level` | **Keep blocked** | They refer to Word style ids and outline structure the chatbot can't see from the text, so it is likely to get them wrong in ways validation doesn't catch. |

**Decisions (2026-10-19).** D2 was paused until the formula refactor so the guide documents one syntax once. That refactor is done; what D2 can rely on:

- **Syntax and scopes** are in the guide's *Schema format → Calculated values* paragraph and the README *Calculated Values* section. The guide's example is checked by `templateAuthoringGuide.test.ts`, which also fails if a function name is missing from the guide or a retired key (`computed`, `derived_fields`, `aggregates`) reappears.
- **Migration** of anything written in the old shapes happens on read (`src/schemas/migrateStored.ts`, `migrateSchemaShape` in `src/engine/formula/migrate.ts`): stored custom templates and drafts, uploads, session imports, bundles, and backups. A chatbot that still writes `computed` gets its file rewritten on upload; the loader names the replacement if a raw file reaches it.
- **Totals now reach the document.** `aggregates` (UI footer only) is gone; a total is a formula field and renders wherever its tag is mapped.
- **Still open: sample-number preview.** The editor preview leaves formula fields empty, so a wrong formula only shows up in a real draft. Filling number inputs with sample values would make results visible before saving [~1 hr]. Recommended alongside D2.

**Work:**

- **Guide.** Replace the blanket *Advanced features* rule with: what may be added, what to keep as is, and that the chatbot must say so when a request needs a blocked feature. Document each allowed feature in *Schema format*: syntax, constraints matching the loader's checks, and a short example. Extend the worked example to use `same_as`, `auto_fill`, and one `validate` rule, so the existing "worked example passes upload validation" test covers them.
- **Drift tests** in `templateAuthoringGuide.test.ts`: every rule in the validation registry and every `auto_fill` key is named in the guide (like the existing field-type and operator checks).
- **Issue catalog.** The `schema-invalid` fix text stays generic, but check that the loader's messages for these features say what to change.
- **Correct the user-facing limits.** The help page's *What the editor can't change* table and `EDITOR_LIMITS` in the zip README currently tell users to download the files for every limit, including ones the guide blocks. Split them into three groups: changes the files can make, changes that need the developers (*Submit for team use*), and settings kept as is. Keep the drift test between the two.
- **Locks.** No change. The editor still locks fields that use these features (formula dependencies now come from the same scope resolver the evaluator uses); Phase 6 makes the simple ones editable in the app.
- **Formulas.** Replace the *Advanced features* bullet's `formula` / `constants` / `display` / `decimals` entries with permission to add them, pointing at *Calculated values*; extend the worked example with one formula field.

## Step E — Documentation sync

After the code lands, ask before updating `changelog.d/`, `README.md`, and ticking Phase 2 in `docs/public/development-plan.md`.

---

## Verification

1. `npm test`: new suites plus the existing `templateScan`, `userTemplateValidation`, `templateAuthoringGuide`, and `templateIntegrity` suites stay green.
2. `npm run build`: the editor page is its own chunk.
3. `npx playwright test e2e/tests/10-custom-templates.spec.ts`: the two new scenarios.
4. Manual: upload a tagged `.docx` only → editor → fix labels → preview markers land in the right places → save → draft a document → `/preview` renders. *Edit* an installed row, save, confirm `revision` increments and saved documents still open. *Edit in app* on an official template, save, confirm *Switch to official* appears. Reload mid-edit on a draft; work persists.

## Order

Step 0 first. Then A → B → C → D as separate merge requests (A has no user-visible change; B is the first shippable product; C and D complete the acceptance test). Step D2 after D, once the decisions in it are made. Step E after D2. Tick each step's sub-bullet in `development-plan.md` as it ships.
