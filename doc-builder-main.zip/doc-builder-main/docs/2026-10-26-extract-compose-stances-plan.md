# Two stances for the AI Assistant: extract and compose

**Date:** 2026-10-26
**Status:** Proposed. Nothing in this plan has started.
**Builds on:** `docs/2026-10-13-fill-run-steps-plan.md` (stepped fill run, Phases B and C supply the per-step runner) and `docs/2026-10-20-lcsp-drafting-quality-plan.md` (Phase 2 program brief and Phase 3 bounded review are where the two stances meet).
**Amends:** drafting-quality plan Phase 3 (review differs by stance) and the fill-run plan Phase B (steps are grouped by stance before they are grouped by section).

## Problem

Doc Builder has two different jobs that today run through one prompt and one effort setting.

| | Fact extraction | Solution drafting |
|---|---|---|
| Example | FMS templates: 13 of 15 schemas have zero freetext fields | LCSP: 54 of 112 fields are freetext, most ask for an approach or concept |
| What "correct" means | The value appears in a source, verbatim or by direct reading | The prose solves the problem the field poses, using the facts the sources supply |
| Cost of a wrong answer | A plausible invented value is worse than an empty field | An empty field is worse than a hedged draft with its assumptions stated |
| Model work | Lookup and transcription | Reasoning over several sources and the rest of the draft |
| Right tier | Standard model, no thinking, large batches | Advanced model, extended thinking, small groups of coupled fields |

The current prompt handles the split with one set of grounding rules written for extraction (`GROUNDING_RULES` in `src/ai/promptUtils.ts`) and one carve-out for narrative fields (`FREETEXT_DRAFTING_RULE`). The carve-out gives permission to keep writing when no source covers a section. It does not give permission to solve the problem, say what the model may assume, or ask for the facts it used. The effort tier (`src/ai/effortTiers.ts`) is one setting for the whole chat, so a Thorough fill run spends thinking on contract numbers and a Fast run drafts the maintenance concept without it.

## Design

**Stance** is a per-field property with two values.

- **Extract.** Truth is the sources. Propose a value only when a source states it. For string, number, date, enum and multiselect values, say which document it came from. No value is better than a plausible value. The identifier rule (never construct emails, phones, contract numbers, serials or addresses by pattern) applies verbatim.
- **Compose.** Truth has two layers. Specific facts (names, numbers, dates, sites, commitments, identifiers) still come from the sources, from already-extracted fields, or from the program brief. The approach, argument or recommendation is the model's job, informed by the field's `ai_hint`, the template context, the exemplar depth the judge rubric calibrates against, and standard practice for the document type. The draft names the facts it relied on and the assumptions it made, and its confidence drops below 0.6 when it rests mainly on practice. The identifier rule applies verbatim here too; it is the one place where composing turns into fabrication.

**Stance comes from the field type by default and a schema knob can override it.**

- `freetext` fields default to compose. Every other field type and every table column defaults to extract.
- An optional `ai_mode: "extract" | "compose"` on a field or table column overrides the default. An FMS memo's background paragraph that must only restate the request becomes `extract`. An LCSP table column that asks for a proposed support concept per subsystem becomes `compose`. This is schema-only, so no engine or component change is needed for a new document type.

**The fill run routes each step by stance.** This is where the two modes meet and the reason the design is not just two prompt blocks.

1. **Extract steps run first**, across every in-scope section, on the Fast tier regardless of the user's picker. They are cheap, batchable and produce the fact base.
2. **The program brief is built** (drafting-quality Phase 2) from the extracted facts and the sources. Compose steps read facts from it rather than re-searching.
3. **Compose steps run after**, one group of coupled sections at a time, with the brief pinned in the cached prefix. They run at the user's tier, with the picker acting as a ceiling: Thorough is the default for compose, and a user who picks Fast gets Balanced for compose steps and a one-line note in the progress line saying why.
4. **Verification differs by stance.** Extract proposals get a mechanical check that string values appear in a source, plus the existing conflict observations. Compose proposals get the bounded review from drafting-quality Phase 3 and the rubric judge. Neither check blocks the user. They set confidence and flag in the Changes tab.

**Prompt.** Replace the rule-plus-carve-out with two named blocks, `EXTRACT_RULES` and `COMPOSE_RULES`, and include only the one a step needs. Whole-document chat turns outside a fill run include both, each introduced by the field types it governs. The compose block adds three things today's text lacks: explicit permission to propose a solution, an explicit list of what may be assumed and what may not, and a request for a one-line "based on" statement naming the facts used.

## What changes

### 1. Stance resolution — new `src/engine/stance.ts`

```ts
export type AiStance = "extract" | "compose";
export function resolveStance(field: Field | TableColumn): AiStance;
```

Default by type, `ai_mode` overrides. Add `ai_mode?: AiStance` to `Field` and `TableColumn` in `src/schemas/types.ts`. The loader accepts the key and rejects any value other than the two literals. `templateScan.ts` gains no new check; an unknown `ai_mode` value is a loader error, not a template integrity issue.

### 2. Prompt blocks — `src/ai/promptUtils.ts`, `src/ai/bulkEdit.ts`

- `EXTRACT_RULES` is today's `GROUNDING_RULES` plus one line: "State which document each value came from in your reply."
- `COMPOSE_RULES` replaces `FREETEXT_DRAFTING_RULE`. Permission: "These fields ask for an approach, concept or recommendation. Propose one." Boundary: "Names, numbers, dates, sites, identifiers and commitments come from the sources, the working draft's extracted fields, or the program brief. Everything else may be your professional judgment." Reporting: "End each composed field's reply line with 'Based on:' and the facts you used, then 'Assumed:' for anything you supplied yourself." Confidence rule unchanged.
- `buildBulkEditChatSystemPrompt` takes the step's stance (or `"mixed"` for ordinary chat) and includes the matching block. The field listing marks each field `[extract]` or `[compose]` so the model sees the stance per field even in mixed turns.
- Table rows: the whole-row rule stays. A table with any compose column is a compose step; its extract columns still obey the identifier rule.

### 3. Fill plan by stance — `src/ai/fillPlan.ts` (fill-run plan B1)

`buildFillPlan` groups steps by stance first, then by section. Each `FillStep` gains `stance: AiStance`. The extract phase is one step per section with empty extract fields; sections with no extract fields are skipped. The compose phase is one step per section with empty compose fields, sub-stepped at eight fields as planned. When the schema declares `program_brief: true`, the brief step sits between the two phases. `coverageGap` is unchanged; the freetext-or-table split it uses already approximates the stance split and should now call `resolveStance` instead.

### 4. Tier routing — `src/hooks/useAiChat.ts`, `src/ai/effortTiers.ts`

Add `resolveStepTier(userTier: EffortTier, stance: AiStance): EffortTier`. Extract steps return `"low"`. Compose steps return `max(userTier, "medium")`. The step runner (fill-run plan B2) resolves the tier per step instead of once per run. Ordinary chat turns keep the user's tier. The progress line shows the effective tier when it differs from the picker ("Step 9 of 14 · Sustainment Strategy · Thorough").

### 5. Verification by stance — `src/ai/proposalChecks.ts` (new), drafting-quality Phase 3

- Extract: for every proposed string, number or date value, search the included documents and the retrieved chunks already in the conversation for the value as text. A miss lowers confidence to at most 0.4 and attaches a `report_observations` entry of type `assumption` with the field key. Numbers are matched after normalising separators and units; dates after parsing. This is a pure function over the proposal and the source text already in memory; it makes no model call.
- Compose: the bounded review from drafting-quality Phase 3, unchanged, plus the "Based on" line parsed into the proposal's metadata so the Changes tab can show it.

### 6. UI — Changes tab and progress line

- Each proposed change shows its stance as a small label and, for compose, the "Based on" and "Assumed" lines under the value.
- The progress line shows the current phase ("Extracting facts", "Building program brief", "Drafting") and the effective tier.

### 7. Tests

- `stance.test.ts`: defaults by type, override, table column, loader rejects bad values.
- `bulkEdit.validation.test.ts`: extract-only step contains `EXTRACT_RULES` and not `COMPOSE_RULES`, and the reverse; mixed turns contain both; field listing carries the stance tags.
- `fillPlan.test.ts`: LCSP plan has extract steps before compose steps; FMS task-order mod plan has no compose steps; `program_brief: true` inserts the brief step between phases.
- `effortTiers.test.ts`: `resolveStepTier` table.
- `proposalChecks.test.ts`: value present, number with different separators, date in another format, miss lowers confidence and emits an observation.
- `useAiChat.test.ts`: a two-stance plan sends the extract step at `low` and the compose step at the user's tier; a Fast user gets `medium` for compose.
- Template authoring guide test: `ai_mode` and both values appear in the guide.

## What this does to the other plans

- **Fill-run plan Phase B.** Steps are ordered by stance before section. Everything else in B1 and B2 stands.
- **Drafting-quality Phase 2.** The brief step moves from "step 0" to "between the extract and compose phases", so it can read extracted fields from the working draft.
- **Drafting-quality Phase 3.** Review becomes compose-only. Extract proposals get the mechanical check instead, which is cheaper and more precise for that stance.
- **Source-reading plan.** Unchanged. Compose steps are the ones that use `read_reference_section`; extract steps mostly use the inline documents and `search_references`.

## Delivery order

```
fill-run B + C ──► this plan steps 1–4 ──► drafting-quality Phase 2 ──► step 5 (with Phase 3)
                        │
                        └── step 6 lands with step 4
```

Steps 1 and 2 (stance resolution and prompt blocks) can ship alone and improve ordinary chat turns. Steps 3 and 4 need the fill-run step runner. Step 5 needs the brief and lands with drafting-quality Phase 3. Phase 0 of the drafting-quality plan should record its baseline before any of this ships, so the judge can attribute the change.

Estimate: steps 1–2 [2 hr], steps 3–4 [3 hr], step 5 [3 hr], step 6 [1.5 hr], tests throughout. **[~9.5 hr]**

## Verification

1. `npm test` and `npm run build`.
2. FMS task-order mod with one small document: the fill run has only extract steps, runs at Fast regardless of the picker, and every proposed string value is found in the source or flagged.
3. LCSP with the WFR inputs: the progress line shows extract steps, the brief, then compose steps; compose steps run with thinking; the Changes tab shows "Based on" lines; the judge's *Traceability* score does not fall against the Phase 2 result and *Specificity* rises.
4. Chat troubleshoot export: extract calls show the standard model and no thinking tokens; compose calls show the advanced model.
5. Provider check: everything runs with `thinking`, `effort` and `promptCaching` flags off, since tier routing degrades to model selection only.

## Risks

- **Mode leakage in mixed fields.** A compose field that quotes a contract number is the failure case. The identifier rule in both blocks and the mechanical check on extract columns cover it. The judge's unsupported-claim count is the measure.
- **Thinking cost on 54 compose fields.** Acceptable under the token guideline, but context room is the real limit, so this plan lands after the source-reading plan's budget and caching work.
- **Picker expectations.** A user who chose Fast and sees thinking on freetext needs to know why. The progress line note is the fix; if it is not enough, add a Settings toggle to disable per-step routing.

## Not doing

- A global "extraction mode" or "drafting mode" switch. The LCSP needs both within one run, and the FMS memos with two freetext fields need both within one section.
- Letting the model choose its own stance. Stance is a schema fact, like field type.
- An agent framework for the step runner. See `docs/2026-10-26-agentic-framework-notes.md`.

## Documentation

Final step: ask the user whether to update `changelog.d/`, `README.md` (AI panel: stance labels, progress line, "Based on" lines), `docs/help/template-authoring-guide.md` (`ai_mode`), and `docs/public/development-plan.md`. Do not run `/update-docs` automatically.
