# Tune freetext drafting style to the customer

## Context

User-requested (2026-10-20). Tracked under *Remaining MVP-gate items* in `docs/public/development-plan.md`, ahead of the backlog.

LCSP customers differ on how narrative sections should read. Some want bullet-heavy sections; others want flowing paragraphs. Today the only way to steer the AI is to say so in chat, and that instruction is lost when the user changes scope, starts a new thread, or reopens the document. The LCSP has 57 freetext fields ([lcsp.schema.json](../src/schemas/lcsp/lcsp.schema.json)), so re-stating the preference per field is not workable.

A user suggested a bullets/paragraphs toggle. The toggle is rejected as the mechanism because bullets vs. prose is one axis of several that customers care about: sentence length, voice, tense, acronym handling, whether to cite source paragraphs, whether sub-headings are allowed, how much hedging. A two-value switch cannot carry that and would grow a new toggle per customer request. The drafting prompt already consumes free-form guidance well (field `ai_hint`, the no-subheadings rule in [bulkEdit.ts:618-621](../src/ai/bulkEdit.ts#L618-L621), and `FREETEXT_DRAFTING_RULE` in [promptUtils.ts:58](../src/ai/promptUtils.ts#L58)), so free text is the natural carrier. The toggle survives as a preset that fills the free text.

Design constraints:

- Schema-first: the mechanism must be schema-agnostic. No LCSP-specific code.
- Provider portability: style is plain text in the system prompt. No Anthropic-only parameters.
- No generation changes needed: [markdownToWordXml.ts](../src/generation/markdownToWordXml.ts) already renders list items, so bullet-heavy drafts render today.

## Priority

Build the style-reference upload first. It is the least effort for the user: drop in the customer's previous document and the style is captured, including conventions the user would never think to write down. The free-text style note is second, as the fallback for customers with no prior document and as the place where the user can see and correct what the AI inferred from the reference. The restyle action is third. Per-section override and user default are speculative; do not build them until a user asks for something the first three cannot express.

| Phase | Item | Priority | Estimate | Build now? |
|---|---|---|---|---|
| 1 | Style reference upload role, deriving a style note | P1 | 3.5 hr | Yes |
| 2 | Editable document-level style note + presets | P1 | 2.5 hr | Yes, same release as Phase 1 |
| 3 | Reformat action on a drafted field or section | P2 | 1.5 hr | After Phases 1 and 2 are in use |
| 4 | Per-section style override | P3 | 2 hr | Only if the document note proves insufficient |
| 5 | User-level default style | P3 | 1 hr | Only if users serve one customer repeatedly |

Phases 1 and 2 share one storage field (`session.draftingStyle`) and one prompt block. Phase 1 writes the field from the reference document; Phase 2 lets the user read and edit it. Ship them together: shipping Phase 1 alone means the user cannot see or correct what was inferred, and shipping Phase 2 alone means the user does the work the reference could have done.

Why Phase 4 is deferred even though the LCSP mixes styles: a derived or hand-written note can already say "bullets for Integrated Schedule and Performance Requirements, prose everywhere else" and the model will follow it. Build the structured override only if that proves unreliable.

## Phase 1 — Style reference upload role, deriving a style note [P1, 3.5 hr]

Let the user mark an uploaded document (typically the customer's previous LCSP, or any document the customer wrote) as a style reference rather than a factual source.

### 1a. Derive, don't retrieve

Do not feed the reference document into the drafting prompt. A full prior LCSP is large and would be chunked into RAG, and style is a whole-document property that chunk retrieval captures poorly. It would also be re-sent on every call. Instead, run a one-time analysis when the role is assigned: send the reference text (first ~30k characters, which comfortably covers the introduction and several body sections) to `models.standard` with a fixed instruction to describe the document's style in a short note, then store the result in `session.draftingStyle` (Phase 2's field).

Analysis instruction, kept in `src/ai/draftingStyle.ts`:

```
Describe how this document is written so another writer could match it. Cover: paragraphs vs. bullet points and when each is used; typical sentence and paragraph length; voice and tense; how acronyms are introduced; heading and numbering conventions within sections; use of tables; how hedged or definite the language is; any recurring phrasing. Do NOT summarize the content and do NOT quote facts, names, dates, or amounts. Output 6 to 12 short lines, no preamble.
```

This resolves the RAG concern, costs one call per reference instead of one per draft, and makes the inferred style visible and editable through Phase 2's UI. If the user assigns a second style reference, re-run on both and replace the note; tell the user it was replaced.

### 1b. Role plumbing — [src/ai/bulkEdit.ts](../src/ai/bulkEdit.ts), upload UI

Roles today come from each schema's `recommended_uploads`, so a cross-schema role needs a small engine addition: a built-in `style-reference` role offered for every schema in the role picker. Documents with this role are **excluded** from the drafting prompt's `<document>` set and from RAG retrieval. They exist only to produce the note. Their "Source document guidance" entry is therefore unnecessary; the note carries the style.

This exclusion is the whole point. Without it a prior LCSP will be mined for facts about the wrong program.

### 1c. Prompt injection — shared with Phase 2

See Phase 2b. The derived note is injected the same way a hand-written note is; the model never knows which it was.

### 1d. Tests

- Unit: the analysis request is built with the fixed instruction and truncated text; the response is stored on the session.
- Prompt: a document with role `style-reference` does not appear in the user message's `<document>` set (extend the existing bulkEdit prompt tests).
- Fixture: one real redacted reference paragraph set and a snapshot of the derived note, to catch instruction drift.

## Phase 2 — Editable document-level style note with presets [P1, 2.5 hr]

### 2a. Persist the note — [src/db/types.ts](../src/db/types.ts), [src/db/dexie.ts](../src/db/dexie.ts)

Add `draftingStyle?: string` to `Session`. Phase 1 writes this field; Phase 2 shows and edits it. Optional and additive; no index needed, so no Dexie `.stores()` change and no upgrade function. Document it next to `fieldMeta`.

Add the same field to `SessionExportFile.session` so the style travels with a handoff. Export `version` stays at 1; the field is optional, so older importers ignore it and newer importers accept files without it. Add a round-trip case to the session export test.

### 2b. Inject into every drafting prompt — [src/ai/bulkEdit.ts](../src/ai/bulkEdit.ts), [src/ai/unifiedPrompt.ts](../src/ai/unifiedPrompt.ts)

Add an optional `draftingStyle?: string` parameter to `buildBulkEditChatSystemPrompt` and thread it through `buildUnifiedSystemPrompt` for all three scopes. When present, emit a `## Drafting Style` block immediately after the `## Rules` block:

```
## Drafting Style
The customer for this document has the following style preferences. Apply them to every freetext field you draft or revise. They govern form, not facts; the grounding rules above still control what you may assert.
<note text>
```

The "form, not facts" sentence prevents a note like "be confident" from overriding the grounding rules. Place the block in the system prompt so it is covered by the existing system-prompt caching in [litellm.ts](../src/ai/litellm.ts) and the user can edit it without invalidating conversation history.

Call sites: find where `buildUnifiedSystemPrompt` is called from `useAiChat` / `AiPanelContext` and pass `session.draftingStyle`. Also pass it to the document review prompt ([documentReviewPrompt.ts](../src/ai/documentReviewPrompt.ts)) so review does not flag bullet sections as "unprofessional tone" when the customer asked for bullets.

Tests: extend [unifiedPrompt.test.ts](../src/ai/unifiedPrompt.test.ts) with one case asserting the block appears for each scope when set and is absent when undefined.

### 2c. UI — AI panel

Add a "Drafting style" control in the AI panel header area (near the scope selector in `src/components/ai-panel/`). Collapsed state shows a one-line summary ("Derived from <filename>" / "Narrative" / "Bulleted" / "Custom" / "Not set"). Expanded state shows:

- When the note was derived from a style reference (Phase 1), a line "Derived from <filename>" above the textarea so the user knows where it came from and can correct it.
- Three preset buttons: **Narrative**, **Bulleted**, **Mixed**. Clicking one replaces the textarea contents with the preset text below. The user can then edit.
- A textarea bound to `session.draftingStyle`, saved through `updateSession` wrapped in `trackWrite()` on blur, debounced the same way answers are.
- A "Clear" link.

Preset text (keep in one constants module, e.g. `src/ai/draftingStylePresets.ts`, so it is testable and reusable by Phase 5):

- **Narrative:** "Write in complete paragraphs. Use bullet lists only for enumerations of four or more discrete items (for example a list of annexes or deliverables). Open each section with a one-sentence statement of purpose. Third person, present tense. Spell out each acronym on first use within a section."
- **Bulleted:** "Lead each section with one or two sentences of context, then present the substance as concise bullet points. One idea per bullet; bullets are fragments or single sentences, not paragraphs. Use bold lead-ins for bullet groups instead of sub-headings where sub-headings are not permitted. Spell out each acronym on first use within a section."
- **Mixed:** "Use paragraphs for strategy, rationale, and context (introductions, overviews, approach descriptions). Use bullet points for enumerable content (requirements, risks, schedules, responsibilities, deliverables). Third person, present tense. Spell out each acronym on first use within a section."

The presets are intentionally generic. Nothing in them is LCSP-specific, so they work for every schema.

Changing the note does not re-draft anything. Show a one-line hint under the textarea: "Applies to new drafts. To restyle existing text, ask the AI to reformat a section." Phase 3 turns that hint into a button.

### 2d. Document set sessions

A set session has one `Session` record, so the note applies to every member document. That is the desired behavior: the customer is the same across the set.

## Phase 3 — Reformat action [P2, 1.5 hr]

For the case where a customer changes their mind after a section is drafted. Add a canned prompt, available in field scope and section scope, labelled "Restyle to match drafting style". It sends a fixed user message:

```
Reformat the current value(s) of the in-scope freetext field(s) to match the Drafting Style in your instructions. Preserve every fact, figure, name, and commitment exactly. Do not add or remove substantive content. Propose the result with propose_changes.
```

This reuses the existing proposal flow, so the user sees a diff and approves per field. If `draftingStyle` is empty, disable the action with a tooltip pointing to the style control. No new tools, prompt rules, or storage.

## Phase 4 — Per-section override [P3, 2 hr]

Add `draftingStyleBySection?: Record<string, string>` to `Session`. In section and field scope, emit the section's override in place of the document note; in document scope, emit the document note plus a short list of section exceptions. UI: a "Style for this section" link in the section header of the wizard that opens the same textarea and presets.

Build only if users report the model ignoring per-section instructions written into the document note.

## Phase 5 — User-level default [P3, 1 hr]

Add `defaultDraftingStyle` to [UserPreferencesContext.tsx](../src/context/UserPreferencesContext.tsx) (localStorage, like `profile`). On session creation, copy it into `session.draftingStyle`. Settings page gets the same preset buttons and textarea. The session copy is what the prompt reads, so changing the default never silently changes an existing document.

## Out of scope

- Per-field style overrides. The LCSP has 57 freetext fields; nobody will maintain that, and field-scope chat already covers one-off cases.
- Schema-declared style. Style belongs to the customer, not the document type, so it does not go in `.schema.json`.
- Changing Word output formatting (list styles, numbering). Existing Markdown-to-Word rendering is sufficient.

## Documentation step

After Phases 1 and 2 ship, ask the user whether to update `changelog.d/`, `README.md`, and `docs/public/development-plan.md` to reflect the change. Do not run `/update-docs` automatically.
