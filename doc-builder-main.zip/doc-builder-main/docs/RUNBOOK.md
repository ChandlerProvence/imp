# Doc Builder — Troubleshooting Runbook

Quick reference for diagnosing and fixing template/schema issues. All fixes follow the same workflow: **branch → fix → push → MR → merge to `main` → auto-deploys**.

---

## Quick Start

```bash
# Clone and install
git clone <repo-url> && cd doc-builder && npm ci

# Run all tests (including template integrity checks)
npm test

# Run ONLY the template integrity tests
npx vitest run src/schemas/templateIntegrity.test.ts

# Validate a single template against its schema (Python)
python3 tools/docx-utils.py validate src/schemas/<dir>/<file>.docx src/schemas/<dir>/<schema>.schema.json
```

---

## How CI Catches Template Bugs

The `unit-test` job in CI runs `npm test`, which includes **Template Integrity** tests (`src/schemas/templateIntegrity.test.ts`). These check:

| Check | What it catches |
|-------|-----------------|
| Every `{{TAG}}` in .docx → exists in `template_key_map` | Typos in the Word template |
| Every `template_key_map` key → exists as `{{TAG}}` in .docx | Dead mappings in schema |
| Every `template_key_map` value → resolves to a real field | Broken field references |
| Loop tags → point to table-type fields | Wrong field types |
| Column tags inside loops → match `template_column_map` | Table column mismatches |

### Reading a CI failure

```
FAIL  src/schemas/templateIntegrity.test.ts > Template Integrity > fms-tte-mod > every template_key_map value resolves to a real field
  TKM entries pointing to non-existent fields: MY_TAG → "header.wrong_field"
```

This tells you:
- **Which schema:** `fms-tte-mod`
- **What's wrong:** The tag `MY_TAG` points to `header.wrong_field` which doesn't exist
- **Where to fix:** `src/schemas/fms-tte-mod/fms-tte-mod.schema.json` → `template_key_map`

---

## Common Bug Patterns & Fixes

### 1. "Blank field in the generated document"

**Symptom:** User generates a .docx and one field shows `{{TAG_NAME}}` instead of their answer.

**Cause:** The `template_key_map` value doesn't match any field the user filled in.

**Fix:**
1. Open `src/schemas/<dir>/<schema>.schema.json`
2. Find the tag in `template_key_map`
3. Verify the value matches a real `section_id.field_id` in `sections`
4. Common mistake: typo in section or field ID

```json
// WRONG — "headr" is a typo
"MY_TAG": "headr.field_name"

// RIGHT
"MY_TAG": "header.field_name"
```

### 2. "Tag in template but not in schema" (CI failure)

**Symptom:** CI reports a tag found in the .docx that has no entry in `template_key_map`.

**Fix:** Either:
- Add the tag to `template_key_map` in the `.schema.json`, OR
- Remove the `{{TAG}}` from the Word template if it shouldn't be there

### 3. "TKM key defined but missing from template" (CI failure)

**Symptom:** Schema defines a mapping that doesn't correspond to any tag in the .docx.

**Fix:** Either:
- Add `{{TAG}}` to the Word template where the content should appear, OR
- Remove the dead entry from `template_key_map`
- If intentional, add to `ALLOWED_MISSING_FROM_TEMPLATE` in `templateIntegrity.test.ts`

### 4. "Table loop produces wrong columns"

**Symptom:** A table in the output has blank or mismatched columns.

**Fix:**
1. Check `template_column_map` in the schema
2. The outer key must match a `template_key_map` key that points to a table field
3. Inner keys = tag names in the Word template's loop
4. Inner values = column `id`s from the field's `columns` array

```json
"template_column_map": {
  "PTab": {                    // ← matches a TKM key
    "NOUN": "noun",            // ← Word tag : schema column id
    "NSN_NUMBER": "nsn"
  }
}
```

### 5. "Field not showing in interview wizard"

**Symptom:** A field exists in the schema but doesn't appear in the UI.

**Check:**
- Is the field in the correct `section`?
- Does the section have a valid `id` and `title`?
- Is the field `type` valid? (string, number, boolean, date, enum, freetext, table)
- For enum fields: does it have an `options` array?

---

## Project File Structure

```
src/schemas/
  <schema-id>/
    <schema-id>.schema.json    ← Schema definition (fields, TKM, TCM)
    <template>.docx            ← Word template with {{TAGS}}
  sets/
    *.set.json                 ← Document set groupings
  loader.ts                    ← Schema validator (runs at app load)
  templateIntegrity.test.ts    ← CI integrity checks
  types.ts                     ← TypeScript type definitions
```

### Key files for troubleshooting

| File | Purpose |
|------|---------|
| `src/schemas/<dir>/*.schema.json` | Schema definition — TKM, fields, structure |
| `src/schemas/<dir>/*.docx` | Word template with placeholder tags |
| `src/schemas/loader.ts` | Runtime schema validation (console errors) |
| `src/generation/generateDocx.ts` | Document generation logic |
| `tools/docx-utils.py` | Python utilities for template inspection |

---

## Useful Commands

```bash
# Extract all placeholders from a .docx
python3 tools/docx-utils.py extract-placeholders src/schemas/<dir>/<file>.docx

# Full validation (template vs schema)
python3 tools/docx-utils.py validate <docx> <schema.json>

# Run dev server to test locally
npm run dev

# Type-check without building
npm run typecheck

# Run all tests
npm test

# Run a specific test file
npx vitest run src/schemas/templateIntegrity.test.ts
```

---

## Deployment

Push to `main` → GitLab CI builds and deploys automatically to GitLab Pages.

**URL:** `https://ams-oot.pages.lsde.leidos.com/doc-builder/`

The pipeline runs: typecheck → unit tests → e2e smoke → build → deploy → verify.

If the template integrity tests fail, the MR cannot merge (CI gate).

### Scheduled e2e check

A pipeline schedule runs the `e2e-nightly` job against the live site every day at 18:00. It catches breakage that comes from outside the repo (browser updates, GitLab Pages, the network), with no deploy involved. AI and proxy calls are mocked inside the browser, so it needs no API key and doesn't depend on the LiteLLM proxy being up. Scheduled pipelines run only this job: no build, no deploy, no security scans.

**Setup (one time):** Build → Pipeline schedules → New schedule. Target branch `main`, custom interval `0 18 * * *` (every day at 18:00), set **Cron timezone** to your local zone, Active. No variables are needed. GitLab checks for due schedules every few minutes, so expect the job to start a little after 18:00 and finish within about 15 minutes.

**Ownership:** the schedule runs as the user who created it. If that user leaves the project or loses Developer access, the schedule goes inactive with no warning. When maintainers change, open the schedule and click **Take ownership**.

**Notifications:** the schedule owner gets a "Pipeline failed" email when a run fails and "Pipeline fixed" when the next run passes. This works by default, as long as the owner's notification level for the project isn't **Disabled**. Passing runs send no email.

Only needed when more than one person maintains the tool: turn on Settings → Integrations → **Pipeline status emails** so the others also get failure emails. Use the team list as recipients, check "Notify only broken pipelines", and set the branch filter to the default branch. It works on every GitLab tier.

**Check that it is still running:** no email means either everything passed or the job never ran (schedule inactive, owner lost access, runner down). Every week or two, open Build → Pipeline schedules and confirm **Last pipeline** is recent and passed. Do the same check when the tool changes hands.

**When it fails:** open the failed job and download the `e2e/test-results/` artifact (screenshots and traces). To reproduce locally against production:

```bash
E2E_BASE_URL=https://ams-oot.pages.lsde.leidos.com/doc-builder/ npx playwright test
```

A failure on both the scheduled run and the next MR's `e2e-smoke` points to a code problem. A failure only on the scheduled run points to the deployed site or its environment.

### GitLab tier

The security scans in `.gitlab-ci.ultimate.yml` can stay included on any tier. If the Ultimate subscription lapses, Dependency Scanning and DAST stop being created on their own (their rules check `$GITLAB_FEATURES`), SAST and Secret Detection keep running, and the MR security widget goes away. Nothing in the pipeline needs editing. Everything else in CI, including the schedule and its notifications, works on Free.

---

## AI Model Retirements

Model IDs are configured in `ENDPOINTS` (`src/ai/endpoints.ts`). At runtime the app asks each LiteLLM proxy (`GET /v1/models`) which models exist:

- **Configured model still listed:** the app uses it, even if a newer one exists. Settings shows "Newer model available" as an opt-in.
- **Configured model missing:** the app switches to the newest same-family model (e.g. another `…-sonnet-aws-comm-il2`) and shows a one-time "AI model changed" banner.
- **Users can override any role** under Edit → Settings → AI Models. Costs shown there come from LiteLLM `GET /model/info`.
- A diagnostics report (Copy diagnostics) lists each role's model and its `source`: `default`, `override`, `substituted`, or `missing`.

When the "AI model changed" banner appears, update the IDs in `ENDPOINTS` (`src/ai/endpoints.ts`) to the replacement and let `main` redeploy.

---

## AskSage (SharePoint) — disabled pending approval

SharePoint / OneDrive search through AskSage is turned off by the `askSage` feature flag (`src/ai/featureFlags.ts`, default `false`). The code is kept on purpose; don't delete it as unused. The full status, including what to change when it's turned back on, is the STATUS block at the top of `src/ai/asksage.ts`.

**Why:** the deployed site calls `api.asksage.leidos.com` cross-origin, and the AskSage API doesn't send CORS headers for our origin, so the browser blocks every request. It works only under `npm run dev`, through the Vite proxy.

**What we need from the AskSage team:** allow `https://ams-oot.pages.lsde.leidos.com` in the CORS policy of `api.asksage.leidos.com`.
- Methods: `POST` and the `OPTIONS` preflight.
- Request headers: `Content-Type`, `Accept`, `x-access-tokens`.
- Endpoints: `/user/get-token-with-api-key`, `/server/get-models`, `/server/query`.
- Credentials (cookies) aren't needed.

**Trying it locally:** in DevTools, run `localStorage.setItem("doc-builder:ai-feature-flags", JSON.stringify({ ...JSON.parse(localStorage.getItem("doc-builder:ai-feature-flags") ?? "{}"), askSage: true }))` and reload. Settings → AskSage appears, and the document picker's SharePoint column shows the AskSage controls instead of its "Coming soon" placeholder. Set it back to `false` to hide them again.

**Gate for re-enabling:** after AskSage confirms the change, the flag is turned on as above on the production URL, Test shows "✓ Connected", and a SharePoint search returns results that can be attached. Then follow the steps in the STATUS block.

---

## Adding a New Schema

1. Create `src/schemas/<new-id>/` directory
2. Add `<new-id>.schema.json` with fields, sections, TKM
3. Add the `.docx` template file
4. Register the import in `src/schemas/loader.ts` (add import + RAW_SCHEMAS entry)
5. Run `npm test` to verify integrity checks pass
6. If it's part of a document set, add to the relevant `src/schemas/sets/*.set.json`

---

## Escalation

If you can't figure it out from CI messages + this guide:
- The template integrity test file (`src/schemas/templateIntegrity.test.ts`) has inline comments explaining each check
- The Python tool `tools/docx-utils.py validate` gives a JSON report showing exactly what's in the template vs schema
- Schema validation errors during app load appear in the browser console (`[doc-builder] Schema validation failed...`)
