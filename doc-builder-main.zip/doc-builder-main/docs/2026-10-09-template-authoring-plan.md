# Template Authoring Plan — from upload-only to in-app template creation

**Date:** 2026-10-09
**Status:** Phase 1 complete (shipped 2026-10-08, `worktree-user-templates`). Phase 2 shipped 2026-10-19 (Steps A–D), Step D2 pending. Phases 3–6 proposed.
**Phase 2 breakdown:** `docs/2026-10-09-template-authoring-phase2-plan.md` splits Phase 2 into shippable steps (Steps A–D complete).
**Supersedes:** the *Custom templates — follow-ups* list in `docs/public/development-plan.md`, which this plan re-sequences.

## Goal

Let users create and maintain their own document templates without a developer, ending in two complementary capabilities:

1. **AI-assisted authoring** — generate the schema for a tagged Word file, and convert a finished Word document into a tagged template.
2. **Manual designation** — upload a Word document, walk through it, and mark each run of text as either a *field* (the user fills it in per document) or *fixed text* (rendered verbatim, never edited).

These are not competing end states. The manual designation UI is the review surface the AI features need anyway: every AI proposal lands there as a suggestion to accept, change, or reject. Building the manual path first means each phase ships a usable product, and the AI phases add speed rather than new concepts.

## Design principles

- **Every phase is shippable.** Each phase ends with a product a user can complete a template with, using less outside help than the phase before.
- **Manual before automatic.** Each AI phase populates a UI that already works by hand. When the model is unavailable, wrong, or disabled, the user finishes the job themselves on the same screen.
- **One validator.** Everything a user builds in-app passes through `validateUserTemplatePair()` (`src/schemas/userTemplateValidation.ts`) before install, exactly as uploads do today. New authoring surfaces never bypass it; they just produce fewer errors.
- **Convergence, not forks.** Custom templates remain a staging area on the way to shared built-ins (`tools/import-template-bundle.ts`, *Switch to official*). Nothing here changes that.
- **Provider portability.** AI calls use forced `tool_choice` with raw JSON-schema tools in `src/ai/toolDefinitions.ts`, through the LiteLLM proxy. No Anthropic-only parameters outside `featureFlags.ts`.
- **Port, don't invent.** `tools/docx-utils.py`, the `schema-generate` and `schema-prep` agents, and `docs/help/template-authoring-guide.md` already encode the rules. The in-browser versions are TypeScript ports with the same test fixtures, so CLI and browser behavior stay aligned.

## Phase overview

| Phase | What the user can do at the end | Automation | Est. |
|---|---|---|---|
| 1 ✅ | Download an official template, edit the Word file and schema with an external chatbot, re-upload, see validation errors with fixes, submit for team use | Validation only | done |
| 2 | Tag a Word file in Word, upload it alone, get a starter schema generated from the tags, fix labels/types/sections in an in-app editor, preview the output, install | Deterministic scaffold + editor | 14 hr |
| 3 | Same as 2, but the AI fills in labels, types, sections, and hints from document context, and repairs validation errors; the user reviews in the Phase 2 editor | AI schema generation | 10 hr |
| 4 | Upload a *finished* Word document with no tags, select text in-app and mark it as a field (or fixed text), have the app insert the tags, then continue with 2 or 3 | Manual templatizing | 16 hr |
| 5 | Same as 4, but the AI pre-marks likely fields, repeated values, table rows, and guidance paragraphs; the user accepts or rejects each in the Phase 4 UI | AI templatizing | 10 hr |
| 6 | Iterate on an installed template (re-upload a revised Word file and keep the schema), edit simple field dependencies (profile fill, copy from another field, show only when), group custom templates into sets, pick from a shared catalogue; external chatbot guide retired | Hardening and convergence | 23 hr |

Estimates assume one developer with Claude Code, matching the convention in `development-plan.md`.

---

## Phase 1 — Upload, validate, share ✅ (complete)

Shipped in `changelog.d/20261008-113707.worktree-user-templates.md`. Summary of what exists, since later phases build on it:

- `/templates` page: upload `.schema.json` + `.docx` (or a bundle), install to IndexedDB (`userTemplates`, Dexie v12), draft from it, archive it.
- `templateScan.ts` runs the CI integrity checks in the browser; `issueCatalog.ts` gives every issue code a plain-language fix; `ValidationReport` has *Copy for your AI assistant*.
- *Download as starting point* / *Download for editing* produce a zip with the schema, the Word file (variant replacements baked in), and `AI-EDITING-GUIDE.md`.
- `cleanTemplateTags()` already rewrites docx XML in the browser (hint stripping, split-run merging) — the first in-browser docx edit, and the pattern Phase 4 extends.
- *Submit for team use* bundle + email; `tools/import-template-bundle.ts` for promotion; *Switch to official* on promotion.
- Session exports embed custom templates.

**Gap this phase leaves:** the schema is still written by hand or by an external chatbot, with copy-paste round trips. Templatizing a finished document is a manual Find-and-Replace exercise in Word.

---

## Phase 2 — Tag-driven starter schema and in-app schema editor

Detailed step breakdown: `docs/2026-10-09-template-authoring-phase2-plan.md`.

**Product at the end:** a user who can add `{{TAGS}}` in Word never touches JSON. They upload the Word file alone, the app proposes a schema from the tags, they fix it up in a form, preview the output, and install.

### 2.1 Starter schema from a tagged `.docx` [3 hr]

New pure module `src/schemas/scaffoldSchema.ts`:

- Input: `TemplateScan` (already produced by `scanTemplate()` — placeholders, hints, loops, column tags, header/footer locations).
- Output: a `DocumentSchema` that passes `validateUserTemplatePair()` with zero errors.
- Rules, ported from `schema-generate` where they are deterministic:
  - Every scalar tag → one field; `template_key_map` entry per tag. Default type `string`; `date` when the tag name matches `/date|_dt$|_on$/i`; `number` when it matches `/amount|count|qty|total|price|cost|rate|num(ber)?$/i`; `freetext` when the tag sits alone in its own paragraph under a heading (use the structure walk from `extract-structure`).
  - Inline `{{TAG: hint}}` → `ai_hint` (hints already extracted by `scanTemplate`).
  - Loop `{{#TAG}}…{{/TAG}}` → one `table` field with columns from the in-loop tags; `template_column_map` generated explicitly.
  - Freetext tags in headers/footers are downgraded to `string` with a warning (schema-generate rule 17).
  - Sections: one per top-level heading that contains tags, in document order; tags before the first heading go to a `header` section. Section/field ids derived from tag names (lowercase snake, deduplicated).
  - Labels: humanized tag name (`SCS_NAME` → "SCS name"). The user fixes these in 2.2; the AI fixes them in Phase 3.
  - `id` from the filename, suffixed `-custom`; `title` from the filename with template suffixes stripped (schema-generate rule 16 patterns); `output_filename` only when `x`-runs or similar patterns are present.
- Tests: fixture-driven, one tagged `.docx` per pattern (scalar, hints, loop, header/footer, no headings), asserting the scaffold validates and maps every tag.

### 2.2 In-app schema editor [6 hr]

New route `/templates/edit/:id` (and used inline by the upload flow). Form-based, not a JSON editor:

- Sections: rename, reorder, merge, split; add a description.
- Fields: label, type (with the type-specific extras: `options` for enum/multiselect, columns for table), required, help text, `ai_hint`, reorder, move between sections.
- A read-only *Template tags* panel: every tag, which field it maps to, and the paragraph it appears in (from `scanTemplate`), so the user can see what each field renders into.
- Guardrails from the authoring guide's *Rules for custom templates*: advanced features (`computed`, `formula`, `derived_fields`, `validate`, `same_as`, `auto_fill`, `aggregates`, `rows`, `toc`, `heading_style_map`, `recommended_uploads`, `template_heading`, `outline_number`, `heading_level`) are preserved untouched and shown as a locked badge, not editable here. Phase 6 makes `auto_fill`, `same_as`, and simple `visible_when` conditions editable.
- Save re-runs `validateUserTemplatePair()`; errors render in the existing `ValidationReport`; a valid save updates the IndexedDB record and bumps `version`.
- Works for already-installed custom templates too (edit labels on a template a chatbot wrote), which is the backlog item *In-app schema editor* [6 hr].

### 2.3 Template preview before install [2 hr]

In the upload/editor flow, render the template with sample answers (`renderDocxFromArrayBuffer` + `docxToHtmlPreview`) so the user sees where each field lands before installing. Sample values are the field label in brackets (`[Preparer name]`) so the preview doubles as a tag-location map. Backlog item *Template preview before install*.

### 2.4 Upload flow changes [3 hr]

- The upload dialog accepts a `.docx` alone. If no schema is provided, it runs `cleanTemplateTags()` → `scanTemplate()` → `scaffoldSchema()` and opens the editor with the result instead of failing with "schema missing".
- The *Modify an official template* flow gains an *Edit in app* path next to *Download as starting point*: clone the built-in schema to a `-custom` id and open the editor directly.
- `ManageTemplates.tsx` (451 lines) should not absorb this. Add `src/components/templates/TemplateEditor/` and keep the page as the list.

**Acceptance test:** a user with Word and no chatbot takes `cases/` sample document, adds six tags including one table loop, uploads the `.docx` only, corrects two field types and all labels in the editor, previews, installs, and generates a document — with zero JSON edited and zero validation errors shown that the editor could not fix in place.

**Docs:** authoring guide gets a short "you may not need this" preface pointing at the in-app path; help page for the editor.

---

## Phase 3 — AI schema generation from a tagged `.docx`

**Product at the end:** the scaffold from Phase 2 arrives already finished — human labels, correct types, sensible sections, `ai_hint` written from surrounding guidance text. The user reviews rather than authors.

### 3.1 Document context extraction [2 hr]

`src/schemas/templateContext.ts`: for each tag, collect the heading path, the paragraph text with the tag, the previous and next paragraphs, table header row when inside a loop, and whether it is in a header/footer. Also collect candidate guidance paragraphs (style name contains Guidance/Instruction/Note, or the paragraph starts with a directive verb and precedes a tag — schema-generate step 1.6 heuristics). Cap total context at the existing prompt limit; truncate per-tag context evenly rather than dropping tags.

### 3.2 `propose_schema` tool [4 hr]

- Raw JSON-schema tool in `toolDefinitions.ts`; forced `tool_choice`; portable per CLAUDE.md. Response shape mirrors `DocumentSchema` minus the mechanical parts (`template_key_map`, `docx_template`, ids are computed locally so the model cannot break the mapping).
- System prompt is the *Instructions for the AI assistant* section of `docs/help/template-authoring-guide.md` plus the schema-generate rules that need judgment (labels as questions, units stay in the template, `freetext` for prose, `enum` for closed sets, section grouping, filename-derived `output_filename`, author hints take priority).
- Model: the extraction role (`models.sonnet`-tier) by default; the Thorough tier available in the UI for large templates.
- Flow: scaffold (Phase 2) → proposal → merge (proposal wins on label/type/section/hint; scaffold wins on ids, TKM, loops) → `validateUserTemplatePair()` → editor.

### 3.3 Repair loop [2 hr]

If validation returns errors, send the issues with their `ISSUE_CATALOG` fix text back to the model once with a `repair_schema` tool (same shape), then stop. Remaining errors go to the editor for the user. Two round trips maximum; the user is never blocked on the model.

### 3.4 Guidance stripping [2 hr]

Where 3.1 identified guidance paragraphs that were used as `ai_hint`, offer *Remove guidance text from the Word file* as a checkbox list in the editor (default on for paragraphs the model used as hints, off otherwise). Removal is an in-browser XML edit of whole paragraphs — the simplest case of the Phase 4 editor, and schema-generate rule 14 ("the template is an output artifact").

**Acceptance test:** for each built-in schema, strip its schema to the `.docx` alone, run Phase 3, and compare to the hand-authored schema: ≥90% of fields match on type, every table loop is a `table` field, and the output passes `validateUserTemplatePair()` with no errors after at most one repair pass. Run as an opt-in LLM-gated test (`RUN_LLM_TESTS=true`) alongside the existing stubs in `extractionTypeConformance.test.ts`.

**Docs:** authoring guide Procedure B becomes "or upload the Word file and let the app draft the schema"; `CLAUDE.md` notes the browser module as the source of truth for schema-generate rules that have been ported.

---

## Phase 4 — Manual templatizing of a finished document

**Product at the end:** a user with a completed Word document and no template experience can turn it into a template in the browser by pointing at what varies. The output is a tagged `.docx`, which flows into Phase 2 or 3.

### 4.1 Document viewer with run-level selection [5 hr]

- Render the uploaded `.docx` as paragraphs and tables in the app's own React view (not mammoth HTML — selection must map back to XML). Build from `word/document.xml`: paragraph → runs → text, with a stable `paragraphIndex`/`runIndex`/`charOffset` address, reusing the walker already in `templateScan.ts` and `cleanTemplateTags()`.
- Headers and footers shown in collapsed groups so they can be tagged with scalar fields.
- Images shown as placeholders with dimensions and the preceding paragraph as caption (schema-prep step 2's "is this a table screenshot?" check becomes a visual question).

### 4.2 Designation actions [5 hr]

Selecting text offers:

- **Make this a field** — name (suggested from nearby label text, e.g. "Controlled by: Acme" → `CONTROLLED_BY`), type, and *replace all N other occurrences* when the same text appears elsewhere (schema-prep `--all`). Units rule enforced in the UI: if the selection matches `^\$?[\d,\.]+\s*[a-zA-Z%]+$` the app proposes tagging only the number and keeping the unit as fixed text.
- **Mark as fixed text** — explicit "never a field" marking, stored in a sidecar list so later AI passes (Phase 5) do not re-propose it. Fixed text needs no XML change.
- **Make this table a repeating table** — pick the data row(s); the app replaces cell values with `{{column_id}}` tags, adds `{{#Tag}}`/`{{/Tag}}` to the first and last cell, and removes extra data rows (schema-prep step 6).
- **Remove this paragraph** — for guidance and provenance text.
- **Undo / redo** over the edit list; nothing is written to the `.docx` until *Continue*.

### 4.3 In-browser docx editing module [4 hr]

`src/schemas/docxEdit.ts`, pure functions over PizZip, mirroring `docx-utils.py` subcommands with the same fixtures:

- `replaceText(range, tag)` — splits the containing `<w:t>` at the selection boundaries, keeps the run's formatting, handles selections that span runs (merge into the first run, as `cleanTemplateTags` does).
- `insertLoopTags(tableIndex, rowIndex, tag, columnIds)`.
- `removeParagraph(index)`.
- `fixNamespaces()` — port of `fix-namespaces` (Word "unreadable content" errors), run on every output.
- Golden tests: apply the edit list to a fixture, compare the result to what `docx-utils.py` produces for the same operations (`tools/tests/`).

Out of scope for the browser editor, shown as "not supported here" with a pointer to Word: tracked changes, content controls, fields inside `w:fldSimple`/`w:instrText`, text boxes. Detection of these is a new `templateScan` warning.

### 4.4 Flow [2 hr]

*Create from a finished document* on `/templates` → viewer → *Continue* → `cleanTemplateTags()` → Phase 2 scaffold (or Phase 3 proposal if AI is enabled) → editor → preview → install. The designations made in 4.2 seed field names and types in the scaffold so the user does not enter them twice.

**Acceptance test:** take one hand-authored ground-truth case (`cases/<id>/output - ground truth/`), templatize it through the viewer in under 20 minutes, generate a schema via Phase 2, enter the original values, and get a `docx-diff.py diff` of zero unallowed hunks against the original.

---

## Phase 5 — AI-proposed templatizing

**Product at the end:** the Phase 4 viewer opens with likely fields already highlighted. The user confirms rather than hunts.

### 5.1 `propose_placeholders` tool [5 hr]

- Input: the document's paragraph list (indexed), table header rows, image captions, and optionally a **reference schema** chosen from installed templates (schema-prep's strongest signal: reuse field names, hints, and `auto_fill` from a sibling document). Keep it under the prompt cap by sending paragraph text, not XML.
- Output per proposal: paragraph address and exact text span, tag name, type, confidence, `all_occurrences`, rationale, and a `kind` of `field | strip_guidance | table_rows | fixed`.
- Forced `tool_choice`, raw JSON-schema tool. Proposals are validated locally (the span must exist verbatim at the address) before display; anything that does not match is dropped, never auto-applied.

### 5.2 Review UI [3 hr]

Proposals render as pending highlights in the Phase 4 viewer, grouped by confidence (schema-prep: high → preselected, medium → selected but flagged, low → unselected). *Accept all high*, per-item accept/reject/edit. Rejections are stored as fixed-text markings so a re-run does not re-propose them.

### 5.3 Table image handling [2 hr]

For images the model flags as probable table screenshots, prompt the user for column headers and a loop tag, then `replaceImageWithTable()` (port of `replace-image-with-table`) inserts a Word table with a loop row. Model never does this unprompted; it cannot see inside images in this flow.

Then chain straight into Phase 3 so the schema proposal reuses the same context. From the user's view: upload a finished document, review two screens of suggestions, install.

**Acceptance test:** on three finished documents from `cases/`, ≥80% of the fields in the hand-authored schema are proposed at high or medium confidence with the correct span, and no proposal is applied that does not match the document text verbatim.

---

## Phase 6 — Iteration, sets, and convergence

**Product at the end:** custom templates have a lifecycle, not just a creation path, and the external-chatbot workflow can be retired.

- **Revise the Word file, keep the schema** [3 hr] — re-upload a `.docx` for an installed custom template; the app diffs tags (added / removed / renamed), proposes schema edits for the delta only, and preserves everything else. Today a re-upload replaces the pair wholesale.
- **Custom document sets** [7 hr] — `.set.json` upload or in-app set builder referencing built-in and custom ids; merged with `mergeSetSchemas`. Backlog item carried over.
  - *Why more than a set builder:* `mergeSetSchemas` shares an answer between templates only when the `section_id.field_id` paths are identical. Templates scaffolded from Word get section ids from heading text, and the Phase 2 editor keeps section and field ids read-only, so two custom templates with the same `{{VENDOR}}` tag under different headings ask for the vendor twice, and the user can't fix it in the app. Copies made with *Edit in app* keep official paths and are not affected.
  - Editable section ids (and field ids) in the editor, routed through the existing `retargetFieldPath()`.
  - *Match with another template:* pick a template, get suggested pairs by tag name or label, move the fields onto the same paths.
  - Set-level check when a set is built: type conflicts (today first-wins with only a console warning), table column mismatches (today the table splits in two), and questions asked twice. Same checks as the `set-health-check` agent runs for built-in sets.
  - The editor's save confirmation names the sets a template belongs to and which shared answers a path change affects.
- **Edit field dependencies in the editor** [6 hr] — turn the three most common locks into controls the user can change. Removing a dependency unlocks the field; the lock rules in `locks.ts` stay as they are.
  - *Fill from my profile* [1 hr]: a picker on text fields (none / name / title / phone / email) that writes `auto_fill`.
  - *Copy the answer from…* [1.5 hr]: a field picker that writes `same_as`, offering only fields of a compatible type and refusing cycles with the engine's existing cycle check.
  - *Show only when…* [3.5 hr]: "show this section or field only when field X is / is not / contains Y", which writes a named `content_blocks` entry and the `visible_when` reference. Offers only the operators `BlockCondition` supports; existing hand-written blocks stay read-only. Resolves open question 1.
  - Not included: formulas, totals, and derived values wait for the *Collapse overlapping schema mechanisms* backlog refactor, so one expression editor serves all three. `validate` rule forms (`range`, `compare`) follow the *Validation layer* backlog item.
- **Shared template catalogue** [4 hr] — reviewed bundles published as static files on GitLab Pages, listed in `/templates` with one-click install; `based_on` and revision tracked so *Switch to official* keeps working. Backlog item carried over; needs the approval process written in `RUNBOOK.md`.
- **Conflict resolution on session import** [2 hr] — keep / replace / install-as-copy when a progress file carries a different revision. Backlog item carried over.
- **Submission tracking** [1 hr] — GitLab issue template linked from the submit dialog. Backlog item carried over.
- **Retire the external guide** — once Phases 3 and 5 are stable, `docs/help/template-authoring-guide.md` shrinks to the schema reference and "fixing upload errors"; the download zips drop `AI-EDITING-GUIDE.md`. `templateAuthoringGuide.test.ts` stays as the drift test for the reference section.

---

## Sequencing and alternatives considered

- **Why the editor (Phase 2) before AI schema generation (Phase 3):** the AI output needs a review screen, and the fallback when the model is wrong is the same screen. Building Phase 3 first would mean reviewing in JSON, which is Phase 1 again with fewer copy-pastes.
- **Why manual templatizing (Phase 4) before AI templatizing (Phase 5):** same reason, plus the docx editing module in 4.3 is the hard engineering part either way. The AI in Phase 5 only decides *where* to edit.
- **If time is short after Phase 2:** Phase 3 alone is the biggest win per hour, because tagging in Word is something users already do and the schema is what they get wrong. Phase 4 is the next most valuable because finished documents are what users actually have.
- **If AI access becomes a problem** (model retirement, key policy): Phases 2, 4, and 6 are complete products with no model dependency.
- **Alternative rejected: edit in Word via an add-in.** A Word add-in would make designation feel native but needs a hosted manifest, sideloading approval, and a second codebase; it does not fit the no-backend, GitLab-Pages constraint.
- **Alternative rejected: contentEditable WYSIWYG of the whole document.** Editing document *content* in the browser is a different product. The viewer in Phase 4 is read-only except for tag insertion, which keeps the XML edits small and testable.

## Cross-cutting work

- **One docx toolkit, two runtimes.** As each `docx-utils.py` subcommand is ported to `src/schemas/docxEdit.ts`, point the agent prompts (`schema-generate.md`, `schema-prep.md`) at a `npx tsx` wrapper for the TS version so the CLI and browser cannot drift. Target: `docx-utils.py` becomes a thin shim or is deleted by the end of Phase 5.
- **Error handling.** New failure modes (unparseable docx part, unsupported construct, model proposal rejected) get `catalog.ts` entries and classifier cases per the project rule; nothing surfaces raw messages.
- **Storage.** Draft templates in progress (viewer edit lists, unaccepted proposals) are kept in a new `templateDrafts` IndexedDB table so a page reload does not lose a half-finished templatizing session. Covered by *Whole-database backup/restore* when that ships.
- **Bundle size.** The viewer and editor are route-split (`React.lazy`), in line with the *Bundle and route splitting* refactor.
- **E2E.** Extend `e2e/tests/08-custom-templates.spec.ts` per phase: scaffold-from-docx, editor save, viewer designation, AI flows with the mocked proxy.

## Dependencies on existing backlog

- *Validation layer* (min/max constraints) is independent; the editor exposes `validate` rules read-only until then.
- *Build-time schema compiler* is independent; if it lands first, `scaffoldSchema` output should be checked against the compiler's lint as well as `validateUserTemplatePair()`.
- *Settings by effort tier* would let Phases 3 and 5 pick a tier instead of a model family; not required.

## Open questions

1. ~~Should custom templates created in-app be allowed to use `visible_when` / `content_blocks`?~~ Resolved 2026-10-13: yes, through the simple *Show only when…* control in Phase 6 (*Edit field dependencies in the editor*). Hand-written blocks stay read-only.
2. Who approves catalogue entries (Phase 6), and is an MR per template acceptable as the approval mechanism?
3. Is the `cases/` corpus large enough for the Phase 3 and 5 acceptance tests, or do we need two or three more scrubbed finished documents?
