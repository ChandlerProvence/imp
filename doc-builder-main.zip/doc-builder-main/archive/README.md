# Archived schemas

Superseded document schemas kept for reference only. Nothing here is loaded by
`src/schemas/loader.ts`, copied into `dist/templates/` by the Vite build, or
scanned by the test suite.

This directory lives **outside `src/`** on purpose: `vite.config.ts` copies every
`src/schemas/**/*.docx` into a single flat `templates/` folder, so an archived
template with the same filename as an active one would silently overwrite it.

| Directory | Superseded by |
|-----------|---------------|
| `schemas/fms-tte-repair-funding-mod/` | `fms-to-mod` |
| `schemas/fms-repair-rr-funding-mod/` | `fms-to-mod` |

Delete these once the development-plan item "Remove legacy funding-mod schemas"
is closed.
